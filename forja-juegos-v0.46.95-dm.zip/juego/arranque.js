/* =========================================================
   JUEGO · ARRANQUE
   Lo que hace index.html (el juego exportado) al abrirse: lee los datos, crea la Partida
   (portada → menú → jugar) y mueve el bucle. El editor lo mete tal cual en el .html exportado.
   ========================================================= */
(function (F) {
  'use strict';
  const $ = (id) => document.getElementById(id);

  F.on('aviso', (html) => {
    const el = document.createElement('div');
    el.innerHTML = html;
    $('avisos').appendChild(el);
    setTimeout(() => el.remove(), 6000);
  });

  const vista = new F.Render.Vista($('pantalla'));
  F.Entrada.escuchar(vista.renderer.domElement);
  let partida = null;

  /* Todo el flujo (portada, menú principal, pausa, opciones, partidas) lo lleva FORJA.Partida.
     La portada "Pulsa cualquier tecla" hace falta: sin un clic o tecla el navegador no deja sonar música ni bloquear el cursor. */
  async function preparar(datos) {
    await F.Generadores.desempaquetar(datos.proyecto);   // el juego exportado los trae comprimidos
    F.Generadores.usarProyecto(datos.proyecto || {});   // las recetas se generan con el código que trae el proyecto
    await F.Assets.deserializar(datos.assets, false);
    const proyecto = F.Escena.normalizarProyecto(datos.proyecto || {});
    F.Assets.aplicarMateriales(proyecto);
    document.title = proyecto.nombre;
    $('capaInicio').style.display = 'none';
    partida = new F.Partida({ vista, proyecto, contenedor: document.body });
    partida.arrancar('portada');
  }

  let ultimo = performance.now(), fps = 0, cuadros = 0, acumulado = 0;
  function bucle(ahora) {
    requestAnimationFrame(bucle);
    if (!partida || !partida.listo(ahora)) return;
    const dt = Math.min((ahora - ultimo) / 1000, 1 / 20);
    ultimo = ahora;
    cuadros++; acumulado += dt;
    if (acumulado >= 0.5) { fps = Math.round(cuadros / acumulado); cuadros = 0; acumulado = 0; }
    partida.actualizar(dt);
    const j = partida.juego, jugando = partida.estado === 'jugando' && j;
    $('mira').style.display = 'none';   // la mira la dibuja el HUD (Juego ▸ HUD)
    $('depuracion').style.display = jugando && j.depuracion ? 'block' : 'none';
    if (jugando && j.depuracion) { const el = $('depuracion'), tx = j.textoDepuracion(fps); if (el._tx !== tx) el.textContent = el._tx = tx; }
  }
  requestAnimationFrame(bucle);

  // Sin datos exportados: se puede soltar un .forja.json para probar
  if (window.FORJA_JUEGO) {
    preparar(window.FORJA_JUEGO);
  } else {
    $('titulo').textContent = 'SIN JUEGO';
    $('ayudaInicio').innerHTML = 'En el editor pulsa <b>Exportar juego</b> y pon el <b>datos.js</b> en la carpeta <b>juego/</b>.<br>O arrastra aquí un proyecto <b>.forja.json</b> para probarlo.';
    window.addEventListener('dragover', (e) => e.preventDefault());
    window.addEventListener('drop', async (e) => {
      e.preventDefault();
      const f = e.dataTransfer.files[0];
      if (!f) return;
      try { await preparar(JSON.parse(await f.text())); } catch (err) { F.aviso('Archivo no válido: ' + err.message); }
    });
  }
})(window.FORJA);
