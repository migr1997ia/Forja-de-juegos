/* Componentes de objetos (puerta, plataforma móvil, trigger...) — llegan en el paso 0.2.
   Cada uno: FORJA.registrarComponente({ nombre, etiqueta, props, iniciar, actualizar, detener }) y su ruta en archivos.js */
