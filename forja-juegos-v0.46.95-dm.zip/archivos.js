/* =========================================================
   FORJA · LISTA DE ARCHIVOS DEL MOTOR
   La usan editor.html e index.html (el juego). Para añadir un módulo
   o componente nuevo: copia su archivo a su carpeta y añade su ruta aquí.
   ========================================================= */
(function () {
  const ARCHIVOS = [
    'lib/three-forja.js',

    'motor/nucleo.js',
    'motor/render.js',
    'motor/efectos.js',
    'motor/luces.js',
    'motor/fisica.js',
    'motor/entrada.js',
    'motor/tactil.js',
    'motor/hud.js',
    'motor/brujula.js',
    'motor/agua.js',
    'motor/generadores.js',
    'motor/assets.js',
    'motor/recogibles.js',
    'motor/inventario.js',
    'motor/enemigos.js',
    'motor/niveles.js',
    'motor/guardado.js',
    'motor/empujables.js',
    'motor/montables.js',
    'motor/aliados.js',
    'motor/estados.js',
    'motor/mecanismos.js',
    'motor/camaras.js',
    'motor/misiones.js',
    'motor/tactico.js',
    'motor/sonidos.js',
    'motor/gestor.js',
    'motor/horneado.js',
    'motor/clima.js',
    'motor/particulas.js',
    'motor/pasto.js',
    'motor/explosiones.js',
    'motor/campos.js',
    'motor/area.js',
    'motor/animbase.js',
    'motor/cinematicas.js',
    'motor/escena.js',
    'motor/juego.js',
    'motor/audio.js',
    'motor/opciones.js',
    'motor/menus.js',
    'motor/partida.js',

    'jugador/jugador.js',
    'jugador/modulos/cuerpo.js',
    'jugador/modulos/camara.js',
    'jugador/modulos/balanceo.js',
    'jugador/modulos/sprint.js',
    'jugador/modulos/nadar.js',
    'jugador/modulos/movimiento.js',
    'jugador/modulos/salto.js',
    'jugador/modulos/gravedad.js',
    'jugador/modulos/modelo.js',
    'jugador/modulos/sombra.js',
    'jugador/modulos/salud.js',
    'jugador/modulos/agachar.js',
    'jugador/modulos/esquiva.js',
    'jugador/modulos/interactuar.js',
    'jugador/modulos/pasos.js',
    'jugador/modulos/combate.js',
    'jugador/modulos/armas.js',
    'jugador/modulos/inventario.js',
    'jugador/modulos/linterna.js',
    'jugador/modulos/sigilo.js',
    'jugador/modulos/trepar.js',
    'jugador/modulos/orillas.js',
    'jugador/modulos/asomarse.js',
    'jugador/modulos/correrpared.js',
    'jugador/modulos/especial.js',

    // 'componentes/mover.js',   ← paso 0.2 en adelante
  ];
  // ?v= obliga al navegador a cargar los archivos nuevos tras cada actualización (subir en cada versión)
  const V = '0.46.95-dm';
  window.FORJA_ARCHIVOS = ARCHIVOS;   // el editor la usa para meter el motor dentro del .html exportado
  for (const ruta of ARCHIVOS) document.write('<script src="' + ruta + '?v=' + V + '"><\/script>');
})();
