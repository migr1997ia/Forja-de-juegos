/* =========================================================
   HERRAMIENTA · EMPAQUETAR EL MOTOR PARA "EXPORTAR JUEGO"
   El navegador no deja que una página abierta con doble clic (file://) lea otros archivos,
   así que el editor no puede leer el motor para meterlo dentro del .html exportado.
   Este script copia el texto del motor a editor/empaque.js (lo carga el editor).

   Se corre después de cambiar cualquier archivo del motor (lo hace Claude en cada versión):
     node herramientas/empaquetar.js
   Si no se corre, el editor avisa al exportar que el empaque es de otra versión.
   ========================================================= */
const fs = require('fs');
const path = require('path');
const raiz = path.join(__dirname, '..');

// La lista de archivos sale de archivos.js (la misma que usa el juego)
const texto = fs.readFileSync(path.join(raiz, 'archivos.js'), 'utf8');
const lista = [...texto.matchAll(/^\s*'([^']+\.js)',/gm)].map((m) => m[1]);
const version = (texto.match(/const V = '([^']+)'/) || [])[1] || '?';
const extra = ['index.html', 'juego/arranque.js'];

const archivos = {};
for (const ruta of [...lista, ...extra]) archivos[ruta] = fs.readFileSync(path.join(raiz, ruta), 'utf8');

const salida = '/* Generado por herramientas/empaquetar.js — no editar a mano. Motor ' + version + ' para "Exportar juego". */\n' +
  'window.FORJA_EMPAQUE = ' + JSON.stringify({ version, lista, archivos }) + ';\n';
fs.writeFileSync(path.join(raiz, 'editor', 'empaque.js'), salida);
console.log(`editor/empaque.js: motor ${version}, ${lista.length + extra.length} archivos, ${(salida.length / 1024).toFixed(0)} KB`);

/* ---------- editor/guia-animaciones.js: la guía del muñeco (docs/) para exportarla desde el editor (pestaña Armas) ---------- */
{
  const d = (f) => fs.readFileSync(path.join(raiz, 'docs', f), 'utf8');
  const guia = `/* Generado por herramientas/empaquetar.js desde docs/ — no editar a mano */\nwindow.FORJA_GUIA = ${JSON.stringify({ txt: d('ANIMACIONES-MUNECO.txt'), html: d('base-generador-personajes.html') })};\n`;
  fs.writeFileSync(path.join(raiz, 'editor', 'guia-animaciones.js'), guia);
  console.log(`editor/guia-animaciones.js: ${(guia.length / 1024).toFixed(0)} KB`);
}

/* ---------- editor-completo.html: TODO el editor en un solo archivo ----------
   Para abrirlo donde no se pueden leer archivos sueltos de una carpeta (tablet / celular Android desde
   el administrador de archivos, que lo abre como content://). Cada script lleva data-ruta para que
   "Exportar juego" lo pueda leer de la propia página. */
const seguro = (t) => t.replace(/<\/script/gi, '<\\/script');
let html = fs.readFileSync(path.join(raiz, 'editor.html'), 'utf8');
const leer = (r) => fs.readFileSync(path.join(raiz, r), 'utf8');
html = html.replace(/<link rel="stylesheet" href="editor\/editor\.css[^"]*">/, () => `<style>\n${leer('editor/editor.css')}\n</style>`);
const motor = lista.map((r) => `<script data-ruta="${r}">\n${seguro(leer(r))}\n</script>`).join('\n');
// index.html y arranque.js como texto (JSON con "<" escapado: el HTML no los puede confundir con etiquetas)
const textos = `<script>window.FORJA_TEXTOS = ${JSON.stringify(Object.fromEntries(extra.map((r) => [r, leer(r)]))).replace(/</g, '\\u003c')};</script>`;
html = html.replace(/<script src="archivos\.js[^"]*"><\/script>/, () =>
  `<script>window.FORJA_ARCHIVOS = ${JSON.stringify(lista)}; window.FORJA_UN_ARCHIVO = true;</script>\n${motor}\n${textos}`);
html = html.replace(/<!--[^>]*empaquetar[^>]*-->\s*<script src="editor\/empaque\.js[^"]*"><\/script>/, '');
html = html.replace(/<script src="(editor\/[^"?]+\.js)[^"]*"><\/script>/g, (m, r) => `<script>\n${seguro(leer(r))}\n</script>`);
// con la versión en el nombre (editor-completo-v0.25.0.html) para distinguir cuál tiene cada quien.
// Va FUERA de la carpeta del proyecto (../Respaldos/Editores): en forja-juegos solo está la versión de carpetas
for (const f of fs.readdirSync(raiz)) if (/^editor-completo(-v[\d.]+)?\.html$/.test(f)) fs.unlinkSync(path.join(raiz, f));
const destino = path.join(raiz, '..', 'Respaldos', 'Editores');
fs.mkdirSync(destino, { recursive: true });
const nombreCompleto = `editor-completo-v${version}.html`;
fs.writeFileSync(path.join(destino, nombreCompleto), html);
console.log(`Respaldos/Editores/${nombreCompleto}: ${(html.length / 1024).toFixed(0)} KB (todo en un archivo)`);
