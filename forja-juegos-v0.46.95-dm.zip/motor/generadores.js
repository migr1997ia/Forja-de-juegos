/* =========================================================
   FORJA · GENERADORES (recetas)
   Un recurso puede venir como RECETA (nombre.receta.json) en vez de como archivo terminado: los ajustes + la semilla.
   El código que la convierte en geometría es el GENERADOR de la app que la hizo, versionado:
     window.FORJA_GENERADORES['forja-terrenos@1'] = { app, generador, generar(receta, THREE, opciones) → { escena, info } }
   escena = THREE.Group con la misma forma que la raíz de su GLB (nodo «nivel» con userData.forja, «geometria» y
   «marcadores»): así un nivel de receta se usa igual que un GLB (materiales, líquidos, convertir marcadores…).
   El código de cada generador va DENTRO del proyecto (proyecto.generadores['app@n'] = texto): el editor lo copia del
   HTML de la app (su <script id="forja-generador">) y el juego exportado lo trae consigo; no hace falta la app.
   Lo ya generado se guarda en memoria mientras dura la sesión (misma receta = mismo resultado).
   ========================================================= */
(function (F) {
  'use strict';
  const T = THREE;
  const G = {};
  let codigos = {};                  // 'app@n' → código (del proyecto)
  const cargados = new Set();        // códigos ya ejecutados
  const cache = new Map();           // texto de la receta → { escena, info }

  const registro = () => (window.FORJA_GENERADORES = window.FORJA_GENERADORES || {});
  G.clave = (receta) => `${receta.app}@${receta.generador || 1}`;

  // ¿es una receta válida? (JSON con formato 'forja-receta')
  G.leer = function (datos) {
    const txt = typeof datos === 'string' ? datos : new TextDecoder().decode(datos);
    const r = JSON.parse(txt);
    if (!r || r.formato !== 'forja-receta' || !r.app) throw new Error('no es una receta de la Forja');
    return { receta: r, texto: txt };
  };

  // ejecuta el código de un generador (lo registra en window.FORJA_GENERADORES)
  G.cargarCodigo = function (codigo) {
    if (!codigo || cargados.has(codigo)) return;
    cargados.add(codigo);
    // eslint-disable-next-line no-new-func
    new Function(codigo)();
  };

  G.obtener = function (clave) {
    if (!registro()[clave] && codigos[clave]) G.cargarCodigo(codigos[clave]);
    return registro()[clave] || null;
  };

  // el proyecto que manda (editor al abrirlo, juego al arrancar)
  G.usarProyecto = function (proyecto) {
    codigos = (proyecto && proyecto.generadores) || {};
  };

  // añadir el código de un generador al proyecto (lo hace el editor al importar una receta)
  G.guardarEnProyecto = function (proyecto, clave, codigo) {
    proyecto.generadores = proyecto.generadores || {};
    proyecto.generadores[clave] = codigo;
    codigos = proyecto.generadores;
  };

  /* ---------- Comprimido en el juego exportado ----------
     El código de un generador es grande (el de terrenos ~1,5 MB legible): el juego lo lleva en gzip + base64
     (proyecto.generadoresGz) y lo descomprime al arrancar. Sin CompressionStream se queda como está */
  const aB64 = (u8) => { let s = ''; for (let i = 0; i < u8.length; i += 0x8000) s += String.fromCharCode.apply(null, u8.subarray(i, i + 0x8000)); return btoa(s); };
  const deB64 = (t) => { const s = atob(t), u8 = new Uint8Array(s.length); for (let i = 0; i < s.length; i++) u8[i] = s.charCodeAt(i); return u8; };
  async function pasar(datos, flujo) { return new Uint8Array(await new Response(new Blob([datos]).stream().pipeThrough(flujo)).arrayBuffer()); }

  // copia del proyecto para exportar: solo los generadores que usa alguna receta, comprimidos
  G.empaquetar = async function (proyecto, usados) {
    const gens = proyecto.generadores || {};
    const claves = Object.keys(gens).filter((k) => !usados || usados.has(k));
    const P = { ...proyecto };
    delete P.generadores;
    if (!claves.length) return P;
    if (typeof CompressionStream === 'undefined') { P.generadores = Object.fromEntries(claves.map((k) => [k, gens[k]])); return P; }
    P.generadoresGz = {};
    for (const k of claves) P.generadoresGz[k] = aB64(await pasar(new TextEncoder().encode(gens[k]), new CompressionStream('gzip')));
    return P;
  };

  // al arrancar el juego: descomprime lo que venga en generadoresGz (antes de generar las recetas)
  G.desempaquetar = async function (proyecto) {
    if (!proyecto || !proyecto.generadoresGz) return proyecto;
    proyecto.generadores = proyecto.generadores || {};
    for (const [k, t] of Object.entries(proyecto.generadoresGz)) {
      proyecto.generadores[k] = new TextDecoder().decode(await pasar(deB64(t), new DecompressionStream('gzip')));
    }
    delete proyecto.generadoresGz;
    return proyecto;
  };

  // receta → { escena, info } (o error con un mensaje para el creador)
  G.generar = function (receta, texto) {
    const clave = G.clave(receta);
    if (texto && cache.has(texto)) return cache.get(texto);
    const gen = G.obtener(clave);
    if (!gen) {
      const e = new Error(`falta el generador ${clave}`);
      e.faltaGenerador = clave;
      throw e;
    }
    const t0 = performance.now();
    const r = gen.generar(receta, T, {}) || {};
    if (!r.escena || !r.escena.isObject3D) throw new Error(`el generador ${clave} no devolvió una escena`);
    r.info = { ...(r.info || {}), ms: Math.round(performance.now() - t0) };
    // la receta entera queda en el nodo raíz: así "✎ Editar en la app" le devuelve la receta
    let raiz = null;
    r.escena.traverse((o) => { if (!raiz && o.userData && o.userData.forja) raiz = o; });
    if (!raiz) { raiz = r.escena; raiz.userData.forja = {}; }
    raiz.userData.forja = { app: receta.app, ...raiz.userData.forja, estado: receta, receta: true };
    if (texto) cache.set(texto, r);
    return r;
  };

  F.Generadores = G;
})(window.FORJA);
