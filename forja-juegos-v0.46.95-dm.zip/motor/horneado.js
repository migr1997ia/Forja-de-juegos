/* =========================================================
   FORJA · HORNEADO DE LUCES Y SOMBRAS (Render ▸ hornear)
   Al empezar a jugar, la luz del nivel se calcula UNA vez en cada vértice de lo que no se mueve (modelos sin animación,
   cubos, suelos, rampas, escaleras) y se guarda como color del vértice. Esas mallas pasan a dibujarse SIN luces
   (MeshBasicMaterial + colores): lo más barato que hay, y con sombras de las lámparas y del sol que antes no había.
   - Misma cuenta que el motor en vivo (Lambert de three r160): ambiente + hemisferio + sol + luces de punto con su caída.
   - Sombras: un rayo contra la colisión (BVH) desde el vértice a cada luz y al sol.
   - Lo que se mueve (jugador, enemigos, hojas de puerta) sigue con luces de verdad; las luces que una palanca o un
     disparador encienden / apagan, las que empiezan apagadas y las de parpadeo fuerte NO se hornean.
   - Mientras está horneado el sol no dibuja su mapa de sombras (el nivel ya las lleva puestas).
   - Caché en memoria: misma escena y mismas luces = no se vuelve a calcular (probar varias veces es instantáneo).
   🌦 Con clima en la escena se hornea POR PARTES (una sola pasada): cada vértice guarda cuánto sol le llega (con su
  sombra), hacia dónde mira (cielo / suelo), las lámparas fijas y las de noche. El color final lo arma la GPU con
  unos pocos números de la hora (motor/clima.js): día, tarde, noche y lluvia sin volver a hornear nada.
  La calidad depende de los vértices: paredes de pocas caras dan luz gruesa (PS1). El generador puede partirlas.
     const h = F.Horneado.aplicar(juego) → { ms, vertices, luces, rayos } · F.Horneado.quitar(juego, h)
   ========================================================= */
(function (F) {
  'use strict';
  const T = THREE;
  const QUIETOS = new Set(['modelo', 'cubo', 'suelo', 'rampa', 'escalera']);
  const cache = new Map();   // clave → Map(uuid de malla → Float32Array de colores)
  const _p = new T.Vector3(), _n = new T.Vector3(), _m3 = new T.Matrix3(), _c = new T.Color();

  // ¿esta luz puede cambiar en el juego? (la toca una acción, empieza apagada o parpadea mucho) → no se hornea
  function lucesQueCambian(escena) {
    const s = new Set();
    for (const e of escena.entidades) {
      const d = e.palanca || e.disparador || e.pedestal || e.condicion;
      for (const a of (d && d.acciones) || []) if (/^luz/.test(a.que) && a.a) s.add(a.a);
      if (e.tipo === 'luz' && e.luz && (e.luz.apagada || e.luz.parpadeo > 0.5)) s.add(e.id);
    }
    return s;
  }

  // atenuación de three (getDistanceAttenuation) con decay 1
  const caida = (d, alcance) => {
    let f = 1 / Math.max(d, 0.01);
    if (alcance > 0) { const x = Math.min(1, d / alcance); const q = Math.max(0, 1 - x * x * x * x); f *= q * q; }
    return f;
  };

  function aplicar(juego) {
    const t0 = performance.now();
    const V = juego.vista, L = V.luces, M = juego.mundo;
    if (!M) return null;
    const cambian = lucesQueCambian(juego.escena);
    // 🌦 por partes solo si la luz cambia al jugar; con clima a hora fija y seco: clásico a esa hora
    const conClima = !!(F.Clima && F.Clima.porPartes(juego.escena));
    const amb0 = juego.escena.ambiente || {};
    if (amb0.clima) F.Clima.vistaPrevia(V, amb0);   // la luz de la hora elegida (también en el juego exportado)
    const nocheFija = amb0.clima && !conClima ? F.Clima.esNoche(amb0) : true;
    // luces de punto que se hornean (las fuentes del sistema de luces: entidades 💡 y lámparas de los modelos)
    const luces = [];
    for (const f of (L && L.fuentes) || []) {
      if (!f.obj || !f.obj.parent || f.apagada) continue;
      const entId = f.obj.userData.entId;
      if (entId && cambian.has(entId)) continue;
      if (f.cfg && f.cfg.soloNoche && !nocheFija) continue;   // 🌙 hora fija de día: esa lámpara está apagada
      const c = f.cfg, pos = f.local.clone().applyMatrix4(f.obj.matrixWorld);
      const k = c.parpadeo > 0 ? 1 - c.parpadeo * 0.5 : 1;   // las que tiemblan, a su media
      const I = c.fuerza * Math.PI * (c.alcance * 0.5) * k;
      _c.set(c.color);
      luces.push({ pos, alcance: c.alcance, r: _c.r * I, g: _c.g * I, b: _c.b * I, f, noche: !!(conClima && c.soloNoche) });
      f.horneada = true;
    }
    // ambiente: hemisferio + sol + luces de ambiente que haya en la escena (lo que la vista tenga encendido)
    let hemi = null, sol = null;
    const amb = [0, 0, 0];
    V.escena.traverse((o) => {
      if (!o.visible) return;
      if (o.isHemisphereLight && (o.intensity > 0 || conClima)) hemi = o;
      else if (o.isDirectionalLight && (o.intensity > 0 || conClima) && !sol) sol = o;
      else if (o.isAmbientLight) { amb[0] += o.color.r * o.intensity; amb[1] += o.color.g * o.intensity; amb[2] += o.color.b * o.intensity; }
    });
    const dirSol = sol ? sol.position.clone().sub(sol.target.position).normalize() : null;
    const clave = (conClima ? 'clima|' : '') + juego.escena.id + '|' + luces.map((l) => l.pos.toArray().map((v) => v.toFixed(2)).join(',') + l.r.toFixed(2)).join(';') +
      '|' + (hemi ? hemi.color.getHexString() + hemi.groundColor.getHexString() + hemi.intensity : '') + '|' + (sol ? sol.color.getHexString() + sol.intensity + dirSol.toArray().map((v) => v.toFixed(2)) : '');
    let guardado = cache.get(clave);
    const nuevo = !guardado;
    if (nuevo) guardado = new Map();
    const hecho = { mallas: [], sombraSol: null, vertices: 0, rayos: 0, luces: luces.length, cache: !nuevo, clima: conClima };
    const hayNoche = luces.some((l) => l.noche);
    // las mallas
    V.escena.updateMatrixWorld(true);
    for (const ent of juego.escena.entidades) {
      if (!QUIETOS.has(ent.tipo) || ent.visible === false) continue;
      const obj = juego.objetos.get(ent.id);
      if (!obj) continue;
      if (ent.tipo === 'modelo' && (obj.userData.animaciones || []).length) continue;
      const mallas = [];
      const rec = (o) => { if (o.isMesh && !o.isSkinnedMesh && !o.userData.ayudaEditor && !o.userData.esAgua && o.visible) mallas.push(o); for (const h of o.children) if (!h.userData.entId) rec(h); };
      rec(obj);
      for (const malla of mallas) {
        const mats = Array.isArray(malla.material) ? malla.material : [malla.material];
        if (mats.some((m) => !m || m.transparent || m.isShaderMaterial || m.userData.compartido)) continue;   // cristal, agua, figuras del motor
        const geo0 = malla.geometry, pos = geo0.attributes.position, nor = geo0.attributes.normal;
        if (!pos || !nor) continue;
        let col = guardado.get(malla.uuid), partes = guardado.get(malla.uuid + '|c'), noche = guardado.get(malla.uuid + '|n');
        if (!col) {
          col = new Float32Array(pos.count * 3);
          if (conClima) { partes = new Float32Array(pos.count * 2); if (hayNoche) noche = new Float32Array(pos.count * 3); }
          const mw = malla.matrixWorld;
          _m3.getNormalMatrix(mw);
          // luces que llegan a esta malla (su caja contra el alcance)
          if (!geo0.boundingBox) geo0.computeBoundingBox();
          const caja = geo0.boundingBox.clone().applyMatrix4(mw);
          const cerca = luces.filter((l) => caja.distanceToPoint(l.pos) < l.alcance);
          for (let i = 0; i < pos.count; i++) {
            _p.fromBufferAttribute(pos, i).applyMatrix4(mw);
            _n.fromBufferAttribute(nor, i).applyMatrix3(_m3).normalize();
            let r = amb[0], g = amb[1], b = amb[2];
            if (conClima) partes[i * 2 + 1] = 0.5 * _n.y + 0.5;   // hacia dónde mira: 1 cielo · 0 suelo
            else if (hemi) {
              const w = 0.5 * _n.y + 0.5, I = hemi.intensity;
              r += (hemi.groundColor.r + (hemi.color.r - hemi.groundColor.r) * w) * I;
              g += (hemi.groundColor.g + (hemi.color.g - hemi.groundColor.g) * w) * I;
              b += (hemi.groundColor.b + (hemi.color.b - hemi.groundColor.b) * w) * I;
            }
            const ox = _p.x + _n.x * 0.04, oy = _p.y + _n.y * 0.04, oz = _p.z + _n.z * 0.04;
            if (sol) {
              const dn = _n.x * dirSol.x + _n.y * dirSol.y + _n.z * dirSol.z;
              if (dn > 0) {
                hecho.rayos++;
                if (!M.rayo(ox, oy, oz, dirSol.x, dirSol.y, dirSol.z, 80)) {
                  if (conClima) partes[i * 2] = dn;   // cuánto sol le llega (0 = a la sombra)
                  else { const I = sol.intensity * dn; r += sol.color.r * I; g += sol.color.g * I; b += sol.color.b * I; }
                }
              }
            }
            for (const l of cerca) {
              const dx = l.pos.x - _p.x, dy = l.pos.y - _p.y, dz = l.pos.z - _p.z, d = Math.hypot(dx, dy, dz);
              if (d >= l.alcance || d < 1e-4) continue;
              const dn = (_n.x * dx + _n.y * dy + _n.z * dz) / d;
              if (dn <= 0) continue;
              hecho.rayos++;
              // los últimos 80 cm no cuentan: la luz suele estar DENTRO de su lámpara, farol o candelabro
              if (!Horneado.sinSombras && d > 0.9 && M.rayo(ox, oy, oz, dx / d, dy / d, dz / d, d - 0.8)) { hecho.tapados = (hecho.tapados || 0) + 1; continue; }   // a la sombra
              const k = caida(d, l.alcance) * dn;
              if (l.noche) { noche[i * 3] += l.r * k / Math.PI; noche[i * 3 + 1] += l.g * k / Math.PI; noche[i * 3 + 2] += l.b * k / Math.PI; continue; }
              r += l.r * k; g += l.g * k; b += l.b * k;
            }
            col[i * 3] = r / Math.PI; col[i * 3 + 1] = g / Math.PI; col[i * 3 + 2] = b / Math.PI;
          }
          guardado.set(malla.uuid, col);
          if (partes) guardado.set(malla.uuid + '|c', partes);
          if (noche) guardado.set(malla.uuid + '|n', noche);
        }
        hecho.vertices += pos.count;
        // copia de la geometría con sus colores y material sin luces (el original se guarda para volver)
        const geo = geo0.clone();
        geo.setAttribute('color', new T.BufferAttribute(col, 3));
        if (partes) geo.setAttribute('aClima', new T.BufferAttribute(partes, 2));
        if (noche) geo.setAttribute('aLamN', new T.BufferAttribute(noche, 3));
        const nuevos = mats.map((m) => {
          const b = new T.MeshBasicMaterial({ color: m.color ? m.color.clone() : 0xffffff, map: m.map || null, vertexColors: true,
            alphaTest: m.alphaTest || 0, side: m.side, fog: true, name: m.name });
          b.userData.uEsHorneado = { value: 1 };   // la linterna sí lo alumbra (render.js)
          F.Render.hacerRetro(b);
          if (m.userData.uDesplazUV) b.userData.uDesplazUV.value.copy(m.userData.uDesplazUV.value);
          F.Render.copiarMovimiento(m, b);   // 🌊 olas, viento, ondear… siguen igual
          if (partes && F.Clima) F.Clima.prepararMaterial(b, !!noche, !!juego.escena.ambiente.climaCharcos && juego.escena.ambiente.climaLluvia !== 'no');
          return b;
        });
        hecho.mallas.push({ malla, geo0, mat0: malla.material });
        malla.geometry = geo;
        malla.material = Array.isArray(malla.material) ? nuevos : nuevos[0];
      }
    }
    if (nuevo) { if (cache.size > 6) cache.delete(cache.keys().next().value); cache.set(clave, guardado); }
    // el nivel ya lleva sus sombras: el sol deja de dibujar su mapa (una pasada menos cada cuadro)
    if (sol && sol.castShadow && hecho.mallas.length) { hecho.sombraSol = sol; sol.castShadow = false; }
    hecho.ms = Math.round(performance.now() - t0);
    F.emitir('horneado', hecho);
    return hecho;
  }

  function quitar(juego, h) {
    if (!h) return;
    for (const x of h.mallas) {
      const mats = Array.isArray(x.malla.material) ? x.malla.material : [x.malla.material];
      mats.forEach((m) => m.dispose());
      x.malla.geometry.dispose();
      x.malla.geometry = x.geo0;
      x.malla.material = x.mat0;
    }
    if (h.sombraSol) h.sombraSol.castShadow = true;
    const L = juego.vista.luces;
    for (const f of (L && L.fuentes) || []) f.horneada = false;
  }

  const Horneado = F.Horneado = { aplicar, quitar, sinSombras: false };
})(window.FORJA);
