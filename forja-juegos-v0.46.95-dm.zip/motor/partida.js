/* =========================================================
   FORJA · PARTIDA
   El "director" del juego completo: portada → menú principal → jugar → pausa → menú…
   Carga escenas, guarda y carga partidas (3 ranuras) y aplica las opciones del jugador.
   Los viajes entre niveles (🚪 salidas) los hace FORJA.Niveles (this.niveles); aquí solo se cambia de Juego.
   La usan index.html (juego exportado) y el editor ("Probar con menús").
     const p = new FORJA.Partida({ vista, proyecto, contenedor, enEditor, alSalir });
     p.arrancar('portada' | 'principal' | 'pausa' | 'opciones');
     cada cuadro:  if (p.listo(ahora)) p.actualizar(dt);
     al terminar:  p.destruir();
   ========================================================= */
(function (F) {
  'use strict';
  const T = THREE;
  const S = () => F.Escena;

  class Partida {
    constructor({ vista, proyecto, contenedor, enEditor = false, alSalir = null }) {
      this.vista = vista;
      this.proyecto = proyecto;
      this.enEditor = enEditor;
      this.alSalir = alSalir;
      this.opciones = new F.Opciones(proyecto);
      this.opciones.aplicar();
      this.grupo = new T.Group();            // aquí van los objetos de la escena cargada
      this.grupo.name = 'partida';
      vista.escena.add(this.grupo);
      this.objetos = new Map();
      this.escena = null;
      this.juego = null;
      this.estado = 'menu';                  // 'menu' | 'jugando' | 'pausa' | 'muerte' | 'viajando'
      this.niveles = new F.Niveles();        // memoria de cada nivel y cómo entraste al actual
      this.origen = 'teclado';               // con qué se empezó a jugar (con mando no se bloquea el cursor)
      this.tiempo = 0;                       // segundos jugados (se guarda en la ranura)
      this.camMenu = new T.PerspectiveCamera(60, 1, 0.05, 1500);
      vista.usarCamara(this.camMenu);
      this.orbita = { centro: new T.Vector3(), radio: 10, angulo: 0 };
      this.limite = new F.LimiteFps();
      if (vista.luces) vista.luces.enJuego = true;   // sin marcas del editor en el fondo del menú
      this.menu = new F.MenuJuego({
        contenedor, proyecto, opciones: this.opciones, enEditor,
        alAccion: (a, b, origen) => this.accion(a, b, origen),
      });
      this.oyentes = [
        F.on('jugador-muerto', (juego) => { if (juego === this.juego) this.gameOver(); }),
        F.on('juego-pausa', () => this.pausar()),
        F.on('cursor-liberado', () => { if (this.estado === 'viajando') this.pausarAlLlegar = true; else this.pausar(); }),
        F.on('salida', ({ juego, ent }) => { if (juego === this.juego) this.viajar(ent); }),
        // 🏁 la misión terminó y no lleva a otro nivel: fin de la partida → portada
        // 💣🧍 misión perdida (bomba, rehén muerto): como morir
        F.on('mision-fallida', ({ juego }) => { if (juego === this.juego) this.gameOver(); }),
        F.on('punto-guardado', (d) => { if (d.juego === this.juego) this.puntoGuardado(d); }),
        F.on('vida-extra', (d) => { if (d.juego === this.juego) this.sumarVida(d.n || 1); }),
        F.on('monedas', (j) => { if (this.juego && j === this.juego.jugador) this._vidaPorDivisa(j); }),
        F.on('partida-fin', (juego) => { if (juego === this.juego) this.victoria(); }),
        // 🗺 misión acabada en un juego por misiones: de vuelta al menú de misiones
        F.on('partida-misiones', (juego) => { if (juego === this.juego) { this.arrancar('principal'); this.menu.abrir('misiones'); } }),
      ];
    }

    /* ---------- Escenas ---------- */
    buscarEscena(id) {
      const ps = this.proyecto.escenas;
      return ps.find((s) => s.id === id) || ps.find((s) => s.id === this.proyecto.escenaInicial) || ps[0];
    }

    limpiarEscena() {
      for (const o of [...this.grupo.children]) { this.grupo.remove(o); S().liberarObjeto(o); }
      this.objetos = new Map();
      this.escena = null;
    }

    cargarEscena(id) {
      this.limpiarEscena();
      this.escena = this.buscarEscena(id);
      this.objetos = S().construirEscena(this.escena, this.grupo, this.proyecto);
      return this.escena;
    }

    // Lo que el jugador eligió en Opciones, encima de los ajustes del proyecto
    aplicarImagen() {
      const aj = this.opciones.ajustes();
      if (this.juego) this.juego.ajustes = aj;
      const amb = this.escena ? this.escena.ambiente : F.valoresPorDefecto(S().ESQUEMA_AMBIENTE);
      this.vista.aplicar(aj, amb, true, true);
    }

    /* Fondo del menú principal: la escena en vivo con la cámara girando, o nada (color / imagen los pone el menú) */
    prepararFondo() {
      const mp = this.proyecto.menus.principal;
      if (mp.fondo !== 'escena') { this.limpiarEscena(); this.aplicarImagen(); return; }
      const esc = this.cargarEscena(mp.escena || this.proyecto.escenaInicial);
      for (const ent of esc.entidades) {
        const obj = this.objetos.get(ent.id);
        if (!obj) continue;
        obj.visible = ent.tipo !== 'inicio' && ent.visible;
        obj.traverse((o) => { if (o.userData.ayudaEditor) o.visible = false; });
      }
      if (this.vista.luces) this.vista.luces.registrar(esc.entidades, this.objetos);
      const caja = new T.Box3().setFromObject(this.grupo);
      if (caja.isEmpty()) caja.set(new T.Vector3(-5, 0, -5), new T.Vector3(5, 2, 5));
      caja.getCenter(this.orbita.centro);
      this.orbita.radio = Math.max(4, caja.getSize(new T.Vector3()).length() * 0.45);
      this.orbita.alto = this.orbita.centro.y + this.orbita.radio * 0.35;
      this.camMenu.far = F.Render.Vista.distanciaDibujo(esc.ambiente) + this.orbita.radio;
      this.camMenu.updateProjectionMatrix();
      this.aplicarImagen();
    }

    /* ---------- Flujo ---------- */
    arrancar(pantalla = 'principal') {
      this.detenerJuego();
      this.estado = 'menu';
      F.Entrada.activo = false;
      F.Entrada.soltarBloqueo();
      const mp = this.proyecto.menus.principal;
      if (pantalla === 'gameover') {
        this.empezar(this.proyecto.escenaInicial, null, 'mando');
        this.gameOver();
        return;
      }
      if (pantalla === 'victoria') {
        this.empezar(this.proyecto.escenaInicial, null, 'mando');
        this.tiempo = 4 * 3600 + 23 * 60 + 7;   // prueba: un tiempo de ejemplo
        this.victoria();
        return;
      }
      if (pantalla === 'pausa') {
        this.empezar(this.proyecto.escenaInicial, null, 'mando');
        this.pausar();
        return;
      }
      if (!mp.activo && pantalla !== 'opciones') {
        // sin menú principal: la portada (si la hay) lleva directo al juego
        if (pantalla === 'portada') { this.prepararFondo(); this.menu.mostrar('portada'); return; }
        this.nuevaPartida(this.proyecto.escenaInicial, 'teclado');
        return;
      }
      this.prepararFondo();
      F.Audio.musica(mp.musica);
      this.menu.mostrar(pantalla === 'portada' ? 'portada' : 'principal');
      if (pantalla === 'opciones') this.menu.abrir('opciones');
    }

    // Partida desde cero (Nueva partida, botón "ir a escena", sin menú principal): los niveles se olvidan
    nuevaPartida(idEscena, origen = 'teclado') {
      const esc = this.buscarEscena(idEscena);
      if (F.Cine) F.Cine.reiniciarPartida();   // 🎬 partida nueva: las de "una vez" se vuelven a ver
      const V = this._cfgVidas();
      this.vidas = V.activo ? V.inicio : 0;
      this.sigUmbral = V.extraCada;
      this.niveles.olvidar();
      const inicio = { llegada: '' };
      this.niveles.marcarEntrada(esc.id, inicio);
      this.empezar(esc.id, inicio, origen);
    }

    // origen: 'raton' | 'teclado' | 'mando' (con mando el navegador no deja bloquear el cursor)
    // guardado: partida cargada ({escena, pos, yaw, jugador, rotos…}) o inicio de nivel ({llegada, jugador, rotos…})
    empezar(idEscena, guardado = null, origen = 'teclado') {
      this.detenerJuego();
      this.checkpoint = null;
      this._entrar(idEscena, guardado);
      this.tiempo = (guardado && guardado.tiempo) || 0;
      this.origen = origen;
      this.menu.ocultar();
      if (origen !== 'mando') F.Entrada.pedirBloqueo();
      F.emitir('partida-jugando', this);
      this.niveles.aparecer(this.juego, 0.35);
    }

    // Crea el Juego de una escena (lo usan empezar y los viajes entre niveles)
    _entrar(idEscena, inicio) {
      const esc = this.cargarEscena(idEscena);
      this.juego = new F.Juego(this.vista, this.proyecto, esc, this.objetos, { ajustes: this.opciones.ajustes() });
      this.juego.conPartida = true;   // al morir, Game Over (no reaparecer solo)
      this.juego.iniciar(inicio);
      this.estado = 'jugando';
      this.pintarVidas();
      // 💾 entrar a un nivel cuenta como checkpoint (si así se eligió)
      if ((this.proyecto.menus.guardado || {}).alEntrarNivel !== false) { try { this.checkpoint = this.instantanea(); } catch (e) { /* sin estado aún */ } }
      F.Audio.musicaNivel(esc.nivel);   // la misma pista sigue sin cortarse (solo cambia su volumen / bucle)
      return this.juego;
    }

    // 🚪 Una salida se activó: fundido, guardar cómo queda este nivel, cargar el otro (motor/niveles.js)
    viajar(ent) {
      if (this.estado !== 'jugando' || !this.juego) return;
      this.estado = 'viajando';
      this.pausarAlLlegar = false;
      const desde = this.juego;
      this.niveles.viajar({
        juego: desde,
        ent,
        cambiar: (idEscena, inicio) => {
          // si mientras tanto volvieron al menú (o se cerró la prueba), no se carga nada
          if (this.estado !== 'viajando' || this.juego !== desde) return null;
          desde.detener({ seguir: true });
          this.juego = null;
          return this._entrar(idEscena, inicio);
        },
      }).then((ok) => {
        if (this.estado === 'viajando') this.estado = 'jugando';   // no se pudo (salida sin destino) o misma escena
        if (ok && this.pausarAlLlegar && this.estado === 'jugando') this.pausar();
        this.pausarAlLlegar = false;
      });
    }

    detenerJuego() {
      if (this.juego) this.juego.detener();
      this.juego = null;
      if (this.estado === 'viajando') this.estado = 'menu';
    }

    pausar() {
      if (this.estado !== 'jugando') return;
      this.estado = 'pausa';
      F.Entrada.activo = false;
      F.Entrada.soltarBloqueo();
      this.menu.mostrar('pausa', { sobreJuego: true });
      F.emitir('partida-pausa', this);
    }

    /* ---------- ❤ Vidas (arcade) ---------- */
    _cfgVidas() { return { ...F.Escena.menusPorDefecto().vidas, ...((this.proyecto.menus || {}).vidas || {}) }; }
    pintarVidas() {
      const V = this._cfgVidas();
      if (!this.juego || !V.activo) return;
      const el = F.Hud.pieza(this.juego, 'fh-vidas');
      const img = V.imagen && F.Assets && F.Assets.mapa.get(V.imagen);
      el.innerHTML = (img && img.url ? `<img src="${img.url}" style="height:1em;vertical-align:-.15em;image-rendering:pixelated">` : (V.icono || '❤'));
      el.innerHTML = `<span class="fh-ico">${el.innerHTML}</span><span class="fh-num">× ${Math.max(0, this.vidas)}</span>`;
    }
    sumarVida(n = 1) {
      const V = this._cfgVidas();
      if (!V.activo) return;
      this.vidas = Math.min(V.max || 99, (this.vidas || 0) + n);
      this.pintarVidas();
      F.Audio.sintetico('recoger', { volumen: 0.9, tono: 1.8 });
      F.emitir('vidas', this);
    }
    // cada X de una divisa = 1 vida (Mario: 100 monedas). Con "gastar" se descuentan; si no, cuenta por umbrales
    _vidaPorDivisa(j) {
      const V = this._cfgVidas();
      if (!V.activo || !(V.extraCada > 0)) return;
      const D = F.Divisas, id = D.de(this.proyecto, V.divisa).id, n = D.tiene(j, id);
      if (V.gastar) { if (n >= V.extraCada) { D.sumar(j, id, -V.extraCada, this.proyecto); this.sumarVida(1); } }
      else { if (!this.sigUmbral) this.sigUmbral = V.extraCada; while (n >= this.sigUmbral) { this.sigUmbral += V.extraCada; this.sumarVida(1); } }
    }

    gameOver() {
      if (this.estado !== 'jugando') return;
      this.estado = 'muerte';
      F.Entrada.activo = false;
      F.Entrada.soltarBloqueo();
      F.Tactil && F.Tactil.ocultar();
      // ❤ con vidas: se gasta una y reapareces (checkpoint o principio del nivel); sin vidas, Game Over
      const V = this._cfgVidas();
      if (V.activo) {
        this.vidas = (this.vidas || 0) - 1;
        this.pintarVidas();
        if (this.vidas > 0) {
          const juego = this.juego;
          setTimeout(() => { if (this.estado === 'muerte' && this.juego === juego) this.accion(this.checkpoint ? 'checkpoint' : 'reiniciar', null, this.origen); }, 1500);
          return;
        }
        this.vidasAgotadas = true;
      }
      // 💾 "reaparecer solo": vuelve al último checkpoint sin pantalla de Game Over
      const cfg = this.proyecto.menus.guardado || {};
      if (cfg.alMorir === 'reaparecer') {
        const juego = this.juego;
        setTimeout(() => { if (this.estado === 'muerte' && this.juego === juego) this.accion(this.checkpoint ? 'checkpoint' : 'reiniciar', null, this.origen); }, 1500);
        return;
      }
      this.menu.mostrar('gameover', { sobreJuego: true, checkpoint: !!this.checkpoint });
    }

    // lo que se guarda en una ranura o en un checkpoint
    instantanea(extra = {}) {
      return { ...this.juego.estado(), vidas: this.vidas, sigUmbral: this.sigUmbral, tiempo: this.tiempo, nombreEscena: this.escena.nombre, niveles: this.niveles.serializar(), ...extra };
    }

    // 💾 un punto de guardado del mapa se activó (motor/guardado.js)
    puntoGuardado({ p, gastar }) {
      if (this.estado !== 'jugando' || !this.juego) return;
      if (p.hace === 'menu') {
        this.puntoGastar = gastar;
        this.estado = 'pausa';
        F.Entrada.activo = false;
        F.Entrada.soltarBloqueo();
        this.menu.mostrar('ranuras', { modo: 'guardar', sobreJuego: true, desdePunto: true });
        return;
      }
      this.checkpoint = this.instantanea({ llenarVida: !!p.llenarVida });
      if (p.hace === 'auto' && (this.proyecto.menus.guardado || {}).ranuraAuto !== false) F.Partidas.guardar(this.proyecto, F.Partidas.AUTO, this.checkpoint);
    }

    // 🏆 juego completado: pantalla de victoria encima del juego (tiempo total, rango, estrellas de las misiones)
    victoria() {
      if (this.estado !== 'jugando' && this.estado !== 'viajando') return;
      this.estado = 'victoria';
      F.Entrada.activo = false;
      F.Entrada.soltarBloqueo();
      F.Tactil && F.Tactil.ocultar();
      let n = 0, max = 0;
      try {
        const d = JSON.parse(localStorage.getItem('forja-estrellas-' + (this.proyecto.id || this.proyecto.nombre)) || '{}');
        for (const esc of this.proyecto.escenas) if (esc.mision && esc.mision.activa) { max += 3; n += d[esc.id] || 0; }
      } catch (err) { /* sin almacenamiento */ }
      this.menu.mostrar('victoria', { tiempo: this.tiempo, estrellas: { n, max }, sobreJuego: true });
      F.emitir('partida-victoria', this);
    }

    reanudar(origen) {
      if (this.estado !== 'pausa' || !this.juego) return;
      this.menu.ocultar();
      this.estado = 'jugando';
      F.Entrada.limpiar();
      F.Entrada.activo = true;
      if (origen !== 'mando') F.Entrada.pedirBloqueo();
      F.emitir('partida-jugando', this);
    }

    accion(a, b, origen) {
      const P = F.Partidas;
      switch (a) {
        case 'portada':
          if (this.proyecto.menus.principal.activo) { this.menu.mostrar('principal'); F.Audio.musica(this.proyecto.menus.principal.musica); }
          else this.nuevaPartida(this.proyecto.escenaInicial, origen);
          break;
        case 'nueva': this.nuevaPartida(this.proyecto.escenaInicial, origen); break;
        case 'escena': this.nuevaPartida(b && b.escena, origen); break;
        case 'continuar': {
          const i = P.ultima(this.proyecto);
          if (i >= 0) this.accion('cargar-ranura', { ranura: i }, origen);
          break;
        }
        case 'cargar-ranura': {
          const datos = P.leer(this.proyecto, b.ranura);
          if (!datos) break;
          if (!this.proyecto.escenas.some((s) => s.id === datos.escena)) { this.menu.aviso('Esa escena ya no existe'); break; }
          this.niveles.cargar(datos);   // memoria de los demás niveles y la entrada al actual
          this.vidasAgotadas = false;
          this.vidas = typeof datos.vidas === 'number' && datos.vidas > 0 ? datos.vidas : this._cfgVidas().inicio;
          this.sigUmbral = datos.sigUmbral || this._cfgVidas().extraCada;
          this.empezar(datos.escena, datos, origen);
          break;
        }
        case 'guardar-ranura': {
          if (!this.juego) break;
          const desdePunto = this.menu.pila[0] && this.menu.pila[0].datos && this.menu.pila[0].datos.desdePunto;
          if (desdePunto && this.puntoGastar) { this.puntoGastar(); this.puntoGastar = null; }   // la cinta de tinta se gasta al guardar
          const ok = P.guardar(this.proyecto, b.ranura, this.instantanea());
          if (desdePunto) { this.checkpoint = this.instantanea(); this.reanudar(origen); F.emitir('partida-guardada', this); break; }
          this.menu.atras();
          this.menu.aviso(ok ? `Guardado en la ranura ${b.ranura + 1}` : 'No se pudo guardar (el navegador no deja)');
          break;
        }
        case 'reanudar': this.reanudar(origen); break;
        case 'checkpoint': {
          if (this.vidasAgotadas) { this.vidasAgotadas = false; this.vidas = this._cfgVidas().inicio; }
          // 💾 reaparecer como estaba todo al tocar el punto de control
          const d = this.checkpoint;
          if (!d) { this.accion('reiniciar', null, origen); break; }
          this.niveles.cargar(d);
          this.empezar(d.escena, d, origen);
          if (d.llenarVida && this.juego && this.juego.jugador.vidaMax) this.juego.jugador.vida = this.juego.jugador.vidaMax;
          this.checkpoint = d;
          break;
        }
        case 'reiniciar': {
          if (this.vidasAgotadas) { this.vidasAgotadas = false; this.vidas = this._cfgVidas().inicio; }
          // vuelve a como entraste a este nivel (con lo que traías), no al principio del juego
          const r = this.niveles.reinicio(this.escena.id);
          this.empezar(r.escena, r.inicio, origen);
          break;
        }
        case 'tactil-acomodar':
          this.menu.esconderUnMomento();
          F.Tactil.acomodar(this.vista.contenedor, {
            alGuardar: (pos) => this.opciones.poner('tactilPos', { ...pos }),
            alTerminar: () => { this.opciones.aplicar(); this.menu.volverAMostrar(); },
          });
          break;
        case 'menu_principal': this.arrancar('principal'); break;
        case 'opciones-cambiaron': this.aplicarImagen(); break;
        case 'salir':
          if (this.alSalir) { this.alSalir(); break; }
          // Escritorio (futuro) o ventana abierta por script: se cierra. En navegador normal no se puede: a la portada.
          try { window.close(); } catch (err) { /* el navegador no deja */ }
          setTimeout(() => { if (!window.closed) this.arrancar('portada'); }, 100);
          break;
      }
    }

    /* ---------- Cada cuadro ---------- */
    listo(ahora) {
      return this.limite.listo(ahora, this.opciones.valores.limiteFps);
    }

    actualizar(dt) {
      this.menu.actualizar(dt);
      if (this.estado === 'jugando' && this.juego) {
        this.juego.actualizar(dt);
        this.tiempo += dt;
      } else if ((this.estado === 'pausa' || this.estado === 'muerte' || this.estado === 'viajando' || this.estado === 'victoria') && this.juego) {
        this.vista.render(this.juego.camara);
      } else {
        const o = this.orbita;
        o.angulo += dt * (this.proyecto.menus.principal.velGiro || 0);
        this.camMenu.position.set(o.centro.x + Math.cos(o.angulo) * o.radio, o.alto || o.centro.y + 3, o.centro.z + Math.sin(o.angulo) * o.radio);
        this.camMenu.lookAt(o.centro);
        this.vista.render(this.camMenu);
      }
    }

    destruir() {
      this.detenerJuego();
      this.limpiarEscena();
      this.vista.escena.remove(this.grupo);
      this.menu.destruir();
      this.niveles.quitarCapa();
      for (const quitar of this.oyentes) quitar();
      F.Audio.pararMusica();
      F.Entrada.activo = false;
      F.Entrada.usarMapa(null);
      if (this.vista.luces) this.vista.luces.enJuego = false;
    }
  }

  F.Partida = Partida;
})(window.FORJA);
