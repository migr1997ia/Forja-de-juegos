/* =========================================================
   FORJA · ESCENA
   Proyecto → escenas → entidades (con jerarquía padre-hijo).
   Ajustes de render (de todo el proyecto) y ambiente (de cada escena).
   ========================================================= */
(function (F) {
  'use strict';
  const T = THREE;
  const DEG = F.DEG;

  /* ---------- Render: igual para todo el proyecto ---------- */
  const ESQUEMA_RENDER = [
    { grupo: 'Render retro' },
    { k: 'resolucion', t: 'sel', e: 'Resolución', def: 240, op: [[240, '240p (PS1)'], [288, '288p'], [360, '360p'], [480, '480p (N64 alta)'], [0, 'Nativa']] },
    { k: 'snap', t: 'rango', e: 'Temblor vértices', def: 0.5, min: 0, max: 1, paso: 0.05, ayuda: 'El "bailoteo" de la PS1' },
    { k: 'afin', t: 'rango', e: 'Textura afín', def: 0.25, min: 0, max: 1, paso: 0.05, ayuda: 'Deformación de texturas sin perspectiva (PS1)' },
    { k: 'dither', t: 'bool', e: 'Dither 15 bits', def: true },
    { k: 'filtroN64', t: 'bool', e: 'Filtro N64', def: false, ayuda: 'Texturas suavizadas como la N64' },
    { k: 'limiteFps', t: 'sel', e: 'Límite de FPS', def: 0,
      op: [[0, 'Sin límite (los de la pantalla)'], [30, '30 (PS1 / N64)'], [60, '60'], [120, '120'], [144, '144']],
      ayuda: 'Cuadros por segundo máximos del juego. "Sin límite" = lo que dé tu monitor (60, 120, 144…). 30 se siente como consola de la época y gasta menos batería' },
    // 📼 efectos de cámara de todo el juego (motor/efectos.js); cada nivel puede tener los suyos
    ...F.Efectos.ESQUEMA.map((d) => ({ ...d })),
    { grupo: 'Luces y sombras' },
    { k: 'lucesExtra', t: 'bool', e: 'Luces y sombras', def: false,
      ayuda: 'Apagado = como siempre (ambiente + sol sin sombras, lo más rápido). Encendido = sombras del sol y luces de lámparas, antorchas y entidades 💡' },
    { k: 'sombrasSol', t: 'sel', e: 'Sombras del sol', def: 1024,
      op: [[0, 'Sin sombras'], [512, 'Baja · pixeladas (retro)'], [1024, 'Media'], [2048, 'Alta · suaves']],
      ayuda: 'Un solo mapa de sombras que sigue a la cámara. Baja es la más rápida y la más de la época' },
    { k: 'distanciaSombras', t: 'num', e: 'Alcance sombras (m)', def: 35, paso: 5, min: 5,
      ayuda: 'Hasta dónde se ven sombras alrededor de la cámara. Menos = sombras más nítidas' },
    { k: 'halos', t: 'rango', e: 'Auras de luz', def: 1, min: 0, max: 2, paso: 0.1,
      ayuda: 'El resplandor alrededor de lámparas y antorchas, como en los juegos de la época. 0 = sin auras · 1 = normal · 2 = exagerado' },
    { k: 'hornear', t: 'bool', e: 'Hornear luces y sombras', def: false,
      ayuda: 'Al empezar a jugar calcula una vez la luz y las sombras de lámparas, antorchas y sol en el nivel y lo dibuja sin luces: lo más rápido, y con sombras de las antorchas. Lo que se mueve sigue con luz real. Las luces que encienden palancas no se hornean' },
    { k: 'manchasEnemigos', t: 'bool', e: 'Sombra de mancha bajo enemigos', def: true,
      ayuda: 'Un círculo oscuro bajo cada enemigo (como el jugador con el módulo Sombra). Casi gratis: todas juntas son un solo dibujo. Con el nivel horneado o sin sombras del sol, es lo que los asienta en el suelo' },
    { k: 'aurasSinLuces', t: 'bool', e: 'Auras aunque no haya luces', def: false,
      ayuda: 'Con "Luces y sombras" apagado, las lámparas y antorchas siguen teniendo su aura (el resplandor), sin el coste de las luces' },
    { k: 'luzVertice', t: 'bool', e: 'Luz por vértice (PS1, rápido)', def: true,
      ayuda: 'Lámparas y antorchas se calculan en cada vértice, como en la PS1: mucho más rápido (sobre todo con muchas luces y en resolución alta). Desmarcado = por píxel, más suave pero cuesta GPU. El sol y la linterna van siempre por píxel' },
    { k: 'maxLuces', t: 'sel', e: 'Luces a la vez', def: 8, op: [[4, '4 (lo más rápido)'], [8, '8'], [12, '12'], [16, '16']],
      ayuda: 'Cuántas lámparas / antorchas alumbran al mismo tiempo (las más cercanas a la cámara). Puede haber muchas más en el nivel' },
    { grupo: 'Optimización' },
    { k: 'juntarQuietos', t: 'bool', e: 'Juntar lo que no se mueve', def: true,
      ayuda: 'Al jugar, los marcos de puerta y piezas quietas con el mismo material se dibujan de una vez (menos llamadas de dibujo). En el editor no cambia nada' },
    { k: 'ocultarTapado', t: 'bool', e: 'No dibujar lo tapado', def: true,
      ayuda: 'Objetos, puertas, palancas y enemigos que quedan detrás de paredes no se dibujan (y los enemigos tranquilos piensan menos)' },
    { k: 'distObjetos', t: 'num', e: 'Objetos hasta (m)', def: 0, paso: 5, min: 0,
      ayuda: 'Más lejos no se dibujan recogibles, palancas, cofres, puertas… 0 = hasta la distancia de dibujo' },
    { k: 'distEnemigos', t: 'num', e: 'Enemigos duermen a (m)', def: 50, paso: 5, min: 10,
      ayuda: 'Más lejos, un enemigo tranquilo no piensa ni se anima (los que te persiguen siguen). A la mitad piensa y se anima menos' },
    { grupo: 'Controles táctiles' },
    { k: 'controlesTactiles', t: 'sel', e: 'Controles táctiles', def: 'auto',
      op: [['auto', 'Automático (al tocar la pantalla)'], ['siempre', 'Siempre'], ['nunca', 'Nunca']],
      ayuda: 'Stick a la izquierda, mirar arrastrando a la derecha y botones. Automático: aparecen en tablets y celulares, o al tocar la pantalla' },
    // qué botones táctiles tiene el juego (además, cada uno solo sale si su módulo está activo)
    ...F.Tactil.BOTONES.map((b) => ({ k: 'tb_' + b.accion, t: 'bool', e: 'Botón ' + b.etiqueta, def: true,
      ayuda: b.modulo ? `Solo aparece si el módulo del jugador "${b.modulo}" está activo` + (b.contextual ? '. Sale solo cuando sirve' : '') : '' })),
    { grupo: 'Vista del editor' },
    { k: 'vistaRetroEditor', t: 'bool', e: 'Retro en editor', def: false, ayuda: 'Ver la resolución y efectos del juego mientras editas' },
    { k: 'nieblaEditor', t: 'bool', e: 'Niebla en editor', def: false },
    { k: 'fxEnEditor', t: 'bool', e: 'Efectos de cámara en editor', def: true, ayuda: 'Ver VHS / CRT en la vista 3D mientras editas (las vistas superior, frontal y lateral nunca los llevan)' },
  ];

  /* ---------- Ambiente: propio de cada escena (≈ WorldEnvironment) ----------
     La niebla imita la de tu camera_3dretro.gd: lineal por profundidad, el cielo no se nubla,
     y la distancia de dibujado se puede cortar justo donde termina la niebla. */
  const ESQUEMA_AMBIENTE = [
    { grupo: 'Cielo' },
    { k: 'fondo', t: 'color', e: 'Color del cielo', def: '#1e2533', ayuda: 'Arriba. Con textura funciona como tinte (blanco = colores reales)' },
    { k: 'cieloHorizonte', t: 'color', e: 'Color horizonte', def: '#3a4357', ayuda: 'Abajo y en el horizonte' },
    { k: 'cieloAlturaHorizonte', t: 'rango', e: 'Altura horizonte', def: 0.25, min: 0.05, max: 1, paso: 0.05, ayuda: 'Cuánto sube el degradado' },
    { k: 'cieloTextura', t: 'asset', e: 'Textura', def: '', tipoAsset: 'textura', vacio: '(sin textura)' },
    { k: 'cieloModo', t: 'sel', e: 'Proyección', def: 'esfera', op: [['esfera', 'Esférica (panorama)'], ['plano', 'Plana (techo de nubes)']] },
    { k: 'cieloEscalaX', t: 'rango', e: 'Escala X', def: 1, min: 0.1, max: 5, paso: 0.05 },
    { k: 'cieloEscalaY', t: 'rango', e: 'Escala Y', def: 1, min: 0.1, max: 5, paso: 0.05 },
    { k: 'cieloVelX', t: 'num', e: 'Movimiento X', def: 0, paso: 0.005, ayuda: 'Desplazamiento por segundo (nubes que avanzan)' },
    { k: 'cieloVelY', t: 'num', e: 'Movimiento Y', def: 0, paso: 0.005 },
    { grupo: 'Niebla PS1' },
    { k: 'niebla', t: 'bool', e: 'Niebla', def: true },
    { k: 'nieblaDelCielo', t: 'bool', e: 'Color = horizonte', def: true, ayuda: 'La niebla usa el color del horizonte (como auto_sync_color)' },
    { k: 'nieblaColor', t: 'color', e: 'Color niebla', def: '#2a3140' },
    { k: 'nieblaCerca', t: 'num', e: 'Empieza (m)', def: 12, paso: 1 },
    { k: 'nieblaLejos', t: 'num', e: 'Termina (m)', def: 45, paso: 1 },
    { k: 'nieblaVertice', t: 'bool', e: 'Por vértice (PS1)', def: false, ayuda: 'Calculada en cada vértice como la PS1: se nota en polígonos grandes' },
    { k: 'nieblaPasos', t: 'num', e: 'Bandas', def: 0, paso: 1, min: 0, ayuda: '0 = suave · 4-8 = escalones visibles, muy retro' },
    { grupo: 'Distancia de dibujado' },
    { k: 'recortarEnNiebla', t: 'bool', e: 'Cortar tras niebla', def: true, ayuda: 'No dibuja lo que queda oculto por la niebla (más rendimiento, como render_distance)' },
    { k: 'distanciaDibujo', t: 'num', e: 'Distancia (m)', def: 300, paso: 10, ayuda: 'Se usa cuando no hay niebla o no se corta en ella' },
    { grupo: 'Luz' },
    { k: 'luzAmb', t: 'rango', e: 'Luz ambiente', def: 0.55, min: 0, max: 2, paso: 0.05 },
    { k: 'luzSol', t: 'rango', e: 'Luz sol', def: 0.8, min: 0, max: 3, paso: 0.05 },
    { k: 'solAltura', t: 'rango', e: 'Altura sol', def: 55, min: 5, max: 90, paso: 1 },
    { k: 'solGiro', t: 'rango', e: 'Giro sol', def: 35, min: 0, max: 360, paso: 1 },
    { k: 'solColor', t: 'color', e: 'Color sol', def: '#fff2dd', ayuda: 'Naranja = atardecer · azul = noche de luna' },
    { k: 'solSombra', t: 'bool', e: 'El sol hace sombras', def: true, ayuda: 'Solo con "Luces y sombras" activado en Proyecto. Apágalo en interiores o de noche' },
    // 🌦 clima (motor/clima.js): apagado = no existe en la escena (no cuesta nada)
    { grupo: '🌦 Clima (día, noche, lluvia)' },
    { k: 'clima', t: 'bool', e: 'Activar clima', def: false, ayuda: 'Apagado no existe en la escena (cero coste). Encendido, el "día" usa los colores de cielo y sol de arriba. Con Hornear: a hora fija y sin lluvia se hornea como siempre (lo más barato); si la luz cambia al jugar (tiempo que avanza, lluvia, acciones de clima) se hornea por partes' },
    { k: 'climaHora', t: 'rango', e: 'Hora', def: 12, min: 0, max: 24, paso: 0.25, si: (v) => v.clima, ayuda: '6-8 amanecer · 8-17 día · 17-20 atardecer · 20-5 noche. El editor la muestra tal cual' },
    { k: 'climaCiclo', t: 'bool', e: 'El tiempo avanza', def: false, si: (v) => v.clima, ayuda: 'Apagado: siempre a esa hora' },
    { k: 'climaMinutos', t: 'num', e: 'Minutos por día', def: 12, paso: 1, min: 1, si: (v) => v.clima && v.climaCiclo, ayuda: 'Minutos reales que dura un día completo (GTA SA ≈ 24)' },
    { k: 'climaLluvia', t: 'sel', e: 'Lluvia', def: 'no', si: (v) => v.clima, op: [['no', 'Sin lluvia'], ['si', 'Lloviendo'], ['azar', 'A ratos (al azar)']],
      ayuda: 'Un disparador puede cambiarla al jugar (acción 🌦 Clima)' },
    { k: 'climaFuerza', t: 'rango', e: 'Fuerza lluvia', def: 0.6, min: 0.1, max: 1, paso: 0.05, si: (v) => v.clima && v.climaLluvia !== 'no' },
    { k: 'climaTormenta', t: 'bool', e: 'Tormenta (rayos)', def: false, si: (v) => v.clima && v.climaLluvia !== 'no', ayuda: 'Destello del cielo y trueno con retraso. Solo mientras llueve' },
    { k: 'climaRayos', t: 'num', e: 'Rayo cada (s)', def: 14, paso: 1, min: 3, si: (v) => v.clima && v.climaTormenta && v.climaLluvia !== 'no', ayuda: 'Media de segundos entre rayos' },
    { k: 'climaGotas', t: 'bool', e: 'Gotas en pantalla', def: true, si: (v) => v.clima && v.climaLluvia !== 'no' },
    { k: 'climaCharcos', t: 'bool', e: 'Suelo mojado y charcos', def: true, si: (v) => v.clima && v.climaLluvia !== 'no', ayuda: 'Solo en lo horneado (Proyecto ▸ hornear): oscurece el suelo y pone charcos con ondas' },
    // 🌬 viento del nivel: lo usan los materiales que se mecen, las hojas al viento (partículas) y la lluvia
    { grupo: '🌬 Viento' },
    { k: 'viento', t: 'bool', e: 'Viento en el nivel', def: false, ayuda: 'Pasto, árboles y banderas con viento "del nivel" se mueven juntos hacia el mismo lado; las 🍃 hojas al viento y la lluvia también. Apagado queda una brisa suave' },
    { k: 'vientoDir', t: 'rango', e: 'Hacia dónde sopla (°)', def: 90, min: 0, max: 360, paso: 5, si: (v) => v.viento, ayuda: '0 = hacia el norte (−Z) · 90 = hacia +X' },
    { k: 'vientoFuerza', t: 'rango', e: 'Fuerza', def: 0.4, min: 0, max: 1, paso: 0.05, si: (v) => v.viento },
    { k: 'vientoRafagas', t: 'rango', e: 'Ráfagas', def: 0.4, min: 0, max: 1, paso: 0.05, si: (v) => v.viento, ayuda: 'A ratos sopla más fuerte. 0 = constante' },
    // 📼 efectos de cámara propios del nivel (si no, los del Proyecto)
    ...F.Efectos.ESQUEMA.flatMap((d, i) => {
      const propio = { ...d, si: d.si ? (v) => v.fxPropio && d.si(v) : (v) => v.fxPropio };
      if (i === 0) return [{ ...d }, { k: 'fxPropio', t: 'bool', e: 'Efectos propios en este nivel', def: false,
        ayuda: 'Apagado = usa los de Proyecto ▸ Imagen y rendimiento. Encendido = este nivel usa los de abajo (empiezan copiando los del proyecto). Para quitarlos solo aquí, elige estilo Apagado' }];
      return [propio];
    }),
    { grupo: '🌦 Colores del clima', si: (v) => v.clima },
    { k: 'climaAmaCielo', t: 'color', e: 'Amanecer · cielo', def: '#6b7fb8' },
    { k: 'climaAmaHorizonte', t: 'color', e: 'Amanecer · horizonte', def: '#f0a78c' },
    { k: 'climaAmaSol', t: 'color', e: 'Amanecer · sol', def: '#ffc9a8' },
    { k: 'climaTarCielo', t: 'color', e: 'Atardecer · cielo', def: '#4a4f8a' },
    { k: 'climaTarHorizonte', t: 'color', e: 'Atardecer · horizonte', def: '#ff8a4a' },
    { k: 'climaTarSol', t: 'color', e: 'Atardecer · sol', def: '#ff9c5a' },
    { k: 'climaNocCielo', t: 'color', e: 'Noche · cielo', def: '#05070f' },
    { k: 'climaNocHorizonte', t: 'color', e: 'Noche · horizonte', def: '#141a2e' },
    { k: 'climaNocSol', t: 'color', e: 'Noche · luna', def: '#7f95d6' },
    { k: 'climaNocLuz', t: 'rango', e: 'Noche · claridad', def: 0.3, min: 0, max: 1, paso: 0.05, ayuda: 'Cuánta luz queda de noche (0 = negro total)' },
    { k: 'climaLluviaColor', t: 'color', e: 'Color de la lluvia', def: '#9fb3c8' },
  ];

  /* ---------- Tipos de entidad ---------- */
  const PARAMS_PRIMITIVA = {
    cubo: [['ancho', 1, 0.1], ['alto', 1, 0.1], ['largo', 1, 0.1]],
    suelo: [['ancho', 20, 1], ['largo', 20, 1]],
    rampa: [['ancho', 2, 0.1], ['alto', 1, 0.1], ['largo', 3, 0.1]],
    escalera: [['peldanos', 8, 1], ['ancho', 1.2, 0.1], ['altoPeldano', 0.19, 0.01], ['fondo', 0.30, 0.01]],
    escala: [['alto', 3, 0.1], ['ancho', 0.6, 0.05]],
    barril: [['radio', 0.35, 0.05], ['alto', 1, 0.1]],
  };
  const COLOR_PRIMITIVA = { barril: '#a8302a', escala: '#8a6a44', cubo: '#8a8f99', suelo: '#5f6b4e', rampa: '#9a7f5f', escalera: '#7f8a9a' };
  const ICONO = { cubo: '⬛', suelo: '▭', rampa: '◢', escalera: '▤', escala: '🪜', barril: '🛢', camara: '📷', rehen: '🧍', bomba: '💣', brecha: '🚧', tienda: '🏪', npc: '🗣', sonido: '🔊', particulas: '✨', barrera: '⬡', inicio: '⚑', modelo: '◆', carpeta: '📁', luz: '💡', recogible: '✚', enemigo: '☠', punto: '📍', aparecedor: '🥚', marcador: '📌', salida: '🚪', guardado: '💾', empujable: '🧱', montable: '🐎', agua: '💧', baul: '📦', puerta: '🔒', palanca: '🕹', disparador: '⬚', pedestal: '🏺', condicion: '⚙', plataforma: '⇅', trampa: '⚠' };
  const NOMBRE_TIPO = { cubo: 'Cubo', suelo: 'Suelo', rampa: 'Rampa', escalera: 'Escalera', escala: 'Escalera de mano', barril: 'Barril', camara: 'Cámara fija', rehen: 'Rehén', bomba: 'Bomba', brecha: 'Puerta táctica', tienda: 'Tienda', npc: 'Personaje (NPC)', sonido: 'Sonido', particulas: 'Partículas', barrera: 'Barrera de energía', inicio: 'Inicio jugador', modelo: 'Modelo', carpeta: 'Carpeta', luz: 'Luz', recogible: 'Recogible', punto: 'Punto de ruta', aparecedor: 'Aparecedor', marcador: 'Marcador', agua: 'Agua', baul: 'Baúl', puerta: 'Puerta', palanca: 'Palanca', disparador: 'Disparador', pedestal: 'Pedestal', condicion: 'Condición', plataforma: 'Plataforma', trampa: 'Trampa', enemigo: 'Enemigo', salida: 'Salida a otro nivel', guardado: 'Punto de guardado', empujable: 'Objeto movible', montable: 'Montable (vehículo)' };
  const SIN_COLISION = new Set(['particulas', 'escala', 'camara', 'rehen', 'bomba', 'sonido', 'npc', 'inicio', 'carpeta', 'luz', 'recogible', 'enemigo', 'punto', 'aparecedor', 'marcador', 'salida', 'guardado', 'agua', 'disparador', 'condicion', 'montable']);

  function entidadNueva(tipo, extra = {}) {
    const ent = {
      id: F.util.uid(), tipo, nombre: extra.nombre || NOMBRE_TIPO[tipo] || tipo,
      padre: '',                     // id de la entidad padre ('' = raíz de la escena)
      plegado: false,                // en el árbol del editor
      pos: [0, 0, 0], rot: [0, 0, 0], esc: [1, 1, 1],
      colision: SIN_COLISION.has(tipo) ? 'ninguna' : 'malla',
      visible: true, color: COLOR_PRIMITIVA[tipo] || '#ffffff',
      textura: '', normal: '', fuerzaNormal: 1, mosaico: 2,
      // material de primitivas: mismo sistema simple que los modelos
      material: { modo: 'opaco', opacidad: 1, prioridad: 0, dobleCara: false, sinLuz: false, desplazX: 0, desplazY: 0, ondular: false, ondularCant: 0.02, ondularTam: 8, ondularVel: 1.5, olas: false, olaAltura: 0.3, olaLargo: 6, olaVel: 1.5, olaDir: 0, olasJuego: false, pasto: false, pastoDensidad: 3, pastoAlto: 0.35, pastoAncho: 0.45, pastoColor: '#2f5f22', pastoColor2: '#9acd5a', pastoVariar: 0.25, pastoViento: 1, pastoLejos: 25, viento: false, vientoFuente: 'nivel', vientoDir: 90, vientoFuerza: 0.6, vientoCant: 0.15, vientoAlto: 1, vientoVel: 1, ondear: false, ondearCant: 0.12, ondearLargo: 0.6, ondearVel: 1.2 },
      params: {},
      sombra: true,                  // proyecta sombra del sol (si "Luces y sombras" está activado)
      vida: 0,                       // > 0 = se puede romper a golpes / disparos (0 = indestructible)
    };
    if (tipo === 'luz') { ent.luz = { ...F.Luces.LUZ_BASE }; ent.pos = [0, 2, 0]; }
    if (tipo === 'recogible') { ent.recogible = { ...F.Recogibles.BASE }; ent.sombra = false; }
    if (tipo === 'enemigo') { ent.enemigo = { ...F.Enemigos.BASE }; ent.criatura = ''; }   // criatura: id de la biblioteca (vinculado)
    if (tipo === 'punto') { ent.punto = { ...F.Enemigos.PUNTO }; ent.sombra = false; }
    if (tipo === 'escala') ent.forma = 'escalera';
    if (tipo === 'barril') { ent.vida = 20; ent.explota = 4; ent.danoExplosion = 70; ent.nombre = 'Barril explosivo'; }
    if (tipo === 'rehen') { ent.rehen = { ...F.Tactico.REHEN }; ent.sombra = true; }
    if (tipo === 'bomba') { ent.bomba = { ...F.Tactico.BOMBA }; }
    if (tipo === 'brecha') { ent.brecha = { ...F.Tactico.BRECHA }; }
    if (tipo === 'npc') { ent.npc = { ...F.util.copiar(F.Tactico.NPC), nodos: [F.Tactico.nodoNuevo({ opciones: [F.Tactico.opcionNueva({ texto: '¿Qué hay por aquí?', siguiente: '1' }), F.Tactico.opcionNueva()] }), F.Tactico.nodoNuevo({ texto: 'Ten cuidado más adelante.' })] }; ent.nombre = 'Aldeano'; }
    if (tipo === 'tienda') { ent.tienda = { ...F.util.copiar(F.Tactico.TIENDA), articulos: [F.Tactico.articuloNuevo(), F.Tactico.articuloNuevo({ que: 'armadura', cantidad: 50, precio: 20 })] }; ent.colision = 'caja'; }
    if (tipo === 'sonido') { ent.sonido = { ...F.Sonidos.SONIDO }; ent.sombra = false; ent.pos = [0, 1, 0]; }
    if (tipo === 'particulas') { ent.particulas = { ...F.Particulas.PARTICULAS }; ent.sombra = false; }
    if (tipo === 'barrera') { ent.barrera = { ...F.Campo.BARRERA }; ent.sombra = false; ent.esc = [4, 3, 4]; }
    if (tipo === 'camara') { ent.camara = { ...F.Camaras.CAMARA }; ent.sombra = false; ent.pos = [0, 3, 4]; ent.rot = [-25, 0, 0]; }
    if (tipo === 'aparecedor') { ent.aparecedor = { ...F.Enemigos.APARECEDOR }; ent.sombra = false; }
    if (tipo === 'marcador') { ent.marcador = { ...F.Brujula.MARCADOR }; ent.sombra = false; }
    if (tipo === 'agua') { ent.agua = { ...F.Agua.AGUA }; ent.sombra = false; ent.esc = [8, 1.5, 8]; }
    if (tipo === 'baul') { ent.baul = F.util.copiar(F.Inventario.BAUL); ent.colision = 'caja'; }
    if (tipo === 'guardado') ent.guardado = { ...F.Guardado.PUNTO };
    if (tipo === 'empujable') ent.empujable = { ...F.Empujables.EMPUJABLE };
    if (tipo === 'montable') ent.montable = { ...F.Montables.MONTABLE };
    // 🔒 la caja es el hueco de la puerta: 1,4 m de ancho, 2,3 de alto y 0,3 de fondo de serie
    if (tipo === 'puerta') { ent.puerta = { ...F.Mecanismos.PUERTA }; ent.esc = [1.4, 2.3, 0.3]; }
    if (tipo === 'plataforma') { ent.plataforma = F.util.copiar(F.Mecanismos.PLATAFORMA); ent.pos = [0, 0.3, 0]; }
    if (tipo === 'trampa') { ent.trampa = F.util.copiar(F.Mecanismos.TRAMPA); }
    if (tipo === 'pedestal') { ent.pedestal = F.util.copiar(F.Mecanismos.PEDESTAL); ent.colision = 'caja'; }
    if (tipo === 'condicion') { ent.condicion = F.util.copiar(F.Mecanismos.CONDICION); ent.sombra = false; }
    if (tipo === 'disparador') { ent.disparador = F.util.copiar(F.Mecanismos.DISPARADOR); ent.esc = [3, 2.5, 3]; ent.sombra = false; }
    if (tipo === 'palanca') { ent.palanca = { ...F.util.copiar(F.Mecanismos.PALANCA) }; ent.colision = 'caja'; }
    // ⚑ principal = donde empieza el juego; los demás son puntos de llegada desde otros niveles
    if (tipo === 'inicio') ent.inicio = { principal: true };
    // 🚪 la caja mide 1×1×1 y se agranda con la escala (2 m de ancho, 2.5 de alto, 1 de fondo de serie)
    if (tipo === 'salida') { ent.salida = { ...F.Niveles.SALIDA }; ent.esc = [2, 2.5, 1]; ent.sombra = false; }
    for (const [k, v] of PARAMS_PRIMITIVA[tipo] || []) ent.params[k] = v;
    return Object.assign(ent, extra);
  }

  function escenaNueva(nombre = 'Escena', conEjemplo = false) {
    const entidades = conEjemplo
      ? [
        entidadNueva('suelo', { nombre: 'Suelo' }),
        entidadNueva('inicio', { pos: [0, 0, 4] }),
        entidadNueva('escalera', { pos: [-3, 0, -2] }),
        entidadNueva('rampa', { pos: [3, 0, -2] }),
        entidadNueva('cubo', { pos: [0, 0, -4], params: { ancho: 2, alto: 0.4, largo: 2 } }),
        entidadNueva('cubo', { pos: [0, 0, -7], params: { ancho: 2, alto: 1.2, largo: 2 } }),
      ]
      : [entidadNueva('suelo', { nombre: 'Suelo' }), entidadNueva('inicio', { pos: [0, 0, 4] })];
    return { id: F.util.uid(), nombre, ambiente: F.valoresPorDefecto(ESQUEMA_AMBIENTE), nivel: { ...F.Niveles.NIVEL }, entidades };
  }

  /* ---------- Carpetas de Archivos (solo organizan) ----------
     rol: a qué tipo de archivo va cada una por defecto al importar */
  const CARPETAS_BASE = [
    ['modelos', 'Modelos'], ['texturas', 'Texturas'], ['musica', 'Música'], ['sonidos', 'Sonidos'], ['fuentes', 'Fuentes'],
  ];
  function carpetasPorDefecto() {
    return CARPETAS_BASE.map(([rol, nombre]) => ({ id: F.util.uid(), nombre, rol, padre: '', plegada: false }));
  }
  // Rol de un archivo: audio de más de 20 s (o MIDI) = música; corto = sonido
  function rolDeAsset(a) {
    if (a.tipo === 'modelo') return 'modelos';
    if (a.tipo === 'textura') return 'texturas';
    if (a.tipo === 'fuente') return 'fuentes';
    if (a.tipo === 'midi') return 'musica';
    if (a.tipo === 'audio') return (a.duracion || 0) > 20 ? 'musica' : 'sonidos';
    return '';
  }

  function jugadorPorDefecto() {
    const modulos = {};
    for (const m of F.modulosOrdenados()) {
      modulos[m.nombre] = { activo: m.activoPorDefecto !== false, ...F.valoresPorDefecto(m.props) };
    }
    return { modulos };
  }

  /* ---------- Menús del juego (principal, pausa, opciones) ----------
     Botones: { texto, accion, escena? }. Acciones en FORJA.Menus.ACCIONES. */
  // ⚔ estilo de un arma cuerpo a cuerpo: corta · larga · dosManos · lanza (el elegido o por el nombre)
  function estiloCuerpo(d) {
    if (!d || d.tipo !== 'cuerpo') return null;
    if (d.estilo && d.estilo !== 'auto') return d.estilo;
    const n = (d.nombre || '').toLowerCase();
    if (/lanza|bast[oó]n|pica|alabarda|tridente|vara|b[oó] /.test(n)) return 'lanza';
    if (/espad[oó]n|mandoble|claymore|zweih|odachi|nodachi|a dos manos/.test(n)) return 'espadon';
    if (/hacha|mazo|martillo|maza|guada[ñn]a|pico/.test(n)) return 'dosManos';
    if (/espada|machete|sable|katana|cimitarra|tubo|bate|palo|porra/.test(n)) return 'larga';
    return 'corta';
  }
  function menusPorDefecto() {
    return {
      tema: {
        plantilla: 'clasico', fuente: '', colorTexto: '#e8e2d0', colorSel: '#e8a33d', colorFondo: '#000000',
        opacidadFondo: 0.55, tamano: 22, alineacion: 'centro', mayusculas: true, sonidoMover: '', sonidoAceptar: '',
      },
      principal: {
        activo: true, titulo: '', subtitulo: '', logo: '', fondo: 'escena', imagen: '', escena: '', velGiro: 0.08,
        musica: '', textoPulsar: 'PULSA CUALQUIER TECLA',
        botones: [
          { texto: 'Nueva partida', accion: 'nueva' },
          { texto: 'Continuar', accion: 'continuar' },
          { texto: 'Cargar partida', accion: 'cargar' },
          { texto: 'Opciones', accion: 'opciones' },
          { texto: 'Salir', accion: 'salir' },
        ],
      },
      pausa: {
        titulo: 'PAUSA',
        botones: [
          { texto: 'Continuar', accion: 'reanudar' },
          { texto: 'Guardar partida', accion: 'guardar' },
          { texto: 'Cargar partida', accion: 'cargar' },
          { texto: 'Mapa', accion: 'mapa' },
          { texto: 'Opciones', accion: 'opciones' },
          { texto: 'Reiniciar nivel', accion: 'reiniciar' },
          { texto: 'Menú principal', accion: 'menu_principal' },
        ],
      },
      opciones: { video: true, audio: true, controles: true, tactil: true, mapeo: true },
      gameover: {
        titulo: 'HAS MUERTO', subtitulo: '',
        botones: [
          { texto: 'Reintentar', accion: 'reiniciar' },
          { texto: 'Cargar partida', accion: 'cargar' },
          { texto: 'Menú principal', accion: 'menu_principal' },
          { texto: 'Salir del juego', accion: 'salir' },
        ],
      },
      // 🗺 Menú de misiones (selección de nivel tipo móvil): tarjetas por nivel con sus estrellas, bloqueados en orden
      misiones: { titulo: 'MISIONES', bloquear: true, soloConMision: true, alTerminar: 'menu', desbloquearTodo: false },
      // 📚 Capítulos (episodios): elegir capítulo → sus niveles, que se abren al llegar a ellos
      capitulos: { titulo: 'CAPÍTULOS', bloquear: true, verCuantos: true },
      // 🏆 Juego completado (acción "🏆 Juego completado" o "🏁 Terminar la misión" sin más niveles): tiempo y rango
      victoria: {
        titulo: 'JUEGO COMPLETADO', subtitulo: '', tiempo: true, rango: true, rangos: 'S:300, A:480, B:720', rangoPeor: 'C', estrellas: true,
        botones: [
          { texto: 'Menú principal', accion: 'menu_principal' },
          { texto: 'Nueva partida', accion: 'nueva' },
        ],
      },
      // 💾 Dónde se guarda y qué pasa al morir (puntos de guardado: motor/guardado.js)
      guardado: { ...F.Guardado.GUARDADO },
      // ❤ vidas estilo arcade: al morir se gasta una y reapareces; sin vidas, Game Over
      vidas: { activo: false, inicio: 3, max: 9, extraCada: 100, divisa: '', gastar: true, icono: '❤', imagen: '' },
      // 🎯 Briefing de misión (pantalla antes de empezar un nivel con misión)
      briefing: {
        fondo: 'aerea', velGiro: 0.08, distancia: 1, altura: 0.35, colorFondo: '#000000', opacidadFondo: 0.55, difuminado: 4,
        ancho: 640, colorCaja: '#14161d', opacidadCaja: 1, colorBorde: '#e8a33d', grosorBorde: 2, colorTitulo: '#e8a33d', colorTexto: '#e8e2d0',
        colorBoton: '#e8a33d', colorTextoBoton: '#14161d', textoSub: 'Misión', textoObjetivos: 'Objetivos', textoBoton: 'Empezar',
        verObjetivos: true, verPista: true, sonidoAbrir: '',
      },
      // Caja de mensajes del juego (carteles, notas, diálogos): ver motor/hud.js → Hud.estiloMensaje
      mensaje: {
        posicion: 'abajo', ancho: 70, tamano: 1, colorTexto: '#e8e2d0', colorFondo: '#000000', opacidadFondo: 0.82,
        colorBorde: '#e8a33d', grosorBorde: 2, esquinas: 0, alineacion: 'izquierda', escribir: 40, sonidoAbrir: '', sonidoLetra: '',
      },
    };
  }

  function normalizarMenus(m) {
    const base = menusPorDefecto();
    m = m || {};
    const n = {};
    for (const k of Object.keys(base)) n[k] = { ...base[k], ...(m[k] || {}) };
    for (const k of ['principal', 'pausa', 'gameover', 'victoria']) if (!Array.isArray(n[k].botones)) n[k].botones = base[k].botones;
    return n;
  }

  /* ---------- Armas del proyecto (se editan en la pestaña Armas) ----------
     tipo: 'instantaneo' (la bala llega al instante, como Doom) · 'proyectil' (se ve volar: cohetes, flechas, bolas de fuego)
           · 'cuerpo' (cuchillo, espada, puño) */
  const ESQUEMA_ARMA = [
    { grupo: 'Arma' },
    { k: 'nombre', t: 'texto', e: 'Nombre', def: 'Arma' },
    { k: 'tipo', t: 'sel', e: 'Tipo', def: 'instantaneo',
      op: [['instantaneo', 'Disparo instantáneo (pistola, escopeta)'], ['proyectil', 'Proyectil (cohete, flecha, magia)'], ['rayo', 'Rayo continuo (láser, 1 a 3 rayos)'], ['cuerpo', 'Cuerpo a cuerpo (cuchillo, espada)'], ['escudo', '🛡 Escudo (hechizo de protección)'], ['area', '✸ Ataque de área (onda o aura)']] },
    { k: 'magia', t: 'sel', e: 'Arma mágica', def: 'no', si: (v) => v.tipo !== 'cuerpo',
      op: [['no', 'No (arma normal)'], ['varita', '🪄 Varita (una mano)'], ['baston', '🦯 Bastón (dos manos, cristal en la punta)'], ['libro', '📖 Libro de hechizos']],
      ayuda: 'Forma de serie y animación de lanzar: la varita da un toque al frente, el bastón empuja con las dos manos y el libro pasa las hojas. La gema / el cristal brillan del color del hechizo (Proyectil ▸ Color). Un modelo propio la sustituye' },
    { k: 'alEmpezar', t: 'bool', e: 'La tiene al empezar', def: true, ayuda: 'Si no, hay que recogerla (✚ Recogible). El módulo Armas puede cambiar esto para todas' },
    { k: 'municion', t: 'sel', e: 'Usa munición', def: '', op: [['', 'Propia (solo esta arma)']],
      ayuda: 'Un tipo de munición se comparte entre las armas que lo usan (como en Doom). Los tipos se crean abajo, en "Tipos de munición"' },
    { k: 'dano', t: 'num', e: 'Daño', def: 20, paso: 1, min: 0, ayuda: 'Por bala / perdigón / golpe. Rayo: por SEGUNDO, repartido entre sus rayos. El tipo de munición puede multiplicarlo' },
    { k: 'tipoDano', t: 'sel', e: 'Tipo de daño', def: 'normal', op: [], ayuda: 'Los enemigos podrán resistirlo o ser débiles a él. Con munición: si no es Normal, manda sobre el de la munición (hechizos que comparten maná)' },
    { k: 'efecto', t: 'sel', e: 'Efecto de estado', def: 'auto', op: [], ayuda: 'Fuego quema, veneno envenena, hielo congela, eléctrico aturde. Los enemigos con resistencia 0 a ese tipo son inmunes' },
    { k: 'efectoSeg', t: 'num', e: 'Duración del efecto (s)', def: 0, paso: 0.5, min: 0, ayuda: '0 = la de serie', si: (v) => v.efecto !== 'ninguno' },
    { k: 'efectoProb', t: 'rango', e: 'Probabilidad del efecto', def: 1, min: 0, max: 1, paso: 0.05, si: (v) => v.efecto !== 'ninguno' },
    { k: 'cadencia', t: 'num', e: 'Disparos por segundo', def: 3, paso: 0.5, min: 0.1, si: (v) => v.tipo !== 'rayo' },
    { k: 'automatica', t: 'bool', e: 'Automática', def: false, ayuda: 'Dispara mientras mantienes el botón', si: (v) => v.tipo !== 'rayo' },
    { k: 'alcance', t: 'num', e: 'Alcance (m)', def: 80, paso: 1, min: 0.5 },
    { k: 'golpe3p', t: 'sel', e: 'Golpe en 3ª persona', def: 'auto', si: (v) => v.tipo === 'cuerpo',
      op: [['auto', 'Automático (el que traiga el modelo)'], ['slash', '🗡 Tajo (slash1-3)'], ['stab', '🔪 Estocada (stab 1-3)'], ['spear', '🔱 Lanza (spear 1-3)'], ['axe', '🪓 Hacha (axe 1-3)'], ['kick', '🦵 Patada (kick 1-3)'], ['attack', '👊 Sin arma (attack 1-3)']],
      ayuda: 'Qué animación de golpe usa el modelo y su combo: si traes 2 o 3 golpes (stab2, stab3…), se encadenan al pegar seguido' },
    { k: 'cuerpo3p', t: 'sel', e: 'Cómo golpea en 3ª persona', def: 'auto', si: (v) => v.tipo === 'cuerpo',
      op: [['auto', 'Automático (brazos si caminas, entero si estás quieto)'], ['brazos', '💪 Solo brazos (las piernas siguen caminando)'], ['entero', '🦵 Cuerpo entero (frena al golpear)']],
      ayuda: 'Solo brazos: el torso golpea y las piernas siguen tu paso (cuchillo, puño, espada ligera). Cuerpo entero: la animación completa y el jugador se frena para no deslizarse (martillo, embestida). Las patadas y el golpe agachado siempre son de cuerpo entero' },
    { grupo: '⚔ Cuerpo a cuerpo', si: (v) => v.tipo === 'cuerpo' },
    { k: 'estilo', t: 'sel', e: 'Cómo se sujeta', def: 'auto', si: (v) => v.tipo === 'cuerpo',
      op: [['auto', 'Automático (por el nombre)'], ['corta', '🔪 Corta, una mano (cuchillo, daga, puño)'], ['larga', '🗡 Larga, una mano (espada, machete, sable)'],
        ['espadon', '⚔ Espada a dos manos (mandoble, espadón, katana a dos manos)'], ['dosManos', '🪓 A dos manos (hacha, mazo, martillo)'], ['lanza', '🔱 Lanza (lanza, bastón, pica)']],
      ayuda: 'Cambia la postura, el golpe del muñeco del motor y la forma del arma de serie. Automático: cuchillo/daga = corta · espada/machete = larga · mandoble/espadón = espada a dos manos · hacha/mazo/martillo = dos manos · lanza/bastón = lanza' },
    { k: 'clicDerecho', t: 'sel', e: 'Clic derecho / LT', def: 'ambos', si: (v) => v.tipo === 'cuerpo',
      op: [['ambos', '🛡🎯 Apuntar y bloquear a la vez'], ['bloquear', '🛡 Solo bloquear'], ['apuntar', '🎯 Solo apuntar (mira hacia la cámara)']] },
    { k: 'bloqueo', t: 'rango', e: 'Daño que para al bloquear (%)', def: 70, min: 0, max: 100, paso: 5, si: (v) => v.tipo === 'cuerpo' && v.clicDerecho !== 'apuntar',
      ayuda: 'Solo lo que viene de frente. 100 = no entra nada. Las explosiones no se bloquean' },
    { k: 'parry', t: 'num', e: 'Parry: ventana (s)', def: 0.25, paso: 0.05, min: 0, si: (v) => v.tipo === 'cuerpo' && v.clicDerecho !== 'apuntar',
      ayuda: 'Si bloqueas justo antes del golpe (dentro de este tiempo) no recibes nada y el enemigo queda aturdido. 0 = sin parry' },
    { k: 'aturdeParry', t: 'num', e: 'Parry: aturde (s)', def: 1.2, paso: 0.1, min: 0, si: (v) => v.tipo === 'cuerpo' && v.clicDerecho !== 'apuntar' && v.parry > 0 },
    // ⚔ combo (módulo Combate ▸ Combos): la cadena de golpes al pegar seguido. Movimientos: tajo, estocada, giro, lanzador, barrido, fuerte
    { k: 'combo', t: 'texto', e: 'Combo', def: '', si: (v) => v.tipo === 'cuerpo',
      ayuda: 'Golpes separados por comas, se encadenan al pegar seguido. Vacío = el de su estilo. Movimientos: tajo, estocada, giro (todo alrededor), lanzador (lo levanta), barrido (lo aturde), fuerte (lento y potente). Ej.: tajo, tajo, giro' },
    { k: 'comboPausa', t: 'texto', e: 'Combo con pausa', def: '', si: (v) => v.tipo === 'cuerpo',
      ayuda: 'Si esperas un instante entre dos golpes, sigue por aquí (como Devil May Cry). Vacío = el de su estilo. Ej.: tajo, lanzador' },
    { k: 'postura3p', t: 'sel', e: 'Postura en 3ª persona', def: 'auto', si: (v) => v.tipo !== 'cuerpo',
      op: [['auto', 'Automática (según el arma)'], ['pistola', '🔫 A una mano (pistola)'], ['rifle', '🎯 A dos manos (rifle, escopeta, ballesta)'], ['hombro', '🚀 Al hombro (lanzacohetes)'], ['ninguna', 'Sin postura']],
      ayuda: 'Cómo la sujeta el modelo al apuntar y disparar en 3ª persona (usa aim_pistol / aim_rifle / aim_shoulder del modelo si los trae). Automática: por el nombre y el tipo' },
    { grupo: 'Rayo continuo', si: (v) => v.tipo === 'rayo' },
    { k: 'rayos', t: 'rango', e: 'Rayos', def: 1, min: 1, max: 3, paso: 1, ayuda: '1 a 3 rayos a la vez, en abanico. El daño se reparte entre ellos' },
    { k: 'separacion', t: 'num', e: 'Apertura del abanico (°)', def: 2.5, paso: 0.5, min: 0, si: (v) => v.rayos > 1 },
    { k: 'capas', t: 'rango', e: 'Capas', def: 3, min: 1, max: 3, paso: 1, ayuda: '1 = línea simple · 2 = núcleo blanco + cuerpo · 3 = + halo exterior' },
    { k: 'anchoRayo', t: 'num', e: 'Grosor (m)', def: 0.07, paso: 0.01, min: 0.01 },
    { k: 'colorRayo', t: 'color', e: 'Color', def: '#66e6ff' },
    { k: 'consumo', t: 'num', e: 'Munición por segundo', def: 8, paso: 1, min: 0, ayuda: 'Lo que gasta mientras dispara (sin munición infinita)' },
    { k: 'duracionMax', t: 'num', e: 'Se recalienta a los (s)', def: 3, paso: 0.5, min: 0, ayuda: 'Segundos seguidos que aguanta. 0 = sin límite' },
    { k: 'recuperacion', t: 'num', e: 'Enfriar (s)', def: 2, paso: 0.25, min: 0, si: (v) => v.duracionMax > 0,
      ayuda: 'Espera al recalentarse. Si sueltas antes, espera la parte proporcional' },
    { k: 'orbe', t: 'bool', e: 'Esfera de energía en el cañón', def: true },
    { grupo: 'Balas' },
    { k: 'perdigones', t: 'num', e: 'Balas por disparo', def: 1, paso: 1, min: 1, ayuda: 'Escopeta: 6-10', si: (v) => v.tipo !== 'rayo' },
    { k: 'dispersion', t: 'num', e: 'Dispersión (°)', def: 1, paso: 0.5, min: 0, si: (v) => v.tipo !== 'rayo' },
    { k: 'cargador', t: 'num', e: 'Cargador', def: 12, paso: 1, min: 0, ayuda: '0 = sin recargar (usa directo la reserva)' },
    { k: 'reserva', t: 'num', e: 'Munición que trae', def: 48, paso: 1, min: 0,
      ayuda: 'Propia: la que tiene al empezar y la que da al recogerla de nuevo. Con tipo de munición: la que suma al recogerla' },
    { k: 'reservaMax', t: 'num', e: 'Munición extra máxima', def: 120, paso: 1, min: 0, si: (v) => !v.municion, ayuda: 'Con un tipo de munición manda la máxima del tipo' },
    { k: 'infinita', t: 'bool', e: 'Munición infinita', def: false },
    { k: 'gasto', t: 'num', e: 'Munición por disparo', def: 1, paso: 1, min: 1, si: (v) => !v.infinita && !(v.cargador > 0) && v.tipo !== 'rayo', ayuda: 'Hechizos: maná que gasta cada lanzamiento' },
    { k: 'recarga', t: 'num', e: 'Tiempo de recarga (s)', def: 1.2, paso: 0.1, min: 0 },
    // 🛡 hechizo escudo: un campo de energía te rodea unos segundos y para el daño (motor/campos.js)
    { grupo: '🛡 Escudo', si: (v) => v.tipo === 'escudo' },
    { k: 'escudoSeg', t: 'num', e: 'Dura (s)', def: 6, paso: 0.5, min: 0.5 },
    { k: 'escudoBloquea', t: 'rango', e: 'Daño que para (%)', def: 100, min: 10, max: 100, paso: 5, ayuda: '100 = no entra nada mientras dura' },
    { k: 'escudoAguante', t: 'num', e: 'Aguanta (daño)', def: 0, paso: 10, min: 0, ayuda: 'Se rompe al recibir tanto daño. 0 = aguanta todo hasta que se acaba el tiempo' },
    { k: 'escudoEstilo', t: 'sel', e: 'Aspecto', def: 'ondas', op: [['ondas', '〰 Ondas + borde brillante'], ['hex', '⬡ Rejilla de hexágonos'], ['rayos', '⚡ Rayos eléctricos'], ['anillos', '◎ Anillos que recorren'], ['plasma', '🔥 Plasma que fluye']] },
    { k: 'escudoColor', t: 'color', e: 'Color', def: '#7fb4ff' },
    // ✸ ataque de área: una esfera de energía alrededor del jugador (motor/area.js). Usa Daño de arriba
    { grupo: '✸ Área', si: (v) => v.tipo === 'area' },
    { k: 'areaForma', t: 'sel', e: 'Forma', def: 'onda', op: [['onda', '💥 Onda que crece (un golpe)'], ['aura', '🌀 Aura que se queda (daña poco a poco)']],
      ayuda: 'Daño: onda = el golpe (la mitad en el borde) · aura = por segundo' },
    { k: 'areaRadio', t: 'num', e: 'Radio (m)', def: 5, paso: 0.5, min: 1 },
    { k: 'areaEmpuje', t: 'num', e: 'Empujón', def: 8, paso: 1, min: 0 },
    { k: 'areaCrecer', t: 'num', e: 'Tarda en crecer (s)', def: 0.35, paso: 0.05, min: 0.05, si: (v) => v.areaForma !== 'aura' },
    { k: 'areaDura', t: 'num', e: 'Dura (s)', def: 4, paso: 0.5, min: 0.5, si: (v) => v.areaForma === 'aura' },
    { k: 'areaEstilo', t: 'sel', e: 'Aspecto', def: 'ondas', op: [['ondas', '〰 Ondas + borde brillante'], ['hex', '⬡ Rejilla de hexágonos'], ['rayos', '⚡ Rayos eléctricos'], ['anillos', '◎ Anillos que recorren'], ['plasma', '🔥 Plasma que fluye']] },
    { k: 'areaColor', t: 'color', e: 'Color', def: '#c08cff' },
    { k: 'areaPulso', t: 'bool', e: '◎ Pulso (2 esferas)', def: false, ayuda: 'Sale una segunda esfera detrás de la primera (onda) o una que late hacia fuera una y otra vez (aura). Solo se ve: no hace más daño' },
    { grupo: 'Proyectil', si: (v) => v.tipo !== 'escudo' && v.tipo !== 'area' },
    { k: 'velocidad', t: 'num', e: 'Velocidad (m/s)', def: 28, paso: 1, min: 1 },
    { k: 'gravedadBala', t: 'num', e: 'Gravedad', def: 0, paso: 0.5, min: 0, ayuda: '0 = recto · 9.8 = cae como una flecha o granada' },
    { k: 'radio', t: 'num', e: 'Radio de explosión (m)', def: 0, paso: 0.5, min: 0, ayuda: '0 = sin explosión' },
    { k: 'danaJugador', t: 'bool', e: 'La explosión daña al jugador', def: true },
    { k: 'colorBala', t: 'color', e: 'Color', def: '#ffcc66' },
    { grupo: 'Sensación', av: true },
    { k: 'retroceso', t: 'num', e: 'Retroceso (°)', def: 1.5, paso: 0.5, min: 0, ayuda: 'Cuánto sube la vista al disparar' },
    { k: 'zoom', t: 'num', e: 'Campo de visión al apuntar', def: 50, paso: 1, min: 10, ayuda: 'Clic derecho / LT. Menos = más zoom' },
    { k: 'fogonazo', t: 'color', e: 'Color del fogonazo', def: '#ffd27a' },
    { k: 'tamFogonazo', t: 'num', e: 'Tamaño del fogonazo', def: 1, paso: 0.1, min: 0, ayuda: '1 = normal · 0 = sin fogonazo (silenciador, arco, magia)' },
    { k: 'agujeros', t: 'bool', e: 'Marcas en paredes', def: true },
    { grupo: 'Aspecto y sonido' },
    { k: 'modelo', t: 'asset', e: 'Modelo del arma', def: '', tipoAsset: 'modelo', vacio: '(una pistola de cajas)', ayuda: 'Se usa en 1ª y 3ª persona. Si trae Arma_FPS y Arma_TPS (Forja de personajes a2) cada vista usa la suya; si no, el mismo modelo sirve para las dos' },
    { k: 'escalaModelo', t: 'num', e: 'Escala del modelo', def: 1, paso: 0.05, min: 0.01 },
    { k: 'posX', t: 'num', e: 'Posición X', def: 0.22, paso: 0.01 },
    { k: 'posY', t: 'num', e: 'Posición Y', def: -0.2, paso: 0.01 },
    { k: 'posZ', t: 'num', e: 'Posición Z', def: -0.42, paso: 0.01 },
    { k: 'fpGiroX', t: 'num', e: 'Girar en X (°)', def: 0, paso: 5, ayuda: '1ª persona: inclinar la punta / el cañón arriba (+) o abajo (−)' },
    { k: 'fpGiroY', t: 'num', e: 'Girar en Y (°)', def: 0, paso: 5, ayuda: '1ª persona: girar a la izquierda (+) o a la derecha (−)' },
    { k: 'fpGiroZ', t: 'num', e: 'Girar en Z (°)', def: 0, paso: 5, ayuda: '1ª persona: rodar sobre su eje (espada de canto o de plano: 90)' },
    { k: 'sonido', t: 'asset', e: 'Sonido de disparo', def: '', tipoAsset: 'audio', vacio: '(del motor)' },
    { k: 'sonidoRecarga', t: 'asset', e: 'Sonido de recarga', def: '', tipoAsset: 'audio', vacio: '(del motor)' },
    { grupo: 'En la mano (3ª persona)' },
    { k: 'tpsX', t: 'num', e: 'Mover a los lados', def: 0, paso: 0.01, ayuda: 'Metros. Para que la empuñadura quede justo en la mano de tu modelo' },
    { k: 'tpsY', t: 'num', e: 'Mover arriba / abajo', def: 0, paso: 0.01 },
    { k: 'tpsZ', t: 'num', e: 'Mover adelante / atrás', def: 0, paso: 0.01, ayuda: 'Positivo = hacia atrás (hacia la culata)' },
    { k: 'tpsGiroX', t: 'num', e: 'Girar en X (°)', def: 0, paso: 15, ayuda: 'Inclinar el cañón arriba / abajo' },
    { k: 'tpsGiroY', t: 'num', e: 'Girar en Y (°)', def: 0, paso: 15, ayuda: 'Si el arma queda de lado respecto a tu modelo, prueba 90 o −90' },
    { k: 'tpsGiroZ', t: 'num', e: 'Girar en Z (°)', def: 0, paso: 15, ayuda: 'Rodar el arma sobre su cañón' },
    { k: 'tpsEscala', t: 'num', e: 'Tamaño en 3ª persona', def: 1, paso: 0.05, min: 0.05 },
  ];
  function armaNueva(extra = {}) {
    return { id: F.util.uid(), ...F.valoresPorDefecto(ESQUEMA_ARMA), ...extra };
  }
  /* Tipos de munición: se comparten entre armas (balas para pistola y metralleta, cartuchos, cohetes…).
     multDano y tipoDano llegan a lo que recibe el golpe: objetos con Vida y, más adelante, enemigos (resistencias). */
  const TIPOS_DANO = [['normal', 'Normal'], ['perforante', 'Perforante (atraviesa armaduras)'], ['explosivo', 'Explosivo'],
    ['fuego', 'Fuego'], ['electrico', 'Eléctrico'], ['magico', 'Mágico'], ['veneno', 'Veneno'], ['hielo', 'Hielo']];
  ESQUEMA_ARMA.find((d) => d.k === 'tipoDano').op = TIPOS_DANO;
  ESQUEMA_ARMA.find((d) => d.k === 'efecto').op = F.Estados ? F.Estados.OPCIONES : [['auto', 'Según el tipo de daño']];
  const ESQUEMA_MUNICION = [
    { k: 'nombre', t: 'texto', e: 'Nombre', def: 'Munición' },
    { k: 'icono', t: 'texto', e: 'Icono en el HUD', def: '▮', ayuda: 'Un carácter o emoji (▮ ◆ ● ✦ 🔥…)' },
    { k: 'maxima', t: 'num', e: 'Máximo que se puede llevar', def: 200, paso: 5, min: 0 },
    { k: 'alEmpezar', t: 'num', e: 'Al empezar', def: 0, paso: 5, min: 0 },
    { k: 'multDano', t: 'rango', e: 'Multiplica el daño', def: 1, min: 0.1, max: 5, paso: 0.05, ayuda: 'Balas de punta hueca 1.5, munición de práctica 0.5…' },
    { k: 'tipoDano', t: 'sel', e: 'Tipo de daño', def: 'normal', op: TIPOS_DANO, ayuda: 'Los enemigos podrán resistirlo o ser débiles a él' },
    { k: 'color', t: 'color', e: 'Color del impacto', def: '#ffd27a' },
    { k: 'regenera', t: 'num', e: 'Se recarga sola (por segundo)', def: 0, paso: 1, min: 0, ayuda: 'Maná que vuelve poco a poco. 0 = no' },
  ];
  function municionNueva(extra = {}) {
    return { id: F.util.uid(), ...F.valoresPorDefecto(ESQUEMA_MUNICION), ...extra };
  }
  function armasPorDefecto() {
    return paqueteArmas().armas;
  }
  // Armas y munición de ejemplo, enlazadas entre sí
  function paqueteArmas() {
    const balas = municionNueva({ nombre: 'Balas', icono: '▮', maxima: 200, alEmpezar: 48 });
    const cartuchos = municionNueva({ nombre: 'Cartuchos', icono: '◼', maxima: 50, alEmpezar: 12, color: '#ffb35a' });
    const cohetes = municionNueva({ nombre: 'Cohetes', icono: '➶', maxima: 20, alEmpezar: 0, tipoDano: 'explosivo', color: '#ff8a3a' });
    const energia = municionNueva({ nombre: 'Energía', icono: 'ϟ', maxima: 300, alEmpezar: 120, tipoDano: 'electrico', color: '#66e6ff' });
    const armas = [
      armaNueva({ nombre: 'Pistola', municion: balas.id }),
      armaNueva({ nombre: 'Escopeta', municion: cartuchos.id, perdigones: 8, dispersion: 6, dano: 9, cadencia: 1.2, cargador: 6, reserva: 12, reservaMax: 48,
        retroceso: 4, alcance: 40, recarga: 1.8, posX: 0.2, posY: -0.22 }),
      armaNueva({ nombre: 'Lanzacohetes', municion: cohetes.id, tipo: 'proyectil', dano: 100, cadencia: 0.9, cargador: 1, reserva: 6, reservaMax: 20,
        radio: 3.5, velocidad: 22, retroceso: 3, recarga: 1, colorBala: '#ff8a3a', alEmpezar: false }),
      armaNueva({ nombre: 'Rifle de asalto', municion: balas.id, automatica: true, cadencia: 10, dano: 14, cargador: 30, reserva: 60, dispersion: 2.5,
        retroceso: 0.7, alcance: 70, recarga: 1.6, posX: 0.2, posY: -0.21, postura3p: 'rifle' }),
      armaNueva({ nombre: 'Rayo de energía', municion: energia.id, tipo: 'rayo', dano: 30, cargador: 0, reserva: 120, alcance: 30, retroceso: 0,
        agujeros: false, fogonazo: '#66e6ff', postura3p: 'rifle', posX: 0.2, posY: -0.21 }),
      armaNueva({ nombre: 'Cuchillo', tipo: 'cuerpo', dano: 35, cadencia: 2.2, alcance: 1.8, cargador: 0, reserva: 0, infinita: true,
        retroceso: 0, agujeros: false }),
      armaNueva({ nombre: 'Espada', tipo: 'cuerpo', estilo: 'larga', dano: 45, cadencia: 1.6, alcance: 2.2, cargador: 0, reserva: 0, infinita: true, retroceso: 0, agujeros: false }),
      armaNueva({ nombre: 'Mandoble', tipo: 'cuerpo', estilo: 'espadon', dano: 70, cadencia: 1.1, alcance: 2.6, cargador: 0, reserva: 0, infinita: true, retroceso: 0, agujeros: false, cuerpo3p: 'entero', alEmpezar: false }),
      armaNueva({ nombre: 'Hacha', tipo: 'cuerpo', estilo: 'dosManos', dano: 80, cadencia: 0.9, alcance: 2.3, cargador: 0, reserva: 0, infinita: true, retroceso: 0, agujeros: false, cuerpo3p: 'entero' }),
      armaNueva({ nombre: 'Lanza', tipo: 'cuerpo', estilo: 'lanza', dano: 40, cadencia: 1.4, alcance: 3, cargador: 0, reserva: 0, infinita: true, retroceso: 0, agujeros: false }),
    ];
    // ✦ maná: munición de los hechizos (cada hechizo pone su tipo de daño y su efecto)
    const mana = municionNueva({ nombre: 'Maná', icono: '✦', maxima: 100, alEmpezar: 100, color: '#8fa8ff', regenera: 2 });
    armas.push(
      armaNueva({ nombre: 'Bola de fuego', magia: 'varita', municion: mana.id, tipo: 'proyectil', tipoDano: 'fuego', dano: 35, cadencia: 1.5, cargador: 0, reserva: 0, gasto: 8,
        radio: 1.5, velocidad: 18, retroceso: 0, colorBala: '#ff7a2a', fogonazo: '#ff7a2a', agujeros: false, alEmpezar: false }),
      armaNueva({ nombre: 'Rayo de hielo', magia: 'baston', municion: mana.id, tipo: 'proyectil', tipoDano: 'hielo', dano: 15, cadencia: 2, cargador: 0, reserva: 0, gasto: 6,
        radio: 0, velocidad: 24, retroceso: 0, colorBala: '#9ae6ff', fogonazo: '#9ae6ff', agujeros: false, alEmpezar: false }),
      armaNueva({ nombre: 'Escudo arcano', magia: 'libro', municion: mana.id, tipo: 'escudo', dano: 0, cadencia: 0.5, cargador: 0, reserva: 0, gasto: 25,
        escudoSeg: 6, escudoBloquea: 100, escudoEstilo: 'hex', escudoColor: '#b48cff', colorBala: '#b48cff', fogonazo: '#b48cff', tamFogonazo: 0, retroceso: 0, agujeros: false, alEmpezar: false }),
      // ✸ ataque de área como arma: onda de energía que empuja (bastón)
      armaNueva({ nombre: 'Nova arcana', magia: 'baston', municion: mana.id, tipo: 'area', tipoDano: 'magico', dano: 45, cadencia: 0.6, cargador: 0, reserva: 0, gasto: 30,
        areaForma: 'onda', areaRadio: 6, areaEmpuje: 10, areaCrecer: 0.35, areaEstilo: 'ondas', areaColor: '#c08cff', colorBala: '#c08cff', fogonazo: '#c08cff', tamFogonazo: 0, retroceso: 0, agujeros: false, alEmpezar: false })
    );
    return { armas, municiones: [balas, cartuchos, cohetes, energia, mana] };
  }

  /* ---------- HUD del juego (lo dibuja motor/hud.js; se edita en Juego ▸ HUD) ---------- */
  const ESQUEMA_HUD = [
    { grupo: 'Distribución' },
    { k: 'posicion', t: 'sel', e: 'Posiciones', def: 'esquinas', op: [
      ['esquinas', 'Esquinas: vida abajo a la izq., munición abajo a la der.'],
      ['barra', 'Barra abajo: todo en una franja (Quake / Doom)'],
      ['arriba', 'Arriba: escudo y vida arriba, munición arriba (Halo)'],
      ['arcade', 'Arcade: números grandes arriba (Mario / plataformas)'],
      ['centro', 'Centrado: todo abajo al centro, junto a la mira'],
      ['discreto', 'Discreto: pequeño abajo a la derecha (survival)'],
      ['libre', '✥ Libre: arrastra cada pieza en la vista previa']],
      ayuda: 'Libre: empieza como Esquinas; mueve con el ratón cada pieza de la vista previa y queda donde la sueltes' },
    { k: 'equipoPos', t: 'sel', e: 'Panel de aliados', def: 'auto', op: [['auto', 'Automático (hueco libre según las posiciones)'], ['arriba-izq', 'Arriba a la izq.'], ['arriba-der', 'Arriba a la der.'], ['abajo-izq', 'Abajo a la izq.'], ['abajo-der', 'Abajo a la der.']], ayuda: 'Solo si el nivel tiene aliados' },
    { k: 'vidasPos', t: 'sel', e: 'Vidas (❤ × 3)', def: 'auto', op: [['auto', 'Junto a la vida'], ['arriba-izq', 'Arriba a la izq.'], ['arriba-der', 'Arriba a la der.'], ['abajo-izq', 'Abajo a la izq.'], ['abajo-der', 'Abajo a la der.']], ayuda: 'Solo con el sistema de vidas (Menús ▸ Partidas)' },
    { k: 'escala', t: 'rango', e: 'Tamaño', def: 1, min: 0.5, max: 2, paso: 0.05 },
    { k: 'margen', t: 'rango', e: 'Separación del borde', def: 3, min: 0, max: 10, paso: 0.5 },
    { grupo: 'Qué se muestra' },
    { k: 'vida', t: 'bool', e: 'Vida', def: true },
    { k: 'armadura', t: 'bool', e: 'Armadura / escudo', def: true },
    { k: 'municion', t: 'bool', e: 'Munición', def: true },
    { k: 'nombreArma', t: 'bool', e: 'Nombre del arma', def: true, si: (v) => v.municion },
    { k: 'iconoMunicion', t: 'bool', e: 'Icono de la munición', def: true, si: (v) => v.municion },
    { k: 'recogidos', t: 'bool', e: 'Avisos al recoger', def: true, ayuda: '"+25 Vida" y el destello de color' },
    { k: 'mira', t: 'sel', e: 'Mira', def: 'fps', op: [['fps', 'En 1ª persona'], ['siempre', 'Siempre'], ['tps', 'Solo en 3ª persona'],
      ['apuntar', 'Solo al apuntar'], ['nunca', 'Nunca']] },
    { k: 'avisoBajo', t: 'rango', e: 'Avisar con poca vida', def: 0.25, min: 0, max: 0.6, paso: 0.05,
      ayuda: 'Por debajo de esta parte de la vida (o del cargador) el número se pone rojo y parpadea. 0 = nunca' },
    { k: 'ocultarTras', t: 'num', e: 'Esconder tras (s)', def: 0, paso: 0.5, min: 0,
      ayuda: '0 = siempre a la vista. Con más, la vida y la munición aparecen al cambiar y se esconden solas (estilo Resident Evil)' },
    { grupo: 'Estilo' },
    { k: 'estiloVida', t: 'sel', e: 'Vida y armadura', def: 'ambos', op: [['ambos', 'Barra y número'], ['barra', 'Solo barra'], ['numero', 'Solo número']] },
    { k: 'iconos', t: 'bool', e: 'Iconos (♥ ⛨)', def: true },
    { k: 'fondo', t: 'bool', e: 'Fondo detrás', def: false },
    { k: 'colorFondo', t: 'color', e: 'Color del fondo', def: '#000000', si: (v) => v.fondo },
    { k: 'opacidadFondo', t: 'rango', e: 'Opacidad del fondo', def: 0.55, min: 0, max: 1, paso: 0.05, si: (v) => v.fondo },
    { k: 'sombra', t: 'bool', e: 'Sombra en el texto', def: true },
    { k: 'estiloMira', t: 'sel', e: 'Forma de la mira', def: 'punto', op: [['punto', '· Punto'], ['cruz', '+ Cruz'], ['abierta', '⁜ Cruz abierta'], ['circulo', '○ Círculo']],
      si: (v) => v.mira !== 'nunca' },
    { k: 'colorMira', t: 'color', e: 'Color de la mira', def: '#ffffff', si: (v) => v.mira !== 'nunca' },
    { k: 'tamMira', t: 'rango', e: 'Tamaño de la mira', def: 1, min: 0.5, max: 3, paso: 0.1, si: (v) => v.mira !== 'nunca' },
    { grupo: 'Brújula' },
    { k: 'brujula', t: 'sel', e: 'Brújula', def: 'no', op: [['no', 'Sin brújula'], ['tira', 'Tira arriba (N · E · S · O)'], ['circulo', 'Círculo en una esquina'], ['esfera', "🌐 Esfera 3D (King's Field)"]],
      ayuda: 'Para no perderse. Muestra los 📌 marcadores que pongas en el mapa' },
    { k: 'brujulaEsquina', t: 'sel', e: 'Dónde', def: 'arriba-der', si: (v) => v.brujula === 'circulo' || v.brujula === 'esfera',
      op: [['arriba-der', 'Arriba a la derecha'], ['arriba-izq', 'Arriba a la izquierda'], ['abajo-der', 'Abajo a la derecha'], ['abajo-izq', 'Abajo a la izquierda'], ['abajo-centro', 'Abajo al centro']] },
    { k: 'brujulaColor', t: 'color', e: 'Color de la esfera', def: '#4f74a8', si: (v) => v.brujula === 'esfera' },
    { k: 'brujulaCalidad', t: 'sel', e: 'Calidad', def: 'alta', si: (v) => v.brujula === 'esfera', op: [['alta', 'Alta (80 px, luz suave)'], ['media', 'Media (48 px)'], ['baja', 'Baja / PS1 (28 px, 3 tonos, pocas líneas)']],
      ayuda: 'Menos píxeles = más retro (y aún más barata)' },
    { k: 'brujulaInclina', t: 'bool', e: 'Se inclina al mirar arriba / abajo', def: true, si: (v) => v.brujula === 'esfera' },
    { k: 'brujulaTam', t: 'rango', e: 'Tamaño de la brújula', def: 1, min: 0.5, max: 2, paso: 0.05, si: (v) => v.brujula !== 'no' },
    { k: 'brujulaMarcadores', t: 'bool', e: 'Marcadores', def: true, si: (v) => v.brujula !== 'no' },
    { k: 'brujulaDistancia', t: 'bool', e: 'Distancia a los marcadores', def: true, si: (v) => v.brujula !== 'no' && v.brujulaMarcadores },
    { k: 'norte', t: 'num', e: 'Dónde está el norte (°)', def: 0, paso: 15, av: true, si: (v) => v.brujula !== 'no',
      ayuda: '0 = hacia el fondo de la vista superior (−Z). 90 = el norte queda hacia +X' },
  ];
  function hudPorDefecto() { return F.valoresPorDefecto(ESQUEMA_HUD); }
  // Plantillas: solo cambian lo que las distingue (el resto queda como esté)
  const PLANTILLAS_HUD = {
    clasico: { nombre: 'Clásico', colorMira: '#ffffff', posicion: 'esquinas', estiloVida: 'ambos', fondo: false, ocultarTras: 0, escala: 1, mira: 'fps', estiloMira: 'punto', iconos: true },
    quake: { nombre: 'Quake / Doom', colorMira: '#ffffff', posicion: 'barra', estiloVida: 'numero', fondo: true, colorFondo: '#3a2f25', opacidadFondo: 0.92, ocultarTras: 0, escala: 1.1, mira: 'fps', estiloMira: 'cruz', iconos: true, nombreArma: true, iconoMunicion: true, avisoBajo: 0.25 },
    centrado: { nombre: 'Centrado', colorMira: '#ffffff', posicion: 'centro', estiloVida: 'ambos', fondo: true, colorFondo: '#000000', opacidadFondo: 0.4, ocultarTras: 0, escala: 1, mira: 'siempre', estiloMira: 'abierta', iconos: true },
    halo: { nombre: 'Halo', posicion: 'arriba', brujulaEsquina: 'abajo-der', estiloVida: 'barra', fondo: false, ocultarTras: 0, escala: 1, mira: 'siempre', estiloMira: 'circulo', colorMira: '#7fd4ff', iconos: false },
    survival: { nombre: 'Survival', colorMira: '#ffffff', posicion: 'discreto', estiloVida: 'barra', fondo: true, colorFondo: '#000000', opacidadFondo: 0.5, ocultarTras: 3, escala: 0.85, mira: 'apuntar', estiloMira: 'punto', iconos: true },
    arcade: { nombre: 'Arcade', brujulaEsquina: 'abajo-izq', colorMira: '#ffffff', posicion: 'arcade', estiloVida: 'numero', fondo: false, ocultarTras: 0, escala: 1.4, mira: 'nunca', iconos: true },
    kingsfield: { nombre: "King's Field", posicion: 'esquinas', brujula: 'esfera', brujulaEsquina: 'abajo-centro', brujulaColor: '#4f74a8', brujulaTam: 1.1, estiloVida: 'barra', fondo: true, colorFondo: '#000000', opacidadFondo: 0.45, ocultarTras: 0, escala: 1, mira: 'nunca', iconos: false },
    minimo: { nombre: 'Mínimo', colorMira: '#ffffff', fondo: false, posicion: 'esquinas', estiloVida: 'numero', fondo: false, ocultarTras: 2, escala: 0.8, mira: 'fps', estiloMira: 'punto', iconos: false, nombreArma: false },
  };

  function proyectoNuevo() {
    const primera = escenaNueva('Nivel 1', true);
    const pa = paqueteArmas();
    return {
      formato: 'forja-juegos', version: F.VERSION, nombre: 'Mi juego',
      ajustes: F.valoresPorDefecto(ESQUEMA_RENDER),
      jugador: jugadorPorDefecto(),
      escenas: [primera],
      escenaInicial: primera.id,
      materiales: {},          // ajustes de materiales de modelos: { idAsset: { índice: cfg } }
      carpetasArchivos: carpetasPorDefecto(),
      menus: menusPorDefecto(),
      armas: pa.armas,
      municiones: pa.municiones,
      hud: hudPorDefecto(),
      criaturas: criaturasPorDefecto(),
      objetos: F.Inventario.objetosPorDefecto(),     // biblioteca de la mochila (Juego ▸ Objetos)
      recetas: F.Inventario.recetasPorDefecto(),
    };
  }

  function normalizarEntidad(e) {
    const base = entidadNueva(e.tipo || 'cubo');
    const ent = { ...base, ...e };
    ent.params = { ...base.params, ...(e.params || {}) };
    ent.material = { ...base.material, ...(e.material || {}) };
    if (ent.tipo === 'luz') ent.luz = { ...F.Luces.LUZ_BASE, ...(e.luz || {}) };
    if (ent.tipo === 'puerta') ent.puerta = { ...F.Mecanismos.PUERTA, ...(e.puerta || {}) };
    if (ent.tipo === 'plataforma') ent.plataforma = { ...F.Mecanismos.PLATAFORMA, ...(e.plataforma || {}) };
    if (ent.tipo === 'trampa') ent.trampa = { ...F.Mecanismos.TRAMPA, ...(e.trampa || {}) };
    if (ent.tipo === 'pedestal') {
      ent.pedestal = { ...F.util.copiar(F.Mecanismos.PEDESTAL), ...(e.pedestal || {}) };
      ent.pedestal.acciones = (ent.pedestal.acciones || []).map((a) => F.Mecanismos.accionNueva(a));
    }
    if (ent.tipo === 'condicion') {
      ent.condicion = { ...F.util.copiar(F.Mecanismos.CONDICION), ...(e.condicion || {}) };
      ent.condicion.acciones = (ent.condicion.acciones || []).map((a) => F.Mecanismos.accionNueva(a));
      ent.condicion.requisitos = (ent.condicion.requisitos || []).map((r) => F.Mecanismos.requisitoNuevo(r));
    }
    if (ent.tipo === 'disparador') {
      ent.disparador = { ...F.util.copiar(F.Mecanismos.DISPARADOR), ...(e.disparador || {}) };
      ent.disparador.acciones = (ent.disparador.acciones || []).map((a) => F.Mecanismos.accionNueva(a));
    }
    if (ent.tipo === 'palanca') {
      ent.palanca = { ...F.util.copiar(F.Mecanismos.PALANCA), ...(e.palanca || {}) };
      ent.palanca.acciones = (ent.palanca.acciones || []).map((a) => F.Mecanismos.accionNueva(a));
    }
    if (ent.tipo === 'recogible') ent.recogible = { ...F.Recogibles.BASE, ...(e.recogible || {}) };
    if (ent.tipo === 'enemigo') ent.enemigo = { ...F.Enemigos.BASE, ...(e.enemigo || {}) };
    if (ent.tipo === 'punto') ent.punto = { ...F.Enemigos.PUNTO, ...(e.punto || {}) };
    if (ent.tipo === 'camara') ent.camara = { ...F.Camaras.CAMARA, ...(e.camara || {}) };
    if (ent.tipo === 'rehen') ent.rehen = { ...F.Tactico.REHEN, ...(e.rehen || {}) };
    if (ent.tipo === 'bomba') ent.bomba = { ...F.Tactico.BOMBA, ...(e.bomba || {}) };
    if (ent.tipo === 'brecha') ent.brecha = { ...F.Tactico.BRECHA, ...(e.brecha || {}) };
    if (ent.tipo === 'npc') ent.npc = { ...F.util.copiar(F.Tactico.NPC), ...(e.npc || {}), nodos: ((e.npc && e.npc.nodos) || []).map((n) => ({ ...F.Tactico.nodoNuevo(n), opciones: (n.opciones || []).map((o) => ({ ...F.Tactico.opcionNueva(o), acciones: (o.acciones || []).map((a) => F.Mecanismos.accionNueva(a)) })) })) };
    if (ent.tipo === 'tienda') ent.tienda = { ...F.util.copiar(F.Tactico.TIENDA), ...(e.tienda || {}), articulos: ((e.tienda && e.tienda.articulos) || []).map((a) => F.Tactico.articuloNuevo(a)) };
    if (ent.tipo === 'sonido') ent.sonido = { ...F.Sonidos.SONIDO, ...(e.sonido || {}) };
    if (ent.tipo === 'particulas') ent.particulas = { ...F.Particulas.PARTICULAS, ...(e.particulas || {}) };
    if (ent.tipo === 'barrera') ent.barrera = { ...F.Campo.BARRERA, ...(e.barrera || {}) };
    if (ent.tipo === 'marcador') ent.marcador = { ...F.Brujula.MARCADOR, ...(e.marcador || {}) };
    if (ent.tipo === 'agua') ent.agua = { ...F.Agua.AGUA, ...(e.agua || {}) };
    if (ent.tipo === 'baul') ent.baul = { ...F.util.copiar(F.Inventario.BAUL), ...(e.baul || {}) };
    if (ent.tipo === 'guardado') ent.guardado = { ...F.Guardado.PUNTO, ...(e.guardado || {}) };
    if (ent.tipo === 'empujable') ent.empujable = { ...F.Empujables.EMPUJABLE, ...(e.empujable || {}) };
    if (ent.tipo === 'montable') ent.montable = { ...F.Montables.MONTABLE, ...(e.montable || {}) };
    if (ent.tipo === 'inicio') ent.inicio = { principal: true, ...(e.inicio || {}) };
    if (ent.tipo === 'salida') ent.salida = { ...F.Niveles.SALIDA, ...(e.salida || {}) };
    if (ent.tipo === 'aparecedor') {
      const a = e.aparecedor || {};
      ent.aparecedor = { ...F.util.copiar(F.Enemigos.APARECEDOR), ...a };
      // v0.13.0 escribía los nombres a mano: se pasan a criaturas de la biblioteca
      if (typeof a.enemigos === 'string') {
        if (!a.salen) ent.aparecedor.salen = F.Enemigos.textoACriaturas(a.enemigos);
        if (!a.oleadas && typeof a.lista === 'string') ent.aparecedor.oleadas = a.lista.split('\n').map(F.Enemigos.textoACriaturas).filter((o) => o.length);
        if (a.jefe && !String(a.jefe).startsWith('cr_')) ent.aparecedor.jefe = (F.Enemigos.textoACriaturas(a.jefe)[0] || {}).criatura || '';
        delete ent.aparecedor.enemigos;
        delete ent.aparecedor.lista;
      }
    }
    return ent;
  }

  /* ---------- Biblioteca de criaturas (proyecto.criaturas): enemigos y animales reutilizables ---------- */
  function criaturaNueva(extra = {}) {
    return { id: F.util.uid(), nombre: 'Criatura', enemigo: { ...F.Enemigos.BASE }, ...extra };
  }
  // de serie: una por preajuste del motor (ids fijos cr_<preajuste>)
  function criaturasPorDefecto() {
    return Object.entries(F.Enemigos.PRESETS).map(([k, pr]) => {
      const { nombre, ...v } = pr;
      return { id: 'cr_' + k, nombre, enemigo: { ...F.Enemigos.BASE, ...v } };
    });
  }
  // los enemigos vinculados copian la configuración de su criatura. Devuelve los que cambiaron
  function aplicarCriaturas(p, soloId) {
    const mapa = new Map((p.criaturas || []).map((c) => [c.id, c]));
    const cambiados = [];
    for (const s of p.escenas) for (const e of s.entidades) {
      if (e.tipo !== 'enemigo' || !e.criatura || (soloId && e.criatura !== soloId)) continue;
      const c = mapa.get(e.criatura);
      if (!c) { e.criatura = ''; continue; }
      // la patrulla es de cada enemigo (las rutas son de su escena), no de la criatura
      const ruta = (e.enemigo && e.enemigo.patrulla) || '';
      e.enemigo = { ...F.Enemigos.BASE, ...F.util.copiar(c.enemigo), patrulla: ruta };
      cambiados.push(e);
    }
    return cambiados;
  }

  // Completa proyectos de versiones anteriores (v0.1/v0.2 tenían una sola lista de entidades)
  function normalizarProyecto(p) {
    const base = proyectoNuevo();
    const n = { ...base, ...p };
    n.ajustes = { ...base.ajustes, ...(p.ajustes || {}) };
    n.materiales = p.materiales || {};
    n.carpetasArchivos = Array.isArray(p.carpetasArchivos) ? p.carpetasArchivos : carpetasPorDefecto();
    n.menus = normalizarMenus(p.menus);
    if (Array.isArray(p.armas)) {
      // 🪄 proyectos de antes: los hechizos (munición de maná ✦) pasan a ser varitas (antes salían como lanzacohetes de cajas)
      const muns = Array.isArray(p.municiones) ? p.municiones : [];
      const esMana = (id) => muns.some((m) => m.id === id && (/man[aá]/i.test(m.nombre || '') || m.icono === '✦'));
      n.armas = p.armas.map((a) => ({ ...armaNueva(), ...(a.magia === undefined && a.tipo !== 'cuerpo' && esMana(a.municion) ? { magia: 'varita' } : {}), ...a }));
      // proyectos de antes: sus armas siguen con munición propia; los tipos de ejemplo quedan para usarlos
      n.municiones = Array.isArray(p.municiones) ? p.municiones.map((m) => ({ ...municionNueva(), ...m })) : base.municiones;
    } else {
      n.armas = base.armas;
      n.municiones = base.municiones;
    }
    n.hud = { ...hudPorDefecto(), ...(p.hud || {}) };
    n.criaturas = Array.isArray(p.criaturas)
      ? p.criaturas.map((c) => ({ ...criaturaNueva(), ...c, enemigo: { ...F.Enemigos.BASE, ...(c.enemigo || {}) } }))
      : criaturasPorDefecto();
    n.objetos = Array.isArray(p.objetos) ? p.objetos.map((o) => ({ ...F.Inventario.OBJETO, id: F.util.uid(), ...o })) : F.Inventario.objetosPorDefecto();
    n.recetas = Array.isArray(p.recetas) ? p.recetas : F.Inventario.recetasPorDefecto();

    n.jugador = { modulos: {} };
    const guardados = (p.jugador && p.jugador.modulos) || {};
    for (const [nombre, def] of Object.entries(base.jugador.modulos)) {
      n.jugador.modulos[nombre] = { ...def, ...(guardados[nombre] || {}) };
    }
    // ⚔ Combate: los valores de la primera versión eran demasiado suaves (y el empujón era en m/s) → los del estilo
    { const cb = n.jugador.modulos.combate, M = F.modulos && F.modulos.combate;
      if (cb && M && !cb.v2) { if (M.ESTILOS[cb.estilo]) Object.assign(cb, M.ESTILOS[cb.estilo]); else if (cb.empujonGolpe > 2) cb.empujonGolpe = 0.8; cb.v2 = true; } }

    // v0.16: la figura del motor pasó a muñeco de pruebas; si nunca cambiaste sus colores, toma los nuevos
    // v0.18: el aire bajo el agua viene encendido (en la 0.17 venía apagado de serie)
    const na = n.jugador.modulos.nadar;
    if (na && /^0\.17\./.test(String(p.version || '')) && na.aire === false) na.aire = true;
    const mo = n.jugador.modulos.modelo;
    if (mo && mo.colorRopa === '#3b6ad1' && mo.colorPantalon === '#3a3f48' && mo.colorPiel === '#d8a27a') {
      Object.assign(mo, { colorRopa: '#e8b923', colorPantalon: '#d4a51c', colorPiel: '#e8b923' });
    }

    let escenas = p.escenas;
    if (!escenas && p.entidades) {
      const ambienteViejo = {};
      for (const d of ESQUEMA_AMBIENTE) if (d.k && p.ajustes && p.ajustes[d.k] !== undefined) ambienteViejo[d.k] = p.ajustes[d.k];
      escenas = [{ id: F.util.uid(), nombre: 'Nivel 1', ambiente: ambienteViejo, entidades: p.entidades }];
    }
    if (!escenas || !escenas.length) escenas = base.escenas;
    n.escenas = escenas.map((s) => ({
      id: s.id || F.util.uid(),
      nombre: s.nombre || 'Escena',
      ambiente: { ...F.valoresPorDefecto(ESQUEMA_AMBIENTE), ...(s.ambiente || {}) },
      nivel: { ...F.Niveles.NIVEL, ...(s.nivel || {}) },
      // 🎬 cinemáticas del nivel (motor/cinematicas.js)
      ...((s.cinematicas || []).length ? { cinematicas: s.cinematicas.map((c) => (F.Cine ? { ...F.util.copiar(F.Cine.CINE), ...c,
        pasos: (c.pasos || []).map((p) => ({ cuando: 'despues', ...p })) } : c)) } : {}),
      ...(s.capitulo ? { capitulo: String(s.capitulo) } : {}),   // 📚 capítulo (episodio) del nivel
      ...(s.mision ? { mision: { ...F.Misiones.MISION, ...s.mision, objetivos: (s.mision.objetivos || []).map((o) => F.Misiones.objetivoNuevo(o)) } } : {}),   // ⭐ (sin esto se perdía al guardar)
      entidades: (s.entidades || []).map(normalizarEntidad),
    }));
    if (!n.escenas.some((s) => s.id === n.escenaInicial)) n.escenaInicial = n.escenas[0].id;
    delete n.entidades;
    aplicarCriaturas(n);
    return n;
  }

  /* ---------- Jerarquía ---------- */
  // Hijos directos de una entidad ('' = raíz), en el orden de la lista
  function hijos(entidades, padreId) {
    return entidades.filter((e) => (e.padre || '') === (padreId || ''));
  }

  // La entidad y todos sus descendientes
  function subarbol(entidades, id) {
    const ids = new Set([id]);
    let creciendo = true;
    while (creciendo) {
      creciendo = false;
      for (const e of entidades) if (e.padre && ids.has(e.padre) && !ids.has(e.id)) { ids.add(e.id); creciendo = true; }
    }
    return entidades.filter((e) => ids.has(e.id));
  }

  /* ---------- Geometría ---------- */
  function uvPlanar(geo, escala) {
    const pos = geo.attributes.position, nor = geo.attributes.normal;
    const uv = new Float32Array(pos.count * 2);
    for (let i = 0; i < pos.count; i++) {
      const nx = Math.abs(nor.getX(i)), ny = Math.abs(nor.getY(i)), nz = Math.abs(nor.getZ(i));
      const x = pos.getX(i), y = pos.getY(i), z = pos.getZ(i);
      let u, v;
      if (ny >= nx && ny >= nz) { u = x; v = z; }
      else if (nx >= nz) { u = z; v = y; }
      else { u = x; v = y; }
      uv[i * 2] = u * escala;
      uv[i * 2 + 1] = v * escala;
    }
    geo.setAttribute('uv', new T.BufferAttribute(uv, 2));
    return geo;
  }

  function geomRampa(w, h, l) {
    const A = [-w / 2, 0, 0], B = [w / 2, 0, 0], C = [w / 2, 0, l], D = [-w / 2, 0, l];
    const E = [-w / 2, h, l], Fv = [w / 2, h, l];
    const tris = [A, B, C, A, C, D, D, C, Fv, D, Fv, E, A, E, Fv, A, Fv, B, A, D, E, B, Fv, C];
    const geo = new T.BufferGeometry();
    geo.setAttribute('position', new T.Float32BufferAttribute(tris.flat(), 3));
    geo.computeVertexNormals();
    geo.translate(0, 0, -l / 2);
    return geo;
  }

  function geomEscalera(n, ancho, alto, fondo) {
    n = Math.max(1, Math.round(n));
    const partes = [];
    for (let i = 0; i < n; i++) {
      const h = (i + 1) * alto;
      const g = new T.BoxGeometry(ancho, h, fondo);
      g.translate(0, h / 2, i * fondo + fondo / 2 - (n * fondo) / 2);
      partes.push(g);
    }
    return T.mergeGeometries(partes);
  }

  function geomPrimitiva(ent) {
    const p = ent.params || {};
    let g;
    // 🌊 con material que se mueve (olas, viento, ondear) va más partido (cada ~0,5 m, máx. 64) para que se doble bien
    const cada = F.Render.movVertices(ent.material) ? 0.5 : 2, seg = (l) => Math.min(64, Math.max(1, Math.ceil(l / cada)));
    if (ent.tipo === 'cubo') {
      // Subdividido cada ~2 m: la textura afín (y la niebla por vértice) se ven como en PS1 sin exagerar
      g = new T.BoxGeometry(p.ancho, p.alto, p.largo, seg(p.ancho), seg(p.alto), seg(p.largo));
      g.translate(0, p.alto / 2, 0);
    } else if (ent.tipo === 'suelo') {
      g = new T.BoxGeometry(p.ancho, 0.2, p.largo, seg(p.ancho), 1, seg(p.largo));
      g.translate(0, -0.1, 0);
    } else if (ent.tipo === 'rampa') {
      g = geomRampa(p.ancho, p.alto, p.largo);
    } else if (ent.tipo === 'escalera') {
      g = geomEscalera(p.peldanos, p.ancho, p.altoPeldano, p.fondo);
    } else if (ent.tipo === 'barril') {
      // 🛢 barril: cilindro de 10 lados (con aros por la textura de cuadros)
      g = new T.CylinderGeometry(Math.max(0.05, p.radio || 0.35), Math.max(0.05, p.radio || 0.35), Math.max(0.1, p.alto || 1), 10, 2);
      g.translate(0, Math.max(0.1, p.alto || 1) / 2, 0);
    } else if (ent.tipo === 'escala') {
      // 🪜 escalera de mano: dos largueros y peldaños cada 30 cm; se sube por su frente (+Z). No choca: apóyala en una pared
      const alto = Math.max(0.5, p.alto || 3), an = Math.max(0.2, p.ancho || 0.6), partes = [];
      if (ent.forma === 'cuerda') {
        // 🪢 cuerda: cuelga de arriba, con un nudo cada 50 cm y un lazo arriba (se agarra desde cualquier lado)
        const c = new T.CylinderGeometry(0.035, 0.035, alto, 6, Math.max(1, Math.round(alto / 0.5))); c.translate(0, alto / 2, 0); partes.push(c);
        for (let y = 0.35; y < alto - 0.1; y += 0.5) { const n = new T.SphereGeometry(0.06, 6, 4); n.translate(0, y, 0); partes.push(n); }
        const lazo = new T.TorusGeometry(0.12, 0.03, 4, 10); lazo.translate(0, alto + 0.1, 0); partes.push(lazo);
        g = T.mergeGeometries(partes.map((x) => x.index ? x.toNonIndexed() : x));
      } else {
      for (const sx of [-1, 1]) { const b = new T.BoxGeometry(0.06, alto, 0.06); b.translate(sx * (an / 2 - 0.03), alto / 2, 0.06); partes.push(b); }
      for (let y = 0.3; y < alto - 0.05; y += 0.3) { const b = new T.BoxGeometry(an - 0.06, 0.04, 0.04); b.translate(0, y, 0.06); partes.push(b); }
      g = T.mergeGeometries(partes);
      }
    } else {
      g = new T.BoxGeometry(1, 1, 1);
    }
    // UV en metros: "mosaico" = cuántos metros ocupa una repetición de la textura
    uvPlanar(g, 1 / Math.max(0.05, ent.mosaico || 2));
    return g;
  }

  function materialPrimitiva(ent) {
    const conTextura = ent.textura && F.Assets.textura(ent.textura, 'color');
    const mat = new T.MeshLambertMaterial({ color: ent.color, map: conTextura || F.Render.texCuadros });
    const normal = ent.normal && F.Assets.textura(ent.normal, 'normal');
    if (normal) {
      mat.normalMap = normal;
      mat.normalScale.set(ent.fuerzaNormal, ent.fuerzaNormal);
    }
    F.Render.hacerRetro(mat);
    // 🚩 ondear: el lado fijo es el borde izquierdo de la pieza (sus medidas)
    const pp = ent.params || {};
    F.Render.aplicarConfig(mat, { ondearBorde: -(pp.ancho || 1) / 2, ...(ent.material || {}), tinte: ent.color });
    return mat;
  }

  // verde = inicio principal · amarillo = punto de llegada desde otro nivel
  function marcadorInicio(cuerpo, principal = true, proyecto = null) {
    const r = cuerpo.radio ?? 0.35, h = cuerpo.altura ?? 1.8, ojos = cuerpo.alturaOjos ?? 1.6;
    const color = principal ? 0x4fd18b : 0xe8c547;
    const grupo = new T.Group();
    const mat = new T.MeshBasicMaterial({ color, wireframe: true, fog: false });
    const capsula = new T.Mesh(new T.CapsuleGeometry(r, Math.max(0.01, h - r * 2), 4, 8), mat);
    capsula.position.y = h / 2;
    const flecha = new T.Mesh(new T.ConeGeometry(0.18, 0.5, 8), new T.MeshBasicMaterial({ color, fog: false }));
    flecha.rotation.x = -Math.PI / 2;
    flecha.position.set(0, ojos, -0.55);
    grupo.add(capsula, flecha);
    grupo.userData.esMarcador = true;
    // 🧍 vista previa del personaje del jugador (módulo Modelo ▸ "Verlo en el editor"): quieto, mirando hacia la flecha
    try { const fig = principal && proyecto && figuraJugador(proyecto, h); if (fig) { grupo.add(fig); mat.opacity = 0.35; mat.transparent = true; } } catch (e) { console.warn('[inicio] vista del jugador', e); }
    return grupo;
  }
  function figuraJugador(proyecto, h) {
    const md = proyecto.jugador && proyecto.jugador.modulos;
    const p = md && md.modelo;
    if (!p || p.activo === false || p.verEnEditor === false) return null;
    const asset = p.modelo && F.Assets.mapa.get(p.modelo);
    let obj;
    if (asset && asset.gltf) {
      obj = T.SkeletonUtils.clone(asset.gltf.scene);
      // primer cuadro de "idle" si lo trae (si no, su reposo: brazos colgando)
      const clips = asset.gltf.animations || [];
      const idle = clips.find((c) => /(^|\|)idle$/i.test(c.name)) || null;
      if (idle) { const mx = new T.AnimationMixer(obj); mx.clipAction(idle).play(); mx.update(0.01); }
    } else if (!p.modelo && F.modulos && F.modulos.modelo) {
      obj = F.modulos.modelo._figura({ cuerpo: { altura: h } }, { ...F.valoresPorDefecto(F.modulos.modelo.props), ...p });
    } else return null;
    obj.scale.setScalar(p.escala || 1);
    obj.rotation.y = Math.PI + (p.girar180 ? Math.PI : 0);   // los modelos miran a +Z; el jugador, hacia la flecha (−Z)
    obj.traverse((o) => { if (o.isMesh) { o.frustumCulled = false; o.castShadow = false; } });
    obj.userData.vistaJugador = true;
    return obj;
  }

  // Ayuda del editor para una luz: bombilla de su color + círculo de su alcance (no se ven al jugar)
  function marcadorLuz(ent) {
    const l = { ...F.Luces.LUZ_BASE, ...(ent.luz || {}) };
    const grupo = new T.Group();
    const bombilla = new T.Mesh(new T.OctahedronGeometry(0.18), new T.MeshBasicMaterial({ color: l.color, fog: false }));
    bombilla.userData.ayudaEditor = true;
    const puntos = [];
    for (let i = 0; i <= 48; i++) { const a = (i / 48) * Math.PI * 2; puntos.push(new T.Vector3(Math.cos(a) * l.alcance, 0, Math.sin(a) * l.alcance)); }
    const circulo = new T.Line(new T.BufferGeometry().setFromPoints(puntos),
      new T.LineBasicMaterial({ color: l.color, transparent: true, opacity: 0.35, fog: false }));
    circulo.userData.ayudaEditor = true;
    grupo.add(bombilla, circulo);
    return grupo;
  }

  function aplicarTransform(obj, ent) {
    obj.position.fromArray(ent.pos);
    obj.rotation.set(ent.rot[0] * DEG, ent.rot[1] * DEG, ent.rot[2] * DEG);
    obj.scale.fromArray(ent.esc);
  }

  // Crea el Object3D de una entidad (no lo añade a la escena ni a su padre)
  function crearObjeto(ent, proyecto) {
    let obj;
    if (ent.tipo === 'modelo') {
      const a = F.Assets.mapa.get(ent.asset);
      if (a && a.gltf) {
        obj = T.SkeletonUtils.clone(a.gltf.scene);
        obj.userData.animaciones = a.gltf.animations || [];
        // nivel del Entorno de Niveles con sus marcadores ya convertidos en entidades: el modelo no los dibuja
        // (las hojas de puerta y las plataformas del GLB son ahora puertas y elevadores de verdad)
        if (ent.marcadores === 'convertidos') {
          const quitar = [];
          obj.traverse((o) => { if (o.name === 'marcadores' && o.children.some((c) => c.userData && c.userData.forja)) quitar.push(o); });
          for (const o of quitar) o.parent.remove(o);
        }
        if (F.Agua) F.Agua.marcarModelo(obj, ent);   // lagos, ríos y lava del modelo (no chocan; se nada dentro)
      } else {
        const caja = new T.Mesh(new T.BoxGeometry(1, 1, 1), new T.MeshBasicMaterial({ color: 0xff3355, wireframe: true }));
        caja.position.y = 0.5;
        caja.userData.ayudaEditor = true;
        obj = new T.Group();
        obj.add(caja);
      }
    } else if (ent.tipo === 'inicio') {
      obj = marcadorInicio((proyecto && proyecto.jugador.modulos.cuerpo) || {}, !ent.inicio || ent.inicio.principal !== false, proyecto);
    } else if (ent.tipo === 'carpeta') {
      // Como un Node3D vacío de Godot: solo agrupa y mueve a sus hijos
      obj = new T.Group();
      const ejes = new T.AxesHelper(0.6);
      ejes.userData.ayudaEditor = true;
      obj.add(ejes);
    } else if (ent.tipo === 'luz') {
      obj = marcadorLuz(ent);
    } else if (ent.tipo === 'recogible') {
      obj = F.Recogibles.figura(ent, proyecto);
    } else if (ent.tipo === 'enemigo') {
      obj = F.Enemigos.figura(ent);
    } else if (ent.tipo === 'punto') {
      obj = F.Enemigos.figuraPunto(ent);
    } else if (ent.tipo === 'camara') {
      obj = F.Camaras.figura(ent);
    } else if (ent.tipo === 'rehen') {
      obj = F.Tactico.figuraRehen(ent);
    } else if (ent.tipo === 'bomba') {
      obj = F.Tactico.figuraBomba(ent);
    } else if (ent.tipo === 'brecha') {
      obj = F.Tactico.figuraBrecha(ent);
    } else if (ent.tipo === 'tienda') {
      obj = F.Tactico.figuraTienda(ent);
    } else if (ent.tipo === 'npc') {
      obj = F.Tactico.figuraNpc(ent);
    } else if (ent.tipo === 'sonido') {
      obj = F.Sonidos.figura(ent);
    } else if (ent.tipo === 'particulas') {
      obj = F.Particulas.figura(ent);
    } else if (ent.tipo === 'barrera') {
      obj = F.Campo.figuraBarrera(ent);
    } else if (ent.tipo === 'aparecedor') {
      obj = F.Enemigos.figuraAparecedor(ent);
    } else if (ent.tipo === 'marcador') {
      obj = F.Brujula.figura(ent);
    } else if (ent.tipo === 'agua') {
      obj = F.Agua.figura(ent);
    } else if (ent.tipo === 'baul') {
      obj = F.Inventario.figuraBaul(ent);
    } else if (ent.tipo === 'guardado') {
      obj = F.Guardado.figura(ent);
    } else if (ent.tipo === 'empujable') {
      obj = F.Empujables.figura(ent);
    } else if (ent.tipo === 'montable') {
      obj = F.Montables.figura(ent);
    } else if (ent.tipo === 'salida') {
      obj = F.Niveles.figura(ent);
    } else if (ent.tipo === 'puerta') {
      obj = F.Mecanismos.figuraPuerta(ent);
    } else if (ent.tipo === 'palanca') {
      obj = F.Mecanismos.figuraPalanca(ent);
    } else if (ent.tipo === 'disparador') {
      obj = F.Mecanismos.figuraDisparador(ent);
    } else if (ent.tipo === 'pedestal') {
      obj = F.Mecanismos.figuraPedestal(ent, proyecto);
    } else if (ent.tipo === 'plataforma') {
      obj = F.Mecanismos.figuraPlataforma(ent);
    } else if (ent.tipo === 'trampa') {
      obj = F.Mecanismos.figuraTrampa(ent);
    } else if (ent.tipo === 'condicion') {
      obj = F.Mecanismos.figuraCondicion(ent);
    } else {
      obj = new T.Mesh(geomPrimitiva(ent), materialPrimitiva(ent));
      obj.renderOrder = (ent.material && ent.material.prioridad) || 0;
      obj.userData.propia = true;
    }
    obj.userData.entId = ent.id;
    aplicarTransform(obj, ent);
    if (!['inicio', 'carpeta', 'luz', 'salida', 'puerta', 'palanca', 'disparador', 'pedestal', 'condicion', 'plataforma', 'trampa'].includes(ent.tipo)) F.Luces.aplicarSombras(obj, ent.sombra !== false);
    return obj;
  }

  // Crea todos los objetos de una escena y arma la jerarquía. Devuelve Map id → Object3D
  function construirEscena(escena, raiz, proyecto) {
    const objetos = new Map();
    for (const ent of escena.entidades) objetos.set(ent.id, crearObjeto(ent, proyecto));
    for (const ent of escena.entidades) {
      const padre = ent.padre && objetos.get(ent.padre);
      (padre || raiz).add(objetos.get(ent.id));
    }
    return objetos;
  }

  function liberarObjeto(obj) {
    if (obj.userData.propia) {
      obj.geometry.dispose();
      obj.material.dispose();
    }
  }

  /* Animaciones por nombre. Acepta los nombres de la Forja de personajes (hit, death, walk_c, dash),
     los de Godot/Mixamo con prefijo ("Armature|Walk") y el sufijo -loop. Si falta uno, usa su pareja. */
  const ALIAS_ANIM = {
    hurt: ['hit', 'damage', 'hurt'], hit: ['hurt', 'damage'],
    die: ['death', 'dead', 'die'], death: ['die', 'dead'],
    crouch_walk: ['walk_c', 'crouchwalk', 'crouch_walk'], walk_c: ['crouch_walk'],
    roll: ['dash', 'dodge', 'roll'], dodge: ['dash', 'roll', 'dodge'],
    attack: ['attack_melee', 'slash1', 'stab', 'attack'],
    fly: ['fly', 'walk'],
    swim: ['swim', 'swimming', 'nadar', 'swim_idle'],
    hang: ['hang', 'ledge_hang'],
  };
  // las que se hacen una vez (no en ciclo) y se quedan en el último cuadro
  const UNA_VEZ = /^(jump|hit|hurt|damage|death|die|dead|attack.*|slash\d*|stab\d*|spear\d*|axe\d*|kick\d*|dash|roll|dodge|recoil|reload|double_jump|jump2|flip|ledge_climb|climb_up|shoot_.*|upper|sweep|spin|plunge|great)$/;
  function mapaAcciones(mixer, clips) {
    const acc = {};
    for (const c of clips) {
      const base = c.name.toLowerCase().replace(/^.*\|/, '').replace(/-loop$/, '').trim();
      if (!acc[base]) acc[base] = mixer.clipAction(c);
    }
    for (const [nombre, a] of Object.entries(acc)) {
      if (UNA_VEZ.test(nombre)) { a.setLoop(T.LoopOnce, 1); a.clampWhenFinished = true; }
    }
    for (const [nombre, otros] of Object.entries(ALIAS_ANIM)) {
      if (acc[nombre]) continue;
      const o = otros.find((x) => acc[x]);
      if (o) acc[nombre] = acc[o];
    }
    return acc;
  }

  F.Escena = {
    ESQUEMA_RENDER, ESQUEMA_AMBIENTE, estiloCuerpo, PARAMS_PRIMITIVA, COLOR_PRIMITIVA, ICONO, NOMBRE_TIPO, SIN_COLISION,
    menusPorDefecto, normalizarMenus, ESQUEMA_ARMA, armaNueva, armasPorDefecto, paqueteArmas,
    ESQUEMA_MUNICION, municionNueva, TIPOS_DANO, ESQUEMA_HUD, PLANTILLAS_HUD, hudPorDefecto,
    criaturaNueva, criaturasPorDefecto, aplicarCriaturas,
    entidadNueva, escenaNueva, proyectoNuevo, carpetasPorDefecto, rolDeAsset, normalizarProyecto, jugadorPorDefecto, hijos, subarbol,
    crearObjeto, construirEscena, liberarObjeto, aplicarTransform, mapaAcciones, geomPrimitiva,
  };
})(window.FORJA);
