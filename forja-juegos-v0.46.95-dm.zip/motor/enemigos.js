/* =========================================================
   FORJA · ENEMIGOS
   Entidad 'enemigo' de la escena (ent.enemigo = config). Un solo GESTOR por partida (lo crea el Juego, así
   nunca se queda vacío) que reparte el trabajo:
     - PENSAR (decidir) ~8 veces por segundo cerca, 2 lejos, nada si duerme; cada uno con su desfase.
     - VER: un rayo por el BVH solo al pensar y solo si el jugador está en alcance y cono.
       Persiguiendo también se comprueba: si te pierde va a tu última posición conocida y luego busca.
     - OÍR: sin rayos. Pasos según caminas / corres / agachado, y disparos (evento 'disparo').
       Oír nunca bloquea la vista (en el framework de Godot sí lo hacía).
     - MOVER: cada cuadro, cápsula del motor contra el BVH; separación entre vecinos.
     - ANIMAR: cerca cada cuadro; lejos cada 3; fuera de cámara, nada.
   Ataques: cuerpo a cuerpo, disparo, proyectil, embestida, salto y picado (volador), siempre con
   anticipación (aviso) y enfriamiento que se respeta siempre.
   El volador mantiene su altura SOBRE EL SUELO (rayo abajo 2 veces por segundo) con un muelle, no la del jugador;
   no atraviesa techos y al morir cae.
   Para las armas cada enemigo es un "objetivo" con rayo y distancia propios (cápsula matemática):
   no se recorren sus mallas, así 30 enemigos con esqueleto no cuestan más al disparar.
   ========================================================= */
(function (F) {
  'use strict';
  const T = THREE;
  const clamp = (v, a, b) => (v < a ? a : v > b ? b : v);
  const DEG = Math.PI / 180;

  const RESISTENCIAS = ['normal', 'perforante', 'explosivo', 'fuego', 'electrico', 'magico', 'veneno', 'hielo'];

  const BASE = {
    tipo: 'terrestre',        // 'terrestre' | 'volador' | 'fijo' | 'acuatico' (solo vive dentro del 💧 agua)
    enAgua: 'nadar',          // terrestres al llegar al agua: 'nadar' (más lento) | 'orilla' (no entra) | 'fondo' (camina por el fondo)
    saltaFuera: false,        // acuáticos: salta fuera del agua para morderte en la orilla
    alcanceSalto: 6,
    ejecutable: true,         // 🗡 se le puede ejecutar por la espalda sin que se entere (módulo Sigilo del jugador)
    // comportamiento
    actitud: 'agresivo',      // 'pacifico' (huye) | 'neutral' (se defiende) | 'agresivo' (te caza) | 'depredador' (caza animales) | 'aliado' (tu equipo: motor/aliados.js)
    fuegoAmigo: false,        // aliado: tus balas le hacen daño
    seguirAlEmpezar: true,    // aliado: empieza siguiéndote (si no, esperando)
    etiqueta: '',             // su especie o grupo: avisa a los de su misma etiqueta; los depredadores cazan por etiqueta
    caza: '',                 // etiquetas que caza, separadas por comas ("presa, ganado"); "jugador" también vale
    avisar: 8,                // radio (m) al que avisa a los suyos al verte o al recibir daño (0 = a nadie)
    huirConVida: 0,           // 0..1: huye cuando le queda esta parte de la vida (0 = nunca)
    patrulla: '',             // nombre de una ruta de puntos (entidad 'punto'): la recorre en vez de deambular
    jefe: false, nombreJefe: '',
    soloMolde: false,         // no sale en la escena: solo lo copian los aparecedores
    forma: 'humano',          // figura del motor sin modelo: 'humano' | 'animal'
    vida: 60,
    velocidad: 2,             // caminando (patrulla, buscar)
    velCorrer: 4.2,           // persiguiendo
    giro: 7,                  // qué tan rápido gira (rad/s)
    radio: 0.4,
    altura: 1.8,
    // percibir
    vision: 14, angulo: 120, oidoCaminar: 5, oidoCorrer: 13, oidoDisparo: 28, memoria: 4, reaccion: 0.35, veLinterna: true,
    // sin verte
    inactivo: 'deambular',    // 'quieto' | 'deambular'
    radioDeambular: 5,
    // atacar
    ataque: 'cuerpo',         // 'cuerpo' | 'disparo' | 'proyectil' | 'embestida' | 'salto' | 'picado'
    dano: 12, alcance: 1.7, distanciaIdeal: 9, anticipacion: 0.45, enfriamiento: 1.3, empuje: 4,
    dispersion: 3, velProyectil: 14, colorProyectil: '#ff5a3a', tipoDano: 'normal',
    // recibir
    aguante: 0,               // daño para aturdirlo (0 = cualquier golpe)
    aturdir: 0.3,
    res_normal: 1, res_perforante: 1, res_explosivo: 1, res_fuego: 1, res_electrico: 1, res_magico: 1, res_veneno: 1,
    // táctica (élite de Halo): escudo que se recarga, esquiva al verse apuntado, se cubre al perder el escudo, se mueve de lado
    escudo: 0,                // puntos de escudo (0 = sin escudo): absorbe el daño antes que la vida (destello azul)
    escudoEspera: 3,          // s sin recibir daño hasta que empieza a recargar
    escudoRecarga: 30,        // puntos por segundo
    esquiva: 0,               // 0..1: qué tan seguido esquiva de lado cuando le apuntas o le das
    esquivaCada: 1.6,         // s entre esquivas
    cubrirse: false,          // al romperse el escudo (o con poca vida si no tiene) busca dónde no lo veas y espera
    lateral: 0,               // m/s de paso lateral mientras dispara (0 = quieto)
    pisable: false,           // muere (o se daña) si le caes encima, estilo Mario
    danoPisar: 999,
    // volador
    alturaVuelo: 3, flotar: 0.25,
    escalaVel: false, escalaFuerza: false,
    efecto: 'auto', efectoSeg: 0, efectoProb: 1,   // estado que deja su ataque (motor/estados.js) según su tipo de daño   // 📏 al escalarlo en el editor: ¿también cambia velocidad / vida y daño?
    // al morir
    suelta: '', probSoltar: 1, suelta2: '', probSoltar2: 0.5, cantidad2: 1, suelta3: '', probSoltar3: 0.25, cantidad3: 1, desaparecer: 4,
    // aspecto y sonido
    modelo: '', escalaModelo: 1, color: '#6f8a4a',
    sonidoAlerta: '', sonidoAtaque: '', sonidoDolor: '', sonidoMuerte: '',
  };

  const PRESETS = {
    zombi: { nombre: 'Zombi', tipo: 'terrestre', vida: 90, velocidad: 0.9, velCorrer: 1.9, giro: 3, vision: 12, angulo: 140, reaccion: 0.8,
      ataque: 'cuerpo', dano: 18, alcance: 1.5, anticipacion: 0.7, enfriamiento: 1.6, aguante: 25, res_fuego: 2, res_normal: 0.8,
      color: '#6f8a4a', suelta: 'balas', probSoltar: 0.4, enAgua: 'fondo' },
    demonio: { nombre: 'Demonio', tipo: 'terrestre', vida: 60, velocidad: 2.5, velCorrer: 6.5, giro: 9, vision: 22, angulo: 160,
      ataque: 'embestida', dano: 20, alcance: 7, anticipacion: 0.45, enfriamiento: 2, empuje: 8, color: '#a8402e', res_fuego: 0.3, enAgua: 'orilla' },
    agente: { nombre: 'Agente (aliado)', tipo: 'terrestre', actitud: 'aliado', etiqueta: 'aliado', vida: 100, velocidad: 2.2, velCorrer: 4.5, giro: 9, vision: 24, angulo: 160,
      ataque: 'disparo', dano: 10, alcance: 22, distanciaIdeal: 8, anticipacion: 0.3, enfriamiento: 0.7, dispersion: 3, reaccion: 0.3, color: '#2f4a7a', avisar: 0, enAgua: 'orilla' },
    soldado: { nombre: 'Soldado', tipo: 'terrestre', vida: 70, velocidad: 1.8, velCorrer: 3.6, giro: 7, vision: 26, angulo: 110,
      ataque: 'disparo', dano: 8, alcance: 24, distanciaIdeal: 10, anticipacion: 0.35, enfriamiento: 0.9, dispersion: 4,
      color: '#4f5f6f', suelta: 'balas', probSoltar: 0.7, res_perforante: 1.3, enAgua: 'orilla' },
    elite: { nombre: 'Élite', tipo: 'terrestre', vida: 70, velocidad: 2.2, velCorrer: 4.8, giro: 9, vision: 28, angulo: 140, reaccion: 0.25,
      ataque: 'proyectil', dano: 10, alcance: 26, distanciaIdeal: 11, anticipacion: 0.25, enfriamiento: 0.7, velProyectil: 22, colorProyectil: '#6fd2ff',
      escudo: 60, escudoEspera: 3, escudoRecarga: 30, esquiva: 0.6, esquivaCada: 1.4, cubrirse: true, lateral: 1.8, aguante: 999, avisar: 20,
      color: '#5a4a9a', suelta: 'balas', probSoltar: 0.6, enAgua: 'orilla', memoria: 6 },
    torreta: { nombre: 'Torreta', tipo: 'fijo', vida: 120, giro: 2.5, vision: 30, angulo: 360, ataque: 'proyectil', dano: 15, alcance: 30,
      anticipacion: 0.6, enfriamiento: 1.4, velProyectil: 16, color: '#8a8a7a', res_normal: 0.5, res_electrico: 2, res_explosivo: 1.5, aguante: 999 },
    saltarin: { nombre: 'Bicho saltarín', tipo: 'terrestre', vida: 30, velocidad: 2.2, velCorrer: 4, giro: 10, radio: 0.35, altura: 0.9,
      ataque: 'salto', dano: 12, alcance: 7, anticipacion: 0.35, enfriamiento: 1.4, color: '#c9a23a', pisable: true },
    murcielago: { nombre: 'Murciélago', tipo: 'volador', vida: 25, velocidad: 3, velCorrer: 6, giro: 10, radio: 0.3, altura: 0.6, vision: 18, angulo: 220,
      ataque: 'picado', dano: 10, alcance: 9, anticipacion: 0.4, enfriamiento: 1.6, alturaVuelo: 3.2, flotar: 0.35, color: '#4a3a5a', desaparecer: 2 },
    gargola: { nombre: 'Gárgola', tipo: 'volador', vida: 80, velocidad: 2, velCorrer: 3.5, giro: 6, radio: 0.5, altura: 1.2, vision: 26, angulo: 200,
      ataque: 'proyectil', dano: 14, alcance: 26, distanciaIdeal: 11, anticipacion: 0.6, enfriamiento: 1.8, alturaVuelo: 4.5, flotar: 0.4,
      velProyectil: 12, colorProyectil: '#7fd4ff', tipoDano: 'magico', color: '#6a6a72', res_normal: 0.7, res_explosivo: 1.5 },
    // animales (figura de cuatro patas si no tienen modelo)
    conejo: { nombre: 'Conejo', forma: 'animal', actitud: 'pacifico', etiqueta: 'presa', vida: 10, velocidad: 1.2, velCorrer: 5.2, giro: 12,
      radio: 0.22, altura: 0.4, vision: 11, angulo: 300, oidoCaminar: 6, oidoCorrer: 13, memoria: 3, reaccion: 0.1, ataque: 'cuerpo', dano: 0,
      radioDeambular: 4, avisar: 10, color: '#c9b9a0', desaparecer: 3, enAgua: 'orilla' },
    vaca: { nombre: 'Vaca', forma: 'animal', actitud: 'neutral', etiqueta: 'ganado', vida: 80, velocidad: 0.7, velCorrer: 4, giro: 3,
      radio: 0.55, altura: 1.3, vision: 12, angulo: 200, ataque: 'embestida', dano: 12, alcance: 5, anticipacion: 0.6, enfriamiento: 2.5, empuje: 7,
      radioDeambular: 6, avisar: 10, aguante: 20, color: '#e8e0d0', huirConVida: 0.3 },
    lobo: { nombre: 'Lobo', forma: 'animal', actitud: 'depredador', etiqueta: 'lobo', caza: 'presa, ganado', vida: 45, velocidad: 2, velCorrer: 7.8, giro: 10,
      radio: 0.33, altura: 0.8, vision: 22, angulo: 220, oidoCorrer: 16, ataque: 'cuerpo', dano: 10, alcance: 1.3, anticipacion: 0.3, enfriamiento: 1,
      avisar: 18, huirConVida: 0.2, radioDeambular: 8, color: '#7a7a80' },
    oso: { nombre: 'Oso', forma: 'animal', actitud: 'agresivo', etiqueta: 'oso', caza: 'presa, ganado', vida: 220, velocidad: 1.3, velCorrer: 5.5, giro: 4,
      radio: 0.6, altura: 1.4, vision: 16, angulo: 160, ataque: 'cuerpo', dano: 30, alcance: 1.9, anticipacion: 0.65, enfriamiento: 1.8, empuje: 8,
      aguante: 45, avisar: 0, color: '#5a3d28', res_normal: 0.8 },
    // acuáticos (solo dentro del agua; figura de pez si no tienen modelo)
    pez: { nombre: 'Pez', tipo: 'acuatico', actitud: 'pacifico', etiqueta: 'pez', vida: 8, velocidad: 1.4, velCorrer: 4.5, giro: 6,
      radio: 0.2, altura: 0.4, vision: 8, angulo: 300, oidoCaminar: 0, oidoCorrer: 0, oidoDisparo: 10, memoria: 2, reaccion: 0.05,
      ataque: 'cuerpo', dano: 0, radioDeambular: 5, avisar: 6, color: '#d9a23a', desaparecer: 2 },
    tiburon: { nombre: 'Tiburón', tipo: 'acuatico', actitud: 'agresivo', etiqueta: 'tiburon', caza: 'pez', vida: 120, velocidad: 2, velCorrer: 6.5, giro: 3.5,
      radio: 0.55, altura: 1.1, vision: 16, angulo: 200, oidoCaminar: 0, oidoCorrer: 0, oidoDisparo: 25, ataque: 'cuerpo', dano: 25, alcance: 1.6,
      anticipacion: 0.35, enfriamiento: 1.6, empuje: 6, aguante: 40, radioDeambular: 10, color: '#6f7f8f', saltaFuera: true, alcanceSalto: 6 },
    pirana: { nombre: 'Piraña', tipo: 'acuatico', actitud: 'agresivo', etiqueta: 'pirana', vida: 6, velocidad: 2.5, velCorrer: 6, giro: 12,
      radio: 0.14, altura: 0.28, vision: 10, angulo: 300, oidoCaminar: 0, oidoCorrer: 0, ataque: 'cuerpo', dano: 4, alcance: 0.9,
      anticipacion: 0.1, enfriamiento: 0.5, empuje: 0.5, avisar: 12, radioDeambular: 4, color: '#9a3a3a', desaparecer: 2 },
  };

  /* Aparecedor (entidad 'aparecedor'): zona que va sacando enemigos o arena de oleadas */
  const APARECEDOR = {
    modo: 'zona',             // 'zona' (estilo Minecraft) | 'oleadas' (horda / tiroteo)
    // qué salen: criaturas de la biblioteca (proyecto.criaturas) con su número
    // (zona y oleadas automáticas: cuánto más a menudo sale; en la lista de oleadas: cuántos)
    salen: [{ criatura: 'cr_zombi', n: 1 }],
    radio: 12,                // dónde salen (y en oleadas "entrar", la zona que las empieza)
    aparicion: 'fuera',       // 'fuera' (donde no lo ves) | 'siempre'
    distanciaMin: 8,          // nunca más cerca de ti que esto
    puntos: '',               // ruta de puntos donde salen (en vez de al azar en el radio)
    // zona
    maximo: 4, cada: 8, alInicio: true, activa: 60, desaparecerLejos: 90,
    // oleadas
    forma: 'auto',            // 'auto' (crecen solas) | 'lista' (una línea por oleada)
    empezar: 'entrar',        // 'entrar' | 'inicio' | 'mecanismo' (la empieza una palanca / disparador)
    encendido: true,          // zona: false = no saca nada hasta que una palanca / disparador lo encienda
    inicial: 4, crecer: 2, fuerza: 10, jefeCada: 5, jefe: '', total: 10, descanso: 8, vivosMax: 10,   // jefe = id de criatura
    oleadas: [[{ criatura: 'cr_zombi', n: 4 }], [{ criatura: 'cr_zombi', n: 6 }, { criatura: 'cr_demonio', n: 1 }],
      [{ criatura: 'cr_soldado', n: 4 }, { criatura: 'cr_demonio', n: 2 }]],
    avisoOleada: true,
  };
  const PUNTO = { ruta: 'ruta1', orden: 0, espera: 1 };

  const IDLE = new Set(['quieto', 'deambular', 'buscar', 'orden']);
  const ACTIVOS = new Set(['alerta', 'perseguir', 'anticipar', 'atacar', 'aturdido', 'huir', 'cubrirse']);
  const norm = (s) => String(s || '').trim().toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g, '');
  // texto de la v0.13.0 ("zombi x5, demonio") → [{ criatura: 'cr_zombi', n }] (las criaturas de serie se llaman cr_<preajuste>)
  function textoACriaturas(txt) {
    return leerLista(txt).map((x) => {
      const k = norm(x.nombre);
      const clave = Object.keys(PRESETS).find((pk) => norm(pk) === k || norm(PRESETS[pk].nombre) === k);
      return clave ? { criatura: 'cr_' + clave, n: x.n } : null;
    }).filter(Boolean);
  }
  // "zombi x5, demonio, 2 soldado" → [{ nombre, n }]
  function leerLista(txt) {
    const out = [];
    for (const parte of String(txt || '').split(/[,;+]/)) {
      const s = parte.trim();
      if (!s) continue;
      let m = s.match(/^(\d+)\s*[x×*]?\s+(.+)$/i), n = 1, nom = s;
      if (m) { n = +m[1]; nom = m[2]; } else if ((m = s.match(/^(.+?)\s*[x×*]\s*(\d+)$/i))) { nom = m[1]; n = +m[2]; }
      if (n > 0) out.push({ nombre: nom.trim(), n });
    }
    return out;
  }

  /* ---------- Figura retro del motor (si no hay modelo): geometría compartida, material propio (para el destello) ---------- */
  function caja(w, h, d, x, y, z, color) {
    const g = new T.BoxGeometry(w, h, d).toNonIndexed();
    g.translate(x, y, z);
    const c = new T.Color(color), n = g.attributes.position.count, col = new Float32Array(n * 3);
    for (let i = 0; i < n; i++) { col[i * 3] = c.r; col[i * 3 + 1] = c.g; col[i * 3 + 2] = c.b; }
    g.setAttribute('color', new T.BufferAttribute(col, 3));
    g.deleteAttribute('uv');
    return g;
  }
  const geoms = {};
  function unir(partes) {
    const g = T.mergeGeometries(partes);
    partes.forEach((p) => p.dispose());
    g.computeVertexNormals();
    return g;
  }
  function geomCuerpo() {
    // de pie, mirando a +Z, de 1 m de alto (se escala a su altura). Ojos rojos.
    return geoms.cuerpo || (geoms.cuerpo = unir([
      caja(0.34, 0.42, 0.22, 0, 0.21, 0, '#cfcfcf'),            // piernas
      caja(0.44, 0.36, 0.26, 0, 0.6, 0, '#ffffff'),             // torso
      caja(0.11, 0.36, 0.11, -0.29, 0.58, 0.02, '#e0e0e0'),     // brazos
      caja(0.11, 0.36, 0.11, 0.29, 0.58, 0.02, '#e0e0e0'),
      caja(0.24, 0.22, 0.22, 0, 0.9, 0, '#f2f2f2'),             // cabeza
      caja(0.05, 0.04, 0.02, -0.06, 0.92, 0.115, '#ff2a1a'),    // ojos
      caja(0.05, 0.04, 0.02, 0.06, 0.92, 0.115, '#ff2a1a'),
    ]));
  }
  function geomVolador() {
    return geoms.vol || (geoms.vol = unir([
      caja(0.36, 0.3, 0.46, 0, 0, 0, '#ffffff'),
      caja(0.22, 0.2, 0.18, 0, 0.08, 0.3, '#f0f0f0'),
      caja(0.05, 0.04, 0.02, -0.05, 0.1, 0.395, '#ff2a1a'),
      caja(0.05, 0.04, 0.02, 0.05, 0.1, 0.395, '#ff2a1a'),
    ]));
  }
  function geomAnimal() {
    // cuatro patas, mirando a +Z, de 1 m de alto (se escala a su altura)
    return geoms.animal || (geoms.animal = unir([
      caja(0.09, 0.45, 0.09, -0.16, 0.225, 0.38, '#cfcfcf'), caja(0.09, 0.45, 0.09, 0.16, 0.225, 0.38, '#cfcfcf'),
      caja(0.09, 0.45, 0.09, -0.16, 0.225, -0.38, '#cfcfcf'), caja(0.09, 0.45, 0.09, 0.16, 0.225, -0.38, '#cfcfcf'),
      caja(0.42, 0.38, 0.98, 0, 0.62, 0, '#ffffff'),             // lomo
      caja(0.26, 0.26, 0.3, 0, 0.84, 0.6, '#f2f2f2'),            // cabeza
      caja(0.05, 0.04, 0.02, -0.07, 0.88, 0.755, '#ff2a1a'),
      caja(0.05, 0.04, 0.02, 0.07, 0.88, 0.755, '#ff2a1a'),
    ]));
  }
  function geomPez() {
    // mirando a +Z, 1 m de largo (se escala con el radio): cuerpo, cabeza, aleta de arriba y ojos
    return geoms.pez || (geoms.pez = unir([
      caja(0.34, 0.42, 0.7, 0, 0, 0.05, '#ffffff'),
      caja(0.26, 0.32, 0.22, 0, -0.02, 0.5, '#f0f0f0'),
      caja(0.05, 0.2, 0.3, 0, 0.28, 0, '#d8d8d8'),
      caja(0.02, 0.05, 0.05, -0.135, 0.04, 0.5, '#111111'), caja(0.02, 0.05, 0.05, 0.135, 0.04, 0.5, '#111111'),
    ]));
  }
  function geomCola() {
    return geoms.cola || (geoms.cola = unir([caja(0.05, 0.42, 0.3, 0, 0, -0.15, '#d8d8d8')]));
  }
  function geomAla(lado) {
    const k = 'ala' + lado;
    return geoms[k] || (geoms[k] = unir([caja(0.7, 0.04, 0.34, lado * 0.35, 0, 0, '#d8d8d8')]));
  }
  function geomTorreta() {
    return geoms.torreta || (geoms.torreta = unir([
      caja(0.7, 0.3, 0.7, 0, 0.15, 0, '#bbbbbb'),
      caja(0.5, 0.4, 0.5, 0, 0.5, 0, '#ffffff'),
      caja(0.12, 0.12, 0.5, 0, 0.55, 0.4, '#555555'),
      caja(0.08, 0.06, 0.02, 0, 0.62, 0.255, '#ff2a1a'),
    ]));
  }
  function materialPropio(color) {
    return F.Render.matRetro(color, { vertexColors: true });
  }

  /* Ayudas del editor: cono de visión y radios de oído / deambular (no se ven al jugar) */
  function ayudas(c) {
    const g = new T.Group();
    const linea = (puntos, color, op) => {
      const l = new T.Line(new T.BufferGeometry().setFromPoints(puntos), new T.LineBasicMaterial({ color, transparent: true, opacity: op, fog: false }));
      l.userData.ayudaEditor = true;
      g.add(l);
    };
    const circulo = (r, color, op) => {
      const p = [];
      for (let i = 0; i <= 48; i++) { const a = (i / 48) * Math.PI * 2; p.push(new T.Vector3(Math.cos(a) * r, 0.05, Math.sin(a) * r)); }
      linea(p, color, op);
    };
    // cono (hacia +Z, que es "adelante" del enemigo)
    const med = Math.min(c.angulo, 359) * DEG / 2, p = [new T.Vector3(0, 0.08, 0)];
    for (let i = 0; i <= 16; i++) { const a = -med + (2 * med * i) / 16; p.push(new T.Vector3(Math.sin(a) * c.vision, 0.08, Math.cos(a) * c.vision)); }
    p.push(new T.Vector3(0, 0.08, 0));
    linea(p, '#ffd24a', 0.55);
    circulo(c.oidoCorrer, '#4fb3ff', 0.35);
    if (c.inactivo === 'deambular' && c.tipo !== 'fijo') circulo(c.radioDeambular, '#7fbf7f', 0.3);
    g.userData.ayudaEditor = true;
    return g;
  }

  /* Object3D de la entidad: raíz (posición) → "visual" (gira hacia donde mira) → figura o modelo */
  function figura(ent) {
    const c = { ...BASE, ...(ent.enemigo || {}) };
    const raiz = new T.Group();
    const visual = new T.Group();
    raiz.add(visual);
    raiz.userData.visual = visual;
    const a = c.modelo && F.Assets.mapa.get(c.modelo);
    if (a && a.gltf) {
      const m = T.SkeletonUtils.clone(a.gltf.scene);
      m.scale.setScalar(c.escalaModelo || 1);
      visual.add(m);
      raiz.userData.animaciones = a.gltf.animations || [];
      raiz.userData.esModelo = true;
    } else if (c.tipo === 'volador') {
      const cuerpo = new T.Mesh(geomVolador(), materialPropio(c.color));
      const s = c.altura / 0.6;
      cuerpo.scale.setScalar(s);
      const alaI = new T.Mesh(geomAla(-1), cuerpo.material), alaD = new T.Mesh(geomAla(1), cuerpo.material);
      alaI.position.set(-0.17 * s, 0.05 * s, 0); alaD.position.set(0.17 * s, 0.05 * s, 0);
      alaI.scale.setScalar(s); alaD.scale.setScalar(s);
      const caja3 = new T.Group();
      caja3.position.y = c.alturaVuelo;    // en el editor se ve a su altura de vuelo
      caja3.add(cuerpo, alaI, alaD);
      visual.add(caja3);
      raiz.userData.alas = [alaI, alaD];
      raiz.userData.cuerpoVol = caja3;
    } else if (c.tipo === 'acuatico') {
      const s = c.radio * 3.2, grupo = new T.Group(), mat = materialPropio(c.color);
      const cuerpo = new T.Mesh(geomPez(), mat), cola = new T.Mesh(geomCola(), mat);
      cola.position.z = -0.3;
      grupo.add(cuerpo, cola);
      grupo.scale.setScalar(s);
      const caja3 = new T.Group();
      caja3.position.y = c.radio;           // en el editor no se hunde en el suelo
      caja3.add(grupo);
      visual.add(caja3);
      raiz.userData.cola = cola;
      raiz.userData.cuerpoVol = caja3;
      raiz.userData.alturaEditor = c.radio;
    } else if (c.tipo === 'fijo') {
      const m = new T.Mesh(geomTorreta(), materialPropio(c.color));
      m.scale.setScalar(c.altura / 0.7);
      visual.add(m);
    } else if (c.forma === 'animal') {
      const m = new T.Mesh(geomAnimal(), materialPropio(c.color));
      m.scale.setScalar(c.altura);
      visual.add(m);
    } else {
      const m = new T.Mesh(geomCuerpo(), materialPropio(c.color));
      m.scale.set(c.radio / 0.25, c.altura, c.radio / 0.25);
      visual.add(m);
    }
    raiz.add(ayudas(c));
    return raiz;
  }

  /* Ayudas del editor (no se ven al jugar): punto de ruta y aparecedor */
  function figuraPunto(ent) {
    const pt = { ...PUNTO, ...(ent.punto || {}) };
    const g = new T.Group();
    const m = new T.MeshBasicMaterial({ color: 0xffb03a, fog: false });
    const palo = new T.Mesh(new T.CylinderGeometry(0.03, 0.03, 1, 6), m);
    palo.position.y = 0.5;
    const bandera = new T.Mesh(new T.BoxGeometry(0.3, 0.18, 0.02), m);
    bandera.position.set(0.15, 0.9, 0);
    const base = new T.Mesh(new T.CylinderGeometry(0.22, 0.22, 0.03, 12), new T.MeshBasicMaterial({ color: 0xffb03a, wireframe: true, fog: false }));
    for (const o of [palo, bandera, base]) { o.userData.ayudaEditor = true; g.add(o); }
    g.userData.ayudaEditor = true;
    g.userData.ruta = pt.ruta;
    return g;
  }
  function figuraAparecedor(ent) {
    const c = { ...APARECEDOR, ...(ent.aparecedor || {}) };
    const g = new T.Group();
    const color = c.modo === 'oleadas' ? 0xff4a4a : 0x6adf6a;
    const p = [];
    for (let i = 0; i <= 64; i++) { const a = (i / 64) * Math.PI * 2; p.push(new T.Vector3(Math.cos(a) * c.radio, 0.06, Math.sin(a) * c.radio)); }
    const anillo = new T.Line(new T.BufferGeometry().setFromPoints(p), new T.LineBasicMaterial({ color, transparent: true, opacity: 0.7, fog: false }));
    const m = new T.MeshBasicMaterial({ color, wireframe: true, fog: false });
    const centro = new T.Mesh(new T.OctahedronGeometry(0.35), m);
    centro.position.y = 0.8;
    const poste = new T.Mesh(new T.CylinderGeometry(0.05, 0.05, 0.8, 6), m);
    poste.position.y = 0.4;
    for (const o of [anillo, centro, poste]) { o.userData.ayudaEditor = true; g.add(o); }
    g.userData.ayudaEditor = true;
    return g;
  }

  /* ---------- Rayo y distancia contra una cápsula vertical (para armas y explosiones) ---------- */
  function rayoEsfera(ox, oy, oz, dx, dy, dz, cx, cy, cz, r) {
    const lx = ox - cx, ly = oy - cy, lz = oz - cz;
    const b = lx * dx + ly * dy + lz * dz, c = lx * lx + ly * ly + lz * lz - r * r;
    const disc = b * b - c;
    if (disc < 0) return -1;
    const t = -b - Math.sqrt(disc);
    return t >= 0 ? t : (c <= 0 ? 0 : -1);
  }
  function rayoCapsula(o, d, max, x, y0, z, r, h) {
    const ya = y0 + r, yb = y0 + Math.max(r, h - r);
    let mejor = Infinity;
    const ox = o.x - x, oz = o.z - z;
    const a = d.x * d.x + d.z * d.z;
    if (a > 1e-8) {
      const b = 2 * (ox * d.x + oz * d.z), c = ox * ox + oz * oz - r * r;
      const disc = b * b - 4 * a * c;
      if (disc >= 0) {
        const t = (-b - Math.sqrt(disc)) / (2 * a);
        const yy = o.y + t * d.y;
        if (t >= 0 && yy >= ya && yy <= yb) mejor = t;
      }
    }
    for (const yc of [ya, yb]) {
      const t = rayoEsfera(o.x, o.y, o.z, d.x, d.y, d.z, x, yc, z, r);
      if (t >= 0 && t < mejor) mejor = t;
    }
    return mejor <= max ? mejor : -1;
  }

  const _v = new T.Vector3(), _v2 = new T.Vector3(), _v3 = new T.Vector3(), _esfera = new T.Sphere(), _frustum = new T.Frustum(), _pm = new T.Matrix4();

  /* =========================================================
     GESTOR
     ========================================================= */
  class Enemigos {
    constructor(juego) {
      this.juego = juego;
      this.lista = [];
      this.muertos = new Set();     // ids que ya no salen (se guardan en la partida)
      this.ruidos = [];             // { x, y, z, fuerza (multiplica oidoDisparo), t }
      this.balas = [];
      this.rutas = new Map();       // nombre de ruta → [{ pos, espera, orden }]
      this.moldes = new Map();      // nombre → { clave, nombre, cfg, sombra } (enemigos de la escena y preajustes)
      this.aparecedores = [];
      this.reserva = new Map();     // clave de molde → enemigos generados que ya murieron (se reutilizan)
      this.nGen = 0;
      this.cuadro = 0;
      this.t = 0;
      this.quitarOyente = F.on('disparo', (d) => {
        if (!d || !d.punto) return;
        const cuerpo = d.arma && d.arma.tipo === 'cuerpo';
        this.ruidos.push({ x: d.punto.x, y: d.punto.y, z: d.punto.z, fuerza: cuerpo ? 0.25 : 1, t: this.t });
      });
    }

    preparar(guardado) {
      const muertos = new Set((guardado && guardado.enemigosMuertos) || []);
      const ents = this.juego.escena.entidades;
      // rutas de puntos y moldes (antes de crear a nadie)
      for (const ent of ents) {
        const obj = this.juego.objetos.get(ent.id);
        if (!obj) continue;
        if (ent.tipo === 'punto') {
          const pt = { ...PUNTO, ...(ent.punto || {}) }, k = norm(pt.ruta);
          if (!this.rutas.has(k)) this.rutas.set(k, []);
          this.rutas.get(k).push({ pos: obj.getWorldPosition(new T.Vector3()), espera: pt.espera, orden: pt.orden });
        } else if (ent.tipo === 'enemigo' && ent.nombre && !this.moldes.has(norm(ent.nombre))) {
          this.moldes.set(norm(ent.nombre), { clave: 'e:' + ent.id, nombre: ent.nombre, cfg: ent.enemigo || {}, sombra: ent.sombra !== false });
        }
      }
      for (const L of this.rutas.values()) L.sort((a, b) => a.orden - b.orden);
      for (const ent of ents) {
        if (ent.tipo !== 'enemigo') continue;
        const obj = this.juego.objetos.get(ent.id);
        if (!obj || ent.visible === false) continue;
        if (ent.enemigo && ent.enemigo.soloMolde) { obj.visible = false; continue; }
        if (muertos.has(ent.id)) { obj.visible = false; this.muertos.add(ent.id); continue; }
        this.lista.push(this._crear(ent, obj));
      }
      for (const ent of ents) {
        if (ent.tipo !== 'aparecedor' || ent.visible === false) continue;
        const obj = this.juego.objetos.get(ent.id);
        if (obj) this.aparecedores.push(this._nuevoAparecedor(ent, obj));
      }
      // 🥚 oleadas de la partida guardada: terminadas siguen terminadas; a medias se repite la que iba (con su descanso)
      const memO = (guardado && guardado.oleadas) || {};
      for (const A of this.aparecedores) {
        const m = memO[A.ent.id];
        if (!m || A.c.modo !== 'oleadas') continue;
        if (m.fase === 'fin') { A.fase = 'fin'; A.n = m.n; A.totalN = m.totalN || 0; A.lleno = true; }
        else if (m.fase === 'oleada' || m.fase === 'descanso') { A.n = Math.max(0, m.fase === 'oleada' ? m.n - 1 : m.n); A.fase = 'descanso'; A.t2 = 3; A.apagado = false; }
      }
      // ⚫ sombras de mancha de todos los enemigos: UNA malla instanciada (una llamada de dibujo para todas)
      const aj = this.juego.ajustes || this.juego.proyecto.ajustes || {};
      if (aj.manchasEnemigos !== false && (this.lista.length || this.aparecedores.length)) {
        const c = document.createElement('canvas'); c.width = c.height = 32;
        const g = c.getContext('2d');
        for (let i = 8; i >= 1; i--) { g.fillStyle = `rgba(0,0,0,${Math.min(1, (9 - i) / 5)})`; g.beginPath(); g.arc(16, 16, (i / 8) * 15, 0, Math.PI * 2); g.fill(); }
        const tex = new T.CanvasTexture(c); tex.magFilter = T.NearestFilter;
        const mat = new T.MeshBasicMaterial({ map: tex, transparent: true, depthWrite: false, opacity: 0.5, polygonOffset: true, polygonOffsetFactor: -4, polygonOffsetUnits: -4 });
        this.manchas = new T.InstancedMesh(new T.PlaneGeometry(1, 1).rotateX(-Math.PI / 2), mat, 128);
        this.manchas.count = 0; this.manchas.renderOrder = 5; this.manchas.frustumCulled = false;
        this.juego.vista.escena.add(this.manchas);
      }
      // pool de proyectiles enemigos (no se crean al disparar)
      if (this.aparecedores.length || this.lista.some((e) => e.c.ataque === 'proyectil')) {
        const tex = this._textura();
        for (let i = 0; i < 20; i++) {
          const sp = new T.Sprite(new T.SpriteMaterial({ map: tex, color: '#ffffff', transparent: true, blending: T.AdditiveBlending, depthWrite: false }));
          sp.visible = false;
          sp.scale.setScalar(0.35);
          this.juego.vista.escena.add(sp);
          this.balas.push({ sp, activa: false, pos: new T.Vector3(), vel: new T.Vector3(), vida: 0, dano: 0, tipo: 'normal', de: null, blanco: null });
        }
      }
      this.aliados = this.lista.filter((E) => E.c.actitud === 'aliado');   // 🛡 tu equipo (motor/aliados.js)
    }

    _textura() {
      const c = document.createElement('canvas');
      c.width = c.height = 32;
      const g = c.getContext('2d');
      for (let i = 4; i >= 1; i--) { g.fillStyle = `rgba(255,255,255,${(5 - i) / 4})`; g.beginPath(); g.arc(16, 16, i * 3.8, 0, 7); g.fill(); }
      const t = new T.CanvasTexture(c);
      t.magFilter = T.NearestFilter;
      this._tex = t;
      return t;
    }

    // 📏 escala de la entidad: tamaño, choque, alcance cuerpo a cuerpo, vuelo y empuje (y si se pide, velocidad y fuerza)
    _escalar(c, k) {
      if (!k || k === 1) return;
      c.radio *= k; c.altura *= k; c.alturaVuelo *= k; c.flotar *= k; c.empuje *= k;
      if (c.ataque === 'cuerpo') c.alcance *= k;
      else if (c.ataque === 'embestida') c.alcance *= Math.sqrt(k);
      if (c.escalaVel) { const v = Math.sqrt(k); c.velocidad *= v; c.velCorrer *= v; }
      if (c.escalaFuerza) { c.vida = Math.round(c.vida * k * k); c.dano = Math.round(c.dano * k); }
    }

    _crear(ent, obj) {
      const c = { ...BASE, ...(ent.enemigo || {}) };
      // 📏 la colisión sigue a la escala: la de la entidad (editor) y, con modelo, su "escala del modelo"
      const kEsc = Math.max(obj.scale.x, obj.scale.y, obj.scale.z) * (c.modelo ? c.escalaModelo || 1 : 1);
      this._escalar(c, kEsc);
      const juego = this.juego;
      const inicio = new T.Vector3();
      obj.getWorldPosition(inicio);
      // la raíz pasa al nivel de la escena para moverla en coordenadas del mundo (al parar vuelve a su padre)
      const padre0 = obj.parent;
      if (obj.parent !== juego.vista.escena && obj.parent) juego.vista.escena.attach(obj);
      obj.rotation.set(0, 0, 0);
      const yaw0 = (ent.rot ? ent.rot[1] : 0) * DEG;
      const nada = c.tipo === 'acuatico';
      const vol = c.tipo === 'volador' || nada;   // los acuáticos usan el cuerpo del volador (cápsula baja, sin escalones)
      const cuerpo = new F.Fisica.CuerpoCinematico(juego.mundo, {
        radio: c.radio, altura: vol ? c.radio * 2 : c.altura, escalon: vol ? 0.02 : Math.min(0.35, c.altura * 0.25), pendienteMax: 50,
      });
      cuerpo.teletransportar(inicio.x, inicio.y + (c.tipo === 'volador' ? c.alturaVuelo : nada ? c.radio : 0), inicio.z);
      const E = {
        ent, c, obj, kEsc, visual: obj.userData.visual, cuerpo, vol, nada, enAgua: null, fijo: c.tipo === 'fijo',
        vida: c.vida, escudo: c.escudo || 0, tEscudo: 0, cdEsq: 0, esq: null, ladoLat: Math.random() < 0.5 ? -1 : 1, tLat: 1, estado: 'quieto', t: 0,
        yaw: yaw0, casa: inicio.clone(), meta: inicio.clone(), ultima: new T.Vector3(), recuerdo: 0, viendo: false,
        cd: Math.random() * 0.5, tPensar: Math.random() * 0.12, cadaPensar: 0.12, lod: 0, animAcum: 0,
        sep: new T.Vector3(), sueloY: inicio.y, techoY: Infinity, tSuelo: 0, vy: 0, flash: 0, mats: [],
        fase: Math.random() * 6.28, golpeado: false, embiste: null, salto: null, picado: null, muerto: false, tMuerte: 0,
        // a quién: blanco = con quien está ahora (el jugador o la "cara" de otro enemigo); amenaza = quien le atacó o le marcaron
        blanco: null, amenaza: null, presa: null, tCaza: Math.random() * 0.5, asustado: false, sabe: false, comer: 0, desvio: 0,
        ruta: null, iRuta: 0, espera: 0, generado: false, reserva: false, de: null,
      };
      this._etiquetas(E);
      const ruta = c.patrulla && this.rutas.get(norm(c.patrulla));
      if (ruta && ruta.length) {
        E.ruta = ruta;
        let mejor = Infinity;
        ruta.forEach((pt, i) => { const d = pt.pos.distanceToSquared(inicio); if (d < mejor) { mejor = d; E.iRuta = i; } });
      }
      E.estado = this._inicial(E);
      // su "cara" como blanco de otros enemigos (misma forma que el jugador: cuerpo, muerto, danar)
      const self = this;
      E.yo = { enemigo: E, cuerpo, agachado: false, corriendo: false,
        get muerto() { return E.muerto; },
        danar: (cantidad, origen, de) => self.danar(E, cantidad, { tipo: (de && de.c.tipoDano) || 'normal', de }) };
      // materiales COMPARTIDOS con los de su mismo tipo; solo mientras dura el destello rojo lleva copia propia
      E.originales = [];
      obj.traverse((o) => {
        if (!o.isMesh) return;
        o.frustumCulled = true;
        E.originales.push([o, o.material]);
      });
      if (obj.userData.cuerpoVol) obj.userData.cuerpoVol.position.y = 0;
      // animaciones del modelo
      const clips = obj.userData.animaciones;
      if (clips && clips.length) {
        E.mixer = new T.AnimationMixer(obj);
        E.acc = F.Escena.mapaAcciones(E.mixer, clips);
        for (const k of ['attack', 'hurt', 'die']) if (E.acc[k]) { E.acc[k].setLoop(T.LoopOnce, 1); E.acc[k].clampWhenFinished = true; }
        this._anim(E, 'idle');
      }
      // objetivo para las armas: rayo y distancia contra su cápsula (no contra sus mallas)
      const P = cuerpo.pie, h = vol ? c.radio * 2 : c.altura;
      const yBase = () => P.y;
      E.objetivo = { esEnemigo: true,
        ent, obj, enemigo: E, vidaMax: c.vida,
        get vida() { return E.vida; },
        danar: (cantidad, punto, info) => { if (c.actitud === 'aliado' && !c.fuegoAmigo && !(info && info.de)) return; this.danar(E, cantidad, info || {}); },
        rayo: (ori, dir, max) => {
          if (E.muerto) return null;
          const t = rayoCapsula(ori, dir, max, P.x, yBase(), P.z, c.radio, h);
          if (t < 0) return null;
          const punto = ori.clone().addScaledVector(dir, t);
          const normal = new T.Vector3(punto.x - P.x, 0, punto.z - P.z).normalize();
          return { t, punto, normal };
        },
        distancia: (p, out) => {
          const y = clamp(p.y, yBase() + c.radio, yBase() + Math.max(c.radio, h - c.radio));
          _v.set(p.x - P.x, p.y - y, p.z - P.z);
          const d = _v.length();
          if (out) out.set(P.x, y, P.z).addScaledVector(_v, d > 0 ? Math.min(c.radio, d) / d : 0);
          return Math.max(0, d - c.radio);
        },
      };
      juego.objetivos.push(E.objetivo);
      E.padre0 = padre0;
      obj.position.set(P.x, P.y + (vol ? c.radio : 0), P.z);
      if (c.jefe) this.hayJefes = true;
      return E;
    }

    _etiquetas(E) {
      E.etq = norm(E.c.etiqueta);
      E.caza = new Set(String(E.c.caza || '').split(',').map(norm).filter(Boolean));
    }
    _inicial(E) { if (E.c.actitud === 'aliado') return 'orden'; return !E.fijo && (E.c.inactivo === 'deambular' || E.ruta) ? 'deambular' : 'quieto'; }
    _huye(E) { return !E.fijo && (E.c.actitud === 'pacifico' || E.asustado); }

    /* ---------- Animación (si el modelo trae: idle, walk, run, attack, hurt, die, fly) ---------- */
    _anim(E, nombre, vel = 1) {
      if (!E.acc) return;
      let a = E.acc[nombre];
      if (!a && nombre === 'run') a = E.acc.walk;
      if (!a && nombre === 'fly') a = E.acc.idle;
      if (!a) a = E.acc.idle;
      if (!a) return;
      a.timeScale = vel;
      if (E.anim === a) return;
      // reset() vuelve a habilitarla (tras un fadeOut three la deja apagada con peso 0)
      a.reset().fadeIn(0.15).play();
      if (E.anim) E.anim.fadeOut(0.15);
      E.anim = a;
    }

    /* ---------- Daño ---------- */
    // info: { tipo, arma, jugador } de las armas del jugador, o { tipo, de: enemigo } si le pega otro enemigo
    danar(E, cantidad, info) {
      if (E.muerto || !(cantidad > 0) || info.de === E) return;
      const c = E.c, tipo = info.tipo || 'normal';
      const mult = c['res_' + tipo] ?? 1;
      let real = cantidad * mult;
      // 🛡 el escudo se lo come primero (destello azul); lo que sobra va a la vida
      if (E.escudo > 0) {
        const a = Math.min(E.escudo, real);
        E.escudo -= a; real -= a;
        E.tEscudo = c.escudoEspera;
        E.flashCol = real > 0 ? null : 'escudo';
        if (E.escudo <= 0) this._escudoRoto(E);
      } else E.flashCol = null;
      if (c.escudo > 0) E.tEscudo = c.escudoEspera;
      if (c.esquiva > 0 && !info.liquido && Math.random() < c.esquiva * 0.5) this._esquivar(E);
      E.vida -= real;
      if (!info.tic && F.Estados) F.Estados.enemigo(this, E, info.arma || (info.de && info.de.c), tipo);
      if (!(info.tic && E.flash > 0)) E.flash = 0.12;
      F.emitir('enemigo-danado', E, real, info);
      if (E.vida <= 0) { this._morir(E, info.de || null); return; }
      if (c.huirConVida > 0 && E.vida <= c.vida * c.huirConVida && !E.fijo) E.asustado = true;
      if (c.cubrirse && !(c.escudo > 0) && E.vida <= c.vida * 0.45 && !E.yaCubierto && E.vida > 0) { E.yaCubierto = true; this._cubrirse(E); }
      // quien le pega pasa a ser su amenaza (el neutral se defiende, el pacífico huye) y avisa a los suyos
      let quien = info.de ? (info.de.muerto ? null : info.de.yo) : info.liquido ? null : this.juego.jugador;   // la lava no es "alguien"
      if (c.actitud === 'aliado' && quien === this.juego.jugador) quien = null;   // 🛡 fuego amigo: no se vuelve contra ti
      if (quien) {
        E.amenaza = quien;
        this._reaccionar(E, quien, true);
        this._avisar(E, quien);
      }
      // aturdirse (no durante un ataque especial en marcha)
      if (real >= c.aguante && !E.embiste && !E.salto && !E.picado && c.aturdir > 0) {
        this._ir(E, 'aturdido', c.aturdir);
        this._anim(E, 'hurt');
        if (c.sonidoDolor) F.Audio.efecto(c.sonidoDolor, { tono: 0.9 + Math.random() * 0.2 });
      }
    }

    /* 🗡 Ejecución silenciosa: ¿puede el jugador matarlo por la espalda ahora? (cerca, detrás y sin haberte visto) */
    ejecutable(E, j, dist, angulo) {
      if (E.muerto || E.reserva || E.c.ejecutable === false || E.viendo || /^(anticipar|atacar|perseguir|huir|cubrirse)$/.test(E.estado)) return false;
      const P = j.cuerpo.pie, pie = E.cuerpo.pie, dx = P.x - pie.x, dz = P.z - pie.z, d = Math.hypot(dx, dz);
      if (d > dist + E.c.radio || Math.abs(P.y - pie.y) > 1.2 || d < 1e-3) return false;
      // detrás: el jugador cae dentro del cono de su espalda
      const atras = -(Math.sin(E.yaw) * dx + Math.cos(E.yaw) * dz) / d;
      return atras >= Math.cos((angulo || 100) * Math.PI / 360);
    }
    // 💫 aturdido unos segundos (patada a una puerta, C2, flash…)
    aturdir(E, s) {
      if (E.muerto || !(s > 0)) return;
      this._ir(E, 'aturdido', s);
      this._anim(E, 'hurt');
    }
    ejecutar(E) {
      if (E.muerto) return;
      E.vida = 0;
      E.silencioso = true;   // sin grito ni aviso a los demás
      this._morir(E, null);
      F.emitir('enemigo-ejecutado', E);
    }

    _morir(E, de) {
      E.muerto = true;
      E.estado = 'muerto';
      E.tMuerte = 0;
      E.embiste = E.salto = E.picado = null;
      E.blanco = E.amenaza = null;
      if (!E.generado) this.muertos.add(E.ent.id);
      const j = this.juego;
      j.objetivos = j.objetivos.filter((o) => o !== E.objetivo);
      this._anim(E, 'die');
      if (E.silencioso) F.Audio.sintetico('golpe', { volumen: 0.25, tono: 0.4 });
      else if (E.c.sonidoMuerte) F.Audio.efecto(E.c.sonidoMuerte);
      else F.Audio.sintetico('golpe', { volumen: 0.8, tono: 0.55 });
      // 🎁 botín: hasta tres cosas, cada una con su probabilidad (un preajuste o un objeto de la mochila 'obj:<id>')
      if (j.recogibles) {
        let k = 0;
        for (const [que, prob, n] of [[E.c.suelta, E.c.probSoltar, 0], [E.c.suelta2, E.c.probSoltar2, E.c.cantidad2], [E.c.suelta3, E.c.probSoltar3, E.c.cantidad3]]) {
          if (!que || Math.random() > (prob ?? 1)) continue;
          let pr = null;
          if (/^obj:/.test(que)) {
            const ob = (j.proyecto.objetos || []).find((o) => o.id === que.slice(4));
            if (ob) pr = { nombre: ob.nombre, tipo: 'objeto', objeto: ob.id, cantidad: Math.max(1, n | 0), recoger: 'tocar', soloSiFalta: false, color: ob.color };
          } else pr = F.Recogibles.PRESETS[que];
          if (!pr) continue;
          const a = k * 2.4 + E.yaw, r = k ? 0.55 : 0;   // repartidos alrededor del cuerpo
          j.recogibles.soltar(pr, _v.set(E.cuerpo.pie.x + Math.sin(a) * r, E.cuerpo.pie.y, E.cuerpo.pie.z + Math.cos(a) * r));
          k++;
        }
      }
      // el depredador que lo cazó se queda comiendo un rato
      if (de && !de.muerto && de.c.actitud === 'depredador') { de.amenaza = de.blanco = null; this._ir(de, 'quieto'); de.comer = 3; }
      F.emitir('enemigo-muerto', E);
    }

    _ir(E, estado, t = 0) { if (estado === 'buscar' && E.c.actitud === 'aliado') estado = 'orden'; E.estado = estado; E.t = t; }

    // ⚫ cada enemigo visible: su mancha en el suelo que ya conoce (sin rayos: los voladores tienen sueloY;
    // los de a pie, donde pisan o donde pisaron por última vez)
    _manchas() {
      const M = this.manchas, m = _pm;
      let n = 0;
      for (const E of this.lista) {
        if (n >= 128) break;
        if (E.reserva || !E.obj.visible || E.nada || (E.muerto && E.tMuerte > 0.6)) continue;
        const pie = E.cuerpo.pie;
        if (!E.vol && E.cuerpo.enSuelo) E.yMancha = pie.y;
        const y = E.vol ? E.sueloY : (E.yMancha ?? pie.y);
        if (!(y > -1e8) || pie.y - y > 12) continue;
        const k = Math.max(0.35, 1 - (pie.y - y) / 12), tam = Math.max(0.4, E.c.radio * 2.6) * k;
        m.makeScale(tam, 1, tam).setPosition(pie.x, y + 0.03, pie.z);
        M.setMatrixAt(n++, m);
      }
      M.count = n;
      M.instanceMatrix.needsUpdate = true;
    }

    /* ---------- Táctica (élite) ---------- */
    _tactica(E, j, dt) {
      const c = E.c;
      // escudo: tras unos segundos sin daño se recarga
      if (c.escudo > 0 && E.escudo < c.escudo) {
        if (E.tEscudo > 0) E.tEscudo -= dt;
        else { E.escudo = Math.min(c.escudo, E.escudo + c.escudoRecarga * dt); if (E.escudo >= c.escudo) F.emitir('enemigo-escudo', E); }
      }
      // esquivar al verse apuntado: el centro de la pantalla cerca de él (sin rayos)
      if (E.cdEsq > 0) E.cdEsq -= dt;
      if (c.esquiva > 0 && E.cdEsq <= 0 && E.viendo && !E.esq && ACTIVOS.has(E.estado) && E.estado !== 'aturdido' && j && j.camara) {
        E._tApunta = (E._tApunta || 0) - dt;
        if (E._tApunta <= 0) {
          E._tApunta = 0.25;
          const cam = j.camara, o = cam.getWorldPosition(_v3), d = cam.getWorldDirection(_v2);
          const ex = E.cuerpo.pie.x - o.x, ey = E.cuerpo.pie.y + c.altura * 0.6 - o.y, ez = E.cuerpo.pie.z - o.z, dist = Math.hypot(ex, ey, ez) || 1;
          const cos = (ex * d.x + ey * d.y + ez * d.z) / dist;
          const margen = Math.atan2(c.radio * 2.2, dist);
          if (cos > Math.cos(margen) && Math.random() < c.esquiva * 0.6) this._esquivar(E);
        }
      }
    }

    // ↯ de lado (perpendicular a ti), hacia donde no haya pared
    _esquivar(E) {
      const c = E.c;
      if (E.esq || E.cdEsq > 0 || E.fijo || E.vol || E.nada || E.embiste || E.salto || E.picado || E.estado === 'aturdido') return;
      const j = this.juego.jugador, pie = E.cuerpo.pie;
      if (!j) return;
      const dx = j.cuerpo.pie.x - pie.x, dz = j.cuerpo.pie.z - pie.z, h = Math.hypot(dx, dz) || 1;
      const lx = -dz / h, lz = dx / h, M = this.juego.mundo;
      let lado = Math.random() < 0.5 ? 1 : -1;
      const libre = (s) => !M.rayo(pie.x, pie.y + 0.5, pie.z, lx * s, 0, lz * s, 2.4);
      if (!libre(lado)) { lado = -lado; if (!libre(lado)) return; }
      E.esq = { dx: lx * lado, dz: lz * lado, t: 0.3, vel: Math.max(6, c.velCorrer * 1.4) };
      E.cdEsq = c.esquivaCada * (0.8 + Math.random() * 0.4);
      this._anim(E, 'dodge');
    }

    // 🛡 escudo roto: a cubrirse (si sabe)
    _escudoRoto(E) {
      F.emitir('enemigo-escudo-roto', E);
      F.Audio.sintetico('golpe', { volumen: 0.6, tono: 2.2 });
      if (E.c.cubrirse) this._cubrirse(E);
    }

    /* busca una cobertura cerca: un punto al que llega en línea recta y desde el que NO te ve (unos 30 rayos,
       solo cuando hace falta). Sin cobertura: se aparta de ti */
    _cubrirse(E) {
      const j = this.juego.jugador, M = this.juego.mundo, pie = E.cuerpo.pie;
      if (!j || !M || E.fijo || E.vol || E.nada) return;
      const P = j.cuerpo.pie, py = P.y + 1.4;
      let mejor = null, md = Infinity;
      for (const r of [3, 5.5, 8]) for (let i = 0; i < 10; i++) {
        const a = (i / 10) * Math.PI * 2 + r;
        const cx = pie.x + Math.sin(a) * r, cz = pie.z + Math.cos(a) * r;
        if (M.rayo(pie.x, pie.y + 0.8, pie.z, Math.sin(a), 0, Math.cos(a), r + E.c.radio)) continue;      // no llega (pared)
        const suelo = M.rayo(cx, pie.y + 1, cz, 0, -1, 0, 2.5);
        if (!suelo) continue;                                                                            // no hay suelo
        const cy = pie.y + 1 - suelo.t + 1.2;
        const vx = P.x - cx, vy = py - cy, vz = P.z - cz, vd = Math.hypot(vx, vy, vz) || 1;
        const tapa = M.rayo(cx, cy, cz, vx / vd, vy / vd, vz / vd, vd);
        if (!tapa || tapa.t > vd - 0.6) continue;                                                        // desde ahí te ve
        const d = r + (Math.hypot(cx - P.x, cz - P.z) < 4 ? 20 : 0);                                      // no pegado a ti
        if (d < md) { md = d; mejor = [cx, pie.y + 1 - suelo.t, cz]; }
      }
      E.esq = null;
      E.cubierto = false;
      if (mejor) { E.meta.set(mejor[0], mejor[1], mejor[2]); this._ir(E, 'cubrirse', 4); }
      else { this._ir(E, 'huir', 2); E.asustado = false; }
      F.emitir('enemigo-cubrirse', E, !!mejor);
    }

    // 🔴 destello al recibir daño: copia propia de sus materiales solo mientras dura (k > 0); al acabar vuelve a
    // los compartidos (así 30 zombis son los mismos 2 o 3 materiales y el rojo no pinta a los demás)
    _destello(E, k) {
      if (k > 0) {
        // 🎨 destello COMPARTIDO: una copia roja (o azul de escudo) por material original, para todos los enemigos que
        // lo usan; se crea la primera vez y se reutiliza (antes cada golpe copiaba y tiraba materiales)
        const tipo = E.flashCol === 'escudo' ? 'e' : E.flashCol === 'aviso' ? 'a' : 'r';
        const colA = tipo === 'a' ? (this.aviso && this.aviso.color) || '#ff8a1a' : '';
        const clave = tipo + colA;   // el aviso puede cambiar de color (verde = se puede hacer parry)
        if (E.propios !== clave) {
          E.propios = clave;
          const cache = this._flashMats || (this._flashMats = new Map());
          const fl = (m) => {
            const k2 = m.uuid + clave;
            let n = cache.get(k2);
            if (!n) {
              n = m.clone(); n.onBeforeCompile = m.onBeforeCompile; n.customProgramCacheKey = m.customProgramCacheKey; n.userData = { ...m.userData, compartido: false };
              if (n.emissive) { if (tipo === 'e') n.emissive.setRGB(0.22, 0.5, 0.9); else if (tipo === 'a') n.emissive.set(colA); else n.emissive.setRGB(0.9, 0, 0); }
              cache.set(k2, n);
            }
            return n;
          };
          for (const [o, m] of E.originales || []) o.material = Array.isArray(m) ? m.map(fl) : fl(m);
        }
      } else if (E.propios) {
        E.propios = false;
        for (const [o, m] of E.originales || []) o.material = m;   // vuelve al material compartido de siempre
      }
    }

    // vio / oyó / recibió daño de "b": huye o va a por él según su actitud
    _reaccionar(E, b, inmediato) {
      if (E.muerto || !b) return;
      if (E.c.actitud === 'pacifico' && E.fijo) return;
      E.blanco = b;
      E.ultima.copy(b.cuerpo.pie);
      E.recuerdo = E.c.memoria;
      E.comer = 0;
      if (this._huye(E)) {
        if (E.estado === 'aturdido') return;           // al terminar el aturdimiento huye
        if (E.estado !== 'huir') this._ir(E, 'huir', E.c.memoria + 1.5);
        else E.t = Math.max(E.t, E.c.memoria + 1.5);
        this._rumbo(E, b);
        return;
      }
      if (IDLE.has(E.estado) || E.estado === 'huir') {
        E.meta.copy(b.cuerpo.pie);
        this._ir(E, inmediato ? 'perseguir' : 'alerta', inmediato ? 0 : E.c.reaccion);
      }
    }

    // vuelve a lo suyo (deambular, patrullar o quieto) y se olvida de quien le molestaba
    _calmar(E) {
      E.amenaza = null;
      E.blanco = null;
      this._ir(E, this._inicial(E));
    }

    // avisa a los de su misma etiqueta que estén cerca y tranquilos (la manada ataca o huye junta)
    _avisar(E, b) {
      const r = E.c.avisar;
      if (!(r > 0) || !b) return;
      const r2 = r * r, pie = E.cuerpo.pie;
      for (const B of this.lista) {
        if (B === E || B.muerto || B.etq !== E.etq || B === b.enemigo || !IDLE.has(B.estado)) continue;
        const dx = B.cuerpo.pie.x - pie.x, dz = B.cuerpo.pie.z - pie.z;
        if (dx * dx + dz * dz < r2) { B.amenaza = b; this._reaccionar(B, b); }
      }
    }

    // ¿a quién mira / persigue? (barato: la presa se busca 2 veces por segundo)
    _elegirBlanco(E, j, dtp) {
      const a = E.amenaza;
      if (a) { if (!a.muerto) return a; E.amenaza = null; }
      const b0 = E.blanco;
      if (b0 && !b0.muerto && ACTIVOS.has(E.estado)) return b0;
      const act = E.c.actitud, pie = E.cuerpo.pie;
      if (act === 'aliado') return this._blancoAliado(E, dtp);
      let mejor = null, md = Infinity;
      if (j && !j.muerto && (act === 'agresivo' || act === 'pacifico' || E.caza.has('jugador'))) {
        const P = j.cuerpo.pie;
        mejor = j; md = (P.x - pie.x) ** 2 + (P.z - pie.z) ** 2;
      }
      if (E.caza.size && (act === 'depredador' || act === 'agresivo')) {
        E.tCaza -= dtp;
        if (E.tCaza <= 0 || (E.presa && E.presa.muerto)) {
          E.tCaza = 0.5;
          E.presa = null;
          let pd = E.c.vision * E.c.vision;
          for (const B of this.lista) {
            if (B === E || B.muerto || !B.etq || !E.caza.has(B.etq)) continue;
            const d2 = (B.cuerpo.pie.x - pie.x) ** 2 + (B.cuerpo.pie.z - pie.z) ** 2;
            if (d2 < pd) { pd = d2; E.presa = B.yo; }
          }
        }
        const pr = E.presa;
        if (pr) { const d2 = (pr.cuerpo.pie.x - pie.x) ** 2 + (pr.cuerpo.pie.z - pie.z) ** 2; if (d2 < md) mejor = pr; }
      }
      // 🛡 los agresivos también van a por tus aliados si están más cerca que tú (son pocos: máx. 3)
      if (act === 'agresivo' && this.aliados && this.aliados.length) {
        const v2 = E.c.vision * E.c.vision;
        for (const A of this.aliados) {
          if (A.muerto) continue;
          const d2 = (A.cuerpo.pie.x - pie.x) ** 2 + (A.cuerpo.pie.z - pie.z) ** 2;
          if (d2 < md && d2 < v2) { md = d2; mejor = A.yo; }
        }
      }
      return mejor;
    }

    // 🛡 aliado: el enemigo más cercano a la vista (se busca 2-3 veces por segundo); nunca el jugador
    _blancoAliado(E, dtp) {
      const pie = E.cuerpo.pie, j = this.juego.jugador;
      E.tCaza -= dtp;
      if (E.tCaza <= 0 || (E.presa && E.presa.muerto)) {
        E.tCaza = 0.4;
        E.presa = null;
        let pd = E.c.vision * E.c.vision;
        for (const B of this.lista) {
          if (B === E || B.muerto || B.reserva || B.c.actitud === 'aliado' || B.c.actitud === 'pacifico') continue;
          if (B.c.actitud === 'neutral' && !B.blanco) continue;   // el neutral solo si ya está peleando
          const d2 = (B.cuerpo.pie.x - pie.x) ** 2 + (B.cuerpo.pie.z - pie.z) ** 2;
          if (d2 < pd) { pd = d2; E.presa = B.yo; }
        }
      }
      return E.presa;
    }

    // huye en dirección contraria a la amenaza; si choca con algo o se atasca, tuerce
    _rumbo(E, b) {
      const pie = E.cuerpo.pie, P = b.cuerpo.pie, v = E.cuerpo.velocidad;
      let ax = pie.x - P.x, az = pie.z - P.z;
      const h = Math.hypot(ax, az) || 1;
      ax /= h; az /= h;
      const atascado = E.cuerpo.contactoPared || (E.estado === 'huir' && Math.hypot(v.x, v.z) < E.c.velCorrer * 0.2);
      if (atascado) E.desvio += Math.random() < 0.5 ? 1.3 : -1.3;
      else E.desvio = E.desvio * 0.7 + (Math.random() - 0.5) * 0.4;
      E.desvio = clamp(E.desvio, -2.2, 2.2);
      const cs = Math.cos(E.desvio), sn = Math.sin(E.desvio);
      E.meta.set(pie.x + (ax * cs - az * sn) * 8, pie.y, pie.z + (ax * sn + az * cs) * 8);
    }

    /* =========================================================
       CADA CUADRO
       ========================================================= */
    actualizar(dt) {
      this.t += dt;
      this.cuadro++;
      const juego = this.juego, j = juego.jugador;
      if (!j) { this._moverBalas(dt); return; }
      const P = j.cuerpo.pie;
      // ruido de los pasos del jugador: 0 nada, 1 caminar, 2 correr (agachado no se oye)
      const vj = j.cuerpo.velocidad;
      const moviendo = j.cuerpo.enSuelo && vj.x * vj.x + vj.z * vj.z > 0.36;
      this.ruidoPasos = !moviendo || j.agachado ? 0 : j.corriendo ? 2 : 1;
      // frustum de la cámara (para no animar lo que no se ve, y para aparecer donde no miras)
      const cam = juego.camara;
      _pm.multiplyMatrices(cam.projectionMatrix, cam.matrixWorldInverse);
      _frustum.setFromProjectionMatrix(_pm);
      const lejos = this.lejos = F.Render.Vista.distanciaDibujo(juego.escena.ambiente);
      if (this.aparecedores.length) this._aparecedores(dt, j);

      for (const E of this.lista) {
        if (E.reserva) continue;
        if (E.cuerpo.mundo !== juego.mundo) E.cuerpo.mundo = juego.mundo;   // tras romper algo
        const dx = P.x - E.cuerpo.pie.x, dz = P.z - E.cuerpo.pie.z, d2 = dx * dx + dz * dz;
        // LOD por distancia: 0 cerca, 1 medio, 2 dormido
        const dd = this._dDormir || (this._dDormir = Math.max(10, +((juego.proyecto.ajustes || {}).distEnemigos) || 50) ** 2);
        E.lod = d2 < dd / 4 ? 0 : d2 < dd ? 1 : 2;
        if (E.tapado && E.lod === 0) E.lod = 1;   // detrás de una pared (gestor): piensa y se anima menos
        if (E.muerto) { this._muerto(E, dt); continue; }
        // lejos duerme, salvo si está en plena acción (cazando, huyendo, atacando): eso termina siempre
        if (E.lod === 2 && !ACTIVOS.has(E.estado)) {
          E.obj.visible = d2 < lejos * lejos && !E.tapado;
          continue;
        }
        E.obj.visible = !E.tapado;
        // 🧠 inteligencia por niveles (veces por segundo, en TIEMPO real, no en cuadros):
        //   cerca y en acción (cazando, atacando, huyendo) o viéndote: 8 · cerca y tranquilo: 4 · media distancia o tras una pared: 2
        const activo = ACTIVOS.has(E.estado) || E.viendo;
        E.cadaPensar = E.lod === 0 ? (activo ? 0.125 : 0.25) : 0.5;
        // repartidos: cada enemigo empieza en un momento distinto, así no piensan (ni lanzan rayos de visión) todos a la vez
        if (E.tPensar === undefined || E.tPensar > E.cadaPensar) E.tPensar = Math.random() * E.cadaPensar;
        E.tPensar -= dt;
        if (E.tPensar <= 0) { E.tPensar += E.cadaPensar; this._pensar(E, j, E.cadaPensar); }
        if (E.c.escudo > 0 || E.c.esquiva > 0) this._tactica(E, j, dt);
        this._mover(E, E.blanco, dt, j);
        // animación: cerca cada cuadro, medio cada 3, fuera de cámara nada
        if (E.mixer) {
          E.animAcum += dt;
          _esfera.center.copy(E.cuerpo.pie); _esfera.center.y += E.c.altura * 0.5; _esfera.radius = E.c.altura;
          const seVe = !E.tapado && _frustum.intersectsSphere(_esfera);
          // 🎞 animación a ritmo fijo (estilo PS1, y no depende de los fps): cerca 30 veces/s · media distancia 15 · fuera de cámara nada
          const ritmo = E.lod === 0 ? 1 / 30 : 1 / 15;
          if (seVe && E.animAcum >= ritmo) { E.mixer.update(E.animAcum); E.animAcum = 0; }
          else if (!seVe && E.animAcum > 1) E.animAcum = 1;   // al volver a verse no da un salto enorme
        }
        if (E.est) F.Estados.ticEnemigo(this, E, dt);
        if (E.flash > 0) {
          E.flash -= dt;
          this._destello(E, E.flash > 0 ? 0.9 : 0);
        } else if (this.aviso && E.estado === 'anticipar') {
          // ⚠ aviso de ataque (módulo Combate): parpadea en su color mientras se prepara
          E.flashCol = 'aviso';
          this._destello(E, Math.floor(performance.now() / 90) % 2 ? 0.9 : 0);
        } else if (E.propios && E.propios[0] === 'a') this._destello(E, 0);
      }
      this._separar(j);
      if (this.manchas) this._manchas();
      this._moverBalas(dt);
      if (this.hayJefes && this.cuadro % 4 === 0) this._hudJefe(j);
      // los ruidos viejos se olvidan
      if (this.ruidos.length) this.ruidos = this.ruidos.filter((r) => this.t - r.t < 0.5);
    }

    /* ---------- PENSAR (unas 8 veces por segundo) ---------- */
    _pensar(E, j, dtp) {
      const c = E.c, pie = E.cuerpo.pie;
      // ¿está en el agua? (terrestres; los acuáticos lo miran cada cuadro al moverse)
      const agua = this.juego.agua;
      if (!E.nada) E.enAgua = agua && agua.lista.length ? agua.en(pie.x, pie.y + c.altura * 0.5, pie.z) : null;
      // líquido que quema (lava, ácido): daño del tipo que toca (sus resistencias cuentan: res_fuego 0 = inmune a la lava)
      const liq = E.enAgua || (!E.nada && agua && agua.lista.length ? agua.en(pie.x, pie.y + 0.2, pie.z) : null);
      if (liq && liq.c.dano > 0) this.danar(E, liq.c.dano * dtp, { tipo: liq.c.liquido === 'lava' ? 'fuego' : 'veneno', liquido: true });
      if (E.muerto) return;
      const b = E.blanco = this._elegirBlanco(E, j, dtp);
      let ve = false, dist = Infinity, oido = null, P = null;
      if (b) {
        P = b.cuerpo.pie;
        const ojoY = E.vol ? pie.y + c.radio : pie.y + c.altura * 0.85;
        const dx = P.x - pie.x, dy = P.y + (b === j ? 1.2 : b.cuerpo.altura * 0.6) - ojoY, dz = P.z - pie.z;
        dist = Math.sqrt(dx * dx + dy * dy + dz * dz);
        // 🔦 la linterna encendida delata: te ven desde más lejos, y si los alumbras te ven aunque no te miren
        const L = b === j && j.linterna && j.linterna.on && j.linterna.veEnemigo && c.veLinterna !== false ? j.linterna : null;
        let alumbrado = false;
        if (L) {
          const lx = pie.x - L.pos.x, ly = ojoY - L.pos.y, lz = pie.z - L.pos.z, ld = Math.hypot(lx, ly, lz) || 1;
          alumbrado = ld < L.alcance && (lx * L.dir.x + ly * L.dir.y + lz * L.dir.z) / ld > Math.cos((L.angulo / 2 + 4) * DEG);
        }
        const verHasta = c.vision * (E.estado === 'perseguir' ? 1.3 : 1) * (L ? 1.6 : 1) + (alumbrado ? L.alcance : 0);
        // ¿lo ve? alcance → cono (persiguiendo o huyendo vale todo alrededor) → rayo por el BVH
        if (!b.muerto && dist < verHasta) {
          let enCono = alumbrado || c.angulo >= 360 || (ACTIVOS.has(E.estado) && E.estado !== 'aturdido');
          if (!enCono) {
            const fx = Math.sin(E.yaw), fz = Math.cos(E.yaw), h = Math.hypot(dx, dz) || 1;
            enCono = (fx * dx + fz * dz) / h >= Math.cos((c.angulo / 2) * DEG);
          }
          if (enCono) {
            const g = this.juego.mundo.rayo(pie.x, ojoY, pie.z, dx / dist, dy / dist, dz / dist, dist);
            ve = !g || g.t >= dist - 0.3;
          }
        }
        if (ve || (E.sabe && b === j)) { E.ultima.copy(P); E.recuerdo = c.memoria; }   // en las oleadas siempre saben dónde estás
        else if (E.recuerdo > 0) E.recuerdo -= dtp;
        // ¿te oye? (sin rayos; nunca bloquea la vista). Solo al jugador
        if (!ve && b === j && IDLE.has(E.estado)) {
          const radioPasos = this.ruidoPasos === 2 ? c.oidoCorrer : this.ruidoPasos === 1 ? c.oidoCaminar : 0;
          if (radioPasos > 0 && dist < radioPasos) oido = P;
          for (const r of this.ruidos) {
            const rx = r.x - pie.x, rz = r.z - pie.z;
            if (rx * rx + rz * rz < (c.oidoDisparo * r.fuerza) ** 2) { oido = r; break; }
          }
        }
      }
      E.dist = dist;
      E.viendo = ve;

      switch (E.estado) {
        case 'quieto':
        case 'deambular':
        case 'buscar':
          if (E.comer > 0) { E.comer -= dtp; if (E.comer <= 0) this._ir(E, this._inicial(E)); break; }
          if (b && (ve || (E.sabe && b === j))) { this._reaccionar(E, b, E.sabe); this._alertar(E, b); break; }
          if (oido) {
            if (this._huye(E)) { this._reaccionar(E, b); break; }
            E.meta.set(oido.x, pie.y, oido.z); this._ir(E, 'buscar', 4); E.giraHacia = true; break;
          }
          if (E.estado === 'buscar') {
            E.t -= dtp;
            if (E.t <= 0) this._calmar(E);
            else if (this._llego(E, 0.8)) this._puntoCerca(E, E.ultima.lengthSq() ? E.ultima : E.casa, 4);
          } else if (E.estado === 'deambular') {
            if (E.ruta) {
              // patrulla: punto a punto, esperando en cada uno
              const pt = E.ruta[E.iRuta];
              if (E.espera > 0) E.espera -= dtp;
              else {
                E.meta.copy(pt.pos);
                if (this._llego(E, 0.6)) { E.espera = pt.espera; E.iRuta = (E.iRuta + 1) % E.ruta.length; }
              }
            } else if (this._llego(E, 0.6) || Math.random() < 0.01) this._puntoCerca(E, E.casa, c.radioDeambular);
          } else {
            E.meta.copy(E.casa);
          }
          break;
        case 'orden':
          // 🛡 aliado: va donde manda la orden (motor/aliados.js pone metaOrden); si ve a un enemigo, a pelear
          if (b && ve) { this._reaccionar(E, b, false); break; }
          E.meta.copy(E.metaOrden || pie);
          break;
        case 'perseguir': {
          if (!b) { this._calmar(E); break; }
          // acuático que salta fuera del agua para morderte en la orilla
          if (E.nada && c.saltaFuera && ve && E.cd <= 0 && E.enAgua && !E.salto && agua && !agua.en(P.x, P.y + 0.5, P.z)
            && Math.hypot(P.x - pie.x, P.z - pie.z) <= c.alcanceSalto) { this._saltoFuera(E, b); break; }
          if (!ve && E.recuerdo <= 0) { this._ir(E, 'buscar', 5); this._puntoCerca(E, E.ultima, 3); break; }
          E.meta.copy(ve ? P : E.ultima);
          if (!ve && this._llego(E, 0.8)) { this._ir(E, 'buscar', 5); this._puntoCerca(E, E.ultima, 3); break; }
          if (ve && E.cd <= 0 && this._enAlcance(E, dist)) {
            // ⚠ con el aviso del módulo Combate, el ataque se prepara al menos su tiempo mínimo (para poder reaccionar)
            this._ir(E, 'anticipar', Math.max(c.anticipacion || 0, (this.aviso && this.aviso.minimo) || 0));
            if (c.sonidoAtaque) F.Audio.efecto(c.sonidoAtaque);
            else if (this.aviso && this.aviso.sonido) F.Audio.sintetico('impacto', { volumen: 0.35, tono: 1.9 });
          }
          break;
        }
        case 'cubrirse': {
          // va a su cobertura y espera a recargar el escudo (o un rato si no tiene); luego vuelve a por ti
          E.t -= dtp;
          const listo = c.escudo > 0 ? E.escudo >= c.escudo * 0.9 : E.t <= 0;
          if (!b || listo || E.t < -6) { E.cubierto = false; this._ir(E, b ? 'perseguir' : this._inicial(E)); break; }
          if (this._llego(E, 0.7)) E.cubierto = true;
          break;
        }
        case 'huir': {
          if (!b) { this._calmar(E); break; }
          if (ve || dist < c.oidoCorrer) E.t = Math.max(E.t, c.memoria + 1.5);
          E.t -= dtp;
          if (E.t <= 0) { this._calmar(E); break; }
          this._rumbo(E, b);
          break;
        }
        default:
          break;
      }
    }

    // salto de un acuático fuera del agua: llega a ti en lo más alto y vuelve a caer (al agua o a la orilla)
    _saltoFuera(E, b) {
      const c = E.c, P = b.cuerpo.pie, pie = E.cuerpo.pie, v = E.cuerpo.velocidad, g = 20;
      const h = Math.max(0.8, P.y + 1 - pie.y) + 0.4, vy = Math.sqrt(2 * g * h), tSub = vy / g;
      const dx = P.x - pie.x, dz = P.z - pie.z, d = Math.hypot(dx, dz) || 1, vh = Math.min(10, d / tSub);
      v.x = (dx / d) * vh; v.z = (dz / d) * vh; v.y = vy; E.vy = vy;
      E.cuerpo.enSuelo = false;
      E.salto = { t: 0, tv: tSub * 2, pego: false };
      E.yaw = Math.atan2(dx, dz);
      this._ir(E, 'atacar', tSub * 2 + 0.3);
      E.cd = c.enfriamiento;
      this._anim(E, 'attack');
      F.Audio.sintetico('aterrizar', { volumen: 0.7, tono: 0.6 });
      if (c.sonidoAtaque) F.Audio.efecto(c.sonidoAtaque);
    }

    _alertar(E, b) {
      if (E.c.sonidoAlerta) F.Audio.efecto(E.c.sonidoAlerta);
      F.emitir('enemigo-alerta', E);
      this._avisar(E, b);
      // la presa se entera de que la cazan (el pacífico huye, el neutral se defiende)
      const B = b && b.enemigo;
      if (B && !B.muerto && !B.amenaza && !this._huye(E)) { B.amenaza = E.yo; this._reaccionar(B, E.yo); }
    }

    _enAlcance(E, dist) {
      return dist <= E.c.alcance + (E.c.ataque === 'cuerpo' ? 0.3 : 0);
    }

    _llego(E, margen) {
      const dx = E.meta.x - E.cuerpo.pie.x, dz = E.meta.z - E.cuerpo.pie.z;
      return dx * dx + dz * dz < margen * margen;
    }

    _puntoCerca(E, centro, r) {
      const a = Math.random() * Math.PI * 2, k = Math.sqrt(Math.random()) * r;
      E.meta.set(centro.x + Math.cos(a) * k, centro.y, centro.z + Math.sin(a) * k);
    }

    /* ---------- MOVER (cada cuadro) ---------- */
    // b = su blanco (jugador o presa, puede ser null); jug = el jugador (pisotón)
    _mover(E, b, dt, jug) {
      const c = E.c, cu = E.cuerpo, pie = cu.pie, v = cu.velocidad, P = b ? b.cuerpo.pie : null;
      let vel = 0, mirar = null;
      if (!b && (E.estado === 'alerta' || E.estado === 'perseguir' || E.estado === 'anticipar' || E.estado === 'huir')) this._calmar(E);

      switch (E.estado) {
        case 'quieto': vel = 0; break;
        case 'orden': {
          const d = Math.hypot(E.meta.x - pie.x, E.meta.z - pie.z);
          vel = d < 0.6 ? 0 : d > 4 ? c.velCorrer : c.velocidad;
          if (vel === 0 && E.mirarOrden) mirar = E.mirarOrden;
          break;
        }
        case 'deambular': vel = E.espera > 0 ? 0 : c.velocidad * (E.ruta ? 1 : 0.7); break;
        case 'huir': vel = c.velCorrer; break;
        case 'cubrirse': vel = E.cubierto ? 0 : c.velCorrer; if (E.cubierto) mirar = P; break;
        case 'buscar': vel = c.velocidad; break;
        case 'alerta':
          E.t -= dt; mirar = P; vel = 0;
          if (E.t <= 0) this._ir(E, 'perseguir');
          break;
        case 'perseguir': {
          vel = c.velCorrer;
          // a distancia: mantener la distancia preferida (y moverse de lado un poco)
          if ((c.ataque === 'disparo' || c.ataque === 'proyectil') && E.viendo) {
            const d = E.dist || 99;
            mirar = P;
            if (d < c.distanciaIdeal - 1.5) vel = -c.velocidad;
            else if (d < c.distanciaIdeal + 1) vel = 0;
          }
          if (c.actitud === 'aliado' && E.orden && E.orden.tipo !== 'seguir' && E.viendo) vel = 0;   // 🛡 con "esperar" / "ir": dispara sin moverse
          break;
        }
        case 'anticipar':
          // quieto mirando al jugador: el aviso
          E.t -= dt; mirar = P; vel = 0;
          if (E.vol && c.ataque === 'picado') E.vy += 6 * dt;   // toma altura antes del picado
          if (E.t <= 0) { if (b) this._atacar(E, b); else this._calmar(E); }
          break;
        case 'atacar':
          E.t -= dt;
          if (E.embiste) vel = 0; else mirar = P;
          if (E.t <= 0 && !E.embiste && !E.salto && !E.picado) { if (b) this._ir(E, 'perseguir'); else this._calmar(E); }
          break;
        case 'aturdido':
          E.t -= dt; vel = 0;
          if (E.t <= 0) {
            if (!b) this._calmar(E);
            else if (this._huye(E)) { this._ir(E, 'huir', c.memoria + 1.5); this._rumbo(E, b); }
            else this._ir(E, 'perseguir');
          }
          break;
        default: break;
      }
      if (E.cd > 0) E.cd -= dt;
      if (E.fijo) vel = 0;
      if (E.enAgua && !E.nada && vel > 0) vel *= c.enAgua === 'fondo' ? 0.6 : 0.55;   // en el agua van más lentos

      // dirección hacia la meta
      let mx = E.meta.x - pie.x, mz = E.meta.z - pie.z;
      const md = Math.hypot(mx, mz);
      if (md > 0.01) { mx /= md; mz /= md; } else { mx = mz = 0; }
      if (E.estado === 'perseguir' && md < (c.ataque === 'cuerpo' ? c.alcance * 0.7 : 0.5) && vel > 0) vel = 0;
      if (E.estado === 'orden' && md < 0.6) vel = 0;

      // 💥 retroceso por golpe (módulo Combate): sale echado hacia atrás un instante y frena (no se cancela)
      if (E.retro && !E.embiste && !E.salto && !E.picado) {
        const r = E.retro;
        r.t -= dt;
        const k = Math.max(0, r.t / r.total);
        v.x = r.dx * r.vel * k; v.z = r.dz * r.vel * k;
        if (r.t <= 0 || cu.contactoPared) E.retro = null;
        if (P) mirar = P;
      } else
      // ↯ esquiva de lado (élite): rápida, corta, no se cancela con nada
      if (E.esq && !E.embiste && !E.salto && !E.picado) {
        E.esq.t -= dt;
        v.x = E.esq.dx * E.esq.vel; v.z = E.esq.dz * E.esq.vel;
        if (E.esq.t <= 0 || cu.contactoPared) E.esq = null;
        if (P) mirar = P;
      } else
      // ataques con movimiento propio
      if (E.embiste) {
        const em = E.embiste;
        em.t -= dt;
        v.x = em.dx * em.vel; v.z = em.dz * em.vel;
        if (b) this._golpeContacto(E, b, 0.6);
        // se termina por tiempo o al chocar con una PARED (el suelo no cuenta: en Godot sí y se cortaba al instante)
        if (em.t <= 0 || (cu.contactoPared && em.t < em.total - 0.08)) { E.embiste = null; this._ir(E, 'atacar', 0.5); E.cd = c.enfriamiento; }
      } else if (E.salto) {
        // en el aire corrige un poco hacia ti (como un animal que estira las patas), sin ser imposible de esquivar
        const sa = E.salto, resta = Math.max(0.15, sa.tv - sa.t);
        if (b) {
          const vj = b.cuerpo.velocidad;
          const qx = (P.x + vj.x * resta - pie.x) / resta, qz = (P.z + vj.z * resta - pie.z) / resta;
          const acel = 7 * dt;
          v.x += clamp(qx - v.x, -acel, acel);
          v.z += clamp(qz - v.z, -acel, acel);
          this._golpeContacto(E, b, 0.5);
        }
        const vuelveAlAgua = E.nada && E.salto.t > 0.3 && E.enAgua;
        if ((cu.enSuelo && E.salto.t > 0.1) || vuelveAlAgua) { E.salto = null; this._ir(E, 'atacar', 0.3); E.cd = c.enfriamiento; }
        if (E.salto) E.salto.t += dt;
      } else if (E.picado) {
        const pc = E.picado;
        pc.t -= dt;
        v.copy(pc.dir).multiplyScalar(pc.vel);
        if (b) this._golpeContacto(E, b, 0.5);
        if (pc.t <= 0 || cu.contactoPared || (cu.enSuelo && pc.t < pc.total - 0.1)) { E.picado = null; this._ir(E, 'atacar', 0.4); E.cd = c.enfriamiento; }
      } else if (E.nada && !E.enAgua) {
        // acuático fuera del agua: lo mueven sus saltitos de vuelta (en _moverAcuatico), no la persecución
      } else {
        // 'orilla': no entra al agua (se para en el borde y busca otro camino)
        const agua = this.juego.agua;
        const delante = !E.nada && !E.vol && !E.enAgua && vel > 0 && agua && agua.lista.length ? (agua.en(pie.x + mx * 0.7, pie.y + 0.3, pie.z + mz * 0.7) || agua.en(pie.x + mx * 0.7, pie.y - 0.8, pie.z + mz * 0.7)) : null;   // también un líquido algo más bajo que el suelo
        // nadie se mete en lava o ácido (salvo que sea inmune al fuego y sea lava); los de 'orilla' tampoco en agua
        const peligro = delante && delante.c.dano > 0 && !(delante.c.liquido === 'lava' && c.res_fuego === 0);
        if (delante && (c.enAgua === 'orilla' || peligro || delante.c.nadable === false)) {
          vel = 0;
          if (IDLE.has(E.estado)) this._puntoCerca(E, E.casa, c.radioDeambular);
          else if (E.estado === 'huir') E.desvio += 1.3;
        }
        const sx = E.sep.x, sz = E.sep.z;
        // paso lateral mientras dispara (cambia de lado cada poco o al chocar)
        let lat = 0;
        if (c.lateral > 0 && E.viendo && (E.estado === 'perseguir' || E.estado === 'anticipar') && (c.ataque === 'disparo' || c.ataque === 'proyectil')) {
          E.tLat -= dt;
          if (E.tLat <= 0 || cu.contactoPared) { E.ladoLat = -E.ladoLat; E.tLat = 0.8 + Math.random() * 1.4; }
          lat = c.lateral * E.ladoLat;
        }
        const objetivoX = mx * vel + sx - mz * lat, objetivoZ = mz * vel + sz + mx * lat;
        const k = Math.min(1, dt * (cu.enSuelo || E.vol ? 8 : 1.5));
        v.x += (objetivoX - v.x) * k;
        v.z += (objetivoZ - v.z) * k;
        if (vel !== 0 && !mirar) mirar = _v2.set(pie.x + mx, pie.y, pie.z + mz);
      }

      // vertical: acuático (dentro del agua), volador (muelle sobre el suelo), terrestre (gravedad; en el agua flota)
      if (E.nada) {
        this._moverAcuatico(E, b, P, dt, jug);
      } else if (E.vol) {
        E.tSuelo -= dt;
        if (E.tSuelo <= 0) {
          E.tSuelo = 0.5;
          const M = this.juego.mundo;
          const ab = M.rayo(pie.x, pie.y, pie.z, 0, -1, 0, 40);
          E.sueloY = ab ? pie.y - ab.t : E.casa.y;
          const ar = M.rayo(pie.x, pie.y, pie.z, 0, 1, 0, 20);
          E.techoY = ar ? pie.y + ar.t : Infinity;
        }
        if (!E.picado) {
          let meta = E.sueloY + c.alturaVuelo + Math.sin(this.t * 2 + E.fase) * c.flotar;
          // persiguiendo baja hacia la altura del jugador (sin pasar del suelo + 1)
          if (P && (E.estado === 'perseguir' || E.estado === 'atacar')) meta = Math.max(E.sueloY + 1, Math.min(meta, P.y + c.alturaVuelo * 0.6));
          meta = Math.min(meta, E.techoY - c.radio - 0.3);
          E.vy += ((meta - pie.y) * 14 - E.vy * 5) * dt;   // muelle con amortiguación
          v.y = E.vy;
        }
      } else if (!E.fijo) {
        if (E.enAgua && E.enAgua.c.nadable !== false && c.enAgua !== 'fondo' && !E.salto) {
          // nada: flota con la cabeza fuera (los de 'orilla' que acaban en el agua también nadan para salir)
          const meta = E.enAgua.top - c.altura * 0.65;
          v.y += ((meta - pie.y) * 4 - v.y) * Math.min(1, dt * 4);
        } else if (!cu.enSuelo) v.y -= (E.enAgua ? 8 : 20) * dt;
        else if (v.y < 0) v.y = 0;
      }
      if (!E.fijo) cu.moverYDeslizar(dt);
      if (E.vol && !E.picado) E.vy = v.y;

      // girar hacia donde va o hacia el jugador (sin pasarse: en Godot el slerp con peso 8 se pasaba)
      if (mirar) {
        const objetivo = Math.atan2(mirar.x - pie.x, mirar.z - pie.z);
        let dif = objetivo - E.yaw;
        dif = Math.atan2(Math.sin(dif), Math.cos(dif));
        const paso = c.giro * dt;
        E.yaw += Math.abs(dif) <= paso ? dif : Math.sign(dif) * paso;
      }
      E.obj.position.set(pie.x, E.vol ? pie.y + c.radio : cu.visY, pie.z);
      E.visual.rotation.y = E.yaw;

      // animación / figura
      const rapidez = Math.hypot(v.x, v.z);
      if (E.estado !== 'aturdido' && E.estado !== 'atacar' && E.estado !== 'anticipar') {
        if (E.nada) this._anim(E, 'swim');
        else if (E.vol) this._anim(E, 'fly');
        else this._anim(E, rapidez > c.velocidad * 1.2 ? 'run' : rapidez > 0.3 ? 'walk' : 'idle', rapidez > 0.3 ? clamp(rapidez / Math.max(0.5, c.velocidad), 0.6, 2) : 1);
      }
      // sin animaciones (figura del motor) o con un modelo al que le faltan: movimiento hecho por el motor
      if (!E.acc) this._figuraViva(E, rapidez, dt, false);
      else if (!E.acc.attack || !E.acc.hurt) this._figuraViva(E, rapidez, dt, true);
      // pisotón estilo Mario
      if (c.pisable && jug) this._pisar(E, jug);
    }

    // acuático: se mueve en 3D dentro del agua y no sale de ella (salvo saltando); fuera, coletea hacia el agua
    _moverAcuatico(E, b, P, dt, jug) {
      const c = E.c, cu = E.cuerpo, pie = cu.pie, v = cu.velocidad, agua = this.juego.agua;
      let w = agua && agua.lista.length ? agua.en(pie.x, pie.y + c.radio, pie.z) : null;
      if (w && (w.c.dano > 0 || w.c.nadable === false)) w = null;   // los peces no viven en lava ni ácido
      E.enAgua = w;
      if (w && !E.salto) {
        E.varado = false;
        E.tSuelo -= dt;
        if (E.tSuelo <= 0) {
          E.tSuelo = 0.5;
          const ab = this.juego.mundo.rayo(pie.x, pie.y + c.radio, pie.z, 0, -1, 0, 40);
          E.sueloY = ab ? pie.y + c.radio - ab.t : w.caja.min.y;
        }
        const fondo = Math.max(E.sueloY, w.caja.min.y) + 0.05, techo = w.top - c.radio * 2.2;
        if (E.prof === undefined) E.prof = 0.3 + Math.random() * 0.5;
        let meta = fondo + Math.max(0, techo - fondo) * E.prof + Math.sin(this.t * 1.5 + E.fase) * 0.12;
        if (P && E.estado !== 'huir' && ACTIVOS.has(E.estado)) meta = P.y + (b === jug ? 0.9 : b.cuerpo.altura * 0.5) - c.radio;
        if (E.estado === 'huir') meta = fondo;                 // se esconde en el fondo
        meta = clamp(meta, fondo, Math.max(fondo, techo));
        E.vy += ((meta - pie.y) * 6 - E.vy * 4) * dt;
        v.y = E.vy;
        // no sale por los lados: si el siguiente paso queda fuera del agua, rebota y busca otro sitio
        const sig = agua.en(pie.x + v.x * 0.35, pie.y + c.radio, pie.z + v.z * 0.35);
        if (!sig || sig.c.dano > 0 || sig.c.nadable === false) {
          v.x *= -0.2; v.z *= -0.2;
          if (IDLE.has(E.estado)) this._puntoCerca(E, E.casa, c.radioDeambular);
          else if (E.estado === 'huir') E.desvio += 1.3;
        }
      } else {
        // fuera del agua (saltó o lo sacaron): cae; en el suelo da saltitos hacia el agua (hacia su casa)
        v.y -= 20 * dt;
        if (cu.enSuelo && !E.salto) {
          const dx = E.casa.x - pie.x, dz = E.casa.z - pie.z, d = Math.hypot(dx, dz) || 1;
          v.x = (dx / d) * 2.5; v.z = (dz / d) * 2.5; v.y = 3.5;
          cu.enSuelo = false;
          E.varado = true;
        }
        E.vy = v.y;
      }
    }

    // sin animaciones: la figura del motor se mece al caminar, aletea y se inclina al atacar
    _figuraViva(E, rapidez, dt, soloInclinar) {
      const vis = E.visual;
      if (soloInclinar) {
        // modelo con animaciones pero sin "attack"/"hit": solo se inclina al atacar o al recibir daño
        const ataca = !E.acc.attack && (E.estado === 'anticipar' || E.estado === 'atacar');
        const duele = !E.acc.hurt && E.estado === 'aturdido';
        const k = ataca ? (E.estado === 'anticipar' ? -0.25 : 0.35) : duele ? -0.3 : 0;
        vis.rotation.x += (k - vis.rotation.x) * Math.min(1, dt * 12);
        return;
      }
      E.fase += dt * (4 + rapidez * 2);
      if (E.obj.userData.cola) {
        // pez: la cola se mueve (más rápido nadando deprisa); varado, se sacude
        E.obj.userData.cola.rotation.y = Math.sin(this.t * (rapidez > 2 ? 16 : 7) + E.fase) * 0.5;
        vis.rotation.z = E.varado ? Math.sin(this.t * 22) * 0.5 : vis.rotation.z * 0.8;
        return;
      }
      if (E.obj.userData.alas) {
        const [ai, ad] = E.obj.userData.alas, a = Math.sin(this.t * (E.picado ? 6 : 14) + E.fase) * (E.picado ? 0.2 : 0.7);
        ai.rotation.z = a; ad.rotation.z = -a;
      } else if (!E.fijo) {
        vis.position.y = rapidez > 0.3 ? Math.abs(Math.sin(E.fase)) * 0.05 : 0;
      }
      const inclinar = E.estado === 'anticipar' ? -0.25 : E.estado === 'atacar' ? 0.35 : E.estado === 'aturdido' ? -0.3 : 0;
      vis.rotation.x += (inclinar - vis.rotation.x) * Math.min(1, dt * 12);
    }

    /* ---------- Atacar (tras la anticipación) ---------- */
    _atacar(E, j) {   // j = su blanco: el jugador o la "cara" de otro enemigo (misma forma)
      const c = E.c, pie = E.cuerpo.pie, P = j.cuerpo.pie;
      this._anim(E, 'attack');
      E.cd = c.enfriamiento;
      const ojo = _v.set(pie.x, E.vol ? pie.y + c.radio : pie.y + c.altura * 0.75, pie.z);
      const pecho = _v2.set(P.x, P.y + (j.enemigo ? j.cuerpo.altura * 0.55 : 1.1), P.z);
      const dir = pecho.clone().sub(ojo);
      const dist = dir.length();
      dir.divideScalar(dist || 1);
      this._ir(E, 'atacar', 0.35);
      // muy cerca, los ataques con carrera no tienen espacio: golpe corto
      const tipo = (c.ataque === 'embestida' || c.ataque === 'salto' || c.ataque === 'picado') && dist < 1.8 ? 'cuerpo' : c.ataque;
      switch (tipo) {
        case 'cuerpo': {
          // ¿sigue delante y cerca? (puedes esquivarlo durante el aviso)
          const fx = Math.sin(E.yaw), fz = Math.cos(E.yaw), h = Math.hypot(P.x - pie.x, P.z - pie.z) || 1;
          const alc = c.ataque === 'cuerpo' ? c.alcance : 1.8;
          if (dist <= alc + 0.45 && (h < 0.5 || ((P.x - pie.x) * fx + (P.z - pie.z) * fz) / h > 0.3) && Math.abs(P.y - pie.y) < 2.2) this._pegar(E, j, dir);
          else F.Audio.sintetico('vacio', { volumen: 0.4, tono: 0.6 });
          break;
        }
        case 'disparo': {
          const disp = c.dispersion * DEG;
          dir.x += (Math.random() - 0.5) * disp * 2; dir.y += (Math.random() - 0.5) * disp * 2; dir.z += (Math.random() - 0.5) * disp * 2;
          dir.normalize();
          F.Audio.sintetico('disparo', { volumen: 0.6, tono: 0.8 + Math.random() * 0.2 });
          const pared = this.juego.mundo.rayo(ojo.x, ojo.y, ojo.z, dir.x, dir.y, dir.z, c.alcance);
          // ¿pasa cerca del jugador antes de la pared? (cápsula del jugador)
          const t = rayoCapsula(ojo, dir, pared ? pared.t : c.alcance, P.x, P.y, P.z, j.cuerpo.radio + 0.1, j.cuerpo.altura);
          if (t >= 0) this._pegar(E, j, dir);
          break;
        }
        case 'proyectil': this._lanzar(E, ojo, dir, j); break;
        case 'embestida': {
          const h = Math.hypot(P.x - pie.x, P.z - pie.z) || 1;
          E.embiste = { dx: (P.x - pie.x) / h, dz: (P.z - pie.z) / h, vel: c.velCorrer * 2.2, t: Math.min(1.2, (c.alcance + 2) / (c.velCorrer * 2.2)), total: 0, pego: false };
          E.embiste.total = E.embiste.t;
          E.yaw = Math.atan2(E.embiste.dx, E.embiste.dz);
          break;
        }
        case 'salto': {
          // tiro parabólico (gravedad 20) que cae donde VAS a estar: si te alejas, apunta más lejos.
          // El tiempo de vuelo crece con la distancia (saltos largos, más altos).
          const g = 20, vj = j.cuerpo.velocidad;   // eslint-disable-line
          const plano = Math.hypot(P.x - pie.x, P.z - pie.z);
          const tv = clamp(0.55 + plano * 0.045, 0.6, 1.05);
          const mx = P.x + vj.x * tv, mz = P.z + vj.z * tv;
          const v = E.cuerpo.velocidad;
          v.x = (mx - pie.x) / tv; v.z = (mz - pie.z) / tv;
          const hz = Math.hypot(v.x, v.z), max = 16;
          if (hz > max) { v.x *= max / hz; v.z *= max / hz; }
          v.y = (g * tv) / 2 + (P.y - pie.y) / tv;
          E.cuerpo.enSuelo = false;
          E.salto = { t: 0, tv, pego: false };
          break;
        }
        case 'picado': {
          if (!E.vol) { this._pegar(E, j, dir); break; }
          // un poco por delante de ti (la mitad de lo que avanzas mientras baja)
          const vj = j.cuerpo.velocidad, ade = Math.min(0.6, dist / (c.velCorrer * 2.2)) * 0.5;
          const d2 = _v.set(P.x + vj.x * ade, P.y + 0.9, P.z + vj.z * ade).sub(pie).normalize();
          const vel = c.velCorrer * 2.2;
          E.picado = { dir: d2.clone(), vel, t: Math.min(1.6, (dist + 2) / vel), total: 0, pego: false };
          E.picado.total = E.picado.t;
          break;
        }
        default: break;
      }
    }

    // pegarle al jugador (una vez por ataque en los de contacto)
    _pegar(E, j, dir) {
      if (j.danar && E.c.dano > 0) j.danar(E.c.dano, 'enemigo', E);
      const v = j.cuerpo.velocidad, emp = E.c.empuje;
      if (emp > 0) { v.x += dir.x * emp; v.z += dir.z * emp; if (j.cuerpo.enSuelo) v.y = Math.max(v.y, emp * 0.35); }
      if (!j.enemigo) F.emitir('jugador-golpeado', { enemigo: E, jugador: j });
    }

    _golpeContacto(E, j, extra) {
      const a = E.embiste || E.salto || E.picado;
      if (!a || a.pego) return;
      const pie = E.cuerpo.pie, P = j.cuerpo.pie;
      const dx = P.x - pie.x, dz = P.z - pie.z, r = E.c.radio + j.cuerpo.radio + extra;
      const dy = (P.y + 0.9) - (E.vol ? pie.y + E.c.radio : pie.y + E.c.altura * 0.5);
      if (dx * dx + dz * dz < r * r && Math.abs(dy) < 1.4) {
        a.pego = true;
        const h = Math.hypot(dx, dz) || 1;
        this._pegar(E, j, _v.set(dx / h, 0, dz / h));
      }
    }

    // caerle encima: lo pisa (y rebota)
    _pisar(E, j) {
      const jc = j.cuerpo, P = jc.pie, pie = E.cuerpo.pie;
      if (jc.velocidad.y >= -0.5) return;
      const arriba = E.vol ? pie.y + E.c.radio * 2 : pie.y + E.c.altura;
      const dx = P.x - pie.x, dz = P.z - pie.z, r = E.c.radio + jc.radio;
      if (dx * dx + dz * dz < r * r && P.y <= arriba + 0.25 && P.y >= arriba - 0.45) {
        jc.velocidad.y = 9;
        jc.pie.y = arriba + 0.05;
        this.danar(E, E.c.danoPisar, { tipo: 'normal', pisoton: true });
        F.Audio.sintetico('aterrizar', { volumen: 0.9, tono: 1.3 });
      }
    }

    /* ---------- Proyectiles enemigos (pool fijo) ---------- */
    _lanzar(E, desde, dir, blanco) {
      const b = this.balas.find((x) => !x.activa);
      if (!b) return;
      b.activa = true;
      b.de = E;
      b.blanco = blanco;
      b.pos.copy(desde).addScaledVector(dir, E.c.radio + 0.2);
      b.vel.copy(dir).multiplyScalar(E.c.velProyectil);
      b.vida = (E.c.alcance * 1.4) / E.c.velProyectil;
      b.dano = E.c.dano;
      b.sp.material.color.set(this.aviso && this.aviso.balas ? '#3aff6a' : E.c.colorProyectil);   // 🛡 verde = se puede devolver con un parry
      b.devuelta = false;
      b.sp.position.copy(b.pos);
      b.sp.visible = true;
      F.Audio.sintetico('aterrizar', { volumen: 0.5, tono: 1.6 });
    }

    _moverBalas(dt) {
      if (!this.balas.length) return;
      const M = this.juego.mundo;
      for (const b of this.balas) {
        if (!b.activa) continue;
        b.vida -= dt;
        const paso = b.vel.length() * dt;
        const dir = _v.copy(b.vel).normalize();
        const pared = M.rayo(b.pos.x, b.pos.y, b.pos.z, dir.x, dir.y, dir.z, paso);
        let pega = false;
        // 🛡 devuelta con un parry: ahora le da al primer enemigo que cruce
        if (b.devuelta) {
          for (const E of this.lista) {
            if (E.muerto) continue;
            const t = rayoCapsula(b.pos, dir, pared ? pared.t : paso, E.cuerpo.pie.x, E.cuerpo.pie.y, E.cuerpo.pie.z, (E.cuerpo.radio || 0.4) + 0.1, E.cuerpo.altura || 1.8);
            if (t >= 0) { this.danar(E, b.dano * 2, { tipo: 'normal', devuelta: true }); F.Audio.sintetico('impacto', { volumen: 0.8, tono: 1.2 }); pega = true; break; }
          }
          if (pega || pared || b.vida <= 0) { b.activa = false; b.sp.visible = false; continue; }
          b.pos.addScaledVector(b.vel, dt); b.sp.position.copy(b.pos);
          continue;
        }
        const j = b.blanco || this.juego.jugador;   // solo le da a quien apuntaba
        if (j && !j.muerto) {
          const P = j.cuerpo.pie;
          const t = rayoCapsula(b.pos, dir, pared ? pared.t : paso, P.x, P.y, P.z, j.cuerpo.radio + 0.1, j.cuerpo.altura);
          if (t >= 0) pega = true;
        }
        if (pega && j.alDesviar && j.alDesviar(b)) {
          // 🛡 parry a un proyectil: vuelve por donde vino, más rápido, contra los enemigos
          b.vel.multiplyScalar(-1.4); b.devuelta = true; b.vida = Math.max(b.vida, 2);
          b.sp.material.color.set('#ffffff');
          b.pos.addScaledVector(b.vel, dt * 2); b.sp.position.copy(b.pos);
          continue;
        }
        if (pega) { if (j.danar) j.danar(b.dano, 'enemigo', b.de); F.Audio.sintetico('impacto', { volumen: 0.6 }); }
        if (pega || pared || b.vida <= 0) { b.activa = false; b.sp.visible = false; continue; }
        b.pos.addScaledVector(b.vel, dt);
        b.sp.position.copy(b.pos);
      }
    }

    /* ---------- Separación: entre enemigos (en la decisión) y del jugador (cada cuadro, barato) ---------- */
    _separar(j) {
      const L = this.lista, P = j.cuerpo.pie;
      for (let a = 0; a < L.length; a++) {
        const A = L[a];
        if (A.muerto || A.lod === 2) continue;
        if ((this.cuadro + a) % 3 === 0) {
          A.sep.set(0, 0, 0);
          for (let b = 0; b < L.length; b++) {
            if (a === b) continue;
            const B = L[b];
            if (B.muerto || B.lod === 2) continue;
            if (Math.abs(A.cuerpo.pie.y - B.cuerpo.pie.y) > Math.max(A.c.altura, B.c.altura)) continue;   // otra planta
            const dx = A.cuerpo.pie.x - B.cuerpo.pie.x, dz = A.cuerpo.pie.z - B.cuerpo.pie.z;
            const r = A.c.radio + B.c.radio + 0.25, d2 = dx * dx + dz * dz;
            if (d2 < r * r && d2 > 1e-6) { const d = Math.sqrt(d2), k = (r - d) / r * 3; A.sep.x += (dx / d) * k; A.sep.z += (dz / d) * k; }
          }
        }
        // el jugador no atraviesa enemigos (empujón horizontal)
        if (A.vol && Math.abs(A.cuerpo.pie.y + A.c.radio - (P.y + 0.9)) > 1.2) continue;
        const dx = P.x - A.cuerpo.pie.x, dz = P.z - A.cuerpo.pie.z, r = A.c.radio + j.cuerpo.radio;
        const d2 = dx * dx + dz * dz;
        // a la misma altura: el de la planta de arriba (o de abajo) no empuja
        if (d2 < r * r && d2 > 1e-6 && (A.vol || (P.y < A.cuerpo.pie.y + A.c.altura - 0.2 && P.y + j.cuerpo.altura > A.cuerpo.pie.y + 0.2))) {
          const d = Math.sqrt(d2), k = r - d, ux = dx / d, uz = dz / d;
          // hasta dónde puede ir el jugador sin meterse en la pared (rayos a media altura y a los pies)
          let libre = k;
          const M = this.juego.mundo;
          if (M) for (const h of [0.3, 1.0]) {
            const g = M.rayo(P.x, P.y + h, P.z, ux, 0, uz, k + j.cuerpo.radio + 0.05);
            if (g) libre = Math.min(libre, Math.max(0, g.t - j.cuerpo.radio - 0.02));
          }
          P.x += ux * libre; P.z += uz * libre;
          // lo que no cabe lo pone el enemigo: retrocede él (y si venía embistiendo, se para: no te aplasta contra la pared)
          const resto = k - libre;
          if (resto > 0.001) {
            A.cuerpo.pie.x -= ux * resto; A.cuerpo.pie.z -= uz * resto;
            if (A.embiste) { A.embiste = null; A.cd = A.c.enfriamiento; this._ir(A, 'atacar', 0.4); }
          }
        }
      }
    }

    /* ---------- Muerte: cae, queda y desaparece parpadeando ---------- */
    _muerto(E, dt) {
      E.tMuerte += dt;
      const cu = E.cuerpo, v = cu.velocidad;
      v.x *= Math.max(0, 1 - dt * 6); v.z *= Math.max(0, 1 - dt * 6);
      const agua = this.juego.agua;
      const w = E.nada && agua && agua.lista.length ? agua.en(cu.pie.x, cu.pie.y + E.c.radio, cu.pie.z) : null;
      if (w) { v.y = cu.pie.y < w.top - E.c.radio * 2 ? 0.8 : 0; cu.enSuelo = false; }   // sube a flotar
      else if (!cu.enSuelo) v.y -= 20 * dt;
      if (!E.fijo && (E.tMuerte < 3 || !cu.enSuelo || w)) cu.moverYDeslizar(dt);
      E.obj.position.set(cu.pie.x, E.vol ? cu.pie.y + E.c.radio : cu.visY, cu.pie.z);
      if (E.mixer && E.lod < 2) E.mixer.update(dt);
      if (!E.acc || !E.acc.die) {
        E.visual.rotation.y = E.yaw;
        // se cae de lado
        const k = Math.min(1, E.tMuerte / 0.45);
        E.visual.rotation.x = 0;
        E.visual.rotation.z = (E.nada ? Math.PI : Math.PI / 2) * k;   // los peces, panza arriba
        if (E.vol && E.obj.userData.cuerpoVol) E.obj.userData.cuerpoVol.position.y = E.c.radio * k;
      }
      if (E.flash > 0) { E.flash -= dt; this._destello(E, E.flash > 0 ? 0.9 : 0); }
      // los que saca un aparecedor siempre desaparecen (si no, se amontonan) y vuelven a la reserva
      const fin = E.c.desaparecer > 0 ? E.c.desaparecer : E.generado ? 8 : 0;
      if (fin > 0 && E.tMuerte > fin) {
        const resta = E.tMuerte - fin;
        E.obj.visible = resta < 1.2 && Math.floor(resta * (6 + resta * 14)) % 2 === 0;
        if (resta >= 1.2) { E.obj.visible = false; E.fuera = true; if (E.generado) this._aReserva(E); }
      }
    }

    /* =========================================================
       APARECEDORES: zonas que van sacando criaturas y arenas de oleadas.
       Lo que sale no se crea cada vez: los muertos vuelven a una reserva por molde y se reutilizan
       (sin compilar shaders ni clonar modelos en mitad de la partida).
       ========================================================= */
    // ref = id de una criatura de la biblioteca (o, como respaldo, el nombre de un enemigo de la escena o de un preajuste)
    _molde(ref) {
      if (!ref) return null;
      const cr = (this.juego.proyecto.criaturas || []).find((c) => c.id === ref);
      if (cr) {
        const kc = '#' + cr.id;
        if (!this.moldes.has(kc)) this.moldes.set(kc, { clave: 'c:' + cr.id, nombre: cr.nombre, cfg: cr.enemigo, sombra: true });
        return this.moldes.get(kc);
      }
      const k = norm(ref);
      if (this.moldes.has(k)) return this.moldes.get(k);
      let m = null;
      for (const [pk, pr] of Object.entries(PRESETS)) {
        if (norm(pk) !== k && norm(pr.nombre) !== k) continue;
        const { nombre: nn, ...cfg } = pr;
        m = { clave: 'p:' + pk, nombre: nn, cfg, sombra: true };
        break;
      }
      if (!m) console.warn('[Forja] Aparecedor: no existe la criatura "' + ref + '"');
      this.moldes.set(k, m);
      return m;
    }

    _nuevoAparecedor(ent, obj) {
      const c = { ...APARECEDOR, ...(ent.aparecedor || {}) };
      const tabla = (c.salen || []).map((x) => ({ m: this._molde(x.criatura), n: Math.max(1, x.n | 0) })).filter((x) => x.m);
      const pts = c.puntos && this.rutas.get(norm(c.puntos));
      return {
        ent, c, pos: obj.getWorldPosition(new T.Vector3()), tabla, peso: tabla.reduce((s, x) => s + x.n, 0),
        puntos: pts && pts.length ? pts : null, vivos: [], t: Math.random() * 0.25, cuenta: c.cada, lleno: false,
        fase: 'espera', n: 0, cola: [], t2: 0, tSacar: 0, fallos: 0, fuerzaK: 1, totalN: 0, texto: '',
        apagado: c.modo !== 'oleadas' && c.encendido === false,   // zona apagada hasta que la enciendan
      };
    }

    _elegirMolde(A) {
      if (!A.peso) return null;
      let r = Math.random() * A.peso;
      for (const x of A.tabla) { r -= x.n; if (r <= 0) return x.m; }
      return A.tabla[A.tabla.length - 1].m;
    }

    // 🥚 encender / apagar un aparecedor desde una palanca o un disparador (zona: sale o no; oleadas: empiezan)
    activarAparecedor(entId, on = true) {
      for (const A of this.aparecedores) {
        if (A.ent.id !== entId) continue;
        A.apagado = !on;
        if (on && A.c.modo === 'oleadas' && A.fase === 'espera') { A.fase = 'descanso'; A.t2 = 1.5; }
      }
    }

    // ☠ despertar (arena, emboscada): sabe dónde estás y va a por ti
    despertar(entId) {
      const j = this.juego.jugador;
      if (!j) return;
      for (const E of this.lista) {
        if (E.ent.id !== entId || E.muerto) continue;
        E.sabe = true;
        E.amenaza = j;
        this._reaccionar(E, j, false);
        this._alertar(E, j);
      }
    }

    _aparecedores(dt, j) {
      for (const A of this.aparecedores) {
        if (A.apagado) continue;
        A.t -= dt;
        if (A.t > 0) continue;
        A.t += 0.25;
        A.vivos = A.vivos.filter((E) => E.de === A && !E.muerto);
        if (A.c.modo === 'oleadas') this._arena(A, j, 0.25);
        else this._zona(A, j, 0.25);
      }
    }

    _zona(A, j, paso) {
      const c = A.c, P = j.cuerpo.pie;
      // al empezar: la zona ya está poblada (nadie la ha visto todavía)
      if (!A.lleno) {
        A.lleno = true;
        if (c.alInicio) for (let i = 0; i < c.maximo; i++) this._sacar(A, this._elegirMolde(A), false);
        return;
      }
      // los que quedan muy lejos y no se ven se retiran (así siempre hay criaturas cerca, pero nunca las mismas)
      if (c.desaparecerLejos > 0) {
        const L2 = c.desaparecerLejos * c.desaparecerLejos;
        for (const E of A.vivos) {
          const pe = E.cuerpo.pie, dx = pe.x - P.x, dz = pe.z - P.z;
          if (dx * dx + dz * dz > L2 && !ACTIVOS.has(E.estado) && !this._enVista(pe.x, pe.y + E.c.altura * 0.5, pe.z, E.c.altura)) this._aReserva(E);
        }
      }
      const dx = P.x - A.pos.x, dz = P.z - A.pos.z;
      if (dx * dx + dz * dz > (c.activa + c.radio) ** 2) {
        // 🚪 saliste de la zona: los que no te persiguen ni ves se retiran y al volver la zona se llena otra vez
        for (const E of A.vivos) if (!ACTIVOS.has(E.estado) && !this._enVista(E.cuerpo.pie.x, E.cuerpo.pie.y + E.c.altura * 0.5, E.cuerpo.pie.z, E.c.altura)) this._aReserva(E);
        if (!A.vivos.some((E) => !E.reserva)) A.lleno = false;
        return;
      }
      A.cuenta -= paso;
      if (A.cuenta > 0 || A.vivos.length >= c.maximo) return;
      A.cuenta = this._sacar(A, this._elegirMolde(A), c.aparicion === 'fuera') ? c.cada : 1;
    }

    _arena(A, j, paso) {
      const c = A.c, P = j.cuerpo.pie;
      switch (A.fase) {
        case 'espera': {
          const dx = P.x - A.pos.x, dz = P.z - A.pos.z;
          if (c.empezar === 'mecanismo') break;   // las empieza una palanca o un disparador (activarAparecedor)
          if (c.empezar === 'inicio' || dx * dx + dz * dz < c.radio * c.radio) { A.fase = 'descanso'; A.t2 = 1.5; }
          break;
        }
        case 'descanso':
          A.t2 -= paso;
          this._hudOleadas(A, A.n ? 'Siguiente oleada en ' + Math.ceil(A.t2) : '');
          if (A.t2 <= 0) this._oleada(A);
          break;
        case 'oleada': {
          A.tSacar -= paso;
          if (A.cola.length && A.vivos.length < c.vivosMax && A.tSacar <= 0) {
            const it = A.cola[A.cola.length - 1];
            // si no encuentra sitio fuera de tu vista, al rato sale aunque lo veas (la oleada no se atasca)
            const E = this._sacar(A, it.m, c.aparicion === 'fuera' && A.fallos < 10);
            if (E) {
              A.cola.pop();
              A.fallos = 0;
              A.tSacar = 0.25;
              this._fortalecer(E, A, it.jefe);
              E.sabe = true;
              E.amenaza = j;
              this._reaccionar(E, j, true);
            } else A.fallos++;
          }
          const quedan = A.cola.length + A.vivos.length;
          this._hudOleadas(A, 'OLEADA ' + A.n + ' · quedan ' + quedan);
          if (!quedan) this._finOleada(A);
          break;
        }
        default: break;
      }
    }

    _oleada(A) {
      const c = A.c;
      A.n++;
      let entradas;
      if (c.forma === 'lista') {
        const ols = (c.oleadas || []).filter((o) => o && o.length);
        A.totalN = ols.length;
        if (!ols.length) { A.fase = 'fin'; return; }
        entradas = ols[Math.min(A.n, ols.length) - 1].map((x) => ({ m: this._molde(x.criatura), n: Math.max(0, x.n | 0) }));
      } else {
        const cuantos = Math.max(1, Math.round(c.inicial + c.crecer * (A.n - 1)));
        entradas = [];
        for (let i = 0; i < cuantos; i++) entradas.push({ m: this._elegirMolde(A), n: 1 });
      }
      const cola = [];
      for (const x of entradas) if (x.m) for (let i = 0; i < x.n; i++) cola.push({ m: x.m, jefe: false });
      for (let i = cola.length - 1; i > 0; i--) { const k = (Math.random() * (i + 1)) | 0; [cola[i], cola[k]] = [cola[k], cola[i]]; }
      // el jefe sale el último (la cola se saca por el final)
      if (c.jefe && c.jefeCada > 0 && A.n % c.jefeCada === 0) { const m = this._molde(c.jefe); if (m) cola.unshift({ m, jefe: true }); }
      A.cola = cola;
      A.fuerzaK = 1 + (c.fuerza / 100) * (A.n - 1);
      A.fase = 'oleada';
      A.tSacar = 0;
      A.fallos = 0;
      F.emitir('oleada-inicio', { aparecedor: A.ent, oleada: A.n, enemigos: cola.length });
      if (c.avisoOleada) this._cartel('OLEADA ' + A.n, 2.5);
    }

    _finOleada(A) {
      const c = A.c;
      F.emitir('oleada-fin', { aparecedor: A.ent, oleada: A.n });
      const total = c.forma === 'lista' ? A.totalN : c.total;
      if (total > 0 && A.n >= total) {
        A.fase = 'fin';
        this._hudOleadas(A, '');
        F.emitir('arena-completa', { aparecedor: A.ent, oleadas: A.n });
        if (c.avisoOleada) this._cartel('¡ARENA SUPERADA!', 3.5);
      } else {
        A.fase = 'descanso';
        A.t2 = c.descanso;
        if (c.avisoOleada) this._cartel('OLEADA ' + A.n + ' SUPERADA', 2.2);
      }
    }

    _fortalecer(E, A, jefe) {
      const k = A.fuerzaK || 1;
      if (k !== 1) { E.c.vida *= k; E.c.dano *= k; E.vida = E.c.vida; E.objetivo.vidaMax = E.c.vida; }
      if (jefe) { E.c.jefe = true; if (!E.c.nombreJefe) E.c.nombreJefe = E.molde.nombre; this.hayJefes = true; }
    }

    // busca sitio y saca uno; devuelve el enemigo o null
    _sacar(A, molde, fuera) {
      if (!molde) return null;
      const P = this.juego.jugador.cuerpo.pie, c = A.c, min2 = c.distanciaMin * c.distanciaMin;
      for (let i = 0; i < 6; i++) {
        let x, y, z;
        if (A.puntos) {
          const p = A.puntos[(Math.random() * A.puntos.length) | 0].pos;
          x = p.x; z = p.z;
          y = this._suelo(x, p.y, z);
          if (y === null) y = p.y;
        } else {
          const a = Math.random() * 6.2832, r = Math.sqrt(Math.random()) * c.radio;
          x = A.pos.x + Math.cos(a) * r; z = A.pos.z + Math.sin(a) * r;
          y = this._suelo(x, A.pos.y, z);
          if (y === null) continue;
        }
        const agua = this.juego.agua;
        if (molde.cfg.tipo === 'acuatico') {
          const w = agua && agua.en(x, y + 0.3, z);
          if (!w || w.c.dano > 0 || w.c.nadable === false) continue;   // los acuáticos solo salen dentro del agua (no en lava)
          y += Math.max(0, (w.top - y) * 0.5 - (molde.cfg.radio || 0.3));
        } else if (agua && agua.lista.length && agua.en(x, y + 0.3, z)) continue;   // y los demás nunca dentro
        const dx = x - P.x, dz = z - P.z;
        if (dx * dx + dz * dz < min2) continue;
        if (fuera && this._enVista(x, y + 0.9, z, 1.2)) continue;
        const E = this._generar(molde, x, y, z, Math.random() * 6.2832, A);
        A.vivos.push(E);
        return E;
      }
      return null;
    }

    // altura del suelo en (x, z) cerca de y0 (no se sube a tejados: primero mira cuánto techo hay encima)
    _suelo(x, y0, z) {
      const M = this.juego.mundo;
      const ar = M.rayo(x, y0 + 1.5, z, 0, 1, 0, 15);
      const top = y0 + 1.5 + (ar ? Math.max(0, ar.t - 0.3) : 15);
      const ab = M.rayo(x, top, z, 0, -1, 0, 40);
      return ab ? top - ab.t + 0.02 : null;
    }

    // ¿lo vería la cámara? (dentro del encuadre, al alcance de la vista y sin pared en medio)
    _enVista(x, y, z, r) {
      _esfera.center.set(x, y, z);
      _esfera.radius = r;
      if (!_frustum.intersectsSphere(_esfera)) return false;
      _v3.setFromMatrixPosition(this.juego.camara.matrixWorld);
      const dx = x - _v3.x, dy = y - _v3.y, dz = z - _v3.z, d = Math.sqrt(dx * dx + dy * dy + dz * dz);
      if (d > (this.lejos || 200) + r) return false;
      const g = this.juego.mundo.rayo(_v3.x, _v3.y, _v3.z, dx / d, dy / d, dz / d, d);
      return !g || g.t >= d - r;
    }

    _generar(molde, x, y, z, yaw, A) {
      const pool = this.reserva.get(molde.clave);
      let E = pool && pool.pop();
      if (E) this._reiniciar(E, x, y, z, yaw);
      else {
        const ent = { id: 'gen' + ++this.nGen, tipo: 'enemigo', nombre: molde.nombre, enemigo: molde.cfg, rot: [0, yaw / DEG, 0] };
        const obj = figura(ent);
        obj.traverse((o) => { if (o.userData.ayudaEditor) o.visible = false; });
        obj.userData.entId = ent.id;
        obj.position.set(x, y, z);
        this.juego.vista.escena.add(obj);
        obj.updateMatrixWorld(true);
        if (F.Luces && F.Luces.aplicarSombras) F.Luces.aplicarSombras(obj, molde.sombra);
        E = this._crear(ent, obj);
        E.generado = true;
        E.clave = molde.clave;
        E.molde = molde;
        this.lista.push(E);
      }
      E.de = A;
      return E;
    }

    _reiniciar(E, x, y, z, yaw) {
      const c = Object.assign(E.c, BASE, E.molde.cfg);   // vuelve a los valores del molde (las oleadas los suben)
      this._escalar(c, E.kEsc);
      this._etiquetas(E);
      E.vida = c.vida; E.objetivo.vidaMax = c.vida;
      E.muerto = E.fuera = E.reserva = E.asustado = E.sabe = false;
      E.tMuerte = 0; E.comer = 0; E.recuerdo = 0; E.cd = 0.3; E.flash = 0; E.vy = 0; E.tSuelo = 0; E.desvio = 0;
      E.embiste = E.salto = E.picado = null;
      E.amenaza = E.blanco = E.presa = null;
      E.yaw = yaw;
      E.cuerpo.teletransportar(x, y + (c.tipo === 'volador' ? c.alturaVuelo : E.nada ? c.radio : 0), z);
      E.casa.set(x, y, z); E.meta.copy(E.casa); E.sueloY = y; E.techoY = Infinity;
      E.visual.rotation.set(0, 0, 0); E.visual.position.set(0, 0, 0);
      if (E.obj.userData.cuerpoVol) E.obj.userData.cuerpoVol.position.y = 0;
      this._destello(E, 0);
      if (E.mixer) { E.mixer.stopAllAction(); E.anim = null; this._anim(E, 'idle'); }
      this._ir(E, this._inicial(E));
      E.obj.position.set(x, y, z);
      E.obj.visible = true;
      this.juego.objetivos.push(E.objetivo);
    }

    // a la reserva: muerto y desvanecido, o retirado por lejano (sin soltar nada ni contar como muerto)
    _aReserva(E) {
      if (E.reserva) return;
      if (!E.muerto) { E.muerto = true; const j = this.juego; j.objetivos = j.objetivos.filter((o) => o !== E.objetivo); }
      E.reserva = true;
      E.obj.visible = false;
      let pool = this.reserva.get(E.clave);
      if (!pool) this.reserva.set(E.clave, (pool = []));
      pool.push(E);
    }

    /* ---------- HUD: barra del jefe, contador de oleadas y carteles ---------- */
    _hudJefe(j) {
      let J = null;
      for (const E of this.lista) if (E.c.jefe && !E.muerto && E.blanco === j && (ACTIVOS.has(E.estado) || E === this._jefe)) { J = E; break; }
      const el = F.Hud.pieza(this.juego, 'fh-jefe', '<b></b><div class="fh-jcaja"><div class="fh-jlleno"></div></div>');
      if (J !== this._jefe) {
        this._jefe = J;
        el.classList.toggle('fh-ver', !!J);
        if (J) el.firstChild.textContent = J.c.nombreJefe || J.ent.nombre || 'Jefe';
        this._jefeK = -1;
      }
      if (J) {
        const k = Math.max(0, Math.round((J.vida / J.objetivo.vidaMax) * 200) / 2);
        if (k !== this._jefeK) { this._jefeK = k; el.lastChild.firstChild.style.width = k + '%'; }
      }
    }

    _hudOleadas(A, texto) {
      if (!A.c.avisoOleada || A.texto === texto) return;
      A.texto = texto;
      const el = F.Hud.pieza(this.juego, 'fh-oleadas');
      el.textContent = texto;
      el.classList.toggle('fh-ver', !!texto);
    }

    _cartel(texto, seg) {
      const el = F.Hud.pieza(this.juego, 'fh-cartel');
      el.textContent = texto;
      el.classList.remove('fh-ver');
      void el.offsetWidth;   // reinicia la animación
      el.classList.add('fh-ver');
      clearTimeout(this._tCartel);
      this._tCartel = setTimeout(() => el.classList.remove('fh-ver'), seg * 1000);
    }

    estado() { return [...this.muertos]; }

    // en qué va cada aparecedor de oleadas (se guarda con la partida)
    estadoOleadas() {
      const o = {};
      for (const A of this.aparecedores) if (A.c.modo === 'oleadas' && A.fase !== 'espera') o[A.ent.id] = { fase: A.fase, n: A.n, totalN: A.totalN || 0 };
      return o;
    }

    detener() {
      if (this._flashMats) { for (const m of this._flashMats.values()) m.dispose(); this._flashMats = null; }
      if (this.quitarOyente) this.quitarOyente();
      if (this.manchas) { this.manchas.parent && this.manchas.parent.remove(this.manchas); this.manchas.geometry.dispose(); this.manchas.material.map.dispose(); this.manchas.material.dispose(); this.manchas = null; }
      clearTimeout(this._tCartel);
      for (const b of this.balas) b.sp.parent && b.sp.parent.remove(b.sp);
      if (this._tex) this._tex.dispose();
      for (const E of this.lista) {
        if (E.generado) {
          // los generados no son de la escena: se quitan (la geometría es compartida, solo sus materiales)
          if (E.mixer) E.mixer.stopAllAction();
          if (E.obj.parent) E.obj.parent.remove(E.obj);
          this._destello(E, 0);   // sus materiales son los compartidos: no se liberan
          continue;
        }
        // en el editor la escena sigue: cada enemigo vuelve a su padre, su sitio y su postura
        if (E.mixer) { E.mixer.stopAllAction(); E.obj.traverse((o) => { if (o.isSkinnedMesh) o.skeleton.pose(); }); }
        this._destello(E, 0);
        if (E.padre0 && E.obj.parent !== E.padre0) E.padre0.add(E.obj);
        F.Escena.aplicarTransform(E.obj, E.ent);
        E.visual.rotation.set(0, 0, 0);
        E.visual.position.set(0, 0, 0);
        const cv = E.obj.userData.cuerpoVol;
        if (cv) cv.position.y = E.obj.userData.alturaEditor ?? E.c.alturaVuelo;
        for (const a of E.obj.userData.alas || []) a.rotation.set(0, 0, 0);
        E.obj.visible = true;
      }
    }
  }

  Enemigos.BASE = BASE;
  Enemigos.APARECEDOR = APARECEDOR;
  Enemigos.PUNTO = PUNTO;
  Enemigos.leerLista = leerLista;
  Enemigos.textoACriaturas = textoACriaturas;
  Enemigos.PRESETS = PRESETS;
  Enemigos.RESISTENCIAS = RESISTENCIAS;
  Enemigos.figura = figura;
  Enemigos.figuraPunto = figuraPunto;
  Enemigos.figuraAparecedor = figuraAparecedor;
  F.Enemigos = Enemigos;
})(window.FORJA);
