/* =========================================================
   FORJA · TÁCTICO (tipo SWAT): 🧍 REHENES · 💣 BOMBAS · 🚪 PUERTAS TÁCTICAS (brecha)
   Tres entidades nuevas con su figura base del motor y un gestor al jugar (juego.tactico). Todo se revisa solo cerca
   del jugador y cada 0,15 s (nada de rayos por cuadro); los menús congelan el mundo como el inventario.
   - Rehén: 'liberar' (E y listo) o 'escolta' (E: te sigue; rescatado al llegar a su zona de extracción, un ⬚
     disparador). Con "Vida" > 0 le hacen daño las explosiones y los enemigos que atacan cerca (si muere: aviso,
     y si así se eligió, la misión se pierde).
   - Bomba: cuenta atrás (desde el principio o con la acción "💣 Activar bomba"). Se desactiva manteniendo E o
     cortando el cable correcto (mini-juego). A cero: explota (daño en área) y, si así se eligió, misión perdida.
   - Puerta táctica: menú con E → abrir con cuidado · patada (ruido, aturde a los de detrás) · C2 (revienta la hoja,
     daña y aturde) · ganzúa (mantener) · espejo (marca a los enemigos de detrás unos segundos).
   Eventos: 'rehen-rescatado' / 'rehen-muerto' / 'bomba-desactivada' / 'bomba-explota' / 'mision-fallida'.
   ========================================================= */
(function (F) {
  'use strict';
  const T = THREE;

  const REHEN = { modo: 'liberar', extraccion: '', vida: 0, perderMision: false, velocidad: 3.2, texto: '', color: '#d9792b' };
  const BOMBA = { tiempo: 60, activa: true, desactivar: 'mantener', segundos: 4, cables: 3, correcto: 0, fallo: 'explota', radio: 6, dano: 150,
    canal: '', canalExplota: '', perderMision: true, texto: '' };
  const BRECHA = { ancho: 1.2, alto: 2.2, cerrada: false, llave: '', patada: true, c2: true, c2Objeto: '', ganzua: true, ganzuaSegundos: 3,
    espejo: true, aturdir: 3, color: '#6b5a48' };

  // 🏪 Tienda: lista de artículos { que: vida|armadura|municion|arma|bateria|objeto, ref (arma / munición / objeto),
  //    cantidad, precio (monedas), stock (0 = sin fin) }. Se compra con 🪙 monedas (recogible "Monedas")
  const TIENDA = { titulo: 'TIENDA', texto: 'Comprar', color: '#6a4a2a', articulos: [] };
  function articuloNuevo(extra = {}) { return { que: 'vida', ref: '', cantidad: 25, precio: 10, stock: 0, ...extra }; }

  // 🗣 NPC con diálogo: nodos { texto, opciones: [{ texto, siguiente ('' = fin | índice del nodo), acciones (las de las palancas) }] }
  const NPC = { texto: 'Hablar', color: '#4a7ab8', modelo: '', mirar: true, retrato: '', retratoAuto: false, ladoRetrato: 'izquierda', nodos: [] };

  /* 🖼 Retrato automático: una foto de la cabeza del modelo (figura del motor, receta o GLB), hecha una vez y guardada.
     Render aparte de 96×96 sin suavizar (pixelado retro). */
  const Retrato = {
    cache: new Map(),
    de(obj, clave) {
      if (this.cache.has(clave)) return this.cache.get(clave);
      let url = '';
      try {
        if (!this.r) {
          const cv = document.createElement('canvas'); cv.width = cv.height = 96;
          this.r = new T.WebGLRenderer({ canvas: cv, antialias: false, alpha: true, preserveDrawingBuffer: true });
          this.r.setPixelRatio(1);
          this.esc = new T.Scene();
          this.esc.add(new T.HemisphereLight(0xffffff, 0x50505a, 1.3));
          const sol = new T.DirectionalLight(0xffffff, 1.2); sol.position.set(0.6, 1, 1.5); this.esc.add(sol);
          this.cam = new T.PerspectiveCamera(30, 1, 0.01, 50);
        }
        const copia = T.SkeletonUtils.clone(obj);
        copia.position.set(0, 0, 0); copia.rotation.set(0, 0, 0); copia.scale.copy(obj.scale);
        copia.traverse((o) => { if (o.userData && o.userData.ayudaEditor) o.visible = false; });
        this.esc.add(copia);
        copia.updateMatrixWorld(true);
        const caja = new T.Box3().setFromObject(copia), tam = caja.getSize(new T.Vector3());
        // la cabeza: el 22 % de arriba del modelo; la cámara de frente (los modelos miran a +Z)
        const alto = Math.max(0.15, tam.y * 0.22), cy = caja.max.y - alto * 0.5, cz = (caja.min.z + caja.max.z) / 2;
        const cx = (caja.min.x + caja.max.x) / 2, d = alto * 2.4;
        this.cam.position.set(cx, cy + alto * 0.05, cz + d + tam.z * 0.5);
        this.cam.lookAt(cx, cy, cz);
        this.r.setClearColor(0x1c2230, 1);
        this.r.render(this.esc, this.cam);
        url = this.r.domElement.toDataURL();
        this.esc.remove(copia);
      } catch (err) { url = ''; }
      this.cache.set(clave, url);
      return url;
    },
  };
  F.Retrato = Retrato;
  function nodoNuevo(extra = {}) { return { texto: 'Hola, forastero.', opciones: [], ...extra }; }
  function opcionNueva(extra = {}) { return { texto: 'Adiós', siguiente: '', acciones: [], ...extra }; }

  const ESQ_REHEN = [
    { k: 'modo', t: 'sel', e: 'Rescate', op: [['liberar', '✋ Liberar (acercarse y pulsar usar)'], ['escolta', '🚶 Escolta (te sigue hasta la extracción)']] },
    { k: 'extraccion', t: 'ent', tipoEnt: 'disparador', e: 'Zona de extracción', si: (v) => v.modo === 'escolta', ayuda: 'Un ⬚ disparador: al llevarlo dentro queda rescatado' },
    { k: 'velocidad', t: 'num', e: 'Velocidad al seguirte (m/s)', paso: 0.1, min: 0.5, si: (v) => v.modo === 'escolta' },
    { k: 'vida', t: 'num', e: 'Vida (0 = no le pasa nada)', paso: 10, min: 0, ayuda: 'Con vida le dañan las explosiones y los enemigos que atacan cerca' },
    { k: 'perderMision', t: 'bool', e: 'Si muere, se pierde la misión', si: (v) => v.vida > 0 },
    { k: 'texto', t: 'texto', e: 'Texto del aviso', ayuda: 'Vacío: "Liberar" o "Que te siga"' },
    { k: 'color', t: 'color', e: 'Color (figura del motor)' },
  ];
  const ESQ_BOMBA = [
    { k: 'tiempo', t: 'num', e: 'Cuenta atrás (s)', paso: 5, min: 3 },
    { k: 'activa', t: 'bool', e: 'Cuenta desde el principio', ayuda: 'Si no: la arranca la acción "💣 Activar bomba" de un disparador o palanca' },
    { k: 'desactivar', t: 'sel', e: 'Se desactiva', op: [['mantener', '✋ Manteniendo usar unos segundos'], ['cables', '✂ Cortando el cable correcto']] },
    { k: 'segundos', t: 'num', e: 'Segundos manteniendo', paso: 0.5, min: 0.5, si: (v) => v.desactivar === 'mantener' },
    { k: 'cables', t: 'num', e: 'Cables', paso: 1, min: 2, max: 4, si: (v) => v.desactivar === 'cables' },
    { k: 'correcto', t: 'sel', e: 'Cable bueno', op: [[0, '🎲 Al azar en cada partida'], [1, 'Rojo'], [2, 'Azul'], [3, 'Amarillo'], [4, 'Verde']], si: (v) => v.desactivar === 'cables' },
    { k: 'fallo', t: 'sel', e: 'Cable malo', op: [['explota', '💥 Explota'], ['acelera', '⏩ Quedan 5 segundos']], si: (v) => v.desactivar === 'cables' },
    { k: 'radio', t: 'num', e: 'Radio de la explosión (m)', paso: 0.5, min: 1 },
    { k: 'dano', t: 'num', e: 'Daño en el centro', paso: 10, min: 0 },
    { k: 'perderMision', t: 'bool', e: 'Si explota, se pierde la misión' },
    { k: 'canal', t: 'texto', e: 'Al desactivarla avisa al canal', ayuda: 'Para abrir una puerta, cumplir un objetivo "📡 canal"…', av: true },
    { k: 'canalExplota', t: 'texto', e: 'Al explotar avisa al canal', av: true },
  ];
  const ESQ_BRECHA = [
    { k: 'ancho', t: 'num', e: 'Ancho (m)', paso: 0.1, min: 0.5 },
    { k: 'alto', t: 'num', e: 'Alto (m)', paso: 0.1, min: 1 },
    { k: 'cerrada', t: 'bool', e: 'Cerrada con llave', ayuda: 'Se abre con su llave, con ganzúa, de una patada o con C2' },
    { k: 'llave', t: 'objeto', e: 'Llave', si: (v) => v.cerrada },
    { grupo: 'Qué se puede hacer' },
    { k: 'patada', t: 'bool', e: '🦶 Patada (ruido, aturde a los de detrás)' },
    { k: 'c2', t: 'bool', e: '💥 Explosivo C2 (revienta la hoja)' },
    { k: 'c2Objeto', t: 'objeto', e: 'Gasta este objeto', si: (v) => v.c2, ayuda: 'Vacío: C2 ilimitado. Con un objeto: necesitas llevarlo en la mochila y se gasta' },
    { k: 'ganzua', t: 'bool', e: '🔧 Ganzúa (si está cerrada)' },
    { k: 'ganzuaSegundos', t: 'num', e: 'Segundos con la ganzúa', paso: 0.5, min: 0.5, si: (v) => v.ganzua },
    { k: 'espejo', t: 'bool', e: '🔍 Espejo (ver quién hay detrás)' },
    { k: 'aturdir', t: 'num', e: 'Aturde (s)', paso: 0.5, min: 0 },
    { k: 'color', t: 'color', e: 'Color de la hoja' },
  ];

  /* ---------- Figuras base ---------- */
  const mat = (c) => F.Render.matRetro(c);
  const caja = (w, h, d, c, x = 0, y = 0, z = 0) => { const m = new T.Mesh(new T.BoxGeometry(w, h, d), mat(c)); m.position.set(x, y, z); return m; };

  function figuraRehen(ent) {
    const r = { ...REHEN, ...(ent.rehen || {}) }, g = new T.Group();
    // persona de rodillas con las manos en la nuca (al levantarse: escala Y)
    const cuerpo = new T.Group();
    cuerpo.add(caja(0.42, 0.55, 0.26, r.color, 0, 0.75, 0));          // torso (chaleco)
    cuerpo.add(caja(0.24, 0.24, 0.24, '#e0b48e', 0, 1.18, 0));         // cabeza
    cuerpo.add(caja(0.12, 0.42, 0.12, r.color, -0.27, 1.1, 0).rotateZ(2.6));   // brazos arriba
    cuerpo.add(caja(0.12, 0.42, 0.12, r.color, 0.27, 1.1, 0).rotateZ(-2.6));
    cuerpo.add(caja(0.16, 0.45, 0.16, '#3b3f4a', -0.11, 0.25, 0.1));   // piernas (rodillas)
    cuerpo.add(caja(0.16, 0.45, 0.16, '#3b3f4a', 0.11, 0.25, 0.1));
    cuerpo.add(caja(0.4, 0.12, 0.42, '#3b3f4a', 0, 0.06, 0.25));
    g.add(cuerpo);
    g.userData.rehen = { cuerpo };
    return g;
  }

  function figuraBomba() {
    const g = new T.Group();
    g.add(caja(0.5, 0.28, 0.32, '#3a3d33', 0, 0.14, 0));
    for (let i = 0; i < 3; i++) g.add(caja(0.1, 0.1, 0.34, '#b8402e', -0.15 + i * 0.15, 0.32, 0));    // cartuchos
    const pantalla = new T.Mesh(new T.PlaneGeometry(0.22, 0.09), new T.MeshBasicMaterial({ color: 0xff2a1a }));
    pantalla.position.set(0, 0.2, 0.161);
    g.add(pantalla);
    const cs = ['#e0402e', '#3a86e0', '#e8c547', '#4fb64a'];
    for (let i = 0; i < 4; i++) g.add(caja(0.02, 0.02, 0.3, cs[i], -0.2 + i * 0.04, 0.3, 0.02));      // cables
    g.userData.bomba = { pantalla };
    return g;
  }

  function figuraNpc(ent) {
    const n = { ...NPC, ...(ent.npc || {}) }, g = new T.Group();
    const a = n.modelo && F.Assets && F.Assets.mapa.get(n.modelo);
    if (a && a.gltf && a.gltf.scene) { g.add(T.SkeletonUtils ? T.SkeletonUtils.clone(a.gltf.scene) : a.gltf.scene.clone()); return g; }
    // persona de pie (figura del motor)
    g.add(caja(0.42, 0.6, 0.26, n.color, 0, 1.15, 0), caja(0.26, 0.26, 0.26, '#e0b48e', 0, 1.6, 0));
    g.add(caja(0.12, 0.55, 0.12, n.color, -0.28, 1.1, 0), caja(0.12, 0.55, 0.12, n.color, 0.28, 1.1, 0));
    g.add(caja(0.16, 0.85, 0.16, '#3b3f4a', -0.11, 0.42, 0), caja(0.16, 0.85, 0.16, '#3b3f4a', 0.11, 0.42, 0));
    g.add(caja(0.08, 0.05, 0.03, '#222', -0.06, 1.63, 0.135), caja(0.08, 0.05, 0.03, '#222', 0.06, 1.63, 0.135));   // ojos (mira a +Z)
    return g;
  }

  function figuraTienda(ent) {
    const t = { ...TIENDA, ...(ent.tienda || {}) }, g = new T.Group();
    g.add(caja(2, 1, 0.7, t.color, 0, 0.5, 0));                       // mostrador
    g.add(caja(2.1, 0.08, 0.8, '#3a2a1a', 0, 1.04, 0));
    g.add(caja(0.08, 1.4, 0.08, '#3a2a1a', -0.95, 1.75, -0.3), caja(0.08, 1.4, 0.08, '#3a2a1a', 0.95, 1.75, -0.3));
    g.add(caja(2, 0.45, 0.08, '#e8c547', 0, 2.3, -0.3));                // cartel
    g.add(caja(0.25, 0.25, 0.06, '#ffd23f', 0, 2.3, -0.24));            // 🪙 en el cartel
    for (let i = 0; i < 3; i++) g.add(caja(0.22, 0.22, 0.22, ['#e23b3b', '#3a86e0', '#d8b33a'][i], -0.5 + i * 0.5, 1.2, 0));   // género
    return g;
  }

  function figuraBrecha(ent) {
    const b = { ...BRECHA, ...(ent.brecha || {}) }, g = new T.Group(), w = b.ancho, h = b.alto, m = 0.12;
    const marco = new T.Group();
    marco.add(caja(m, h + m, 0.24, '#4a4038', -w / 2 - m / 2, (h + m) / 2, 0));
    marco.add(caja(m, h + m, 0.24, '#4a4038', w / 2 + m / 2, (h + m) / 2, 0));
    marco.add(caja(w, m, 0.24, '#4a4038', 0, h + m / 2, 0));
    g.add(marco);
    const pivote = new T.Group();
    pivote.position.set(-w / 2, 0, 0);                                  // bisagra a la izquierda
    const hoja = caja(w - 0.02, h - 0.02, 0.06, b.color, w / 2, h / 2, 0);
    pivote.add(hoja);
    pivote.add(caja(0.05, 0.05, 0.14, '#c8b07a', w - 0.14, h * 0.48, 0));   // manilla
    if (b.cerrada) pivote.add(caja(0.12, 0.16, 0.1, '#8a8f99', w - 0.14, h * 0.4, 0));   // cerrojo
    g.add(pivote);
    g.userData.marcoPuerta = marco;    // la física solo pone el marco (la hoja es pieza móvil)
    g.userData.brecha = { pivote, hoja };
    return g;
  }

  /* ---------- Estilo (avisos, barra, menús) ---------- */
  let estilo = false;
  function ponerEstilo() {
    if (estilo) return;
    estilo = true;
    const st = document.createElement('style');
    st.textContent = `
.ft-barra{position:absolute;left:50%;top:68%;transform:translateX(-50%);width:min(50vw,280px);height:10px;background:rgba(0,0,0,.6);border:1px solid #e8a33d;z-index:7;display:none}
.ft-barra div{height:100%;width:0;background:#e8a33d}
.ft-reloj{position:absolute;top:48px;left:50%;transform:translateX(-50%);z-index:7;font-weight:bold;font-size:1.2em;color:#ff3b2a;
  background:rgba(0,0,0,.6);padding:4px 12px;display:none;text-shadow:0 0 8px rgba(255,40,20,.7)}
.ft-menu{position:absolute;inset:0;z-index:25;display:flex;align-items:center;justify-content:center;background:rgba(0,0,0,.45);font-family:ui-monospace,Consolas,monospace;color:#e8e2d0}
.ft-menu .ft-caja{background:#14161d;border:2px solid #e8a33d;padding:14px 18px;min-width:min(80vw,300px)}
.ft-menu h2{margin:0 0 8px;font-size:14px;letter-spacing:2px;text-transform:uppercase;color:#e8a33d}
.ft-menu button{display:block;width:100%;text-align:left;margin:4px 0;padding:8px 10px;background:#1e2129;border:1px solid #333;color:inherit;font:inherit;cursor:pointer}
.ft-menu button.ft-sel{border-color:#e8a33d;background:#2a2418}
.ft-menu button:disabled{opacity:.35;cursor:default}
.ft-cables{display:flex;gap:12px;justify-content:center;margin:10px 0}
.ft-cables button{width:54px;height:110px;border:3px solid #111;text-align:center;font-weight:bold;color:#111}
.ft-pista{font-size:11px;opacity:.55;margin-top:6px;text-align:center}`;
    document.head.appendChild(st);
  }

  const COLOR_CABLE = ['#e0402e', '#3a86e0', '#e8c547', '#4fb64a'], NOMBRE_CABLE = ['Rojo', 'Azul', 'Amarillo', 'Verde'];
  const _v = new T.Vector3(), _w = new T.Vector3();

  class Gestor {
    constructor(juego) {
      this.juego = juego;
      this.rehenes = []; this.bombas = []; this.brechas = []; this.tiendas = []; this.npcs = [];
      this.lista = this.rehenes;      // juego.rehenes.lista (misiones)
      this.blanco = null;             // lo que tienes delante para usar { tipo, it }
      this.reloj = 0; this.tBip = 0;
      this.menu = null;               // DOM del menú abierto (congela el mundo)
      const J = juego;
      for (const ent of J.escena.entidades) {
        const obj = J.objetos.get(ent.id);
        if (!obj) continue;
        if (ent.tipo === 'rehen') {
          const r = { ...REHEN, ...(ent.rehen || {}) };
          let zona = null;
          if (r.extraccion) { const z = J.objetos.get(r.extraccion); if (z) { z.updateWorldMatrix(true, true); zona = new T.Box3().setFromObject(z); } }
          this.rehenes.push({ ent, obj, r, estado: 'espera', vida: r.vida, zona, fig: obj.userData.rehen, tGolpe: 0 });
        } else if (ent.tipo === 'bomba') {
          const b = { ...BOMBA, ...(ent.bomba || {}) };
          const n = Math.max(2, Math.min(4, b.cables | 0));
          this.bombas.push({ ent, obj, b, t: b.tiempo, activa: !!b.activa, estado: 'armada', fig: obj.userData.bomba,
            bueno: b.correcto > 0 && b.correcto <= n ? b.correcto - 1 : Math.floor(Math.random() * n), n });
        } else if (ent.tipo === 'npc') {
          this.npcs.push({ ent, obj, n: { ...NPC, ...(ent.npc || {}) }, rotY: obj.rotation.y });
        } else if (ent.tipo === 'tienda') {
          const t = { ...TIENDA, ...(ent.tienda || {}) };
          this.tiendas.push({ ent, obj, t, stock: (t.articulos || []).map((a) => a.stock > 0 ? a.stock : Infinity) });
        } else if (ent.tipo === 'brecha') {
          const p = { ...BRECHA, ...(ent.brecha || {}) };
          this.brechas.push({ ent, obj, p, fig: obj.userData.brecha, k: 0, meta: 0, vel: 1, cerrada: !!p.cerrada, rota: false, c2: 0, pieza: null });
        }
      }
      // 🪙 contador de monedas: si el nivel tiene tienda o monedas que recoger (o ya llevas)
      this.conMonedas = this.tiendas.length > 0 || J.escena.entidades.some((e) => e.tipo === 'recogible' && e.recogible && e.recogible.tipo === 'moneda');
      // divisas que salen en este nivel (recogibles y precios de las tiendas): su contador se ve aunque vayas a 0
      const L0 = F.Divisas.lista(J.proyecto);
      this._usadas = new Set();
      for (const e of J.escena.entidades) {
        if (e.tipo === 'recogible' && e.recogible && e.recogible.tipo === 'moneda') this._usadas.add(F.Divisas.de(J.proyecto, e.recogible.divisa).id);
        if (e.tienda) for (const a of e.tienda.articulos || []) this._usadas.add(F.Divisas.de(J.proyecto, a.divisa).id);
      }
      if (L0.length === 1 && !this._usadas.size) this._usadas = new Set();
      this.hay = this.rehenes.length + this.bombas.length + this.brechas.length + this.tiendas.length + this.npcs.length > 0 || this.conMonedas;
      if (!this.hay) return;
      ponerEstilo();
      this.aviso = F.Hud.pieza(J, 'fh-aviso'); this.aviso.style.display = 'none';
      this.barra = F.Hud.pieza(J, 'ft-barra'); this.barra.innerHTML = '<div></div>';
      this.relojEl = F.Hud.pieza(J, 'ft-reloj');
      this.marcas = [];
      this.monedasEl = F.Hud.pieza(J, 'ft-monedas');
      this.monedasEl.style.display = 'none';
      this._tecla = (e) => this._teclaMenu(e);
      addEventListener('keydown', this._tecla);
    }

    // piezas móviles (hojas de las puertas tácticas): las pide Mecanismos.alMundo
    piezasMoviles() {
      return this.brechas.map((it) => ({ it, local: F.Fisica.triangulosLocales(it.fig.pivote), obj: it.fig.pivote, activa: !it.rota && it.k < 0.5 }))
        .filter((x) => x.local.length);
    }

    get bloquea() { return !!this.menu; }

    actualizar(dt) {
      if (!this.hay) return;
      const J = this.juego, j = J.jugador;
      if (this.menu) { this._padMenu(); return; }
      this._bombas(dt);
      this._rehenes(dt);
      // 🪙
      const D = F.Divisas, L = this._divL || (this._divL = D.lista(J.proyecto));   // la lista no cambia en la partida
      this._tDiv = (this._tDiv || 0) - dt;
      const cl = this._tDiv <= 0 ? (this._tDiv = 0.1, L.map((d) => D.tiene(j, d.id)).join(',')) : this._mVisto;
      if (cl !== this._mVisto) {
        this._mVisto = cl;
        const ver = L.filter((d, i) => D.tiene(j, d.id) > 0 || (this.conMonedas && i === 0) || this._usadas.has(d.id));
        this.monedasEl.innerHTML = ver.map((d) => `<span style="color:${d.color};margin-left:.6em">${D.html(d)} ${D.tiene(j, d.id)}</span>`).join('');
        this.monedasEl.style.display = ver.length ? 'block' : 'none';
      }
      this._brechas(dt);
      // ¿qué tienes delante? (cada 0,15 s)
      if ((this.reloj -= dt) <= 0) { this.reloj = 0.15; this._elegir(); }
      j.blancoTactico = this.blanco;
      if (!this.blanco || j.muerto) { this._barra(0); this.mant = 0; return; }
      const E = F.Entrada, x = this.blanco;
      // mantener (desactivar bomba, ganzúa)
      if (x.mantener) {
        if (E.mantenido('interactuar')) {
          this.mant = (this.mant || 0) + dt;
          this._barra(this.mant / x.mantener);
          if (this.mant >= x.mantener) { this.mant = 0; this._barra(0); j.sinInteractuar = 0.3; x.hacer(); this.reloj = 0; }
        } else { this.mant = 0; this._barra(0); }
      } else if (E.pulsado('interactuar')) { j.sinInteractuar = 0.3; x.hacer(); this.reloj = 0; }
      // marcas del espejo
      for (const m of this.marcas) { m.t -= dt; if (m.E && !m.E.muerto) m.s.position.set(m.E.cuerpo.pie.x, m.E.cuerpo.pie.y + m.E.c.altura + 0.4, m.E.cuerpo.pie.z); }
      if (this.marcas.some((m) => m.t <= 0)) this.marcas = this.marcas.filter((m) => { if (m.t > 0) return true; m.s.parent && m.s.parent.remove(m.s); return false; });
    }

    _barra(f) {
      this.barra.style.display = f > 0 ? 'block' : 'none';
      this.barra.firstChild.style.width = Math.min(100, f * 100) + '%';
    }

    _poner(texto) {
      const tecla = F.Tactil && F.Tactil.visible ? '' : F.Entrada.textoTeclado('interactuar').split(' / ')[0] + ': ';
      const t = texto ? texto.replace('%', tecla) : '';
      if (this._txt === t) return;
      this._txt = t;
      this.aviso.textContent = t;
      this.aviso.style.display = t ? 'block' : 'none';
      if (F.Tactil) F.Tactil.ponerContexto('interactuar', !!t);
    }

    // lo más cercano a lo que se puede hacer algo
    _elegir() {
      const j = this.juego.jugador, P = j.cuerpo.pie;
      let mejor = null, md = 1e9;
      const ver = (pos, alcance, x) => { const d = Math.hypot(pos.x - P.x, pos.z - P.z); if (d < alcance && Math.abs(pos.y - P.y) < 1.6 && d < md) { md = d; mejor = x; } };
      for (const h of this.rehenes) {
        if (h.estado !== 'espera') continue;
        ver(h.obj.position, 1.7, { tipo: 'rehen', it: h, texto: '🧍 %' + (h.r.texto || (h.r.modo === 'escolta' ? 'Que te siga' : 'Liberar')), hacer: () => this._liberar(h) });
      }
      for (const b of this.bombas) {
        if (b.estado !== 'armada') continue;
        b.obj.getWorldPosition(_v);
        const cables = b.b.desactivar === 'cables';
        ver(_v, 1.5, { tipo: 'bomba', it: b, texto: '💣 ' + (cables ? '%Cortar un cable' : 'Mantén %desactivar'), mantener: cables ? 0 : b.b.segundos, hacer: () => cables ? this._menuCables(b) : this._desactivar(b) });
      }
      for (const n of this.npcs) {
        if (!(n.n.nodos || []).length) continue;
        n.obj.getWorldPosition(_v);
        ver(_v, 2, { tipo: 'npc', it: n, texto: '🗣 %' + (n.n.texto || 'Hablar'), hacer: () => this._hablar(n, 0) });
      }
      for (const t of this.tiendas) {
        t.obj.getWorldPosition(_v);
        ver(_v, 2.2, { tipo: 'tienda', it: t, texto: '🏪 %' + (t.t.texto || 'Comprar'), hacer: () => this._menuTienda(t) });
      }
      for (const d of this.brechas) {
        if (d.rota || d.k > 0.05) continue;
        d.obj.getWorldPosition(_v);
        ver(_v, 1.9, { tipo: 'brecha', it: d, texto: '🚪 %Opciones de la puerta', hacer: () => this._menuBrecha(d) });
      }
      // el ganzúa en marcha se convierte en "mantener"
      if (mejor && this.ganzua && this.ganzua.d === mejor.it) mejor = { ...mejor, texto: '🔧 Mantén %forzar la cerradura', mantener: mejor.it.p.ganzuaSegundos, hacer: () => { this.ganzua = null; mejor.it.cerrada = false; this._abrir(mejor.it, 1.2); } };
      if (!mejor && this.ganzua) this.ganzua = null;
      if ((mejor && mejor.it) !== (this.blanco && this.blanco.it)) this.mant = 0;
      this.blanco = mejor;
      this._poner(mejor && mejor.texto);
    }

    /* ---------- 🧍 Rehenes ---------- */
    _liberar(h) {
      const F_ = F;
      if (h.r.modo === 'escolta') { h.estado = 'sigue'; this._levantar(h, true); F_.Audio.sintetico('recoger', { volumen: 0.5, tono: 0.8 }); }
      else this._rescatado(h);
    }
    _levantar(h, si) { if (h.fig) { h.fig.cuerpo.scale.y = si ? 1.35 : 1; } }
    _rescatado(h) {
      if (h.estado === 'rescatado' || h.estado === 'muerto') return;
      h.estado = 'rescatado';
      this._levantar(h, true);
      F.Audio.sintetico('recoger', { volumen: 0.8, tono: 1.4 });
      F.aviso && 0;
      h.tFuera = 1.5;
      F.emitir('rehen-rescatado', { juego: this.juego, rehen: h });
    }
    danarRehen(h, n) {
      if (!(h.r.vida > 0) || h.estado === 'muerto' || h.estado === 'rescatado') return;
      h.vida -= n;
      if (h.vida > 0) return;
      h.estado = 'muerto';
      h.obj.rotation.x = -Math.PI / 2; h.obj.position.y += 0.15;
      F.emitir('rehen-muerto', { juego: this.juego, rehen: h });
      if (h.r.perderMision) this._fallar('Han matado a un rehén');
    }
    _rehenes(dt) {
      const J = this.juego, j = J.jugador, M = J.mundo, EN = J.enemigos;
      for (const h of this.rehenes) {
        if (h.estado === 'rescatado' && h.tFuera > 0) { h.tFuera -= dt; if (h.tFuera <= 0 && h.r.modo === 'escolta') h.obj.visible = false; continue; }
        if (h.estado !== 'sigue') continue;
        const o = h.obj.position, P = j.cuerpo.pie;
        const dx = P.x - o.x, dz = P.z - o.z, d = Math.hypot(dx, dz);
        if (d > 18) { h.estado = 'espera'; this._levantar(h, false); continue; }   // te alejaste demasiado: se queda
        if (d > 1.8) {
          const paso = Math.min(d - 1.8, h.r.velocidad * dt), ux = dx / d, uz = dz / d;
          // pared delante: se para
          if (!M.rayo(o.x, o.y + 0.6, o.z, ux, 0, uz, paso + 0.35)) {
            o.x += ux * paso; o.z += uz * paso;
            const g = M.rayo(o.x, o.y + 1, o.z, 0, -1, 0, 3);
            if (g) o.y = o.y + 1 - g.t;
          }
          h.obj.rotation.y = Math.atan2(ux, uz);
        }
        if (h.zona && h.zona.containsPoint(_v.set(o.x, o.y + 0.5, o.z))) this._rescatado(h);
        // los enemigos que atacan cerca le hacen daño
        if (h.r.vida > 0 && EN && (h.tGolpe -= dt) <= 0) {
          h.tGolpe = 0.5;
          for (const E of EN.lista) {
            if (E.muerto || !/^(atacar|anticipar)$/.test(E.estado)) continue;
            if (Math.hypot(E.cuerpo.pie.x - o.x, E.cuerpo.pie.z - o.z) < (E.c.alcance || 2) * 0.8) this.danarRehen(h, (E.c.dano || 10) * 0.5);
          }
        }
      }
    }

    /* ---------- 💣 Bombas ---------- */
    activarBomba(id) { const b = this.bombas.find((x) => x.ent.id === id); if (b && b.estado === 'armada') b.activa = true; }
    _bombas(dt) {
      let urg = null;
      for (const b of this.bombas) {
        if (b.estado !== 'armada' || !b.activa) continue;
        b.t -= dt;
        if (!urg || b.t < urg.t) urg = b;
        if (b.fig) b.fig.pantalla.visible = b.t > 10 || (b.t * 4) % 1 > 0.4;
        if (b.t <= 0) this._explotar(b);
      }
      if (urg && urg.estado === 'armada') {
        const s = Math.max(0, urg.t);
        this.relojEl.style.display = 'block';
        this.relojEl.textContent = '💣 ' + Math.floor(s / 60) + ':' + String(Math.floor(s % 60)).padStart(2, '0') + (s < 10 ? '.' + Math.floor((s % 1) * 10) : '');
        this.tBip -= dt;
        if (this.tBip <= 0) { this.tBip = s < 10 ? 0.35 : 1; F.Audio.sintetico('golpe', { volumen: 0.25, tono: 3 }); }
      } else this.relojEl.style.display = 'none';
    }
    _desactivar(b) {
      b.estado = 'desactivada';
      if (b.fig) b.fig.pantalla.material.color.set(0x2ad14f), b.fig.pantalla.visible = true;
      F.Audio.sintetico('recoger', { volumen: 0.8, tono: 1.6 });
      F.emitir('bomba-desactivada', { juego: this.juego, bomba: b });
      if (b.b.canal && this.juego.mecanismos) this.juego.mecanismos.emitir(b.b.canal, true);
    }
    _explotar(b) {
      b.estado = 'explotada';
      b.obj.getWorldPosition(_v);
      this.explosion(_v, b.b.radio, b.b.dano);
      b.obj.visible = false;
      F.emitir('bomba-explota', { juego: this.juego, bomba: b });
      if (b.b.canalExplota && this.juego.mecanismos) this.juego.mecanismos.emitir(b.b.canalExplota, true);
      if (b.b.perderMision) this._fallar('La bomba ha explotado');
    }

    // 💥 daño en área (bombas, C2): jugador, enemigos y rehenes; destello y ruido
    explosion(p, radio, dano, aturdir = 0) {
      F.emitir('explosion', p, radio);   // armas: quemadura en el suelo
      const J = this.juego, j = J.jugador, EN = J.enemigos;
      const caida = (d) => Math.max(0, 1 - d / radio);
      const dj = p.distanceTo(_w.set(j.cuerpo.pie.x, j.cuerpo.pie.y + 1, j.cuerpo.pie.z));
      if (dj < radio && j.danar && !j.muerto) j.danar(dano * caida(dj), 'explosion');
      if (EN) for (const E of EN.lista) {
        if (E.muerto) continue;
        const d = p.distanceTo(_w.set(E.cuerpo.pie.x, E.cuerpo.pie.y + 1, E.cuerpo.pie.z));
        if (d < radio) { EN.danar(E, dano * caida(d), { tipo: 'fuego' }); if (aturdir > 0 && !E.muerto && EN.aturdir) EN.aturdir(E, aturdir); }
      }
      for (const h of this.rehenes) { const d = p.distanceTo(h.obj.position); if (d < radio) this.danarRehen(h, dano * caida(d)); }
      if (EN && EN.ruidos) EN.ruidos.push({ x: p.x, y: p.y, z: p.z, fuerza: 1.5, t: EN.t });
      F.Audio.sintetico('disparo', { volumen: 1, tono: 0.35 });
      if (j.temblor !== undefined) j.temblor = Math.max(j.temblor || 0, 0.6);
      // lo que se ve: bola de fuego, chispas, humo y destello (motor/explosiones.js, reciclado)
      if (F.Explosiones) F.Explosiones.efecto(J, p, Math.max(1.5, radio * 0.8));
    }

    _fallar(motivo) { F.emitir('mision-fallida', { juego: this.juego, motivo }); }

    /* ---------- 🚪 Puertas tácticas ---------- */
    // lado del jugador respecto a la hoja (+1 delante de su +Z, -1 detrás)
    _lado(d) {
      const j = this.juego.jugador;
      d.obj.updateWorldMatrix(true, false);
      _v.copy(j.cuerpo.pie).applyMatrix4(new T.Matrix4().copy(d.obj.matrixWorld).invert());
      return _v.z >= 0 ? 1 : -1;
    }
    _abrir(d, segundos) {
      d.meta = 1; d.vel = 1 / Math.max(0.05, segundos);
      d.sentido = this._lado(d);   // se abre hacia el otro lado (lejos del jugador): girar + lleva la hoja a -Z
      F.emitir('puerta-abierta', d.ent);
    }
    _brechas(dt) {
      for (const d of this.brechas) {
        if (d.c2 > 0) {
          d.c2 -= dt;
          if ((this._bipC2 = (this._bipC2 || 0) - dt) <= 0) { this._bipC2 = d.c2 < 1 ? 0.15 : 0.4; F.Audio.sintetico('golpe', { volumen: 0.3, tono: 3.2 }); }
          if (d.c2 <= 0) this._reventar(d);
        }
        if (d.k === d.meta || d.rota) continue;
        d.k = Math.min(1, d.k + d.vel * dt);
        d.fig.pivote.rotation.y = (d.sentido || 1) * d.k * Math.PI * 0.55;
        if (d.pieza && this.juego.mundo) { d.pieza.activa = d.k < 0.5; this.juego.mundo.moverPieza(d.pieza); }
      }
    }
    _detras(d, radio, fn) {
      // enemigos al otro lado de la puerta, a menos de radio
      const EN = this.juego.enemigos, lado = this._lado(d);
      if (!EN) return;
      const inv = new T.Matrix4().copy(d.obj.matrixWorld).invert();
      for (const E of EN.lista) {
        if (E.muerto || E.reserva) continue;
        _v.copy(E.cuerpo.pie).applyMatrix4(inv);
        if (Math.sign(_v.z || 1) === lado || Math.hypot(_v.x, _v.z) > radio) continue;
        fn(E);
      }
    }
    _patada(d) {
      d.cerrada = false;
      this._abrir(d, 0.15);
      F.Audio.sintetico('golpe', { volumen: 1, tono: 0.5 });
      const EN = this.juego.enemigos;
      d.obj.getWorldPosition(_v);
      if (EN && EN.ruidos) EN.ruidos.push({ x: _v.x, y: _v.y + 1, z: _v.z, fuerza: 0.6, t: EN.t });
      if (d.p.aturdir > 0) this._detras(d, 4.5, (E) => EN.aturdir && EN.aturdir(E, d.p.aturdir));
      const j = this.juego.jugador;
      FORJA.emitir('disparo', { jugador: j, arma: { tipo: 'cuerpo', nombre: 'patada', golpe3p: 'kick', cuerpo3p: 'entero' } });
    }
    _ponerC2(d) {
      const p = d.p, inv = this.juego.jugador.inventario;
      if (p.c2Objeto && inv) { if (inv.contar('objeto', p.c2Objeto) < 1) return; inv.gastar('objeto', p.c2Objeto, 1); }
      d.c2 = 2.5;
      const lado = this._lado(d);
      d.cargaC2 = caja(0.18, 0.12, 0.05, '#c8c0a0', 0, 0, 0);
      d.cargaC2.position.set(d.p.ancho * 0.5, d.p.alto * 0.5, 0.06 * lado);
      d.fig.pivote.add(d.cargaC2);
    }
    _reventar(d) {
      d.rota = true; d.cerrada = false;
      d.fig.pivote.visible = false;
      if (d.pieza && this.juego.mundo) { d.pieza.activa = false; this.juego.mundo.moverPieza(d.pieza); }
      d.obj.getWorldPosition(_v); _v.y += 1;
      // daño y aturdir al otro lado; el jugador, si está pegado
      this._detras(d, 5, (E) => { this.juego.enemigos.danar(E, 35, { tipo: 'fuego' }); if (!E.muerto && this.juego.enemigos.aturdir) this.juego.enemigos.aturdir(E, d.p.aturdir + 1); });
      this.explosion(_v, 2.2, 40);
      F.emitir('puerta-abierta', d.ent);
    }
    _espejo(d) {
      const J = this.juego;
      this._detras(d, 12, (E) => {
        const s = new T.Sprite(new T.SpriteMaterial({ color: 0xff3020, depthTest: false, transparent: true, opacity: 0.9 }));
        s.scale.set(0.3, 0.3, 1); s.renderOrder = 999;
        J.vista.escena.add(s);
        this.marcas.push({ E, s, t: 6 });
      });
      F.Audio.sintetico('recoger', { volumen: 0.4, tono: 2 });
      if (!this.marcas.length) { this._poner('🔍 No hay nadie detrás'); this.reloj = 1.2; }
    }

    /* ---------- Menús (congelan el mundo) ---------- */
    _abrirMenu(titulo, opciones, cables, texto, retrato) {
      const c = document.createElement('div');
      c.className = 'ft-menu';
      c.innerHTML = `<div class="ft-caja"><h2></h2>${texto ? '<p class="ft-texto" style="white-space:pre-wrap;line-height:1.5;margin:0 0 10px"></p>' : ''}${cables ? '<div class="ft-cables"></div>' : ''}<div class="ft-ops"></div><div class="ft-pista">${cables ? '1-' + opciones.length + ' o clic · Esc: dejarlo' : '↑↓ y Usar / Enter, 1-5 o clic · Esc: cerrar'}</div></div>`;
      c.querySelector('h2').textContent = titulo;
      if (retrato) {   // 🖼 cara del personaje junto al texto (estilo PS1: MGS, Suikoden, Final Fantasy)
        const caja = c.querySelector('.ft-caja'), img = document.createElement('img');
        img.src = retrato.url; img.className = 'ft-retrato';
        img.style.cssText = `float:${retrato.lado === 'derecha' ? 'right' : 'left'};width:min(22vmin,128px);height:min(22vmin,128px);object-fit:cover;image-rendering:pixelated;border:2px solid currentColor;margin:${retrato.lado === 'derecha' ? '0 0 8px 12px' : '0 12px 8px 0'}`;
        caja.insertBefore(img, caja.firstChild);
        c.querySelector('.ft-ops').style.clear = 'both';
      }
      if (texto) c.querySelector('.ft-texto').textContent = texto;
      const cont = c.querySelector(cables ? '.ft-cables' : '.ft-ops');
      this.ops = opciones;
      opciones.forEach((o, i) => {
        const b = document.createElement('button');
        if (cables) { b.style.background = o.color; b.textContent = i + 1; }
        else b.textContent = (i + 1) + '. ' + o.texto;
        b.disabled = !!o.no;
        b.onclick = () => this._elegirOp(i);
        cont.appendChild(b);
      });
      this.juego.vista.contenedor.appendChild(c);
      this.menu = c; this.sel = opciones.findIndex((o) => !o.no); this._pintarSel();
      F.Entrada.silencioLiberar = true; F.Entrada.soltarBloqueo(); F.Entrada.limpiar && F.Entrada.limpiar();
      this._padAntes = { a: true, b: true, arr: true, aba: true };
      this._poner('');
    }
    _pintarSel() { if (!this.menu) return; [...this.menu.querySelectorAll('button')].forEach((b, i) => b.classList.toggle('ft-sel', i === this.sel)); }
    _cerrarMenu() {
      if (!this.menu) return;
      this.menu.remove(); this.menu = null; this.ops = null;
      F.Entrada.limpiar && F.Entrada.limpiar();
      if (!F.Entrada.tactil) F.Entrada.pedirBloqueo();
      this.juego.jugador.sinInteractuar = 0.3;
      this.reloj = 0;
    }
    _elegirOp(i) { const o = this.ops && this.ops[i]; if (!o || o.no) return; this._cerrarMenu(); o.hacer(); }
    _mover(d) { if (!this.ops) return; let i = this.sel; for (let k = 0; k < this.ops.length; k++) { i = (i + d + this.ops.length) % this.ops.length; if (!this.ops[i].no) break; } this.sel = i; this._pintarSel(); }
    _teclaMenu(e) {
      if (!this.menu) return;
      if (e.code === 'Escape') { this._cerrarMenu(); e.preventDefault(); return; }
      if (/^Digit[1-9]$/.test(e.code)) { this._elegirOp(+e.code.slice(5) - 1); return; }
      if (e.code === 'ArrowUp' || e.code === 'KeyW') this._mover(-1);
      if (e.code === 'ArrowDown' || e.code === 'KeyS') this._mover(1);
      if (e.code === 'Enter' || e.code === 'KeyE' || e.code === 'Space') this._elegirOp(this.sel);
    }
    _padMenu() {
      const g = navigator.getGamepads ? [...navigator.getGamepads()].find(Boolean) : null;
      if (!g) return;
      const b = (i) => !!(g.buttons[i] && g.buttons[i].pressed), ax = g.axes[1] || 0;
      const ahora = { a: b(0), b: b(1), arr: b(12) || ax < -0.6, aba: b(13) || ax > 0.6 };
      const p = this._padAntes || {};
      if (ahora.arr && !p.arr) this._mover(-1);
      if (ahora.aba && !p.aba) this._mover(1);
      if (ahora.a && !p.a) this._elegirOp(this.sel);
      else if (ahora.b && !p.b) this._cerrarMenu();
      this._padAntes = ahora;
    }

    _menuBrecha(d) {
      const p = d.p, inv = this.juego.jugador.inventario;
      const llave = d.cerrada && p.llave && inv && inv.contar('objeto', p.llave) > 0;
      const c2 = p.c2 && (!p.c2Objeto || (inv && inv.contar('objeto', p.c2Objeto) > 0));
      this._abrirMenu('Puerta', [
        { texto: d.cerrada ? (llave ? '🗝 Abrir con la llave' : '🔒 Cerrada con llave') : '🤫 Abrir con cuidado', no: d.cerrada && !llave, hacer: () => { d.cerrada = false; this._abrir(d, 1.2); } },
        { texto: '🦶 Patada', no: !p.patada, hacer: () => this._patada(d) },
        { texto: '💥 Poner C2' + (p.c2Objeto && !c2 ? ' (no llevas)' : ''), no: !c2, hacer: () => this._ponerC2(d) },
        { texto: '🔧 Ganzúa', no: !(p.ganzua && d.cerrada), hacer: () => { this.ganzua = { d }; this.reloj = 0; } },
        { texto: '🔍 Mirar por debajo (espejo)', no: !p.espejo, hacer: () => this._espejo(d) },
      ]);
    }
    _nombreArticulo(a) {
      const P = this.juego.proyecto, ref = (L) => ((L || []).find((x) => x.id === a.ref) || {}).nombre;
      switch (a.que) {
        case 'vida': return '✚ Vida +' + a.cantidad;
        case 'armadura': return '⛨ Armadura +' + a.cantidad;
        case 'bateria': return '🔋 Pilas +' + a.cantidad + '%';
        case 'arma': return '🔫 ' + (ref(P.armas) || 'Arma');
        case 'municion': return '▮ ' + (ref(P.municiones) || 'Munición') + ' ×' + a.cantidad;
        case 'objeto': return '🎒 ' + (ref(P.objetos) || 'Objeto') + (a.cantidad > 1 ? ' ×' + a.cantidad : '');
      }
      return a.que;
    }
    _menuTienda(t) {
      const j = this.juego.jugador, D = F.Divisas, P = this.juego.proyecto;
      const ops = (t.t.articulos || []).map((a, i) => ({
        texto: `${this._nombreArticulo(a)} — ${a.precio} ${D.texto(D.de(P, a.divisa))}${t.stock[i] !== Infinity ? ' (quedan ' + t.stock[i] + ')' : ''}`,
        no: D.tiene(j, D.de(P, a.divisa).id) < a.precio || t.stock[i] <= 0,
        hacer: () => {
          const r = { ...F.Recogibles.BASE, tipo: a.que, cantidad: a.cantidad, soloSiFalta: false,
            arma: a.que === 'arma' || a.que === 'municion' ? a.ref : '', municionTipo: a.que === 'municion' ? a.ref : '', objeto: a.que === 'objeto' ? a.ref : '' };
          if (a.que === 'municion') r.arma = '';
          const R = this.juego.recogibles;
          const dv = D.de(P, a.divisa).id;
          if (D.tiene(j, dv) >= a.precio && R && R._aplicar(r, true)) { D.sumar(j, dv, -a.precio, P); t.stock[i]--; F.Audio.sintetico('recoger', { volumen: 0.8, tono: 1.3 }); F.emitir('compra', { juego: this.juego, articulo: a }); }
          else F.Audio.sintetico('golpe', { volumen: 0.4, tono: 0.6 });
          this._menuTienda(t);   // seguir comprando
        },
      }));
      ops.push({ texto: 'Salir', hacer: () => {} });
      const usa = [...new Set((t.t.articulos || []).map((a) => D.de(P, a.divisa).id))].map((id) => D.de(P, id));
      this._abrirMenu(`${t.t.titulo || 'TIENDA'} · ${usa.map((d) => D.texto(d) + ' ' + D.tiene(j, d.id)).join('  ')}`, ops);
    }

    /* 🗣 diálogo: el texto del nodo y sus respuestas; cada respuesta hace sus acciones y va a otro nodo o termina */
    _hablar(n, i) {
      const nodo = (n.n.nodos || [])[i];
      if (!nodo) return;
      if (n.n.mirar !== false) {   // se gira hacia ti
        const P = this.juego.jugador.cuerpo.pie, o = n.obj.getWorldPosition(_v);
        n.obj.rotation.y = Math.atan2(P.x - o.x, P.z - o.z);   // (sin carpeta girada; con carpeta girada mira aproximado)
      }
      const ops = (nodo.opciones && nodo.opciones.length ? nodo.opciones : [{ texto: 'Continuar', siguiente: '', acciones: [] }]).map((o) => ({
        texto: o.texto || '…',
        hacer: () => {
          if (o.acciones && o.acciones.length && this.juego.mecanismos) this.juego.mecanismos.ejecutar(o.acciones, true);
          F.emitir('dialogo', { juego: this.juego, npc: n.ent, nodo: i, opcion: o });
          const sig = o.siguiente === '' || o.siguiente == null ? -1 : +o.siguiente;
          if (sig >= 0) this._hablar(n, sig);
        },
      }));
      // 🖼 retrato: el del diálogo (si lo tiene: otra cara, otra expresión) o el del personaje
      const ret = F.Assets && F.Assets.mapa.get(nodo.retrato || n.n.retrato);
      const url = ret && ret.url ? ret.url : n.n.retratoAuto ? Retrato.de(n.obj, 'npc:' + n.ent.id) : '';
      this._abrirMenu(n.ent.nombre || 'NPC', ops, false, nodo.texto, url ? { url, lado: n.n.ladoRetrato } : null);
    }

    _menuCables(b) {
      const ops = [];
      for (let i = 0; i < b.n; i++) ops.push({ color: COLOR_CABLE[i], texto: NOMBRE_CABLE[i], hacer: () => {
        if (i === b.bueno) this._desactivar(b);
        else if (b.b.fallo === 'acelera') { b.t = Math.min(b.t, 5); b.activa = true; F.Audio.sintetico('golpe', { volumen: 0.8, tono: 2.5 }); }
        else this._explotar(b);
      } });
      this._abrirMenu('✂ Corta un cable', ops, true);
    }

    detener() {
      // las figuras son las del editor: todo vuelve a como estaba (si no, al probar otra vez seguía abierta, el rehén movido…)
      for (const h of this.rehenes) {
        h.obj.position.fromArray(h.ent.pos || [0, 0, 0]);
        h.obj.rotation.set(...(h.ent.rot || [0, 0, 0]).map((g) => g * Math.PI / 180));
        h.obj.visible = h.ent.visible !== false;
        if (h.fig) h.fig.cuerpo.scale.y = 1;
      }
      for (const b of this.bombas) {
        b.obj.visible = b.ent.visible !== false;
        if (b.fig) { b.fig.pantalla.visible = true; b.fig.pantalla.material.color.set(0xff2a1a); }
      }
      for (const n of this.npcs) n.obj.rotation.y = n.rotY;
      for (const d of this.brechas) {
        d.fig.pivote.rotation.y = 0;
        d.fig.pivote.visible = true;
        if (d.cargaC2) { d.cargaC2.parent && d.cargaC2.parent.remove(d.cargaC2); d.cargaC2 = null; }
      }
      this._poner && this.aviso && this._poner('');
      if (this.relojEl) this.relojEl.style.display = 'none';
      if (this._tecla) removeEventListener('keydown', this._tecla);
      if (this.menu) this.menu.remove();
      for (const m of this.marcas || []) m.s.parent && m.s.parent.remove(m.s);
      if (this.juego.jugador) this.juego.jugador.blancoTactico = null;
    }
  }

  F.Tactico = { ponerEstilo, NPC, nodoNuevo, opcionNueva, figuraNpc, TIENDA, articuloNuevo, figuraTienda, REHEN, BOMBA, BRECHA, ESQ_REHEN, ESQ_BOMBA, ESQ_BRECHA, figuraRehen, figuraBomba, figuraBrecha, Gestor };
})(window.FORJA);
