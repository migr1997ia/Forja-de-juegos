/* =========================================================
   FORJA · PUNTOS DE GUARDADO (entidad 💾 'guardado')
   Al pasar encima o con el botón de usar:
     · menu       → abre las ranuras para guardar (máquina de escribir de RE)
     · checkpoint → marca dónde reapareces al morir (no escribe partida)
     · auto       → guarda en la ranura "Autoguardado" y además es checkpoint
   Opcional: solo una vez, gastar un objeto de la mochila (cinta de tinta), llenar la vida al reaparecer.
   El juego avisa con F.emitir('punto-guardado', { juego, ent, p, datos }); FORJA.Partida guarda y recuerda el checkpoint.
   Ajustes del proyecto en menus.guardado: donde (pausa | puntos | ambos), alMorir (gameover | reaparecer), alEntrarNivel.
   ========================================================= */
(function (F) {
  'use strict';
  const T = THREE;

  const PUNTO = {
    activar: 'usar',          // 'tocar' | 'usar'
    hace: 'menu',             // 'menu' | 'checkpoint' | 'auto'
    unaVez: false,
    objeto: '',               // objeto de la mochila que hace falta ('' = ninguno)
    gastar: true,             // se gasta 1 al guardar
    llenarVida: false,        // al reaparecer aquí, con la vida llena
    aviso: '',                // '' = el de serie
    texto: '',                // texto del botón de usar ('' = "Guardar partida" / "Punto de control")
    sonido: '',
    figura: 'maquina',        // 'maquina' | 'bandera' | 'cristal' | 'ninguna'
    modelo: '',
    color: '#c8a040',
    radio: 1.2,               // con 'tocar': distancia (m)
  };

  const ESQUEMA = [
    { grupo: '💾 Punto de guardado' },
    { k: 'hace', t: 'sel', e: 'Qué hace', op: [['menu', 'Abre el menú de guardar (ranuras)'], ['checkpoint', 'Checkpoint (reaparecer aquí al morir)'], ['auto', 'Autoguardado + checkpoint']] },
    { k: 'activar', t: 'sel', e: 'Se activa', op: [['usar', 'Con el botón de usar'], ['tocar', 'Al pasar encima']] },
    { k: 'radio', t: 'num', e: 'Distancia para tocar (m)', paso: 0.1, min: 0.3, si: (v) => v.activar === 'tocar' },
    { k: 'texto', t: 'texto', e: 'Texto del botón', si: (v) => v.activar === 'usar', ayuda: 'Vacío = "Guardar partida" o "Punto de control"' },
    { k: 'unaVez', t: 'bool', e: 'Solo una vez', ayuda: 'Después de usarlo se apaga' },
    { k: 'objeto', t: 'objeto', e: 'Necesita un objeto', ayuda: 'Ej. cinta de tinta (Resident Evil). Vacío = no hace falta' },
    { k: 'gastar', t: 'bool', e: 'Se gasta 1 al usarlo', si: (v) => !!v.objeto },
    { k: 'llenarVida', t: 'bool', e: 'Llenar la vida al reaparecer', si: (v) => v.hace !== 'menu' },
    { k: 'aviso', t: 'texto', e: 'Aviso', ayuda: 'Vacío = "Punto de control" / "Partida guardada"' },
    { k: 'sonido', t: 'asset', e: 'Sonido', tipoAsset: 'audio', vacio: '(del motor)' },
    { grupo: 'Cómo se ve' },
    { k: 'figura', t: 'sel', e: 'Figura del motor', op: [['maquina', 'Máquina de escribir'], ['bandera', 'Bandera'], ['cristal', 'Cristal flotante'], ['ninguna', 'Ninguna (invisible)']], si: (v) => !v.modelo },
    { k: 'modelo', t: 'asset', e: 'Modelo', tipoAsset: 'modelo', vacio: '(figura del motor)' },
    { k: 'color', t: 'color', e: 'Color' },
  ];

  const GUARDADO = { donde: 'ambos', alMorir: 'gameover', alEntrarNivel: true, ranuraAuto: true };

  function figura(ent) {
    const s = { ...PUNTO, ...(ent.guardado || {}) };
    const g = new T.Group();
    const a = s.modelo && F.Assets && F.Assets.mapa.get(s.modelo);
    if (a && a.gltf) { g.add(T.SkeletonUtils.clone(a.gltf.scene)); return g; }
    const mat = (c) => F.Render.matRetro(c);
    const caja = (w, h, d, x, y, z, c) => { const o = new T.Mesh(new T.BoxGeometry(w, h, d), mat(c)); o.position.set(x, y, z); g.add(o); return o; };
    const brillo = new T.MeshBasicMaterial({ color: s.color, transparent: true, opacity: 0.85, fog: false });
    let luz = null;
    if (s.figura === 'maquina') {
      caja(0.8, 0.75, 0.5, 0, 0.375, 0, '#4a3a2c');                 // mesita
      caja(0.5, 0.14, 0.34, 0, 0.82, 0.02, '#2a2a2e');              // cuerpo de la máquina
      caja(0.46, 0.06, 0.16, 0, 0.92, -0.08, '#3a3a40');            // rodillo
      caja(0.3, 0.2, 0.01, 0, 1.02, -0.1, '#e8e2d0');               // hoja
      luz = new T.Mesh(new T.BoxGeometry(0.06, 0.06, 0.06), brillo); luz.position.set(0.2, 0.92, 0.12); g.add(luz);
    } else if (s.figura === 'bandera') {
      caja(0.06, 1.8, 0.06, 0, 0.9, 0, '#8a8a90');
      caja(0.3, 0.06, 0.3, 0, 0.03, 0, '#5a5a60');
      luz = new T.Mesh(new T.BoxGeometry(0.55, 0.36, 0.02), brillo); luz.position.set(0.3, 1.58, 0); g.add(luz);
    } else if (s.figura === 'cristal') {
      caja(0.5, 0.15, 0.5, 0, 0.075, 0, '#5a5a60');
      luz = new T.Mesh(new T.OctahedronGeometry(0.28, 0), brillo); luz.position.set(0, 1.0, 0); g.add(luz);
      g.userData.flota = luz;
    } else {
      // invisible en el juego: solo una marca en el editor
      const m = new T.Mesh(new T.BoxGeometry(0.6, 0.05, 0.6), new T.MeshBasicMaterial({ color: s.color, transparent: true, opacity: 0.4 }));
      m.position.y = 0.03; m.userData.ayudaEditor = true; g.add(m);
    }
    g.userData.luzGuardado = luz;
    return g;
  }

  /* Gestor por Juego: los toca, apaga los usados y avisa */
  class Gestor {
    constructor(juego, inicio) {
      this.juego = juego;
      this.lista = [];
      const usados = new Set((inicio && inicio.puntosUsados) || []);
      for (const ent of juego.escena.entidades) {
        if (ent.tipo !== 'guardado') continue;
        const obj = juego.objetos.get(ent.id);
        const p = { ...PUNTO, ...(ent.guardado || {}) };
        const it = { ent, obj, p, usado: usados.has(ent.id), dentro: false, t: Math.random() * 6 };
        this.lista.push(it);
        if (it.usado) this._apagar(it);
      }
      this.activo = null;   // el último que tocaste (checkpoint)
    }

    estado() { return this.lista.filter((x) => x.usado && x.p.unaVez).map((x) => x.ent.id); }

    textoUsar(ent) {
      const it = this.lista.find((x) => x.ent === ent);
      if (!it || (it.usado && it.p.unaVez)) return null;
      return it.p.texto || (it.p.hace === 'menu' ? 'Guardar partida' : 'Punto de control');
    }

    actualizar(dt) {
      const j = this.juego.jugador;
      if (!j || j.muerto) return;
      const c = j.cuerpo.pie;
      for (const it of this.lista) {
        const fl = it.obj && it.obj.userData.flota;
        if (fl) { it.t += dt; fl.position.y = 1.0 + Math.sin(it.t * 2) * 0.08; fl.rotation.y += dt; }
        if (it.p.activar !== 'tocar' || !it.obj || (it.usado && it.p.unaVez)) continue;
        const o = it.obj.position, d = Math.hypot(c.x - o.x, c.z - o.z), dy = Math.abs(c.y - o.y);
        const den = d < it.p.radio && dy < 2;
        if (den && !it.dentro) this.usar(it.ent);
        it.dentro = den;
      }
    }

    // lo usa el módulo Interactuar (botón de usar) y el toque
    usar(ent) {
      const it = this.lista.find((x) => x.ent === ent);
      if (!it || (it.usado && it.p.unaVez)) return false;
      const J = this.juego, j = J.jugador, p = it.p;
      if (p.objeto) {
        const inv = j.inventario;
        if (!inv || inv.contar('obj', p.objeto) < 1) {
          const ob = (J.proyecto.objetos || []).find((o) => o.id === p.objeto);
          this._aviso('Necesitas ' + (ob ? ob.nombre : 'un objeto'));
          return false;
        }
      }
      it.usado = true;
      if (p.unaVez) this._apagar(it);
      this.activo = it;
      if (p.sonido) F.Audio.efecto(p.sonido); else F.Audio.sintetico('recoger', { volumen: 0.6, tono: 0.8 });
      const gastar = () => { if (p.objeto && p.gastar && j.inventario) { j.inventario.gastar('obj', p.objeto, 1); } };
      if (p.hace !== 'menu') { gastar(); this._aviso(p.aviso || (p.hace === 'auto' ? 'Partida guardada' : 'Punto de control')); }
      F.emitir('punto-guardado', { juego: J, ent, p, gastar });
      return true;
    }

    _apagar(it) {
      const l = it.obj && it.obj.userData.luzGuardado;
      if (l) { l.material = l.material.clone(); l.material.color.set('#3a3a3a'); l.material.opacity = 0.6; }
    }

    _aviso(texto) {
      const el = F.Hud.pieza(this.juego, 'fg-aviso');
      el.style.cssText = 'position:absolute;left:50%;top:22%;transform:translateX(-50%);font-size:1.4em;letter-spacing:.15em;color:#ffe08a;text-shadow:2px 2px 0 #000;pointer-events:none;text-transform:uppercase;transition:opacity .4s;opacity:1';
      el.textContent = texto;
      clearTimeout(this._t); this._t = setTimeout(() => { el.style.opacity = '0'; }, 1600);
    }
  }

  F.Guardado = { PUNTO, ESQUEMA, GUARDADO, figura, Gestor };
})(window.FORJA);
