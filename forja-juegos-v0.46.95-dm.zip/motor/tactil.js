/* =========================================================
   FORJA · CONTROLES TÁCTILES (tablet / celular, sin mando ni teclado)
   - Mitad izquierda: stick que aparece donde pones el dedo → moverse.
   - Mitad derecha: arrastrar el dedo → mirar (como el ratón).
   - Botones de acción (lista BOTONES) y Pausa.
   No lee nada por su cuenta: llena FORJA.Entrada.virtual, así que los módulos del jugador
   ven las mismas acciones que con teclado o mando.

   Quién decide qué se ve:
   - El creador (Proyecto → Controles táctiles): qué botones existen en su juego.
   - El módulo: un botón de un módulo apagado no aparece (sin "Agacharse" no hay botón de agacharse).
   - "contextual": solo aparece cuando sirve (Usar, cuando miras algo con interacción).
   - El jugador (Opciones → Controles táctiles): tamaño, transparencia y dónde va cada botón (los arrastra).
   ========================================================= */
(function (F) {
  'use strict';

  /* Añadir un botón = una línea aquí.
     accion: la de FORJA.Entrada · modo: 'pulsar' (mientras el dedo está) o 'alternar' (toca = encender / apagar)
     modulo: solo si ese módulo del jugador está activo · lugar: [derecha, abajo] en vmin · tam: diámetro en vmin */
  const BOTONES = [
    { accion: 'saltar', texto: '⤒', etiqueta: 'Saltar', modo: 'pulsar', lugar: [4, 5], tam: 17, modulo: 'salto' },
    { accion: 'atacar', texto: '✸', etiqueta: 'Disparar', modo: 'pulsar', lugar: [4, 26], tam: 15, modulo: 'armas' },
    { accion: 'correr', texto: '»', etiqueta: 'Correr', modo: 'alternar', lugar: [24, 3], tam: 12, modulo: 'sprint' },
    { accion: 'esquivar', texto: '↯', etiqueta: 'Esquivar', modo: 'pulsar', lugar: [23, 17], tam: 11, modulo: 'esquiva' },
    { accion: 'agachar', texto: '▼', etiqueta: 'Agachar', modo: 'alternar', lugar: [38, 3], tam: 10, modulo: 'agachar' },
    { accion: 'apuntar', texto: '⊕', etiqueta: 'Apuntar', modo: 'alternar', lugar: [36, 15], tam: 10, modulo: 'armas' },
    { accion: 'recargar', texto: '↻', etiqueta: 'Recargar', modo: 'pulsar', lugar: [21, 30], tam: 9, modulo: 'armas' },
    { accion: 'arma_siguiente', texto: '⇄', etiqueta: 'Arma', modo: 'pulsar', lugar: [21, 41], tam: 9, modulo: 'armas' },
    { accion: 'interactuar', texto: '✋', etiqueta: 'Usar', modo: 'pulsar', lugar: [4, 45], tam: 12, modulo: 'interactuar', contextual: true },
    { accion: 'cambiar_camara', texto: '◎', etiqueta: 'Cámara', modo: 'pulsar', lugar: [15, 82], tam: 9 },
    { accion: 'inventario', texto: '🎒', etiqueta: 'Mochila', modo: 'pulsar', lugar: [4, 62], tam: 9, modulo: 'inventario' },
    { accion: 'ordenes', texto: '👥', etiqueta: 'Equipo', modo: 'pulsar', lugar: [26, 62], tam: 9, contextual: true },
    { accion: 'linterna', texto: '🔦', etiqueta: 'Linterna', modo: 'pulsar', lugar: [15, 70], tam: 9, modulo: 'linterna' },
    { accion: 'especial', texto: '✸', etiqueta: 'Especial', modo: 'pulsar', lugar: [36, 27], tam: 10, modulo: 'especial' },
    { accion: 'fijar', texto: '◈', etiqueta: 'Fijar', modo: 'pulsar', lugar: [36, 38], tam: 10, modulo: 'combate' },
  ];
  const POR_ACCION = Object.fromEntries(BOTONES.map((b) => [b.accion, b]));

  const CSS = `
  .ft { position: absolute; inset: 0; z-index: 25; touch-action: none; user-select: none; -webkit-user-select: none; display: none;
    --ft-escala: 1; --ft-opacidad: 1; }
  .ft-zona { position: absolute; top: 0; bottom: 0; }
  .ft-izq { left: 0; width: 45%; }
  .ft-der { right: 0; width: 55%; }
  .ft-base { position: absolute; width: calc(22vmin * var(--ft-escala)); height: calc(22vmin * var(--ft-escala));
    transform: translate(-50%, -50%); border-radius: 50%; opacity: var(--ft-opacidad);
    border: .5vmin solid rgba(255,255,255,.35); background: rgba(0,0,0,.18); display: none; pointer-events: none; }
  .ft-perilla { position: absolute; left: 50%; top: 50%; width: 40%; height: 40%; margin: -20% 0 0 -20%; border-radius: 50%;
    background: rgba(255,255,255,.45); box-shadow: 0 0 0 .4vmin rgba(0,0,0,.35); }
  .ft-guia { position: absolute; width: calc(18vmin * var(--ft-escala)); height: calc(18vmin * var(--ft-escala)); border-radius: 50%;
    border: .4vmin dashed rgba(255,255,255,.22); pointer-events: none; opacity: var(--ft-opacidad); }
  .ft-btn { position: absolute; border-radius: 50%; display: flex; align-items: center; justify-content: center;
    flex-direction: column; font-weight: bold; font-family: ui-monospace, Consolas, monospace; color: #fff; text-shadow: .3vmin .3vmin 0 #000;
    background: rgba(0,0,0,.28); border: .5vmin solid rgba(255,255,255,.4); opacity: var(--ft-opacidad); line-height: 1; }
  .ft-btn small { font-size: 1.7vmin; letter-spacing: .1em; margin-top: .4vmin; opacity: .85; }
  .ft-btn.activo { background: rgba(232,163,61,.55); border-color: #e8a33d; }
  .ft-btn.oculto { display: none; }
  .ft-pausa { position: absolute; top: 3vmin; right: 3vmin; width: 9vmin; height: 9vmin; border-radius: 1.5vmin; display: flex;
    align-items: center; justify-content: center; font: bold 4vmin ui-monospace, monospace; color: #fff;
    background: rgba(0,0,0,.3); border: .4vmin solid rgba(255,255,255,.4); opacity: var(--ft-opacidad); }
  /* Modo "acomodar": se ven todos y se arrastran */
  .ft.acomodar { background: rgba(0,0,0,.45); display: block; z-index: 40; }
  .ft.acomodar .ft-btn, .ft.acomodar .ft-guia { outline: .4vmin dashed #e8a33d; outline-offset: .6vmin; pointer-events: auto; }
  .ft.acomodar .ft-btn.oculto { display: flex; }
  .ft-barra { position: absolute; top: 3vmin; left: 50%; transform: translateX(-50%); display: none; gap: 2vmin; align-items: center;
    font: 2.6vmin ui-monospace, monospace; color: #fff; background: rgba(0,0,0,.75); padding: 1.5vmin 2.5vmin; border: .3vmin solid #e8a33d; }
  .ft.acomodar .ft-barra { display: flex; }
  .ft-barra button { font: inherit; padding: 1vmin 2.5vmin; background: #2a2f3a; color: #fff; border: .3vmin solid #888; }
  .ft-barra button.si { background: #e8a33d; color: #1a1408; border-color: #e8a33d; }
  `;

  const Tc = {
    modo: 'auto',            // 'auto' | 'siempre' | 'nunca'
    visible: false,
    acomodando: false,
    seToco: matchMedia('(pointer: coarse)').matches || ((navigator.maxTouchPoints || 0) > 0 && !matchMedia('(pointer: fine)').matches),
    raiz: null,
    contenedor: null,
    activos: new Set(BOTONES.map((b) => b.accion)),   // qué botones hay en esta partida
    contexto: {},            // accion → true cuando un botón contextual debe verse
    pos: {},                 // accion → [derecha, abajo] elegido por el jugador (y 'stick')
    escala: 1,
    opacidad: 1,
  };
  const V = () => F.Entrada.virtual;
  const dedos = new Map();   // pointerId → { tipo: 'stick' | 'mirar' | 'boton' | 'mover', … }

  function crear(contenedor) {
    if (!document.getElementById('estilos-forja-tactil')) {
      const st = document.createElement('style');
      st.id = 'estilos-forja-tactil';
      st.textContent = CSS;
      document.head.appendChild(st);
    }
    const r = document.createElement('div');
    r.className = 'ft';
    r.innerHTML = '<div class="ft-zona ft-izq"></div><div class="ft-zona ft-der"></div><div class="ft-guia" data-accion="stick"></div>' +
      '<div class="ft-base"><div class="ft-perilla"></div></div><div class="ft-pausa">II</div>' +
      '<div class="ft-barra">Arrastra los botones <button data-b="fabrica">Restablecer</button><button data-b="listo" class="si">Listo</button></div>';
    for (const b of BOTONES) {
      const el = document.createElement('div');
      el.className = 'ft-btn';
      el.dataset.accion = b.accion;
      el.innerHTML = `${b.texto}<small>${b.etiqueta}</small>`;
      r.appendChild(el);
      b.el = el;
    }
    if (getComputedStyle(contenedor).position === 'static') contenedor.style.position = 'relative';
    contenedor.appendChild(r);
    r.addEventListener('pointerdown', abajo);
    r.addEventListener('pointermove', mover);
    r.addEventListener('pointerup', arriba);
    r.addEventListener('pointercancel', arriba);
    r.addEventListener('contextmenu', (e) => e.preventDefault());
    Tc.raiz = r;
    Tc.contenedor = contenedor;
  }

  // Coloca botones y guía del stick según lo guardado por el jugador (o su lugar de fábrica)
  function colocar() {
    if (!Tc.raiz) return;
    Tc.raiz.style.setProperty('--ft-escala', Tc.escala);
    Tc.raiz.style.setProperty('--ft-opacidad', Tc.opacidad);
    for (const b of BOTONES) {
      const [x, y] = Tc.pos[b.accion] || b.lugar;
      const tam = b.tam * Tc.escala;
      Object.assign(b.el.style, { right: x + 'vmin', bottom: y + 'vmin', width: tam + 'vmin', height: tam + 'vmin', fontSize: tam * 0.4 + 'vmin' });
      const ver = Tc.activos.has(b.accion) && (!b.contextual || Tc.contexto[b.accion]);
      b.el.classList.toggle('oculto', !ver);
      if (Tc.acomodando) b.el.style.display = Tc.activos.has(b.accion) ? '' : 'none';
      else b.el.style.display = '';
    }
    const g = Tc.raiz.querySelector('.ft-guia');
    const [gx, gy] = Tc.pos.stick || [6, 8];
    g.style.left = gx + 'vmin';
    g.style.bottom = gy + 'vmin';
  }

  /* ---------- Dedos ---------- */
  const vmin = () => Math.min(Tc.raiz.clientWidth, Tc.raiz.clientHeight) / 100;

  function abajo(e) {
    e.preventDefault();
    try { Tc.raiz.setPointerCapture(e.pointerId); } catch (err) { /* sin captura también funciona */ }
    const t = e.target;
    if (Tc.acomodando) {
      const bb = t.closest('[data-b]');
      if (bb) { bb.dataset.b === 'fabrica' ? Tc.restablecerLugares() : Tc.terminarAcomodo(); return; }
      const el = t.closest('.ft-btn, .ft-guia');
      if (el) dedos.set(e.pointerId, { tipo: 'mover', el, accion: el.dataset.accion, x: e.clientX, y: e.clientY });
      return;
    }
    if (t.closest('.ft-pausa')) { F.emitir('juego-pausa'); return; }
    const btn = t.closest('.ft-btn');
    if (btn) {
      const b = POR_ACCION[btn.dataset.accion];
      if (b.modo === 'alternar') {
        const on = !V().acciones.has(b.accion);
        if (on) V().acciones.add(b.accion); else V().acciones.delete(b.accion);
        V().toques.add(b.accion);
        btn.classList.toggle('activo', on);
      } else {
        V().acciones.add(b.accion);
        V().toques.add(b.accion);       // un toque rapidísimo tampoco se pierde
        btn.classList.add('activo');
        dedos.set(e.pointerId, { tipo: 'boton', b });
      }
      return;
    }
    const caja = Tc.raiz.getBoundingClientRect();
    const x = e.clientX - caja.left, y = e.clientY - caja.top;
    if (x < caja.width * 0.45 && ![...dedos.values()].some((d) => d.tipo === 'stick')) {
      const base = Tc.raiz.querySelector('.ft-base');
      base.style.display = 'block';
      base.style.left = x + 'px';
      base.style.top = y + 'px';
      Tc.raiz.querySelector('.ft-guia').style.display = 'none';
      dedos.set(e.pointerId, { tipo: 'stick', x0: x, y0: y });
    } else {
      dedos.set(e.pointerId, { tipo: 'mirar', x: e.clientX, y: e.clientY });
    }
  }

  function mover(e) {
    const d = dedos.get(e.pointerId);
    if (!d) return;
    e.preventDefault();
    if (d.tipo === 'mirar') {
      V().mx += e.clientX - d.x;
      V().my += e.clientY - d.y;
      d.x = e.clientX;
      d.y = e.clientY;
    } else if (d.tipo === 'stick') {
      const caja = Tc.raiz.getBoundingClientRect();
      const radio = Math.min(caja.width, caja.height) * 0.09 * Tc.escala;
      let dx = e.clientX - caja.left - d.x0, dy = e.clientY - caja.top - d.y0;
      const l = Math.hypot(dx, dy);
      if (l > radio) { dx *= radio / l; dy *= radio / l; }
      Tc.raiz.querySelector('.ft-perilla').style.transform = `translate(${dx}px, ${dy}px)`;
      let vx = dx / radio, vy = -dy / radio;
      if (Math.hypot(vx, vy) < 0.15) vx = vy = 0;   // zona muerta
      V().x = vx;
      V().y = vy;
    } else if (d.tipo === 'mover') {
      // acomodar: los botones se miden desde abajo-derecha; la guía del stick desde abajo-izquierda
      const u = vmin();
      const dx = (e.clientX - d.x) / u, dy = (e.clientY - d.y) / u;
      d.x = e.clientX;
      d.y = e.clientY;
      const b = POR_ACCION[d.accion];
      const [px, py] = Tc.pos[d.accion] || (b ? b.lugar : [6, 8]);
      const nx = d.accion === 'stick' ? px + dx : px - dx;
      Tc.pos[d.accion] = [Math.max(0, +nx.toFixed(1)), Math.max(0, +(py - dy).toFixed(1))];
      colocar();
    }
  }

  function arriba(e) {
    const d = dedos.get(e.pointerId);
    dedos.delete(e.pointerId);
    if (!d) return;
    if (d.tipo === 'boton') {
      V().acciones.delete(d.b.accion);
      d.b.el.classList.remove('activo');
    } else if (d.tipo === 'stick') {
      V().x = V().y = 0;
      Tc.raiz.querySelector('.ft-base').style.display = 'none';
      Tc.raiz.querySelector('.ft-perilla').style.transform = '';
      Tc.raiz.querySelector('.ft-guia').style.display = '';
      // al soltar el stick se deja de correr (como soltar el L3)
      V().acciones.delete('correr');
      if (POR_ACCION.correr.el) POR_ACCION.correr.el.classList.remove('activo');
    } else if (d.tipo === 'mover' && Tc.alGuardar) {
      Tc.alGuardar(Tc.pos);
    }
  }

  /* ---------- Mostrar / ocultar ---------- */
  Tc.debeVerse = () => Tc.modo === 'siempre' || (Tc.modo === 'auto' && Tc.seToco);

  // Lo que eligió el creador (ajustes) y los módulos activos del jugador
  Tc.configurar = function (ajustes, jugador) {
    Tc.modo = (ajustes && ajustes.controlesTactiles) || 'auto';
    Tc.activos = new Set(BOTONES.filter((b) =>
      (!ajustes || ajustes['tb_' + b.accion] !== false) && (!b.modulo || b.contextual || !jugador || jugador.tieneModulo(b.modulo))).map((b) => b.accion));
    colocar();
  };

  // Lo que eligió el jugador (Opciones)
  Tc.preferencias = function ({ escala = 1, opacidad = 1, pos = {} } = {}) {
    Tc.escala = escala;
    Tc.opacidad = opacidad;
    Tc.pos = { ...pos };
    colocar();
  };

  Tc.ponerContexto = function (accion, si) {
    if (!!Tc.contexto[accion] === !!si) return;
    Tc.contexto[accion] = !!si;
    const b = POR_ACCION[accion];
    if (b && b.el) b.el.classList.toggle('oculto', !(Tc.activos.has(accion) && si));
  };

  Tc.mostrar = function (contenedor) {
    if (!Tc.debeVerse()) { Tc.ocultar(); return; }
    if (!Tc.raiz || Tc.contenedor !== contenedor) {
      if (Tc.raiz) Tc.raiz.remove();
      crear(contenedor);
    }
    colocar();
    Tc.raiz.style.display = 'block';
    Tc.visible = true;
    F.Entrada.tactil = true;
    F.Entrada.soltarBloqueo();
  };

  Tc.ocultar = function () {
    if (Tc.acomodando) return;
    if (Tc.raiz) Tc.raiz.style.display = 'none';
    Tc.visible = false;
    F.Entrada.tactil = false;
    dedos.clear();
    const v = V();
    v.x = v.y = 0;
    v.acciones.clear();
    for (const b of BOTONES) if (b.el) b.el.classList.remove('activo');
  };

  /* Acomodar (desde Opciones → Controles táctiles): se ven todos los botones y se arrastran.
     alGuardar(pos) se llama al soltar cada uno · alTerminar() al pulsar "Listo" */
  Tc.acomodar = function (contenedor, { alGuardar, alTerminar } = {}) {
    if (!Tc.raiz || Tc.contenedor !== contenedor) {
      if (Tc.raiz) Tc.raiz.remove();
      crear(contenedor);
    }
    Tc.acomodando = true;
    Tc.alGuardar = alGuardar;
    Tc.alTerminar = alTerminar;
    Tc.raiz.classList.add('acomodar');
    Tc.raiz.style.display = 'block';
    colocar();
  };
  Tc.restablecerLugares = function () {
    Tc.pos = {};
    colocar();
    if (Tc.alGuardar) Tc.alGuardar(Tc.pos);
  };
  Tc.terminarAcomodo = function () {
    Tc.acomodando = false;
    Tc.raiz.classList.remove('acomodar');
    Tc.raiz.style.display = 'none';
    dedos.clear();
    colocar();
    const fin = Tc.alTerminar;
    Tc.alGuardar = Tc.alTerminar = null;
    if (fin) fin();
  };

  // Cualquier toque en la página = es un dispositivo táctil (modo Automático)
  window.addEventListener('touchstart', () => { Tc.seToco = true; }, { passive: true, capture: true });

  // Aparecen al jugar y se esconden en menús, pausa o al volver al editor
  F.on('juego-iniciado', (j) => {
    Tc.contexto = {};
    Tc.configurar(j.ajustes, j.jugador);
    Tc.mostrar(j.vista.contenedor);
  });
  F.on('partida-jugando', (p) => { if (p.juego) Tc.mostrar(p.vista.contenedor); });
  F.on('partida-pausa', () => Tc.ocultar());
  F.on('juego-detenido', () => Tc.ocultar());

  Tc.BOTONES = BOTONES;
  F.Tactil = Tc;
})(window.FORJA);
