/* =========================================================
   FORJA · 💥 EXPLOSIONES (baratas, como las partículas)
   Cada explosión es UN dibujo de puntos que se mueven en la GPU (bola de fuego, chispas y humo) más un
   destello (esfera que crece y se apaga). La CPU solo cambia un número por cuadro (la edad).
   Hay un grupo fijo de 6 por vista que se recicla: lanzar muchas no crea ni borra nada.

   F.Explosiones.lanzar(juego, punto, opciones) → visual + sonido + temblor (+ daño si dano > 0)
     opciones: { tam: 'pequena' | 'media' | 'grande', radio (m, si no sale del tamaño), dano (0 = sin daño),
                 humo (true), sonido (asset o '' = el del motor), temblor (true), color ('#ff8a3a') }
   F.Explosiones.efecto(juego, punto, radio, color) → solo lo que se ve (lo usa tactico.explosion)
   ========================================================= */
(function (F) {
  'use strict';
  const T = THREE;

  const TAMANOS = { pequena: 1.5, media: 3, grande: 5 };
  const OP_TAMANOS = [['pequena', '💥 Pequeña (granada)'], ['media', '💥 Mediana (barril)'], ['grande', '💥 Grande (coche, depósito)']];
  const N_FUEGO = 70, N_CHISPA = 30, N_HUMO = 34, N = N_FUEGO + N_CHISPA + N_HUMO;
  const VIDA = 3;   // segundos que dura todo (el humo es lo último)

  // geometría compartida por todas (semillas al azar + clase de cada punto)
  let _geo = null;
  function geometria() {
    if (_geo) return _geo;
    const pos = new Float32Array(N * 3), sem = new Float32Array(N * 4), clase = new Float32Array(N);
    for (let i = 0; i < N * 4; i++) sem[i] = Math.random();
    for (let i = 0; i < N; i++) clase[i] = i < N_FUEGO ? 0 : i < N_FUEGO + N_CHISPA ? 1 : 2;
    _geo = new T.BufferGeometry();
    _geo.setAttribute('position', new T.BufferAttribute(pos, 3));
    _geo.setAttribute('aS', new T.BufferAttribute(sem, 4));
    _geo.setAttribute('aClase', new T.BufferAttribute(clase, 1));
    _geo.boundingSphere = new T.Sphere(new T.Vector3(), 30);
    return _geo;
  }
  let _esfera = null;

  const VERT = `
    uniform float uEdad, uRadio, uAltoPx;
    attribute vec4 aS;
    attribute float aClase;
    varying float vK;
    varying float vClase;
    void main() {
      vClase = aClase;
      vec3 dir = normalize(vec3(aS.x * 2.0 - 1.0, aS.y * 1.3 - 0.25, aS.z * 2.0 - 1.0) + 1e-3);
      vec3 p = vec3(0.0);
      float tam = 0.0, k = 1.0;
      if (aClase < 0.5) {
        // 🔥 bola de fuego: sale rápido y se frena, crece y luego se encoge
        float L = 0.55 + 0.45 * aS.w;
        k = uEdad / L;
        float sal = 1.0 - pow(1.0 - min(k, 1.0), 3.0);
        p = dir * uRadio * 0.75 * sal * (0.35 + 0.65 * aS.w);
        p.y += uRadio * 0.25 * k;
        tam = uRadio * 0.42 * (0.5 + 0.9 * min(k * 3.0, 1.0)) * (1.0 - 0.6 * k);
      } else if (aClase < 1.5) {
        // ✨ chispas y trozos: salen disparados y caen
        float L = 0.9 + 0.6 * aS.w;
        k = uEdad / L;
        float t = uEdad;
        p = dir * uRadio * (1.8 + 1.6 * aS.w) * t + vec3(0.0, uRadio * 1.2 * t - 6.0 * t * t, 0.0);
        tam = uRadio * 0.05 * (1.0 - 0.7 * k);
      } else {
        // 💨 humo: aparece un poco después, sube y se abre
        float t = uEdad - 0.12 - 0.2 * aS.w;
        float L = 2.2 + 0.7 * aS.w;
        k = t < 0.0 ? 2.0 : t / L;
        p = dir * uRadio * 0.55 * sqrt(max(k, 0.0)) + vec3(0.0, uRadio * 0.9 * k + uRadio * 0.2, 0.0);
        tam = uRadio * 0.45 * (0.6 + 1.4 * k);
      }
      vK = k;
      if (k > 1.0 || k < 0.0) { gl_Position = vec4(2.0, 2.0, 2.0, 1.0); gl_PointSize = 0.0; return; }
      vec4 mv = modelViewMatrix * vec4(p, 1.0);
      gl_Position = projectionMatrix * mv;
      gl_PointSize = clamp(tam * projectionMatrix[1][1] * uAltoPx * 0.5 / max(-mv.z, 0.05), 1.0, uAltoPx * 0.2);
    }`;
  const FRAG = `
    uniform vec3 uColor;
    uniform float uHumo;
    varying float vK;
    varying float vClase;
    void main() {
      vec3 c; float a;
      if (vClase < 0.5) {
        c = mix(vec3(1.0, 0.95, 0.6), uColor, smoothstep(0.0, 0.45, vK));
        c = mix(c, vec3(0.25, 0.08, 0.04), smoothstep(0.55, 1.0, vK));
        a = 1.0 - smoothstep(0.7, 1.0, vK);
      } else if (vClase < 1.5) {
        c = mix(vec3(1.0, 0.9, 0.5), uColor, vK); a = 1.0 - vK;
      } else {
        if (uHumo < 0.5) discard;
        c = mix(vec3(0.35), vec3(0.18), vK); a = 0.75 * (1.0 - vK) * smoothstep(0.0, 0.08, vK);
      }
      if (a < 0.02) discard;
      gl_FragColor = vec4(c, a);
    }`;

  // Grupo fijo por vista (se crea la primera vez)
  function pool(vista) {
    if (vista._explosiones) return vista._explosiones;
    const L = [];
    if (!_esfera) _esfera = new T.SphereGeometry(1, 10, 8);
    const tmp = new T.Vector2();
    for (let i = 0; i < 6; i++) {
      const mat = new T.ShaderMaterial({
        uniforms: { uEdad: { value: 99 }, uRadio: { value: 3 }, uAltoPx: { value: 480 }, uColor: { value: new T.Color('#ff8a3a') }, uHumo: { value: 1 } },
        vertexShader: VERT, fragmentShader: FRAG, transparent: true, depthWrite: false,
      });
      const pts = new T.Points(geometria(), mat);
      pts.frustumCulled = false;
      pts.visible = false;
      pts.raycast = () => {};
      pts.renderOrder = 5;
      const flash = new T.Mesh(_esfera, new T.MeshBasicMaterial({ color: 0xffd080, transparent: true, opacity: 0, depthWrite: false, blending: T.AdditiveBlending, fog: false }));
      flash.visible = false;
      flash.raycast = () => {};
      const x = { pts, flash, t0: 0, radio: 3 };
      // la edad se pone justo antes de dibujar: funciona igual jugando, en pausa de cinemática o en el editor
      pts.onBeforeRender = (r) => {
        const rt = r.getRenderTarget();
        if (rt) tmp.set(rt.width, rt.height); else r.getDrawingBufferSize(tmp);
        mat.uniforms.uAltoPx.value = tmp.y;
        const edad = (performance.now() - x.t0) / 1000;
        mat.uniforms.uEdad.value = edad;
        const kf = edad / 0.3;
        if (kf < 1) { flash.visible = true; flash.scale.setScalar(x.radio * (0.3 + 0.6 * kf)); flash.material.opacity = 0.85 * (1 - kf); }
        else flash.visible = false;
        if (edad > VIDA) { pts.visible = false; flash.visible = false; }
      };
      vista.escena.add(pts, flash);
      L.push(x);
    }
    vista._explosiones = L;
    return L;
  }

  /* Solo lo que se ve (destello, fuego, chispas, humo) */
  function efecto(juego, punto, radio = 3, color = '#ff8a3a', humo = true) {
    const vista = juego.vista || juego;
    const L = pool(vista);
    // la libre, o la más vieja
    let x = L.find((e) => !e.pts.visible) || L.reduce((a, b) => (a.t0 < b.t0 ? a : b));
    x.t0 = performance.now();
    x.radio = radio;
    x.pts.position.copy(punto);
    x.flash.position.copy(punto);
    x.pts.material.uniforms.uRadio.value = radio;
    x.pts.material.uniforms.uColor.value.set(color || '#ff8a3a');
    x.pts.material.uniforms.uHumo.value = humo === false ? 0 : 1;
    x.pts.visible = true;
    // si la escena se rehízo (otro nivel) vuelve a meterse
    if (x.pts.parent !== vista.escena) vista.escena.add(x.pts, x.flash);
    return x;
  }

  const _w = new T.Vector3();
  /* Explosión completa: lo que se ve + sonido + temblor + (con dano) daño a jugador, enemigos y rompibles */
  function lanzar(juego, punto, op = {}) {
    const J = juego;
    const radio = op.radio > 0 ? op.radio : TAMANOS[op.tam] || TAMANOS.media;
    efecto(J, punto, radio, op.color, op.humo !== false);
    if (op.sonido) F.Audio.efecto(op.sonido);
    else F.Audio.sintetico('explosion', { volumen: Math.min(1, 0.5 + radio / 8), tono: 0.8 + Math.random() * 0.2 });
    F.emitir('explosion', punto, radio);   // armas: quemadura en el suelo
    const j = J.jugador;
    // 📳 temblor: en una cinemática lo hace su cámara; jugando, la del jugador (según la distancia)
    if (op.temblor !== false) {
      if (J.cine && J.cine.activo) J.cine.sacudir(Math.min(1.2, radio / 4), 0.8);
      else if (j && j.cuerpo) {
        const d = punto.distanceTo(_w.copy(j.cuerpo.pie));
        const f = Math.max(0, 1 - d / (radio * 4));
        if (f > 0) j.temblor = Math.max(j.temblor || 0, 0.7 * f);
      }
    }
    // 💥 daño (como un barril): cae con la distancia
    if (op.dano > 0) {
      const caida = (d) => Math.max(0, 1 - d / radio);
      if (j && j.danar && !j.muerto) {
        const dj = punto.distanceTo(_w.set(j.cuerpo.pie.x, j.cuerpo.pie.y + 1, j.cuerpo.pie.z));
        if (dj < radio) j.danar(op.dano * caida(dj), 'explosion');
      }
      const EN = J.enemigos;
      if (EN) {
        for (const E of EN.lista) {
          if (E.muerto) continue;
          const d = punto.distanceTo(_w.set(E.cuerpo.pie.x, E.cuerpo.pie.y + 1, E.cuerpo.pie.z));
          if (d < radio) EN.danar(E, op.dano * caida(d), { tipo: 'explosivo' });
        }
        if (EN.ruidos) EN.ruidos.push({ x: punto.x, y: punto.y, z: punto.z, fuerza: 1.5, t: EN.t });
      }
      for (const x of [...(J.objetivos || [])]) {
        if (x.esEnemigo) continue;   // a los enemigos ya se les dañó arriba
        const d = x.obj.getWorldPosition(_w).distanceTo(punto);
        if (d < radio) setTimeout(() => { if (J.enMarcha) x.danar(op.dano * caida(d), null, { tipo: 'explosivo' }); }, 80 + d * 40);
      }
    }
  }

  /* Dónde: una entidad del nivel (su posición; los personajes a media altura) o el jugador */
  function puntoDe(juego, id, out = new T.Vector3()) {
    if (id === '__jugador' && juego.jugador) return out.copy(juego.jugador.cuerpo.pie).add(_w.set(0, 1, 0));
    const o = id && juego.objetos.get(id);
    if (!o) return null;
    o.getWorldPosition(out);
    out.y += 0.5;
    return out;
  }

  F.Explosiones = { TAMANOS, OP_TAMANOS, efecto, lanzar, puntoDe };
})(window.FORJA);
