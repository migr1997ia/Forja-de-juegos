/* =========================================================
   FORJA · HUD
   Capa HTML encima del juego para barras, munición, mira, avisos ("E: Leer"), mensajes y pantallazos
   (rojo al recibir daño, negro al morir). Los módulos piden sus piezas con FORJA.Hud.pieza(juego, 'clase') y solo
   cambian el texto o el estilo cuando su valor cambia (tocar el HTML cada cuadro sí cuesta).
   DÓNDE va cada pieza y QUÉ se ve lo decide proyecto.hud (pestaña Juego ▸ HUD): son clases en la capa,
   así que cambiar de plantilla no toca a los módulos.
   Usa la fuente y los colores del tema de Menús, así todo el juego se ve igual.
   ========================================================= */
(function (F) {
  'use strict';

  // --fh-u: 1vmin en el juego; en la vista previa del editor, píxeles de la cajita
  const CSS = `
  .fhud { --fh-u: 1vmin; --fh-m: 3; position: absolute; inset: 0; z-index: 20; pointer-events: none; overflow: hidden;
    font-family: var(--fh-fuente); color: var(--fh-texto); font-size: calc(2.6 * var(--fh-u) * var(--fh-escala, 1)); }
  .fhud .fh-barras, .fhud .fh-municion, .fhud .fh-recogidos { position: absolute; z-index: 1; text-shadow: .12em .12em 0 #000; }
  .fhud .fh-barras { display: flex; flex-direction: column; gap: .5em; }
  .fhud .fh-barra { display: flex; align-items: center; gap: .5em; }
  .fhud .fh-barra .fh-ico { width: 1.2em; text-align: center; }
  .fhud .fh-barra .fh-caja { width: 9em; height: .7em; background: rgba(0,0,0,.55); border: .12em solid rgba(255,255,255,.55); }
  .fhud .fh-barra .fh-lleno { height: 100%; background: var(--fh-color); transition: width .15s steps(4); }
  .fhud .fh-barra .fh-num { min-width: 2.2em; }
  .fhud .fh-municion { display: flex; align-items: baseline; gap: .45em; font-size: 1.3em; white-space: nowrap; }
  .fhud .fh-municion .fh-arma { font-size: .7em; opacity: .85; }
  .fhud .fh-municion.fh-vacio { display: none; }
  .fhud .fh-recogidos { display: flex; flex-direction: column; gap: .25em; }
  .fhud .fh-recogidos div { animation: fh-recogido 2.2s steps(8) forwards; }
  @keyframes fh-recogido { 0%, 70% { opacity: 1; } 100% { opacity: 0; } }

  /* --- posiciones (proyecto.hud.posicion) --- */
  .fhud { --fh-b: calc(var(--fh-m) * var(--fh-u)); }
  :is(.fh-pos-esquinas, .fh-pos-libre) .fh-barras { left: var(--fh-b); bottom: var(--fh-b); }
  :is(.fh-pos-esquinas, .fh-pos-libre) .fh-municion { right: var(--fh-b); bottom: var(--fh-b); }
  :is(.fh-pos-esquinas, .fh-pos-libre) .fh-recogidos { left: var(--fh-b); top: var(--fh-b); }
  /* ✥ libre: la pieza movida a mano (left/top en % los pone colocar) */
  .fhud .fh-libre { position: absolute !important; z-index: 1; }

  /* Quake / Doom: una franja abajo de lado a lado, en tres casillas (armadura · vida · munición) con números grandes
     y su nombre debajo; el número se pone rojo y parpadea cuando queda poco */
  .fh-pos-barra { --fh-alto: calc(var(--fh-b) * 1.2 + 3.6em); }
  .fh-pos-barra .fh-barras { left: 0; width: 66.6%; bottom: 0; height: var(--fh-alto); flex-direction: row; gap: 0; align-items: stretch; }
  .fh-pos-barra .fh-barra { flex: 1; justify-content: center; position: relative; padding-bottom: 1em; }
  .fh-pos-barra .fh-barras .fh-arm { order: -1; border-right: .12em solid rgba(255,255,255,.18); }
  .fh-pos-barra .fh-barra .fh-ico { font-size: 1.7em; width: auto; }
  .fh-pos-barra .fh-barra .fh-num { font-size: 2.3em; min-width: 1.8em; text-align: left; font-weight: bold; }
  .fh-pos-barra .fh-barra .fh-caja { width: 5em; }
  .fh-pos-barra .fh-barra::after { position: absolute; bottom: .55em; left: 0; right: 0; text-align: center; font-size: .7em;
    letter-spacing: .25em; opacity: .65; }
  .fh-pos-barra .fh-vida::after { content: 'VIDA'; }
  .fh-pos-barra .fh-arm::after { content: 'ARMADURA'; }
  .fh-pos-barra .fh-municion { right: 0; width: 33.4%; bottom: 0; height: var(--fh-alto); justify-content: center; align-items: center;
    gap: .35em; padding-bottom: 1em; box-sizing: border-box; border-left: .12em solid rgba(255,255,255,.18); font-size: 1em; }
  .fh-pos-barra .fh-municion .fh-arma { position: absolute; bottom: .55em; left: 0; right: 0; text-align: center; font-size: .7em; letter-spacing: .25em; text-transform: uppercase; opacity: .65; }
  .fh-pos-barra .fh-municion .fh-ico { font-size: 1.4em; }
  .fh-pos-barra .fh-municion .fh-num { font-size: 1.8em; font-weight: bold; }
  .fh-pos-barra .fh-recogidos { left: var(--fh-b); top: var(--fh-b); }
  .fh-pos-barra::after { content: ''; position: absolute; left: 0; right: 0; bottom: 0; height: var(--fh-alto); z-index: 0;
    background: var(--fh-fondo); border-top: .15em solid rgba(255,255,255,.3); box-shadow: inset 0 .2em 0 rgba(0,0,0,.35); }
  .fh-pos-barra:not(.fh-fondo)::after { background: linear-gradient(transparent, rgba(0,0,0,.45)); border-top: none; box-shadow: none; }

  /* Centrado: todo junto abajo al centro, a los lados de la mira (consolas modernas) */
  .fh-pos-centro .fh-barras { right: calc(50% + .8em); bottom: var(--fh-b); gap: .35em; align-items: flex-end; }
  .fh-pos-centro .fh-barra { flex-direction: row-reverse; }
  .fh-pos-centro .fh-municion { left: calc(50% + .8em); bottom: var(--fh-b); }
  .fh-pos-centro .fh-recogidos { left: 50%; top: var(--fh-b); transform: translateX(-50%); align-items: center; }
  .fh-pos-centro .fh-barra .fh-caja { width: 6em; }

  /* poca vida / poca munición: rojo y parpadeo de la época */
  .fhud .fh-bajo .fh-num, .fhud .fh-municion.fh-bajo .fh-num { color: #ff4a3a; animation: fh-parpadeo .8s steps(2) infinite; }
  @keyframes fh-parpadeo { 50% { opacity: .35; } }

  .fh-pos-arriba .fh-barras { left: 50%; top: var(--fh-b); transform: translateX(-50%); align-items: center; }
  .fh-pos-arriba .fh-barras .fh-arm { order: -1; }
  .fh-pos-arriba .fh-barras .fh-arm .fh-caja { width: 16em; height: .9em; }
  .fh-pos-arriba .fh-municion { right: var(--fh-b); top: var(--fh-b); }
  .fh-pos-arriba .fh-recogidos { left: var(--fh-b); bottom: var(--fh-b); }

  .fh-pos-arcade .fh-barras { left: var(--fh-b); top: var(--fh-b); flex-direction: row; gap: 1.5em; }
  .fh-pos-arcade .fh-municion { right: var(--fh-b); top: var(--fh-b); }
  .fh-pos-arcade .fh-barra .fh-num { font-size: 1.5em; }
  .fh-pos-arcade .fh-recogidos { left: 50%; top: var(--fh-b); transform: translateX(-50%); align-items: center; }

  .fh-pos-discreto .fh-barras { right: var(--fh-b); bottom: calc(var(--fh-b) + 2.6em); align-items: flex-end; }
  .fh-pos-discreto .fh-barra { flex-direction: row-reverse; }
  .fh-pos-discreto .fh-barra .fh-caja { width: 6em; }
  .fh-pos-discreto .fh-municion { right: var(--fh-b); bottom: var(--fh-b); }
  .fh-pos-discreto .fh-recogidos { left: var(--fh-b); top: var(--fh-b); }

  /* --- estilo --- */
  .fhud.fh-fondo:not(.fh-pos-barra) .fh-barras, .fhud.fh-fondo:not(.fh-pos-barra) .fh-municion {
    background: var(--fh-fondo); padding: .45em .75em; border: .1em solid rgba(255,255,255,.18); }
  .fh-est-numero .fh-barra .fh-caja { display: none; }
  .fh-est-barra .fh-barra .fh-num { display: none; }
  .fh-sin-iconos .fh-barra .fh-ico { display: none; }
  .fh-sin-sombra .fh-barras, .fh-sin-sombra .fh-municion, .fh-sin-sombra .fh-recogidos { text-shadow: none; }
  .fh-no-vida .fh-vida, .fh-no-arm .fh-arm, .fh-no-mun .fh-municion, .fh-no-nombre .fh-municion .fh-arma,
  .fh-no-icomun .fh-municion .fh-ico, .fh-no-recog .fh-recogidos, .fh-no-recog .fh-tinte { display: none !important; }
  /* aparecen al cambiar y se esconden solas (survival) */
  .fh-auto .fh-barras, .fh-auto .fh-municion { opacity: 0; transition: opacity .5s; }
  .fh-auto .fh-barras.fh-ver, .fh-auto .fh-municion.fh-ver { opacity: 1; transition: opacity .1s; }

  /* --- mira --- */
  .fhud .fh-mira { position: absolute; left: 50%; top: 50%; transform: translate(-50%, -50%); display: none;
    --c: var(--fh-mira, #fff); filter: drop-shadow(0 0 1px #000) drop-shadow(0 0 1px #000); }
  .fhud .fh-mira.fh-ver { display: block; }
  .fh-mira-punto .fh-mira { width: calc(4px * var(--fh-mt)); height: calc(4px * var(--fh-mt)); background: var(--c); }
  .fh-mira-cruz .fh-mira { width: calc(14px * var(--fh-mt)); height: calc(14px * var(--fh-mt));
    background: linear-gradient(var(--c), var(--c)) center / 100% 2px no-repeat, linear-gradient(var(--c), var(--c)) center / 2px 100% no-repeat; }
  .fh-mira-abierta .fh-mira { width: calc(20px * var(--fh-mt)); height: calc(20px * var(--fh-mt));
    background: linear-gradient(var(--c), var(--c)) 50% 0 / 2px 35% no-repeat, linear-gradient(var(--c), var(--c)) 50% 100% / 2px 35% no-repeat,
      linear-gradient(var(--c), var(--c)) 0 50% / 35% 2px no-repeat, linear-gradient(var(--c), var(--c)) 100% 50% / 35% 2px no-repeat; }
  .fh-mira-circulo .fh-mira { width: calc(16px * var(--fh-mt)); height: calc(16px * var(--fh-mt)); border: 2px solid var(--c); border-radius: 50%;
    background: radial-gradient(var(--c) 1.5px, transparent 2px); }

  /* --- avisos, mensajes y pantallazos --- */
  .fhud .fh-aviso { position: absolute; left: 50%; top: 62%; transform: translateX(-50%); padding: .3em .8em;
    background: rgba(0,0,0,.6); border: .1em solid var(--fh-sel); white-space: nowrap; display: none; }
  .fhud .fh-mensaje { position: absolute; left: 50%; bottom: 12%; transform: translateX(-50%); width: min(80%, 34em);
    font-size: calc(1em * var(--fm-tam, 1));
    padding: .9em 1.2em; background: rgba(0,0,0,.82); border: .12em solid var(--fh-sel); line-height: 1.4; display: none;
    pointer-events: auto; white-space: pre-wrap; z-index: 3; }
  .fhud .fh-mensaje b.fh-titulo { display: block; margin-bottom: .5em; color: var(--fh-sel); letter-spacing: .1em; }
  .fhud .fh-mensaje small { display: block; margin-top: .8em; opacity: .6; font-size: .75em; text-align: right; }
  /* --- barra de aire bajo el agua (módulo Nadar) --- */
  .fhud .fh-aire { position: absolute; left: 50%; bottom: 20%; transform: translateX(-50%); display: none; align-items: center; gap: .5em;
    font-size: .75em; letter-spacing: .12em; text-shadow: .1em .1em 0 #000; }
  .fhud .fh-aire.fh-ver { display: flex; }
  .fhud .fh-aire-caja { width: 9em; height: .6em; background: rgba(0,0,0,.55); border: .12em solid rgba(255,255,255,.55); }
  .fhud .fh-aire-lleno { height: 100%; background: var(--fh-color, #7fd4ff); transition: width .2s steps(4); }
  .fhud .fh-aire.fh-bajo .fh-aire-lleno { background: #e0473a; animation: fh-parpadeo .5s steps(2) infinite; }
  @keyframes fh-parpadeo { 50% { opacity: .35; } }
  /* --- jefe y oleadas (los pone motor/enemigos.js) --- */
  .fhud .fh-jefe { position: absolute; left: 50%; top: 5%; transform: translateX(-50%); width: min(60%, 30em); text-align: center; display: none; }
  .fhud .fh-jefe b { display: block; font-size: .85em; letter-spacing: .12em; margin-bottom: .25em; text-shadow: 0 0 .3em #000; }
  .fhud .fh-jcaja { height: .7em; border: .12em solid rgba(0,0,0,.8); background: rgba(0,0,0,.55); }
  .fhud .fh-jlleno { height: 100%; width: 100%; background: linear-gradient(#e0473a, #9a2018); transition: width .15s; }
  .fhud .fh-oleadas { position: absolute; left: 50%; top: 12%; transform: translateX(-50%); font-size: .8em; letter-spacing: .1em;
    padding: .2em .7em; background: rgba(0,0,0,.45); white-space: nowrap; display: none; }
  .fhud .fh-cartel { position: absolute; left: 50%; top: 30%; transform: translateX(-50%); font-size: 2.4em; letter-spacing: .18em;
    color: var(--fh-sel); text-shadow: 0 0 .25em #000, 0 .08em 0 #000; white-space: nowrap; display: none; }
  .fhud .fh-cartel.fh-ver { display: block; animation: fh-cartel .5s ease-out; }
  .fhud .fh-jefe.fh-ver, .fhud .fh-oleadas.fh-ver { display: block; }
  @keyframes fh-cartel { from { opacity: 0; transform: translateX(-50%) scale(1.6); } to { opacity: 1; transform: translateX(-50%) scale(1); } }
  .fhud .fh-rojo { position: absolute; inset: 0; background: radial-gradient(ellipse at center, rgba(160,0,0,0) 35%, rgba(200,0,0,.75) 100%);
    opacity: 0; transition: opacity .35s; z-index: 2; }
  .fhud .fh-negro { position: absolute; inset: 0; background: #000; opacity: 0; z-index: 4; }
  .fhud .fh-tinte { position: absolute; inset: 0; opacity: 0; transition: opacity .4s; mix-blend-mode: screen; }
  /* --- zonas: las piezas fijas se apilan en 5 columnas y nunca se pisan --- */
  .fhud .fh-zona { position: absolute; z-index: 1; display: flex; flex-direction: column; gap: .45em; pointer-events: none; }
  .fhud .fh-zona:empty { display: none; }
  .fhud .fh-zona > * { position: relative !important; left: auto !important; right: auto !important; top: auto !important; bottom: auto !important; transform: none !important; }
  .fhud .fh-z-ti { left: var(--fh-b); top: var(--fh-b); align-items: flex-start; }
  .fhud .fh-z-tc { left: 50%; top: calc(var(--fh-b) * .6); transform: translateX(-50%); align-items: center; }
  .fhud .fh-z-td { right: var(--fh-b); top: var(--fh-b); align-items: flex-end; }
  .fhud .fh-z-bi { left: var(--fh-b); bottom: var(--fh-b); align-items: flex-start; justify-content: flex-end; }
  .fhud .fh-z-bd { right: var(--fh-b); bottom: var(--fh-b); align-items: flex-end; justify-content: flex-end; }
  .fh-pos-barra .fh-z-bi, .fh-pos-barra .fh-z-bd { bottom: calc(var(--fh-alto) + var(--fh-b)); }
  /* con controles táctiles: botón de pausa arriba a la der. y joystick/botones abajo */
  .fhud.fh-tactil .fh-z-td { right: calc(var(--fh-b) + 11vmin); }
  .fhud.fh-tactil .fh-z-bi, .fhud.fh-tactil .fh-z-bd { bottom: 42vmin; }
  .fhud .fh-zona .fh-jefe { width: 18em; max-width: 40vw; }
  .fhud .fh-zona .fh-br-circulo { margin: .3em; }
  /* arcade: la fila de vida/armadura va arriba del todo; lo del centro baja un renglón */
  .fh-pos-arcade .fh-z-tc { top: calc(var(--fh-b) + 2.4em); }
  .fhud .fh-zona .fh-br-tira { flex: none; }
  .fh-z-tc .fh-recogidos { align-items: center; }
  .fh-z-td .fh-recogidos, .fh-z-bd .fh-recogidos { align-items: flex-end; }
  /* piezas de otros módulos, con el estilo del HUD */
  .fhud .fh-vidas { display: flex; align-items: center; gap: .5em; font-weight: bold; color: #ff6a6a; text-shadow: .12em .12em 0 #000; white-space: nowrap; }
  .fhud .fh-vidas .fh-ico { width: 1.2em; text-align: center; }
  .fh-z-bd .fh-vidas, .fh-z-td .fh-vidas { flex-direction: row-reverse; }
  .fh-pos-arcade .fh-vidas .fh-num { font-size: 1.5em; }
  .fhud .fh-z-bc { left: 50%; bottom: calc(var(--fh-b) + 3em); transform: translateX(-50%); align-items: center; }
  .fhud .ft-monedas { font-weight: bold; font-size: .9em; white-space: nowrap; text-shadow: .1em .1em 0 #000; }
  .fhud.fh-fondo .ft-monedas, .fhud.fh-fondo .fh-vidas { background: var(--fh-fondo); padding: .2em .6em; }
  .fh-sin-sombra .fh-vidas, .fh-sin-sombra .ft-monedas { text-shadow: none; }
  .fhud .fh-estados { display: none; gap: .5em; font-size: .9em; text-shadow: .1em .1em 0 #000; }
  .fhud .fh-estados small { font-size: .65em; margin-left: .1em; opacity: .9; }
  `;

  function asegurarCss() {
    if (document.getElementById('estilos-forja-hud')) return;
    const st = document.createElement('style');
    st.id = 'estilos-forja-hud';
    st.textContent = CSS;
    document.head.appendChild(st);
  }

  function hexA(hex, a) {
    const h = (hex || '#000000').replace('#', '');
    const n = parseInt(h.length === 3 ? h.split('').map((c) => c + c).join('') : h, 16) || 0;
    return `rgba(${(n >> 16) & 255},${(n >> 8) & 255},${n & 255},${a})`;
  }

  /* Pone en la capa las clases y variables de proyecto.hud (y el tema de Menús) */
  function aplicarEstilo(el, proyecto) {
    const h = { ...(F.Escena ? F.Escena.hudPorDefecto() : {}), ...(proyecto.hud || {}) };
    const t = (proyecto.menus && proyecto.menus.tema) || {};
    const fuente = t.fuente && F.Assets.mapa.get(t.fuente);
    el.style.setProperty('--fh-fuente', (fuente && fuente.familia ? `'${fuente.familia}', ` : '') + 'ui-monospace, Consolas, monospace');
    el.style.setProperty('--fh-texto', t.colorTexto || '#e8e2d0');
    el.style.setProperty('--fh-sel', t.colorSel || '#e8a33d');
    el.style.setProperty('--fh-escala', h.escala ?? 1);
    el.style.setProperty('--fh-m', h.margen ?? 3);
    el.style.setProperty('--fh-fondo', hexA(h.colorFondo, h.opacidadFondo ?? 0.55));
    el.style.setProperty('--fh-mira', h.colorMira || '#ffffff');
    el.style.setProperty('--fh-mt', h.tamMira ?? 1);
    const clases = ['fhud', 'fh-pos-' + (h.posicion || 'esquinas'), 'fh-est-' + (h.estiloVida || 'ambos'), 'fh-mira-' + (h.estiloMira || 'punto'), 'fh-al-' + (h.equipoPos || 'auto')];
    if (h.fondo) clases.push('fh-fondo');
    if (h.iconos === false) clases.push('fh-sin-iconos');
    if (h.sombra === false) clases.push('fh-sin-sombra');
    if (h.vida === false) clases.push('fh-no-vida');
    if (h.armadura === false) clases.push('fh-no-arm');
    if (h.municion === false) clases.push('fh-no-mun');
    if (h.nombreArma === false) clases.push('fh-no-nombre');
    if (h.iconoMunicion === false) clases.push('fh-no-icomun');
    if (h.recogidos === false) clases.push('fh-no-recog');
    if (h.ocultarTras > 0) clases.push('fh-auto');
    el.className = clases.join(' ');
    return h;
  }


  /* Dónde va cada pieza fija según proyecto.hud.posicion: [zona, orden]. Sin entrada = se queda con su posición propia */
  const COMUN = { 'fmi-hud': ['ti', 2], 'fmi-reloj': ['tc', 2], 'ft-reloj': ['tc', 3], 'fh-jefe': ['tc', 4], 'fh-oleadas': ['tc', 5],
    'ft-monedas': ['td', 6], 'fh-estados': ['bi', 3], 'fal-equipo': ['bi', 1], 'fh-recogidos': ['ti', 4], 'fh-especial': ['bd', 4], 'fh-escudomano': ['bi', 6] };
  const ZONAS = {
    esquinas: { 'fh-estados': ['bi', 3], 'fh-vidas': ['bi', 4], 'fh-barras': ['bi', 5], 'fh-municion': ['bd', 5] },
    barra: { 'fh-vidas': ['bi', 4], 'fmi-reloj': ['td', 2], 'ft-reloj': ['td', 3] },
    arriba: { 'fh-estados': ['tc', 1], 'fh-jefe': ['bc', 1], 'fh-barras': ['tc', 0], 'fh-municion': ['td', 1], 'fh-vidas': ['td', 3], 'fh-recogidos': ['bi', 3] },
    arcade: { 'fh-estados': ['ti', 2], 'fal-equipo': ['bd', 1], 'fh-jefe': ['bc', 1], 'fh-barras': ['ti', 0], 'fh-vidas': ['ti', 1], 'fh-municion': ['td', 1], 'fh-recogidos': ['tc', 6] },
    centro: { 'fh-estados': ['ti', 2], 'fmi-hud': ['bd', 5], 'fh-vidas': ['ti', 1], 'fh-recogidos': ['tc', 6] },
    discreto: { 'fh-estados': ['bd', 2], 'fh-vidas': ['bd', 3], 'fh-barras': ['bd', 4], 'fh-municion': ['bd', 5] },
  };
  ZONAS.libre = ZONAS.esquinas;   // ✥ libre: lo que no se ha movido a mano va como en Esquinas
  const ESQ = { 'arriba-izq': 'ti', 'arriba-der': 'td', 'abajo-izq': 'bi', 'abajo-der': 'bd', 'abajo-centro': 'bc' };
  function destino(h, el) {
    const cl = el.classList;
    if (cl.contains('fh-brujula')) {
      if (cl.contains('fh-br-tira')) return ['tc', 1];
      const k = Object.keys(ESQ).find((e) => cl.contains('fh-br-' + e)), z = ESQ[k] || 'td';
      return [z, z[0] === 't' ? 0 : 9];
    }
    if (cl.contains('fh-vidas') && h.vidasPos && h.vidasPos !== 'auto') { const z = ESQ[h.vidasPos]; return [z, z[0] === 't' ? 0 : 9]; }
    if (cl.contains('fal-equipo') && h.equipoPos && h.equipoPos !== 'auto') { const z = ESQ[h.equipoPos]; return [z, z[0] === 't' ? 8 : 0]; }
    const m = ZONAS[h.posicion || 'esquinas'] || {};
    for (const c of cl) { const d = m[c] || COMUN[c]; if (d) return d; }
    return null;
  }
  // nombre de la pieza para el modo libre: su primera clase (fh-barras, fh-municion, fh-brujula, ft-monedas…)
  const clavePieza = (el) => (el.classList.contains('fh-brujula') ? 'fh-brujula' : el.classList[0]) || '';
  // ✥ libre: el punto guardado [x %, y %] es la esquina / el centro según en qué tercio de la pantalla está
  // (cerca de la izquierda crece hacia la derecha, cerca del borde de abajo crece hacia arriba…)
  function ponerLibre(c, el, xy) {
    const [x, y] = xy, ax = x < 33.3 ? 0 : x > 66.6 ? -100 : -50, ay = y < 33.3 ? 0 : y > 66.6 ? -100 : -50;
    el.classList.add('fh-libre');
    Object.assign(el.style, { left: x + '%', top: y + '%', right: 'auto', bottom: 'auto', transform: `translate(${ax}%, ${ay}%)`, margin: '0' });
    if (el.parentNode !== c) c.appendChild(el);
    return el;
  }
  function colocar(c, el, h) {
    h = h || c._hudCfg;
    if (el.classList.contains('fh-mira')) return el;
    const clave = clavePieza(el);
    if (h && h.posicion === 'libre' && h.libre && h.libre[clave]) { el.dataset.fhPieza = clave; return ponerLibre(c, el, h.libre[clave]); }
    const d = h && destino(h, el);
    if (!d) return el;
    el.dataset.fhPieza = clave;
    let z = c.querySelector(':scope > .fh-z-' + d[0]);
    if (!z) { z = document.createElement('div'); z.className = 'fh-zona fh-z-' + d[0]; c.appendChild(z); }
    el.style.order = d[1];
    z.appendChild(el);
    return el;
  }

  function capa(juego) {
    if (juego._hud && juego._hud.isConnected) return juego._hud;
    asegurarCss();
    const cont = juego.vista.contenedor;
    if (getComputedStyle(cont).position === 'static') cont.style.position = 'relative';
    const el = document.createElement('div');
    juego._hudCfg = el._hudCfg = aplicarEstilo(el, juego.proyecto);
    cont.appendChild(el);
    juego._hud = el;
    return el;
  }

  /* Aplica el estilo de proyecto.menus.mensaje a la caja de mensajes (se edita en la pestaña Menús) */
  function estiloMensaje(el, proyecto) {
    const m = (proyecto.menus && proyecto.menus.mensaje) || {};
    const s = el.style;
    s.width = `min(${m.ancho ?? 70}%, 46em)`;
    s.setProperty('--fm-tam', m.tamano ?? 1);
    s.background = hexA(m.colorFondo || '#000000', m.opacidadFondo ?? 0.82);
    s.border = `${(m.grosorBorde ?? 2) * 0.06}em solid ${m.colorBorde || 'var(--fh-sel)'}`;
    s.borderRadius = (m.esquinas || 0) * 0.1 + 'em';
    s.color = m.colorTexto || '';
    s.textAlign = m.alineacion === 'centro' ? 'center' : 'left';
    s.top = s.bottom = 'auto';   // 'auto' y no '': el CSS base trae bottom y la caja se estiraría
    s.transform = 'translateX(-50%)';
    if (m.posicion === 'arriba') s.top = '8%';
    else if (m.posicion === 'centro') { s.top = '50%'; s.transform = 'translate(-50%, -50%)'; }
    else s.bottom = '12%';
  }

  /* Vista previa: solo lo que el proyecto usa de verdad */
  function ejemplos(el, pr, salud) {
    const ents = (pr.escenas || []).flatMap((s) => s.entidades || []), en = (e) => e.enemigo || {};
    const add = (cls, html) => { const d = document.createElement('div'); d.className = cls; d.innerHTML = html; el.appendChild(d); return d; };
    if (salud.modoVida === 'corazones') {
      const v = el.querySelector('.fh-vida'), n = salud.corazones || 3;
      if (v) v.innerHTML = `<span class="fh-corazones" style="font-size:1.3em;line-height:1.1;color:${salud.colorVida || '#d23a2a'}">${'♥'.repeat(Math.max(1, n - 1))}<span style="color:#3a3a3a">♥</span></span>`;
      const a = el.querySelector('.fh-arm'); if (a) a.remove();
    } else if (salud.activo && !(salud.armaduraMax > 0)) { const a = el.querySelector('.fh-arm'); if (a) a.remove(); }
    const V = pr.menus && pr.menus.vidas;
    if (V && V.activo) add('fh-vidas', `<span class="fh-ico">${V.icono || '❤'}</span><span class="fh-num">× ${V.inicio ?? 3}</span>`);
    const conDivisas = (Array.isArray(pr.divisas) && pr.divisas.length) || ents.some((e) => e.tipo === 'tienda' || (e.recogible && e.recogible.tipo === 'moneda'));
    if (conDivisas && F.Divisas) add('ft-monedas', F.Divisas.lista(pr).map((d) => `<span style="color:${d.color};margin-left:.6em">${F.Divisas.html(d)} 25</span>`).join(''));
    const mis = (pr.escenas || []).map((s) => s.mision).find((m) => m && m.activa && (m.objetivos || []).length);
    if (mis && F.Misiones && F.Misiones.ponerEstilo) {
      F.Misiones.ponerEstilo();
      add('fmi-hud fmi-ver', `<b>${mis.titulo || 'Misión'}</b>` + mis.objetivos.slice(0, 3).map((o) => `<div>★ ${o.texto || o.tipo}</div>`).join(''));
      if (mis.objetivos.some((o) => o.tipo === 'tiempo')) add('fmi-reloj', '⏱ 0:42 / 8:00');
    }
    if (ents.some((e) => e.tipo === 'bomba') && F.Tactico) { F.Tactico.ponerEstilo(); add('ft-reloj', '💣 6:57').style.display = 'block'; }
    if (ents.some((e) => en(e).jefe || (e.aparecedor && e.aparecedor.jefe))) add('fh-jefe fh-ver', `<b>${(ents.find((e) => en(e).jefe) || {}).enemigo?.nombreJefe || 'JEFE'}</b><div class="fh-jcaja"><div class="fh-jlleno" style="width:70%"></div></div>`);
    const al = ents.filter((e) => en(e).actitud === 'aliado').slice(0, 3);
    if (al.length && F.Aliados) { F.Aliados.estilo(); add('fal-equipo', al.map((e) => `<div>🛡 ${e.nombre || 'Aliado'} · Siguiendo<i style="width:100%"></i></div>`).join('')); }
  }

  const Hud = {
    estiloMensaje,
    aplicarEstilo,
    asegurarCss,
    capa,
    colocar,
    // Una pieza del HUD (se crea la primera vez). html: contenido inicial
    pieza(juego, clase, html = '') {
      const c = capa(juego);
      let el = c.querySelector('.' + clase);
      if (!el) {
        el = document.createElement('div');
        el.className = clase;
        el.innerHTML = html;
        c.appendChild(el);
        colocar(c, el);
      }
      return el;
    },
    // Una pieza cambió de valor: con "Esconder tras" se muestra un rato y se esconde sola
    cambio(juego, el) {
      const h = juego._hudCfg;
      if (!h || !(h.ocultarTras > 0)) return;
      el.classList.add('fh-ver');
      clearTimeout(el._fhT);
      el._fhT = setTimeout(() => el.classList.remove('fh-ver'), h.ocultarTras * 1000);
    },
    // Cada cuadro (lo llama el juego): solo la mira, y solo toca el HTML si cambia
    actualizar(juego) {
      const j = juego.jugador, h = juego._hudCfg;
      if (!j || !h) return;
      let ver;
      const modo = h.mira || 'fps';
      if (modo === 'nunca' || j.muerto || j.sinControl) ver = false;
      else if (modo === 'siempre') ver = true;
      else if (modo === 'apuntar') ver = (j.apuntando || 0) > 0.5;
      else ver = j.modoCamara === modo;
      // con un arma cuerpo a cuerpo en 3ª persona no hace falta
      const a = j.armas && j.armas[j.armaActual];
      if (ver && j.modoCamara === 'tps' && a && a.def.tipo === 'cuerpo') ver = false;
      const tc = !!(F.Tactil && F.Tactil.visible);
      if (tc !== juego._hudTactil) { juego._hudTactil = tc; if (juego._hud) juego._hud.classList.toggle('fh-tactil', tc); }
      if (ver !== juego._miraVer) {
        juego._miraVer = ver;
        Hud.pieza(juego, 'fh-mira').classList.toggle('fh-ver', ver);
      }
    },
    /* Vista previa para el editor: una capa con valores de ejemplo dentro de "cont" (que pone el tamaño) */
    vistaPrevia(cont, proyecto) {
      asegurarCss();
      cont.innerHTML = '';
      const el = document.createElement('div');
      const h = aplicarEstilo(el, proyecto);
      el.style.setProperty('--fh-u', (cont.clientHeight || 160) / 100 + 'px');
      const salud = (proyecto.jugador && proyecto.jugador.modulos.salud) || {};
      el.innerHTML =
        `<div class="fh-barras"><div class="fh-barra fh-vida" style="--fh-color:${salud.colorVida || '#d23a2a'}"><span class="fh-ico">♥</span><span class="fh-caja"><div class="fh-lleno" style="width:72%"></div></span><span class="fh-num">72</span></div>` +
        `<div class="fh-barra fh-arm" style="--fh-color:${salud.colorArmadura || '#3a8ad2'}"><span class="fh-ico">⛨</span><span class="fh-caja"><div class="fh-lleno" style="width:40%"></div></span><span class="fh-num">40</span></div></div>` +
        `<div class="fh-municion"><span class="fh-arma">Pistola</span><span class="fh-ico">▮</span><span class="fh-num">12 / 48</span></div>` +
        `<div class="fh-recogidos"><div style="animation:none">+25 Vida</div></div>` +
        `<div class="fh-mira ${h.mira !== 'nunca' ? 'fh-ver' : ''}"></div>`;
      ejemplos(el, proyecto, salud);
      // piezas de otros módulos (para poder acomodarlas en el modo libre)
      const md = (proyecto.jugador && proyecto.jugador.modulos) || {};
      const pz = (cls, html) => { const d = document.createElement('div'); d.className = cls; d.innerHTML = html; d.style.textShadow = '.1em .1em 0 #000'; el.appendChild(d); };
      if (md.especial && md.especial.activo) pz('fh-especial', `<span style="color:${md.especial.color || '#c08cff'};font-size:1.25em">✸</span> <small>B</small>`);
      if (md.armas && md.armas.activo && md.armas.escudoMano && md.armas.escudoMano !== 'no') pz('fh-escudomano', '🛡 <span style="display:inline-block;width:5em;height:.5em;border:1px solid #000;background:#d9c08a;vertical-align:middle"></span> 120');
      if (F.Brujula) F.Brujula.vistaPrevia(el, h);
      el._hudCfg = h;
      [...el.children].forEach((x) => colocar(el, x, h));
      if (h.ocultarTras > 0) el.querySelectorAll('.fh-barras, .fh-municion').forEach((x) => x.classList.add('fh-ver'));
      cont.appendChild(el);
      return el;
    },
    quitar(juego) {
      if (juego._hud) juego._hud.remove();
      juego._hud = null;
      juego._miraVer = undefined; juego._hudTactil = undefined;
    },
  };

  // Al terminar una partida (o volver al editor) el HUD se va
  F.on('juego-detenido', (j) => Hud.quitar(j));

  F.Hud = Hud;
})(window.FORJA);
