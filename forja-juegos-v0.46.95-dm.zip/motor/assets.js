/* =========================================================
   FORJA · ASSETS
   Biblioteca de archivos (≈ Sistema de archivos de Godot):
   modelos GLB, texturas (color y normal), audio y MIDI.
   Se guardan en el navegador (IndexedDB) para que sigan ahí al reabrir.
   ========================================================= */
(function (F) {
  'use strict';
  const T = THREE;

  /* ---------- IndexedDB ---------- */
  const DB = {
    db: null,
    abrir(nombre = 'forja-juegos') {
      return new Promise((resolver, rechazar) => {
        const r = indexedDB.open(nombre, 1);
        r.onupgradeneeded = () => {
          const d = r.result;
          for (const s of ['assets', 'apps', 'proyecto']) {
            if (!d.objectStoreNames.contains(s)) d.createObjectStore(s, { keyPath: 'id' });
          }
        };
        r.onsuccess = () => { DB.db = r.result; resolver(); };
        r.onerror = () => rechazar(r.error);
      });
    },
    _tx(store, modo, fn) {
      return new Promise((resolver, rechazar) => {
        if (!DB.db) return resolver(null);
        const t = DB.db.transaction(store, modo);
        const req = fn(t.objectStore(store));
        t.oncomplete = () => resolver(req ? req.result : null);
        t.onerror = () => rechazar(t.error);
      });
    },
    poner(store, obj) { return this._tx(store, 'readwrite', (s) => s.put(obj)); },
    leer(store, id) { return this._tx(store, 'readonly', (s) => s.get(id)); },
    todos(store) { return this._tx(store, 'readonly', (s) => s.getAll()); },
    borrar(store, id) { return this._tx(store, 'readwrite', (s) => s.delete(id)); },
    vaciar(store) { return this._tx(store, 'readwrite', (s) => s.clear()); },
  };

  /* ---------- Tipos de archivo ---------- */
  function tipoPorNombre(nombre) {
    // 🧾 receta (motor/generadores.js): un modelo que se genera con el código de su app
    if (/\.receta\.json$/i.test(nombre)) return { tipo: 'modelo', mime: 'application/json', receta: true };
    const ext = (nombre.split('.').pop() || '').toLowerCase();
    if (ext === 'glb' || ext === 'gltf') return { tipo: 'modelo', mime: 'model/gltf-binary' };
    if (ext === 'mp3') return { tipo: 'audio', mime: 'audio/mpeg' };
    if (ext === 'wav') return { tipo: 'audio', mime: 'audio/wav' };
    if (ext === 'ogg') return { tipo: 'audio', mime: 'audio/ogg' };
    if (ext === 'mid' || ext === 'midi') return { tipo: 'midi', mime: 'audio/midi' };
    if (ext === 'png') return { tipo: 'textura', mime: 'image/png' };
    if (ext === 'jpg' || ext === 'jpeg') return { tipo: 'textura', mime: 'image/jpeg' };
    if (ext === 'webp') return { tipo: 'textura', mime: 'image/webp' };
    if (ext === 'ttf') return { tipo: 'fuente', mime: 'font/ttf' };
    if (ext === 'otf') return { tipo: 'fuente', mime: 'font/otf' };
    if (ext === 'woff') return { tipo: 'fuente', mime: 'font/woff' };
    if (ext === 'woff2') return { tipo: 'fuente', mime: 'font/woff2' };
    return null;
  }

  const mapa = new Map();               // id → asset { id, nombre, tipo, mime, datos, gltf?, imagen?, url?, tris? }
  const cacheTexturas = new Map();      // `${id}|${uso}` → THREE.Texture
  const cargadorGLTF = new T.GLTFLoader();

  // Duración de un audio (para decidir si es música o sonido). 0 si no se puede leer.
  function duracionAudio(url) {
    return new Promise((ok) => {
      const au = new Audio();
      const fin = (v) => { clearTimeout(t); ok(v); };
      const t = setTimeout(() => fin(0), 2500);
      au.preload = 'metadata';
      au.onloadedmetadata = () => fin(isFinite(au.duration) ? au.duration : 0);
      au.onerror = () => fin(0);
      au.src = url;
    });
  }

  function cargarImagen(url) {
    return new Promise((ok, mal) => {
      const img = new Image();
      img.onload = () => ok(img);
      img.onerror = () => mal(new Error('imagen no válida'));
      img.src = url;
    });
  }

  async function preparar(a) {
    if (a.url) URL.revokeObjectURL(a.url);
    a.url = URL.createObjectURL(new Blob([a.datos], { type: a.mime }));
    if (a.tipo === 'modelo' && /\.receta\.json$/i.test(a.nombre)) {
      // receta: se genera (si el proyecto trae su generador; si no, queda pendiente hasta que lo tenga)
      a.esReceta = true;
      a.faltaGenerador = '';
      a.errorReceta = '';
      let gltf = null;
      try {
        const { receta, texto } = F.Generadores.leer(a.datos);
        a.receta = receta;
        const r = F.Generadores.generar(receta, texto);
        gltf = { scene: r.escena, animations: r.escena.animations || [] };   // las animaciones de la receta (personajes)
        a.infoReceta = r.info;
      } catch (err) {
        a.gltf = null;
        a.faltaGenerador = err.faltaGenerador || '';
        a.errorReceta = err.message || String(err);
        if (!err.faltaGenerador) console.warn('[FORJA] receta', a.nombre, err);
        return;
      }
      F.Render.convertirMateriales(gltf.scene);
      F.Render.aplicarPrioridad(gltf.scene);
      let tris = 0;
      gltf.scene.traverse((o) => {
        if (o.isMesh) { o.geometry.userData.compartida = true; tris += (o.geometry.index ? o.geometry.index.count : o.geometry.attributes.position.count) / 3; }
      });
      a.gltf = gltf;
      a.tris = tris;
    } else if (a.tipo === 'modelo') {
      const gltf = await new Promise((ok, mal) => cargadorGLTF.parse(a.datos.slice(0), '', ok, mal));
      F.Render.convertirMateriales(gltf.scene);
      F.Render.aplicarPrioridad(gltf.scene);
      let tris = 0;
      gltf.scene.traverse((o) => {
        if (o.isMesh) {
          o.geometry.userData.compartida = true;
          tris += (o.geometry.index ? o.geometry.index.count : o.geometry.attributes.position.count) / 3;
        }
      });
      a.gltf = gltf;
      a.tris = tris;
    } else if (a.tipo === 'fuente') {
      // Se registra como fuente del navegador: sirve para textos del HUD y menús
      a.familia = 'forja_' + a.id;
      const ff = new FontFace(a.familia, a.datos.slice(0));
      await ff.load();
      document.fonts.add(ff);
    } else if (a.tipo === 'audio') {
      a.duracion = await duracionAudio(a.url);
    } else if (a.tipo === 'textura') {
      a.imagen = await cargarImagen(a.url);
      // Si el asset se reemplazó, las texturas en uso se actualizan
      for (const [clave, tex] of cacheTexturas) {
        if (clave.startsWith(a.id + '|')) { tex.image = a.imagen; tex.needsUpdate = true; }
      }
    }
    return a;
  }

  /* Textura lista para un material.
     uso: 'color' (sRGB) o 'normal' (lineal). Se comparte entre todos los que la usan. */
  function textura(id, uso = 'color') {
    const a = mapa.get(id);
    if (!a || a.tipo !== 'textura' || !a.imagen) return null;
    const clave = id + '|' + uso;
    if (cacheTexturas.has(clave)) return cacheTexturas.get(clave);
    const t = new T.Texture(a.imagen);
    t.wrapS = t.wrapT = T.RepeatWrapping;
    t.colorSpace = uso === 'color' ? T.SRGBColorSpace : T.NoColorSpace;
    t.needsUpdate = true;
    F.Render.registrarTextura(t);
    cacheTexturas.set(clave, t);
    return t;
  }

  // Lo que se guarda en IndexedDB (sin objetos de Three.js)
  const paraGuardar = (a) => ({ id: a.id, nombre: a.nombre, tipo: a.tipo, mime: a.mime, datos: a.datos, carpeta: a.carpeta });

  /* Importar un archivo. Si ya existe uno con el mismo nombre, lo reemplaza
     (así reexportar un nivel desde la forja lo actualiza en la escena). */
  async function importar(nombre, blob) {
    const info = tipoPorNombre(nombre);
    if (!info) throw new Error(`No sé importar "${nombre}"`);
    const existente = [...mapa.values()].find((a) => a.nombre === nombre);
    const a = existente || { id: F.util.uid(), nombre, tipo: info.tipo, mime: info.mime };
    a.datos = await blob.arrayBuffer();
    a.sucio = true;            // pendiente de escribir en la carpeta del proyecto
    await preparar(a);
    mapa.set(a.id, a);
    await DB.poner('assets', paraGuardar(a)).catch(() => {});
    F.emitir('assets-cambiaron', a.id);
    return { asset: a, reemplazado: !!existente };
  }

  // Reemplazar el archivo de un asset conservando su id (todo lo que lo usa se actualiza)
  async function reemplazar(id, blob, nombreNuevo) {
    const a = mapa.get(id);
    if (!a) throw new Error('asset no encontrado');
    a.datos = await blob.arrayBuffer();
    a.sucio = true;
    if (nombreNuevo) a.nombre = nombreNuevo;
    await preparar(a);
    await DB.poner('assets', paraGuardar(a)).catch(() => {});
    F.emitir('assets-cambiaron', a.id);
    return a;
  }

  // Carpeta del archivo ('' = raíz). Solo organiza; no cambia nada del juego.
  async function moverACarpeta(id, carpeta) {
    const a = mapa.get(id);
    if (!a) return;
    if ((a.carpeta || '') === (carpeta || '')) return;
    a.carpeta = carpeta || '';
    await DB.poner('assets', paraGuardar(a)).catch(() => {});
    F.emitir('assets-cambiaron', a.id);
  }

  async function renombrar(id, nombre) {
    const a = mapa.get(id);
    if (!a || !nombre) return;
    a.nombre = nombre;
    await DB.poner('assets', paraGuardar(a)).catch(() => {});
    F.emitir('assets-cambiaron', a.id);
  }

  // Desglose de un GLB: mallas, materiales, texturas, animaciones y huesos
  function desglose(a) {
    if (!a || !a.gltf) return null;
    const mallas = [], materiales = new Map(), texturas = new Set();
    let huesos = 0;
    a.gltf.scene.traverse((o) => {
      if (o.isBone) huesos++;
      if (!o.isMesh) return;
      const g = o.geometry;
      mallas.push({ nombre: o.name || '(sin nombre)', tris: (g.index ? g.index.count : g.attributes.position.count) / 3, piel: !!o.isSkinnedMesh });
      for (const m of Array.isArray(o.material) ? o.material : [o.material]) {
        if (!m || materiales.has(m)) continue;
        materiales.set(m, { nombre: m.name || '(sin nombre)', color: !!m.map, normal: !!m.normalMap, colorVertice: !!m.vertexColors, transparente: !!m.transparent });
        for (const t of [m.map, m.normalMap, m.emissiveMap]) if (t) texturas.add(t);
      }
    });
    const tam = [...texturas].map((t) => t.image ? `${t.image.width}×${t.image.height}` : '?');
    return {
      mallas, materiales: [...materiales.values()], texturas: tam, huesos,
      animaciones: (a.gltf.animations || []).map((c) => ({ nombre: c.name, duracion: c.duration })),
    };
  }

  /* ---------- Materiales de un modelo ----------
     Cada material del GLB se puede ajustar (modo, opacidad, prioridad, textura…).
     Los ajustes se guardan en proyecto.materiales[idAsset][clave] y valen para
     todas las copias del modelo, como un material compartido de Godot.
     clave = 'n:<nombre>' si el material tiene un nombre que no se repite en el modelo (así, si al reexportar el nivel
     aparece o desaparece un material, los ajustes no se corren al de al lado); si no, su posición (como antes). */
  function materialesDe(a) {
    const lista = [];
    if (!a || !a.gltf) return lista;
    a.gltf.scene.traverse((o) => {
      if (!o.isMesh) return;
      for (const m of Array.isArray(o.material) ? o.material : [o.material]) if (m && !lista.includes(m)) lista.push(m);
    });
    return lista;
  }

  function claveMaterial(a, i) {
    const mats = materialesDe(a), m = mats[i];
    const n = m && m.name;
    return n && mats.filter((x) => x.name === n).length === 1 ? 'n:' + n : String(i);
  }
  // los ajustes de la versión vieja (por posición) pasan a su nombre una sola vez
  function migrarMateriales(proyecto, a) {
    const todos = proyecto.materiales && proyecto.materiales[a.id];
    if (!todos) return;
    materialesDe(a).forEach((m, i) => {
      const k = claveMaterial(a, i);
      if (k !== String(i) && todos[i] && !todos[k]) { todos[k] = todos[i]; delete todos[i]; }
    });
  }
  function configMaterial(proyecto, idAsset, i, mat) {
    const todos = (proyecto.materiales && proyecto.materiales[idAsset]) || {};
    const a = mapa.get(idAsset);
    const guardado = (a && todos[claveMaterial(a, i)]) || todos[i] || {};
    return { ...mat.userData.original, ...guardado };
  }
  // guardar los ajustes de un material (con su clave; borra la de posición si quedaba)
  function guardarConfigMaterial(proyecto, a, i, cfg) {
    const todos = (proyecto.materiales[a.id] = proyecto.materiales[a.id] || {});
    const k = claveMaterial(a, i);
    todos[k] = cfg;
    if (k !== String(i)) delete todos[i];
    return todos;
  }
  function borrarConfigMaterial(proyecto, a, i) {
    const todos = proyecto.materiales && proyecto.materiales[a.id];
    if (!todos) return;
    delete todos[claveMaterial(a, i)];
    delete todos[i];
  }

  function aplicarMaterialesAsset(proyecto, a) {
    if (!a || !a.gltf) return;   // receta aún sin generar
    migrarMateriales(proyecto, a);
    const mats = materialesDe(a);
    mats.forEach((m, i) => {
      const cfg = configMaterial(proyecto, a.id, i, m);
      m.map = cfg.textura ? textura(cfg.textura, 'color') || m.userData.original.map : m.userData.original.map;
      m.normalMap = cfg.normal ? textura(cfg.normal, 'normal') || m.userData.original.normalMap : m.userData.original.normalMap;
      if (m.map) F.Render.registrarTextura(m.map);
      F.Render.aplicarConfig(m, cfg);
    });
    F.Render.aplicarPrioridad(a.gltf.scene);
  }

  function aplicarMateriales(proyecto) {
    for (const a of mapa.values()) if (a.tipo === 'modelo' && a.gltf) aplicarMaterialesAsset(proyecto, a);
  }

  function quitar(id) {
    const a = mapa.get(id);
    if (!a) return;
    if (a.url) URL.revokeObjectURL(a.url);
    for (const clave of [...cacheTexturas.keys()]) if (clave.startsWith(id + '|')) cacheTexturas.delete(clave);
    mapa.delete(id);
    DB.borrar('assets', id).catch(() => {});
    F.emitir('assets-cambiaron', id);
  }

  async function cargarGuardados() {
    for (const a of (await DB.todos('assets')) || []) {
      try { await preparar(a); mapa.set(a.id, a); } catch (err) { console.warn('[FORJA] asset dañado', a.nombre, err); }
    }
  }

  // Para empaquetar el proyecto o el juego exportado
  async function serializar() {
    const lista = [];
    for (const a of mapa.values()) {
      lista.push({ id: a.id, nombre: a.nombre, tipo: a.tipo, mime: a.mime, carpeta: a.carpeta, b64: await F.util.bufferABase64(a.datos) });
    }
    return lista;
  }

  async function deserializar(lista, guardar = true) {
    for (const x of lista || []) {
      // x.datos (ArrayBuffer, desde la carpeta de proyecto) o x.b64 (desde un .forja.json)
      const a = { id: x.id, nombre: x.nombre, tipo: x.tipo, mime: x.mime, carpeta: x.carpeta,
        datos: x.datos || await F.util.base64ABuffer(x.b64), sucio: !x.datos };
      try { await preparar(a); } catch (err) { F.aviso(`Error en ${a.nombre}`, 'error'); continue; }
      mapa.set(a.id, a);
      if (guardar) await DB.poner('assets', paraGuardar(a)).catch(() => {});
    }
  }

  function vaciar() {
    for (const a of mapa.values()) if (a.url) URL.revokeObjectURL(a.url);
    mapa.clear();
    cacheTexturas.clear();
    return DB.vaciar('assets').catch(() => {});
  }

  const de = (tipo) => [...mapa.values()].filter((a) => a.tipo === tipo);

  // recetas que no se pudieron generar (faltaba su generador): se intenta otra vez. Devuelve cuántas salieron
  async function regenerarRecetas() {
    let n = 0;
    for (const a of mapa.values()) {
      if (!a.esReceta || a.gltf) continue;
      await preparar(a);
      if (a.gltf) n++;
    }
    return n;
  }

  F.Assets = { DB, mapa, tipoPorNombre, preparar, importar, reemplazar, renombrar, moverACarpeta, desglose, materialesDe, configMaterial, claveMaterial, guardarConfigMaterial, borrarConfigMaterial, aplicarMaterialesAsset, aplicarMateriales, quitar, textura, cargarGuardados, serializar, deserializar, vaciar, de, regenerarRecetas };
})(window.FORJA);
