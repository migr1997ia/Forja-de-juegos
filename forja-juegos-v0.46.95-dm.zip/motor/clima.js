/* =========================================================
   FORJA · 🌦 CLIMA: día y noche, lluvia y tormenta (Escena ▸ Ambiente ▸ Clima)
   Solo existe si la escena lo activa; apagado no se crea nada (cero coste).
   - La hora elige entre 4 paletas (día = los colores de la escena, amanecer, atardecer, noche) y las mezcla.
     Se recalcula 4 veces por segundo, no en cada cuadro (salvo durante un rayo).
   - Lo horneado (Proyecto ▸ hornear) se hornea UNA vez por partes (sol con sombra, cielo/suelo, lámparas fijas y
     de noche) y la GPU arma el color con 5 números: cambiar la hora o llover no vuelve a hornear nada.
   - Lo que se mueve (jugador, enemigos) usa las luces de siempre, teñidas con la misma paleta.
   - Lluvia: un solo lote de líneas alrededor de la cámara que cae en la GPU (1 dibujo). Bajo techo se apaga (un rayo
     hacia arriba cada 0,3 s). Sonido de lluvia y truenos hechos por el motor (sin archivos).
   - Rayo: destello del cielo y del ambiente unos cuadros + trueno con retraso.
     F.Clima.vistaPrevia(vista, amb) · new F.Clima.Gestor(juego) → actualizar(dt), accion(que, a), detener()
   ========================================================= */
(function (F) {
  'use strict';
  const T = THREE;
  // uniformes que leen los materiales horneados por partes
  const U = {
    uClSol: { value: new T.Color() }, uClCielo: { value: new T.Color() }, uClSuelo: { value: new T.Color() },
    uClHorizonte: { value: new T.Color() }, uClNoche: { value: 0 }, uClMojado: { value: 0 },
  };
  const HEMI_CIELO = new T.Color(0xdde6ff), HEMI_SUELO = new T.Color(0x3a3328), BLANCO = new T.Color(1, 1, 1);
  const DESTELLO = new T.Color('#dfe6ff');
  // puntos del día: entre dos se mezcla
  const PUNTOS = [[0, 'noc'], [5, 'noc'], [6.5, 'ama'], [8, 'dia'], [17, 'dia'], [18.5, 'tar'], [20, 'noc'], [24, 'noc']];

  const nuevoEstado = () => ({ cielo: new T.Color(), hor: new T.Color(), sol: new T.Color(), tinte: new T.Color(), iSol: 1, iAmb: 1, noche: 0, niebla: 1 });
  const _a = nuevoEstado(), _b = nuevoEstado(), _g = new T.Color();

  function paleta(amb, k, o) {
    if (k === 'dia') {
      o.cielo.set(amb.fondo); o.hor.set(amb.cieloHorizonte || amb.fondo); o.sol.set(amb.solColor || '#fff2dd');
      o.iSol = 1; o.iAmb = 1; o.noche = 0; o.tinte.copy(BLANCO);
    } else if (k === 'noc') {
      const c = amb.climaNocLuz ?? 0.3;
      o.cielo.set(amb.climaNocCielo || '#05070f'); o.hor.set(amb.climaNocHorizonte || '#141a2e'); o.sol.set(amb.climaNocSol || '#7f95d6');
      o.iSol = c * 0.6; o.iAmb = c; o.noche = 1; o.tinte.copy(BLANCO).lerp(o.sol, 0.6);
    } else {
      const p = k === 'ama' ? 'climaAma' : 'climaTar';
      o.cielo.set(amb[p + 'Cielo']); o.hor.set(amb[p + 'Horizonte']); o.sol.set(amb[p + 'Sol']);
      o.iSol = 0.65; o.iAmb = 0.75; o.noche = 0.35; o.tinte.copy(BLANCO).lerp(o.sol, 0.35);
    }
  }

  const gris = (c, k) => { const v = (c.r + c.g + c.b) / 3 * 0.8; c.lerp(_g.setRGB(v, v, v * 1.06), k); };

  /* estado(amb, hora, lluvia 0-1, destello 0-1, salida) */
  function estado(amb, hora, lluvia, destello, o) {
    hora = ((hora % 24) + 24) % 24;
    let i = 0;
    while (i < PUNTOS.length - 2 && hora >= PUNTOS[i + 1][0]) i++;
    const [h0, k0] = PUNTOS[i], [h1, k1] = PUNTOS[i + 1];
    let t = h1 > h0 ? (hora - h0) / (h1 - h0) : 0;
    t = t * t * (3 - 2 * t);
    paleta(amb, k0, _a); paleta(amb, k1, _b);
    for (const c of ['cielo', 'hor', 'sol', 'tinte']) o[c].copy(_a[c]).lerp(_b[c], t);
    for (const n of ['iSol', 'iAmb', 'noche']) o[n] = _a[n] + (_b[n] - _a[n]) * t;
    // 🌧 lluvia: cielo gris, sol tapado, menos luz y niebla más cerca
    o.niebla = 1;
    if (lluvia > 0) {
      gris(o.cielo, 0.75 * lluvia); gris(o.hor, 0.75 * lluvia);
      o.iSol *= 1 - 0.85 * lluvia; o.iAmb *= 1 - 0.25 * lluvia; o.niebla = 1 - 0.45 * lluvia;
    }
    // 🌩 destello del rayo
    if (destello > 0) {
      o.cielo.lerp(DESTELLO, destello * 0.8); o.hor.lerp(DESTELLO, destello * 0.6);
      o.iAmb += destello * 1.6; o.tinte.lerp(DESTELLO, destello);
    }
    return o;
  }

  function aplicarVista(V, amb, st) {
    const cu = V.cielo.material.uniforms;
    cu.uCielo.value.copy(st.cielo);
    cu.uHorizonte.value.copy(st.hor);
    if (V.escena.background && V.escena.background.isColor) V.escena.background.copy(st.hor);
    const lejos = amb.nieblaLejos * st.niebla, cerca = Math.min(amb.nieblaCerca, lejos * 0.6);
    if (V.escena.fog) {
      if (amb.nieblaDelCielo) V.escena.fog.color.copy(st.hor);
      V.escena.fog.near = cerca; V.escena.fog.far = lejos;
    }
    F.Render.U.uNieblaCerca.value = cerca;
    F.Render.U.uNieblaLejos.value = lejos;
    V.hemi.color.copy(HEMI_CIELO).multiply(st.tinte);
    V.hemi.groundColor.copy(HEMI_SUELO).multiply(st.tinte);
    V.hemi.intensity = amb.luzAmb * Math.PI * st.iAmb;
    V.sol.color.copy(st.sol);
    V.sol.intensity = amb.luzSol * Math.PI * st.iSol;
    // lo horneado por partes
    U.uClSol.value.copy(st.sol).multiplyScalar(amb.luzSol * st.iSol);
    U.uClCielo.value.copy(V.hemi.color).multiplyScalar(amb.luzAmb * st.iAmb);
    U.uClSuelo.value.copy(V.hemi.groundColor).multiplyScalar(amb.luzAmb * st.iAmb);
    U.uClHorizonte.value.copy(st.hor);
    const n = Math.min(1, Math.max(0, (st.noche - 0.45) / 0.15));
    U.uClNoche.value = n;
    return n;
  }

  const _prev = nuevoEstado();
  function vistaPrevia(V, amb) {
    const ll = amb.climaLluvia === 'si' ? amb.climaFuerza ?? 0.6 : 0;
    aplicarVista(V, amb, estado(amb, amb.climaHora ?? 12, ll, 0, _prev));
    U.uClMojado.value = 0;
  }

  /* ---------- Materiales horneados por partes ---------- */
  const CHARCOS = `
    #ifdef CL_CHARCOS
      if (uClMojado > 0.001 && vClMoj > 0.5) {
        float hcClima = fract(sin(dot(floor(vLinMundo.xz * 0.5), vec2(12.9898, 78.233))) * 43758.5453);
        float charco = step(0.68, hcClima);
        outgoingLight *= 1.0 - 0.35 * uClMojado;   // suelo mojado: más oscuro
        vec2 qClima = fract(vLinMundo.xz * 1.25 + hcClima * 3.0) - 0.5;
        float onda = step(0.93, fract(length(qClima) * 2.0 - uTiempo * 0.9 + hcClima * 7.0)) * step(length(qClima), 0.4);
        outgoingLight = mix(outgoingLight, uClHorizonte * 0.7, charco * 0.6 * uClMojado);
        outgoingLight += uClHorizonte * (onda * 0.35 * charco * uClMojado);   // ondas: solo en los charcos y suaves
      }
    #endif
  `;
  function prepararMaterial(mat, noche, charcos) {
    const ob = mat.onBeforeCompile, ck = mat.customProgramCacheKey;
    mat.onBeforeCompile = (sh, r) => {
      ob.call(mat, sh, r);
      Object.assign(sh.uniforms, U);
      const def = (noche ? '#define CL_NOCHE\n' : '') + (charcos ? '#define CL_CHARCOS\n' : '');
      sh.vertexShader = def + 'attribute vec2 aClima;\nuniform vec3 uClSol;\nuniform vec3 uClCielo;\nuniform vec3 uClSuelo;\nuniform float uClNoche;\nvarying float vClMoj;\n' +
        '#ifdef CL_NOCHE\nattribute vec3 aLamN;\n#endif\n' +
        sh.vertexShader.replace('#include <color_vertex>', `#include <color_vertex>
          vColor.rgb = color.rgb + mix(uClSuelo, uClCielo, aClima.y) + uClSol * aClima.x;
          #ifdef CL_NOCHE
            vColor.rgb += aLamN * uClNoche;
          #endif
          vClMoj = step(0.9, aClima.y);`);
      sh.fragmentShader = def + 'uniform float uClMojado;\nuniform vec3 uClHorizonte;\nvarying float vClMoj;\n' +
        sh.fragmentShader.replace('#include <opaque_fragment>', CHARCOS + '#include <opaque_fragment>');
    };
    mat.customProgramCacheKey = () => ck.call(mat) + '-clima' + (noche ? 'n' : '') + (charcos ? 'c' : '');
  }

  /* ---------- Lluvia: líneas que caen en la GPU alrededor de la cámara ---------- */
  const MAX_GOTAS = 600;
  function crearLluvia(color) {
    const pos = new Float32Array(MAX_GOTAS * 6), fin = new Float32Array(MAX_GOTAS * 2);
    for (let i = 0; i < MAX_GOTAS; i++) {
      const x = Math.random(), y = Math.random(), z = Math.random();
      pos.set([x, y, z, x, y, z], i * 6);
      fin[i * 2 + 1] = 1;
    }
    const geo = new T.BufferGeometry();
    geo.setAttribute('position', new T.BufferAttribute(pos, 3));
    geo.setAttribute('aFin', new T.BufferAttribute(fin, 1));
    const mat = new T.ShaderMaterial({
      uniforms: { uCam: { value: new T.Vector3() }, uT: { value: 0 }, uTam: { value: 26 }, uAlto: { value: 16 }, uLargo: { value: 0.7 }, uViento: F.Render.U.uViento,
        uColor: { value: new T.Color(color) }, uOpac: { value: 0 } },
      vertexShader: `
        uniform vec3 uCam; uniform float uT; uniform float uTam; uniform float uAlto; uniform float uLargo; uniform vec4 uViento;
        attribute float aFin;
        varying float vBorde;
        void main() {
          vec3 base = uCam - vec3(uTam * 0.5, uAlto * 0.5, uTam * 0.5);
          vec3 p0 = position * vec3(uTam, uAlto, uTam);
          vec3 w;
          // 🌬 con viento la lluvia cae inclinada y se desplaza (hasta 8 m/s de lado con fuerza 1)
          vec2 vh = uViento.xy * uViento.z * (1.0 + uViento.w) * 8.0;
          w.xz = base.xz + mod(p0.xz + vh * uT - base.xz, uTam);
          w.y = base.y + mod(p0.y - uT * 17.0 - base.y, uAlto);
          w.y += aFin * uLargo;
          w.x += aFin * uLargo * 0.12;
          w.xz -= aFin * uLargo * vh / 17.0;
          vBorde = length(w.xz - uCam.xz) / (uTam * 0.5);
          gl_Position = projectionMatrix * viewMatrix * vec4(w, 1.0);
        }`,
      fragmentShader: `
        uniform vec3 uColor; uniform float uOpac;
        varying float vBorde;
        void main() { gl_FragColor = vec4(uColor, uOpac * (1.0 - smoothstep(0.55, 1.0, vBorde))); }`,
      transparent: true, depthWrite: false, fog: false,
    });
    const m = new T.LineSegments(geo, mat);
    m.frustumCulled = false;
    m.renderOrder = 5;
    m.userData.ayudaEditor = false;
    return m;
  }

  /* ---------- Sonidos hechos por el motor ---------- */
  function ruido(c, seg) {
    const b = c.createBuffer(1, Math.floor(c.sampleRate * seg), c.sampleRate), d = b.getChannelData(0);
    let ult = 0;
    for (let i = 0; i < d.length; i++) { const r = Math.random() * 2 - 1; ult = ult * 0.6 + r * 0.4; d[i] = ult; }
    return b;
  }
  const volEfectos = () => { const A = F.Audio || {}; return (A.volGeneral ?? 1) * (A.volEfectos ?? 1); };

  class Gestor {
    constructor(juego) {
      this.juego = juego;
      const amb = this.amb = juego.escena.ambiente;
      this.hora = amb.climaHora ?? 12;
      this.horaObjetivo = null;
      this.modo = amb.climaLluvia || 'no';
      this.fuerza = amb.climaFuerza ?? 0.6;
      this.objetivo = this.modo === 'si' ? this.fuerza : this.modo === 'azar' && Math.random() < 0.5 ? this.fuerza : 0;
      this.lluvia = this.objetivo;
      this.tAzar = 30 + Math.random() * 60;
      this.colorLluvia = new T.Color(amb.climaLluviaColor || '#9fb3c8');
      this.st = nuevoEstado();
      this.tTick = 1;
      this.destello = 0; this.tDestello = -1; this.tTrueno = -1;
      this.tRayo = this._siguienteRayo();
      this.techo = false; this.dentro = 0; this.tTecho = 0;
      this.nocheAntes = null;
      // lo que había antes (para dejarlo como estaba)
      const V = juego.vista;
      this.antes = { hemiC: V.hemi.color.clone(), hemiS: V.hemi.groundColor.clone(), hemiI: V.hemi.intensity, solC: V.sol.color.clone(), solI: V.sol.intensity };
      // la lluvia solo se crea si esta escena puede llover
      if (this.modo !== 'no') {
        this.malla = crearLluvia(amb.climaLluviaColor || '#9fb3c8');
        V.escena.add(this.malla);
        if (amb.climaGotas !== false) this._crearGotas();
      }
      this._aplicar(0);
    }

    _siguienteRayo() { return (this.amb.climaRayos || 14) * (0.4 + Math.random() * 1.2); }

    accion(que, a) {
      if (que === 'lluviaOn') { this.modo = 'si'; this.objetivo = this.fuerza; if (!this.malla) { this.malla = crearLluvia(this.amb.climaLluviaColor || '#9fb3c8'); this.juego.vista.escena.add(this.malla); if (this.amb.climaGotas !== false) this._crearGotas(); } }
      else if (que === 'lluviaOff') { this.modo = 'no'; this.objetivo = 0; }
      else if (que === 'rayo') this._rayo();
      else if (que === 'hora') this.horaObjetivo = a.hora ?? 21;
    }

    _rayo() { this.tDestello = 0; this.tTrueno = 0.4 + Math.random() * 2.2; }

    actualizar(dt) {
      const amb = this.amb, J = this.juego;
      // ⏱ la hora
      if (this.horaObjetivo !== null) {
        let d = this.horaObjetivo - this.hora;
        if (Math.abs(d) < 0.05) { this.hora = this.horaObjetivo; this.horaObjetivo = null; }
        else this.hora += Math.sign(d) * Math.min(Math.abs(d), dt * 6);   // fundido corto: 6 horas por segundo
      } else if (amb.climaCiclo) this.hora = (this.hora + dt * 24 / (Math.max(1, amb.climaMinutos || 12) * 60)) % 24;
      // 🌧 lluvia a ratos
      if (this.modo === 'azar') {
        this.tAzar -= dt;
        if (this.tAzar <= 0) {
          const llueve = this.objetivo > 0;
          this.objetivo = llueve ? 0 : this.fuerza;
          this.tAzar = llueve ? 40 + Math.random() * 80 : 30 + Math.random() * 60;
        }
      }
      if (this.lluvia !== this.objetivo) {
        const d = this.objetivo - this.lluvia;
        this.lluvia += Math.sign(d) * Math.min(Math.abs(d), dt * 0.08);
      }
      // 🌩 tormenta
      if (amb.climaTormenta && this.lluvia > 0.3) {
        this.tRayo -= dt;
        if (this.tRayo <= 0) { this._rayo(); this.tRayo = this._siguienteRayo(); }
      }
      let conDestello = false;
      if (this.tDestello >= 0) {
        const t = this.tDestello += dt;
        this.destello = t < 0.08 ? 1 : t < 0.15 ? 0.15 : t < 0.22 ? 0.8 : Math.max(0, 0.8 - (t - 0.22) * 2.6);
        if (t > 0.6) { this.tDestello = -1; this.destello = 0; }
        conDestello = true;
      }
      if (this.tTrueno >= 0) { this.tTrueno -= dt; if (this.tTrueno < 0) this._trueno(); }
      // la luz: 4 veces por segundo (cada cuadro solo durante un rayo)
      this.tTick += dt;
      if (this.tTick >= 0.25 || conDestello || this._habiaDestello) { this.tTick = 0; this._aplicar(); }
      this._habiaDestello = conDestello;
      // lluvia, techo, sonido y gotas
      if (this.malla) this._lluvia(dt);
    }

    _aplicar() {
      const J = this.juego, V = J.vista, amb = this.amb;
      estado(amb, this.hora, this.lluvia, this.destello, this.st);
      const noche = aplicarVista(V, amb, this.st);
      U.uClMojado.value = amb.climaCharcos !== false ? Math.min(1, this.lluvia * 1.6) : 0;
      // 🌙 lámparas "solo de noche": encender / apagar (las horneadas solo su aura; su luz va en la GPU)
      const encendidas = noche > 0.5;
      if (encendidas !== this.nocheAntes && V.luces) {
        this.nocheAntes = encendidas;
        for (const f of V.luces.fuentes || []) if (f.cfg && f.cfg.soloNoche) f.apagada = !encendidas;
        V.luces.reparto = 0;
      }
    }

    _lluvia(dt) {
      const J = this.juego, cam = J.camara, u = this.malla.material.uniforms;
      // ¿bajo techo? un rayo hacia arriba de vez en cuando
      this.tTecho -= dt;
      if (this.tTecho <= 0 && J.mundo) { this.tTecho = 0.3; this.techo = !!J.mundo.rayo(cam.position.x, cam.position.y + 0.2, cam.position.z, 0, 1, 0, 40); }
      const obj = this.techo ? 0 : 1;
      this.dentro += (obj - this.dentro) * Math.min(1, dt * 4);
      u.uCam.value.copy(cam.position);
      u.uT.value = F.Render.U.uTiempo.value;
      const vis = this.lluvia * this.dentro;
      u.uOpac.value = 0.35 * Math.min(1, vis * 1.5);
      // de noche la lluvia también se apaga (si no, es un velo gris)
      const luz = Math.min(1, Math.max(0.12, this.st.iAmb * 0.8 + this.st.iSol * 0.4));
      u.uColor.value.copy(this.colorLluvia).multiplyScalar(luz);
      this.malla.visible = vis > 0.01;
      this.malla.geometry.setDrawRange(0, Math.round(MAX_GOTAS * Math.min(1, this.lluvia * 1.2)) * 2);
      this._sonidoLluvia(this.lluvia * (0.35 + 0.65 * this.dentro));
      if (this.gotas) this._gotas(dt, vis);
    }

    _sonidoLluvia(vol) {
      const c = F.Audio && F.Audio.contexto && F.Audio.contexto();
      if (!c) return;
      if (!this.sLluvia) {
        if (vol < 0.01) return;
        const src = c.createBufferSource(); src.buffer = ruido(c, 2); src.loop = true;
        const f = c.createBiquadFilter(); f.type = 'lowpass'; f.frequency.value = 1800;
        const g = c.createGain(); g.gain.value = 0;
        src.connect(f).connect(g).connect(c.destination); src.start();
        this.sLluvia = { src, g, f };
      }
      const s = this.sLluvia;
      s.g.gain.value = vol * 0.22 * volEfectos() * (F.Audio.bajoAgua ? 0.3 : 1);
      s.f.frequency.value = this.techo ? 600 : 1800;   // bajo techo: apagado
    }

    _trueno() {
      const c = F.Audio && F.Audio.contexto && F.Audio.contexto();
      if (!c) return;
      if (c.state === 'suspended') c.resume().catch(() => {});
      const t = c.currentTime, src = c.createBufferSource();
      src.buffer = ruido(c, 3.5);
      const f = c.createBiquadFilter(); f.type = 'lowpass'; f.frequency.setValueAtTime(900, t); f.frequency.exponentialRampToValueAtTime(120, t + 1.2);
      const g = c.createGain(), v = 0.9 * volEfectos() * (this.techo ? 0.6 : 1);
      g.gain.setValueAtTime(0.0001, t); g.gain.exponentialRampToValueAtTime(v, t + 0.05);
      g.gain.setValueAtTime(v * 0.7, t + 0.4); g.gain.exponentialRampToValueAtTime(0.001, t + 3.3);
      src.connect(f).connect(g).connect(c.destination);
      src.start(t); src.stop(t + 3.5);
    }

    /* 💧 gotas en la pantalla: unos pocos círculos que aparecen y escurren (DOM, sin texturas) */
    _crearGotas() {
      const cont = this.juego.vista.contenedor;
      const capa = document.createElement('div');
      capa.style.cssText = 'position:absolute;inset:0;pointer-events:none;overflow:hidden;z-index:3';
      const lista = [];
      for (let i = 0; i < 10; i++) {
        const d = document.createElement('div');
        d.style.cssText = 'position:absolute;border-radius:50%;opacity:0;transition:opacity 1.6s linear, transform 1.6s ease-in;' +
          'background:radial-gradient(circle at 35% 30%, rgba(255,255,255,.55), rgba(190,210,230,.18) 45%, rgba(120,140,160,.12) 65%, transparent 70%)';
        capa.appendChild(d); lista.push({ d, t: 0 });
      }
      cont.appendChild(capa);
      this.gotas = { capa, lista, t: 0 };
    }

    _gotas(dt, vis) {
      const G = this.gotas;
      G.t -= dt;
      // solo si llueve donde estás y miras hacia delante o arriba
      const mira = new T.Vector3(0, 0, -1).applyQuaternion(this.juego.camara.quaternion).y;
      if (G.t > 0 || vis < 0.2 || mira < -0.45) return;
      G.t = (0.9 + Math.random()) / (vis * 2);
      const g = G.lista.find((x) => x.libre !== false) || G.lista[0];
      const tam = 18 + Math.random() * 26, d = g.d;
      d.style.transition = 'none';
      d.style.width = d.style.height = tam + 'px';
      d.style.left = (Math.random() * 92) + '%'; d.style.top = (Math.random() * 80) + '%';
      d.style.opacity = '0.9'; d.style.transform = 'translateY(0)';
      g.libre = false;
      void d.offsetWidth;
      d.style.transition = '';
      d.style.opacity = '0'; d.style.transform = 'translateY(' + (10 + Math.random() * 30) + 'px)';
      setTimeout(() => { g.libre = true; }, 1600);
    }

    detener() {
      const V = this.juego.vista, a = this.antes;
      if (this.malla) { V.escena.remove(this.malla); this.malla.geometry.dispose(); this.malla.material.dispose(); this.malla = null; }
      if (this.gotas) { this.gotas.capa.remove(); this.gotas = null; }
      if (this.sLluvia) { try { this.sLluvia.src.stop(); } catch (e) { /* ya parado */ } this.sLluvia = null; }
      V.hemi.color.copy(a.hemiC); V.hemi.groundColor.copy(a.hemiS); V.hemi.intensity = a.hemiI;
      V.sol.color.copy(a.solC); V.sol.intensity = a.solI;
      if (V.luces) for (const f of V.luces.fuentes || []) if (f.cfg && f.cfg.soloNoche) f.apagada = false;
      vistaPrevia(V, this.amb);
    }
  }

  /* ¿Hace falta hornear por partes? Solo si la luz cambia al jugar: el tiempo avanza, puede llover o un disparador
     cambia la hora / la lluvia. Si no (hora fija y seco), basta el horneado clásico a esa hora: más barato aún. */
  function porPartes(escena) {
    const amb = escena.ambiente || {};
    if (!amb.clima) return false;
    if (amb.climaCiclo || (amb.climaLluvia || 'no') !== 'no') return true;
    for (const e of escena.entidades || []) {
      const d = e.palanca || e.disparador || e.pedestal || e.condicion || e.npc;
      const txt = d ? JSON.stringify(d) : '';
      if (/"que":"(lluviaOn|lluviaOff|hora|rayo)"/.test(txt)) return true;
    }
    return false;
  }
  // a hora fija: ¿es de noche? (las lámparas 🌙 se hornean encendidas o no)
  const esNoche = (amb) => { const o = nuevoEstado(); estado(amb, amb.climaHora ?? 12, 0, 0, o); return o.noche > 0.5; };

  F.Clima = { U, estado, porPartes, esNoche, vistaPrevia, prepararMaterial, Gestor, PUNTOS };
})(window.FORJA);
