/* =========================================================
   FORJA · RECOGIBLES (pickups)
   Entidad 'recogible' de la escena: vida, armadura, arma o munición.
   - Se ve con su modelo, o con una figura retro que hace el motor (cruz, chaleco, arma, caja de balas).
   - Se recoge al tocarlo (Quake, Mario) o con el botón de usar (Resident Evil; lo hace el módulo Interactuar).
   - "Solo si lo necesita": con la vida llena no se gasta el botiquín.
   - Reaparece a los N segundos (0 = nunca). Lo recogido se guarda en la partida.
   Rendimiento: sin física ni rayos. Cada cuadro solo se mide la distancia al jugador de los que siguen
   en el mapa; las figuras comparten geometría y material (200 cajas de balas cuestan casi como una).
     juego.recogibles = new FORJA.Recogibles(juego); .preparar(guardado); .actualizar(dt); .recoger(ent)
   ========================================================= */
(function (F) {
  'use strict';
  const T = THREE;

  const BASE = {
    tipo: 'vida',            // 'vida' | 'armadura' | 'arma' | 'municion' | 'bateria' (pilas de la linterna, %) | 'objeto' (a la mochila)
    objeto: '',              // id de proyecto.objetos (para 'objeto')
    cantidad: 25,            // vida / armadura / balas que da (arma: munición extra si ya la tienes = la de su ficha)
    arma: '',                // id de proyecto.armas (para 'arma', y para 'municion' sin tipo)
    municionTipo: '',        // id de proyecto.municiones (munición: de qué tipo; vacío = la propia de "arma")
    recoger: 'tocar',        // 'tocar' | 'usar'
    soloSiFalta: true,
    reaparece: 0,            // segundos (0 = no vuelve)
    modelo: '',              // asset (vacío = figura del motor)
    color: '',               // vacío = el del tipo
    girar: true,
    flotar: true,
    brillo: 0.6,             // aura alrededor (0 = sin aura)
    radio: 0.8,              // a qué distancia se recoge (m)
    aviso: true,             // "+25 Vida" en pantalla
    texto: '',               // aviso propio (vacío = automático)
    sonido: '',
    // 🛡 tipo 'escudo' (escudo de fuerza temporal, módulo Salud)
    escudoManoEstilo: 'medieval',   // 🛡 tipo 'escudoMano': medieval | antimotines (cantidad = aguante)
    escudoSeg: 15, escudoAguante: 100, escudoBloquea: 100, escudoEstilo: 'hex', escudoColor: '#ffcc4a',
  };

  const COLOR_TIPO = { escudoMano: '#d9c08a', escudo: '#ffcc4a', vida: '#e23b3b', armadura: '#3a86e0', arma: '#c9c9c9', municion: '#d8b33a', bateria: '#8fd14f', objeto: '#c8b07a', moneda: '#ffd23f', vidaExtra: '#5fd35f', corazon: '#ff4a6a', piezaCorazon: '#ff8aa0', capacidad: '#e0a040' };
  const NOMBRE_TIPO = { escudoMano: 'Escudo de mano', escudo: 'Escudo de fuerza', vida: 'Vida', armadura: 'Armadura', arma: 'Arma', municion: 'Munición', bateria: 'Pilas', objeto: 'Objeto', moneda: 'Monedas', vidaExtra: 'Vida extra', corazon: 'Contenedor de corazón', piezaCorazon: 'Pedazo de corazón', capacidad: 'Más munición máx.' };

  // armaPorNombre: se busca al aplicar el preajuste (las armas son del proyecto)
  const PRESETS = {
    botiquin: { nombre: 'Botiquín', tipo: 'vida', cantidad: 25 },
    botiquinGrande: { nombre: 'Botiquín grande', tipo: 'vida', cantidad: 50 },
    megasalud: { nombre: 'Megasalud', tipo: 'vida', cantidad: 100, soloSiFalta: false, reaparece: 60, brillo: 1.2 },
    chaleco: { nombre: 'Chaleco', tipo: 'armadura', cantidad: 50 },
    armaduraPesada: { nombre: 'Armadura pesada', tipo: 'armadura', cantidad: 100, brillo: 1 },
    balas: { nombre: 'Caja de balas', tipo: 'municion', cantidad: 20, municionPorNombre: 'Balas', armaPorNombre: 'Pistola' },
    cartuchos: { nombre: 'Cartuchos', tipo: 'municion', cantidad: 8, municionPorNombre: 'Cartuchos', armaPorNombre: 'Escopeta' },
    cohetes: { nombre: 'Cohetes', tipo: 'municion', cantidad: 4, municionPorNombre: 'Cohetes', armaPorNombre: 'Lanzacohetes' },
    escopeta: { nombre: 'Escopeta', tipo: 'arma', cantidad: 0, armaPorNombre: 'Escopeta', brillo: 0.8 },
    lanzacohetes: { nombre: 'Lanzacohetes', tipo: 'arma', cantidad: 0, armaPorNombre: 'Lanzacohetes', brillo: 0.8 },
    pilas: { nombre: 'Pilas', tipo: 'bateria', cantidad: 50 },
    moneda: { nombre: 'Moneda', tipo: 'moneda', cantidad: 1, soloSiFalta: false, brillo: 0.4, radio: 0.9 },
    bolsaMonedas: { nombre: 'Bolsa de monedas', tipo: 'moneda', cantidad: 10, soloSiFalta: false },
    corazon: { nombre: 'Contenedor de corazón', tipo: 'corazon', cantidad: 1, soloSiFalta: false, brillo: 0.6 },
    piezaCorazon: { nombre: 'Pedazo de corazón', tipo: 'piezaCorazon', cantidad: 1, soloSiFalta: false, brillo: 0.4 },
    escudoMedieval: { nombre: 'Escudo medieval', tipo: 'escudoMano', escudoManoEstilo: 'medieval', cantidad: 120, soloSiFalta: true, brillo: 0.5 },
    escudoAntimotines: { nombre: 'Escudo antimotines', tipo: 'escudoMano', escudoManoEstilo: 'antimotines', cantidad: 200, soloSiFalta: true, brillo: 0.5 },
    escudoFuerza: { nombre: 'Escudo de fuerza', tipo: 'escudo', cantidad: 0, escudoSeg: 15, escudoAguante: 100, escudoBloquea: 100, escudoEstilo: 'hex', escudoColor: '#ffcc4a', brillo: 0.8 },
    bolsaBalas: { nombre: 'Bolsa de balas (+máx.)', tipo: 'capacidad', cantidad: 50, llenar: true, soloSiFalta: false, municionPorNombre: 'Balas', brillo: 0.6 },
    frascoMana: { nombre: 'Frasco de maná', tipo: 'municion', cantidad: 40, municionPorNombre: 'Maná' },
    vidaExtra: { nombre: 'Vida extra (1UP)', tipo: 'vidaExtra', cantidad: 1, soloSiFalta: false, brillo: 0.5 },
  };

  /* ---------- Figuras retro (geometría con colores por vértice, una por tipo) ---------- */
  function caja(w, h, d, x, y, z, color) {
    const g = new T.BoxGeometry(w, h, d).toNonIndexed();
    g.translate(x, y, z);
    const c = new T.Color(color), n = g.attributes.position.count, col = new Float32Array(n * 3);
    for (let i = 0; i < n; i++) { col[i * 3] = c.r; col[i * 3 + 1] = c.g; col[i * 3 + 2] = c.b; }
    g.setAttribute('color', new T.BufferAttribute(col, 3));
    g.deleteAttribute('uv');
    return g;
  }
  const geoms = {};
  function geometria(tipo) {
    if (geoms[tipo]) return geoms[tipo];
    const B = '#ffffff', O = '#8c8c8c', N = '#3a3a3a';
    let partes;
    if (tipo === 'escudoMano') {
      // escudo redondo (octógono) con borde y umbo: de canto mira al jugador
      const disco = new T.CylinderGeometry(0.24, 0.24, 0.05, 8).rotateX(Math.PI / 2).toNonIndexed();
      const umbo = new T.CylinderGeometry(0.05, 0.07, 0.05, 6).rotateX(Math.PI / 2).toNonIndexed(); umbo.translate(0, 0, 0.05);
      for (const [g0, col] of [[disco, '#ffffff'], [umbo, '#8c8c8c']]) {
        const c = new T.Color(col), n = g0.attributes.position.count, a = new Float32Array(n * 3);
        for (let i = 0; i < n; i++) { a[i * 3] = c.r; a[i * 3 + 1] = c.g; a[i * 3 + 2] = c.b; }
        g0.setAttribute('color', new T.BufferAttribute(a, 3)); g0.deleteAttribute('uv');
      }
      partes = [disco, umbo];
    } else if (tipo === 'escudo') {
      // gema de energía: dos pirámides (octaedro) en caras planas, y la esfera del campo alrededor (en figura)
      const g0 = new T.OctahedronGeometry(0.16, 0).toNonIndexed();
      g0.scale(1, 1.4, 1);
      const n = g0.attributes.position.count, col = new Float32Array(n * 3).fill(1);
      g0.setAttribute('color', new T.BufferAttribute(col, 3));
      g0.deleteAttribute('uv');
      partes = [g0];
    } else if (tipo === 'armadura') {
      // chaleco: pecho, hombreras y cuello
      partes = [caja(0.42, 0.4, 0.12, 0, 0, 0, B), caja(0.13, 0.1, 0.13, -0.15, 0.24, 0, B), caja(0.13, 0.1, 0.13, 0.15, 0.24, 0, B),
        caja(0.3, 0.06, 0.13, 0, -0.08, 0, O)];
    } else if (tipo === 'bateria') {
      // dos pilas de pie: cuerpo, franja y polo
      partes = [caja(0.1, 0.3, 0.1, -0.07, 0, 0, '#3a3a3a'), caja(0.1, 0.3, 0.1, 0.07, 0, 0, '#3a3a3a'),
        caja(0.105, 0.1, 0.105, -0.07, 0.1, 0, B), caja(0.105, 0.1, 0.105, 0.07, 0.1, 0, B),
        caja(0.04, 0.04, 0.04, -0.07, 0.17, 0, O), caja(0.04, 0.04, 0.04, 0.07, 0.17, 0, O)];
    } else if (tipo === 'moneda') {
      // moneda de canto: disco cuadrado (PS1) con el borde más oscuro
      partes = [caja(0.3, 0.3, 0.05, 0, 0, 0, B), caja(0.34, 0.06, 0.04, 0, 0.15, 0, O), caja(0.34, 0.06, 0.04, 0, -0.15, 0, O)];
    } else if (tipo === 'arma') {
      partes = [caja(0.12, 0.12, 0.62, 0, 0.04, 0, O), caja(0.1, 0.2, 0.12, 0, -0.1, 0.16, N), caja(0.06, 0.06, 0.2, 0, 0.02, -0.38, N)];
    } else {
      // caja de munición con tapa y franja
      partes = [caja(0.38, 0.22, 0.26, 0, 0, 0, B), caja(0.4, 0.05, 0.28, 0, 0.12, 0, O), caja(0.39, 0.05, 0.27, 0, 0, 0, N)];
    }
    const g = T.mergeGeometries(partes);
    partes.forEach((p) => p.dispose());
    g.computeVertexNormals();
    return (geoms[tipo] = g);
  }

  // La cruz de la vida va en el color del tipo y la caja queda blanca: se pinta por vértice
  const geomsVida = {};
  function geometriaVida(color) {
    if (geomsVida[color]) return geomsVida[color];
    const partes = [caja(0.42, 0.3, 0.3, 0, 0, 0, '#f4f4f4'), caja(0.26, 0.08, 0.32, 0, 0, 0, color), caja(0.08, 0.24, 0.32, 0, 0, 0, color)];
    const g = T.mergeGeometries(partes);
    partes.forEach((p) => p.dispose());
    g.computeVertexNormals();
    return (geomsVida[color] = g);
  }

  const mats = {};
  function material(color) {
    return mats[color] || (mats[color] = new T.MeshLambertMaterial({ color, vertexColors: true, flatShading: true }));
  }

  let texAura = null;
  function texturaAura() {
    if (texAura) return texAura;
    const c = document.createElement('canvas');
    c.width = c.height = 64;
    const g = c.getContext('2d');
    for (let i = 6; i >= 1; i--) {          // anillos duros, estilo PS1
      g.fillStyle = `rgba(255,255,255,${(Math.pow(1 - i / 6 + 1 / 6, 2) * 0.9).toFixed(3)})`;
      g.beginPath(); g.arc(32, 32, (i / 6) * 31, 0, Math.PI * 2); g.fill();
    }
    texAura = new T.CanvasTexture(c);
    texAura.magFilter = T.NearestFilter;
    return texAura;
  }
  const matsAura = {};
  function materialAura(color) {
    return matsAura[color] || (matsAura[color] = new T.SpriteMaterial({ map: texturaAura(), color, transparent: true, opacity: 0.55,
      blending: T.AdditiveBlending, depthWrite: false }));
  }

  const ALTURA = 0.45;   // la figura flota a esta altura sobre el punto de la entidad

  // Object3D de la entidad: grupo → "giro" (lo que gira y flota) → figura + aura
  function figura(ent, proyecto) {
    const r = { ...BASE, ...(ent.recogible || {}) };
    // objeto de la mochila: su figura (hierba, frasco, llave…) y su color
    const ob = r.tipo === 'objeto' && proyecto && (proyecto.objetos || []).find((o) => o.id === r.objeto);
    const color = r.color || (ob && ob.color) || COLOR_TIPO[r.tipo] || '#ffffff';
    const grupo = new T.Group();
    const giro = new T.Group();
    giro.position.y = ALTURA;
    const a = r.modelo && F.Assets.mapa.get(r.modelo);
    if (a && a.gltf) {
      giro.add(T.SkeletonUtils.clone(a.gltf.scene));
    } else if (ob && F.Inventario) {
      giro.add(F.Inventario.figuraObjeto(ob, 1.6));
    } else if (r.tipo === 'vida') {
      giro.add(new T.Mesh(geometriaVida(color), material('#ffffff')));
    } else {
      giro.add(new T.Mesh(geometria(r.tipo), material(color)));
      // 🛡 escudo de fuerza: una esfera de energía pequeña alrededor de la gema
      if (r.tipo === 'escudo' && F.Campo) {
        const c = F.Campo.crear({ forma: 'esfera', estilo: r.escudoEstilo || 'hex', color: r.escudoColor || color, fuerza: 0.9 });
        c.malla.scale.setScalar(0.38);
        c.malla.userData.sinSombra = true;
        giro.add(c.malla);
      }
    }
    if (r.brillo > 0) {
      const aura = new T.Sprite(materialAura(color));
      aura.scale.setScalar(0.5 + 0.9 * r.brillo);
      aura.renderOrder = 5;
      aura.userData.sinSombra = true;
      giro.add(aura);
    }
    grupo.add(giro);
    grupo.userData.giro = giro;
    return grupo;
  }

  /* ---------- En el juego ---------- */
  class Recogibles {
    constructor(juego) {
      this.juego = juego;
      this.lista = [];
      this.recogidos = new Set();   // ids que ya no están (se guardan en la partida)
      this.t = 0;
    }

    preparar(guardado) {
      const yaTomados = new Set((guardado && guardado.recogidos) || []);
      for (const ent of this.juego.escena.entidades) {
        if (ent.tipo !== 'recogible') continue;
        const obj = this.juego.objetos.get(ent.id);
        if (!obj || !ent.visible) continue;
        const r = { ...BASE, ...(ent.recogible || {}) };
        const it = { ent, obj, r, giro: obj.userData.giro, activo: true, espera: 0, fase: Math.random() * 6.28, pos: new T.Vector3() };
        obj.getWorldPosition(it.pos);
        if (yaTomados.has(ent.id)) { it.activo = false; obj.visible = false; this.recogidos.add(ent.id); }
        this.lista.push(it);
      }
      this.tocar = this.lista.filter((x) => x.r.recoger !== 'usar');
      this._juntar();
    }

    /* ⚡ Los iguales en UN dibujo: las figuras con la misma forma y material van en un InstancedMesh y las auras del mismo
       color y tamaño en un lote de puntos. 100 monedas: de ~200 dibujos a 2. Cada cuadro solo se copian sus posiciones. */
    _juntar() {
      this.lotes = [];
      const esc = this.juego.vista.escena, figs = new Map(), auras = new Map();
      for (const it of this.lista) {
        if (!it.giro || it.suelto) continue;
        for (const h of it.giro.children) {
          if (h.isMesh && !h.isSkinnedMesh && !Array.isArray(h.material)) {
            const k = h.geometry.uuid + '|' + h.material.uuid;
            (figs.get(k) || figs.set(k, []).get(k)).push({ it, o: h });
          } else if (h.isSprite) {
            const k = h.material.uuid + '|' + h.scale.x.toFixed(2);
            (auras.get(k) || auras.set(k, []).get(k)).push({ it, o: h });
          }
        }
      }
      for (const lista of figs.values()) {
        if (lista.length < 3) continue;
        const im = new T.InstancedMesh(lista[0].o.geometry, lista[0].o.material, lista.length);
        im.frustumCulled = false;
        im.userData.ayudaEditor = true;
        for (const x of lista) {
          x.o.visible = false;
          // base fija: el recogible no se mueve; solo cambia el "giro" (gira y flota). Así no se recorren los padres cada cuadro
          x.it.obj.updateWorldMatrix(true, false);
          x.o.updateMatrix();
          x.base = x.it.obj.matrixWorld.clone();
        }
        esc.add(im);
        this.lotes.push({ im, lista });
      }
      for (const lista of auras.values()) {
        if (lista.length < 3) continue;
        const sm = lista[0].o.material;
        const geo = new T.BufferGeometry();
        geo.setAttribute('position', new T.BufferAttribute(new Float32Array(lista.length * 3), 3));
        const pm = new T.PointsMaterial({ map: sm.map, color: sm.color, size: lista[0].o.scale.x, sizeAttenuation: true, transparent: true,
          opacity: sm.opacity, depthWrite: false, blending: sm.blending });
        const pts = new T.Points(geo, pm);
        pts.frustumCulled = false;
        pts.renderOrder = 5;
        pts.userData.ayudaEditor = true;
        for (const x of lista) x.o.visible = false;
        esc.add(pts);
        this.lotes.push({ pts, lista });
      }
    }

    _moverLotes() {
      const w = this._w || (this._w = new T.Vector3()), cero = this._cero || (this._cero = new T.Matrix4().makeScale(0, 0, 0));
      for (const L of this.lotes) {
        if (L.im) {
          L.lista.forEach((x, i) => {
            if (x.it.activo && x.it.obj.visible) {
              const g = x.it.giro, m = this._m || (this._m = new T.Matrix4());
              g.updateMatrix();
              L.im.setMatrixAt(i, m.multiplyMatrices(x.base, g.matrix).multiply(x.o.matrix));
            }
            else L.im.setMatrixAt(i, cero);
          });
          L.im.instanceMatrix.needsUpdate = true;
          // la primera vez: esfera que abarca todo el lote → si no se ve ninguno, no se dibuja (antes: siempre)
          if (!L.esfera) { L.im.computeBoundingSphere(); L.im.boundingSphere.radius += 1; L.im.frustumCulled = true; L.esfera = true; }
        } else {
          const a = L.pts.geometry.attributes.position;
          L.lista.forEach((x, i) => {
            if (x.it.activo && x.it.obj.visible) { const P = x.it.pos, g = x.it.giro; a.setXYZ(i, P.x + g.position.x, P.y + g.position.y + x.o.position.y, P.z + g.position.z); }
            else a.setXYZ(i, 0, -1e5, 0);
          });
          a.needsUpdate = true;
          if (!L.esfera) {
            // esfera solo con los visibles (los recogidos están lejísimos abajo)
            const g = L.pts.geometry, vis = L.lista.filter((x) => x.it.activo);
            const caja = new T.Box3();
            for (const x of vis) caja.expandByPoint(x.it.pos);
            g.boundingSphere = caja.isEmpty() ? new T.Sphere() : caja.getBoundingSphere(new T.Sphere());
            g.boundingSphere.radius += 2;
            L.pts.frustumCulled = true; L.esfera = true;
          }
        }
      }
    }

    // ¿Le sirve al jugador? Devuelve true si se lo dio
    _aplicar(r, forzar) {
      const j = this.juego.jugador;
      const solo = r.soloSiFalta && !forzar;
      if (r.tipo === 'vida') {
        if (!j.curar) return false;
        if (solo && j.vida >= j.vidaMax) return false;
        j.curar(r.cantidad, 0);
        return true;
      }
      if (r.tipo === 'armadura') {
        if (!j.curar || !(j.armaduraMax > 0)) return false;
        if (solo && j.armadura >= j.armaduraMax) return false;
        j.curar(0, r.cantidad);
        return true;
      }
      if (r.tipo === 'arma') {
        if (!j.darArma) return false;
        return j.darArma(r.arma, r.cantidad) || !solo;
      }
      if (r.tipo === 'bateria') {
        if (!j.recargarLinterna) { this.mensaje('Activa el módulo Linterna para usarlas'); return false; }
        return j.recargarLinterna(r.cantidad, solo);
      }
      if (r.tipo === 'municion') {
        if (!j.darMunicion) return false;
        return j.darMunicion(r.municionTipo || r.arma, r.cantidad) || !solo;
      }
      if (r.tipo === 'escudoMano') {
        // 🛡 escudo de mano (módulo Armas): cantidad = aguante
        if (!j.darEscudoMano) { this.mensaje('Activa el módulo Armas para usarlo'); return false; }
        if (solo && j.escudoMano && j.escudoMano.estilo === (r.escudoManoEstilo || 'medieval') && j.escudoMano.vida >= j.escudoMano.max) return false;
        return j.darEscudoMano({ estilo: r.escudoManoEstilo || 'medieval', aguante: r.cantidad > 0 ? r.cantidad : 120, color: r.escudoManoColor || '' });
      }
      if (r.tipo === 'escudo') {
        // 🛡 escudo de fuerza temporal (módulo Salud)
        if (!j.activarEscudo) { this.mensaje('Activa el módulo Salud para usarlo'); return false; }
        if (solo && j.escudoActivo && j.escudoActivo()) return false;
        return j.activarEscudo({ seg: r.escudoSeg ?? 15, aguante: r.escudoAguante ?? 100, bloquea: r.escudoBloquea ?? 100, estilo: r.escudoEstilo || 'hex', color: r.escudoColor || r.color || '#ffcc4a' });
      }
      if (r.tipo === 'capacidad') return j.ampliarMunicion ? j.ampliarMunicion(r.municionTipo, r.cantidad, r.llenar !== false) : false;   // ⬆ bolsa / carcaj
      if (r.tipo === 'corazon') return j.sumarCorazon ? j.sumarCorazon(Math.max(1, r.cantidad | 0)) : false;   // ♥ +1 corazón máx. (Salud)
      if (r.tipo === 'piezaCorazon') return j.sumarPieza ? j.sumarPieza(Math.max(1, r.cantidad | 0)) : false;
      if (r.tipo === 'vidaExtra') {
        // ❤ 1UP: lo cuenta la partida (sistema de vidas, Menús ▸ Partidas guardadas)
        F.emitir('vida-extra', { juego: j.juego, n: Math.max(1, r.cantidad | 0) });
        return true;
      }
      if (r.tipo === 'moneda') {
        // 🪙 monedas: un contador del jugador (tiendas)
        const pr = j.juego && j.juego.proyecto, d = F.Divisas.de(pr, r.divisa);
        F.Divisas.sumar(j, d.id, Math.max(1, r.cantidad | 0), pr);
        return true;
      }
      if (r.tipo === 'objeto') {
        // a la mochila (módulo Inventario); si no cabe entero, se queda lo que sobra
        if (!j.inventario) { this.mensaje('Activa el módulo Inventario para recogerlo'); return false; }
        const n = Math.max(1, r.cantidad | 0), resto = j.inventario.agregar('obj', r.objeto, n);
        if (resto >= n) { this.mensaje('No tienes sitio'); return false; }
        return true;
      }
      return false;
    }

    // Lo llama el contacto o el módulo Interactuar. true = recogido
    /* Soltar uno en el mapa durante el juego (lo que deja un enemigo al morir). pr: un preajuste (PRESETS)
       o una config parcial. No reaparece y no se guarda en la partida. */
    soltar(pr, pos) {
      const proyecto = this.juego.proyecto;
      const { nombre, armaPorNombre, municionPorNombre, ...valores } = pr;
      const r = { ...BASE, ...valores, reaparece: 0, color: valores.color || COLOR_TIPO[valores.tipo || 'vida'] };
      const armas = proyecto.armas || [], ms = proyecto.municiones || [];
      if (armaPorNombre) { const a = armas.find((x) => x.nombre === armaPorNombre) || armas[0]; r.arma = a ? a.id : ''; }
      if (municionPorNombre) {
        const arma = armas.find((x) => x.id === r.arma);
        const m = ms.find((x) => x.nombre === municionPorNombre) || (arma && ms.find((x) => x.id === arma.municion));
        r.municionTipo = m ? m.id : '';
      }
      this.sueltos = (this.sueltos || 0) + 1;
      const ent = { id: 'suelto' + this.sueltos, tipo: 'recogible', nombre: nombre || 'Recogible', recogible: r, visible: true };
      const obj = figura(ent, proyecto);
      obj.position.set(pos.x, pos.y, pos.z);
      this.juego.vista.escena.add(obj);
      const it = { ent, obj, r, giro: obj.userData.giro, activo: true, espera: 0, fase: Math.random() * 6.28, pos: obj.position.clone(), suelto: true };
      this.lista.push(it);
      if (r.recoger !== 'usar') this.tocar.push(it);
      return it;
    }

    // al terminar la partida se quitan los que soltaron los enemigos
    limpiar() {
      for (const L of this.lotes || []) {
        const o = L.im || L.pts;
        if (o.parent) o.parent.remove(o);
        if (L.pts) { L.pts.geometry.dispose(); L.pts.material.dispose(); }
        for (const x of L.lista) x.o.visible = true;   // en el editor se vuelven a ver sueltos
      }
      this.lotes = [];
      for (const it of this.lista) if (it.suelto && it.obj.parent) it.obj.parent.remove(it.obj);
      this.lista = this.lista.filter((it) => !it.suelto);
      this.tocar = (this.tocar || []).filter((it) => !it.suelto);
    }

    recoger(it) {
      if (typeof it === 'string' || (it && !it.r)) it = this.lista.find((x) => x.ent === it || x.ent.id === it);
      if (!it || !it.activo) return false;
      const j = this.juego.jugador;
      if (!j || j.muerto) return false;
      if (!this._aplicar(it.r)) return false;
      it.activo = false;
      it.obj.visible = false;
      if (it.r.reaparece > 0) it.espera = it.r.reaparece;
      else if (!it.suelto) this.recogidos.add(it.ent.id);
      if (it.r.sonido) F.Audio.efecto(it.r.sonido);
      else F.Audio.sintetico('recoger', { volumen: 0.8, tono: it.r.tipo === 'vida' ? 1.2 : 0.9 });
      if (it.r.aviso && (this.juego.proyecto.hud || {}).recogidos !== false) this._avisar(it);
      F.emitir('recogido', { ent: it.ent, recogible: it.r, jugador: j, juego: this.juego });
      return true;
    }

    _texto(it) {
      const r = it.r;
      if (r.texto) return r.texto;
      const arma = (this.juego.proyecto.armas || []).find((a) => a.id === r.arma);
      if (r.tipo === 'arma') return arma ? arma.nombre : 'Arma';
      const tipoM = r.municionTipo && (this.juego.proyecto.municiones || []).find((m) => m.id === r.municionTipo);
      if (r.tipo === 'municion') return `+${r.cantidad} ${tipoM ? tipoM.nombre : arma ? 'munición de ' + arma.nombre : 'munición'}`;
      if (r.tipo === 'objeto') {
        const ob = (this.juego.proyecto.objetos || []).find((o) => o.id === r.objeto);
        return (ob ? ob.nombre : 'Objeto') + (r.cantidad > 1 ? ' ×' + r.cantidad : '');
      }
      if (r.tipo === 'escudoMano') return r.escudoManoEstilo === 'antimotines' ? '▮ Escudo antimotines' : '🛡 Escudo medieval';
      if (r.tipo === 'escudo') return '🛡 Escudo de fuerza' + (r.escudoSeg > 0 ? ` (${r.escudoSeg} s)` : '');
      return `+${r.cantidad} ${NOMBRE_TIPO[r.tipo]}`;
    }

    // aviso suelto en la lista de recogidos ("No tienes sitio"); el mismo texto como mucho cada 2 s
    mensaje(texto) {
      const ahora = performance.now();
      if (this._ultimo === texto && ahora - this._tMensaje < 2000) return;
      this._ultimo = texto; this._tMensaje = ahora;
      if (!this.hud) { this.hud = F.Hud.pieza(this.juego, 'fh-recogidos'); this.tinte = F.Hud.pieza(this.juego, 'fh-tinte'); }
      const linea = document.createElement('div');
      linea.textContent = texto;
      this.hud.appendChild(linea);
      while (this.hud.children.length > 4) this.hud.firstChild.remove();
      setTimeout(() => linea.remove(), 2200);
    }

    _avisar(it) {
      const H = F.Hud;
      if (!this.hud) {
        this.hud = H.pieza(this.juego, 'fh-recogidos');
        this.tinte = H.pieza(this.juego, 'fh-tinte');
      }
      const linea = document.createElement('div');
      linea.textContent = this._texto(it);
      this.hud.appendChild(linea);
      while (this.hud.children.length > 4) this.hud.firstChild.remove();
      setTimeout(() => linea.remove(), 2200);
      // destello del color del objeto (como Quake al recoger)
      const t = this.tinte;
      t.style.transition = 'none';
      t.style.background = it.r.color || COLOR_TIPO[it.r.tipo];
      t.style.opacity = 0.22;
      void t.offsetWidth;
      t.style.transition = '';
      t.style.opacity = 0;
    }

    actualizar(dt) {
      if (!this.lista.length) return;
      this.t += dt;
      const j = this.juego.jugador;
      // animar los que se ven y volver a poner los que reaparecen
      for (const it of this.lista) {
        if (!it.activo) {
          if (it.espera > 0 && (it.espera -= dt) <= 0) { it.activo = true; it.obj.visible = true; }
          continue;
        }
        if (it.giro) {
          if (it.r.girar) it.giro.rotation.y += dt * 1.8;
          if (it.r.flotar) it.giro.position.y = ALTURA + Math.sin(this.t * 2.2 + it.fase) * 0.07;
        }
      }
      if (this.lotes && this.lotes.length) this._moverLotes();
      // recoger al tocar: distancia al cuerpo (sin rayos ni física)
      if (!j || j.muerto) return;
      const c = j.cuerpo.pie, alto = j.cuerpo.altura || 1.8;
      for (const it of this.tocar) {
        if (!it.activo) continue;
        const dx = it.pos.x - c.x, dz = it.pos.z - c.z, dy = it.pos.y + ALTURA - c.y;
        const rr = it.r.radio + 0.3;
        if (dx * dx + dz * dz < rr * rr && dy > -0.6 && dy < alto + 0.3) this.recoger(it);
      }
    }
  }

  Recogibles.BASE = BASE;
  Recogibles.PRESETS = PRESETS;
  Recogibles.COLOR_TIPO = COLOR_TIPO;
  Recogibles.figura = figura;
  F.Recogibles = Recogibles;

  /* 💰 Divisas del proyecto (proyecto.divisas): oro, gemas… Cada una: { id, nombre, icono (emoji), imagen (textura),
     color, max (0 = sin tope), enBaul (se puede guardar en el baúl) }. Sin lista = solo "Monedas" (como antes).
     El jugador lleva j.divisas = { id: cantidad }; j.monedas sigue igual a la divisa 'monedas' (compatibilidad). */
  const DIVISA = { id: 'monedas', nombre: 'Monedas', icono: '🪙', imagen: '', color: '#ffd23f', max: 0, enBaul: false };
  const Divisas = {
    BASE: DIVISA,
    lista(pr) {
      const l = pr && Array.isArray(pr.divisas) && pr.divisas.length ? pr.divisas : [DIVISA];
      return l.map((d) => ({ ...DIVISA, ...d }));
    },
    de(pr, id) { const l = Divisas.lista(pr); return l.find((d) => d.id === id) || l[0]; },
    tiene(j, id) {
      if (!j.divisas) j.divisas = {};
      if (id === 'monedas' && j.divisas.monedas == null && j.monedas) j.divisas.monedas = j.monedas;
      return j.divisas[id] || 0;
    },
    poner(j, id, n, pr) {
      if (!j.divisas) j.divisas = {};
      const d = Divisas.de(pr || (j.juego && j.juego.proyecto), id);
      n = Math.max(0, Math.round(n));
      if (d && d.max > 0) n = Math.min(d.max, n);
      j.divisas[id] = n;
      if (id === 'monedas') j.monedas = n;
      F.emitir('monedas', j);
      return n;
    },
    sumar(j, id, n, pr) { return Divisas.poner(j, id, Divisas.tiene(j, id) + n, pr); },
    // icono para HTML (imagen del proyecto o emoji) y para texto plano
    html(d) {
      const a = d.imagen && F.Assets && F.Assets.mapa.get(d.imagen);
      if (a && a.url) return `<img src="${a.url}" style="height:1em;vertical-align:-.15em;image-rendering:pixelated">`;
      return String(d.icono || d.nombre).replace(/[&<>]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;' }[c]));
    },
    texto(d) { return d.icono || d.nombre; },
  };
  F.Divisas = Divisas;
})(window.FORJA);
