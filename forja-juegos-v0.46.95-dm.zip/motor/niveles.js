/* =========================================================
   FORJA · NIVELES (gestor de niveles)
   Ir de una escena a otra y volver sin que se rompa nada.

   - Entidad 🚪 'salida' (ent.salida = SALIDA): una caja (se agranda con la escala) que lleva a otra escena.
     Se activa al TOCARLA (Quake / Mario) o con el botón de USAR (puerta estilo Resident Evil, módulo Interactuar).
     Al llegar a una salida no se dispara hasta que sales de ella (sin rebotes).
   - Varios ⚑ inicios por escena: uno es el principal (empezar el juego), los demás son puntos de llegada.
   - Memoria por escena (escena.nivel.memoria): 'recordar' (Resident Evil / Zelda: los muertos siguen muertos,
     lo recogido no vuelve, lo roto sigue roto) o 'reiniciar' (arcade: cada visita sale como nueva).
   - El jugador conserva vida, armadura, armas y munición entre niveles (salvo los "reinicios" de la salida).
   - Transición: fundido a negro + cartel opcional (nombre del nivel, imagen, texto) + tiempo mínimo.
     Mientras está en negro se arma la colisión y se precompilan los shaders: al aparecer no hay tirón.
   - Todo se guarda en la ranura de la partida (en el framework de Godot la memoria de niveles solo vivía
     en RAM y se perdía al cargar).

   Uso (lo hacen FORJA.Partida y el ▶ Jugar del editor):
     const niveles = new FORJA.Niveles();
     juego emite 'salida' {juego, ent} → niveles.viajar({ juego, ent, cambiar(idEscena, inicio) → juegoNuevo })
     niveles.inicioPara(idEscena, llegada, jugador) · marcarEntrada · reinicio · serializar / cargar
   ========================================================= */
(function (F) {
  'use strict';
  const T = THREE;

  /* ---------- Datos ---------- */
  const SALIDA = {
    destino: '',              // id de la escena a la que lleva ('' = ninguna todavía)
    llegada: '',              // id del ⚑ inicio de la escena destino ('' = el principal)
    activar: 'tocar',         // 'tocar' (entrar en la caja) | 'usar' (mirar y pulsar el botón de usar)
    aviso: '',                // texto del aviso con 'usar' ('' = "Ir a <nombre del nivel>")
    sonido: '',               // asset de audio al activarla
    fundido: 0.5,             // segundos del fundido a negro (y de vuelta)
    transicion: 'negro',      // 🎞 'negro' | 'blanco' | 'pixelado' | 'barrido' | 'circulo' | 'estatica' | 'persiana' (motor/efectos.js)
    cartel: false,            // pantalla de carga con el nombre del nivel
    cartelTitulo: '',         // '' = el nombre de la escena destino
    cartelTexto: '',
    cartelImagen: '',         // textura de fondo del cartel
    cartelTiempo: 1.5,        // segundos mínimos que se ve el cartel
    llenarVida: false,        // "capítulo nuevo": llegar con la vida llena
    quitarArmadura: false,
    inventarioInicial: false, // armas y munición como al empezar el juego
    olvidarNiveles: false,    // todos los niveles vuelven a estar como nuevos
    // Sin modelo propio el motor dibuja una figura que se ajusta a la caja (como las figuras retro de los enemigos)
    figura: 'auto',           // 'auto' (puerta si se usa, portal si se toca) | 'puerta' | 'portal' | 'ninguna'
    colorMarco: '#4a3a2c', colorPuerta: '#7a5636', colorPortal: '#38c8ff',
    // Modelo propio (puerta, portal, ascensor…). No se estira con la caja: tiene su propio tamaño.
    modelo: '',               // asset GLB ('' = solo la caja invisible)
    modeloEscala: 1,
    modeloX: 0, modeloY: 0, modeloZ: 0,
    modeloGiro: 0,            // grados en Y
    choca: 'auto',            // la puerta / el modelo: 'auto' (sólida si se usa con el botón) | 'si' | 'no'. La caja nunca choca
    animReposo: '',           // animación del GLB en bucle mientras no se usa ('' = ninguna)
    animUsar: '',             // animación del GLB al activarla, una vez (abrir puerta)
    esperarAnim: true,        // el fundido empieza cuando termina animUsar
    girar: 0,                 // vueltas por segundo (portal, objeto flotante) · 0 = quieto
    flotar: 0,                // metros que sube y baja
    ritmo: 0,                 // cuadros por segundo de girar/flotar (10 = movimiento entrecortado retro) · 0 = fluido
  };

  const NIVEL = {
    memoria: 'recordar',      // 'recordar' | 'reiniciar'
    musica: '',               // asset de audio ('' = sin música)
    musicaVolumen: 1, musicaInicio: 0, musicaFin: 0, musicaFundido: 1,
  };

  const ESQUEMA_NIVEL = [
    { grupo: '🚪 Nivel' },
    { k: 'memoria', t: 'sel', e: 'Al volver a este nivel', def: 'recordar',
      op: [['recordar', 'Recuerda lo que pasó (Resident Evil / Zelda)'], ['reiniciar', 'Sale como nuevo (arcade)']],
      ayuda: 'Recuerda: los enemigos muertos siguen muertos, lo recogido no vuelve y lo roto sigue roto. Los enemigos vivos vuelven a su sitio' },
    { k: 'musica', t: 'asset', e: 'Música', def: '', tipoAsset: 'audio', vacio: '(sin música)',
      ayuda: 'Suena en bucle mientras juegas este nivel. Si el siguiente nivel tiene la misma, sigue sin cortarse' },
    { k: 'musicaVolumen', t: 'rango', e: 'Volumen de la música', def: 1, min: 0, max: 1, paso: 0.05, si: (v) => v.musica },
    { k: 'musicaInicio', t: 'num', e: 'El bucle vuelve a (s)', def: 0, paso: 0.1, min: 0, si: (v) => v.musica,
      ayuda: 'La primera vez suena desde el principio (la intro); al llegar al final vuelve a este segundo. 0 = desde el principio' },
    { k: 'musicaFin', t: 'num', e: 'El bucle termina en (s)', def: 0, paso: 0.1, min: 0, si: (v) => v.musica, ayuda: '0 = al final del archivo' },
    { k: 'musicaFundido', t: 'num', e: 'Fundido al entrar (s)', def: 1, paso: 0.25, min: 0, si: (v) => v.musica, ayuda: 'Se cruza con la música del nivel anterior. 0 = de golpe' },
  ];

  // Lo que se edita de una salida en el Inspector (el destino y la llegada los pone el editor: dependen del proyecto)
  const ESQUEMA_SALIDA = [
    { k: 'activar', t: 'sel', e: 'Se activa', def: 'tocar',
      op: [['tocar', 'Al entrar en la caja (Quake / Mario)'], ['usar', 'Con el botón de usar (puerta)']],
      ayuda: 'Agranda o achica la caja con la herramienta Escalar (R). Con "usar" necesitas el módulo Interactuar' },
    { k: 'aviso', t: 'texto', e: 'Texto del aviso', def: '', si: (v) => v.activar === 'usar',
      ayuda: 'Vacío = "Ir a <nombre del nivel>". Ej.: "Abrir puerta", "Bajar al sótano"' },
    { k: 'sonido', t: 'asset', e: 'Sonido', def: '', tipoAsset: 'audio', vacio: '(ninguno)', ayuda: 'Puerta que se abre, ascensor, teletransporte…' },
    { k: 'transicion', t: 'sel', e: 'Transición', def: 'negro', op: (F.Efectos ? F.Efectos.TRANSICIONES : [['negro', 'Fundido a negro']]),
      ayuda: 'Cómo se tapa la pantalla al irte y cómo se destapa al llegar' },
    { k: 'fundido', t: 'rango', e: 'Duración de la transición (s)', def: 0.5, min: 0, max: 2, paso: 0.05 },
    { grupo: 'Cómo se ve' },
    { k: 'modelo', t: 'asset', e: 'Modelo', def: '', tipoAsset: 'modelo', vacio: '(figura del motor)',
      ayuda: 'Tu modelo GLB (puerta, ascensor…). Sin modelo, el motor dibuja una puerta o un portal del tamaño de la caja' },
    { k: 'figura', t: 'sel', e: 'Figura del motor', def: 'auto', si: (v) => !v.modelo,
      op: [['auto', 'Automática (puerta si se usa, portal si se toca)'], ['puerta', '🚪 Puerta (se abre al usarla)'], ['portal', '🌀 Portal'], ['ninguna', 'Ninguna (invisible)']] },
    { k: 'colorMarco', t: 'color', e: 'Color del marco', def: '#4a3a2c', si: (v) => !v.modelo && figuraDe(v) !== 'ninguna' },
    { k: 'colorPuerta', t: 'color', e: 'Color de la puerta', def: '#7a5636', si: (v) => !v.modelo && figuraDe(v) === 'puerta' },
    { k: 'colorPortal', t: 'color', e: 'Color del portal', def: '#38c8ff', si: (v) => !v.modelo && figuraDe(v) === 'portal' },
    { k: 'modeloEscala', t: 'num', e: 'Escala del modelo', def: 1, paso: 0.05, min: 0.01, si: (v) => v.modelo },
    { k: 'modeloX', t: 'num', e: 'Mover X', def: 0, paso: 0.05, si: (v) => v.modelo },
    { k: 'modeloY', t: 'num', e: 'Mover Y', def: 0, paso: 0.05, si: (v) => v.modelo },
    { k: 'modeloZ', t: 'num', e: 'Mover Z', def: 0, paso: 0.05, si: (v) => v.modelo, ayuda: 'Negativo = hacia la flecha (el frente)' },
    { k: 'modeloGiro', t: 'num', e: 'Girar modelo (°)', def: 0, paso: 15, si: (v) => v.modelo },
    { k: 'choca', t: 'sel', e: '¿Se puede atravesar?', def: 'auto', si: (v) => v.modelo || figuraDe(v) === 'puerta',
      op: [['auto', 'Automático: sólida si se usa con el botón'], ['si', 'No: siempre sólida'], ['no', 'Sí: se atraviesa']],
      ayuda: 'Una puerta estilo Resident Evil es sólida: te paras delante y pulsas el botón. Si se activa al entrar en la caja tiene que poder atravesarse' },
    { k: 'animReposo', t: 'sel', e: 'Animación en reposo', def: '', op: [['', '(ninguna)']], si: (v) => v.modelo,
      ayuda: 'En bucle mientras nadie la usa (portal que brilla, luz que parpadea)' },
    { k: 'animUsar', t: 'sel', e: 'Animación al usarla', def: '', op: [['', '(ninguna)']], si: (v) => v.modelo,
      ayuda: 'Una vez al activarla: la puerta se abre, el ascensor baja…' },
    { k: 'esperarAnim', t: 'bool', e: 'Esperar a que termine', def: true, si: (v) => v.modelo && v.animUsar,
      ayuda: 'El fundido a negro empieza cuando acaba la animación' },
    { k: 'girar', t: 'num', e: 'Girar (vueltas/s)', def: 0, paso: 0.1, si: (v) => v.modelo, ayuda: 'Sin animación propia: el motor lo hace girar. 0 = quieto' },
    { k: 'flotar', t: 'num', e: 'Flotar (m)', def: 0, paso: 0.05, min: 0, si: (v) => v.modelo, ayuda: 'Sube y baja. 0 = quieto' },
    { k: 'ritmo', t: 'num', e: 'Cuadros por segundo', def: 0, paso: 1, min: 0, si: (v) => v.modelo && (v.girar || v.flotar),
      ayuda: '0 = fluido · 8-12 = entrecortado como en PS1' },
    { grupo: 'Cartel de carga' },
    { k: 'cartel', t: 'bool', e: 'Mostrar cartel', def: false, ayuda: 'Pantalla negra con el nombre del nivel (como "Capítulo 2")' },
    { k: 'cartelTitulo', t: 'texto', e: 'Título', def: '', si: (v) => v.cartel, ayuda: 'Vacío = el nombre del nivel al que vas' },
    { k: 'cartelTexto', t: 'textoLargo', e: 'Texto', def: '', filas: 2, si: (v) => v.cartel },
    { k: 'cartelImagen', t: 'asset', e: 'Imagen de fondo', def: '', tipoAsset: 'textura', vacio: '(negro)', si: (v) => v.cartel },
    { k: 'cartelTiempo', t: 'num', e: 'Se ve al menos (s)', def: 1.5, paso: 0.5, min: 0, si: (v) => v.cartel },
    { grupo: 'Al cruzar (capítulo nuevo)', av: true },
    { k: 'llenarVida', t: 'bool', e: 'Llenar la vida', def: false },
    { k: 'quitarArmadura', t: 'bool', e: 'Quitar la armadura', def: false },
    { k: 'inventarioInicial', t: 'bool', e: 'Armas como al empezar', def: false, ayuda: 'Armas y munición vuelven a ser las del principio del juego' },
    { k: 'olvidarNiveles', t: 'bool', e: 'Olvidar los niveles', def: false, ayuda: 'Todos los niveles vuelven a estar como nuevos (enemigos, recogibles, cosas rotas)' },
  ];

  // qué figura del motor lleva una salida sin modelo
  function figuraDe(s) {
    const f = s.figura || 'auto';
    return f === 'auto' ? (s.activar === 'usar' ? 'puerta' : 'portal') : f;
  }
  // ¿la puerta o el modelo de la salida es sólido? (v0.15.1 guardaba modeloChoca: true = sólido)
  function chocaDe(s) {
    if (!s || !(s.modelo || figuraDe(s) === 'puerta')) return false;
    if (s.choca === 'si') return true;
    if (s.choca === 'no') return false;
    if (s.modeloChoca === true) return true;
    return s.activar === 'usar';
  }
  const copiar = (o) => (o == null ? o : JSON.parse(JSON.stringify(o)));
  const esperar = (s) => new Promise((ok) => setTimeout(ok, Math.max(0, s * 1000)));
  const cuadro = () => new Promise((ok) => requestAnimationFrame(() => ok()));

  /* ---------- Inicios de una escena ---------- */
  function inicios(escena) {
    return (escena && escena.entidades || []).filter((e) => e.tipo === 'inicio');
  }
  // El ⚑ donde aparece el jugador: la llegada pedida, si no el principal, si no el primero
  function inicioDe(escena, llegada) {
    const lista = inicios(escena);
    return (llegada && lista.find((e) => e.id === llegada)) || lista.find((e) => e.inicio && e.inicio.principal) || lista[0] || null;
  }

  /* =========================================================
     SALIDAS DE UNA ESCENA EN JUEGO (juego.salidas)
     ========================================================= */
  class Salidas {
    constructor(juego) {
      this.juego = juego;
      this.lista = [];
      this.usada = false;     // una salida ya se activó (esperando el viaje)
      this._p = new T.Vector3();
      for (const ent of juego.escena.entidades) {
        if (ent.tipo !== 'salida') continue;
        const obj = juego.objetos.get(ent.id);
        if (!obj) continue;
        obj.updateWorldMatrix(true, false);
        const it = { ent, obj, inv: obj.matrixWorld.clone().invert(), armada: false, s: { ...SALIDA, ...(ent.salida || {}) }, t: 0, acum: 0 };
        // modelo con animaciones del GLB: un mezclador propio (reposo en bucle, "usar" una vez)
        const m = obj.userData.modeloSalida;
        const clips = (m && m.userData.animaciones) || [];
        if (clips.length && (it.s.animReposo || it.s.animUsar)) {
          it.mixer = new T.AnimationMixer(m);
          const clip = (n) => n && clips.find((c) => c.name === n);
          if (clip(it.s.animReposo)) { it.reposo = it.mixer.clipAction(clip(it.s.animReposo)); it.reposo.play(); }
          if (clip(it.s.animUsar)) {
            it.usar = it.mixer.clipAction(clip(it.s.animUsar));
            it.usar.setLoop(T.LoopOnce, 1);
            it.usar.clampWhenFinished = true;
          }
        }
        it.giro = obj.userData.giroSalida || null;
        it.puerta = obj.userData.puertaMotor || null;   // figura del motor: hoja que se abre / velo del portal
        it.abriendo = 0;
        this.lista.push(it);
      }
      this.reiniciarArmado();
    }

    // Girar / flotar (con "cuadros por segundo" retro) y animaciones del GLB. Sigue durante el viaje (fundido)
    animar(dt) {
      for (const it of this.lista) {
        if (it.mixer) it.mixer.update(dt);
        const pm = it.puerta;
        if (pm) {
          if (pm.bisagra && it.abriendo > 0) {
            it.abriendo += dt;
            const k = Math.min(1, it.abriendo / 0.5);
            pm.bisagra.rotation.y = -1.45 * (1 - (1 - k) * (1 - k));   // se abre hacia dentro (lejos del frente)
          }
          if (pm.velo) { it.t += dt; pm.velo.material.opacity = 0.42 + Math.sin(it.t * 3) * 0.14; }
        }
        if (!it.giro || !(it.s.girar || it.s.flotar)) continue;
        it.t += dt;
        it.acum += dt;
        const paso = it.s.ritmo > 0 ? 1 / it.s.ritmo : 0;
        if (it.acum < paso) continue;
        it.acum = 0;
        if (it.s.girar) it.giro.rotation.y = (it.t * it.s.girar * Math.PI * 2) % (Math.PI * 2);
        if (it.s.flotar) it.giro.position.y = (Math.sin(it.t * 2.2) * 0.5 + 0.5) * it.s.flotar;
      }
    }

    // Animación "al usarla": devuelve cuántos segundos hay que esperar antes del fundido
    abrir(ent) {
      const it = this.lista.find((x) => x.ent === ent);
      if (it && !it.usar && it.puerta && it.puerta.bisagra) { it.abriendo = 1e-4; return it.s.esperarAnim === false ? 0 : 0.45; }
      if (!it || !it.usar) return 0;
      if (it.reposo) it.reposo.fadeOut(0.15);
      it.usar.reset().fadeIn(0.1).play();
      return it.s.esperarAnim ? it.usar.getClip().duration / Math.max(0.01, it.usar.timeScale) : 0;
    }

    // Al detener el juego (editor): el modelo vuelve a su pose
    detener() {
      for (const it of this.lista) {
        if (it.mixer) { it.mixer.stopAllAction(); it.obj.traverse((o) => { if (o.isSkinnedMesh) o.skeleton.pose(); }); }
        if (it.giro) { it.giro.rotation.y = 0; it.giro.position.y = 0; }
        if (it.puerta && it.puerta.bisagra) it.puerta.bisagra.rotation.y = 0;
        it.abriendo = 0;
      }
    }

    // ¿El jugador está dentro de la caja de esta salida? (caja de 1×1×1 sobre el suelo, escalada por la entidad)
    _dentro(it) {
      const c = this.juego.jugador.cuerpo;
      const p = this._p.set(c.pie.x, c.pie.y + 0.3, c.pie.z).applyMatrix4(it.inv);
      return Math.abs(p.x) <= 0.5 && Math.abs(p.z) <= 0.5 && p.y >= -0.25 && p.y <= 1;
    }

    // Las salidas en las que ya estás (acabas de llegar) no se disparan hasta que sales
    reiniciarArmado() {
      if (!this.juego.jugador) return;
      for (const it of this.lista) it.armada = !this._dentro(it);
      this.usada = false;
    }

    actualizar() {
      if (this.usada || !this.lista.length) return;
      const j = this.juego.jugador;
      if (!j || j.muerto) return;
      for (const it of this.lista) {
        if (it.s.activar !== 'tocar') continue;
        if (this._dentro(it)) { if (it.armada) { this.activar(it.ent); return; } }
        else it.armada = true;
      }
    }

    // Lo llaman la caja (tocar) y el módulo Interactuar (usar)
    activar(ent) {
      if (this.usada) return false;
      this.usada = true;
      F.emitir('salida', { juego: this.juego, ent });
      return true;
    }

    // Si el viaje no se pudo hacer: hay que salir de la caja para volver a intentarlo
    liberar() {
      this.usada = false;
      for (const it of this.lista) if (this._dentro(it)) it.armada = false;
    }
  }

  /* =========================================================
     EL GESTOR (uno por partida)
     ========================================================= */
  const CSS = `
  .fn-viaje { position: absolute; inset: 0; z-index: 28; background: #000; opacity: 0; pointer-events: none;
    display: flex; align-items: center; justify-content: center; transition-property: opacity; transition-timing-function: linear; }
  .fn-viaje.fn-tapa { pointer-events: auto; }
  .fn-cartel { position: absolute; inset: 0; display: none; flex-direction: column; align-items: center; justify-content: center; text-align: center;
    background-size: cover; background-position: center; image-rendering: pixelated; color: var(--fn-texto, #e8e2d0);
    font-family: var(--fn-fuente, ui-monospace, Consolas, monospace); padding: 8%; box-sizing: border-box; }
  .fn-cartel.fn-ver { display: flex; animation: fn-aparecer .35s ease-out; }
  .fn-cartel h1 { margin: 0; font-size: calc(min(9vmin, 64px)); letter-spacing: .08em; text-shadow: .08em .08em 0 #000;
    text-transform: var(--fn-mayus, uppercase); font-weight: normal; }
  .fn-cartel p { margin: .8em 0 0; font-size: calc(min(3.6vmin, 22px)); opacity: .9; white-space: pre-wrap; text-shadow: .1em .1em 0 #000; }
  .fn-cartel .fn-raya { width: 30%; height: 2px; background: var(--fn-sel, #e8a33d); margin: .6em 0 0; }
  @keyframes fn-aparecer { from { opacity: 0; } to { opacity: 1; } }
  `;
  function asegurarCss() {
    if (document.getElementById('estilos-forja-niveles')) return;
    const st = document.createElement('style');
    st.id = 'estilos-forja-niveles';
    st.textContent = CSS;
    document.head.appendChild(st);
  }

  class Niveles {
    constructor() {
      this.memoria = {};      // { idEscena: { rotos, recogidos, enemigosMuertos, mecanismos } }
      this.entrada = null;    // cómo entraste al nivel actual (para "Reiniciar nivel" / "Reintentar")
      this.viajando = false;
      this.capa = null;
    }

    /* ---------- Memoria de los niveles ---------- */
    static recuerda(escena) {
      return ((escena && escena.nivel) || NIVEL).memoria !== 'reiniciar';
    }

    // Guarda cómo quedó el nivel que dejas (si ese nivel recuerda)
    recordar(juego) {
      if (!Niveles.recuerda(juego.escena)) { delete this.memoria[juego.escena.id]; return; }
      const est = juego.estado();
      this.memoria[juego.escena.id] = { rotos: est.rotos || [], recogidos: est.recogidos || [], enemigosMuertos: est.enemigosMuertos || [], mecanismos: est.mecanismos || {}, oleadas: est.oleadas || {} };
    }

    // Lo que recibe Juego.iniciar para entrar a una escena: llegada + estado del jugador + memoria del nivel
    inicioPara(idEscena, llegada = '', jugador = null, escena = null) {
      const m = (!escena || Niveles.recuerda(escena)) ? this.memoria[idEscena] : null;
      const ini = { llegada: llegada || '' };
      if (jugador) ini.jugador = copiar(jugador);
      if (m) Object.assign(ini, copiar(m));
      return ini;
    }

    // Foto de la entrada al nivel: "Reiniciar nivel" vuelve aquí (con lo que traías, no al principio del juego)
    marcarEntrada(idEscena, inicio) {
      const { pos, yaw, pitch, tiempo, nombreEscena, niveles, escena, ...resto } = inicio || {};
      this.entrada = { escena: idEscena, inicio: copiar(resto) };
    }

    // Para "Reiniciar nivel": la escena y el inicio con los que se entró (la memoria del nivel vuelve a ese momento)
    reinicio(idEscenaActual) {
      if (!this.entrada || this.entrada.escena !== idEscenaActual) return { escena: idEscenaActual, inicio: { llegada: '' } };
      const ini = copiar(this.entrada.inicio);
      if (ini.rotos || ini.recogidos || ini.enemigosMuertos) {
        this.memoria[idEscenaActual] = { rotos: ini.rotos || [], recogidos: ini.recogidos || [], enemigosMuertos: ini.enemigosMuertos || [], mecanismos: ini.mecanismos || {}, oleadas: ini.oleadas || {} };
      } else {
        delete this.memoria[idEscenaActual];
      }
      return { escena: idEscenaActual, inicio: ini };
    }

    olvidar() {
      this.memoria = {};
      this.entrada = null;
    }

    // En la ranura de guardado
    serializar() {
      return copiar({ memoria: this.memoria, entrada: this.entrada });
    }

    // Al cargar una partida. Las de antes de la v0.15 no traen niveles: la entrada es el punto guardado
    cargar(datos) {
      const n = (datos && datos.niveles) || {};
      this.memoria = copiar(n.memoria) || {};
      this.entrada = copiar(n.entrada) || null;
      if (!this.entrada && datos && datos.escena) {
        this.marcarEntrada(datos.escena, { llegada: '', jugador: datos.jugador, rotos: datos.rotos, recogidos: datos.recogidos, enemigosMuertos: datos.enemigosMuertos, mecanismos: datos.mecanismos, oleadas: datos.oleadas });
      }
    }

    // Reinicios de la salida sobre el estado del jugador (sin datos = el módulo pone lo de serie al empezar)
    aplicarReinicios(s, pj) {
      if (!pj) return pj;
      if (s.llenarVida) delete pj.vida;
      if (s.quitarArmadura) pj.armadura = 0;
      if (s.inventarioInicial) { delete pj.armas; delete pj.armaActual; delete pj.municion; }
      if (s.olvidarNiveles) this.memoria = {};
      return pj;
    }

    /* ---------- Fundido y cartel ---------- */
    _capa(juego) {
      asegurarCss();
      const cont = juego.vista.contenedor;
      if (this.capa && this.capa.parentNode === cont) return this.capa;
      if (this.capa) this.capa.remove();
      if (getComputedStyle(cont).position === 'static') cont.style.position = 'relative';
      const c = document.createElement('div');
      c.className = 'fn-viaje';
      c.innerHTML = '<div class="fn-cartel"><h1></h1><div class="fn-raya"></div><p></p></div>';
      cont.appendChild(c);
      this.capa = c;
      return c;
    }

    /* 🎞 Tapar (a = 1) o destapar (a = 0) con la transición de la salida. 'negro' = la capa de siempre (fundido CSS);
       las demás las dibuja el pase de efectos y la capa se pone de golpe debajo (para el cartel y la carga) */
    async _tapar(juego, capa, s, a) {
      const tipo = s.transicion || 'negro';
      if (tipo === 'negro' || !F.Efectos || !juego.vista) return this._fundir(capa, a, s.fundido);
      capa.style.background = tipo === 'blanco' ? '#fff' : '#000';
      if (a) {
        await F.Efectos.transicion(juego.vista, { tipo, a: 1, segundos: s.fundido });
        await this._fundir(capa, 1, 0);
      } else {
        await this._fundir(capa, 0, 0);
        await F.Efectos.transicion(juego.vista, { tipo, a: 0, segundos: s.fundido });
      }
      capa.style.background = '';
    }

    _fundir(capa, opacidad, segundos) {
      capa.style.transitionDuration = Math.max(0, segundos) + 's';
      // forzar el estilo actual para que la transición arranque desde ahí
      void capa.offsetWidth;
      capa.style.opacity = opacidad;
      capa.classList.toggle('fn-tapa', opacidad > 0);
      return esperar(segundos);
    }

    _cartel(capa, s, destino, proyecto) {
      const el = capa.querySelector('.fn-cartel');
      if (!s.cartel) { el.classList.remove('fn-ver'); return; }
      const t = (proyecto.menus && proyecto.menus.tema) || {};
      const fuente = t.fuente && F.Assets && F.Assets.mapa.get(t.fuente);
      el.style.setProperty('--fn-fuente', (fuente && fuente.familia ? `'${fuente.familia}', ` : '') + 'ui-monospace, Consolas, monospace');
      el.style.setProperty('--fn-texto', t.colorTexto || '#e8e2d0');
      el.style.setProperty('--fn-sel', t.colorSel || '#e8a33d');
      el.style.setProperty('--fn-mayus', t.mayusculas === false ? 'none' : 'uppercase');
      const img = s.cartelImagen && F.Assets && F.Assets.mapa.get(s.cartelImagen);
      el.style.backgroundImage = img && img.url ? `url("${img.url}")` : '';
      el.querySelector('h1').textContent = s.cartelTitulo || destino.nombre;
      const p = el.querySelector('p');
      p.textContent = s.cartelTexto || '';
      p.style.display = s.cartelTexto ? '' : 'none';
      el.classList.add('fn-ver');
    }

    quitarCapa() {
      if (this.capa) this.capa.remove();
      this.capa = null;
    }

    /* ---------- El viaje ----------
       cambiar(idEscena, inicio) → el Juego nuevo ya iniciado (o null si se canceló: volvieron al menú, detuvieron…).
       Devuelve true si se llegó. */
    async viajar({ juego, ent, cambiar }) {
      const proyecto = juego.proyecto;
      const s = { ...SALIDA, ...(ent.salida || {}) };
      // 🏆 salida "Fin del juego": puntuación de la misión y pantalla de victoria
      if (s.destino === '__fin__') {
        if (this.viajando) return false;
        this.viajando = true;
        juego.jugador.sinControl = true;
        if (s.sonido) F.Audio.efecto(s.sonido);
        if (juego.misiones && juego.misiones.activa) await juego.misiones.final(ent);
        this.viajando = false;
        F.emitir('partida-fin', juego);
        return false;
      }
      const destino = proyecto.escenas.find((e) => e.id === s.destino);
      if (!destino) {
        F.aviso(`🚪 La salida <b>${ent.nombre}</b> no lleva a ningún nivel (elige su destino en el Inspector)`);
        juego.salidas.liberar();
        return false;
      }
      if (this.viajando) return false;
      this.viajando = true;
      const capa = this._capa(juego);
      if (s.sonido) F.Audio.efecto(s.sonido);
      juego.jugador.sinControl = true;
      // ⭐ misión: pantalla de puntuación antes de irse (a otro nivel)
      if (juego.misiones && juego.misiones.activa && destino.id !== juego.escena.id) {
        await juego.misiones.final(ent);
        // 🗺 juego por misiones: al acabar una se vuelve al menú de misiones (no al nivel siguiente)
        const mm = proyecto.menus && proyecto.menus.misiones;
        if (mm && mm.alTerminar === 'menu' && (proyecto.menus.principal.botones || []).some((b) => b.accion === 'misiones')) {
          this.viajando = false;
          F.emitir('partida-misiones', juego);
          return false;
        }
      }
      F.emitir('nivel-saliendo', { juego, ent, destino });

      // la puerta se abre (animación del modelo) y luego el fundido; el modelo se sigue animando en negro
      let animando = true;
      const anim = async () => {
        let antes = performance.now();
        while (animando) {
          await cuadro();
          const ahora = performance.now();
          juego.salidas.animar(Math.min(0.05, (ahora - antes) / 1000));
          antes = ahora;
        }
      };
      anim();
      const espera = juego.salidas.abrir(ent);
      if (espera > 0) await esperar(espera);
      await this._tapar(juego, capa, s, 1);
      animando = false;
      const t0 = performance.now();
      this._cartel(capa, s, destino, proyecto);

      // Misma escena: teletransporte (no se recarga nada)
      if (destino.id === juego.escena.id) {
        juego.irALlegada(s.llegada);
        juego.jugador.sinControl = false;
        if (s.cartel) await esperar(s.cartelTiempo - (performance.now() - t0) / 1000);
        juego.salidas.reiniciarArmado();
        this.viajando = false;
        capa.querySelector('.fn-cartel').classList.remove('fn-ver');
        await this._tapar(juego, capa, s, 0);
        return true;
      }

      // Lo que te llevas y cómo queda el nivel que dejas
      const pj = this.aplicarReinicios(s, copiar(juego.estado().jugador || {}));
      this.recordar(juego);
      if (s.olvidarNiveles) this.memoria = {};
      await cuadro();   // que el cartel se pinte antes del trabajo pesado

      const inicio = this.inicioPara(destino.id, s.llegada, pj, destino);
      let nuevo = null;
      try {
        nuevo = cambiar(destino.id, inicio);
      } catch (err) {
        console.error(err);
        F.aviso('No se pudo cargar el nivel: ' + err.message);
      }
      if (!nuevo) {
        // cancelado (menú principal, Detener…) o error
        this.viajando = false;
        this.quitarCapa();
        return false;
      }
      this.marcarEntrada(destino.id, inicio);
      // en negro: compilar los shaders del nivel nuevo y dibujar un cuadro (que al aparecer no haya tirón)
      try { nuevo.vista.renderer.compile(nuevo.vista.escena, nuevo.camara); } catch (err) { /* no es grave */ }
      nuevo.vista.render(nuevo.camara);
      if (s.cartel) await esperar(s.cartelTiempo - (performance.now() - t0) / 1000);
      F.emitir('nivel-llegada', { juego: nuevo, escena: destino });
      this.viajando = false;
      capa.querySelector('.fn-cartel').classList.remove('fn-ver');
      await this._tapar(nuevo, capa, s, 0);
      return true;
    }

    // Fundido de entrada al empezar o cargar (sin salida de por medio)
    async aparecer(juego, segundos = 0.4) {
      const capa = this._capa(juego);
      capa.querySelector('.fn-cartel').classList.remove('fn-ver');
      await this._fundir(capa, 1, 0);
      await cuadro();
      await this._fundir(capa, 0, segundos);
    }
  }

  /* ---------- Ayuda del editor para la salida: la caja (no se ve al jugar) ---------- */
  function figura(ent) {
    const s = { ...SALIDA, ...(ent.salida || {}) };
    const color = s.activar === 'usar' ? 0xffb34a : 0x38c8ff;
    const g = new T.Group();
    const geo = new T.BoxGeometry(1, 1, 1);
    geo.translate(0, 0.5, 0);
    const relleno = new T.Mesh(geo, new T.MeshBasicMaterial({ color, transparent: true, opacity: 0.18, depthWrite: false, fog: false }));
    const bordes = new T.LineSegments(new T.EdgesGeometry(geo), new T.LineBasicMaterial({ color, fog: false }));
    // flecha en el suelo hacia el frente (−Z): por dónde se "entra"
    const flecha = new T.Mesh(new T.ConeGeometry(0.12, 0.3, 4), new T.MeshBasicMaterial({ color, fog: false }));
    flecha.rotation.x = -Math.PI / 2;
    flecha.position.set(0, 0.05, -0.5);
    for (const o of [relleno, bordes, flecha]) { o.userData.ayudaEditor = true; g.add(o); }
    relleno.userData.cajaSalida = true;
    const a = s.modelo && F.Assets && F.Assets.mapa.get(s.modelo);
    if (a && a.gltf) {
      // soporte: deshace la escala de la caja (así el modelo no se estira al agrandarla) · modelo: su escala, giro y ajuste
      const soporte = new T.Group();
      const ajuste = new T.Vector3(s.modeloX, s.modeloY, s.modeloZ);
      soporte.updateMatrixWorld = function (force) {
        const e = this.parent ? this.parent.scale : null;
        if (e && e.x && e.y && e.z) {
          this.scale.set(1 / e.x, 1 / e.y, 1 / e.z);
          this.position.set(ajuste.x / e.x, ajuste.y / e.y, ajuste.z / e.z);
        }
        T.Object3D.prototype.updateMatrixWorld.call(this, force);
      };
      const giro = new T.Group();          // lo que gira y flota (girar / flotar)
      const modelo = T.SkeletonUtils.clone(a.gltf.scene);
      modelo.scale.setScalar(s.modeloEscala || 1);
      modelo.rotation.y = (s.modeloGiro || 0) * F.DEG;
      modelo.userData.animaciones = a.gltf.animations || [];
      giro.add(modelo);
      soporte.add(giro);
      g.add(soporte);
      F.Luces.aplicarSombras(soporte, true);
      g.userData.modeloSalida = modelo;
      g.userData.giroSalida = giro;
    } else {
      figuraMotor(s, g, ent.esc || [1, 1, 1]);
    }
    return g;
  }

  /* Figura del motor (sin modelo): puerta con marco, hoja y tirador, o portal con marco y velo de luz.
     Se arma en METROS dentro de un soporte que deshace la escala de la caja: así la hoja gira sin deformarse
     y todo se reajusta solo si agrandas la caja con Escalar. */
  function figuraMotor(s, g, esc) {
    const tipo = figuraDe(s);
    if (tipo === 'ninguna') return;
    const retro = (c) => F.Render.matRetro(c);
    const cubo = new T.BoxGeometry(1, 1, 1);
    cubo.translate(0, 0.5, 0);
    const marco = retro(s.colorMarco || '#4a3a2c');
    const izq = new T.Mesh(cubo, marco), der = new T.Mesh(cubo, marco), arriba = new T.Mesh(cubo, marco);
    const soporte = new T.Group();
    soporte.add(izq, der, arriba);
    const pm = {};
    if (tipo === 'puerta') {
      const hojaGeo = new T.BoxGeometry(1, 1, 1);
      hojaGeo.translate(0.5, 0.5, 0);                    // gira desde su canto izquierdo (la bisagra)
      const bisagra = new T.Group();
      const hoja = new T.Mesh(hojaGeo, retro(s.colorPuerta || '#7a5636'));
      const tirador = new T.Mesh(new T.BoxGeometry(0.06, 0.06, 0.12), retro('#d8c070'));
      bisagra.add(hoja, tirador);
      soporte.add(bisagra);
      Object.assign(pm, { bisagra, hoja, tirador });
    } else {
      const velo = new T.Mesh(new T.PlaneGeometry(1, 1).translate(0, 0.5, 0), new T.MeshBasicMaterial({
        color: s.colorPortal || '#38c8ff', transparent: true, opacity: 0.45, blending: T.AdditiveBlending, depthWrite: false, side: T.DoubleSide,
      }));
      soporte.add(velo);
      pm.velo = velo;
    }
    // reparte las piezas para una caja de ancho W, alto H y fondo D (metros)
    let ultimo = '';
    const colocar = (W, H, D) => {
      const clave = W.toFixed(3) + H.toFixed(3) + D.toFixed(3);
      if (clave === ultimo) return;
      ultimo = clave;
      const grosor = Math.min(0.14, W * 0.1), fondo = Math.min(0.3, D);
      izq.scale.set(grosor, H, fondo); izq.position.set(-W / 2 + grosor / 2, 0, 0);
      der.scale.set(grosor, H, fondo); der.position.set(W / 2 - grosor / 2, 0, 0);
      arriba.scale.set(W, grosor, fondo); arriba.position.set(0, H - grosor, 0);
      const hueco = Math.max(0.05, W - grosor * 2), alto = Math.max(0.05, H - grosor);
      if (pm.bisagra) {
        pm.bisagra.position.set(-W / 2 + grosor, 0, 0);
        pm.hoja.scale.set(hueco, alto, 0.06);
        pm.tirador.position.set(hueco * 0.86, alto * 0.47, -0.06);
      }
      if (pm.velo) pm.velo.scale.set(hueco, alto, 1);
    };
    soporte.updateMatrixWorld = function (force) {
      const e = this.parent ? this.parent.scale : null;
      if (e && e.x && e.y && e.z) { this.scale.set(1 / e.x, 1 / e.y, 1 / e.z); colocar(e.x, e.y, e.z); }
      T.Object3D.prototype.updateMatrixWorld.call(this, force);
    };
    soporte.scale.set(1 / esc[0], 1 / esc[1], 1 / esc[2]);
    colocar(esc[0], esc[1], esc[2]);
    g.add(soporte);
    F.Luces.aplicarSombras(soporte, true);
    g.userData.puertaMotor = pm;
    if (tipo === 'puerta') g.userData.modeloSalida = soporte;   // "Choca" usa sus mallas (fisica.triangulosDe)
  }

  Niveles.SALIDA = SALIDA;
  Niveles.NIVEL = NIVEL;
  Niveles.ESQUEMA_NIVEL = ESQUEMA_NIVEL;
  Niveles.ESQUEMA_SALIDA = ESQUEMA_SALIDA;
  Niveles.Salidas = Salidas;
  Niveles.figura = figura;
  Niveles.figuraDe = figuraDe;
  Niveles.chocaDe = chocaDe;
  Niveles.inicios = inicios;
  Niveles.inicioDe = inicioDe;
  F.Niveles = Niveles;
})(window.FORJA);
