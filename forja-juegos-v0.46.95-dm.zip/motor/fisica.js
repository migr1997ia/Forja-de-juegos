/* =========================================================
   FORJA · FÍSICA
   - BVH de triángulos: el mundo estático en un solo árbol (como un trimesh de Godot).
   - CuerpoCinematico: equivalente a CharacterBody3D con moverYDeslizar() ≈ move_and_slide().
   ========================================================= */
(function (F) {
  'use strict';
  const T = THREE;
  const clamp = F.util.clamp;

  /* =========================================================
     BVH
     ========================================================= */
  class BVH {
    constructor(tri) {
      const n = tri.length / 9;
      this.n = n;
      const HOJA = 6;
      const cen = new Float32Array(n * 3), tmin = new Float32Array(n * 3), tmax = new Float32Array(n * 3);
      for (let i = 0; i < n; i++) {
        for (let e = 0; e < 3; e++) {
          const a = tri[i * 9 + e], b = tri[i * 9 + 3 + e], c = tri[i * 9 + 6 + e];
          tmin[i * 3 + e] = Math.min(a, b, c);
          tmax[i * 3 + e] = Math.max(a, b, c);
          cen[i * 3 + e] = (a + b + c) / 3;
        }
      }
      const idx = new Uint32Array(n);
      for (let i = 0; i < n; i++) idx[i] = i;
      const cajas = [], derecho = [], inicio = [], cuenta = [];

      const construir = (ini, fin) => {
        const id = cuenta.length;
        cajas.push(0, 0, 0, 0, 0, 0);
        derecho.push(-1);
        inicio.push(ini);
        cuenta.push(fin - ini);
        let x0 = Infinity, y0 = Infinity, z0 = Infinity, x1 = -Infinity, y1 = -Infinity, z1 = -Infinity;
        let cx0 = Infinity, cy0 = Infinity, cz0 = Infinity, cx1 = -Infinity, cy1 = -Infinity, cz1 = -Infinity;
        for (let k = ini; k < fin; k++) {
          const t = idx[k] * 3;
          if (tmin[t] < x0) x0 = tmin[t];
          if (tmin[t + 1] < y0) y0 = tmin[t + 1];
          if (tmin[t + 2] < z0) z0 = tmin[t + 2];
          if (tmax[t] > x1) x1 = tmax[t];
          if (tmax[t + 1] > y1) y1 = tmax[t + 1];
          if (tmax[t + 2] > z1) z1 = tmax[t + 2];
          if (cen[t] < cx0) cx0 = cen[t];
          if (cen[t + 1] < cy0) cy0 = cen[t + 1];
          if (cen[t + 2] < cz0) cz0 = cen[t + 2];
          if (cen[t] > cx1) cx1 = cen[t];
          if (cen[t + 1] > cy1) cy1 = cen[t + 1];
          if (cen[t + 2] > cz1) cz1 = cen[t + 2];
        }
        const o = id * 6;
        cajas[o] = x0; cajas[o + 1] = y0; cajas[o + 2] = z0;
        cajas[o + 3] = x1; cajas[o + 4] = y1; cajas[o + 5] = z1;
        if (fin - ini <= HOJA) return id;
        const ex = cx1 - cx0, ey = cy1 - cy0, ez = cz1 - cz0;
        const eje = ex >= ey && ex >= ez ? 0 : ey >= ez ? 1 : 2;
        const ext = [ex, ey, ez][eje];
        if (ext < 1e-6) return id;
        const medio = [cx0, cy0, cz0][eje] + ext / 2;
        let i = ini, j = fin - 1;
        while (i <= j) {
          if (cen[idx[i] * 3 + eje] < medio) i++;
          else { const t = idx[i]; idx[i] = idx[j]; idx[j] = t; j--; }
        }
        let m = i;
        if (m === ini || m === fin) {
          const sub = Array.from(idx.subarray(ini, fin)).sort((a, b) => cen[a * 3 + eje] - cen[b * 3 + eje]);
          idx.set(sub, ini);
          m = (ini + fin) >> 1;
        }
        cuenta[id] = 0;
        construir(ini, m);              // hijo izquierdo = id + 1
        derecho[id] = construir(m, fin);
        return id;
      };
      if (n > 0) construir(0, n);

      this.cajas = new Float32Array(cajas);
      this.derecho = new Int32Array(derecho);
      this.inicio = new Int32Array(inicio);
      this.cuenta = new Int32Array(cuenta);
      // Triángulos reordenados (cada hoja contigua) y su normal
      this.t = new Float32Array(n * 9);
      this.nor = new Float32Array(n * 3);
      for (let k = 0; k < n; k++) {
        const s = idx[k] * 9;
        for (let e = 0; e < 9; e++) this.t[k * 9 + e] = tri[s + e];
        const t = this.t, o = k * 9;
        const ux = t[o + 3] - t[o], uy = t[o + 4] - t[o + 1], uz = t[o + 5] - t[o + 2];
        const vx = t[o + 6] - t[o], vy = t[o + 7] - t[o + 1], vz = t[o + 8] - t[o + 2];
        let nx = uy * vz - uz * vy, ny = uz * vx - ux * vz, nz = ux * vy - uy * vx;
        const l = Math.hypot(nx, ny, nz);
        if (l > 1e-12) { nx /= l; ny /= l; nz /= l; } else { nx = ny = nz = 0; }
        this.nor[k * 3] = nx;
        this.nor[k * 3 + 1] = ny;
        this.nor[k * 3 + 2] = nz;
      }
      this.pila = new Int32Array(256);
      this.encontrados = new Int32Array(1024);
      this.golpe = { t: 0, k: -1 };
    }

    // Triángulos que tocan la caja → cuántos; índices en this.encontrados
    recoger(x0, y0, z0, x1, y1, z1) {
      const b = this.cajas, pila = this.pila;
      let sp = 0, total = 0;
      if (this.n) pila[sp++] = 0;
      while (sp > 0) {
        const id = pila[--sp], o = id * 6;
        if (b[o] > x1 || b[o + 3] < x0 || b[o + 1] > y1 || b[o + 4] < y0 || b[o + 2] > z1 || b[o + 5] < z0) continue;
        const c = this.cuenta[id];
        if (c > 0) {
          const s = this.inicio[id];
          for (let k = s; k < s + c; k++) {
            if (total >= this.encontrados.length) {
              const mas = new Int32Array(this.encontrados.length * 2);
              mas.set(this.encontrados);
              this.encontrados = mas;
            }
            this.encontrados[total++] = k;
          }
        } else if (sp < pila.length - 2) {
          pila[sp++] = id + 1;
          pila[sp++] = this.derecho[id];
        }
      }
      // piezas que se mueven (puertas, plataformas): fuera del árbol, se miran todas (son pocas)
      if (this.moviles) for (const m of this.moviles) {
        const c = m.caja;
        if (!m.activa || c[0] > x1 || c[3] < x0 || c[1] > y1 || c[4] < y0 || c[2] > z1 || c[5] < z0) continue;
        if (total + m.cuenta > this.encontrados.length) {
          const mas = new Int32Array((total + m.cuenta) * 2);
          mas.set(this.encontrados);
          this.encontrados = mas;
        }
        for (let k = m.ini; k < m.ini + m.cuenta; k++) this.encontrados[total++] = k;
      }
      return total;
    }

    // Rayo: devuelve { t, k } del golpe más cercano o null
    rayo(ox, oy, oz, dx, dy, dz, maxT) {
      if (!this.n && !this.moviles) return null;
      if (Math.abs(dx) < 1e-9) dx = 1e-9;
      if (Math.abs(dy) < 1e-9) dy = 1e-9;
      if (Math.abs(dz) < 1e-9) dz = 1e-9;
      const ix = 1 / dx, iy = 1 / dy, iz = 1 / dz;
      const b = this.cajas, T9 = this.t, pila = this.pila;
      let mejor = maxT, mk = -1, sp = 0;
      if (this.n) pila[sp++] = 0;
      while (sp > 0) {
        const id = pila[--sp], o = id * 6;
        let ta = (b[o] - ox) * ix, tb = (b[o + 3] - ox) * ix;
        let tmin = Math.min(ta, tb), tmax = Math.max(ta, tb);
        ta = (b[o + 1] - oy) * iy; tb = (b[o + 4] - oy) * iy;
        tmin = Math.max(tmin, Math.min(ta, tb)); tmax = Math.min(tmax, Math.max(ta, tb));
        ta = (b[o + 2] - oz) * iz; tb = (b[o + 5] - oz) * iz;
        tmin = Math.max(tmin, Math.min(ta, tb)); tmax = Math.min(tmax, Math.max(ta, tb));
        if (tmax < Math.max(tmin, 0) || tmin > mejor) continue;
        const c = this.cuenta[id];
        if (c > 0) {
          const s = this.inicio[id];
          for (let k = s; k < s + c; k++) {
            const q = k * 9;
            const e1x = T9[q + 3] - T9[q], e1y = T9[q + 4] - T9[q + 1], e1z = T9[q + 5] - T9[q + 2];
            const e2x = T9[q + 6] - T9[q], e2y = T9[q + 7] - T9[q + 1], e2z = T9[q + 8] - T9[q + 2];
            const px = dy * e2z - dz * e2y, py = dz * e2x - dx * e2z, pz = dx * e2y - dy * e2x;
            const det = e1x * px + e1y * py + e1z * pz;
            if (det > -1e-10 && det < 1e-10) continue;
            const inv = 1 / det;
            const sx = ox - T9[q], sy = oy - T9[q + 1], sz = oz - T9[q + 2];
            const u = (sx * px + sy * py + sz * pz) * inv;
            if (u < 0 || u > 1) continue;
            const qx = sy * e1z - sz * e1y, qy = sz * e1x - sx * e1z, qz = sx * e1y - sy * e1x;
            const v = (dx * qx + dy * qy + dz * qz) * inv;
            if (v < 0 || u + v > 1) continue;
            const t = (e2x * qx + e2y * qy + e2z * qz) * inv;
            if (t > 1e-6 && t < mejor) { mejor = t; mk = k; }
          }
        } else if (sp < pila.length - 2) {
          pila[sp++] = id + 1;
          pila[sp++] = this.derecho[id];
        }
      }
      if (this.moviles) for (const m of this.moviles) {
        if (!m.activa) continue;
        const c = m.caja;
        let ta = (c[0] - ox) * ix, tb = (c[3] - ox) * ix;
        let tmin = Math.min(ta, tb), tmax = Math.max(ta, tb);
        ta = (c[1] - oy) * iy; tb = (c[4] - oy) * iy;
        tmin = Math.max(tmin, Math.min(ta, tb)); tmax = Math.min(tmax, Math.max(ta, tb));
        ta = (c[2] - oz) * iz; tb = (c[5] - oz) * iz;
        tmin = Math.max(tmin, Math.min(ta, tb)); tmax = Math.min(tmax, Math.max(ta, tb));
        if (tmax < Math.max(tmin, 0) || tmin > mejor) continue;
        for (let k = m.ini; k < m.ini + m.cuenta; k++) {
          const t = this._rayoTri(k, ox, oy, oz, dx, dy, dz);
          if (t > 1e-6 && t < mejor) { mejor = t; mk = k; }
        }
      }
      if (mk < 0) return null;
      this.golpe.t = mejor;
      this.golpe.k = mk;
      return this.golpe;
    }

    normalY(k) {
      return this.nor[k * 3 + 1];
    }

    // distancia del rayo al triángulo k (Möller–Trumbore) o -1
    _rayoTri(k, ox, oy, oz, dx, dy, dz) {
      const T9 = this.t, q = k * 9;
      const e1x = T9[q + 3] - T9[q], e1y = T9[q + 4] - T9[q + 1], e1z = T9[q + 5] - T9[q + 2];
      const e2x = T9[q + 6] - T9[q], e2y = T9[q + 7] - T9[q + 1], e2z = T9[q + 8] - T9[q + 2];
      const px = dy * e2z - dz * e2y, py = dz * e2x - dx * e2z, pz = dx * e2y - dy * e2x;
      const det = e1x * px + e1y * py + e1z * pz;
      if (det > -1e-10 && det < 1e-10) return -1;
      const inv = 1 / det;
      const sx = ox - T9[q], sy = oy - T9[q + 1], sz = oz - T9[q + 2];
      const u = (sx * px + sy * py + sz * pz) * inv;
      if (u < 0 || u > 1) return -1;
      const qx = sy * e1z - sz * e1y, qy = sz * e1x - sx * e1z, qz = sx * e1y - sy * e1x;
      const v = (dx * qx + dy * qy + dz * qz) * inv;
      if (v < 0 || u + v > 1) return -1;
      return (e2x * qx + e2y * qy + e2z * qz) * inv;
    }

    /* ---------- Piezas móviles (motor/mecanismos.js) ----------
       piezas: [{ local: Float32Array (triángulos en el espacio de obj), obj: Object3D }]. Cada una ocupa su tramo
       al final de this.t; moverPieza() las pone donde está su objeto ahora (solo cuando se mueve). */
    reservarMoviles(piezas) {
      const total = piezas.reduce((s, p) => s + p.local.length / 9, 0);
      const t = new Float32Array((this.n + total) * 9), nor = new Float32Array((this.n + total) * 3);
      t.set(this.t.subarray(0, this.n * 9));
      nor.set(this.nor.subarray(0, this.n * 3));
      this.t = t; this.nor = nor;
      let ini = this.n;
      this.moviles = piezas.map((p) => {
        const m = { ini, cuenta: p.local.length / 9, local: p.local, obj: p.obj, caja: new Float32Array(6), activa: p.activa !== false };
        ini += m.cuenta;
        return m;
      });
      for (const m of this.moviles) this.moverPieza(m);
      return this.moviles;
    }

    moverPieza(m) {
      m.obj.updateWorldMatrix(true, false);
      const e = m.obj.matrixWorld.elements, L = m.local, T9 = this.t, N = this.nor, c = m.caja;
      c[0] = c[1] = c[2] = Infinity; c[3] = c[4] = c[5] = -Infinity;
      for (let i = 0; i < m.cuenta * 3; i++) {
        const x = L[i * 3], y = L[i * 3 + 1], z = L[i * 3 + 2], o = (m.ini * 3 + i) * 3;
        const wx = e[0] * x + e[4] * y + e[8] * z + e[12], wy = e[1] * x + e[5] * y + e[9] * z + e[13], wz = e[2] * x + e[6] * y + e[10] * z + e[14];
        T9[o] = wx; T9[o + 1] = wy; T9[o + 2] = wz;
        if (wx < c[0]) c[0] = wx; if (wy < c[1]) c[1] = wy; if (wz < c[2]) c[2] = wz;
        if (wx > c[3]) c[3] = wx; if (wy > c[4]) c[4] = wy; if (wz > c[5]) c[5] = wz;
      }
      for (let k = m.ini; k < m.ini + m.cuenta; k++) {
        const o = k * 9;
        const ux = T9[o + 3] - T9[o], uy = T9[o + 4] - T9[o + 1], uz = T9[o + 5] - T9[o + 2];
        const vx = T9[o + 6] - T9[o], vy = T9[o + 7] - T9[o + 1], vz = T9[o + 8] - T9[o + 2];
        let nx = uy * vz - uz * vy, ny = uz * vx - ux * vz, nz = ux * vy - uy * vx;
        const l = Math.hypot(nx, ny, nz);
        if (l > 1e-12) { nx /= l; ny /= l; nz /= l; } else { nx = ny = nz = 0; }
        N[k * 3] = nx; N[k * 3 + 1] = ny; N[k * 3 + 2] = nz;
      }
    }
  }

  // triángulos de las mallas de obj en SU espacio local (para una pieza móvil)
  function triangulosLocales(obj) {
    obj.updateMatrixWorld(true);
    const inv = obj.matrixWorld.clone().invert();
    const partes = triangulosDeMalla(obj);
    const total = partes.reduce((s, p) => s + p.length, 0);
    const out = new Float32Array(total);
    const v = new T.Vector3();
    let o = 0;
    for (const p of partes) for (let i = 0; i < p.length; i += 3) {
      v.set(p[i], p[i + 1], p[i + 2]).applyMatrix4(inv);
      out[o++] = v.x; out[o++] = v.y; out[o++] = v.z;
    }
    return out;
  }

  /* =========================================================
     Distancias (Ericson, Real-Time Collision Detection)
     ========================================================= */
  const _ab = new T.Vector3(), _ac = new T.Vector3(), _ap = new T.Vector3(), _bp = new T.Vector3();
  const _cp = new T.Vector3(), _bc = new T.Vector3();
  function puntoMasCercanoTriangulo(p, a, b, c, out) {
    _ab.subVectors(b, a); _ac.subVectors(c, a); _ap.subVectors(p, a);
    const d1 = _ab.dot(_ap), d2 = _ac.dot(_ap);
    if (d1 <= 0 && d2 <= 0) return out.copy(a);
    _bp.subVectors(p, b);
    const d3 = _ab.dot(_bp), d4 = _ac.dot(_bp);
    if (d3 >= 0 && d4 <= d3) return out.copy(b);
    const vc = d1 * d4 - d3 * d2;
    if (vc <= 0 && d1 >= 0 && d3 <= 0) return out.copy(a).addScaledVector(_ab, d1 / (d1 - d3));
    _cp.subVectors(p, c);
    const d5 = _ab.dot(_cp), d6 = _ac.dot(_cp);
    if (d6 >= 0 && d5 <= d6) return out.copy(c);
    const vb = d5 * d2 - d1 * d6;
    if (vb <= 0 && d2 >= 0 && d6 <= 0) return out.copy(a).addScaledVector(_ac, d2 / (d2 - d6));
    const va = d3 * d6 - d5 * d4;
    if (va <= 0 && d4 - d3 >= 0 && d5 - d6 >= 0) {
      _bc.subVectors(c, b);
      return out.copy(b).addScaledVector(_bc, (d4 - d3) / ((d4 - d3) + (d5 - d6)));
    }
    const den = 1 / (va + vb + vc);
    return out.copy(a).addScaledVector(_ab, vb * den).addScaledVector(_ac, vc * den);
  }

  const _d1 = new T.Vector3(), _d2 = new T.Vector3(), _r = new T.Vector3();
  function segmentoSegmento(p1, q1, p2, q2, c1, c2) {
    _d1.subVectors(q1, p1); _d2.subVectors(q2, p2); _r.subVectors(p1, p2);
    const a = _d1.dot(_d1), e = _d2.dot(_d2), f = _d2.dot(_r);
    let s, t;
    const EPS = 1e-10;
    if (a <= EPS && e <= EPS) { s = t = 0; }
    else if (a <= EPS) { s = 0; t = clamp(f / e, 0, 1); }
    else {
      const c = _d1.dot(_r);
      if (e <= EPS) { t = 0; s = clamp(-c / a, 0, 1); }
      else {
        const b = _d1.dot(_d2), den = a * e - b * b;
        s = den !== 0 ? clamp((b * f - c * e) / den, 0, 1) : 0;
        t = (b * s + f) / e;
        if (t < 0) { t = 0; s = clamp(-c / a, 0, 1); }
        else if (t > 1) { t = 1; s = clamp((b - c) / a, 0, 1); }
      }
    }
    c1.copy(p1).addScaledVector(_d1, s);
    c2.copy(p2).addScaledVector(_d2, t);
    return c1.distanceToSquared(c2);
  }

  const _x = new T.Vector3(), _t1 = new T.Vector3(), _s1 = new T.Vector3(), _s2 = new T.Vector3(), _tmp = new T.Vector3();
  function segmentoTriangulo(p, q, a, b, c, n, outS, outT) {
    const dp = n.dot(_tmp.subVectors(p, a)), dq = n.dot(_tmp.subVectors(q, a));
    if (((dp <= 0 && dq >= 0) || (dp >= 0 && dq <= 0)) && dp !== dq) {
      _x.copy(p).lerp(q, dp / (dp - dq));
      puntoMasCercanoTriangulo(_x, a, b, c, _t1);
      if (_x.distanceToSquared(_t1) < 1e-10) { outS.copy(_x); outT.copy(_t1); return 0; }
    }
    let mejor = Infinity, d;
    puntoMasCercanoTriangulo(p, a, b, c, _t1);
    d = p.distanceToSquared(_t1);
    if (d < mejor) { mejor = d; outS.copy(p); outT.copy(_t1); }
    puntoMasCercanoTriangulo(q, a, b, c, _t1);
    d = q.distanceToSquared(_t1);
    if (d < mejor) { mejor = d; outS.copy(q); outT.copy(_t1); }
    for (const [e0, e1] of [[a, b], [b, c], [c, a]]) {
      d = segmentoSegmento(p, q, e0, e1, _s1, _s2);
      if (d < mejor) { mejor = d; outS.copy(_s1); outT.copy(_s2); }
    }
    return mejor;
  }

  /* =========================================================
     Construir el mundo de colisión desde las entidades de la escena
     ========================================================= */
  // Recorre un objeto sin entrar en las entidades hijas (cada una aporta su propia colisión)
  function recorrerPropio(obj, fn) {
    fn(obj);
    for (const h of obj.children) if (!h.userData.entId) recorrerPropio(h, fn);
  }

  function triangulosDeCaja(obj) {
    obj.updateMatrixWorld(true);
    const inversa = obj.matrixWorld.clone().invert();
    const caja = new T.Box3();
    const m = new T.Matrix4();
    recorrerPropio(obj, (o) => {
      if (!o.isMesh || o.userData.ayudaEditor || o.userData.esAgua || /^deco_/i.test(o.name || '')) return;   // el agua de un modelo no es sólida
      if (!o.geometry.boundingBox) o.geometry.computeBoundingBox();
      caja.union(o.geometry.boundingBox.clone().applyMatrix4(m.multiplyMatrices(inversa, o.matrixWorld)));
    });
    if (caja.isEmpty()) return new Float32Array(0);
    const esq = [];
    for (let i = 0; i < 8; i++) {
      esq.push(new T.Vector3(i & 1 ? caja.max.x : caja.min.x, i & 2 ? caja.max.y : caja.min.y, i & 4 ? caja.max.z : caja.min.z)
        .applyMatrix4(obj.matrixWorld));
    }
    const caras = [[0, 4, 6, 2], [1, 3, 7, 5], [0, 1, 5, 4], [2, 6, 7, 3], [0, 2, 3, 1], [4, 5, 7, 6]];
    const out = new Float32Array(12 * 9);
    let o = 0;
    for (const [a, b, c, d] of caras) {
      for (const v of [esq[a], esq[b], esq[c], esq[a], esq[c], esq[d]]) { out[o++] = v.x; out[o++] = v.y; out[o++] = v.z; }
    }
    return out;
  }

  function triangulosDeMalla(obj) {
    const partes = [];
    const v = new T.Vector3();
    obj.updateMatrixWorld(true);
    recorrerPropio(obj, (o) => {
      // deco_…: decoración que no choca (flores, carteles de árbol del generador de terrenos)
      if (!o.isMesh || o.isSkinnedMesh || o.userData.ayudaEditor || o.userData.esAgua || /^deco_/i.test(o.name || '')) return;
      const pos = o.geometry.attributes.position;
      if (!pos) return;
      const ind = o.geometry.index;
      const nt = Math.floor((ind ? ind.count : pos.count) / 3);
      const arr = new Float32Array(nt * 9);
      for (let i = 0; i < nt * 3; i++) {
        v.fromBufferAttribute(pos, ind ? ind.getX(i) : i).applyMatrix4(o.matrixWorld);
        arr[i * 3] = v.x; arr[i * 3 + 1] = v.y; arr[i * 3 + 2] = v.z;
      }
      partes.push(arr);
    });
    return partes;
  }

  // Todos los triángulos que chocan (x,y,z × 3 por triángulo, en el mundo). El editor los usa para "Ver colisiones".
  // excluir: ids que no van al mundo fijo (plataformas que se mueven y lo que llevan encima)
  function triangulosDe(entidades, objetos, excluir = null) {
    const partes = [];
    for (const ent of entidades) {
      // 🚪 salida: la caja nunca choca; su modelo sí, si tiene "El modelo choca"
      if (ent.tipo === 'salida') {
        const raizSalida = F.Niveles && F.Niveles.chocaDe(ent.salida) && objetos.get(ent.id);
        const m = raizSalida && raizSalida.userData.modeloSalida;
        if (m) { raizSalida.updateWorldMatrix(true, true); partes.push(...triangulosDeMalla(m)); }
        continue;
      }
      // 🚪 puerta: solo el marco es fijo; la hoja es una pieza móvil (motor/mecanismos.js)
      if (ent.tipo === 'puerta' || ent.tipo === 'brecha') {
        const marco = objetos.get(ent.id) && objetos.get(ent.id).userData.marcoPuerta;
        if (marco) partes.push(...triangulosDeMalla(marco));
        continue;
      }
      if (excluir && excluir.has(ent.id)) continue;
      if (ent.tipo === 'plataforma' || ent.tipo === 'trampa' || ent.tipo === 'empujable') continue;   // 🧱 se mueve: pieza móvil   // ⇅ ⚠ se mueven: es una pieza móvil (motor/mecanismos.js)
      if (ent.tipo === 'inicio' || ent.tipo === 'carpeta' || ent.colision === 'ninguna') continue;
      const obj = objetos.get(ent.id);
      if (!obj) continue;
      if (ent.colision === 'caja') partes.push(triangulosDeCaja(obj));
      else partes.push(...triangulosDeMalla(obj));
    }
    const total = partes.reduce((s, p) => s + p.length, 0);
    const tri = new Float32Array(total);
    let o = 0;
    for (const p of partes) { tri.set(p, o); o += p.length; }
    return tri;
  }

  // entidades: lista del proyecto · objetos: Map id → Object3D
  function construirMundo(entidades, objetos, excluir = null) {
    return new BVH(triangulosDe(entidades, objetos, excluir));
  }

  /* =========================================================
     CUERPO CINEMÁTICO (≈ CharacterBody3D)
     - Cápsula elevada por encima del escalón: choca con paredes.
     - 5 rayos al suelo: pisa, sube escalones y se pega al bajar.
     Uso:  cuerpo.velocidad.x = …;  cuerpo.moverYDeslizar(dt);  cuerpo.enSuelo
     ========================================================= */
  const SONDAS = [[0, 0], [0.7, 0], [-0.7, 0], [0, 0.7], [0, -0.7]];
  const _A = new T.Vector3(), _B = new T.Vector3(), _va = new T.Vector3(), _vb = new T.Vector3(), _vc = new T.Vector3();
  const _n = new T.Vector3(), _ps = new T.Vector3(), _pt = new T.Vector3(), _empuje = new T.Vector3();

  class CuerpoCinematico {
    constructor(mundo, opciones = {}) {
      this.mundo = mundo;
      this.radio = opciones.radio ?? 0.35;
      this.altura = opciones.altura ?? 1.8;
      this.escalon = opciones.escalon ?? 0.4;
      this.pendienteMax = opciones.pendienteMax ?? 46;
      this.pie = new T.Vector3();          // posición de los pies
      this.velocidad = new T.Vector3();
      this.enSuelo = false;
      this.tAire = 0;                      // segundos en el aire (para coyote time)
      this.contactoTecho = false;
      this.contactoPared = false;
      this.visY = 0;                       // altura suavizada para cámara/modelo al subir escalones
    }

    teletransportar(x, y, z) {
      this.pie.set(x, y, z);
      this.velocidad.set(0, 0, 0);
      this.visY = y;
      this.enSuelo = false;
    }

    moverYDeslizar(dt) {
      const rapidez = Math.hypot(this.velocidad.x, this.velocidad.y, this.velocidad.z);
      const pasos = clamp(Math.ceil((rapidez * dt) / (this.radio * 0.5)), 1, 12);
      const sdt = dt / pasos;
      this.contactoTecho = this.contactoPared = false;
      for (let i = 0; i < pasos; i++) this._paso(sdt);
      // suavizado visual de escalones
      if (this.enSuelo && Math.abs(this.pie.y - this.visY) < this.escalon + 0.1) {
        this.visY += (this.pie.y - this.visY) * Math.min(1, dt * 14);
      } else {
        this.visY = this.pie.y;
      }
    }

    _paso(dt) {
      this.pie.addScaledVector(this.velocidad, dt);
      this._empujarCapsula();
      const suelo = this.velocidad.y <= 0 ? this._sondearSuelo(dt) : null;
      if (suelo !== null) {
        this.pie.y = suelo;
        this.velocidad.y = 0;
        this.enSuelo = true;
        this.tAire = 0;
      } else {
        this.enSuelo = false;
        this.tAire += dt;
      }
    }

    _empujarCapsula() {
      const r = this.radio, M = this.mundo, T9 = M.t, N = M.nor;
      for (let iter = 0; iter < 4; iter++) {
        const yBajo = this.pie.y + this.escalon + r;
        const yAlto = Math.max(yBajo, this.pie.y + this.altura - r);
        _A.set(this.pie.x, yBajo, this.pie.z);
        _B.set(this.pie.x, yAlto, this.pie.z);
        const cuantos = M.recoger(this.pie.x - r, yBajo - r, this.pie.z - r, this.pie.x + r, yAlto + r, this.pie.z + r);
        let movido = false;
        for (let i = 0; i < cuantos; i++) {
          const k = M.encontrados[i], q = k * 9;
          _n.set(N[k * 3], N[k * 3 + 1], N[k * 3 + 2]);
          if (_n.x === 0 && _n.y === 0 && _n.z === 0) continue;
          _va.set(T9[q], T9[q + 1], T9[q + 2]);
          _vb.set(T9[q + 3], T9[q + 4], T9[q + 5]);
          _vc.set(T9[q + 6], T9[q + 7], T9[q + 8]);
          const d2 = segmentoTriangulo(_A, _B, _va, _vb, _vc, _n, _ps, _pt);
          if (d2 >= r * r) continue;
          const d = Math.sqrt(d2);
          if (d > 1e-6) {
            _empuje.subVectors(_ps, _pt).divideScalar(d);
          } else {
            _tmp.addVectors(_A, _B).multiplyScalar(0.5).sub(_va);
            _empuje.copy(_n).multiplyScalar(_tmp.dot(_n) >= 0 ? 1 : -1);
          }
          const pen = r - d + 1e-4;
          this.pie.addScaledVector(_empuje, pen);
          _A.addScaledVector(_empuje, pen);
          _B.addScaledVector(_empuje, pen);
          const vn = this.velocidad.dot(_empuje);
          if (vn < 0) this.velocidad.addScaledVector(_empuje, -vn);
          if (_empuje.y < -0.5) this.contactoTecho = true;
          else if (Math.abs(_empuje.y) < 0.5) this.contactoPared = true;
          movido = true;
        }
        if (!movido) break;
      }
    }

    _sondearSuelo(dt) {
      const cosMax = Math.cos(this.pendienteMax * F.DEG);
      const oy = this.pie.y + this.escalon + 0.05;
      const largo = this.escalon + 0.05 + (this.enSuelo ? this.escalon : Math.max(0.02, -this.velocidad.y * dt));
      let mejor = -Infinity;
      for (const [sx, sz] of SONDAS) {
        const g = this.mundo.rayo(this.pie.x + sx * this.radio, oy, this.pie.z + sz * this.radio, 0, -1, 0, largo);
        if (!g) continue;
        if (Math.abs(this.mundo.normalY(g.k)) < cosMax) continue;
        const y = oy - g.t;
        if (y > mejor) mejor = y;
      }
      return mejor === -Infinity ? null : mejor;
    }
  }

  F.Fisica = { BVH, CuerpoCinematico, construirMundo, triangulosDe, triangulosDeMalla, triangulosLocales, segmentoTriangulo, puntoMasCercanoTriangulo };
})(window.FORJA);
