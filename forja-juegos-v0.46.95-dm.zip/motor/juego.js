/* =========================================================
   FORJA · JUEGO
   Una partida en marcha. La usan el botón ▶ del editor y el juego exportado (index.html).
   ========================================================= */
(function (F) {
  'use strict';
  const T = THREE;

  class Juego {
    // vista: FORJA.Render.Vista · proyecto: datos · escena: la escena a jugar · objetos: Map id → Object3D ya en la vista
    // opciones.ajustes: ajustes de imagen a usar (los del proyecto con lo que eligió el jugador encima)
    constructor(vista, proyecto, escena, objetos, opciones = {}) {
      this.vista = vista;
      this.proyecto = proyecto;
      this.ajustes = opciones.ajustes || proyecto.ajustes;
      this.escena = escena;
      this.objetos = objetos;
      this.camara = new T.PerspectiveCamera(70, 1, 0.05, 1500);
      vista.usarCamara(this.camara);
      this.mixers = [];
      this.jugador = null;
      this.mundo = null;
      this.depuracion = false;
      this.enMarcha = false;
    }

    /* inicio (opcional):
         { pos: [x,y,z], yaw, pitch }  aparecer donde se guardó la partida
         { llegada: idInicio }          aparecer en ese ⚑ (viniendo de otro nivel; '' = el principal)
         { jugador, rotos, recogidos, enemigosMuertos }  estado del jugador y memoria del nivel */
    iniciar(inicio = null) {
      const t0 = performance.now();
      this.rotos = new Set();   // entidades destruidas en esta partida (ya no se ven ni chocan)
      this.mundo = F.Fisica.construirMundo(this.escena.entidades, this.objetos);
      const msColision = performance.now() - t0;

      // Visibilidad de juego y animaciones "idle" de los modelos de la escena
      for (const ent of this.escena.entidades) {
        const obj = this.objetos.get(ent.id);
        if (!obj) continue;
        obj.visible = ent.tipo !== 'inicio' && ent.visible;
        obj.traverse((o) => { if (o.userData.ayudaEditor) o.visible = false; });
        const anims = obj.userData.animaciones;
        if (anims && anims.length && ent.tipo !== 'enemigo') {   // los enemigos animan con su gestor
          const mx = new T.AnimationMixer(obj);
          const acc = F.Escena.mapaAcciones(mx, anims);
          (acc.idle || Object.values(acc)[0]).play();
          this.mixers.push({ mx, obj });
        }
      }

      this.prepararObjetivos();
      // objetos rotos en la partida guardada: no se ven ni chocan
      if (inicio && Array.isArray(inicio.rotos) && inicio.rotos.length) {
        for (const id of inicio.rotos) {
          const o = this.objetivos.find((x) => x.ent.id === id);
          if (o) { this.rotos.add(id); o.obj.visible = false; }
        }
        this.objetivos = this.objetivos.filter((x) => !this.rotos.has(x.ent.id));
        if (this.rotos.size) this.mundo = F.Fisica.construirMundo(this.escena.entidades.filter((e) => !this.rotos.has(e.id)), this.objetos);
      }
      this.recogibles = new F.Recogibles(this);
      this.recogibles.preparar(inicio);
      this.enemigos = new F.Enemigos(this);
      this.enemigos.preparar(inicio);
      this.brujula = new F.Brujula(this);
      this.agua = new F.Agua(this);   // antes del jugador: el módulo Nadar lo usa
      this.tactico = new F.Tactico.Gestor(this);   // 🧍💣🚪 rehenes, bombas y puertas tácticas (antes: sus hojas van a la colisión)
      this.rehenes = this.tactico;
      this.sonidos = new F.Sonidos.Gestor(this);   // 🔊 sonidos colocados en el nivel
      this.empujables = new F.Empujables.Gestor(this, inicio);
      this.montables = new F.Montables.Gestor(this);   // 🐎 montura, carro, bote y vagoneta (antes de mecanismos: su caja choca)   // 🧱 cajas y estatuas que se empujan (antes: van a la colisión)
      this.mecanismos = new F.Mecanismos(this, inicio);   // 🔒 puertas (y palancas, disparadores…)
      if (this.vista.luces) { this.vista.luces.enJuego = true; this.vista.luces.registrar(this.escena.entidades, this.objetos); }
      this.jugador = new F.Jugador(this);
      // dónde aparece: el ⚑ de llegada (viniendo de otro nivel), si no el principal
      const llegada = this.puntoDeLlegada(inicio && inicio.llegada);
      this.jugador.iniciar(llegada.pos, llegada.yaw);
      if (inicio && inicio.pos) this.jugador.teletransportar(inicio.pos[0], inicio.pos[1], inicio.pos[2], inicio.yaw || 0, inicio.pitch || 0);
      if (inicio && inicio.jugador) this.ponerEstadoJugador(inicio.jugador);
      // 🚪 salidas a otros niveles (las que ya pisas al llegar no se disparan hasta que sales)
      this.salidas = new F.Niveles.Salidas(this);
      this.aliados = new F.Aliados.Gestor(this);   // 🛡 equipo (máx. 3) y sus órdenes
      this.guardado = new F.Guardado.Gestor(this, inicio);   // 💾 puntos de guardado y checkpoints
      this.mecanismos.reponer();   // luces / marcadores que dejaron encendidos las palancas
      if (F.Particulas && F.Particulas.preparar) F.Particulas.preparar(this);   // ✨ las que empiezan apagadas
      if (F.Campo) F.Campo.prepararBarreras(this);   // ⬡ barreras que empiezan apagadas (sin colisión)
      // 🌾 pasto sobre los materiales que lo piden (antes de hornear: el suelo aún tiene su material)
      // (el pasto está apagado por ahora: se rehará solo alrededor del jugador)
      // 🔥 luces y sombras del nivel horneadas en los vértices (Render ▸ hornear)
      if ((this.ajustes || {}).hornear && F.Horneado) this.horneado = F.Horneado.aplicar(this);
      this.gestor = new F.Gestor(this);   // ⚡ optimización: juntar lo quieto, no dibujar lo lejano o tapado
      this.misiones = new F.Misiones(this);   // ⭐ misión del nivel (objetivos, estrellas, briefing)
      // 🎬 cinemáticas del nivel (motor/cinematicas.js; en el juego exportado solo existe si se usan)
      this.cine = F.Cine && (this.escena.cinematicas || []).length ? new F.Cine.Reproductor(this) : null;
      this._cuadros = 0;

      const amb = this.escena.ambiente;
      this.camara.far = F.Render.Vista.distanciaDibujo(amb);
      this.camara.updateProjectionMatrix();
      this.vista.fxForzado = null;   // 📼 lo que puso una acción en el nivel anterior no se arrastra
      this.vista.aplicar(this.ajustes, amb, true, true);
      if (F.Efectos) F.Efectos.limpiarMomentos(this.vista);   // 💥 sin golpes ni mareos de la partida anterior
      this.clima = amb.clima && F.Clima ? new F.Clima.Gestor(this) : null;   // 🌦 solo si la escena lo activa
      F.Entrada.limpiar();
      F.Entrada.activo = true;
      this.enMarcha = true;
      F.juegoActual = this;   // el mapa del menú de pausa lo usa
      this.vista.medirGpu = false;   // solo con F3 abierto (las consultas de tiempo de la tarjeta tienen su coste)
      F.emitir('juego-iniciado', this);
      if (!(inicio && inicio.pos)) this.misiones.empezar();   // el briefing (no al cargar una partida a medias)
      return { triangulos: this.mundo.n, msColision };
    }

    /* ---------- Llegadas (⚑ inicios) ----------
       idLlegada: id de un ⚑ de esta escena ('' = el principal). Devuelve { pos: Vector3, yaw } */
    puntoDeLlegada(idLlegada) {
      const ini = F.Niveles.inicioDe(this.escena, idLlegada);
      const pos = new T.Vector3();
      const obj = ini && this.objetos.get(ini.id);
      if (obj) obj.getWorldPosition(pos);
      else pos.set(0, 2, 0);
      return { pos, yaw: ini ? ini.rot[1] * F.DEG : 0 };
    }

    // Teletransporte dentro de la misma escena (una salida que lleva a esta misma escena)
    irALlegada(idLlegada) {
      const l = this.puntoDeLlegada(idLlegada);
      const j = this.jugador;
      j.puntoInicio.copy(l.pos);
      j.yawInicio = l.yaw;
      j.reaparecer();
    }

    /* ---------- Cosas a las que se puede dañar ----------
       Cada objetivo: { ent, obj, vida, vidaMax, danar(cantidad, punto) }. Los objetos con "Vida" del Inspector
       entran solos; los enemigos (próximamente) se añaden con juego.objetivos.push(...). */
    prepararObjetivos() {
      this.objetivos = [];
      for (const ent of this.escena.entidades) {
        if (!(ent.vida > 0)) continue;
        const obj = this.objetos.get(ent.id);
        if (!obj) continue;
        const o = { ent, obj, vida: ent.vida, vidaMax: ent.vida };
        // info: { tipo: 'normal' | 'explosivo' | 'fuego'…, arma, jugador } (los enemigos usarán el tipo para sus resistencias)
        o.danar = (cantidad, punto, info = {}) => {
          if (o.vida <= 0) return;
          o.vida -= cantidad;
          F.emitir('objetivo-danado', o, cantidad, info);
          if (o.vida <= 0) this.romper(o);
        };
        this.objetivos.push(o);
      }
    }

    // 📊 cuántas entidades de cada clase hay y en qué estado (para F3; se calcula cada medio segundo)
    _conteo() {
      const ahora = performance.now();
      if (this._cnt && ahora - this._cnt.t < 500) return this._cnt.txt;
      const EN = this.enemigos, L = (EN && EN.lista) || [];
      let vivos = 0, cerca = 0, medio = 0, dorm = 0, vis = 0;
      for (const E of L) {
        if (E.reserva || E.muerto) continue;
        vivos++;
        if (E.lod === 0) cerca++; else if (E.lod === 1) medio++; else dorm++;
        if (E.obj && E.obj.visible) vis++;
      }
      const RC = this.recogibles, rl = (RC && RC.lista) || [];
      const activos = rl.filter((x) => x.activo).length, lotes = (RC && RC.lotes) ? RC.lotes.length : 0;
      let part = 0, luces = 0;
      for (const e of this.escena.entidades) { if (e.tipo === 'particulas') part++; }
      const LZ = this.vista.luces;
      if (LZ && LZ.fuentes) luces = LZ.fuentes.filter((f) => !f.apagada && !f.horneada).length;
      const txt = `entidades: enemigos ${vivos} (cerca ${cerca} · medio ${medio} · dormidos ${dorm} · se ven ${vis})  ` +
        `recogibles ${activos}/${rl.length} en ${lotes} lotes  partículas ${part}  luces vivas ${luces}`;
      this._cnt = { t: ahora, txt };
      return txt;
    }

    romper(o) {
      this.rotos.add(o.ent.id);
      o.obj.visible = false;
      this.objetivos = this.objetivos.filter((x) => x !== o);
      F.emitir('objetivo-roto', o);
      this.reconstruirColision();
      // 💥 barriles y demás rompibles que explotan (en cadena: los de al lado, un instante después)
      if (o.ent.explota > 0 && this.tactico) {
        const p = o.obj.getWorldPosition(new T.Vector3()); p.y += 0.5;
        this.tactico.explosion(p, o.ent.explota, o.ent.danoExplosion ?? 70);
        for (const x of [...this.objetivos]) {
          const d = x.obj.getWorldPosition(new T.Vector3()).distanceTo(p);
          if (d < o.ent.explota) setTimeout(() => { if (this.enMarcha) x.danar((o.ent.danoExplosion ?? 70) * (1 - d / o.ent.explota), null, { tipo: 'explosivo' }); }, 120 + d * 40);
        }
      }
    }

    // Tras romper algo: la colisión se vuelve a armar sin eso (pocos ms; solo pasa al destruir)
    reconstruirColision() {
      const vivas = this.escena.entidades.filter((e) => !this.rotos.has(e.id) && !(this.barrerasOff && this.barrerasOff.has(e.id)));   // ⬡ barreras apagadas no chocan
      this.mundo = F.Fisica.construirMundo(vivas, this.objetos);
      if (this.mecanismos) this.mecanismos.alMundo(this.mundo);
      if (this.jugador) {
        this.jugador.mundo = this.mundo;
        this.jugador.cuerpo.mundo = this.mundo;
      }
    }

    // Para guardar la partida: dónde está el jugador, cómo va (vida, armadura, armas) y qué cambió en el mapa
    estado() {
      const j = this.jugador, c = j.cuerpo.pie;
      const est = { escena: this.escena.id, pos: [c.x, c.y, c.z].map((v) => +v.toFixed(3)), yaw: +j.yaw.toFixed(4), pitch: +j.pitch.toFixed(4) };
      est.rotos = [...this.rotos];
      est.recogidos = this.recogibles ? [...this.recogibles.recogidos] : [];
      est.enemigosMuertos = this.enemigos ? this.enemigos.estado() : [];
      est.oleadas = this.enemigos ? this.enemigos.estadoOleadas() : {};
      est.mecanismos = this.mecanismos ? this.mecanismos.estado() : {};
      est.puntosUsados = this.guardado ? this.guardado.estado() : [];
      est.empujables = this.empujables ? this.empujables.estado() : {};
      const pj = {};
      if (j.danar) { pj.vida = Math.ceil(j.vida); pj.armadura = Math.ceil(j.armadura || 0); pj.vidaMax = j.vidaMax; pj.piezasCorazon = j.piezasCorazon || 0; }
      if (j.armas) {
        pj.armas = j.armas.map((a) => ({ id: a.def.id, cargador: a.cargador, reserva: a.reserva }));
        pj.armaActual = j.armaActual || 0;
        if (j.municion) pj.municion = { ...j.municion };
        if (j.municionExtra) pj.municionExtra = { ...j.municionExtra };
      }
      if (j.inventario) { pj.inventario = j.inventario.serializar(); pj.armaEquipada = j.armaEquipada || null; }
      if (j.linterna && j.linterna.bateria != null) pj.linterna = +j.linterna.bateria.toFixed(3);
      if (j.monedas) pj.monedas = j.monedas;
      if (j.divisas) pj.divisas = { ...j.divisas };
      est.jugador = pj;
      return est;
    }

    // Lo que falta en pj se queda como al empezar (así la salida puede "llenar la vida" o devolver las armas de serie)
    ponerEstadoJugador(pj) {
      const j = this.jugador;
      if (j.danar && typeof pj.vidaMax === 'number' && pj.vidaMax > 0) { j.vidaMax = pj.vidaMax; j.piezasCorazon = pj.piezasCorazon || 0; }
      if (j.danar && typeof pj.vida === 'number') j.vida = Math.max(1, Math.min(j.vidaMax || pj.vida, pj.vida));
      if (j.danar && typeof pj.armadura === 'number') j.armadura = Math.max(0, Math.min(j.armaduraMax || 0, pj.armadura));
      if (j.armas && Array.isArray(pj.armas)) {
        const defs = [...(this.proyecto.armas || []), ...(j.armasExtra || [])];
        j.armas = pj.armas.map((a) => {
          const def = defs.find((d) => d.id === a.id);
          return def && { def, cargador: a.cargador, reserva: a.reserva };
        }).filter(Boolean);
        j.armaActual = Math.min(pj.armaActual || 0, Math.max(0, j.armas.length - 1));
        if (pj.municionExtra && j.municionExtra) Object.assign(j.municionExtra, pj.municionExtra);
        if (pj.municion && j.municion) for (const k of Object.keys(j.municion)) if (typeof pj.municion[k] === 'number') j.municion[k] = pj.municion[k];
      }
      if (j.ponerCargaLinterna && typeof pj.linterna === 'number') j.ponerCargaLinterna(pj.linterna);
      if (typeof pj.monedas === 'number') j.monedas = pj.monedas;
      if (pj.divisas && typeof pj.divisas === 'object') { j.divisas = { ...pj.divisas }; if (typeof j.divisas.monedas === 'number') j.monedas = j.divisas.monedas; }
      else if (typeof pj.monedas === 'number') j.divisas = { monedas: pj.monedas };
      // la mochila (y el baúl) viajan con el jugador entre niveles y en la partida guardada
      if (j.inventario && pj.inventario) {
        j.inventario.cargar(pj.inventario);
        if ('armaEquipada' in pj) j.armaEquipada = pj.armaEquipada;
        if (j.sincronizarInventario) j.sincronizarInventario();
      }
    }

    // Briefing: toma aérea girando sobre el nivel (menus.briefing: distancia, altura, giro)
    _tomaAerea(dt) {
      const T = THREE, B = F.Misiones.estiloBriefing(this.proyecto);
      if (B.fondo !== 'aerea') return this.camara;
      let o = this._aerea;
      if (!o) {
        const caja = new T.Box3();
        for (const obj of this.objetos.values()) if (obj.visible) caja.expandByObject(obj);
        if (caja.isEmpty()) caja.set(new T.Vector3(-5, 0, -5), new T.Vector3(5, 2, 5));
        const r = Math.max(4, caja.getSize(new T.Vector3()).length() * 0.45);
        o = this._aerea = { c: caja.getCenter(new T.Vector3()), r, a: 0, cam: new T.PerspectiveCamera(60, 1, 0.05, (this.camara.far || 500) + r * 2) };
      }
      o.a += dt * (B.velGiro || 0);
      const r = o.r * (B.distancia || 1);
      o.cam.aspect = this.camara.aspect || 1; o.cam.updateProjectionMatrix();
      o.cam.position.set(o.c.x + Math.cos(o.a) * r, o.c.y + r * (B.altura ?? 0.35), o.c.z + Math.sin(o.a) * r);
      o.cam.lookAt(o.c);
      return o.cam;
    }

    actualizar(dt) {
      if (!this.enMarcha) return;
      const t0 = performance.now();
      this._actualizar(dt);
      F.Rendimiento.cuadro(performance.now() - t0);
    }

    /* ⏱ el mundo va a "k" de velocidad durante "seg" segundos reales (0.04 = casi congelado). Si ya hay uno,
       manda el más largo. Lo usa el módulo Combate (pausa de impacto) */
    lentoEnemigos(k, seg) { this._lentoE = { k: Math.max(0, Math.min(1, k)), t: seg }; }

    lento(k, seg) {
      if (this._lento && this._lento.t >= seg) return;
      this._lento = { k: Math.max(0, Math.min(1, k)), t: seg };
    }

    _actualizar(dt) {
      F.Entrada.actualizar(dt);
      // 🎬 cinemática: el mundo quieto, solo su cámara, sus pasos y las animaciones de los modelos
      if (this.cine) {
        if (++this._cuadros === 3 && !(this.misiones && this.misiones.bloquea)) this.cine.alEmpezar();
        else if (this._cuadros > 3 && this.cine._esperaBriefing && !(this.misiones && this.misiones.bloquea)) { this.cine._esperaBriefing = false; this.cine.alEmpezar(); }
        if (this._cuadros === 3 && this.misiones && this.misiones.bloquea) this.cine._esperaBriefing = true;
        if (this.cine.activo) {
          const cam = this.cine.actualizar(dt);
          if (this.clima) this.clima.actualizar(dt);
          this.vista.render(cam || this.camara);
          return;
        }
      }
      // inventario abierto: él usa los controles; con "pausa" el mundo se queda quieto (solo se dibuja)
      const inv = this.jugador && this.jugador.inventarioUI;
      if (inv && inv.abierto) {
        inv.actualizar(dt);
        if (inv.pausa || !inv.abierto) { this.vista.render(this.camara); return; }
        F.Entrada.neutralizar();   // tiempo real: el mundo sigue, pero tú no te mueves
      } else if (this.tactico && this.tactico.bloquea) {
        this.tactico.actualizar(dt);   // menú de puerta / cables: el mundo quieto
        this.vista.render(this.camara);
        return;
      } else if (this.misiones && this.misiones.bloquea) {
        // ⭐ briefing o puntuación en pantalla: el mundo quieto
        this.misiones.actualizar(dt);
        this.vista.render(this.misiones.pantalla === 'briefing' ? this._tomaAerea(dt) : this.camara);
        return;
      } else if (F.Entrada.pulsado('pausa')) { F.emitir('juego-pausa', this); return; }
      // ⏱ tiempo lento un momento (pausa de impacto al pegar, cámara lenta…): el mundo avanza menos este cuadro
      if (this._lento) { this._lento.t -= dt; if (this._lento.t <= 0) this._lento = null; else dt *= this._lento.k; }
      if (F.Entrada.pulsado('depurar')) { this.depuracion = !this.depuracion; this.vista.medirGpu = this.depuracion; if (!this.depuracion) F.Rendimiento.gpu = -1; }
      const R = F.Rendimiento;
      let t = performance.now();
      if (this.gestor) { this.gestor.actualizar(dt); R.medir('gestor', t); t = performance.now(); }
      this.jugador.actualizar(dt); R.medir('jugador', t); t = performance.now();
      this.salidas.actualizar();
      this.salidas.animar(dt);
      if (this.guardado) this.guardado.actualizar(dt);
      if (this.empujables) this.empujables.actualizar(dt);
      if (this.montables) this.montables.actualizar(dt);
      if (this.aliados) this.aliados.actualizar(dt);
      this.mecanismos.actualizar(dt); R.medir('mecanismos', t); t = performance.now();
      // ⏱ tiempo lento solo para los enemigos (esquiva perfecta): tú vas normal
      let dtE = dt;
      if (this._lentoE) { this._lentoE.t -= dt; if (this._lentoE.t <= 0) this._lentoE = null; else dtE = dt * this._lentoE.k; }
      this.enemigos.actualizar(dtE); R.medir('enemigos', t); t = performance.now();
      if (this._areas && F.Area) F.Area.actualizar(this, dt);   // ✸ ataques de área activos
      // 📊 cada sistema con su tiempo (F3): así se ve qué pesa en cada nivel
      this.recogibles.actualizar(dt); R.medir('recogibles', t); t = performance.now();
      if (this.misiones) this.misiones.actualizar(dt);
      if (this.tactico) { this.tactico.actualizar(dt); R.medir('tactico', t); t = performance.now(); }
      if (this.sonidos) this.sonidos.actualizar(dt);
      if (this.clima) { this.clima.actualizar(dt); R.medir('clima', t); t = performance.now(); }
      F.Hud.actualizar(this); R.medir('hud', t); t = performance.now();
      this.brujula.actualizar();
      this.agua.actualizar(dt); R.medir('agua', t); t = performance.now();
      for (const { mx } of this.mixers) mx.update(dt);
      R.medir('resto', t); t = performance.now();
      this.vista.render(this.camara); R.medir('render', t);
    }

    // opciones.seguir: se va a otro nivel (no suelta el cursor: el navegador no deja volver a bloquearlo sin un clic)
    detener(opciones = {}) {
      if (!this.enMarcha) return;
      if (F.juegoActual === this) F.juegoActual = null;
      this.enMarcha = false;
      if (F.Efectos) F.Efectos.limpiarMomentos(this.vista);   // 💥 que el editor no se quede en gris o mareado
      if (this.cine) this.cine.detener();
      if (this._areas && F.Area) F.Area.quitar(this);
      if (this.vista.fxForzado && !opciones.seguir) this.vista.forzarEfectos(null);
      if (this.vista.pase && !opciones.seguir) { this.vista.pase.trans.v = this.vista.pase.trans.meta = 0; }
      if (this.jugador) this.jugador.detener();
      if (this.misiones) this.misiones.detener();
      if (this.tactico) this.tactico.detener();
      if (this.sonidos) this.sonidos.detener();
      if (this.clima) { this.clima.detener(); this.clima = null; }
      if (this.enemigos) this.enemigos.detener();
      if (this.salidas) this.salidas.detener();
      if (this.empujables) this.empujables.detener();
      if (this.montables) this.montables.detener();
      if (this.aliados) this.aliados.detener();
      if (this.agua) this.agua.detener();
      if (this.mecanismos) this.mecanismos.detener();
      if (this.gestor) { this.gestor.detener(); this.gestor = null; }
      if (this.horneado) { F.Horneado.quitar(this, this.horneado); this.horneado = null; }
      if (this.pasto) { F.Pasto.quitar(this, this.pasto); this.pasto = null; }
      if (this.recogibles) this.recogibles.limpiar();
      // lo recogido vuelve a verse (en el editor la escena sigue)
      if (this.recogibles) for (const it of this.recogibles.lista) { it.obj.visible = true; if (it.giro) { it.giro.rotation.y = 0; it.giro.position.y = 0.45; } }
      for (const { mx, obj } of this.mixers) {
        mx.stopAllAction();
        obj.traverse((o) => { if (o.isSkinnedMesh) o.skeleton.pose(); });
      }
      this.mixers.length = 0;
      if (!opciones.seguir) {
        F.Entrada.activo = false;
        F.Entrada.soltarBloqueo();
      }
      if (this.vista.luces) this.vista.luces.enJuego = false;
      F.emitir('juego-detenido', this, opciones);
    }

    // F3: el texto se arma 4 veces por segundo (armarlo y pintarlo en cada cuadro costaba más que lo que mide)
    textoDepuracion(fps) {
      const ahora = performance.now();
      if (this._dbg && ahora - this._dbg.t < 250) return this._dbg.txt;
      this._dbg = { t: ahora, txt: this._textoDepuracion(fps) };
      return this._dbg.txt;
    }

    _textoDepuracion(fps) {
      const c = this.jugador.cuerpo, info = this.vista.renderer.info.render;
      const fmt = F.util.fmt;
      const R = this.vista.renderer.info;
      // materiales distintos en la escena (cada medio segundo: recorrerla cuesta)
      const ahora = performance.now();
      if (!this._mats || ahora - this._mats.t > 500) {
        const m = new Set();
        this.vista.escena.traverse((o) => { if (o.isMesh && o.visible) (Array.isArray(o.material) ? o.material : [o.material]).forEach((x) => m.add(x)); });
        this._mats = { t: ahora, n: m.size };
      }
      const g = this.gestor ? this.gestor.resumen() : '';
      return `fps ${fps}  calls ${info.calls}  tris ${fmt(info.triangles)}  materiales ${this._mats.n}  programas ${R.programs ? R.programs.length : '?'}\n` +
        F.Rendimiento.texto() + '\nms: ' + F.Rendimiento.textoSistemas() + '\n' + this._conteo() + '\n' + (g ? g + '\n' : '') +
        `pos ${c.pie.x.toFixed(2)} ${c.pie.y.toFixed(2)} ${c.pie.z.toFixed(2)}\n` +
        `vel ${Math.hypot(c.velocidad.x, c.velocidad.z).toFixed(2)} m/s  vy ${c.velocidad.y.toFixed(2)}\n` +
        `suelo ${c.enSuelo ? 'sí' : 'no'}  cámara ${this.jugador.modoCamara}\n` +
        `colisión ${fmt(this.mundo.n)} tris  mando ${F.Entrada.mando ? 'sí' : 'no'}\n` +
        `módulos: ${this.jugador.activos.map((m) => m.nombre).join(', ')}`;
    }
  }

  F.Juego = Juego;
})(window.FORJA);
