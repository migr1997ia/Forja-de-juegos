/* =========================================================
   FORJA · 🌾 PASTO ENCIMA DE UN MATERIAL
   El creador marca en un material "🌾 Pasto encima" (Material ▸ 🌾 Pasto) y al jugar el motor siembra solo
   matas de pasto sobre todas las caras que miran hacia arriba hechas con ese material (suelos, terrenos de modelos…).
   Cómo es barato (estilo N64 / PS2):
     · Cada mata = 2 planos cruzados con hojas recortadas (textura de 32 px hecha por el motor, sin archivos).
     · Todas las matas de una zona de 16 × 16 m van en UN dibujo (InstancedMesh): la cámara no dibuja las zonas que
       no ve, y en la GPU las matas lejanas se encogen hasta desaparecer (Pasto ▸ "Se ve hasta").
     · Se mecen con el viento (el del nivel o propio) solo en la punta: la raíz no se mueve.
     · La luz: todas miran "hacia arriba", así se iluminan igual que el suelo (no salen negras de lado).
     · Se siembra una vez al empezar el nivel, siempre igual (el azar depende del sitio, no cambia cada vez).
   F.Pasto.sembrar(juego) → { grupos, matas } · F.Pasto.quitar(juego, h)
   ========================================================= */
(function (F) {
  'use strict';
  const T = THREE;
  const ZONA = 16;          // metros por zona (un dibujo cada una)

  /* Valores de serie (los usa el editor) */
  const PASTO = { pasto: false, pastoDensidad: 3, pastoAlto: 0.35, pastoAncho: 0.45, pastoColor: '#2f5f22', pastoColor2: '#9acd5a',
    pastoVariar: 0.25, pastoViento: 1, pastoLejos: 25 };

  // textura de hojas (blanco con transparencia: el color lo pone la mata). Una sola para todo el juego
  let _tex = null;
  function texHojas() {
    if (_tex) return _tex;
    const c = document.createElement('canvas');
    c.width = c.height = 32;
    const g = c.getContext('2d');
    g.fillStyle = '#fff';
    // hojas: triángulos finos de distinta altura e inclinación, desde la base
    const hojas = [[4, 0.7, -2], [8, 0.95, 1], [12, 0.8, -1], [16, 1, 0], [20, 0.85, 2], [24, 0.95, -1], [28, 0.7, 2], [10, 0.6, 3], [22, 0.65, -3]];
    for (const [x, alto, inc] of hojas) {
      g.beginPath();
      g.moveTo(x - 2, 32); g.lineTo(x + 2, 32); g.lineTo(x + inc * 2, 32 - alto * 31); g.closePath(); g.fill();
    }
    _tex = new T.CanvasTexture(c);
    _tex.magFilter = T.NearestFilter; _tex.minFilter = T.NearestFilter;
    _tex.colorSpace = T.SRGBColorSpace;
    return _tex;
  }

  // la mata: 2 planos cruzados de 1 × 1 con la base en y = 0; color de raíz (oscuro) a punta (claro) por vértice
  let _geo = null;
  function geoMata() {
    if (_geo) return _geo;
    const a = new T.PlaneGeometry(1, 1, 1, 2).translate(0, 0.5, 0);
    const b = a.clone().rotateY(Math.PI / 2);
    const g = T.mergeGeometries([a.toNonIndexed(), b.toNonIndexed()]);
    const n = g.attributes.normal;
    for (let i = 0; i < n.count; i++) n.setXYZ(i, 0, 1, 0);   // todas "hacia arriba": la luz del suelo
    const pos = g.attributes.position, col = new Float32Array(pos.count * 3);
    for (let i = 0; i < pos.count; i++) { const k = pos.getY(i); col[i * 3] = col[i * 3 + 1] = col[i * 3 + 2] = k; }   // 0 raíz · 1 punta
    g.setAttribute('aPunta', new T.BufferAttribute(col.filter((_, i) => i % 3 === 0), 1));
    _geo = g;
    return g;
  }

  // azar con semilla (el mismo pasto cada vez que se juega el nivel)
  function azar(semilla) {
    let s = semilla >>> 0 || 1;
    return () => { s ^= s << 13; s ^= s >>> 17; s ^= s << 5; return ((s >>> 0) % 100000) / 100000; };
  }
  const hash = (t) => { let h = 2166136261; for (let i = 0; i < t.length; i++) { h ^= t.charCodeAt(i); h = Math.imul(h, 16777619); } return h >>> 0; };

  // material de las matas de un tipo de pasto (retro, recorte, doble cara, viento en la punta, se encoge de lejos)
  function materialPasto(cfg) {
    const m = new T.MeshLambertMaterial({ map: texHojas(), alphaTest: 0.5, side: T.DoubleSide, color: 0xffffff });
    m.userData.colRaiz = { value: new T.Color(cfg.pastoColor || PASTO.pastoColor) };
    m.userData.colPunta = { value: new T.Color(cfg.pastoColor2 || PASTO.pastoColor2) };
    m.userData.lejos = { value: Math.max(3, cfg.pastoLejos || PASTO.pastoLejos) };
    F.Render.hacerRetro(m);
    F.Render.aplicarMovimiento(m, {
      viento: (cfg.pastoViento ?? 1) > 0, vientoFuente: cfg.vientoFuente === 'propio' ? 'propio' : 'nivel',
      vientoDir: cfg.vientoDir, vientoFuerza: cfg.vientoFuerza,
      vientoCant: 0.45 * (cfg.pastoViento ?? 1), vientoAlto: 1, vientoVel: 1.6,
    });
    const base = m.onBeforeCompile;
    m.onBeforeCompile = (sh, r) => {
      base(sh, r);
      sh.uniforms.uColRaiz = m.userData.colRaiz;
      sh.uniforms.uColPunta = m.userData.colPunta;
      sh.uniforms.uLejos = m.userData.lejos;
      sh.vertexShader = 'attribute float aPunta;\nvarying float vPunta;\nuniform float uLejos;\n' + sh.vertexShader.replace('#include <begin_vertex>', `#include <begin_vertex>
        vPunta = aPunta;
        {
          // lejos se encoge hasta desaparecer (menos píxeles que pintar); la raíz se queda en su sitio
          vec4 cM = modelMatrix * instanceMatrix * vec4(0.0, 0.0, 0.0, 1.0);
          float dM = distance(cM.xyz, cameraPosition);
          transformed *= 1.0 - smoothstep(uLejos * 0.75, uLejos, dM);
        }`);
      sh.fragmentShader = 'varying float vPunta;\nuniform vec3 uColRaiz;\nuniform vec3 uColPunta;\n' + sh.fragmentShader.replace('#include <color_fragment>', `#include <color_fragment>
        diffuseColor.rgb *= mix(uColRaiz, uColPunta, vPunta);`);
    };
    const clave = m.customProgramCacheKey;
    m.customProgramCacheKey = () => clave() + '-pasto';
    return m;
  }

  const _a = new T.Vector3(), _b = new T.Vector3(), _c = new T.Vector3(), _n = new T.Vector3(), _p = new T.Vector3();
  const _m = new T.Matrix4(), _q = new T.Quaternion(), _s = new T.Vector3(), _arr = new T.Vector3(0, 1, 0), _col = new T.Color();

  /* Prepara el pasto del nivel. Para que sirva en terrenos enormes NO se siembra todo de una vez:
     1) una sola pasada guarda los triángulos que miran arriba de cada material con pasto, repartidos en zonas de 16 m;
     2) mientras se juega (o en el editor) solo existen las zonas cercanas a la cámara (hasta "Se ve hasta"):
        al acercarte a una zona se llena de matas (siempre las mismas: el azar sale de la zona) y al alejarte se borra.
     Así da igual que el terreno mida 50 m o 2 km: siempre hay unas pocas zonas vivas. */
  function sembrar(juego) {
    const escena = juego.vista.escena;   // vale el juego o { vista } (vista previa del editor)
    const tipos = new Map();   // material con pasto → { cfg, mat, zonas: Map(clave → { tris: [], areas: [], total }) }
    escena.updateMatrixWorld(true);
    const mallas = [];
    escena.traverse((o) => {
      if (!o.isMesh || o.isSkinnedMesh || o.isInstancedMesh || !o.visible || o.userData.ayudaEditor || o.userData.esAgua) return;
      const mats = Array.isArray(o.material) ? o.material : [o.material];
      if (mats.some((m) => m && m.userData.pastoCfg)) mallas.push(o);
    });
    let triangulos = 0;
    for (const o of mallas) {
      const geo = o.geometry, pos = geo.attributes.position, ind = geo.index, nor = geo.attributes.normal;
      if (!pos) continue;
      const nm = new T.Matrix3().getNormalMatrix(o.matrixWorld);
      const mats = Array.isArray(o.material) ? o.material : [o.material];
      const grupos = Array.isArray(o.material) && geo.groups.length ? geo.groups : [{ start: 0, count: ind ? ind.count : pos.count, materialIndex: 0 }];
      for (const gr of grupos) {
        const mat = mats[gr.materialIndex || 0];
        const cfg = mat && mat.userData.pastoCfg;
        if (!cfg) continue;
        if (!tipos.has(mat)) tipos.set(mat, { cfg, mat: null, zonas: new Map() });
        const Z = tipos.get(mat).zonas;
        for (let i = gr.start; i + 2 < gr.start + gr.count; i += 3) {
          _a.fromBufferAttribute(pos, ind ? ind.getX(i) : i).applyMatrix4(o.matrixWorld);
          _b.fromBufferAttribute(pos, ind ? ind.getX(i + 1) : i + 1).applyMatrix4(o.matrixWorld);
          _c.fromBufferAttribute(pos, ind ? ind.getX(i + 2) : i + 2).applyMatrix4(o.matrixWorld);
          _n.subVectors(_b, _a).cross(_p.subVectors(_c, _a));
          const area2 = _n.length();
          if (area2 < 1e-6) continue;
          // ¿mira hacia arriba? Con las normales del modelo si las trae (no depende del orden de los vértices,
          // que cambia según el programa que lo exportó); si no, la de la cara
          let ny = _n.y / area2;
          if (nor) {
            _p.set(0, 0, 0);
            for (let k = 0; k < 3; k++) _p.add(_s.fromBufferAttribute(nor, ind ? ind.getX(i + k) : i + k));
            _p.applyMatrix3(nm).normalize();
            ny = _p.y;
          }
          if (ny < 0.7) continue;   // solo lo que mira hacia arriba (suelo, no paredes ni techos)
          triangulos += guardarTri(Z, [_a.x, _a.y, _a.z], [_b.x, _b.y, _b.z], [_c.x, _c.y, _c.z]);
        }
      }
    }
    for (const t of tipos.values()) t.mat = materialPasto(t.cfg);
    const h = { tipos, vivas: new Map(), matas: 0, triangulos, escena, grupos: [] };
    // un "sensor" invisible: justo antes de dibujar mira dónde está la cámara y pone / quita zonas (≈ 6 veces por segundo)
    if (tipos.size) {
      const gs = new T.BufferGeometry();
      gs.setAttribute('position', new T.BufferAttribute(new Float32Array(9), 3));   // un triángulo de tamaño cero: no pinta nada
      const sensor = new T.Mesh(gs, new T.MeshBasicMaterial({ colorWrite: false, depthWrite: false, depthTest: false }));
      sensor.frustumCulled = false;
      sensor.userData.ayudaEditor = true;
      sensor.raycast = () => {};
      let ult = 0;
      sensor.onBeforeRender = (r, esc, cam) => {
        const ahora = performance.now();
        if (ahora - ult < 160) return;
        ult = ahora;
        actualizar(h, cam.getWorldPosition(_p));
      };
      escena.add(sensor);
      h.sensor = sensor;
    }
    return h;
  }

  // a su zona (por el centro). Un triángulo grande (suelo de 2 caras, terreno de pocos polígonos) se parte por su lado
  // más largo hasta que cabe en una zona, para que el pasto salga repartido y no amontonado en el centro
  function guardarTri(Z, a, b, c) {
    const lado = (p, q) => Math.hypot(p[0] - q[0], p[2] - q[2]);
    const ab = lado(a, b), bc = lado(b, c), ca = lado(c, a), mx = Math.max(ab, bc, ca);
    if (mx > ZONA * 0.5) {
      const mid = (p, q) => [(p[0] + q[0]) / 2, (p[1] + q[1]) / 2, (p[2] + q[2]) / 2];
      if (mx === ab) { const m = mid(a, b); return guardarTri(Z, a, m, c) + guardarTri(Z, m, b, c); }
      if (mx === bc) { const m = mid(b, c); return guardarTri(Z, a, b, m) + guardarTri(Z, a, m, c); }
      const m = mid(c, a); return guardarTri(Z, a, b, m) + guardarTri(Z, m, b, c);
    }
    const cx = (a[0] + b[0] + c[0]) / 3, cz = (a[2] + b[2] + c[2]) / 3;
    const ix = Math.floor(cx / ZONA), iz = Math.floor(cz / ZONA), clave = ix + ',' + iz;
    let z = Z.get(clave);
    if (!z) { z = { tris: [], areas: [], total: 0, cx: (ix + 0.5) * ZONA, cz: (iz + 0.5) * ZONA }; Z.set(clave, z); }
    const ux = b[0] - a[0], uy = b[1] - a[1], uz = b[2] - a[2], vx = c[0] - a[0], vy = c[1] - a[1], vz = c[2] - a[2];
    const area = Math.hypot(uy * vz - uz * vy, uz * vx - ux * vz, ux * vy - uy * vx) / 2;
    z.tris.push(...a, ...b, ...c);
    z.total += area;
    z.areas.push(z.total);
    return 1;
  }

  // pone las zonas cercanas a la cámara y quita las lejanas
  function actualizar(h, cam) {
    const quedan = new Set();
    for (const [matOrig, t] of h.tipos) {
      const lejos = Math.max(3, t.cfg.pastoLejos ?? PASTO.pastoLejos) + ZONA * 0.75;
      for (const [clave, z] of t.zonas) {
        if (Math.hypot(z.cx - cam.x, z.cz - cam.z) > lejos) continue;
        const k = matOrig.uuid + '|' + clave;
        quedan.add(k);
        if (!h.vivas.has(k)) { const im = llenarZona(t, z, clave); if (im) { h.escena.add(im); h.vivas.set(k, im); } else h.vivas.set(k, null); }
      }
    }
    for (const [k, im] of h.vivas) {
      if (quedan.has(k)) continue;
      if (im) { if (im.parent) im.parent.remove(im); im.dispose(); }
      h.vivas.delete(k);
    }
    h.grupos = [...h.vivas.values()].filter(Boolean);
    h.matas = h.grupos.reduce((n, im) => n + im.count, 0);
  }

  // llena una zona de matas (mismo azar cada vez: sale de la zona)
  function llenarZona(t, z, clave) {
    const cfg = t.cfg;
    const dens = Math.max(0, cfg.pastoDensidad ?? PASTO.pastoDensidad);
    const n = Math.min(4000, Math.round(z.total * dens));
    if (!n) return null;
    const rnd = azar(hash(clave + '|' + (cfg.pastoDensidad || 0)));
    const alto = cfg.pastoAlto ?? PASTO.pastoAlto, ancho = cfg.pastoAncho ?? PASTO.pastoAncho, variar = cfg.pastoVariar ?? PASTO.pastoVariar;
    const im = new T.InstancedMesh(geoMata(), t.mat, n);
    const A = z.areas, P = z.tris;
    for (let j = 0; j < n; j++) {
      // triángulo al azar según su área (búsqueda binaria en las áreas acumuladas)
      const x = rnd() * z.total;
      let lo = 0, hi = A.length - 1;
      while (lo < hi) { const m = (lo + hi) >> 1; if (A[m] < x) lo = m + 1; else hi = m; }
      const o = lo * 9;
      let u = rnd(), v = rnd();
      if (u + v > 1) { u = 1 - u; v = 1 - v; }
      _p.set(P[o] + (P[o + 3] - P[o]) * u + (P[o + 6] - P[o]) * v, P[o + 1] + (P[o + 4] - P[o + 1]) * u + (P[o + 7] - P[o + 1]) * v - 0.02,
        P[o + 2] + (P[o + 5] - P[o + 2]) * u + (P[o + 8] - P[o + 2]) * v);
      const k = 0.7 + 0.6 * rnd();
      _q.setFromAxisAngle(_arr, rnd() * Math.PI);
      _s.set(ancho * k, alto * k, ancho * k);
      im.setMatrixAt(j, _m.compose(_p, _q, _s));
      // un poco de variación de color por mata (más clara / más oscura)
      const tt = 1 + (rnd() - 0.5) * 2 * variar;
      im.setColorAt(j, _col.setRGB(tt, tt, tt * (1 - variar * 0.3)));
    }
    im.instanceMatrix.needsUpdate = true;
    if (im.instanceColor) im.instanceColor.needsUpdate = true;
    im.computeBoundingSphere();
    im.boundingSphere.radius += alto * 1.5;   // que no desaparezca al mecerse en el borde de la vista
    im.castShadow = false; im.receiveShadow = false;
    im.raycast = () => {};
    im.name = 'forja_pasto';
    im.userData.pasto = true;
    im.userData.ayudaEditor = true;   // no se elige ni se guarda en el editor
    return im;
  }

  /* Vista previa en el editor: se vuelve a sembrar (½ s después del último cambio) y se quita al jugar */
  function vistaEditor(vista) {
    let h = null, t = 0, jugando = false;
    const rehacer = () => {
      clearTimeout(t);
      t = setTimeout(() => {
        if (jugando) return;
        if (h) quitar(null, h);
        h = null;
        try { h = sembrar({ vista }); } catch (e) { console.warn('[pasto] vista previa', e); }
      }, 500);
    };
    F.on('escena-reconstruida', rehacer);
    F.on('entidad-reconstruida', rehacer);
    F.on('juego-iniciado', () => { jugando = true; clearTimeout(t); if (h) quitar(null, h); h = null; });
    F.on('juego-detenido', () => { jugando = false; rehacer(); });
    return rehacer;
  }

  function quitar(juego, h) {
    if (!h) return;
    for (const im of h.vivas.values()) if (im) { if (im.parent) im.parent.remove(im); im.dispose(); }
    h.vivas.clear(); h.grupos = [];
    if (h.sensor && h.sensor.parent) h.sensor.parent.remove(h.sensor);
    for (const t of h.tipos.values()) if (t.mat) t.mat.dispose();
  }

  // ¿algún material del nivel lleva pasto? (si no, sembrar no recorre nada)
  F.Pasto = { PASTO, sembrar, quitar, texHojas, vistaEditor };
})(window.FORJA);
