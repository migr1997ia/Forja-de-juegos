/* =========================================================
   FORJA · ✸ ATAQUE DE ÁREA (esfera de energía que daña lo que toca)
   Dos formas, a elegir:
     · 'onda': la esfera sale del jugador, crece rápido hasta su radio, golpea UNA vez a cada cosa que alcanza
               (daño + empujón hacia fuera) y se desvanece.
     · 'aura': la esfera rodea al jugador unos segundos (lo sigue) y daña poco a poco a lo que esté dentro.
   La usan la habilidad especial (jugador/modulos/especial.js, con su tecla) y el tipo de arma '✸ Área'.

   Barato: lo que se ve es la misma esfera low poly de los escudos (motor/campos.js, un dibujo); el daño no usa
   física: distancia a cada objetivo (enemigos y rompibles) mientras la onda crece (≈0,3 s) o 4 veces por segundo
   en el aura. Hay un grupo fijo de 3 esferas por juego que se recicla.

   F.Area.lanzar(juego, jugador, cfg) · cfg: { forma, radio, dano, empuje, crecer, dura, estilo, color, tipoDano, pulso, arma }
     pulso: una 2ª esfera (solo se ve): en la onda sale detrás de la primera; en el aura late hacia fuera una y otra vez
     dano: onda = daño del golpe (menos en el borde) · aura = daño por segundo
   F.Area.actualizar(juego, dt): lo llama juego.js cada cuadro (solo hace algo si hay alguna activa)
   ========================================================= */
(function (F) {
  'use strict';
  const T = THREE;

  const FORMAS = [['onda', '💥 Onda que crece (un golpe)'], ['aura', '🌀 Aura que se queda (daña poco a poco)']];
  const AREA = { forma: 'onda', radio: 5, dano: 40, empuje: 8, crecer: 0.35, dura: 4, estilo: 'ondas', color: '#c08cff', tipoDano: 'magico', pulso: false };
  const PULSO_AURA = 0.75;   // ◎ segundos de cada latido del aura

  const _c = new T.Vector3(), _d = new T.Vector3();

  function lista(juego) {
    if (!juego._areas) juego._areas = [];
    return juego._areas;
  }

  function lanzar(juego, jugador, cfg = {}) {
    if (!F.Campo || !juego) return null;
    const c = { ...AREA, ...cfg };
    const L = lista(juego);
    // una esfera libre del grupo (máx. 3; si no hay, la más vieja)
    let x = L.find((a) => !a.activa);
    if (!x) {
      if (L.length < 3) {
        const campo = F.Campo.crear({ forma: 'esfera', fuerza: 0 });
        campo.malla.userData.ayudaEditor = false;
        x = { campo, activa: false };
        L.push(x);
      } else x = L.reduce((a, b) => (a.t0 < b.t0 ? a : b));
    }
    x.activa = true;
    x.c = c;
    x.t = 0;
    x.t0 = performance.now();
    x.tic = 0;
    x.golpeados = new Set();
    x.jugador = jugador;
    x.centro = new T.Vector3();
    centroDe(jugador, x.centro);
    x.campo.estilo(c.estilo);
    x.campo.color(c.color);
    x.campo.fuerza(1, 0);
    const esc = juego.vista.escena;
    if (x.campo.malla.parent !== esc) esc.add(x.campo.malla);
    x.campo.malla.visible = true;
    x.campo.malla.position.copy(x.centro);
    x.campo.malla.scale.setScalar(0.3);
    // ◎ pulso: la 2ª esfera de este hueco (se crea la primera vez que se pide)
    if (c.pulso) {
      if (!x.eco) { x.eco = F.Campo.crear({ forma: 'esfera', fuerza: 0 }); x.eco.malla.userData.ayudaEditor = false; }
      x.eco.estilo(c.estilo);
      x.eco.color(c.color);
      x.eco.fuerza(0);
      if (x.eco.malla.parent !== esc) esc.add(x.eco.malla);
      x.eco.malla.visible = false;
    } else if (x.eco) x.eco.malla.visible = false;
    F.Audio.sintetico('explosion', { volumen: 0.55, tono: c.forma === 'aura' ? 1.6 : 1.2 });
    F.emitir('ataque-area', { juego, jugador, cfg: c });
    return x;
  }

  function centroDe(j, out) {
    const pie = j.cuerpo.pie;
    return out.set(pie.x, j.cuerpo.visY + (j.cuerpo.altura || 1.8) * 0.5, pie.z);
  }

  // daña (y empuja) a lo que esté a menos de r del centro. soloUnaVez: cada cosa una vez (onda)
  function golpear(juego, x, r, cantidad, soloUnaVez, empuje) {
    const c = x.c, centro = x.centro;
    for (const o of [...(juego.objetivos || [])]) {
      if (soloUnaVez && x.golpeados.has(o)) continue;
      const d = o.distancia ? o.distancia(centro) : (o.obj ? new T.Box3().setFromObject(o.obj).distanceToPoint(centro) : Infinity);
      if (d > r) continue;
      if (soloUnaVez) x.golpeados.add(o);
      const caida = c.forma === 'onda' ? 1 - 0.5 * Math.min(1, d / Math.max(0.1, c.radio)) : 1;
      o.danar(cantidad * caida, centro, { tipo: c.tipoDano || 'magico', arma: c.arma, jugador: x.jugador });
      // empujón hacia fuera (solo enemigos vivos: los rompibles no se mueven)
      const E = o.enemigo;
      if (E && !E.muerto && empuje > 0 && E.cuerpo && E.cuerpo.velocidad) {
        _d.set(E.cuerpo.pie.x - centro.x, 0, E.cuerpo.pie.z - centro.z);
        const L = _d.length() || 1;
        E.cuerpo.velocidad.x += (_d.x / L) * empuje;
        E.cuerpo.velocidad.z += (_d.z / L) * empuje;
        E.cuerpo.velocidad.y = Math.max(E.cuerpo.velocidad.y || 0, empuje * 0.35);
      }
    }
  }

  function actualizar(juego, dt) {
    const L = juego._areas;
    if (!L || !L.length) return;
    for (const x of L) {
      if (!x.activa) continue;
      const c = x.c;
      x.t += dt;
      const m = x.campo.malla;
      if (c.forma === 'aura') {
        // 🌀 sigue al jugador; crece en 0,2 s; daña 4 veces por segundo; se apaga en su último 0,4 s
        centroDe(x.jugador, x.centro);
        const k = Math.min(1, x.t / 0.2);
        m.position.copy(x.centro);
        m.scale.setScalar(Math.max(0.3, c.radio * k));
        x.tic -= dt;
        if (x.tic <= 0 && x.t < c.dura) {
          x.tic = 0.25;
          golpear(juego, x, c.radio * k, c.dano * 0.25, false, c.empuje * 0.15);
        }
        if (x.t >= c.dura - 0.4 && !x.apagando) { x.apagando = true; x.campo.fuerza(0, 0.4); }
        // ◎ latido: una esfera sale del jugador hasta un poco más allá del aura y se apaga, una y otra vez
        if (c.pulso && x.eco) {
          const f = (x.t % PULSO_AURA) / PULSO_AURA, e = x.eco.malla;
          e.visible = true;
          e.position.copy(x.centro);
          e.scale.setScalar(Math.max(0.3, c.radio * (0.25 + 0.95 * f)));
          x.eco.fuerza(0.75 * (1 - f) * Math.min(1, x.t / 0.2) * (x.apagando ? Math.max(0, (c.dura - x.t) / 0.4) : 1));
        }
        if (x.t >= c.dura) { x.activa = false; x.apagando = false; m.visible = false; if (x.eco) x.eco.malla.visible = false; }
      } else {
        // 💥 onda: crece hasta el radio (frenando al final) y golpea una vez a cada cosa que alcanza
        const crecer = Math.max(0.05, c.crecer);
        const k = Math.min(1, x.t / crecer), r = c.radio * (1 - Math.pow(1 - k, 2));
        m.position.copy(x.centro);
        m.scale.setScalar(Math.max(0.3, r));
        if (k < 1 || !x.ultimo) { golpear(juego, x, r, c.dano, true, c.empuje); if (k >= 1) x.ultimo = true; }
        if (k >= 1 && !x.apagando) { x.apagando = true; x.campo.fuerza(0, 0.35); }
        // ◎ pulso: la 2ª esfera sale un poco después, crece hasta el 80 % del radio y se apaga
        const ret = Math.max(0.1, crecer * 0.5);
        if (c.pulso && x.eco) {
          const t2 = x.t - ret, e = x.eco.malla;
          if (t2 >= 0) {
            const k2 = Math.min(1, t2 / crecer);
            e.visible = true;
            e.position.copy(x.centro);
            e.scale.setScalar(Math.max(0.3, c.radio * 0.8 * (1 - Math.pow(1 - k2, 2))));
            x.eco.fuerza(k2 < 1 ? 0.85 : Math.max(0, 0.85 * (1 - (t2 - crecer) / 0.35)));
          }
        }
        if (x.t >= crecer + 0.4 + (c.pulso ? ret : 0)) { x.activa = false; x.apagando = false; x.ultimo = false; m.visible = false; if (x.eco) x.eco.malla.visible = false; }
      }
    }
  }

  // al terminar el nivel: fuera todas
  function quitar(juego) {
    for (const x of juego._areas || []) {
      x.activa = false;
      if (x.campo.malla.parent) x.campo.malla.parent.remove(x.campo.malla);
      if (x.eco && x.eco.malla.parent) x.eco.malla.parent.remove(x.eco.malla);
    }
    juego._areas = [];
  }

  F.Area = { FORMAS, AREA, lanzar, actualizar, quitar };
})(window.FORJA);
