/* =========================================================
   FORJA · BRÚJULA Y MARCADORES
   Brújula del HUD (proyecto.hud.brujula): 'tira' (barra arriba que se desliza, estilo Skyrim), 'circulo'
   (rosa de los vientos en una esquina que gira) o 'esfera' (globo 3D low poly como King's Field: un canvas
   pequeño pixelado con meridianos, paralelos y las letras sobre el ecuador; los marcadores son puntos en él).
   La esfera solo se vuelve a dibujar si cambia el rumbo, la inclinación o un marcador (80×80 px: casi gratis). Muestra los MARCADORES del mapa (entidad 'marcador').
   - Rumbo = hacia donde mira la cámara. Norte = −Z del mundo, girado hud.norte grados.
   - Barato: solo toca el HTML (un transform) si el rumbo cambia; distancias cada 15 cuadros.
   - API para otros sistemas (puertas, misiones…): juego.brujula.marcar(idONombre, visible).
     Evento 'marcador-alcanzado' (marcador) al llegar a uno con "Desaparece al llegar".
   ========================================================= */
(function (F) {
  'use strict';
  const T = THREE;
  const RAD = 180 / Math.PI;
  const LETRAS = { 0: 'N', 45: 'NE', 90: 'E', 135: 'SE', 180: 'S', 225: 'SO', 270: 'O', 315: 'NO' };

  const MARCADOR = {
    icono: '◆',              // un carácter o emoji
    color: '#ffd24a',
    texto: '',               // se ve junto al icono (vacío = nada)
    alEmpezar: true,         // visible desde el principio (si no, lo enciende otro sistema con marcar())
    radioLlegar: 0,          // > 0: desaparece al acercarte a menos de esto (m)
  };

  const CSS = `
  .fh-brujula { position: absolute; z-index: 1; pointer-events: none; font-size: calc(1em * var(--fb-t, 1)); text-shadow: .1em .1em 0 #000; }
  .fh-br-tira { left: 50%; top: calc(var(--fh-u) * var(--fh-m) * .6); transform: translateX(-50%); width: 24em; height: 3.2em; overflow: hidden;
    -webkit-mask-image: linear-gradient(90deg, transparent, #000 18%, #000 82%, transparent); mask-image: linear-gradient(90deg, transparent, #000 18%, #000 82%, transparent);
    background: linear-gradient(rgba(0,0,0,.35), rgba(0,0,0,.35)) 0 1.05em / 100% .08em no-repeat; }
  .fh-br-tira .fh-br-cinta { position: absolute; left: 0; top: 0; width: 400%; height: 100%; will-change: transform; }
  .fh-br-tira .fh-br-m { position: absolute; top: .05em; transform: translateX(-50%); font-size: .85em; }
  .fh-br-tira .fh-br-m.fh-br-card { font-size: 1.05em; top: -.05em; color: var(--fh-sel); }
  .fh-br-tira .fh-br-m.fh-br-raya { top: .55em; width: .08em; height: .45em; background: currentColor; opacity: .6; }
  .fh-br-tira .fh-br-centro { position: absolute; left: 50%; top: 1.15em; transform: translateX(-50%); width: 0; height: 0;
    border: .3em solid transparent; border-bottom-color: var(--fh-sel); }
  .fh-br-mk { position: absolute; transform: translate(-50%, -50%); text-align: center; line-height: 1; white-space: nowrap; }
  .fh-br-mk small { display: block; font-size: .55em; opacity: .9; margin-top: .1em; }
  .fh-br-tira .fh-br-mk { top: 2.15em; }
  .fh-br-circulo { width: 6.5em; height: 6.5em; border-radius: 50%; background: rgba(0,0,0,.4); border: .12em solid rgba(255,255,255,.45); }
  .fh-br-circulo.fh-br-arriba-der { right: calc(var(--fh-u) * var(--fh-m)); top: calc(var(--fh-u) * var(--fh-m)); }
  .fh-br-circulo.fh-br-arriba-izq { left: calc(var(--fh-u) * var(--fh-m)); top: calc(var(--fh-u) * var(--fh-m)); }
  .fh-br-circulo.fh-br-abajo-der { right: calc(var(--fh-u) * var(--fh-m)); bottom: calc(var(--fh-u) * var(--fh-m) + 4em); }
  .fh-br-circulo.fh-br-abajo-izq { left: calc(var(--fh-u) * var(--fh-m)); bottom: calc(var(--fh-u) * var(--fh-m) + 4em); }
  /* con controles táctiles: arriba a la derecha está el botón de pausa (9vmin) → el círculo se corre a su izquierda;
     abajo están el joystick y los botones → el círculo sube por encima de ellos */
  .fh-br-circulo.fh-br-tactil.fh-br-arriba-der { right: calc(var(--fh-u) * var(--fh-m) + 11vmin); }
  .fh-br-circulo.fh-br-tactil.fh-br-abajo-der, .fh-br-circulo.fh-br-tactil.fh-br-abajo-izq { bottom: 42vmin; }
  .fh-br-circulo .fh-br-rosa { position: absolute; inset: 0; will-change: transform; transform: rotate(calc(-1deg * var(--rb, 0))); }
  /* las letras giran al revés que la rosa: siempre derechas */
  .fh-br-circulo .fh-br-l { position: absolute; transform: translate(-50%, -50%) rotate(calc(1deg * var(--rb, 0))); font-size: .8em; }
  .fh-br-circulo .fh-br-l.fh-br-card { color: var(--fh-sel); font-size: .95em; }
  .fh-br-circulo .fh-br-centro { position: absolute; left: 50%; top: .1em; transform: translateX(-50%); width: 0; height: 0;
    border: .32em solid transparent; border-top-color: var(--fh-sel); }
  .fh-br-circulo .fh-br-yo { position: absolute; left: 50%; top: 50%; width: .4em; height: .4em; margin: -.2em 0 0 -.2em; background: var(--fh-sel); border-radius: 50%; }
  .fh-br-circulo .fh-br-mk { font-size: .8em; }
  .fh-br-circulo .fh-br-mk small { display: none; }
  /* 🌐 esfera (King's Field) */
  .fh-br-esfera { width: 7em; height: 7em; }
  .fh-br-esfera canvas { width: 100%; height: 100%; image-rendering: pixelated; display: block; filter: drop-shadow(.1em .15em 0 rgba(0,0,0,.6)); }
  .fh-br-esfera .fh-br-dist { position: absolute; left: 0; right: 0; bottom: -.9em; text-align: center; font-size: .6em; }
  .fh-br-esfera.fh-br-arriba-der { right: calc(var(--fh-u) * var(--fh-m)); top: calc(var(--fh-u) * var(--fh-m)); }
  .fh-br-esfera.fh-br-arriba-izq { left: calc(var(--fh-u) * var(--fh-m)); top: calc(var(--fh-u) * var(--fh-m)); }
  .fh-br-esfera.fh-br-abajo-der { right: calc(var(--fh-u) * var(--fh-m)); bottom: calc(var(--fh-u) * var(--fh-m) + 4em); }
  .fh-br-esfera.fh-br-abajo-izq { left: calc(var(--fh-u) * var(--fh-m)); bottom: calc(var(--fh-u) * var(--fh-m) + 4em); }
  .fh-br-esfera.fh-br-abajo-centro { left: 50%; transform: translateX(-50%); bottom: calc(var(--fh-u) * var(--fh-m)); }
  /* con brújula en tira, la barra del jefe y el contador de oleadas bajan un poco */
  .fhud.fh-con-tira .fh-jefe { top: 11%; }
  .fhud.fh-con-tira .fh-oleadas { top: 18%; }
  `;
  function asegurarCss() {
    if (document.getElementById('estilos-forja-brujula')) return;
    const st = document.createElement('style');
    st.id = 'estilos-forja-brujula';
    st.textContent = CSS;
    document.head.appendChild(st);
  }

  const envolver = (a) => ((a % 360) + 540) % 360 - 180;   // a [-180, 180)

  /* Arma el HTML de la brújula dentro de "capa". Devuelve las piezas que se mueven */
  function construir(capa, h) {
    asegurarCss();
    const el = document.createElement('div');
    // arcade: arriba va la fila de vida y la munición → siempre redonda (la tira pasa abajo a la izq.)
    const arcade = h.posicion === 'arcade', modo = h.brujula === 'esfera' ? 'esfera' : h.brujula === 'circulo' || arcade ? 'circulo' : 'tira';
    let esq = arcade && h.brujula === 'tira' ? 'abajo-izq' : (h.brujulaEsquina || 'arriba-der');
    if (modo === 'circulo' && esq === 'abajo-centro') esq = 'abajo-der';   // el círculo no va al centro (la munición)
    el.className = 'fh-brujula fh-br-' + modo + (modo !== 'tira' ? ' fh-br-' + esq : '');
    el.style.setProperty('--fb-t', h.brujulaTam ?? 1);
    let movil;
    if (modo === 'esfera') {
      const cv = document.createElement('canvas');
      const calidad = h.brujulaCalidad || 'alta';
      cv.width = cv.height = calidad === 'baja' ? 28 : calidad === 'media' ? 48 : 80;
      el.appendChild(cv);
      capa.appendChild(el);
      if (F.Hud && F.Hud.colocar && capa._hudCfg) F.Hud.colocar(capa, el);
      return { el, modo, cv, g: cv.getContext('2d'), color: h.brujulaColor || '#4f74a8', inclina: h.brujulaInclina !== false, mks: [], rumbo: 0, incl: 0.42, calidad };
    }
    if (modo === 'tira') {
      // cinta de −180° a 540° (cuatro veces el ancho visible de 180°): se desliza con el rumbo
      movil = document.createElement('div');
      movil.className = 'fh-br-cinta';
      let html = '';
      for (let g = -180; g <= 540; g += 15) {
        const n = ((g % 360) + 360) % 360, izq = ((g + 180) / 720) * 100;
        if (LETRAS[n]) html += `<span class="fh-br-m${n % 90 === 0 ? ' fh-br-card' : ''}" style="left:${izq}%">${LETRAS[n]}</span>`;
        else html += `<span class="fh-br-m fh-br-raya" style="left:${izq}%"></span>`;
      }
      movil.innerHTML = html;
      el.appendChild(movil);
      el.insertAdjacentHTML('beforeend', '<div class="fh-br-centro"></div>');
    } else {
      movil = document.createElement('div');
      movil.className = 'fh-br-rosa';
      let html = '';
      for (const [g, l] of Object.entries(LETRAS)) {
        const a = +g / RAD, r = 38;
        html += `<span class="fh-br-l${+g % 90 === 0 ? ' fh-br-card' : ''}" style="left:${50 + Math.sin(a) * r}%;top:${50 - Math.cos(a) * r}%">${l}</span>`;
      }
      movil.innerHTML = html;
      el.appendChild(movil);
      el.insertAdjacentHTML('beforeend', '<div class="fh-br-centro"></div><div class="fh-br-yo"></div>');
    }
    capa.appendChild(el);
    if (F.Hud && F.Hud.colocar && capa._hudCfg) F.Hud.colocar(capa, el);
    return { el, movil, modo };
  }

  /* 🌐 Dibuja el globo: rumbo (grados) = el punto del ecuador que queda de frente; incl = cuánto se ve desde arriba.
     Meridianos cada 30°, paralelos cada 30° (el ecuador más marcado), letras sobre el ecuador (más grandes de frente)
     y los marcadores como puntos. Lo de atrás se ve tenue, como un globo de alambre. */
  function hexRgb(c) { const n = parseInt((c || '#4f74a8').slice(1), 16) || 0; return [(n >> 16) & 255, (n >> 8) & 255, n & 255]; }
  function dibujarEsfera(b) {
    const g = b.g, N = b.cv.width, R = N * 0.4, cx = N / 2, cy = N / 2, k = N / 80, baja = b.calidad === 'baja';
    const [r, gg, bb] = hexRgb(b.color), mezcla = (k) => `rgb(${Math.round(r * k)},${Math.round(gg * k)},${Math.round(bb * k)})`;
    const claro = (k) => `rgb(${Math.round(r + (255 - r) * k)},${Math.round(gg + (255 - gg) * k)},${Math.round(bb + (255 - bb) * k)})`;
    g.clearRect(0, 0, N, N);
    // cuerpo con luz arriba a la izquierda (baja: 3 tonos planos, como un sprite de PS1)
    if (baja) {
      g.fillStyle = mezcla(0.45); g.beginPath(); g.arc(cx, cy, R, 0, Math.PI * 2); g.fill();
      g.save(); g.beginPath(); g.arc(cx, cy, R, 0, Math.PI * 2); g.clip();
      g.fillStyle = mezcla(1); g.beginPath(); g.arc(cx - R * 0.15, cy - R * 0.15, R * 0.88, 0, Math.PI * 2); g.fill();
      g.fillStyle = claro(0.45); g.beginPath(); g.arc(cx - R * 0.42, cy - R * 0.42, R * 0.3, 0, Math.PI * 2); g.fill();
      g.restore();
    } else {
      const gr = g.createRadialGradient(cx - R * 0.4, cy - R * 0.45, R * 0.08, cx, cy, R);
      gr.addColorStop(0, claro(0.55)); gr.addColorStop(0.55, mezcla(1)); gr.addColorStop(1, mezcla(0.35));
      g.fillStyle = gr;
      g.beginPath(); g.arc(cx, cy, R, 0, Math.PI * 2); g.fill();
    }
    const ct = Math.cos(b.incl), st = Math.sin(b.incl), r0 = b.rumbo / RAD;
    const P = (lon, lat) => {
      const rel = lon - r0, x = Math.cos(lat) * Math.sin(rel), y = Math.sin(lat), z = Math.cos(lat) * Math.cos(rel);
      return [cx + x * R, cy - (y * ct - z * st) * R, z * ct + y * st];
    };
    const linea = (pts, ancho, luz) => {
      for (let i = 1; i < pts.length; i++) {
        const a = pts[i - 1], c = pts[i], frente = a[2] > 0 && c[2] > 0;
        if (baja && !frente) continue;   // baja: solo las líneas de delante
        g.strokeStyle = frente ? claro(luz) : mezcla(0.6);
        g.globalAlpha = frente ? 1 : 0.35;
        g.lineWidth = frente ? ancho : 1;
        g.beginPath(); g.moveTo(a[0], a[1]); g.lineTo(c[0], c[1]); g.stroke();
      }
      g.globalAlpha = 1;
    };
    const D = Math.PI / 180;
    const pasoLon = baja ? 45 : 30, pasoLat = baja ? 30 : 15, lats = baja ? [-45, 0, 45] : [-60, -30, 0, 30, 60];
    for (let lon = 0; lon < 360; lon += pasoLon) { const pts = []; for (let lat = -90; lat <= 90; lat += pasoLat) pts.push(P(lon * D, lat * D)); linea(pts, 1, 0.35); }
    for (const lat of lats) { const pts = []; for (let lon = 0; lon <= 360; lon += baja ? 30 : 15) pts.push(P(lon * D, lat * D)); linea(pts, lat === 0 && !baja ? 2 : 1, lat === 0 ? 0.75 : 0.35); }
    // borde
    g.strokeStyle = 'rgba(0,0,0,.7)'; g.lineWidth = baja ? 1 : 1.5;
    g.beginPath(); g.arc(cx, cy, R, 0, Math.PI * 2); g.stroke();
    // marcadores (puntos sobre el ecuador, un poco arriba)
    for (const m of b.mks) {
      const p = P(m.rel * D, 0.18);
      if (p[2] <= 0) continue;
      const t = Math.max(1, Math.round(2 * k));
      g.fillStyle = '#000'; g.fillRect(Math.round(p[0]) - t - 1, Math.round(p[1]) - t - 1, t * 2 + 2, t * 2 + 2);
      g.fillStyle = m.color; g.fillRect(Math.round(p[0]) - t, Math.round(p[1]) - t, t * 2, t * 2);
    }
    // letras: de frente grandes, a los lados pequeñas
    g.textAlign = 'center'; g.textBaseline = 'middle';
    for (const [gr2, l] of Object.entries(LETRAS)) {
      const p = P(+gr2 * D, 0);
      if (p[2] < 0.15) continue;
      const card = +gr2 % 90 === 0;
      if (!card && b.calidad !== 'alta') continue;   // media y baja: solo N, E, S, O
      const tam = Math.max(5, Math.round((card ? 13 : 9) * k * (0.6 + 0.4 * p[2]) * (baja ? 1.25 : 1)));
      g.font = `bold ${tam}px monospace`;
      g.globalAlpha = Math.min(1, p[2] * 1.6);
      const sube = 4 * k;
      if (!baja) { g.fillStyle = '#000'; g.fillText(l, p[0] + 1, p[1] - sube + 1); }
      g.fillStyle = card ? (b.sel || '#ffd24a') : '#fff'; g.fillText(l, p[0], p[1] - sube);
    }
    g.globalAlpha = 1;
    // aguja fija: el frente (abajo, apuntando al punto de frente del ecuador)
    const f = P(r0, 0);
    g.fillStyle = b.sel || '#ffd24a'; g.strokeStyle = '#000'; g.lineWidth = 1;
    g.beginPath(); g.moveTo(cx, f[1] + 5 * k); g.lineTo(cx - 4 * k, cy + R + 4 * k); g.lineTo(cx + 4 * k, cy + R + 4 * k); g.closePath(); g.fill(); if (!baja) g.stroke();
  }

  // coloca la cinta o gira la rosa para el rumbo (grados, 0 = norte)
  function girar(b, rumbo) {
    if (b.modo === 'esfera') { b.rumbo = rumbo; return dibujarEsfera(b); }
    if (b.modo === 'tira') b.movil.style.transform = `translateX(${12.5 - (rumbo + 180) / 7.2}%)`;
    else b.movil.style.setProperty('--rb', rumbo.toFixed(1));
  }

  // coloca un marcador a "rel" grados del frente (tira: horizontal; círculo: sobre el aro, cerca o lejos)
  function ponerMarcador(b, el, rel, d) {
    if (b.modo === 'tira') {
      const ver = Math.abs(rel) <= 88;
      el.style.display = ver ? '' : 'none';
      if (ver) el.style.left = 50 + (rel / 180) * 100 + '%';
    } else {
      const a = rel / RAD, r = d < 25 ? 18 + d : 43;   // cerca se acerca al centro; lejos queda en el borde
      el.style.left = 50 + Math.sin(a) * r + '%';
      el.style.top = 50 - Math.cos(a) * r + '%';
    }
  }

  class Brujula {
    constructor(juego) {
      this.juego = juego;
      this.marcadores = [];
      const h = { ...F.Escena.hudPorDefecto(), ...(juego.proyecto.hud || {}) };
      this.h = h;
      // marcadores del mapa (aunque no haya brújula: otros sistemas pueden usarlos)
      for (const ent of juego.escena.entidades) {
        if (ent.tipo !== 'marcador') continue;
        const obj = juego.objetos.get(ent.id);
        if (!obj) continue;
        const c = { ...MARCADOR, ...(ent.marcador || {}) };
        this.marcadores.push({ ent, c, pos: obj.getWorldPosition(new T.Vector3()), visible: c.alEmpezar && ent.visible !== false, el: null, rel: 999, d: -1 });
      }
      this.activa = h.brujula === 'tira' || h.brujula === 'circulo' || h.brujula === 'esfera';
      this.rumbo = -999;
      this.cuadro = 0;
      this._dir = new T.Vector3();
    }

    _montar() {
      const capa = F.Hud.capa(this.juego);
      this.b = construir(capa, this.h);
      if (this.b.modo === 'tira') capa.classList.add('fh-con-tira');
      if (this.h.brujulaMarcadores === false) return;
      if (this.b.modo === 'esfera') return;   // en la esfera los marcadores se dibujan en el canvas
      for (const m of this.marcadores) {
        const el = document.createElement('div');
        el.className = 'fh-br-mk';
        el.style.color = m.c.color;
        el.innerHTML = '<span></span>' + (this.h.brujulaDistancia !== false || m.c.texto ? '<small></small>' : '');
        el.firstChild.textContent = m.c.icono || '◆';
        el.style.display = m.visible ? '' : 'none';
        this.b.el.appendChild(el);
        m.el = el;
      }
    }

    // enciende / apaga un marcador por id o por nombre (para puertas, misiones, disparadores…)
    marcar(cual, visible = true) {
      for (const m of this.marcadores) if (m.ent.id === cual || m.ent.nombre === cual) { m.visible = visible; if (m.el) m.el.style.display = visible ? '' : 'none'; m.rel = 999; }
    }

    actualizar() {
      if (!this.activa && !this.marcadores.length) return;
      const j = this.juego.jugador;
      if (!j) return;
      if (this.activa && !this.b) this._montar();
      this.cuadro++;
      const P = j.cuerpo.pie;
      // llegar a un marcador (2 veces por segundo bastan)
      if (this.cuadro % 30 === 0) {
        for (const m of this.marcadores) {
          if (!m.visible || !(m.c.radioLlegar > 0)) continue;
          if (Math.hypot(m.pos.x - P.x, m.pos.z - P.z) < m.c.radioLlegar) { this.marcar(m.ent.id, false); F.emitir('marcador-alcanzado', m.ent); }
        }
      }
      if (!this.activa) return;
      // controles táctiles a la vista: el círculo se aparta del botón de pausa y de los botones
      if (this.cuadro % 30 === 1) {
        const tactil = !!(F.Tactil && F.Tactil.visible);
        if (tactil !== this.tactil) { this.tactil = tactil; this.b.el.classList.toggle('fh-br-tactil', tactil); }
      }
      // rumbo de la cámara (0 = norte = −Z del mundo, + hacia el este = +X)
      this.juego.camara.getWorldDirection(this._dir);
      const norte = this.h.norte || 0;
      const rumbo = ((Math.atan2(this._dir.x, -this._dir.z) * RAD - norte) % 360 + 360) % 360;
      const giro = Math.abs(envolver(rumbo - this.rumbo)) > 0.15;
      if (this.b.modo === 'esfera') {
        // 🌐 inclinación: se ve desde arriba; al mirar arriba / abajo se inclina con la cámara
        const B = this.b;
        if (!B.sel) B.sel = getComputedStyle(B.el).getPropertyValue('--fh-sel').trim() || '#ffd24a';
        const incl = B.inclina ? Math.max(0.05, Math.min(0.95, 0.42 - Math.asin(Math.max(-1, Math.min(1, this._dir.y))) * 0.5)) : 0.42;
        let cambio = giro || Math.abs(incl - B.incl) > 0.01;
        if (this.cuadro % 10 === 0 || cambio) {
          const mks = [];
          if (this.h.brujulaMarcadores !== false) for (const m of this.marcadores) {
            if (!m.visible) continue;
            mks.push({ rel: envolver(Math.atan2(m.pos.x - P.x, -(m.pos.z - P.z)) * RAD - norte), color: m.c.color });
          }
          const firma = mks.map((m) => m.rel.toFixed(0)).join();
          if (firma !== B.firma) { B.firma = firma; B.mks = mks; cambio = true; }
        }
        if (cambio) { this.rumbo = rumbo; B.incl = incl; girar(B, rumbo); }
        return;
      }
      if (giro) { this.rumbo = rumbo; girar(this.b, rumbo); }
      const textos = this.cuadro % 15 === 0;
      for (const m of this.marcadores) {
        if (!m.el || !m.visible) continue;
        const dx = m.pos.x - P.x, dz = m.pos.z - P.z;
        const rumboM = Math.atan2(dx, -dz) * RAD - norte;
        // el círculo gira entero (la rosa), así que allí el marcador va en ángulo absoluto relativo a la rosa
        const rel = this.b.modo === 'tira' ? envolver(rumboM - rumbo) : envolver(rumboM - rumbo);
        const d = Math.hypot(dx, dz);
        if (Math.abs(rel - m.rel) > 0.15 || (this.b.modo === 'circulo' && Math.abs(d - m.d) > 0.5)) { m.rel = rel; ponerMarcador(this.b, m.el, rel, d); m.d = d; }
        if (textos && m.el.lastChild.tagName === 'SMALL') {
          const t = [m.c.texto, this.h.brujulaDistancia !== false ? Math.round(d) + ' m' : ''].filter(Boolean).join(' · ');
          if (m.el.lastChild.textContent !== t) m.el.lastChild.textContent = t;
        }
      }
    }
  }

  /* Vista previa del editor (HUD): rumbo fijo y un marcador de ejemplo */
  Brujula.vistaPrevia = function (capa, h) {
    if (h.brujula !== 'tira' && h.brujula !== 'circulo' && h.brujula !== 'esfera') return;
    const b = construir(capa, h);
    if (b.modo === 'esfera') { b.sel = '#e8a33d'; b.mks = h.brujulaMarcadores === false ? [] : [{ rel: 35, color: '#ffd24a' }]; girar(b, 20); return; }
    if (b.modo === 'tira') capa.classList.add('fh-con-tira');
    girar(b, 20);
    if (h.brujulaMarcadores === false) return;
    const el = document.createElement('div');
    el.className = 'fh-br-mk';
    el.style.color = '#ffd24a';
    el.innerHTML = '<span>◆</span>' + (h.brujulaDistancia !== false ? '<small>120 m</small>' : '');
    b.el.appendChild(el);
    ponerMarcador(b, el, 35, 120);
  };

  /* Ayuda del editor para la entidad 'marcador' (no se ve al jugar) */
  Brujula.figura = function (ent) {
    const c = { ...MARCADOR, ...(ent.marcador || {}) };
    const g = new T.Group();
    const m = new T.MeshBasicMaterial({ color: c.color, fog: false });
    const rombo = new T.Mesh(new T.OctahedronGeometry(0.3), m);
    rombo.position.y = 2;
    const palo = new T.Mesh(new T.CylinderGeometry(0.03, 0.03, 1.7, 6), m);
    palo.position.y = 0.85;
    for (const o of [rombo, palo]) { o.userData.ayudaEditor = true; g.add(o); }
    if (c.radioLlegar > 0) {
      const p = [];
      for (let i = 0; i <= 48; i++) { const a = (i / 48) * Math.PI * 2; p.push(new T.Vector3(Math.cos(a) * c.radioLlegar, 0.05, Math.sin(a) * c.radioLlegar)); }
      const aro = new T.Line(new T.BufferGeometry().setFromPoints(p), new T.LineBasicMaterial({ color: c.color, transparent: true, opacity: 0.5, fog: false }));
      aro.userData.ayudaEditor = true;
      g.add(aro);
    }
    g.userData.ayudaEditor = true;
    return g;
  };

  Brujula.MARCADOR = MARCADOR;
  F.Brujula = Brujula;
})(window.FORJA);
