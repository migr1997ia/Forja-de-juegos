/* =========================================================
   FORJA · MONTABLES (entidad 🐎 'montable'): montura, carro, bote y vagoneta
   Usar cerca = subir · usar otra vez = bajar (a un lado libre). Solo el jugador.
   Mientras va montado (j.montado = it):
     · jugador.js salta los módulos de andar (movimiento, agachar, esquiva, trepar…) y llama a Gestor.conducir
     · montura / carro: el cuerpo del jugador (con el radio del vehículo) choca y sube rampas; la velocidad la pone el vehículo
     · bote: solo se mueve sobre el agua (motor/agua.js) · vagoneta: sigue los 📍 puntos cuyo nombre empieza por "ruta"
   Aparcado: choca como PIEZA MÓVIL (una caja invisible: motor/mecanismos.js alMundo).
   Al bajar: se queda donde lo dejes, o vuelve a su sitio tras X segundos (lo elige el creador).
   ========================================================= */
(function (F) {
  'use strict';
  const T = THREE;

  const MONTABLE = {
    tipo: 'montura',          // 'montura' | 'carro' | 'bote' | 'riel'
    velocidad: 9,             // m/s hacia delante
    reversa: 3,               // m/s marcha atrás (0 = no)
    aceleracion: 6,           // m/s²
    giro: 120,                // °/s
    salto: 7,                 // montura: fuerza del salto (0 = no salta)
    disparar: true,           // puede usar sus armas montado
    terceraPersona: true,     // al montar pasa a 3ª persona (Halo) y al bajar vuelve a como estaba
    atropello: 0,             // daño al chocar con criaturas a toda velocidad (0 = nada)
    ocultarJugador: false,    // dentro (carro cerrado): no se ve al jugador
    asiento: 0.95,            // altura del jugador sobre el suelo al ir montado (m)
    camara: 1.5,              // metros extra de cámara en 3ª persona
    alBajar: 'quedarse',      // 'quedarse' | 'volver'
    volverTras: 5,            // s
    reaparecer: true,         // destruido (montura, carro o vagoneta que entra al agua o la lava): vuelve a su sitio
    reaparecerTras: 5,        // s
    ruta: 'Riel',             // vagoneta: 📍 puntos cuyo nombre empieza por esto (en orden: Riel 1, Riel 2…)
    sonido: '',
    modelo: '', escalaModelo: 1,
    color: '#7a5634',
    nombreAccion: '',         // '' = "Montar" / "Subir"
  };
  const TIPOS = [['montura', '🐎 Montura (caballo, moto)'], ['carro', '🚗 Carro (jeep, kart)'], ['bote', '🚤 Bote (lancha, balsa)'], ['riel', '🛤 Vagoneta (sigue una ruta)']];
  // valores de cada tipo al elegirlo en el editor
  const PRESETS = {
    montura: { velocidad: 9, reversa: 2.5, aceleracion: 7, giro: 140, salto: 7, atropello: 0, ocultarJugador: false, asiento: 0.95, color: '#7a5634' },
    carro: { velocidad: 14, reversa: 5, aceleracion: 6, giro: 90, salto: 0, atropello: 40, ocultarJugador: false, asiento: 0.65, color: '#b0482c' },
    bote: { velocidad: 8, reversa: 3, aceleracion: 4, giro: 80, salto: 0, atropello: 0, ocultarJugador: false, asiento: 0.05, color: '#8a6a44' },
    riel: { velocidad: 7, reversa: 4, aceleracion: 4, giro: 0, salto: 0, atropello: 25, ocultarJugador: false, asiento: 0.45, color: '#5a5a62' },
  };
  const MEDIDAS = { montura: [0.8, 2.0, 1.5], carro: [1.6, 2.6, 1.2], bote: [1.3, 2.8, 0.6], riel: [1.1, 1.5, 0.9] };   // ancho, largo, alto

  const ESQUEMA = [
    { grupo: '🐎 Montable' },
    { k: 'tipo', t: 'sel', e: 'Tipo', op: TIPOS, ayuda: 'Al cambiarlo se ponen sus valores de serie' },
    { k: 'velocidad', t: 'num', e: 'Velocidad (m/s)', paso: 0.5, min: 0.5 },
    { k: 'reversa', t: 'num', e: 'Marcha atrás (m/s)', paso: 0.5, min: 0, ayuda: '0 = no va hacia atrás' },
    { k: 'aceleracion', t: 'num', e: 'Aceleración', paso: 0.5, min: 0.5 },
    { k: 'giro', t: 'num', e: 'Giro (°/s)', paso: 5, min: 10, si: (v) => v.tipo !== 'riel' },
    { k: 'salto', t: 'num', e: 'Salto', paso: 0.5, min: 0, si: (v) => v.tipo === 'montura', ayuda: '0 = no salta' },
    { k: 'ruta', t: 'texto', e: 'Ruta: puntos que empiezan por', si: (v) => v.tipo === 'riel', ayuda: 'Pon 📍 Puntos de ruta llamados "Riel 1", "Riel 2"… La vagoneta va de uno a otro en orden' },
    { k: 'disparar', t: 'bool', e: 'Puede usar armas montado', ayuda: 'No = guarda el arma mientras va montado' },
    { k: 'terceraPersona', t: 'bool', e: 'Pasar a 3ª persona al montar', ayuda: 'Como en Halo: aunque juegues en 1ª persona, montado se ve desde fuera' },
    { k: 'atropello', t: 'num', e: 'Daño al atropellar', paso: 5, min: 0, ayuda: 'A toda velocidad; menos si va despacio. 0 = no hace daño' },
    { grupo: 'Al bajarse' },
    { k: 'alBajar', t: 'sel', e: 'El vehículo', op: [['quedarse', 'Se queda donde lo dejas'], ['volver', 'Vuelve a su sitio']] },
    { k: 'volverTras', t: 'num', e: 'Vuelve tras (s)', paso: 1, min: 0, si: (v) => v.alBajar === 'volver' },
    { k: 'reaparecer', t: 'bool', e: 'Reaparece si se destruye', si: (v) => v.tipo !== 'bote', ayuda: 'Montura, carro y vagoneta se pierden si entran al agua o la lava: te bajas y ya no se puede usar. Sí = vuelve a su sitio para ir otra vez por él' },
    { k: 'reaparecerTras', t: 'num', e: 'Reaparece tras (s)', paso: 1, min: 0, si: (v) => v.tipo !== 'bote' && v.reaparecer },
    { grupo: 'Cómo se ve' },
    { k: 'modelo', t: 'asset', e: 'Modelo', tipoAsset: 'modelo', vacio: '(figura del motor)' },
    { k: 'escalaModelo', t: 'num', e: 'Escala del modelo', paso: 0.05, min: 0.01, si: (v) => !!v.modelo },
    { k: 'color', t: 'color', e: 'Color' },
    { k: 'asiento', t: 'num', e: 'Altura del asiento (m)', paso: 0.05, min: 0, ayuda: 'Cuánto sube el jugador al montar' },
    { k: 'ocultarJugador', t: 'bool', e: 'Esconder al jugador', ayuda: 'Para vehículos cerrados' },
    { k: 'camara', t: 'num', e: 'Cámara más lejos (m)', paso: 0.25, min: 0 },
    { k: 'sonido', t: 'asset', e: 'Sonido en marcha', tipoAsset: 'audio', vacio: '(ninguno)' },
    { k: 'nombreAccion', t: 'texto', e: 'Texto del botón', ayuda: 'Vacío = "Montar" (montura) o "Subir"' },
  ];

  /* ---------- figura (mirando a -Z, como el jugador) ---------- */
  function figura(ent) {
    const s = { ...MONTABLE, ...(ent.montable || {}) };
    const g = new T.Group();
    const a = s.modelo && F.Assets && F.Assets.mapa.get(s.modelo);
    if (a && a.gltf) { const m = T.SkeletonUtils.clone(a.gltf.scene); m.scale.setScalar(s.escalaModelo || 1); g.add(m); }
    else {
      const mat = (c) => F.Render.matRetro(c);
      const caja = (w, h, d, x, y, z, c) => { const o = new T.Mesh(new T.BoxGeometry(w, h, d), mat(c || s.color)); o.position.set(x, y, z); g.add(o); return o; };
      const osc = new T.Color(s.color).multiplyScalar(0.55).getStyle();
      if (s.tipo === 'montura') {
        caja(0.6, 0.55, 1.5, 0, 1.05, 0);                       // cuerpo
        for (const [x, z] of [[-0.2, -0.55], [0.2, -0.55], [-0.2, 0.55], [0.2, 0.55]]) caja(0.14, 0.85, 0.14, x, 0.42, z, osc);
        const cuello = caja(0.3, 0.75, 0.3, 0, 1.45, -0.72); cuello.rotation.x = -0.5;
        caja(0.3, 0.3, 0.6, 0, 1.75, -1.0);                       // cabeza
        caja(0.08, 0.6, 0.1, 0, 1.3, 0.8, osc);                   // cola
        caja(0.62, 0.08, 0.5, 0, 1.36, 0, '#3a2a1c');             // silla
      } else if (s.tipo === 'carro') {
        caja(1.5, 0.45, 2.5, 0, 0.55, 0);
        caja(1.3, 0.35, 1.0, 0, 0.95, 0.35, osc);                 // asientos
        caja(1.3, 0.4, 0.06, 0, 1.0, -0.4, '#9ad4ff');           // parabrisas
        for (const [x, z] of [[-0.75, -0.85], [0.75, -0.85], [-0.75, 0.85], [0.75, 0.85]]) {
          const r = new T.Mesh(new T.CylinderGeometry(0.32, 0.32, 0.22, 10), mat('#222226')); r.rotation.z = Math.PI / 2; r.position.set(x, 0.32, z); g.add(r);
        }
      } else if (s.tipo === 'bote') {
        caja(1.2, 0.35, 2.6, 0, 0.18, 0);
        caja(0.9, 0.06, 2.2, 0, 0.37, 0, osc);
        const proa = caja(0.85, 0.35, 0.85, 0, 0.18, -1.3); proa.rotation.y = Math.PI / 4; proa.scale.set(1, 1, 1);
      } else {
        caja(1.0, 0.7, 1.4, 0, 0.55, 0);
        caja(0.85, 0.08, 1.25, 0, 0.88, 0, osc);
        for (const [x, z] of [[-0.45, -0.45], [0.45, -0.45], [-0.45, 0.45], [0.45, 0.45]]) {
          const r = new T.Mesh(new T.CylinderGeometry(0.18, 0.18, 0.12, 8), mat('#2a2a2e')); r.rotation.z = Math.PI / 2; r.position.set(x, 0.18, z); g.add(r);
        }
      }
    }
    // caja de choque invisible (aparcado choca; montado no)
    const [w, l, h] = MEDIDAS[s.tipo] || MEDIDAS.montura;
    const choque = new T.Mesh(new T.BoxGeometry(w, h, l), new T.MeshBasicMaterial({ visible: false }));
    choque.position.y = h / 2;
    choque.name = 'choqueMontable';
    g.add(choque);
    g.userData.choque = choque;
    return g;
  }

  const SALTAR = new Set(['salto', 'movimiento', 'agachar', 'esquiva', 'trepar', 'orillas', 'asomarse', 'correrpared', 'sprint', 'nadar', 'interactuar']);

  class Gestor {
    constructor(juego) {
      this.juego = juego;
      this.lista = [];
      for (const ent of juego.escena.entidades) {
        if (ent.tipo !== 'montable') continue;
        const obj = juego.objetos.get(ent.id);
        if (!obj) continue;
        const p = { ...MONTABLE, ...(ent.montable || {}) };
        const it = { ent, obj, p, origen: obj.position.clone(), rot0: obj.rotation.y, v: 0, yaw: obj.rotation.y, tFuera: 0, choque: obj.userData.choque, s: 0 };
        if (p.tipo === 'riel') this._ruta(it);
        this.lista.push(it);
      }
      this.montado = null;
    }

    // la caja de choque, como pieza móvil (la pide Mecanismos.alMundo)
    piezasMoviles() {
      return this.lista.filter((it) => it.choque).map((it) => ({ it, local: F.Fisica.triangulosLocales(it.choque), obj: it.choque, activa: true })).filter((x) => x.local.length);
    }

    _ruta(it) {
      const pre = (it.p.ruta || 'Riel').toLowerCase();
      const pts = this.juego.escena.entidades.filter((e) => e.tipo === 'punto' && (e.nombre || '').toLowerCase().startsWith(pre))
        .sort((a, b) => (a.nombre || '').localeCompare(b.nombre || '', 'es', { numeric: true }))
        .map((e) => { const o = this.juego.objetos.get(e.id); return o ? o.getWorldPosition(new T.Vector3()) : new T.Vector3(...e.pos); });
      it.ruta = pts;
      it.largos = [];
      let tot = 0;
      for (let i = 1; i < pts.length; i++) { tot += pts[i].distanceTo(pts[i - 1]); it.largos.push(tot); }
      it.total = tot;
      // empieza en el punto de la ruta más cercano a donde está
      if (pts.length > 1) { let mejor = 0, d0 = Infinity; pts.forEach((q, i) => { const d = q.distanceTo(it.obj.position); if (d < d0) { d0 = d; mejor = i; } }); it.s = mejor ? it.largos[mejor - 1] : 0; }
    }
    _enRuta(it, s, out) {
      const P = it.ruta, L = it.largos;
      let i = 0; while (i < L.length - 1 && L[i] < s) i++;
      const a = i ? L[i - 1] : 0, k = (s - a) / ((L[i] - a) || 1);
      out.lerpVectors(P[i], P[i + 1], Math.max(0, Math.min(1, k)));
      return Math.atan2(-(P[i + 1].x - P[i].x), -(P[i + 1].z - P[i].z));
    }

    textoUsar(it) { return it.p.nombreAccion || (it.p.tipo === 'montura' ? 'Montar' : 'Subir') + (it.ent.nombre ? ' ' + it.ent.nombre : ''); }

    montar(it) {
      const J = this.juego, j = J.jugador, c = j.cuerpo;
      if (it.roto) return false;
      if (it.p.tipo === 'bote') { const o = it.obj.position; if (!this._agua(o.x, o.y - 0.1, o.z) && !this._agua(o.x, o.y + 0.25, o.z)) return false; }
      it.guarda = { radio: c.radio, escalon: c.escalon };
      const [w, l] = MEDIDAS[it.p.tipo] || MEDIDAS.montura;
      if (it.p.tipo === 'montura' || it.p.tipo === 'carro') { c.radio = Math.max(c.radio, Math.min(w, l) * 0.5); c.escalon = it.p.tipo === 'montura' ? 0.55 : 0.35; }
      if (it.pieza) it.pieza.activa = false;
      it.yaw = it.obj.rotation.y; it.v = 0; it.tFuera = 0;
      const o = it.obj.position;
      if (it.p.tipo === 'montura' || it.p.tipo === 'carro') j.teletransportar(o.x, o.y + 0.05, o.z, it.yaw, j.pitch);
      else { c.pie.copy(o); c.velocidad.set(0, 0, 0); c.visY = o.y; }
      j.montado = it;
      j.camExtra = it.p.camara || 0;
      if (it.p.terceraPersona !== false && j.modoCamara !== 'tps') { it.camAntes = j.modoCamara; j.modoCamara = 'tps'; } else it.camAntes = null;
      this.montado = it;
      if (it.p.sonido && F.Audio.fuente) { it.audio = F.Audio.fuente(it.p.sonido, true); if (it.audio) { it.audio.poner(0.5, 0); it.audio.tocar(); } }
      F.Audio.sintetico('recoger', { volumen: 0.4, tono: 0.5 });
      return true;
    }

    desmontar(forzar) {
      const it = this.montado; if (!it) return;
      const J = this.juego, j = J.jugador, c = j.cuerpo, M = J.mundo, P = c.pie;
      const [w] = MEDIDAS[it.p.tipo] || MEDIDAS.montura, d = w * 0.5 + (it.guarda ? it.guarda.radio : 0.35) + 0.35;
      const fx = -Math.sin(it.yaw), fz = -Math.cos(it.yaw);
      // a la derecha, a la izquierda, detrás o delante: donde haya suelo y no haya pared
      let sitio = null;
      const lejos = it.p.tipo === 'bote' ? [1, 1.7, 2.4] : [1];   // del bote: a la orilla, aunque esté un poco lejos
      for (const k of lejos) for (const [dx, dz] of [[-fz, fx], [fz, -fx], [-fx, -fz], [fx, fz]]) {
        if (sitio) break;
        const x = P.x + dx * d * k, z = P.z + dz * d * k;
        if (M.rayo(P.x, P.y + 0.8, P.z, dx, 0, dz, d * k)) continue;
        const g = M.rayo(x, P.y + 1.5, z, 0, -1, 0, 4);
        if (!g || this._agua(x, P.y + 1.5 - g.t + 0.2, z)) continue;
        sitio = [x, P.y + 1.5 - g.t + 0.02, z];
      }
      if (!sitio && !forzar) { F.Audio.sintetico('golpe', { volumen: 0.3, tono: 0.6 }); return; }
      if (it.guarda) { c.radio = it.guarda.radio; c.escalon = it.guarda.escalon; }
      j.montado = null; j.camExtra = 0; this.montado = null;
      if (it.camAntes) { j.modoCamara = it.camAntes; it.camAntes = null; }
      if (it.audio) { try { it.audio.parar(); it.audio.quitar(); } catch (e) { /* nada */ } } it.audio = null;
      it.v = 0; it.tFuera = 0;
      this._colocar(it);
      if (it.pieza) { it.pieza.activa = true; M.moverPieza(it.pieza); }
      if (sitio) j.teletransportar(sitio[0], sitio[1], sitio[2], j.yaw, j.pitch);
    }

    _agua(x, y, z) { const A = this.juego.agua; return A && A.lista.length ? A.en(x, y, z) : null; }

    /* lo llama jugador.js en su fase de física (después de los módulos) */
    conducir(j, dt) {
      const it = this.montado; if (!it || j.muerto) return;
      const E = F.Entrada, p = it.p, c = j.cuerpo;
      const my = E.mover.y, mx = E.mover.x;
      const meta = my > 0.1 ? my * p.velocidad : my < -0.1 ? my * p.reversa : 0;
      const acc = (Math.sign(meta) !== Math.sign(it.v) && it.v !== 0 ? p.aceleracion * 2 : p.aceleracion) * dt;
      it.v += Math.max(-acc, Math.min(acc, meta - it.v));
      if (p.tipo !== 'riel') {
        // el carro y el bote giran según la marcha (parado casi no gira); la montura gira siempre
        const k = p.tipo === 'montura' ? 1 : Math.min(1, Math.abs(it.v) / 2.5) * Math.sign(it.v || 1);
        it.yaw -= mx * p.giro * Math.PI / 180 * dt * k;
      }
      it.giroVis = (it.giroVis || 0) + (mx - (it.giroVis || 0)) * Math.min(1, dt * 8);   // para la postura del jinete
      it.saltando = !c.enSuelo && (p.tipo === 'montura' || p.tipo === 'carro');
      const fx = -Math.sin(it.yaw), fz = -Math.cos(it.yaw);
      if (p.tipo === 'montura' || p.tipo === 'carro') {
        c.velocidad.x = fx * it.v; c.velocidad.z = fz * it.v;
        if (p.tipo === 'montura' && p.salto > 0 && c.enSuelo && E.pulsado('saltar')) c.velocidad.y = p.salto;
        it.fijo = false;
      } else if (p.tipo === 'bote') {
        const nx = c.pie.x + fx * it.v * dt, nz = c.pie.z + fz * it.v * dt;
        const w = this._agua(nx, c.pie.y + 0.3, nz) || this._agua(nx, c.pie.y - 0.2, nz);
        if (w) { c.pie.x = nx; c.pie.z = nz; c.pie.y = w.top - 0.12; } else it.v = 0;   // la orilla lo para
        c.velocidad.set(0, 0, 0); c.visY = c.pie.y; it.fijo = true;
      } else {
        if (it.ruta && it.ruta.length > 1) {
          it.s += it.v * dt;
          if (it.s <= 0 || it.s >= it.total) { it.s = Math.max(0, Math.min(it.total, it.s)); it.v = 0; }
          it.yaw = this._enRuta(it, it.s, c.pie);
        }
        c.velocidad.set(0, 0, 0); c.visY = c.pie.y; it.fijo = true;
      }
    }

    _colocar(it) {
      const o = it.obj;
      if (it === this.montado) {
        const c = this.juego.jugador.cuerpo;
        o.position.set(c.pie.x, (it.fijo ? c.pie.y : c.visY), c.pie.z);
      }
      o.rotation.y = it.yaw;
    }

    actualizar(dt) {
      if (!this.lista.length) return;
      const J = this.juego, j = J.jugador, E = F.Entrada;
      if (!j) return;
      let aviso = '';
      if (this.montado) {
        const it = this.montado;
        // la velocidad real (tras chocar con paredes) manda
        if (!it.fijo) { const c = j.cuerpo; const real = c.velocidad.x * -Math.sin(it.yaw) + c.velocidad.z * -Math.cos(it.yaw); if (Math.abs(real) < Math.abs(it.v)) it.v = real; }
        this._colocar(it);
        // 💦 al agua (o lava): se pierde y te bajas (el bote no)
        if (it.p.tipo !== 'bote') { const c = j.cuerpo; if (this._agua(c.pie.x, c.pie.y + 0.15, c.pie.z)) { this.desmontar(true); this._romper(it); this._aviso(''); return; } }
        if (it.p.tipo === 'montura' && Math.abs(it.v) > 0.5) it.obj.position.y += Math.abs(Math.sin(this.t = (this.t || 0) + dt * it.v * 1.4)) * 0.06;   // trote
        if (it.p.atropello > 0 && Math.abs(it.v) > 2.5) this._atropellar(it, dt);
        if (j.muerto) this.desmontar(true);
        else if (Math.abs(it.v) < 1.5) {
          aviso = this._tecla() + 'Bajar';
          if (E.pulsado('interactuar')) this.desmontar(false);
        }
      } else if (!j.muerto) {
        const EM = J.empujables, ocupado = EM && (EM.cargado || EM.agarre || EM._tAviso);
        const P = j.cuerpo.pie;
        for (const it of this.lista) {
          if (it.roto) {
            it.tRoto += dt;
            if (it.obj.visible) {
              const k = Math.min(1, it.tRoto / 0.5);
              it.obj.rotation.z = it.lado * (Math.PI / 2) * (1 - (1 - k) * (1 - k));   // cae de costado
              if (it.hunde) it.obj.position.y -= dt * 0.5;
              if (it.tRoto > 2.5) it.obj.visible = false;
            }
            if (it.p.reaparecer !== false && it.tRoto >= Math.max(2.6, it.p.reaparecerTras ?? 5)) this._reponer(it);
            continue;
          }
          // vuelve a su sitio si así se eligió
          if (it.p.alBajar === 'volver' && !it.obj.position.equals(it.origen)) {
            it.tFuera += dt;
            if (it.tFuera >= it.p.volverTras) { it.obj.position.copy(it.origen); it.yaw = it.rot0; it.obj.rotation.y = it.rot0; it.tFuera = 0; if (it.p.tipo === 'riel') this._ruta(it); if (it.pieza) J.mundo.moverPieza(it.pieza); }
          }
          if (ocupado || aviso) continue;
          const o = it.obj.position, [w, l] = MEDIDAS[it.p.tipo] || MEDIDAS.montura;
          const alc = Math.max(w, l) * 0.5 + (it.p.tipo === 'bote' ? 2.2 : 1.1);   // al bote se sube desde la orilla o nadando
          if ((o.x - P.x) ** 2 + (o.z - P.z) ** 2 > alc * alc || Math.abs(o.y - P.y) > 2.2) continue;
          aviso = this._tecla() + this.textoUsar(it);
          if (E.pulsado('interactuar')) { this.montar(it); aviso = ''; }
        }
      }
      this._aviso(aviso);
    }

    // 💥 destruido: desaparece y no se puede usar (hasta que reaparezca, si se eligió)
    _romper(it) {
      it.roto = true; it.tRoto = 0; it.v = 0;
      // 💥 animación: se voltea de lado (½ s), queda tirado (o se hunde en el agua) y a los 2,5 s desaparece
      const o = it.obj.position;
      it.hunde = !!this._agua(o.x, o.y + 0.2, o.z);
      it.lado = Math.random() < 0.5 ? 1 : -1;
      if (it.pieza) it.pieza.activa = false;
      F.Audio.sintetico('impacto', { volumen: 0.6, tono: 0.5 });
    }
    _reponer(it) {
      const M = this.juego.mundo;
      it.roto = false; it.tFuera = 0;
      it.obj.position.copy(it.origen); it.yaw = it.rot0; it.obj.rotation.y = it.rot0; it.obj.rotation.z = 0;
      it.obj.visible = true;
      if (it.p.tipo === 'riel') this._ruta(it);
      if (it.pieza) { it.pieza.activa = true; M.moverPieza(it.pieza); }
    }

    _atropellar(it, dt) {
      const G = this.juego.enemigos; if (!G) return;
      const P = this.juego.jugador.cuerpo.pie, [w, l] = MEDIDAS[it.p.tipo] || MEDIDAS.montura, r = Math.max(w, l) * 0.5;
      for (const E of G.lista) {
        if (E.muerto || E.reserva || E.c.actitud === 'aliado') continue;
        if ((E.tAtrop || 0) > G.t) continue;
        const q = E.cuerpo.pie, dx = q.x - P.x, dz = q.z - P.z;
        if (dx * dx + dz * dz > (r + E.c.radio) ** 2 || Math.abs(q.y - P.y) > 1.5) continue;
        E.tAtrop = G.t + 0.6;
        G.danar(E, it.p.atropello * Math.min(1, Math.abs(it.v) / it.p.velocidad), { tipo: 'normal' });
        if (G.aturdir) G.aturdir(E, 0.6);
        F.Audio.sintetico('impacto', { volumen: 0.6, tono: 0.7 });
      }
    }

    _tecla() {
      if (!(this._tT > 0)) { this._tT = 1; this._t0 = F.Tactil && F.Tactil.visible ? '' : F.Entrada.textoTeclado('interactuar').split(' / ')[0] + ': '; }
      this._tT -= 1 / 60;
      return this._t0;
    }
    _aviso(t) {
      if (!this.avisoEl) { this.avisoEl = F.Hud.pieza(this.juego, 'fmt-aviso'); this.avisoEl.classList.add('fh-aviso'); }
      if (this._tAviso === t) return;
      this._tAviso = t;
      this.avisoEl.textContent = t || '';
      this.avisoEl.style.display = t ? 'block' : 'none';
      if (F.Tactil) F.Tactil.ponerContexto('interactuar', !!t);
    }

    detener() {
      if (this.montado) this.desmontar(true);
      for (const it of this.lista) { it.obj.position.copy(it.origen); it.obj.rotation.y = it.rot0; it.obj.rotation.z = 0; it.obj.visible = true; it.roto = false; }
      if (this.avisoEl) this.avisoEl.style.display = 'none';
    }
  }

  F.Montables = { MONTABLE, TIPOS, PRESETS, ESQUEMA, SALTAR, figura, Gestor };
})(window.FORJA);
