/* =========================================================
   FORJA · ✨ PARTÍCULAS (entidad "particulas": humo, chispas, fuego, polvo)
   Un solo dibujo por emisor: un lote de puntos que se mueven EN LA GPU con el tiempo (uTiempo de render.js).
   La CPU no toca nada cada cuadro: cada punto tiene una semilla y el shader calcula su vida, posición y tamaño.
   Puntos cuadrados con borde duro (estilo PS1), del tamaño correcto a cualquier resolución.
     F.Particulas.figura(ent) · F.Particulas.PARTICULAS (valores de serie) · F.Particulas.ESQ
   ========================================================= */
(function (F) {
  'use strict';
  const T = THREE;
  const MODOS = { humo: 0, chispas: 1, fuego: 2, polvo: 3, hojas: 4 };
  const PRESET = {
    humo: { color: '#8a8a8a', color2: '#4a4a4a', cantidad: 40, radio: 0.4, alto: 3, tam: 0.5, velocidad: 0.5 },
    chispas: { color: '#ffe08a', color2: '#ff6a1a', cantidad: 50, radio: 0.2, alto: 1, tam: 0.06, velocidad: 1.5 },
    fuego: { color: '#ffd23a', color2: '#ff3a0a', cantidad: 60, radio: 0.35, alto: 1.2, tam: 0.3, velocidad: 1.2 },
    polvo: { color: '#cbb894', color2: '#9a8a6a', cantidad: 60, radio: 3, alto: 2, tam: 0.05, velocidad: 0.3 },
    hojas: { color: '#d0a03a', color2: '#7a9a2a', cantidad: 40, radio: 6, alto: 6, tam: 0.2, velocidad: 0.25 },
  };
  const PARTICULAS = { tipo: 'humo', ...PRESET.humo, cuadradas: true, activa: true };
  const ESQ = [
    { k: 'tipo', t: 'sel', e: 'Tipo', def: 'humo', op: [['humo', '💨 Humo'], ['chispas', '✨ Chispas'], ['fuego', '🔥 Fuego'], ['polvo', '🌫 Polvo flotando'], ['hojas', '🍃 Hojas al viento']],
      ayuda: 'Elegir el tipo pone sus valores de serie (colores, cantidad, tamaño…)' },
    { k: 'color', t: 'color', e: 'Color al nacer', def: PRESET.humo.color },
    { k: 'color2', t: 'color', e: 'Color al morir', def: PRESET.humo.color2 },
    { k: 'cantidad', t: 'num', e: 'Cantidad', def: 40, paso: 5, min: 1, max: 400, ayuda: 'Puntos del lote. Todo es un solo dibujo: 100 cuestan casi lo mismo que 10' },
    { k: 'radio', t: 'num', e: 'Radio de salida (m)', def: 0.4, paso: 0.1, min: 0.05 },
    { k: 'alto', t: 'num', e: 'Altura que sube (m)', def: 3, paso: 0.25, min: 0.1, ayuda: 'Polvo: altura de la zona donde flota' },
    { k: 'tam', t: 'num', e: 'Tamaño (m)', def: 0.5, paso: 0.02, min: 0.01 },
    { k: 'velocidad', t: 'num', e: 'Velocidad', def: 0.5, paso: 0.1, min: 0.05 },
    { k: 'cuadradas', t: 'bool', e: 'Cuadradas (PS1)', def: true, ayuda: 'Apagado: redondas' },
    { k: 'activa', t: 'bool', e: 'Encendidas al empezar', def: true,
      ayuda: 'Apagado: no salen hasta que las encienda una palanca, un disparador o una cinemática (acción ✨ Encender partículas)' },
  ];

  function figura(ent) {
    const c = { ...PARTICULAS, ...(ent.particulas || {}) };
    const g = new T.Group();
    const n = Math.max(1, Math.min(400, Math.round(c.cantidad)));
    const pos = new Float32Array(n * 3), sem = new Float32Array(n * 4);
    for (let i = 0; i < n * 4; i++) sem[i] = Math.random();
    const geo = new T.BufferGeometry();
    geo.setAttribute('position', new T.BufferAttribute(pos, 3));
    geo.setAttribute('aS', new T.BufferAttribute(sem, 4));
    geo.boundingSphere = new T.Sphere(new T.Vector3(0, c.alto * 0.5, 0), c.radio + c.alto + 1);
    const modo = MODOS[c.tipo] ?? 0, suma = modo === 1 || modo === 2;
    const mat = new T.ShaderMaterial({
      uniforms: {
        uT: F.Render.U.uTiempo, uVel: { value: c.velocidad }, uRad: { value: c.radio }, uAlto: { value: c.alto }, uTam: { value: c.tam },
        uModo: { value: modo }, uAltoPx: { value: 480 }, uC1: { value: new T.Color(c.color) }, uC2: { value: new T.Color(c.color2) },
        uCuadro: { value: c.cuadradas !== false ? 1 : 0 }, uViento: F.Render.U.uViento,
      },
      vertexShader: `
        uniform float uT; uniform float uVel; uniform float uRad; uniform float uAlto; uniform float uTam; uniform float uModo; uniform float uAltoPx; uniform vec4 uViento;
        attribute vec4 aS;
        varying float vVida;
        varying float vCerca;
        varying float vGiro;
        varying float vA;
        void main() {
          float v = fract(uT * uVel * 0.35 + aS.w);
          vVida = v;
          vec3 p = vec3((aS.x - 0.5) * 2.0 * uRad, 0.0, (aS.z - 0.5) * 2.0 * uRad);
          float tam = uTam;
          vGiro = 0.0; vA = 1.0;
          if (uModo < 0.5) {            // humo: sube, se abre y crece
            p.y = v * uAlto; p.xz *= 1.0 + v * 1.5; p.x += sin(uT * 0.7 + aS.y * 6.28) * 0.25 * v; tam *= 0.4 + 1.6 * v;
          } else if (uModo < 1.5) {     // chispas: salen disparadas y caen
            vec3 d = normalize(vec3(aS.x - 0.5, 0.5 + aS.y, aS.z - 0.5));
            float t = v * 1.4;
            p = d * (2.0 + 3.0 * aS.y) * uVel * t * 0.6 + vec3(0.0, -4.9 * t * t, 0.0);
            tam *= 1.0 - v * 0.8;
          } else if (uModo < 2.5) {     // fuego: sube rápido y se cierra hacia la punta
            p.xz *= 1.0 - v * 0.9; p.y = v * uAlto * (0.6 + 0.4 * aS.y); p.x += sin(uT * 5.0 + aS.y * 9.0) * 0.05; tam *= 1.0 - v * 0.75;
          } else if (uModo > 3.5) {     // 🍃 hojas: caen meciéndose y dando vueltas; el viento del nivel se las lleva
            p.y = uAlto * (1.0 - v);
            float bal = sin(uT * 1.7 + aS.y * 6.28);
            p.x += bal * 0.6; p.z += cos(uT * 1.3 + aS.x * 6.28) * 0.4;
            p.xz += uViento.xy * (uViento.z * (1.0 + uViento.w)) * v * uAlto * 1.6;
            vGiro = uT * (2.0 + 3.0 * aS.y) + aS.x * 6.28;
            vA = smoothstep(0.0, 0.08, v) * (1.0 - smoothstep(0.85, 1.0, v));
            vVida = aS.y;                // color de cada hoja: entre los dos colores
          } else {                      // polvo: flota despacio en la zona
            p.y = aS.y * uAlto + sin(uT * 0.4 + aS.w * 6.28) * 0.3; p.x += sin(uT * 0.25 + aS.y * 5.0) * 0.5; p.z += cos(uT * 0.2 + aS.x * 5.0) * 0.5;
            vVida = 0.5 + 0.5 * sin(uT + aS.w * 6.28) * 0.5;
          }
          vec4 mv = modelViewMatrix * vec4(p, 1.0);
          gl_Position = projectionMatrix * mv;
          // tope en pantalla (12% del alto): pegado a la cámara un punto llenaría media pantalla y se pintaría muchas veces
          gl_PointSize = clamp(tam * projectionMatrix[1][1] * uAltoPx * 0.5 / max(-mv.z, 0.05), 1.0, uAltoPx * 0.12);
          vCerca = smoothstep(0.4, 1.6, -mv.z);   // se desvanece al acercarse a la cámara
        }`,
      fragmentShader: `
        uniform vec3 uC1; uniform vec3 uC2; uniform float uModo; uniform float uCuadro;
        varying float vVida;
        varying float vCerca;
        varying float vGiro;
        varying float vA;
        void main() {
          if (vCerca < 0.02) discard;
          vec2 q = gl_PointCoord - 0.5;
          if (uModo > 3.5) {
            // 🍃 hoja: rombo que gira y se aplana al voltearse (parece que da vueltas en el aire)
            float cg = cos(vGiro), sg = sin(vGiro);
            vec2 r = vec2(cg * q.x - sg * q.y, sg * q.x + cg * q.y);
            float ancho = 0.12 + 0.3 * abs(sin(vGiro * 0.7));
            if (abs(r.x) / ancho + abs(r.y) / 0.48 > 1.0) discard;
            gl_FragColor = vec4(mix(uC1, uC2, vVida) * (0.75 + 0.25 * step(0.0, r.x)), vA * vCerca);
            return;
          }
          if (uCuadro < 0.5 && dot(q, q) > 0.25) discard;
          float a = uModo < 0.5 ? (1.0 - vVida) * 0.55 * smoothstep(0.0, 0.1, vVida)
                  : uModo < 1.5 ? 1.0 - vVida * 0.5
                  : uModo < 2.5 ? 1.0 - vVida
                  : 0.35 * vVida;
          gl_FragColor = vec4(mix(uC1, uC2, vVida), a * vCerca);
        }`,
      transparent: true, depthWrite: false, blending: suma ? T.AdditiveBlending : T.NormalBlending,
    });
    const pts = new T.Points(geo, mat);
    const tmp = new T.Vector2();
    pts.onBeforeRender = (r) => {
      const rt = r.getRenderTarget();   // con efectos de cámara se dibuja en la textura retro
      if (rt) tmp.set(rt.width, rt.height); else r.getDrawingBufferSize(tmp);
      mat.uniforms.uAltoPx.value = tmp.y;
    };
    pts.raycast = () => {};
    g.add(pts);
    // ayuda del editor: un rombo para poder elegirlo
    const ayuda = new T.Mesh(new T.OctahedronGeometry(0.15), new T.MeshBasicMaterial({ color: c.color, wireframe: true }));
    ayuda.userData.ayudaEditor = true;
    g.add(ayuda);
    return g;
  }

  /* ✨ Al jugar: encender / apagar un emisor (solo se esconde su material: el gestor de lo tapado no lo toca) */
  function puntos(juego, id) {
    const g = juego.objetos.get(id);
    return g ? g.children.find((o) => o.isPoints) : null;
  }
  function encender(juego, id, on) {
    const p = puntos(juego, id);
    if (!p) return;
    p.material.visible = on === 'alternar' ? !p.material.visible : !!on;
  }
  // al empezar el nivel: las que empiezan apagadas
  function preparar(juego) {
    for (const e of juego.escena.entidades) if (e.tipo === 'particulas' && e.particulas && e.particulas.activa === false) encender(juego, e.id, false);
  }

  F.Particulas = { PARTICULAS, PRESET, ESQ, figura, encender, preparar };
})(window.FORJA);
