/* =========================================================
   FORJA · RENDER
   Renderer, luces, material retro PS1/N64 y resolución interna.
   ========================================================= */
(function (F) {
  'use strict';
  const T = THREE;

  /* ---------- Uniforms compartidos por todos los materiales retro ---------- */
  const U = {
    uSnapGrid: { value: new T.Vector2(160, 120) },
    uSnap: { value: 0 },
    uAffine: { value: 0 },
    uDither: { value: 0 },
    // Niebla PS1 (lineal como tu camera_3dretro.gd, opcionalmente por vértice y en bandas)
    uNieblaCerca: { value: 12 },
    uNieblaLejos: { value: 45 },
    uNieblaVertice: { value: 0 },
    uNieblaPasos: { value: 0 },
    uTiempo: { value: 0 },   // segundos, para texturas que fluyen (agua, lava)
    // 🌬 viento del nivel (Escena ▸ Ambiente ▸ Viento): x, z = dirección hacia donde sopla · z = fuerza 0..1 · w = ráfaga 0..1
    uViento: { value: new T.Vector4(1, 0, 0, 0) },
    // 🎌 cel shading (motor/efectos.js, estilo Anime): la luz en escalones duros. 0 = luz normal
    uToon: { value: 0 },
    uToonSombra: { value: 0.45 },   // lo más oscuro que queda la sombra (anime: sombras claras)
    // 🔦 linterna proyectada (jugador/modulos/linterna.js): un cono con textura que se pinta encima de TODO material
    // retro, también de lo horneado (que ya no tiene luces). uLinI = 0 → apagada (no cuesta casi nada)
    uLinI: { value: 0 },
    uLinSolo: { value: 0 },          // 1 = solo en lo horneado (modo "Luz de verdad": el resto lo alumbra el foco)
    uLinBandas: { value: 6 },        // escalones de luz (PS1); 0 = suave
    uLinPos: { value: new T.Vector3() },
    uLinDir: { value: new T.Vector3(0, 0, -1) },
    uLinDer: { value: new T.Vector3(1, 0, 0) },
    uLinArr: { value: new T.Vector3(0, 1, 0) },
    uLinTan: { value: 0.3 },
    uLinAlc: { value: 18 },
    uLinEsfera: { value: 0 },   // 1 = antorcha: luz alrededor (sin cono ni textura)
    uLinColor: { value: new T.Color(1, 1, 1) },
    uLinTex: { value: null },
  };

  /* Texturas de la linterna: 32×32 en píxeles grandes (sin filtro), fijas, hechas una vez. El blanco es luz.
     redonda: disco con escalones y borde marcado · anillo: centro, anillo brillante y halo flojo (reflector)
     vieja: disco desigual con manchas (cristal sucio) · suave: degradado (lo usa el modo luz de verdad) */
  const _texLin = {};
  function texLinterna(tipo, suave) {
    const clave = tipo + (tipo === 'suave' ? suave : '');
    if (_texLin[clave]) return _texLin[clave];
    const N = 32, cv = document.createElement('canvas');
    cv.width = cv.height = N;
    const cx = cv.getContext('2d'), img = cx.createImageData(N, N);
    let semilla = 7;
    const azar = () => ((semilla = (semilla * 16807) % 2147483647) / 2147483647);
    const manchas = [];
    if (tipo === 'vieja') for (let i = 0; i < 7; i++) manchas.push([4 + azar() * 24, 4 + azar() * 24, 1.5 + azar() * 3, 0.35 + azar() * 0.35]);
    for (let y = 0; y < N; y++) for (let x = 0; x < N; x++) {
      const dx = x + 0.5 - N / 2, dy = y + 0.5 - N / 2, r = Math.hypot(dx, dy) / (N / 2);   // 0 centro · 1 borde
      let v = 0;
      if (tipo === 'anillo') v = r < 0.25 ? 1 : r < 0.55 ? 0.55 : r < 0.7 ? 0.9 : r < 0.9 ? 0.45 : r < 1 ? 0.2 : 0;
      else if (tipo === 'vieja') {
        const r2 = Math.hypot(dx - 2, dy + 1.5) / (N / 2);   // centro corrido: bombilla torcida
        v = r < 0.95 ? (r2 < 0.3 ? 1 : r2 < 0.6 ? 0.75 : 0.5) : 0;
        for (const [mx, my, mr, mk] of manchas) if (Math.hypot(x - mx, y - my) < mr) v *= mk;
      } else if (tipo === 'suave') {
        const borde = Math.max(0.05, suave || 0.45);
        v = r >= 1 ? 0 : Math.min(1, (1 - r) / borde);
      } else v = r < 0.4 ? 1 : r < 0.65 ? 0.8 : r < 0.85 ? 0.6 : r < 1 ? 0.4 : 0;
      const o = (y * N + x) * 4;
      img.data[o] = img.data[o + 1] = img.data[o + 2] = Math.round(v * 255);
      img.data[o + 3] = 255;
    }
    cx.putImageData(img, 0, 0);
    const t = new T.CanvasTexture(cv);
    t.magFilter = T.NearestFilter; t.minFilter = T.NearestFilter; t.generateMipmaps = false;
    t.wrapS = t.wrapT = T.ClampToEdgeWrapping;
    return (_texLin[clave] = t);
  }

  const texturas = new Set();
  let filtroN64 = false;

  function aplicarFiltro(tex) {
    tex.magFilter = filtroN64 ? T.LinearFilter : T.NearestFilter;
    tex.minFilter = filtroN64 ? T.LinearMipmapLinearFilter : T.NearestMipmapNearestFilter;
    tex.needsUpdate = true;
  }

  function registrarTextura(tex) {
    if (!tex || texturas.has(tex)) return;
    texturas.add(tex);
    aplicarFiltro(tex);
  }

  /* ---------- Material retro ----------
     Parche sobre los shaders de Three.js:
     - temblor de vértices (snap a la rejilla de píxeles, como la PS1)
     - textura afín (deformación sin corrección de perspectiva)
     - dither Bayer 4×4 + color de 15 bits
     Funciona con mapa de color, mapa normal y colores de vértice. */
  /* 💡 Luz por vértice (Gouraud, como la PS1): las luces de PUNTO (lámparas, antorchas, entidades 💡) se calculan en
     cada vértice y se interpolan; en cada píxel solo quedan el sol, el ambiente y los focos (linterna). Con modelos
     low poly cuesta muchísimo menos GPU que por píxel (16 luces × cada píxel). Ajuste del proyecto: Render ▸ luzVertice */
  const LUZ = { vertice: true };
  const chunkLuces = () => {
    const c = T.ShaderChunk.lights_fragment_begin;
    const ini = c.indexOf('#if ( NUM_POINT_LIGHTS > 0 ) && defined( RE_Direct )');
    const fin = c.indexOf('#endif', c.indexOf('#pragma unroll_loop_end', ini)) + 6;
    if (ini < 0 || fin < 6) return null;
    return c.slice(0, ini) + `
      #if ( NUM_POINT_LIGHTS > 0 )
        reflectedLight.directDiffuse += vLuzPV * BRDF_Lambert( material.diffuseColor );
      #endif
    ` + c.slice(fin);
  };
  let _chunk = null;

  function hacerRetro(mat) {
    if (mat.userData.retro) return mat;
    mat.userData.retro = true;
    mat.userData.uDesplazUV = mat.userData.uDesplazUV || { value: new T.Vector2(0, 0) };
    mat.userData.uEsHorneado = mat.userData.uEsHorneado || { value: 0 };
    movUniformes(mat);
    mat.onBeforeCompile = (sh) => {
      if (!U.uLinTex.value) U.uLinTex.value = texLinterna('redonda');
      Object.assign(sh.uniforms, U);
      sh.uniforms.uEsHorneado = mat.userData.uEsHorneado;
      // la linterna solo en lo que es superficie (sprites, auras y halos no: su vértice no da la posición)
      const linOk = sh.vertexShader.includes('#include <project_vertex>') && !mat.isSpriteMaterial && !mat.isPointsMaterial && mat.blending !== T.AdditiveBlending;
      // luz por vértice: solo en materiales con luz (Lambert / Standard) que tengan el trozo de luces
      const pv = LUZ.vertice && sh.fragmentShader.includes('#include <lights_fragment_begin>') && sh.vertexShader.includes('#include <project_vertex>')
        && (_chunk || (_chunk = chunkLuces()));
      if (pv) {
        sh.vertexShader = 'varying vec3 vLuzPV;\n' + sh.vertexShader.replace('#include <common>', '#include <common>\n#include <lights_pars_begin>').replace('#include <project_vertex>', `#include <project_vertex>
          vLuzPV = vec3( 0.0 );
          #if ( NUM_POINT_LIGHTS > 0 )
            vec3 nPV = normalize( transformedNormal );
            IncidentLight ilPV;
            for ( int i = 0; i < NUM_POINT_LIGHTS; i ++ ) {
              getPointLightInfo( pointLights[ i ], mvPosition.xyz, ilPV );
              vLuzPV += ilPV.color * max( dot( nPV, ilPV.direction ), 0.0 );
            }
          #endif`);
        sh.fragmentShader = 'varying vec3 vLuzPV;\n' + sh.fragmentShader.replace('#include <lights_fragment_begin>', _chunk);
      }
      sh.uniforms.uDesplazUV = mat.userData.uDesplazUV;
      Object.assign(sh.uniforms, mat.userData.mov);
      // 🌊 movimiento por vértices (oleaje, viento, ondear): en la GPU, solo si el material lo tiene (#define)
      sh.vertexShader = sh.vertexShader.replace('#include <begin_vertex>', '#include <begin_vertex>\n' + VERT_MOV);
      sh.vertexShader =
        '#if defined(MOV_OLAS) || defined(MOV_VIENTO) || defined(MOV_ONDEAR)\nuniform float uTiempo;\nuniform vec4 uViento;\nuniform vec4 uMovO;\nuniform vec4 uMovV;\nuniform vec4 uMovVD;\nuniform vec4 uMovF;\n#endif\n' +
        'uniform vec2 uSnapGrid;\nuniform float uSnap;\nuniform float uNieblaCerca;\nuniform float uNieblaLejos;\n' +
        'varying vec2 vAffUv;\nvarying float vAffW;\nvarying float vNieblaVert;\nvarying vec3 vLinMundo;\n' +
        sh.vertexShader
          .replace('#include <fog_vertex>', `#include <fog_vertex>
            vNieblaVert = clamp((-mvPosition.z - uNieblaCerca) / max(uNieblaLejos - uNieblaCerca, 0.001), 0.0, 1.0);`)
          .replace('#include <project_vertex>', `#include <project_vertex>
          {
            vec4 wpLin = vec4(transformed, 1.0);
            #ifdef USE_BATCHING
              wpLin = batchingMatrix * wpLin;
            #endif
            #ifdef USE_INSTANCING
              wpLin = instanceMatrix * wpLin;
            #endif
            vLinMundo = (modelMatrix * wpLin).xyz;
          }
          if (uSnap > 0.0) {
            vec4 sp = gl_Position;
            sp.xyz /= sp.w;
            vec2 rejillaSnap = uSnapGrid / (0.25 + 1.75 * uSnap);
            sp.xy = floor(sp.xy * rejillaSnap + 0.5) / rejillaSnap;
            sp.xyz *= sp.w;
            gl_Position = sp;
          }
          vAffW = gl_Position.w;
          vAffUv = vec2(0.0);
          #ifdef USE_MAP
            vAffUv = vMapUv * gl_Position.w;
          #endif`);
      sh.fragmentShader =
        `uniform float uAffine;
         uniform float uDither;
         uniform float uNieblaCerca;
         uniform float uNieblaLejos;
         uniform float uNieblaVertice;
         uniform float uNieblaPasos;
         uniform float uTiempo;
         uniform vec2 uDesplazUV;
         uniform vec4 uMovU;
         uniform float uLinI;
         uniform float uLinSolo;
         uniform float uLinBandas;
         uniform float uEsHorneado;
         uniform vec3 uLinPos;
         uniform vec3 uLinDir;
         uniform vec3 uLinDer;
         uniform vec3 uLinArr;
         uniform float uLinTan;
         uniform float uLinAlc;
         uniform float uLinEsfera;
         uniform vec3 uLinColor;
         uniform sampler2D uLinTex;
         varying vec2 vAffUv;
         varying float vAffW;
         varying float vNieblaVert;
         varying vec3 vLinMundo;
         float bayer2(vec2 p) { return 2.0 * p.x + 3.0 * p.y - 4.0 * p.x * p.y; }
         float bayer4(vec2 p) {
           p = floor(mod(p, 4.0));
           return (4.0 * bayer2(mod(p, 2.0)) + bayer2(floor(p / 2.0))) / 16.0;
         }\n` +
        (linOk ? '#define LIN_OK\n' : '') + (sh.fragmentShader.includes('#include <lights_fragment_begin>') ? '#define TOON_OK\n' : '') + sh.fragmentShader
          .replace('#include <map_fragment>', `
            #ifdef USE_MAP
              vec2 uvRetro = mix(vMapUv, vAffUv / vAffW, uAffine) + uDesplazUV * uTiempo;
              #ifdef MOV_ONDULAR
                // 〰 la textura se deforma en ondas (río, calor, portales)
                uvRetro += vec2(sin(uvRetro.y * uMovU.y + uTiempo * uMovU.z), cos(uvRetro.x * uMovU.y + uTiempo * uMovU.z * 0.83)) * uMovU.x;
              #endif
              vec4 sampledDiffuseColor = texture2D(map, uvRetro);
              diffuseColor *= sampledDiffuseColor;
            #endif
            vec3 linAlb = diffuseColor.rgb;`)
          .replace('#include <fog_fragment>', `
            #ifdef USE_FOG
              float nieblaF = uNieblaVertice > 0.5
                ? vNieblaVert
                : clamp((vFogDepth - uNieblaCerca) / max(uNieblaLejos - uNieblaCerca, 0.001), 0.0, 1.0);
              if (uNieblaPasos > 0.5) nieblaF = floor(nieblaF * uNieblaPasos + 0.5) / uNieblaPasos;
              gl_FragColor.rgb = mix(gl_FragColor.rgb, fogColor, nieblaF);
            #endif`)
          .replace('#include <opaque_fragment>', `
            #ifdef SIN_LUZ
              outgoingLight = diffuseColor.rgb;
            #else
              // 🎌 cel shading: la luz que recibe la cara se redondea a pocos escalones (el color de la textura no)
              #ifdef TOON_OK
              if (uToon > 0.5) {
                vec3 tBase = max(diffuseColor.rgb, vec3(0.02));
                vec3 tLuz = max(outgoingLight - totalEmissiveRadiance, vec3(0.0)) / tBase;
                float tL = max(max(tLuz.r, tLuz.g), tLuz.b);
                float tQ = clamp(ceil(tL * uToon - 0.35) / uToon, uToonSombra, 1.15);
                outgoingLight = tBase * (tL > 1e-4 ? tLuz / tL : vec3(1.0)) * tQ + totalEmissiveRadiance;
              }
              #endif
              // 🔦 linterna proyectada: cono con textura, cara plana (estilo PS1) y luz en escalones
              #ifdef LIN_OK
              vec3 crLin = cross(dFdx(vLinMundo), dFdy(vLinMundo));
              vec3 nLin = crLin / max(length(crLin), 1e-8);
              if (uLinI > 0.0 && (uLinSolo < 0.5 || uEsHorneado > 0.5)) {
                vec3 lv = vLinMundo - uLinPos;
                float lz = dot(lv, uLinDir);
                if (uLinEsfera > 0.5) {
                  // 🔥 antorcha: luz alrededor que cae con la distancia (en escalones si toca)
                  float ld = max(length(lv), 0.001);
                  float la = clamp(1.0 - ld / uLinAlc, 0.0, 1.0);
                  float lk = la * la * (0.35 + 0.65 * abs(dot(nLin, lv / ld)));
                  if (uLinBandas > 0.5) lk = floor(lk * uLinBandas + 0.5) / uLinBandas;
                  outgoingLight += (uEsHorneado > 0.5 ? linAlb : diffuseColor.rgb) * uLinColor * (uLinI * lk);
                } else if (lz > 0.05) {
                  vec2 luv = vec2(dot(lv, uLinDer), dot(lv, uLinArr)) / (lz * uLinTan) * 0.5 + 0.5;
                  if (luv.x > 0.0 && luv.x < 1.0 && luv.y > 0.0 && luv.y < 1.0) {
                    float ld = length(lv);
                    float la = clamp(1.0 - ld / uLinAlc, 0.0, 1.0);
                    float lk = texture2D(uLinTex, luv).r * la * la * (0.3 + 0.7 * abs(dot(nLin, lv / ld)));
                    if (uLinBandas > 0.5) lk = floor(lk * uLinBandas + 0.5) / uLinBandas;
                    outgoingLight += (uEsHorneado > 0.5 ? linAlb : diffuseColor.rgb) * uLinColor * (uLinI * lk);
                  }
                }
              }
              #endif
            #endif
            #include <opaque_fragment>`)
          .replace('#include <dithering_fragment>', `#include <dithering_fragment>
            if (uDither > 0.0) {
              float b = bayer4(gl_FragCoord.xy) - 0.5;
              gl_FragColor.rgb = floor(clamp(gl_FragColor.rgb + b / 31.0, 0.0, 1.0) * 31.0 + 0.5) / 31.0;
            }`);
    };
    mat.customProgramCacheKey = () => 'retro-v5' + (LUZ.vertice ? '-pv' : '');
    if (mat.map) registrarTextura(mat.map);
    if (mat.normalMap) registrarTextura(mat.normalMap);
    mat.needsUpdate = true;
    return mat;
  }

  /* ---------- Configuración simple de material ----------
     cfg = { modo, opacidad, prioridad, dobleCara, sinLuz, tinte, desplazX, desplazY }
     modo: 'opaco' | 'recorte' (hojas, rejas) | 'translucido' (agua, vidrio) | 'aditivo' (fuego, magia)
     prioridad: orden de dibujo entre transparencias (más alto = encima), como render priority de Godot */
  const MODOS_MATERIAL = [['opaco', 'Opaco'], ['recorte', 'Recorte (hojas, rejas)'], ['translucido', 'Translúcido (agua, vidrio)'], ['aditivo', 'Aditivo (fuego, magia)']];
  function aplicarConfig(mat, cfg) {
    const modo = cfg.modo || 'opaco';
    mat.transparent = modo === 'translucido' || modo === 'aditivo';
    mat.alphaTest = modo === 'recorte' ? 0.5 : 0;
    mat.depthWrite = !mat.transparent;
    mat.blending = modo === 'aditivo' ? T.AdditiveBlending : T.NormalBlending;
    mat.opacity = mat.transparent ? (cfg.opacidad ?? 1) : 1;
    mat.side = cfg.dobleCara ? T.DoubleSide : T.FrontSide;
    if (cfg.tinte) mat.color.set(cfg.tinte);
    mat.userData.uDesplazUV = mat.userData.uDesplazUV || { value: new T.Vector2() };
    mat.userData.uDesplazUV.value.set(cfg.desplazX || 0, cfg.desplazY || 0);
    aplicarMovimiento(mat, cfg);
    // 🌾 pasto encima (lo siembra motor/pasto.js al jugar sobre las caras de este material que miran arriba)
    mat.userData.pastoCfg = cfg.pasto ? { ...cfg } : null;
    mat.userData.prioridad = cfg.prioridad || 0;
    // Material que emite luz: lo lee FORJA.Luces al registrar la escena
    mat.userData.cfgLuz = cfg.luz
      ? { color: cfg.luzColor || '#ffc27a', fuerza: cfg.luzFuerza ?? 1.5, alcance: cfg.luzAlcance ?? 7, parpadeo: cfg.luzParpadeo || 0,
        velocidad: cfg.luzVelocidad || 8, agrupar: cfg.luzAgrupar ?? 1.5, halo: cfg.luzHalo ?? 0.5, haloTam: cfg.luzHaloTam ?? 1.2, haloForma: cfg.luzHaloForma || 'circulo' }
      : null;
    const sinLuzAntes = !!(mat.defines && 'SIN_LUZ' in mat.defines);
    mat.defines = mat.defines || {};
    if (cfg.sinLuz) mat.defines.SIN_LUZ = ''; else delete mat.defines.SIN_LUZ;
    if (sinLuzAntes !== !!cfg.sinLuz) mat.needsUpdate = true;
    mat.needsUpdate = true;
  }

  /* ---------- 🌊 Materiales que se mueven (todo en la GPU con uTiempo; sin #define no cuesta nada) ----------
     cfg.olas     → la superficie sube y baja en olas: olaAltura (m), olaLargo (m), olaVel (m/s), olaDir (°)
     cfg.viento   → se mece más arriba que abajo (base fija): vientoCant (m), vientoAlto (m: a esta altura se mueve
                    entero), vientoVel, vientoFuente 'nivel' (el de la escena + sus ráfagas) | 'propio' (vientoDir °, vientoFuerza)
     cfg.ondear   → onda a lo largo del ancho, fija en el lado izquierdo (banderas, telas): ondearCant, ondearLargo, ondearVel
     cfg.ondular  → la textura ondula: ondularCant, ondularTam, ondularVel */
  const VERT_MOV = `
    #if defined(MOV_OLAS) || defined(MOV_VIENTO) || defined(MOV_ONDEAR)
    {
      mat4 mM = modelMatrix;
      #ifdef USE_BATCHING
        mM = mM * batchingMatrix;
      #endif
      #ifdef USE_INSTANCING
        mM = mM * instanceMatrix;
      #endif
      vec3 wM = (mM * vec4(transformed, 1.0)).xyz;
      vec3 esc2M = vec3(dot(mM[0].xyz, mM[0].xyz), dot(mM[1].xyz, mM[1].xyz), dot(mM[2].xyz, mM[2].xyz));
      #ifdef MOV_OLAS
        // 🌊 dos trenes de olas cruzados (en metros del mundo), suben y bajan en el eje vertical del objeto
        vec2 dO = vec2(cos(uMovO.w), sin(uMovO.w));
        float kO = 6.2832 / max(uMovO.y, 0.1);
        float hO = sin((dot(wM.xz, dO) - uTiempo * uMovO.z) * kO) + 0.45 * sin((dot(wM.xz, vec2(-dO.y, dO.x)) * 1.7 + uTiempo * uMovO.z * 0.8) * kO);
        transformed.y += uMovO.x * 0.5 * hO / sqrt(max(esc2M.y, 1e-6));
      #endif
      #ifdef MOV_VIENTO
        // 🌬 mecerse: base quieta, punta con todo; oscila con dos senos y la fase del sitio (no todos a la vez)
        vec3 vD = uMovV.w > 0.5 ? vec3(uMovVD.x, 0.0, uMovVD.y) * uMovVD.z : vec3(uViento.x, 0.0, uViento.y) * uViento.z * (1.0 + uViento.w);
        float hV = clamp(transformed.y / max(uMovV.y, 0.05), 0.0, 1.0);
        hV *= hV;
        float faseV = dot(wM.xz, vec2(0.37, 0.53));
        float oV = 0.65 + 0.35 * sin(uTiempo * uMovV.z * 2.0 + faseV) + 0.2 * sin(uTiempo * uMovV.z * 5.3 + faseV * 2.7);
        vec3 dV = vD * (uMovV.x * hV * oV);
        transformed += (vec4(dV, 0.0) * mM).xyz / max(esc2M, vec3(1e-6));   // del mundo al espacio del objeto
      #endif
      #ifdef MOV_ONDEAR
        // 🚩 onda a lo largo de X, fija en el lado izquierdo (el mástil, x = uMovF.w) y suelta del todo a una onda de él
        float wF = clamp((transformed.x - uMovF.w) / max(uMovF.y, 0.05), 0.0, 1.0);
        float fF = (transformed.x / max(uMovF.y, 0.05) - uTiempo * uMovF.z) * 6.2832;
        transformed.z += uMovF.x * wF * (sin(fF) + 0.3 * sin(fF * 2.3 + transformed.y * 3.0));
      #endif
    }
    #endif`;
  function movUniformes(mat) {
    if (mat.userData.mov) return mat.userData.mov;
    mat.userData.mov = { uMovO: { value: new T.Vector4() }, uMovV: { value: new T.Vector4() }, uMovVD: { value: new T.Vector4() },
      uMovF: { value: new T.Vector4() }, uMovU: { value: new T.Vector4() } };
    return mat.userData.mov;
  }
  const MOV_DEF = ['MOV_OLAS', 'MOV_VIENTO', 'MOV_ONDEAR', 'MOV_ONDULAR'];
  function aplicarMovimiento(mat, cfg) {
    const u = movUniformes(mat), G = Math.PI / 180;
    const quiere = { MOV_OLAS: !!cfg.olas, MOV_VIENTO: !!cfg.viento, MOV_ONDEAR: !!cfg.ondear, MOV_ONDULAR: !!cfg.ondular };
    mat.defines = mat.defines || {};
    let cambio = false;
    for (const d of MOV_DEF) {
      if (quiere[d] !== (d in mat.defines)) { cambio = true; if (quiere[d]) mat.defines[d] = ''; else delete mat.defines[d]; }
    }
    u.uMovO.value.set(cfg.olaAltura ?? 0.3, cfg.olaLargo ?? 6, cfg.olaVel ?? 1.5, (cfg.olaDir ?? 0) * G);
    u.uMovV.value.set(cfg.vientoCant ?? 0.15, cfg.vientoAlto ?? 1, cfg.vientoVel ?? 1, cfg.vientoFuente === 'propio' ? 1 : 0);
    const dv = (cfg.vientoDir ?? 90) * G;
    u.uMovVD.value.set(Math.sin(dv), -Math.cos(dv), cfg.vientoFuerza ?? 0.6, 0);
    u.uMovF.value.set(cfg.ondearCant ?? 0.12, cfg.ondearLargo ?? 0.6, cfg.ondearVel ?? 1.2, cfg.ondearBorde ?? -0.5);
    u.uMovU.value.set(cfg.ondularCant ?? 0.02, cfg.ondularTam ?? 8, cfg.ondularVel ?? 1.5, 0);
    // para el agua del juego (flotar con las olas de un lago de modelo)
    mat.userData.movCfg = cfg.olas ? { olas: true, olaAltura: cfg.olaAltura ?? 0.3, olaLargo: cfg.olaLargo ?? 6, olaVel: cfg.olaVel ?? 1.5, olaDir: cfg.olaDir ?? 0, olasJuego: !!cfg.olasJuego } : null;
    if (cambio) mat.needsUpdate = true;
  }
  // lo horneado cambia de material: se lleva el movimiento
  function copiarMovimiento(de, a) {
    if (!de || !de.userData.mov) return;
    const u = movUniformes(a);
    for (const k of Object.keys(u)) u[k].value.copy(de.userData.mov[k].value);
    a.defines = a.defines || {};
    for (const d of MOV_DEF) if (de.defines && d in de.defines) a.defines[d] = '';
  }
  // ¿el material se deforma? (para subdividir primitivas)
  const movVertices = (cfg) => !!(cfg && (cfg.olas || cfg.viento || cfg.ondear));
  // altura de las olas en (x, z) del mundo: la misma cuenta que el shader (para flotar)
  function alturaOla(cfg, x, z) {
    const G = Math.PI / 180, d = (cfg.olaDir ?? 0) * G, dx = Math.cos(d), dz = Math.sin(d);
    const k = 6.2832 / Math.max(cfg.olaLargo ?? 6, 0.1), t = U.uTiempo.value, v = cfg.olaVel ?? 1.5;
    return (cfg.olaAltura ?? 0.3) * 0.5 * (Math.sin((x * dx + z * dz - t * v) * k) + 0.45 * Math.sin(((x * -dz + z * dx) * 1.7 + t * v * 0.8) * k));
  }
  // 🌬 viento del nivel (lo pone la escena): dirección en grados (hacia donde sopla), fuerza 0..1, ráfagas 0..1
  const VIENTO = { activo: false, dir: 90, fuerza: 0.4, rafagas: 0.4 };
  function ponerViento(amb) {
    // sin viento en el nivel queda una brisa suave fija (el pasto y las hojas con viento "del nivel" se mueven poco)
    VIENTO.activo = !!(amb && amb.viento);
    VIENTO.dir = VIENTO.activo ? amb.vientoDir ?? 90 : 90;
    VIENTO.fuerza = VIENTO.activo ? amb.vientoFuerza ?? 0.4 : 0.25;
    VIENTO.rafagas = VIENTO.activo ? amb.vientoRafagas ?? 0.4 : 0;
    const d = VIENTO.dir * Math.PI / 180;
    U.uViento.value.set(Math.sin(d), -Math.cos(d), VIENTO.fuerza, 0);
  }
  function actualizarViento() {
    if (!VIENTO.activo || !VIENTO.rafagas) return;
    const t = U.uTiempo.value;
    // ráfagas: suben y bajan a ratos (dos senos lentos multiplicados: a veces calma, a veces fuerte)
    U.uViento.value.w = VIENTO.rafagas * Math.max(0, Math.sin(t * 0.37) * Math.sin(t * 0.91 + 1.3)) * 1.5;
  }

  // La prioridad vive en los objetos (renderOrder): se copia de sus materiales
  function aplicarPrioridad(raiz) {
    raiz.traverse((o) => {
      if (!o.isMesh) return;
      const mats = Array.isArray(o.material) ? o.material : [o.material];
      o.renderOrder = Math.max(0, ...mats.map((m) => (m && m.userData.prioridad) || 0));
    });
  }

  /* Convierte los materiales PBR de un GLB a Lambert retro.
     Conserva mapa de color, mapa normal, emisivo, transparencia y colores de vértice. */
  function convertirMateriales(raiz) {
    const cache = new Map();
    raiz.traverse((o) => {
      if (!o.isMesh) return;
      const convertir = (m) => {
        if (!m) return m;
        if (cache.has(m)) return cache.get(m);
        const nuevo = new T.MeshLambertMaterial({
          name: m.name,
          map: m.map || null,
          normalMap: m.normalMap || null,
          color: m.color ? m.color.clone() : new T.Color(1, 1, 1),
          vertexColors: !!m.vertexColors,
          side: m.side,
          emissive: m.emissive ? m.emissive.clone() : new T.Color(0, 0, 0),
          emissiveMap: m.emissiveMap || null,
        });
        if (m.normalScale) nuevo.normalScale.copy(m.normalScale);
        // Modo tal como viene del GLB: translúcido (agua, vidrio), recorte (hojas, rejas) u opaco
        const modo = m.transparent ? 'translucido' : m.alphaTest > 0 ? 'recorte' : 'opaco';
        nuevo.userData.original = {
          modo, opacidad: m.opacity ?? 1, prioridad: 0, dobleCara: m.side === T.DoubleSide, sinLuz: false,
          tinte: '#' + (m.color ? m.color.getHexString() : 'ffffff'), map: m.map || null, normalMap: m.normalMap || null,
          textura: '', normal: '', desplazX: 0, desplazY: 0,
          ondular: false, ondularCant: 0.02, ondularTam: 8, ondularVel: 1.5, olas: false, olaAltura: 0.3, olaLargo: 6, olaVel: 1.5, olaDir: 0, olasJuego: false, pasto: false, pastoDensidad: 3, pastoAlto: 0.35, pastoAncho: 0.45, pastoColor: '#2f5f22', pastoColor2: '#9acd5a', pastoVariar: 0.25, pastoViento: 1, pastoLejos: 25, viento: false, vientoFuente: 'nivel', vientoDir: 90, vientoFuerza: 0.6, vientoCant: 0.15, vientoAlto: 1, vientoVel: 1, ondear: false, ondearCant: 0.12, ondearLargo: 0.6, ondearVel: 1.2,
          // Emite luz (lámparas, antorchas): ver motor/luces.js
          luz: false, luzColor: '#ffc27a', luzFuerza: 1.5, luzAlcance: 7, luzParpadeo: 0, luzVelocidad: 8, luzAgrupar: 1.5,
          luzHalo: 0.5, luzHaloTam: 1.2,
        };
        hacerRetro(nuevo);
        aplicarConfig(nuevo, nuevo.userData.original);
        cache.set(m, nuevo);
        return nuevo;
      };
      o.material = Array.isArray(o.material) ? o.material.map(convertir) : convertir(o.material);
      o.frustumCulled = !o.isSkinnedMesh;
    });
  }

  /* Textura de cuadros para primitivas (se tiñe con el color de cada una) */
  const texCuadros = (() => {
    const c = document.createElement('canvas');
    c.width = c.height = 32;
    const g = c.getContext('2d');
    for (let y = 0; y < 4; y++) {
      for (let x = 0; x < 4; x++) {
        g.fillStyle = (x + y) % 2 ? '#c8c8c8' : '#f0f0f0';
        g.fillRect(x * 8, y * 8, 8, 8);
      }
    }
    const t = new T.CanvasTexture(c);
    t.wrapS = t.wrapT = T.RepeatWrapping;
    t.colorSpace = T.SRGBColorSpace;
    return t;
  })();
  registrarTextura(texCuadros);

  /* ---------- Cielo (como el sky de tu PS1Environment.gd) ----------
     Cúpula que sigue a la cámara y se dibuja detrás de todo:
     degradado cielo → horizonte, textura esférica o plana, escala y desplazamiento. */
  function crearCielo() {
    const mat = new T.ShaderMaterial({
      uniforms: {
        uCielo: { value: new T.Color() },
        uHorizonte: { value: new T.Color() },
        uAltura: { value: 0.25 },
        uTex: { value: null },
        uUsarTex: { value: 0 },
        uModo: { value: 0 },
        uEscala: { value: new T.Vector2(1, 1) },
        uOffset: { value: new T.Vector2() },
        uDither: U.uDither,
      },
      vertexShader: `
        varying vec3 vDir;
        void main() {
          vDir = position;
          gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0);
        }`,
      fragmentShader: `
        uniform vec3 uCielo;
        uniform vec3 uHorizonte;
        uniform float uAltura;
        uniform sampler2D uTex;
        uniform float uUsarTex;
        uniform float uModo;
        uniform vec2 uEscala;
        uniform vec2 uOffset;
        uniform float uDither;
        varying vec3 vDir;
        const float PI_C = 3.14159265;
        float bayer2(vec2 p) { return 2.0 * p.x + 3.0 * p.y - 4.0 * p.x * p.y; }
        float bayer4(vec2 p) { p = floor(mod(p, 4.0)); return (4.0 * bayer2(mod(p, 2.0)) + bayer2(floor(p / 2.0))) / 16.0; }
        void main() {
          vec3 d = normalize(vDir);
          vec3 base = uCielo;
          if (uUsarTex > 0.5) {
            vec2 uv;
            if (uModo < 0.5) {
              uv = vec2(atan(d.x, d.z) / (2.0 * PI_C) + 0.5, 1.0 - acos(clamp(d.y, -1.0, 1.0)) / PI_C);
              uv.y *= uEscala.y;
            } else {
              uv = d.xz / max(d.y, 0.001);
              uv *= uEscala.y * 0.5;
            }
            uv.x *= uEscala.x;
            uv += uOffset;
            base *= textureLod(uTex, uv, 0.0).rgb;   // sin mipmaps: evita la línea en la costura del panorama
          }
          float f = smoothstep(0.0, max(uAltura, 0.001), max(d.y, 0.0));
          vec3 arriba = mix(uHorizonte, base, f);
          gl_FragColor = vec4(mix(arriba, uHorizonte, step(d.y, 0.0)), 1.0);
          #include <colorspace_fragment>
          if (uDither > 0.0) {
            float b = bayer4(gl_FragCoord.xy) - 0.5;
            gl_FragColor.rgb = floor(clamp(gl_FragColor.rgb + b / 31.0, 0.0, 1.0) * 31.0 + 0.5) / 31.0;
          }
        }`,
      side: T.BackSide,
      depthTest: false,
      depthWrite: false,
      fog: false,
    });
    const cielo = new T.Mesh(new T.SphereGeometry(1, 32, 16), mat);
    cielo.renderOrder = -1e9;
    cielo.frustumCulled = false;
    cielo.userData.ayudaEditor = false;
    return cielo;
  }

  /* ---------- Vista: renderer + escena + luces ----------
     La usan el editor y el juego exportado. */
  class Vista {
    constructor(contenedor) {
      this.contenedor = contenedor;
      this.renderer = new T.WebGLRenderer({ antialias: false, powerPreference: 'high-performance' });
      this.renderer.outputColorSpace = T.SRGBColorSpace;
      this.renderer.domElement.style.imageRendering = 'pixelated';
      contenedor.prepend(this.renderer.domElement);

      this.escena = new T.Scene();
      this.hemi = new T.HemisphereLight(0xdde6ff, 0x3a3328, 1);
      this.sol = new T.DirectionalLight(0xfff2dd, 1);
      this.escena.add(this.hemi, this.sol, this.sol.target);
      this.cielo = crearCielo();
      this.escena.add(this.cielo);
      this.velCielo = new T.Vector2();
      this.reloj = performance.now();
      this.direccionSol = new T.Vector3(0, 1, 0);
      // Luces puntuales y sombras del sol (solo con "Luces y sombras" en Proyecto)
      this.luces = F.Luces ? new F.Luces(this) : null;

      this.retro = false;
      this.ajustes = null;
      // 📼 efectos de cámara (motor/efectos.js): null = apagados, se dibuja directo a la pantalla
      this.fxNivel = null;      // los del proyecto o del nivel
      this.fxForzado = null;    // los que pone una cinemática encima (forzarEfectos)
      this.fx = null;           // los que valen ahora
      this.pase = null;         // se crea la primera vez que hacen falta
      this.camaras = new Set();
      new ResizeObserver(() => this.ajustarTamano()).observe(contenedor);
    }

    usarCamara(cam) {
      this.camaras.add(cam);
      this.ajustarTamano();
    }

    /* Aplica ajustes.
       render: los del proyecto (resolución, temblor…) · amb: el ambiente de la escena
       retro: verse como en el juego · conNiebla: mostrar la niebla */
    aplicar(render, amb, retro, conNiebla = retro) {
      const a = render;
      this.ajustes = a;
      // 💡 luz por vértice / por píxel: al cambiar, todos los materiales retro se recompilan
      const pv = a.luzVertice !== false;
      if (pv !== LUZ.vertice) {
        LUZ.vertice = pv;
        this.escena.traverse((o) => { if (o.material) for (const m of Array.isArray(o.material) ? o.material : [o.material]) if (m.userData.retro) m.needsUpdate = true; });
      }
      this.retro = retro;
      const horizonte = amb.cieloHorizonte || amb.fondo;
      this.escena.background = new T.Color(horizonte);
      const cu = this.cielo.material.uniforms;
      cu.uCielo.value.set(amb.fondo);
      cu.uHorizonte.value.set(horizonte);
      cu.uAltura.value = amb.cieloAlturaHorizonte ?? 0.25;
      const tex = amb.cieloTextura && F.Assets && F.Assets.textura(amb.cieloTextura, 'color');
      cu.uTex.value = tex || null;
      cu.uUsarTex.value = tex ? 1 : 0;
      cu.uModo.value = amb.cieloModo === 'plano' ? 1 : 0;
      cu.uEscala.value.set(amb.cieloEscalaX ?? 1, amb.cieloEscalaY ?? 1);
      this.velCielo.set(amb.cieloVelX || 0, amb.cieloVelY || 0);
      ponerViento(amb);
      const colorNiebla = amb.nieblaDelCielo ? horizonte : amb.nieblaColor;
      if (conNiebla && amb.niebla) {
        if (!this.escena.fog) this.escena.fog = new T.Fog(colorNiebla, amb.nieblaCerca, amb.nieblaLejos);
        this.escena.fog.color.set(colorNiebla);
        this.escena.fog.near = amb.nieblaCerca;
        this.escena.fog.far = amb.nieblaLejos;
      } else {
        this.escena.fog = null;
      }
      U.uNieblaCerca.value = amb.nieblaCerca;
      U.uNieblaLejos.value = amb.nieblaLejos;
      U.uNieblaVertice.value = amb.nieblaVertice ? 1 : 0;
      U.uNieblaPasos.value = Math.max(0, Math.round(amb.nieblaPasos || 0));
      this.hemi.color.set(0xdde6ff); this.hemi.groundColor.set(0x3a3328);   // (el clima los tiñe)
      this.hemi.intensity = amb.luzAmb * Math.PI;
      this.sol.intensity = amb.luzSol * Math.PI;
      const alt = amb.solAltura * F.DEG, giro = amb.solGiro * F.DEG;
      this.direccionSol.set(Math.cos(alt) * Math.sin(giro), Math.sin(alt), Math.cos(alt) * Math.cos(giro));
      this.sol.target.position.set(0, 0, 0);
      this.sol.position.copy(this.direccionSol).multiplyScalar(50);
      this.sol.color.set(amb.solColor || '#fff2dd');
      if (this.luces) this.luces.configurar(a, amb);
      if (amb.clima && F.Clima) F.Clima.vistaPrevia(this, amb);   // 🌦 la hora y la lluvia elegidas
      U.uSnap.value = retro ? a.snap : 0;
      U.uAffine.value = retro ? a.afin : 0;
      U.uDither.value = retro && a.dither ? 1 : 0;
      this.fxNivel = (retro || a.fxEnEditor) && F.Efectos ? F.Efectos.efectivos(a, amb) : null;
      this.jugadorSinFx = !!a.fxJugadorApagado;        // el jugador quitó los efectos (Opciones ▸ Imagen)
      this.sinMovimiento = !!a.fxSinMovimiento;        // el jugador pidió reducir el movimiento de pantalla
      this._elegirFx();
      if (filtroN64 !== !!a.filtroN64) {
        filtroN64 = !!a.filtroN64;
        for (const t of texturas) aplicarFiltro(t);
      }
      this.ajustarTamano();
    }

    /* 📼 Efectos encima de los del nivel (cinemáticas). cfg con las claves fx… de motor/efectos.js · null = quitar */
    forzarEfectos(cfg) {
      this.fxForzado = cfg ? ((!this.jugadorSinFx && F.Efectos.efectivos(cfg, null)) || 'nada') : null;
      this._elegirFx();
    }

    _elegirFx() {
      const fx = this.fxForzado ? (this.fxForzado === 'nada' ? null : this.fxForzado) : this.fxNivel;
      const antes = !!this.fx;
      this.fx = fx;
      if (fx && !this.pase) this.pase = new F.Efectos.Pase();
      if (this.pase) this.pase.sinMovimiento = !!this.sinMovimiento;
      if (this.pase) this.pase.configurar(fx);   // sin efectos del nivel el pase queda solo para los 💥 momentos
      U.uToon.value = fx ? (fx.fxToon || 0) : 0;
      U.uToonSombra.value = fx ? (fx.fxToonSombra ?? 0.45) : 0.45;
      if (antes !== !!fx) this.ajustarTamano();
    }

    // Distancia de dibujado de una escena (lo que se usa como "far" de la cámara de juego)
    static distanciaDibujo(amb) {
      if (amb.niebla && amb.recortarEnNiebla) return amb.nieblaLejos + 1;
      return amb.distanciaDibujo || 300;
    }

    ajustarTamano() {
      const w = this.contenedor.clientWidth, h = this.contenedor.clientHeight;
      if (!w || !h) return;
      const a = this.ajustes || { resolucion: 0 };
      const nativa = Math.min(window.devicePixelRatio || 1, 2);
      if (this.fx && this.pase) {
        // 📼 con efectos: la pantalla a resolución nativa (para que las líneas y el letrero se vean finos)
        // y el nivel en una textura chica con la resolución retro. 📱 En celulares y tablets con tope de 720 de alto
        // (la pantalla completa a 3× cuesta mucho y no se nota)
        const tope = (window.matchMedia && matchMedia('(pointer: coarse)').matches) ? 720 : 1440;
        const ratio = Math.max(0.5, Math.min(nativa, tope / h));
        this.renderer.setPixelRatio(ratio);
        this.renderer.setSize(w, h, false);
        const hr = a.resolucion > 0 ? Math.min(a.resolucion, h * ratio) : h * ratio;
        this.pase.tamano(hr * (w / h), hr, w * ratio, h * ratio);
      } else {
        const ratio = this.retro && a.resolucion > 0 ? a.resolucion / h : nativa;
        this.renderer.setPixelRatio(ratio);
        this.renderer.setSize(w, h, false);
        // 💥 momentos sin efectos del nivel: la textura del pase igual que la pantalla (nada cambia de tamaño al usarlo)
        if (this.pase) this.pase.tamano(w * ratio, h * ratio, w * ratio, h * ratio);
      }
      const refH = a.resolucion > 0 ? a.resolucion : 240;
      U.uSnapGrid.value.set((refH * (w / h)) / 2, refH / 2);
      for (const cam of this.camaras) {
        if (cam.isOrthographicCamera) {
          // vistas superior / frontal / lateral del editor: mitadAlto = metros de media pantalla (el zoom va aparte)
          const m = cam.userData.mitadAlto || 10;
          cam.left = -m * (w / h); cam.right = m * (w / h); cam.top = m; cam.bottom = -m;
        } else {
          cam.aspect = w / h;
        }
        cam.updateProjectionMatrix();
      }
    }

    // Tiempo de GPU con consultas de tiempo (sin parar la tarjeta: el resultado llega unos cuadros después)
    _gpuEmpezar() {
      if (!this.medirGpu) return null;
      const gl = this.renderer.getContext();
      if (this._extT === undefined) this._extT = gl.getExtension('EXT_disjoint_timer_query_webgl2') || null;
      const ext = this._extT;
      if (!ext) return null;
      const g = this._gpu || (this._gpu = { lista: [], suma: 0, n: 0, t: performance.now() });
      // recoger las que ya terminaron
      while (g.lista.length && gl.getQueryParameter(g.lista[0], gl.QUERY_RESULT_AVAILABLE)) {
        const q = g.lista.shift();
        if (!gl.getParameter(ext.GPU_DISJOINT_EXT)) { g.suma += gl.getQueryParameter(q, gl.QUERY_RESULT) / 1e6; g.n++; }
        gl.deleteQuery(q);
      }
      if (performance.now() - g.t > 500 && g.n) { F.Rendimiento.gpu = g.suma / g.n; g.suma = 0; g.n = 0; g.t = performance.now(); }
      if (g.lista.length > 4) return null;   // no amontonar
      const q = gl.createQuery();
      gl.beginQuery(ext.TIME_ELAPSED_EXT, q);
      g.lista.push(q);
      return gl;
    }

    render(cam) {
      const glT = this._gpuEmpezar();
      this._render(cam);
      if (glT) glT.endQuery(this._extT.TIME_ELAPSED_EXT);
    }

    _render(cam) {
      const ahora = performance.now();
      const dt = Math.min(0.1, (ahora - this.reloj) / 1000);
      this.reloj = ahora;
      const off = this.cielo.material.uniforms.uOffset.value;
      if (this.velCielo.x || this.velCielo.y) {
        off.x = (off.x + this.velCielo.x * dt) % 1;
        off.y = (off.y + this.velCielo.y * dt) % 1;
      }
      U.uTiempo.value = (U.uTiempo.value + dt) % 3600;
      actualizarViento();
      if (this.luces) this.luces.actualizar(dt, cam);
      this.cielo.position.copy(cam.position);
      this.cielo.visible = !cam.isOrthographicCamera;   // en vistas orto la cúpula no tiene sentido
      // 📼 con efectos se dibuja primero en la textura retro y al final el pase la pone en pantalla
      const conFx = this.pase && (this.fx || this.pase.momentoActivo()) && !cam.isOrthographicCamera;
      this.renderer.setRenderTarget(conFx ? this.pase.rt : null);
      this.renderer.render(this.escena, cam);
      // Primer plano (el arma en 1ª persona): encima de lo ya dibujado, con la profundidad borrada, así nunca
      // se mete en las paredes. Mismo búfer, sin otra textura: solo unas pocas llamadas de dibujo más.
      const pp = this._pp;
      if (pp && pp.activo) {
        const camPP = pp.camara;
        camPP.position.copy(cam.position);
        camPP.quaternion.copy(cam.quaternion);
        const fov = pp.fov > 0 ? pp.fov : cam.fov;
        if (camPP.fov !== fov || camPP.aspect !== cam.aspect) { camPP.fov = fov; camPP.aspect = cam.aspect; camPP.updateProjectionMatrix(); }
        // la misma luz del nivel (cielo + sol), sin sombras
        pp.hemi.color.copy(this.hemi.color); pp.hemi.groundColor.copy(this.hemi.groundColor); pp.hemi.intensity = this.hemi.intensity;
        pp.sol.color.copy(this.sol.color); pp.sol.intensity = this.sol.intensity;
        pp.sol.target.position.copy(cam.position);
        pp.sol.position.copy(cam.position).addScaledVector(this.direccionSol, 10);
        const r = this.renderer, auto = r.autoClear, sombras = r.shadowMap.autoUpdate;
        r.autoClear = false;
        r.shadowMap.autoUpdate = false;
        r.clearDepth();
        r.render(pp.escena, camPP);
        r.autoClear = auto;
        r.shadowMap.autoUpdate = sombras;
      }
      if (conFx) this.pase.dibujar(this.renderer, dt, cam);
    }

    /* Escena de primer plano (se crea al pedirla). pp.activo = dibujarla este cuadro; pp.fov = 0 → el de la cámara */
    primerPlano() {
      if (this._pp) return this._pp;
      const escena = new T.Scene();
      const hemi = new T.HemisphereLight(0xffffff, 0x444444, 1);
      const sol = new T.DirectionalLight(0xffffff, 1);
      escena.add(hemi, sol, sol.target);
      this._pp = { escena, hemi, sol, camara: new T.PerspectiveCamera(70, 1, 0.01, 10), activo: false, fov: 0 };
      return this._pp;
    }
  }

  /* Materiales COMPARTIDOS: las figuras del motor (puertas, palancas, cofres, enemigos…) piden su material por
     color y opciones; los iguales son el MISMO material (menos cambios de estado al dibujar). Quien lo vaya a
     modificar (opacidad, destello) no lo usa o se hace una copia propia. userData.compartido: no se libera. */
  const _compartidos = new Map();
  function matRetro(color, opciones = {}) {
    const c = new T.Color(color);
    const clave = c.getHexString() + JSON.stringify(opciones);
    let m = _compartidos.get(clave);
    if (!m) {
      m = hacerRetro(new T.MeshLambertMaterial({ color: c, flatShading: true, ...opciones }));
      m.userData.compartido = true;
      _compartidos.set(clave, m);
    }
    return m;
  }

  F.Render = { U, texLinterna, hacerRetro, matRetro, convertirMateriales, registrarTextura, texCuadros, Vista, aplicarConfig, aplicarPrioridad, MODOS_MATERIAL,
    aplicarMovimiento, copiarMovimiento, movVertices, alturaOla, ponerViento, VIENTO };
})(window.FORJA);
