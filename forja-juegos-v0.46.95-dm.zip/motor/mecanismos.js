/* =========================================================
   FORJA · MECANISMOS (Fase 5)
   Cosas del nivel que se abren, se mueven o se activan: 🔒 puertas (esta parte), y después palancas, botones,
   disparadores, plataformas y puzles. Todas comparten el mismo "qué hace" (acciones) y los canales.

   🔒 PUERTA (entidad 'puerta', ent.puerta = PUERTA)
     La caja de la entidad (escala) es el hueco: ancho × alto × fondo. Sin modelo, el motor pone marco y hoja.
     · Cómo se abre: 'usar' (mirarla y E) · 'cerca' (sola al acercarte, sci-fi) · 'mecanismo' (solo palanca / botón…)
     · Llave: un objeto de la mochila (tipo llave / objeto clave). Se gasta o se queda (gastarLlave).
     · Estilo: 'bisagra' (gira, se abre hacia el lado contrario al jugador) · 'deslizar' (de lado) · 'arriba'
       (sube) · 'negro' (corte a negro estilo Resident Evil: apareces al otro lado, la puerta no se mueve)
       · 'energia' (campo de energía transparente que se apaga).
     · Con modelo propio: el modelo hace de hoja (mismos estilos) o usa su animación de abrir / cerrar.
     · cerrarTras > 0: se vuelve a cerrar sola N s después (con 'cerca', N s después de irte).
     La hoja choca como PIEZA MÓVIL del mundo (fisica.js reservarMoviles / moverPieza): se recalcula solo
     cuando se mueve. Lo abierto/desbloqueado se guarda en la memoria del nivel.

   🕹 PALANCA (entidad 'palanca', ent.palanca = PALANCA): palanca de suelo, botón de pared o interruptor.
     · modo: 'alternar' (cada uso enciende / apaga) · 'una' (una sola vez) · 'volver' (vuelve sola tras N s)
     · acciones: la lista "Qué hace" [{ que, a, ... , retraso }] (ACCIONES). Al apagarse, con alApagar
       'invertir', hace lo contrario de lo que se pueda deshacer (abrir ↔ cerrar, encender ↔ apagar…).
     · canal: escucha un canal (📡): encendido / apagado desde otro sitio, como si la usaran.
   ⬚ DISPARADOR (entidad 'disparador', ent.disparador = DISPARADOR): una caja invisible (escala = tamaño).
     · cuando: 'una' (la primera vez que entras) · 'cada' (cada vez, con espera) · 'entrarSalir' (al salir deshace)
     · quien: 'jugador' | 'enemigos' | 'todos' · activo / canal: se puede apagar y encender (acción o canal)
     · la misma lista "Qué hace" que las palancas.
   🏺 PEDESTAL (entidad 'pedestal'): hueco donde se coloca un objeto de la mochila (objeto clave, gema, medallón).
     Con el objeto puesto hace su lista "Qué hace"; si se puede quitar, al quitarlo deshace.
   ⚙ CONDICIÓN (entidad 'condicion', solo se ve en el editor): espera a que se cumplan sus requisitos
     (todas o alguna): palancas encendidas / apagadas, pedestales con su objeto, enemigos muertos (un jefe),
     arena terminada, todos los enemigos del nivel muertos, disparador pisado, puerta abierta. Cumplida → su lista;
     si deja de cumplirse (y no es "una vez") → lo contrario. Así se hacen puzles de varias palancas.
   ⇅ PLATAFORMA (entidad 'plataforma'): caja que va y viene entre su sitio y su sitio + recorrido, y lleva encima
     al jugador y a los enemigos. modo 'pisar' (elevador estilo Doom: se mueve al subirte y vuelve tras N s)
     · 'vaiven' (siempre, con espera en los extremos) · 'mecanismo' (solo con palancas, botones, disparadores).
     Choca como pieza móvil, igual que la hoja de una puerta.
   📡 CANALES: la acción 'canal' avisa a un nombre (encendido o apagado). Escuchan: puertas (abren / cierran)
     y palancas (se encienden / apagan y hacen lo suyo). Sirve para cadenas y cosas que varias palancas comparten.
   ========================================================= */
(function (F) {
  'use strict';
  const T = THREE;

  const PUERTA = {
    abrir: 'usar',            // 'usar' | 'cerca' | 'mecanismo'
    canal: '',                // 📡 escucha este canal: encendido = abre, apagado = cierra
    avisoMecanismo: true,     // 'mecanismo': al mirarla sale "Abrir" (y luego "No se abre desde aquí"); false = ni aviso (muro secreto)
    empiezaAbierta: false,
    llave: '',                // id de proyecto.objetos ('' = sin llave)
    gastarLlave: true,        // la llave desaparece de la mochila al abrir (RE) o se queda (Doom / Zelda)
    estilo: 'bisagra',        // 'bisagra' | 'deslizar' | 'arriba' | 'negro' | 'energia'
    lado: 'izq',              // bisagra / hacia dónde se desliza: 'izq' | 'der'
    tiempo: 0.7,              // segundos en abrirse
    cerrarTras: 0,            // 0 = se queda abierta · > 0 = se cierra sola tras N s
    cerrarConUsar: true,      // con 'usar': volver a pulsar la cierra
    distancia: 2.5,           // 'cerca': a cuántos metros se abre
    aviso: '',                // texto al mirarla ('' = "Abrir <nombre>")
    avisoCerrada: '',         // sin llave / con 'mecanismo' ('' = automático)
    fundido: 0.35,            // 'negro': segundos del fundido
    marco: true,              // marco del motor
    colorMarco: '#4a3a2c', colorHoja: '#7a5636', colorEnergia: '#38c8ff', opacidadEnergia: 0.55,
    modelo: '', modeloEscala: 1, modeloX: 0, modeloY: 0, modeloZ: 0, modeloGiro: 0,
    animAbrir: '', animCerrar: '',
    sonidoAbrir: '', sonidoCerrar: '', sonidoCerrada: '', sonidoLlave: '',
  };
  const GIRO = 100 * Math.PI / 180;   // lo que gira una hoja con bisagra

  const ESTILOS = [['bisagra', '🚪 Gira en su bisagra'], ['deslizar', '↔ Se desliza de lado'], ['arriba', '⬆ Sube (rastrillo, sci-fi)'],
    ['negro', '⬛ Corte a negro (Resident Evil)'], ['energia', '⚡ Campo de energía que se apaga']];
  const ESQUEMA_PUERTA = [
    { k: 'abrir', t: 'sel', e: 'Cómo se abre', op: [['usar', '✋ Mirarla y pulsar usar (E)'], ['cerca', '🚶 Sola al acercarte'], ['mecanismo', '🕹 Solo con palanca, botón o disparador']],
      ayuda: '"Solo con palanca": el jugador no la abre; la abre lo que la tenga en su lista "Qué hace"' },
    { k: 'avisoMecanismo', t: 'bool', e: 'Aviso al mirarla', si: (v) => v.abrir === 'mecanismo',
      ayuda: 'Sale "Abrir" y al pulsar dice que no se abre desde aquí. Desmárcalo en un muro secreto: si no, se delata' },
    { k: 'estilo', t: 'sel', e: 'Al abrirse', op: ESTILOS,
      ayuda: 'Corte a negro: la pantalla funde a negro y apareces al otro lado (la puerta no se mueve), como en Resident Evil' },
    { k: 'lado', t: 'sel', e: 'Bisagra / lado', op: [['izq', 'Izquierda'], ['der', 'Derecha']], si: (v) => v.estilo === 'bisagra' || v.estilo === 'deslizar',
      ayuda: 'Mirando la flecha del suelo (el frente). Con bisagra se abre hacia el lado contrario al jugador' },
    { k: 'tiempo', t: 'num', e: 'Tarda en abrirse (s)', paso: 0.1, min: 0.05, si: (v) => v.estilo !== 'negro' },
    { k: 'fundido', t: 'num', e: 'Fundido a negro (s)', paso: 0.05, min: 0, si: (v) => v.estilo === 'negro' },
    { k: 'cerrarTras', t: 'num', e: 'Se cierra sola tras (s)', paso: 0.5, min: 0, si: (v) => v.estilo !== 'negro',
      ayuda: '0 = se queda abierta. Si se abre al acercarte: cuenta desde que te alejas' },
    { k: 'cerrarConUsar', t: 'bool', e: 'Usar otra vez la cierra', si: (v) => v.abrir === 'usar' && v.estilo !== 'negro',
      ayuda: 'Marcado: abierta, el botón la cierra (aunque también se cierre sola). Desmarcado: abierta no sale el aviso y no se puede cerrar; solo se cierra sola o con una palanca' },
    { k: 'distancia', t: 'num', e: 'Se abre a (m)', paso: 0.25, min: 0.5, si: (v) => v.abrir === 'cerca' },
    { k: 'canal', t: 'sel', e: '📡 Escucha el canal', op: [['', '(ninguno)']], av: true,
      ayuda: 'Un canal es un nombre que avisan las palancas (acción "Avisar a un canal"): encendido abre, apagado cierra' },
    { k: 'empiezaAbierta', t: 'bool', e: 'Empieza abierta', si: (v) => v.estilo !== 'negro', ayuda: 'Para puertas que se cierran tras de ti con un disparador' },
    { grupo: '🗝 Llave' },
    { k: 'llave', t: 'sel', e: 'Necesita', op: [['', '(nada: no tiene llave)']], ayuda: 'Un objeto de Juego ▸ Objetos (tipo llave u objeto clave). Se crea ahí' },
    { k: 'gastarLlave', t: 'bool', e: 'La llave se gasta', si: (v) => v.llave, ayuda: 'Sí = desaparece de la mochila (Resident Evil). No = se queda y abre otras puertas (Doom)' },
    { k: 'avisoCerrada', t: 'texto', e: 'Mensaje si está cerrada', ayuda: 'Vacío = "Está cerrada con llave" / "No se abre desde aquí"' },
    { k: 'aviso', t: 'texto', e: 'Aviso al mirarla', av: true, ayuda: 'Vacío = "Abrir <nombre>"' },
    { grupo: 'Cómo se ve' },
    { k: 'marco', t: 'bool', e: 'Marco del motor' },
    { k: 'colorMarco', t: 'color', e: 'Color del marco', si: (v) => v.marco },
    { k: 'colorHoja', t: 'color', e: 'Color de la hoja', si: (v) => !v.modelo && v.estilo !== 'energia' },
    { k: 'colorEnergia', t: 'color', e: 'Color del campo', si: (v) => !v.modelo && v.estilo === 'energia' },
    { k: 'opacidadEnergia', t: 'rango', e: 'Opacidad del campo', min: 0.1, max: 1, paso: 0.05, si: (v) => v.estilo === 'energia' },
    { k: 'modelo', t: 'asset', e: 'Modelo de la hoja', tipoAsset: 'modelo', vacio: '(hoja del motor)',
      ayuda: 'Tu modelo hace de hoja (se abre con el estilo elegido) o usa su animación. Con transparencia: estilo campo de energía' },
    { k: 'modeloEscala', t: 'num', e: 'Escala del modelo', paso: 0.05, min: 0.01, si: (v) => v.modelo },
    { k: 'modeloX', t: 'num', e: 'Ajuste X', paso: 0.05, si: (v) => v.modelo, av: true },
    { k: 'modeloY', t: 'num', e: 'Ajuste Y', paso: 0.05, si: (v) => v.modelo, av: true },
    { k: 'modeloZ', t: 'num', e: 'Ajuste Z', paso: 0.05, si: (v) => v.modelo, av: true },
    { k: 'modeloGiro', t: 'num', e: 'Girar modelo (°)', paso: 15, si: (v) => v.modelo },
    { k: 'animAbrir', t: 'sel', e: 'Animación al abrir', op: [['', '(la mueve el motor)']], si: (v) => v.modelo,
      ayuda: 'Si el modelo trae animación de abrir, la usa en vez de moverlo el motor (deja de chocar al terminar)' },
    { k: 'animCerrar', t: 'sel', e: 'Animación al cerrar', op: [['', '(la de abrir al revés)']], si: (v) => v.modelo && v.animAbrir },
    { grupo: 'Sonidos', av: true },
    { k: 'sonidoAbrir', t: 'asset', e: 'Al abrir', tipoAsset: 'audio', vacio: '(del motor)', av: true },
    { k: 'sonidoCerrar', t: 'asset', e: 'Al cerrar', tipoAsset: 'audio', vacio: '(del motor)', av: true },
    { k: 'sonidoCerrada', t: 'asset', e: 'Cerrada con llave', tipoAsset: 'audio', vacio: '(del motor)', av: true },
    { k: 'sonidoLlave', t: 'asset', e: 'Al usar la llave', tipoAsset: 'audio', vacio: '(del motor)', av: true },
  ];

  /* ---------- Qué puede hacer una palanca (o un disparador) ----------
     que: id · e: texto del selector · obj: tipo de entidad que pide ('' = ninguna) · inv: lo contrario al apagarse */
  const ACCIONES = [
    { que: 'abrir', e: '🔒 Abrir puerta', obj: 'puerta', inv: 'cerrar' },
    { que: 'cerrar', e: '🔒 Cerrar puerta', obj: 'puerta', inv: 'abrir' },
    { que: 'alternar', e: '🔒 Abrir / cerrar puerta', obj: 'puerta', inv: 'alternar' },
    { que: 'bloquear', e: '⛓ Encerrar: cerrar y bloquear puerta', obj: 'puerta', inv: 'desbloquear' },
    { que: 'desbloquear', e: '⛓ Liberar puerta (vuelve a como estaba)', obj: 'puerta', inv: 'bloquear' },
    { que: 'luzOn', e: '💡 Encender luz', obj: 'luz', inv: 'luzOff' },
    { que: 'luzOff', e: '💡 Apagar luz', obj: 'luz', inv: 'luzOn' },
    { que: 'luzAlt', e: '💡 Encender / apagar luz', obj: 'luz', inv: 'luzAlt' },
    { que: 'marcaOn', e: '📌 Mostrar marcador de brújula', obj: 'marcador', inv: 'marcaOff' },
    { que: 'marcaOff', e: '📌 Ocultar marcador de brújula', obj: 'marcador', inv: 'marcaOn' },
    { que: 'apaOn', e: '🥚 Encender aparecedor / empezar oleadas', obj: 'aparecedor', inv: 'apaOff' },
    { que: 'apaOff', e: '🥚 Apagar aparecedor', obj: 'aparecedor', inv: 'apaOn' },
    { que: 'despertar', e: '☠ Despertar enemigo (va a por ti)', obj: 'enemigo' },
    { que: 'condOn', e: '⚙ Encender condición', obj: 'condicion', inv: 'condOff' },
    { que: 'condOff', e: '⚙ Apagar condición', obj: 'condicion', inv: 'condOn' },
    { que: 'palOn', e: '🕹 Encender otra palanca', obj: 'palanca', inv: 'palOff' },
    { que: 'palOff', e: '🕹 Apagar otra palanca', obj: 'palanca', inv: 'palOn' },
    { que: 'disOn', e: '⬚ Encender disparador', obj: 'disparador', inv: 'disOff' },
    { que: 'disOff', e: '⬚ Apagar disparador', obj: 'disparador', inv: 'disOn' },
    { que: 'platIr', e: '⇅ Mover plataforma a su destino', obj: 'plataforma', inv: 'platVolver' },
    { que: 'platVolver', e: '⇅ Devolver plataforma a su sitio', obj: 'plataforma', inv: 'platIr' },
    { que: 'platAlt', e: '⇅ Mover plataforma (ida / vuelta)', obj: 'plataforma', inv: 'platAlt' },
    { que: 'platOn', e: '⇅ Encender plataforma (vaivén)', obj: 'plataforma', inv: 'platOff' },
    { que: 'platOff', e: '⇅ Parar plataforma', obj: 'plataforma', inv: 'platOn' },
    { que: 'trampaOn', e: '⚠ Encender trampa', obj: 'trampa', inv: 'trampaOff' },
    { que: 'trampaOff', e: '⚠ Apagar trampa', obj: 'trampa', inv: 'trampaOn' },
    { que: 'trampaDisparar', e: '⚠ Disparar trampa (abre, baja o lanza una vez)', obj: 'trampa' },
    { que: 'camara', e: '📷 Cambiar a cámara fija', obj: 'camara' },
    { que: 'mision', e: '🏁 Terminar la misión (puntuación y fin)', obj: '' },
    { que: 'victoria', e: '🏆 Juego completado (pantalla de victoria)', obj: '' },
    { que: 'bombaOn', e: '💣 Activar bomba (empieza la cuenta atrás)', obj: 'bomba' },
    { que: 'sonOn', e: '🔊 Encender sonido', obj: 'sonido', inv: 'sonOff' },
    { que: 'sonOff', e: '🔊 Apagar sonido', obj: 'sonido', inv: 'sonOn' },
    { que: 'lluviaOn', e: '🌧 Empezar a llover (clima)', obj: '', inv: 'lluviaOff' },
    { que: 'lluviaOff', e: '🌤 Parar la lluvia (clima)', obj: '', inv: 'lluviaOn' },
    { que: 'rayo', e: '🌩 Rayo y trueno (clima)', obj: '' },
    { que: 'hora', e: '🕓 Poner la hora (clima)', obj: '' },
    { que: 'matar', e: '☠ Dañar al jugador (trampa, caída)', obj: '' },
    { que: 'mensaje', e: '💬 Mostrar mensaje', obj: '' },
    { que: 'cine', e: '🎬 Ver cinemática', obj: '' },
    { que: 'explosion', e: '💥 Explosión', obj: '' },
    { que: 'barOn', e: '⬡ Encender barrera de energía', obj: 'barrera', inv: 'barOff' },
    { que: 'barOff', e: '⬡ Apagar barrera de energía', obj: 'barrera', inv: 'barOn' },
    { que: 'barAlt', e: '⬡ Encender / apagar barrera', obj: 'barrera', inv: 'barAlt' },
    { que: 'partOn', e: '✨ Encender partículas', obj: 'particulas', inv: 'partOff' },
    { que: 'partOff', e: '✨ Apagar partículas', obj: 'particulas', inv: 'partOn' },
    { que: 'partAlt', e: '✨ Encender / apagar partículas', obj: 'particulas', inv: 'partAlt' },
    { que: 'efectos', e: '📼 Cambiar efectos de cámara (VHS, anime, barras…)', obj: '', inv: 'efectosNivel' },
    { que: 'efectosNivel', e: '📼 Volver a los efectos del nivel', obj: '', inv: 'efectos' },
    { que: 'sonido', e: '🔊 Sonar', obj: '' },
    { que: 'musica', e: '🎵 Cambiar la música', obj: '', inv: 'musicaNivel' },
    { que: 'musicaNivel', e: '🎵 Volver a la música del nivel', obj: '', inv: 'musica' },
    { que: 'nivel', e: '🚪 Ir a otro nivel', obj: '' },
    { que: 'canal', e: '📡 Avisar a un canal', obj: '', inv: 'canal' },
  ];
  const ACCION = Object.fromEntries(ACCIONES.map((a) => [a.que, a]));
  function accionNueva(extra = {}) { return { que: 'abrir', a: '', texto: '', asset: '', destino: '', llegada: '', canal: '', retraso: 0, cantidad: 9999, ...extra }; }

  const PLATAFORMA = {
    modo: 'pisar',            // 'pisar' | 'vaiven' | 'mecanismo'
    dx: 0, dy: 3, dz: 0,      // recorrido (m) desde donde está
    tiempo: 3,                // segundos de un viaje
    espera: 2,                // pisar: lo que espera arriba antes de volver · vaivén: en cada extremo
    volver: true,             // pisar: vuelve sola cuando te bajas
    encendida: true,          // vaivén: se mueve desde el principio
    empiezaEnDestino: false,
    ancho: 2, alto: 0.3, largo: 2,
    color: '#7a7f8a',
    sonido: '',
  };
  const ESQUEMA_PLATAFORMA = [
    { k: 'modo', t: 'sel', e: 'Se mueve', op: [['pisar', '🚶 Al subirte (elevador)'], ['vaiven', '↔ Siempre, de ida y vuelta'], ['mecanismo', '🕹 Solo con palanca, botón o disparador']],
      ayuda: 'Al subirte: como los elevadores de Doom; va a su destino y vuelve cuando te bajas' },
    { grupo: 'Recorrido (m)' },
    { k: 'dx', t: 'num', e: 'Hacia los lados (X)', paso: 0.5 },
    { k: 'dy', t: 'num', e: 'Hacia arriba (Y)', paso: 0.5, ayuda: 'Negativo = baja' },
    { k: 'dz', t: 'num', e: 'Adelante / atrás (Z)', paso: 0.5 },
    { k: 'tiempo', t: 'num', e: 'Tarda en llegar (s)', paso: 0.25, min: 0.2 },
    { k: 'espera', t: 'num', e: 'Espera (s)', paso: 0.25, min: 0, si: (v) => v.modo !== 'mecanismo', ayuda: 'Al subirte: cuánto espera para volver. Vaivén: en cada extremo' },
    { k: 'volver', t: 'bool', e: 'Vuelve sola al bajarte', si: (v) => v.modo === 'pisar' },
    { k: 'encendida', t: 'bool', e: 'Se mueve desde el principio', si: (v) => v.modo === 'vaiven', ayuda: 'Apagada: la enciende una palanca ("Encender plataforma")' },
    { k: 'empiezaEnDestino', t: 'bool', e: 'Empieza en su destino', av: true },
    { grupo: 'Cómo es' },
    { k: 'ancho', t: 'num', e: 'Ancho (m)', paso: 0.25, min: 0.25 },
    { k: 'alto', t: 'num', e: 'Grosor (m)', paso: 0.05, min: 0.05 },
    { k: 'largo', t: 'num', e: 'Largo (m)', paso: 0.25, min: 0.25 },
    { k: 'color', t: 'color', e: 'Color' },
    { k: 'sonido', t: 'asset', e: 'Sonido al moverse', tipoAsset: 'audio', vacio: '(del motor)', av: true },
  ];

  // ⇅ figura: la plataforma (su parte de arriba a la altura de la entidad) y, solo en el editor, su destino
  function figuraPlataforma(ent) {
    const p = { ...PLATAFORMA, ...(ent.plataforma || {}) };
    const g = new T.Group();
    const geo = new T.BoxGeometry(p.ancho, p.alto, p.largo).translate(0, -p.alto / 2, 0);
    const caja = new T.Mesh(geo, F.Render.matRetro(p.color));
    g.add(caja);
    const fantasma = new T.LineSegments(new T.EdgesGeometry(geo), new T.LineBasicMaterial({ color: 0x5fc8ff, fog: false }));
    fantasma.position.set(p.dx, p.dy, p.dz);
    const camino = new T.Line(new T.BufferGeometry().setFromPoints([new T.Vector3(), new T.Vector3(p.dx, p.dy, p.dz)]), new T.LineBasicMaterial({ color: 0x5fc8ff, fog: false }));
    for (const o of [fantasma, camino]) { o.userData.ayudaEditor = true; o.raycast = () => {}; g.add(o); }
    F.Luces.aplicarSombras(g, true);
    return g;
  }

  /* ---------- ⚠ Trampas ----------
     forma 'trampilla': losa del suelo que se abre al pisarla (o con mecanismo) sobre un foso (con daño opcional).
     forma 'trituradora': bloque que baja de golpe y sube despacio; aplasta (daño) a quien pille debajo.
     forma 'lanzaclavos': dispara clavos hacia delante (−Z): siempre, al acercarte o con mecanismo.
     La entidad marca: trampilla = la cara de arriba de la losa · trituradora = el centro del bloque arriba ·
     lanzaclavos = la boquilla (en la pared) */
  const TRAMPA = {
    forma: 'trampilla',
    activa: true,             // apagada no hace nada hasta que la encienda una acción o su canal
    canal: '',
    ancho: 2, largo: 2,
    // trampilla
    activar: 'pisar',         // 'pisar' | 'mecanismo'
    retraso: 0.35,            // s pisándola hasta que se abre
    cerrarTras: 3,            // s abierta (0 = se queda abierta)
    grosor: 0.1,
    danoFoso: 0,              // vida por segundo dentro del foso (pinchos) · 0 = nada
    // trituradora
    alto: 0.7, recorrido: 2.5,
    bajar: 0.3, subir: 1.6, esperaAbajo: 0.5, esperaArriba: 1.5, desfase: 0,
    dano: 9999,               // al aplastar (9999 = muerte)
    // lanzaclavos
    disparo: 'cerca',         // 'siempre' | 'cerca' | 'mecanismo'
    distancia: 12, cadencia: 1.5, danoClavo: 15, velocidad: 16, alcance: 25,
    color: '#5a5f68',
    sonido: '',
  };
  const esT = (f) => (v) => v.forma === f;
  const ESQUEMA_TRAMPA = [
    { k: 'forma', t: 'sel', e: 'Trampa', op: [['trampilla', '⬇ Trampilla (el suelo se abre)'], ['trituradora', '⬛ Trituradora (aplasta)'], ['lanzaclavos', '➶ Lanzaclavos']] },
    { k: 'activa', t: 'bool', e: 'Encendida al empezar', ayuda: 'Apagada: no hace nada hasta que una palanca, un disparador o su canal la encienda' },
    { grupo: 'Tamaño (m)', si: (v) => v.forma !== 'lanzaclavos' },
    { k: 'ancho', t: 'num', e: 'Ancho', paso: 0.1, min: 0.2, si: (v) => v.forma !== 'lanzaclavos' },
    { k: 'largo', t: 'num', e: 'Largo', paso: 0.1, min: 0.2, si: (v) => v.forma !== 'lanzaclavos' },
    { k: 'grosor', t: 'num', e: 'Grosor de la losa', paso: 0.05, min: 0.02, si: esT('trampilla'), av: true },
    { k: 'alto', t: 'num', e: 'Alto del bloque', paso: 0.1, min: 0.1, si: esT('trituradora') },
    { grupo: 'Cómo funciona' },
    { k: 'activar', t: 'sel', e: 'Se abre', op: [['pisar', '🚶 Al pisarla'], ['mecanismo', '🕹 Solo con palanca o disparador']], si: esT('trampilla') },
    { k: 'retraso', t: 'num', e: 'Tarda en abrirse (s)', paso: 0.05, min: 0, si: (v) => v.forma === 'trampilla' && v.activar === 'pisar', ayuda: 'Tiempo pisándola antes de abrirse: poco = imposible de esquivar, más = da tiempo a saltar' },
    { k: 'cerrarTras', t: 'num', e: 'Se cierra tras (s)', paso: 0.5, min: 0, si: esT('trampilla'), ayuda: '0 = se queda abierta' },
    { k: 'danoFoso', t: 'num', e: 'Daño en el foso (por s)', paso: 5, min: 0, si: esT('trampilla'), ayuda: 'Pinchos en el fondo. 0 = solo caes' },
    { k: 'recorrido', t: 'num', e: 'Baja (m)', paso: 0.1, min: 0.1, si: esT('trituradora'), ayuda: 'Hasta el suelo: el bloque de abajo (fantasma azul) debe tocarlo' },
    { k: 'bajar', t: 'num', e: 'Tarda en bajar (s)', paso: 0.05, min: 0.05, si: esT('trituradora') },
    { k: 'esperaAbajo', t: 'num', e: 'Abajo espera (s)', paso: 0.1, min: 0, si: esT('trituradora') },
    { k: 'subir', t: 'num', e: 'Tarda en subir (s)', paso: 0.1, min: 0.1, si: esT('trituradora') },
    { k: 'esperaArriba', t: 'num', e: 'Arriba espera (s)', paso: 0.1, min: 0, si: esT('trituradora') },
    { k: 'desfase', t: 'num', e: 'Empieza con retraso (s)', paso: 0.1, min: 0, si: esT('trituradora'), ayuda: 'Para que varias trituradoras seguidas no bajen a la vez' },
    { k: 'dano', t: 'num', e: 'Daño al aplastar', paso: 5, min: 0, si: esT('trituradora'), ayuda: '9999 = muerte' },
    { k: 'disparo', t: 'sel', e: 'Dispara', op: [['cerca', '🚶 Cuando estás cerca'], ['siempre', '⏱ Siempre'], ['mecanismo', '🕹 Solo con palanca o disparador']], si: esT('lanzaclavos') },
    { k: 'distancia', t: 'num', e: 'Cerca = a (m)', paso: 1, min: 1, si: (v) => v.forma === 'lanzaclavos' && v.disparo === 'cerca' },
    { k: 'cadencia', t: 'num', e: 'Cada (s)', paso: 0.1, min: 0.1, si: (v) => v.forma === 'lanzaclavos' && v.disparo !== 'mecanismo' },
    { k: 'danoClavo', t: 'num', e: 'Daño del clavo', paso: 1, min: 0, si: esT('lanzaclavos') },
    { k: 'velocidad', t: 'num', e: 'Velocidad (m/s)', paso: 1, min: 1, si: esT('lanzaclavos'), av: true },
    { k: 'alcance', t: 'num', e: 'Alcance (m)', paso: 1, min: 1, si: esT('lanzaclavos'), av: true },
    { grupo: 'Cómo se ve' },
    { k: 'color', t: 'color', e: 'Color' },
    { k: 'sonido', t: 'asset', e: 'Sonido', tipoAsset: 'audio', vacio: '(del motor)', av: true },
  ];

  // ⚠ figura: la pieza que se mueve (fig.pieza; choca como pieza móvil) y, solo en el editor, su recorrido
  function figuraTrampa(ent) {
    const p = { ...TRAMPA, ...(ent.trampa || {}) };
    const g = new T.Group();
    const mat = F.Render.matRetro(p.color), oscuro = F.Render.matRetro('#2a2c30'), metal = F.Render.matRetro('#c8ccd4');
    const ayuda = (o) => { o.userData.ayudaEditor = true; o.raycast = () => {}; g.add(o); };
    const lineas = (geo, color = 0x5fc8ff) => new T.LineSegments(new T.EdgesGeometry(geo), new T.LineBasicMaterial({ color, fog: false }));
    const fig = { pieza: null };
    if (p.forma === 'trampilla') {
      const piv = new T.Group();
      piv.position.set(-p.ancho / 2, 0, 0);                       // bisagra en el borde −X
      const losa = new T.Mesh(new T.BoxGeometry(p.ancho, p.grosor, p.largo).translate(p.ancho / 2, -p.grosor / 2, 0), mat);
      // juntas pintadas (para que se adivine… o no)
      const raya = new T.Mesh(new T.BoxGeometry(p.ancho * 0.96, 0.004, 0.03).translate(p.ancho / 2, 0.002, 0), oscuro);
      piv.add(losa, raya);
      g.add(piv);
      fig.pieza = piv;
      ayuda(lineas(new T.BoxGeometry(p.ancho, 0.02, p.largo).translate(0, -1, 0), 0xff7a3a));   // el foso
    } else if (p.forma === 'trituradora') {
      const piv = new T.Group();
      const bloque = new T.Mesh(new T.BoxGeometry(p.ancho, p.alto, p.largo), mat);
      piv.add(bloque);
      // dientes abajo
      const n = Math.max(2, Math.round(p.ancho / 0.4));
      const diente = new T.ConeGeometry(0.07, 0.16, 4).rotateX(Math.PI);
      for (let i = 0; i < n; i++) for (let k = 0; k < n; k++) {
        const d = new T.Mesh(diente, metal);
        d.position.set((i + 0.5) / n * p.ancho - p.ancho / 2, -p.alto / 2 - 0.08, (k + 0.5) / n * p.largo - p.largo / 2);
        piv.add(d);
      }
      g.add(piv);
      fig.pieza = piv;
      const abajo = lineas(new T.BoxGeometry(p.ancho, p.alto, p.largo));
      abajo.position.y = -p.recorrido;
      ayuda(abajo);
      ayuda(new T.Line(new T.BufferGeometry().setFromPoints([new T.Vector3(), new T.Vector3(0, -p.recorrido, 0)]), new T.LineBasicMaterial({ color: 0x5fc8ff, fog: false })));
    } else {
      const cuerpo = new T.Mesh(new T.BoxGeometry(0.5, 0.4, 0.12).translate(0, 0, 0.06), mat);
      g.add(cuerpo);
      for (const [x, y] of [[-0.12, -0.08], [0.12, -0.08], [-0.12, 0.08], [0.12, 0.08]]) {
        const b = new T.Mesh(new T.BoxGeometry(0.06, 0.06, 0.03).translate(0, 0, -0.005), oscuro);
        b.position.set(x, y, 0);
        g.add(b);
      }
      ayuda(new T.Line(new T.BufferGeometry().setFromPoints([new T.Vector3(), new T.Vector3(0, 0, -p.alcance)]), new T.LineBasicMaterial({ color: 0xff7a3a, fog: false })));
      const flecha = new T.Mesh(new T.ConeGeometry(0.08, 0.25, 4).rotateX(-Math.PI / 2).translate(0, 0, -0.5), new T.MeshBasicMaterial({ color: 0xff7a3a, fog: false }));
      ayuda(flecha);
    }
    F.Luces.aplicarSombras(g, true);
    g.userData.trampa = fig;
    return g;
  }

  const PALANCA = {
    forma: 'palanca',         // 'palanca' (de suelo) | 'boton' (de pared) | 'interruptor' (de pared, sube / baja)
    modo: 'alternar',         // 'alternar' | 'una' | 'volver'
    volverTras: 3,            // 'volver': segundos
    alApagar: 'invertir',     // 'invertir' (deshace lo que se pueda) | 'nada'
    empiezaEncendida: false,
    acciones: [],             // "Qué hace" (accionNueva)
    canal: '',                // escucha este canal ('' = ninguno)
    aviso: '',                // '' = "Usar <nombre>"
    color: '#b8322a',         // mango / botón
    colorBase: '#3a3a40',
    sonido: '',
  };
  const ESQUEMA_PALANCA = [
    { k: 'forma', t: 'sel', e: 'Forma', op: [['palanca', '🕹 Palanca de suelo'], ['boton', '🔴 Botón de pared'], ['interruptor', '⏻ Interruptor de pared']] },
    { k: 'modo', t: 'sel', e: 'Al usarla', op: [['alternar', 'Enciende / apaga (cada vez)'], ['una', 'Una sola vez'], ['volver', 'Vuelve sola (temporizador)']],
      ayuda: 'Una sola vez: no se puede deshacer. Vuelve sola: como un botón con tiempo (la puerta se cierra al acabar)' },
    { k: 'volverTras', t: 'num', e: 'Vuelve tras (s)', paso: 0.5, min: 0.2, si: (v) => v.modo === 'volver' },
    { k: 'alApagar', t: 'sel', e: 'Al apagarse', op: [['invertir', 'Deshace lo que hizo (cierra, apaga…)'], ['nada', 'No hace nada']], si: (v) => v.modo !== 'una',
      ayuda: 'Deshacer: abrir ↔ cerrar, encender ↔ apagar, mostrar ↔ ocultar. Mensajes, sonidos y viajes no se repiten' },
    { k: 'empiezaEncendida', t: 'bool', e: 'Empieza encendida', ayuda: 'Solo cambia cómo se ve al empezar (no hace sus acciones)' },
    { k: 'aviso', t: 'texto', e: 'Aviso al mirarla', av: true, ayuda: 'Vacío = "Usar <nombre>"' },
    { grupo: 'Cómo se ve' },
    { k: 'color', t: 'color', e: 'Color del mango / botón' },
    { k: 'colorBase', t: 'color', e: 'Color de la base' },
    { k: 'sonido', t: 'asset', e: 'Sonido al usarla', tipoAsset: 'audio', vacio: '(del motor)', av: true },
  ];

  const DISPARADOR = {
    cuando: 'una',            // 'una' | 'cada' | 'entrarSalir'
    espera: 1,                // 'cada': segundos antes de poder volver a saltar
    quien: 'jugador',         // 'jugador' | 'enemigos' | 'todos' | 'objetos' (🧱) | 'jugadorObjetos'
    etiqueta: '',             // con objetos: solo los 🧱 con esta etiqueta ('' = cualquiera)
    placa: false,             // placa de presión visible en el juego (se hunde al pisarla)
    activo: true,             // apagado no hace nada hasta que lo enciendan (acción o canal)
    canal: '',                // escucha: encendido = se activa, apagado = se apaga
    acciones: [],
    color: '#b46bff',         // solo en el editor
  };
  const ESQUEMA_DISPARADOR = [
    { k: 'cuando', t: 'sel', e: 'Salta', op: [['una', 'Una sola vez (la primera vez que entras)'], ['cada', 'Cada vez que entras'], ['entrarSalir', 'Al entrar, y al salir deshace']],
      ayuda: 'Al entrar y salir: al salir hace lo contrario (cierra lo que abrió, apaga lo que encendió). Bueno para luces de pasillo' },
    { k: 'espera', t: 'num', e: 'Espera para volver (s)', paso: 0.5, min: 0, si: (v) => v.cuando === 'cada' },
    { k: 'quien', t: 'sel', e: 'Lo activa', op: [['jugador', '🧍 El jugador'], ['enemigos', '☠ Los enemigos'], ['todos', 'Jugador o enemigos'], ['objetos', '🧱 Objetos movibles'], ['jugadorObjetos', 'Jugador u objetos movibles']] },
    { k: 'etiqueta', t: 'texto', e: 'Etiqueta del objeto', si: (v) => v.quien === 'objetos' || v.quien === 'jugadorObjetos', ayuda: 'Vacío = cualquier objeto movible. Ej. "estatua"' },
    { k: 'placa', t: 'bool', e: 'Placa de presión visible', ayuda: 'Se ve en el juego y se hunde mientras hay algo encima. Para que se suelte al salir usa "Al entrar, y al salir deshace"' },
    { k: 'activo', t: 'bool', e: 'Encendido al empezar', ayuda: 'Apagado: no hace nada hasta que una palanca, otro disparador o un canal lo encienda' },
    { k: 'color', t: 'color', e: 'Color en el editor', av: true },
  ];

  // ⬚ figura (solo se ve en el editor): caja de 1×1×1 sobre el suelo que se agranda con la escala
  function figuraDisparador(ent) {
    const p = { ...DISPARADOR, ...(ent.disparador || {}) };
    const g = new T.Group();
    const geo = new T.BoxGeometry(1, 1, 1).translate(0, 0.5, 0);
    const relleno = new T.Mesh(geo, new T.MeshBasicMaterial({ color: p.color, transparent: true, opacity: 0.12, depthWrite: false, fog: false }));
    const bordes = new T.LineSegments(new T.EdgesGeometry(geo), new T.LineBasicMaterial({ color: p.color, fog: false }));
    for (const o of [relleno, bordes]) { o.userData.ayudaEditor = true; g.add(o); }
    if (p.placa) {   // placa de presión: losa baja que se hunde (userData.placa)
      const placa = new T.Mesh(new T.BoxGeometry(0.9, 0.08, 0.9), F.Render.matRetro(p.color));
      placa.position.y = 0.04;
      g.add(placa);
      g.userData.placa = placa;
    }
    return g;
  }

  const PEDESTAL = {
    objeto: '',               // id de proyecto.objetos que encaja ('' = ninguno todavía)
    gastar: true,             // el objeto sale de la mochila al ponerlo
    sePuedeQuitar: false,     // se puede volver a coger (deshace lo que hizo)
    empiezaPuesto: false,
    acciones: [],
    avisoVacio: '',           // '' = "Aquí encaja algo" (sin el objeto) · con él: "Colocar <objeto>"
    color: '#8a8478',
  };
  const ESQUEMA_PEDESTAL = [
    { k: 'objeto', t: 'sel', e: 'Encaja', op: [['', '(elige el objeto)']], ayuda: 'Un objeto de Juego ▸ Objetos (mejor de tipo 🧩 objeto clave)' },
    { k: 'gastar', t: 'bool', e: 'El objeto se queda ahí', ayuda: 'Sí = sale de la mochila al ponerlo (Resident Evil). No = solo hace falta llevarlo' },
    { k: 'sePuedeQuitar', t: 'bool', e: 'Se puede quitar', si: (v) => v.gastar, ayuda: 'Volver a cogerlo deshace lo que hizo (balanza, puzle de estatuas)' },
    { k: 'empiezaPuesto', t: 'bool', e: 'Empieza puesto', av: true },
    { k: 'avisoVacio', t: 'texto', e: 'Mensaje sin el objeto', ayuda: 'Vacío = "Aquí encaja: <objeto>"' },
    { k: 'color', t: 'color', e: 'Color de la piedra' },
  ];
  const CONDICION = {
    modo: 'todas',            // 'todas' | 'alguna'
    unaVez: true,             // una vez cumplida, se queda así
    activa: true,             // apagada no se revisa hasta que la encienda una acción (arena: al entrar)
    requisitos: [],           // [{ tipo, a, estado }] (REQUISITOS)
    acciones: [],
  };
  // tipo: id · e: texto · obj: entidad que pide ('' = ninguna) · estados: [valor, texto] (si tiene)
  const REQUISITOS = [
    { tipo: 'palanca', e: '🕹 Palanca', obj: 'palanca', estados: [['on', 'encendida'], ['off', 'apagada']] },
    { tipo: 'pedestal', e: '🏺 Pedestal', obj: 'pedestal', estados: [['on', 'con su objeto'], ['off', 'vacío']] },
    { tipo: 'enemigo', e: '☠ Enemigo muerto (un jefe…)', obj: 'enemigo' },
    { tipo: 'arena', e: '🥚 Oleadas terminadas', obj: 'aparecedor' },
    { tipo: 'todos', e: '☠ Todos los enemigos del nivel muertos', obj: '' },
    { tipo: 'disparador', e: '⬚ Disparador pisado', obj: 'disparador' },
    { tipo: 'puerta', e: '🔒 Puerta', obj: 'puerta', estados: [['on', 'abierta'], ['off', 'cerrada']] },
  ];
  const REQUISITO = Object.fromEntries(REQUISITOS.map((r) => [r.tipo, r]));
  function requisitoNuevo(extra = {}) { return { tipo: 'palanca', a: '', estado: 'on', ...extra }; }

  // 🏺 figura: columna con un hueco arriba (el objeto puesto se ve encima)
  function figuraPedestal(ent, proyecto) {
    const p = { ...PEDESTAL, ...(ent.pedestal || {}) };
    const retro = (c) => F.Render.matRetro(c);
    const g = new T.Group(), m = retro(p.color);
    const base = new T.Mesh(new T.BoxGeometry(0.62, 0.12, 0.62).translate(0, 0.06, 0), m);
    const col = new T.Mesh(new T.BoxGeometry(0.4, 0.8, 0.4).translate(0, 0.52, 0), m);
    const tapa = new T.Mesh(new T.BoxGeometry(0.56, 0.1, 0.56).translate(0, 0.97, 0), m);
    const hueco = new T.Mesh(new T.BoxGeometry(0.22, 0.02, 0.22).translate(0, 1.025, 0), retro('#2a2622'));
    g.add(base, col, tapa, hueco);
    // el objeto que encaja, encima (se ve solo cuando está puesto)
    const ob = p.objeto && proyecto && (proyecto.objetos || []).find((o) => o.id === p.objeto);
    const encima = new T.Group();
    encima.position.y = 1.03;
    if (ob && F.Inventario.figuraObjeto) encima.add(F.Inventario.figuraObjeto(ob, 0.6));
    g.add(encima);
    const z = new T.Mesh(new T.BoxGeometry(0.7, 1.4, 0.7).translate(0, 0.7, 0), new T.MeshBasicMaterial({ visible: false }));
    z.userData.ayudaEditor = true;
    g.add(z);
    F.Luces.aplicarSombras(g, true);
    g.userData.pedestal = { encima, poner: (v) => { encima.visible = v; } };
    g.userData.pedestal.poner(true);   // en el editor se ve puesto; al jugar lo decide juego.mecanismos
    return g;
  }

  // ⚙ figura (solo editor): un engranaje de líneas
  function figuraCondicion() {
    const g = new T.Group();
    const geo = new T.TorusGeometry(0.35, 0.08, 4, 8);
    const m = new T.Mesh(geo, new T.MeshBasicMaterial({ color: 0x5fe0a0, wireframe: true, fog: false }));
    m.position.y = 1.2;
    m.userData.ayudaEditor = true;
    const palo = new T.Mesh(new T.CylinderGeometry(0.02, 0.02, 1.2, 4).translate(0, 0.6, 0), new T.MeshBasicMaterial({ color: 0x5fe0a0, fog: false }));
    palo.userData.ayudaEditor = true;
    g.add(m, palo);
    return g;
  }

  // 🕹 figura: base + mango (o botón) que se mueve con userData.palanca.poner(k: 0..1). Frente = −Z
  function figuraPalanca(ent) {
    const p = { ...PALANCA, ...(ent.palanca || {}) };
    const retro = (c) => F.Render.matRetro(c);
    const g = new T.Group();
    const base = retro(p.colorBase), mango = retro(p.color);
    const fig = {};
    if (p.forma === 'palanca') {
      const caja = new T.Mesh(new T.BoxGeometry(0.42, 0.16, 0.3).translate(0, 0.08, 0), base);
      const pivote = new T.Group();
      pivote.position.set(0, 0.14, 0);
      const palo = new T.Mesh(new T.BoxGeometry(0.06, 0.72, 0.06).translate(0, 0.36, 0), retro('#8a8a90'));
      const bola = new T.Mesh(new T.BoxGeometry(0.13, 0.13, 0.13).translate(0, 0.74, 0), mango);
      pivote.add(palo, bola);
      g.add(caja, pivote);
      fig.poner = (k) => { pivote.rotation.x = 0.6 - 1.2 * k; };   // apagada hacia atrás, encendida hacia el frente
    } else if (p.forma === 'boton') {
      const placa = new T.Mesh(new T.BoxGeometry(0.3, 0.3, 0.06).translate(0, 1.1, 0.03), base);
      const boton = new T.Mesh(new T.BoxGeometry(0.14, 0.14, 0.08), mango);
      g.add(placa, boton);
      fig.poner = (k) => { boton.position.set(0, 1.1, -0.04 + 0.05 * k); };   // encendido = hundido
    } else {
      const placa = new T.Mesh(new T.BoxGeometry(0.18, 0.28, 0.05).translate(0, 1.2, 0.025), base);
      const pivote = new T.Group();
      pivote.position.set(0, 1.2, -0.005);
      const tecla = new T.Mesh(new T.BoxGeometry(0.06, 0.12, 0.06).translate(0, 0.05, -0.03), mango);
      pivote.add(tecla);
      g.add(placa, pivote);
      fig.poner = (k) => { pivote.rotation.x = 0.55 - 1.1 * k; };   // apagado hacia arriba-atrás, encendido hacia abajo
    }
    fig.poner(p.empiezaEncendida ? 1 : 0);
    // zona invisible para mirarla y usarla (una palanca fina es difícil de apuntar); no choca ni se ve
    const zona = p.forma === 'palanca' ? [0.7, 1.1, 0.7, 0.55] : [0.5, 0.5, 0.35, p.forma === 'boton' ? 1.1 : 1.2];
    const z = new T.Mesh(new T.BoxGeometry(zona[0], zona[1], zona[2]), new T.MeshBasicMaterial({ visible: false }));
    z.position.y = zona[3];
    z.userData.ayudaEditor = true;
    g.add(z);
    // flecha del frente para el editor
    const flecha = new T.Mesh(new T.ConeGeometry(0.06, 0.16, 4), new T.MeshBasicMaterial({ color: 0xe8a33d, fog: false }));
    flecha.rotation.x = -Math.PI / 2;
    flecha.position.set(0, 0.03, -0.3);
    flecha.userData.ayudaEditor = true;
    g.add(flecha);
    F.Luces.aplicarSombras(g, true);
    g.userData.palanca = fig;
    return g;
  }

  /* ---------- Figura de la puerta ----------
     raíz (escala = caja) → soporte (deshace la escala: nada se estira ni se tuerce al girar)
       → marco (fijo: va al mundo de colisión) + pivote (la hoja: pieza móvil) */
  function figura(ent) {
    const p = { ...PUERTA, ...(ent.puerta || {}) };
    const g = new T.Group();
    // ayuda del editor: la caja y la flecha del frente (−Z)
    const geo = new T.BoxGeometry(1, 1, 1);
    geo.translate(0, 0.5, 0);
    const bordes = new T.LineSegments(new T.EdgesGeometry(geo), new T.LineBasicMaterial({ color: 0xe8a33d, fog: false }));
    const flecha = new T.Mesh(new T.ConeGeometry(0.1, 0.25, 4), new T.MeshBasicMaterial({ color: 0xe8a33d, fog: false }));
    flecha.rotation.x = -Math.PI / 2;
    flecha.position.set(0, 0.04, -0.5);
    for (const o of [bordes, flecha]) { o.userData.ayudaEditor = true; g.add(o); }

    const retro = (c) => F.Render.matRetro(c);
    const cubo = new T.BoxGeometry(1, 1, 1).translate(0, 0.5, 0);
    const soporte = new T.Group();
    const marco = new T.Group();
    const mm = retro(p.colorMarco);
    const izq = new T.Mesh(cubo, mm), der = new T.Mesh(cubo, mm), arriba = new T.Mesh(cubo, mm);
    marco.add(izq, der, arriba);
    marco.visible = !!p.marco;
    soporte.add(marco);
    const pivote = new T.Group();
    const cuerpo = new T.Group();   // lo que se coloca dentro del pivote (hoja del motor o modelo)
    pivote.add(cuerpo);
    soporte.add(pivote);
    const fig = { marco, pivote, cuerpo, mats: [], energia: p.estilo === 'energia', W: 1, H: 1, D: 1, hueco: 1, alto: 1, base: new T.Vector3() };
    const a = p.modelo && F.Assets && F.Assets.mapa.get(p.modelo);
    let hoja = null, tirador = null;
    if (a && a.gltf) {
      const m = T.SkeletonUtils.clone(a.gltf.scene);
      m.scale.setScalar(p.modeloEscala || 1);
      m.rotation.y = (p.modeloGiro || 0) * F.DEG;
      m.userData.animaciones = a.gltf.animations || [];
      cuerpo.add(m);
      fig.modelo = m;
      m.traverse((o) => { if (o.isMesh && fig.energia) { o.material = o.material.clone(); fig.mats.push(o.material); } });   // copia propia solo si se desvanece
      if (fig.energia) for (const mt of fig.mats) { mt.transparent = true; mt.depthWrite = false; mt.userData.op = mt.opacity; }
    } else if (fig.energia) {
      const mt = new T.MeshBasicMaterial({ color: p.colorEnergia, transparent: true, opacity: p.opacidadEnergia, blending: T.AdditiveBlending, depthWrite: false, side: T.DoubleSide });
      mt.userData.op = p.opacidadEnergia;
      hoja = new T.Mesh(new T.BoxGeometry(1, 1, 1).translate(0.5, 0.5, 0), mt);
      fig.mats.push(mt);
      cuerpo.add(hoja);
    } else {
      hoja = new T.Mesh(new T.BoxGeometry(1, 1, 1).translate(0.5, 0.5, 0), retro(p.colorHoja));
      tirador = new T.Mesh(new T.BoxGeometry(0.06, 0.06, 0.16), retro('#d8c070'));
      cuerpo.add(hoja, tirador);
    }
    fig.hoja = hoja;

    // reparte las piezas para un hueco de W × H × D metros
    let ultimo = '';
    const colocar = (W, H, D) => {
      const clave = W.toFixed(3) + H.toFixed(3) + D.toFixed(3);
      if (clave === ultimo) return;
      ultimo = clave;
      const gr = p.marco ? Math.min(0.14, W * 0.1) : 0, fondo = Math.max(0.05, Math.min(0.3, D));
      izq.scale.set(gr || 0.001, H, fondo); izq.position.set(-W / 2 + gr / 2, 0, 0);
      der.scale.set(gr || 0.001, H, fondo); der.position.set(W / 2 - gr / 2, 0, 0);
      arriba.scale.set(W, gr || 0.001, fondo); arriba.position.set(0, H - gr, 0);
      const hueco = Math.max(0.05, W - gr * 2), alto = Math.max(0.05, H - gr);
      Object.assign(fig, { W, H, D, hueco, alto, gr });
      const derecha = p.lado === 'der' && p.estilo === 'bisagra';
      // el pivote está en la bisagra (izquierda o derecha); la hoja va de ahí hacia el otro lado
      fig.base.set(derecha ? W / 2 - gr : -W / 2 + gr, 0, 0);
      pivote.position.copy(fig.base);
      cuerpo.position.set(derecha ? -hueco : 0, 0, 0);
      const grosor = fig.energia ? Math.min(0.04, fondo) : Math.min(0.08, fondo * 0.6);
      if (hoja) hoja.scale.set(hueco, alto, grosor);
      if (tirador) tirador.position.set(derecha ? hueco * 0.14 : hueco * 0.86, alto * 0.47, 0);
      if (fig.modelo) fig.modelo.position.set(hueco / 2 + p.modeloX, p.modeloY, p.modeloZ);
    };
    soporte.updateMatrixWorld = function (force) {
      const e = this.parent ? this.parent.scale : null;
      if (e && e.x && e.y && e.z) { this.scale.set(1 / e.x, 1 / e.y, 1 / e.z); colocar(e.x, e.y, e.z); }
      T.Object3D.prototype.updateMatrixWorld.call(this, force);
    };
    const esc = ent.esc || [1, 1, 1];
    soporte.scale.set(1 / esc[0], 1 / esc[1], 1 / esc[2]);
    colocar(esc[0], esc[1], esc[2]);
    g.add(soporte);
    F.Luces.aplicarSombras(soporte, true);
    if (fig.energia && hoja) hoja.castShadow = false;
    g.userData.puerta = fig;
    g.userData.marcoPuerta = p.marco ? marco : null;
    return g;
  }

  const suave = (k) => k * k * (3 - 2 * k);

  /* =========================================================
     EN JUEGO (juego.mecanismos)
     ========================================================= */
  class Mecanismos {
    constructor(juego, guardado = null) {
      this.juego = juego;
      this.puertas = [];
      this._v = new T.Vector3();
      this._q = new T.Vector3();
      const mem = (guardado && guardado.mecanismos && guardado.mecanismos.puertas) || {};
      for (const ent of juego.escena.entidades) {
        if (ent.tipo !== 'puerta') continue;
        const obj = juego.objetos.get(ent.id);
        if (!obj || !obj.userData.puerta) continue;
        const p = { ...PUERTA, ...(ent.puerta || {}) };
        const m = mem[ent.id] || {};
        const it = { ent, obj, p, fig: obj.userData.puerta, k: 0, meta: 0, signo: 1, tCerrar: 0, lejos: 0,
          desbloqueada: !p.llave || !!m.desbloqueada, cerca: false, bloqueada: !!m.bloqueada, antesAbierta: !!m.antesAbierta };
        const abierta = m.abierta != null ? m.abierta : p.empiezaAbierta && p.estilo !== 'negro';
        if (abierta) { it.k = it.meta = 1; it.signo = m.signo || 1; }
        // animaciones del modelo
        const clips = (it.fig.modelo && it.fig.modelo.userData.animaciones) || [];
        if (clips.length && p.animAbrir) {
          it.mixer = new T.AnimationMixer(it.fig.modelo);
          const clip = (n) => n && clips.find((c) => c.name === n);
          const prep = (c) => { if (!c) return null; const a = it.mixer.clipAction(c); a.setLoop(T.LoopOnce, 1); a.clampWhenFinished = true; return a; };
          it.animAbrir = prep(clip(p.animAbrir));
          it.animCerrar = prep(clip(p.animCerrar));
          if (abierta && it.animAbrir) { it.animAbrir.play(); it.animAbrir.time = it.animAbrir.getClip().duration; }
        }
        this._poner(it);
        this.puertas.push(it);
      }
      // 🕹 palancas
      this.palancas = [];
      const memP = (guardado && guardado.mecanismos && guardado.mecanismos.palancas) || {};
      for (const ent of juego.escena.entidades) {
        if (ent.tipo !== 'palanca') continue;
        const obj = juego.objetos.get(ent.id);
        if (!obj || !obj.userData.palanca) continue;
        const p = { ...PALANCA, ...(ent.palanca || {}) };
        const m = memP[ent.id] || {};
        const it = { ent, obj, p, fig: obj.userData.palanca, on: m.on != null ? m.on : !!p.empiezaEncendida, usada: !!m.usada, k: 0, tVolver: 0 };
        it.k = it.on ? 1 : 0;
        it.fig.poner(it.k);
        this.palancas.push(it);
      }
      // ⬚ disparadores
      this.disparadores = [];
      const memD = (guardado && guardado.mecanismos && guardado.mecanismos.disparadores) || {};
      for (const ent of juego.escena.entidades) {
        if (ent.tipo !== 'disparador') continue;
        const obj = juego.objetos.get(ent.id);
        if (!obj) continue;
        obj.updateWorldMatrix(true, false);
        const p = { ...DISPARADOR, ...(ent.disparador || {}) };
        const m = memD[ent.id] || {};
        this.disparadores.push({ ent, obj, p, inv: obj.matrixWorld.clone().invert(), dentro: false, usado: !!m.usado,
          activo: m.activo != null ? m.activo : p.activo !== false, tEspera: 0 });
      }
      // 🏺 pedestales
      this.pedestales = [];
      const memPe = (guardado && guardado.mecanismos && guardado.mecanismos.pedestales) || {};
      for (const ent of juego.escena.entidades) {
        if (ent.tipo !== 'pedestal') continue;
        const obj = juego.objetos.get(ent.id);
        if (!obj || !obj.userData.pedestal) continue;
        const p = { ...PEDESTAL, ...(ent.pedestal || {}) };
        const m = memPe[ent.id] || {};
        const it = { ent, obj, p, fig: obj.userData.pedestal, puesto: m.puesto != null ? m.puesto : !!p.empiezaPuesto };
        it.fig.poner(it.puesto);
        this.pedestales.push(it);
      }
      // ⚙ condiciones
      this.condiciones = [];
      const memC = (guardado && guardado.mecanismos && guardado.mecanismos.condiciones) || {};
      for (const ent of juego.escena.entidades) {
        if (ent.tipo !== 'condicion') continue;
        const p = { ...CONDICION, ...(ent.condicion || {}) };
        const m = memC[ent.id] || {};
        this.condiciones.push({ ent, p, cumplida: !!m.cumplida, hecha: !!m.hecha, activa: m.activa != null ? m.activa : p.activa !== false });
      }
      // 📦 cofres de premio (los compartidos los abre la mochila: módulo Inventario)
      this.cofres = [];
      const memCo = (guardado && guardado.mecanismos && guardado.mecanismos.cofres) || {};
      for (const ent of juego.escena.entidades) {
        if (ent.tipo !== 'baul' || !ent.baul || ent.baul.modo !== 'premio') continue;
        const obj = juego.objetos.get(ent.id);
        if (!obj) continue;
        const it = { ent, obj, tapa: obj.userData.tapa, abierto: !!memCo[ent.id], k: memCo[ent.id] ? 1 : 0 };
        if (it.tapa) it.tapa.rotation.x = -1.7 * it.k;
        this.cofres.push(it);
      }
      // ⇅ plataformas
      this.plataformas = [];
      const memPl = (guardado && guardado.mecanismos && guardado.mecanismos.plataformas) || {};
      for (const ent of juego.escena.entidades) {
        if (ent.tipo !== 'plataforma') continue;
        const obj = juego.objetos.get(ent.id);
        if (!obj) continue;
        const p = { ...PLATAFORMA, ...(ent.plataforma || {}) };
        const m = memPl[ent.id] || {};
        const it = { ent, obj, p, base: obj.position.clone(), rec: new T.Vector3(p.dx, p.dy, p.dz), k: 0, meta: 0, t: 0, encendida: p.encendida !== false, fuera: 0 };
        it.k = it.meta = m.k != null ? m.k : p.empiezaEnDestino ? 1 : 0;
        if (m.encendida != null) it.encendida = m.encendida;
        obj.position.copy(it.base).addScaledVector(it.rec, it.k);
        this.plataformas.push(it);
      }
      // ⚠ trampas
      this.trampas = [];
      this.clavos = [];
      const memT = (guardado && guardado.mecanismos && guardado.mecanismos.trampas) || {};
      for (const ent of juego.escena.entidades) {
        if (ent.tipo !== 'trampa') continue;
        const obj = juego.objetos.get(ent.id);
        if (!obj || !obj.userData.trampa) continue;
        const p = { ...TRAMPA, ...(ent.trampa || {}) };
        const m = memT[ent.id] || {};
        this.trampas.push({ ent, obj, p, fig: obj.userData.trampa, activa: m.activa != null ? m.activa : p.activa !== false,
          k: 0, meta: 0, t: -(p.desfase || 0), fase: 'arriba', tPisar: 0, tCerrar: 0, tFoso: 0, tDisparo: 0.3, golpe: false });
      }
      this._tCond = 0;
      this._tEnem = 0;
      this.pendientes = [];   // acciones con retraso: { t, a, on }
      this.alMundo(juego.mundo);
      // al volver al nivel (o cargar partida): lo que encendió una palanca sigue encendido (luces y marcadores;
      // las puertas ya se recuerdan solas y las oleadas no se repiten)
      this._restaurar = this.palancas.filter((it) => memP[it.ent.id] && it.on);
    }

    // después de crear brújula y luces (juego.iniciar): reponer lo de las palancas recordadas
    reponer() {
      for (const it of this._restaurar || []) {
        for (const a of it.p.acciones || []) if (/^(luz|marca)/.test(a.que)) this._hacer(a, true);
      }
      this._restaurar = null;
    }

    // el mundo de colisión es nuevo (al empezar o tras romper algo): las hojas vuelven a ser piezas móviles
    alMundo(mundo) {
      const piezas = [], dueños = [];
      for (const it of this.puertas) {
        if (it.p.estilo === 'negro' && !it.fig.pivote.children.length) continue;
        const local = F.Fisica.triangulosLocales(it.fig.pivote);
        if (!local.length) continue;
        piezas.push({ local, obj: it.fig.pivote, activa: this._choca(it) });
        dueños.push(it);
      }
      for (const it of this.plataformas || []) {
        const local = F.Fisica.triangulosLocales(it.obj);
        if (!local.length) continue;
        piezas.push({ local, obj: it.obj, activa: true });
        dueños.push(it);
      }
      for (const it of this.trampas || []) {
        if (!it.fig.pieza) continue;
        const local = F.Fisica.triangulosLocales(it.fig.pieza);
        if (!local.length) continue;
        piezas.push({ local, obj: it.fig.pieza, activa: true });
        dueños.push(it);
      }
      // 🧱 objetos movibles (motor/empujables.js)
      for (const it of (this.juego.empujables ? this.juego.empujables.lista : [])) {
        const local = F.Fisica.triangulosLocales(it.obj);
        if (!local.length) continue;
        piezas.push({ local, obj: it.obj, activa: this.juego.empujables.cargado !== it });
        dueños.push(it);
      }
      // 🐎 montables aparcados (motor/montables.js)
      for (const x of (this.juego.montables ? this.juego.montables.piezasMoviles() : [])) { piezas.push(x); dueños.push(x.it); }
      // 🚪 hojas de las puertas tácticas (motor/tactico.js)
      for (const x of (this.juego.tactico && this.juego.tactico.hay ? this.juego.tactico.piezasMoviles() : [])) { piezas.push(x); dueños.push({ _tact: x.it }); }
      const ms = piezas.length ? mundo.reservarMoviles(piezas) : [];
      dueños.forEach((it, i) => { if (it._tact) it._tact.pieza = ms[i]; else it.pieza = ms[i]; });
      this.mundo = mundo;
    }

    // ¿la hoja tapa el paso ahora?
    _choca(it) {
      if (it.p.estilo === 'energia') return it.k < 0.5;
      if (it.animAbrir) return it.k < 0.5;
      return true;   // las que giran o se deslizan chocan siempre (se apartan)
    }

    // pone la hoja según it.k (0 = cerrada, 1 = abierta)
    _poner(it) {
      const f = it.fig, p = it.p, k = suave(it.k);
      if (it.animAbrir) return;   // la anima su GLB
      f.pivote.position.copy(f.base);
      f.pivote.rotation.y = 0;
      if (p.estilo === 'bisagra') f.pivote.rotation.y = it.signo * GIRO * k;
      else if (p.estilo === 'deslizar') f.pivote.position.x = f.base.x + (p.lado === 'der' ? 1 : -1) * f.hueco * 0.95 * k;
      else if (p.estilo === 'arriba') f.pivote.position.y = f.alto * 0.95 * k;
      else if (p.estilo === 'energia') {
        for (const mt of f.mats) mt.opacity = (mt.userData.op ?? 1) * (1 - k);
        f.cuerpo.visible = k < 0.99;
      }
    }

    // ---- lo que ve el módulo Interactuar ----
    // texto del aviso, o null si ahora no se puede usar (abierta sin poder cerrarla, se abre sola…)
    textoUsar(ent) {
      if (ent.tipo === 'baul') { const c = this.cofres.find((x) => x.ent === ent); return c && !c.abierto ? 'Abrir ' + (ent.nombre || 'cofre') : null; }
      if (ent.tipo === 'pedestal') return this._textoPedestal(ent);
      if (ent.tipo === 'palanca') {
        const pl = this.palancas.find((x) => x.ent === ent);
        if (!pl || (pl.p.modo === 'una' && pl.usada) || (pl.p.modo === 'volver' && pl.on)) return null;
        return pl.p.aviso || 'Usar ' + (ent.nombre || 'palanca');
      }
      const it = this.puertas.find((x) => x.ent === ent);
      if (!it || it.p.abrir === 'cerca' || (it.p.abrir === 'mecanismo' && it.p.avisoMecanismo === false)) return null;
      // solo con la puerta QUIETA: mientras se abre, se cierra o espera a que te apartes, no hay aviso
      if (it.k !== it.meta || this.cruzando) return null;
      const abierta = it.meta > 0.5;
      if (abierta) return it.p.abrir === 'usar' && it.p.cerrarConUsar ? 'Cerrar ' + (ent.nombre || 'puerta') : null;
      return it.p.aviso || 'Abrir ' + (ent.nombre || 'puerta');
    }

    usar(ent) {
      if (ent.tipo === 'baul') { this.abrirCofre(ent); return; }
      if (ent.tipo === 'pedestal') { this.usarPedestal(ent); return; }
      if (ent.tipo === 'palanca') { this.usarPalanca(ent); return; }
      const it = this.puertas.find((x) => x.ent === ent);
      if (!it || this.cruzando || it.k !== it.meta) return;   // moviéndose: el botón no hace nada
      if (it.meta > 0.5) { if (it.p.abrir === 'usar' && it.p.cerrarConUsar) this.cerrar(it); return; }
      if (it.bloqueada) { this._cerrada(it, it.p.avisoBloqueada || 'Bloqueada. No se abre ahora'); return; }
      if (it.p.abrir === 'mecanismo') { this._cerrada(it, it.p.avisoCerrada || 'No se abre desde aquí'); return; }
      if (!this._llave(it)) return;
      if (it.p.estilo === 'negro') this._cruzar(it);
      else this.abrir(it);
    }

    // ¿tiene la llave (o no hace falta)? La gasta si toca. Si no la tiene: aviso de cerrada
    _llave(it) {
      if (it.desbloqueada) return true;
      const j = this.juego.jugador, inv = j && j.inventario;
      const def = (this.juego.proyecto.objetos || []).find((o) => o.id === it.p.llave);
      const i = inv ? inv.items.findIndex((x) => x && x.k === 'obj' && x.id === it.p.llave) : -1;
      if (i < 0) {
        this._cerrada(it, it.p.avisoCerrada || 'Está cerrada con llave' + (def ? `. Necesitas: ${def.nombre}` : ''));
        return false;
      }
      if (it.p.gastarLlave) inv.quitar(i, 1);
      it.desbloqueada = true;
      this._mensaje(`Usaste: ${def ? def.nombre : 'la llave'}`);
      if (it.p.sonidoLlave) F.Audio.efecto(it.p.sonidoLlave);
      else F.Audio.sintetico('recoger', { volumen: 0.5, tono: 1.6 });
      F.emitir('puerta-desbloqueada', { juego: this.juego, ent: it.ent });
      return true;
    }

    _cerrada(it, texto) {
      this._mensaje(texto);
      if (it.p.sonidoCerrada) F.Audio.efecto(it.p.sonidoCerrada);
      else F.Audio.sintetico('aterrizar', { volumen: 0.5, tono: 1.8 });
    }

    _mensaje(texto) { if (this.juego.recogibles) this.juego.recogibles.mensaje(texto); }

    // ---- API para palancas, disparadores, puzles (y para otros sistemas) ----
    // it puede ser el objeto interno, la entidad o su id
    _it(x) { return this.puertas.find((it) => it === x || it.ent === x || it.ent.id === x) || null; }

    abrir(x, desbloquear = false) {
      const it = this._it(x);
      if (!it || it.meta === 1 || it.bloqueada) return;   // encerrada (arena): solo la libera "desbloquear"
      if (desbloquear) it.desbloqueada = true;
      if (it.p.estilo === 'negro') return;   // una puerta de corte a negro no se abre: se cruza
      // la bisagra se abre hacia el lado contrario al jugador
      const j = this.juego.jugador;
      if (j && it.p.estilo === 'bisagra' && it.k < 0.05) {
        const q = this._local(it, j.cuerpo.pie);
        const derecha = it.p.lado === 'der';
        it.signo = (q.z < 0) !== derecha ? -1 : 1;
      }
      it.meta = 1;
      it.tCerrar = it.p.cerrarTras;
      if (it.animAbrir) { if (it.animCerrar) it.animCerrar.stop(); it.animAbrir.reset().setEffectiveTimeScale(1).play(); }
      this._sonido(it, true);
      F.emitir('puerta-abierta', { juego: this.juego, ent: it.ent });
    }

    cerrar(x) {
      const it = this._it(x);
      if (!it || it.meta === 0) return;
      it.meta = 0;
      if (it.animAbrir) {
        if (it.animCerrar) { it.animAbrir.stop(); it.animCerrar.reset().play(); }
        else { it.animAbrir.paused = false; it.animAbrir.setEffectiveTimeScale(-1).play(); }
      }
      this._sonido(it, false);
      F.emitir('puerta-cerrada', { juego: this.juego, ent: it.ent });
    }

    // ⛓ encerrar: se cierra y nada la abre (ni el jugador, ni "cerca", ni canales) hasta liberarla
    bloquear(x) {
      const it = this._it(x);
      if (!it || it.bloqueada) return;
      it.antesAbierta = it.meta > 0.5;
      it.bloqueada = true;
      this.cerrar(it);
    }

    // ⛓ liberar: vuelve a como estaba (si estaba abierta se abre; si tenía llave sigue pidiéndola)
    desbloquear(x) {
      const it = this._it(x);
      if (!it || !it.bloqueada) return;
      it.bloqueada = false;
      if (it.antesAbierta) this.abrir(it);
    }

    alternar(x) {
      const it = this._it(x);
      if (it) (it.meta > 0.5 ? this.cerrar(it) : this.abrir(it, true));
    }

    _sonido(it, abrir) {
      const s = abrir ? it.p.sonidoAbrir : it.p.sonidoCerrar;
      if (s) F.Audio.efecto(s, { posicion: it.obj.getWorldPosition(this._q) });
      else if (it.p.estilo === 'energia') F.Audio.sintetico('disparo', { volumen: 0.25, tono: abrir ? 0.4 : 0.6 });
      else F.Audio.sintetico('aterrizar', { volumen: 0.45, tono: abrir ? 0.7 : 0.55 });
    }

    // posición del mundo en el espacio de la puerta (x: a lo ancho, z: delante < 0 < detrás)
    _local(it, pos) {
      it.obj.updateWorldMatrix(true, false);
      const q = this._v.copy(pos);
      q.applyMatrix4(this._inv || (this._inv = new T.Matrix4()).copy(it.obj.matrixWorld).invert());
      q.x *= it.obj.scale.x; q.y *= it.obj.scale.y; q.z *= it.obj.scale.z;   // a metros
      return q;
    }

    /* ---------- 🕹 Palancas ---------- */
    _pal(x) { return this.palancas.find((it) => it === x || it.ent === x || it.ent.id === x) || null; }

    usarPalanca(x) {
      const it = this._pal(x);
      if (!it) return;
      if (it.p.modo === 'una' && it.usada) return;
      if (it.p.modo === 'volver' && it.on) return;
      this.ponerPalanca(it, it.p.modo === 'alternar' ? !it.on : true, true);
    }

    // enciende o apaga una palanca: se mueve, suena y hace su lista (o lo contrario)
    ponerPalanca(x, on, porJugador = false) {
      const it = this._pal(x);
      if (!it || it.on === on) return;
      if (it.p.modo === 'una' && it.usada) return;
      it.on = on;
      it.usada = it.usada || on;
      if (it.p.modo === 'volver' && on) it.tVolver = it.p.volverTras;
      if (it.p.sonido) F.Audio.efecto(it.p.sonido);
      else F.Audio.sintetico(it.p.forma === 'palanca' ? 'recarga' : 'golpe', { volumen: 0.6, tono: on ? 1 : 0.8 });
      F.emitir(on ? 'palanca-encendida' : 'palanca-apagada', { juego: this.juego, ent: it.ent, porJugador });
      this._tCond = 0;
      if (on) this.ejecutar(it.p.acciones, true);
      else if (it.p.alApagar === 'invertir') this.ejecutar(it.p.acciones, false);
    }

    /* ---------- 📦 Cofre de premio: se abre una vez y da lo que lleva ---------- */
    abrirCofre(x) {
      const it = this.cofres.find((c) => c === x || c.ent === x || c.ent.id === x);
      if (!it || it.abierto) return;
      it.abierto = true;
      const R = this.juego.recogibles, contenido = (it.ent.baul.contenido || []);
      F.Audio.sintetico('aterrizar', { volumen: 0.5, tono: 1.3 });
      setTimeout(() => F.Audio.sintetico('recoger', { volumen: 0.8, tono: 1 }), 250);
      if (!contenido.length) this._mensaje('Está vacío');
      for (const c of contenido) {
        const r = { ...F.Recogibles.BASE, ...c, soloSiFalta: false, aviso: true };
        if (R && R._aplicar(r, true)) R._avisar({ r });
      }
      F.emitir('cofre-abierto', { juego: this.juego, ent: it.ent });
    }

    /* ---------- ⇅ Plataformas ---------- */
    moverPlataforma(it, meta) {
      if (it.meta === meta) return;
      it.meta = meta;
      it.t = 0;
      if (it.p.sonido) F.Audio.efecto(it.p.sonido);
      else F.Audio.sintetico('aterrizar', { volumen: 0.35, tono: 0.45 });
      F.emitir('plataforma', { juego: this.juego, ent: it.ent, destino: meta === 1 });
    }

    // ¿estos pies están encima de la plataforma? (dentro de su caja vista desde arriba y a la altura de su cara de arriba)
    _encima(it, pie, radio) {
      const q = this._v.copy(pie);
      it.obj.parent.worldToLocal(q);
      const o = it.obj.position;
      return Math.abs(q.x - o.x) <= it.p.ancho / 2 + radio * 0.5 && Math.abs(q.z - o.z) <= it.p.largo / 2 + radio * 0.5 && Math.abs(q.y - o.y) < 0.3;
    }

    _plataformas(dt) {
      const j = this.juego.jugador;
      for (const it of this.plataformas) {
        const p = it.p;
        const subido = j && !j.muerto && this._encima(it, j.cuerpo.pie, j.cuerpo.radio);
        // qué decide moverse
        if (it.k === it.meta) {
          it.t += dt;
          if (p.modo === 'vaiven' && it.encendida && it.t >= p.espera) this.moverPlataforma(it, it.meta > 0.5 ? 0 : 1);
          if (p.modo === 'pisar') {
            if (subido && it.t > 0.35) {
              it.fuera = 0;
              if (it.meta === 0) this.moverPlataforma(it, 1);
            } else if (!subido && p.volver && it.meta === 1) {
              it.fuera += dt;
              if (it.fuera >= p.espera) { it.fuera = 0; this.moverPlataforma(it, 0); }
            }
          }
          continue;
        }
        // moverse: velocidad constante (con un poco de suavizado al llegar)
        const antes = this._q.setFromMatrixPosition(it.obj.matrixWorld).clone();
        const paso = dt / Math.max(0.2, p.tiempo);
        it.k = it.meta > it.k ? Math.min(it.meta, it.k + paso) : Math.max(it.meta, it.k - paso);
        it.obj.position.copy(it.base).addScaledVector(it.rec, it.k);
        it.obj.updateMatrixWorld(true);
        const delta = this._q.setFromMatrixPosition(it.obj.matrixWorld).sub(antes);
        if (it.pieza) this.mundo.moverPieza(it.pieza);
        // lleva encima al jugador y a los enemigos
        if (subido) { j.cuerpo.pie.add(delta); j.cuerpo.visY += delta.y; }
        if (this.juego.enemigos) for (const E of this.juego.enemigos.lista) {
          if (E.muerto || !E.cuerpo) continue;
          if (this._encima(it, E.cuerpo.pie, E.cuerpo.radio)) { E.cuerpo.pie.add(delta); if (E.cuerpo.visY !== undefined) E.cuerpo.visY += delta.y; }
        }
        if (it.k === it.meta) { it.t = 0; F.emitir('plataforma-llego', { juego: this.juego, ent: it.ent, destino: it.meta === 1 }); }
      }
    }

    /* ---------- ⚠ Trampas ---------- */
    _trampa(x) { return this.trampas.find((it) => it === x || it.ent === x || it.ent.id === x) || null; }

    // pies en local de la pieza (o de la entidad)
    _localT(it, pie, obj) { return (obj || it.obj).worldToLocal(this._v.copy(pie)); }

    dispararTrampa(it) {
      const p = it.p;
      if (p.forma === 'trampilla') this._abrirTrampilla(it);
      else if (p.forma === 'trituradora') { if (it.fase === 'arriba') { it.fase = 'bajando'; it.t = 0; it.golpe = false; } }
      else this._disparar(it);
    }

    _abrirTrampilla(it) {
      if (it.meta === 1) return;
      it.meta = 1; it.tCerrar = it.p.cerrarTras; it.tPisar = 0;
      this._sonidoT(it, 'aterrizar', 0.9);
      F.emitir('trampa', { juego: this.juego, ent: it.ent, que: 'abrir' });
    }

    _sonidoT(it, sint, tono) {
      if (it.p.sonido) F.Audio.efecto(it.p.sonido);
      else F.Audio.sintetico(sint, { volumen: 0.5, tono });
    }

    _trampas(dt) {
      const j = this.juego.jugador, vivo = j && !j.muerto;
      const C = vivo ? j.cuerpo : null;
      for (const it of this.trampas) {
        const p = it.p, f = it.fig;
        if (p.forma === 'trampilla') {
          // ¿la pisa? (pies dentro de la losa y a su altura)
          let pisa = false;
          if (vivo && it.meta === 0 && it.k === 0) {
            const q = this._localT(it, C.pie);
            pisa = Math.abs(q.x) <= p.ancho / 2 && Math.abs(q.z) <= p.largo / 2 && Math.abs(q.y) < 0.25;
          }
          if (pisa && it.activa && p.activar === 'pisar') { it.tPisar += dt; if (it.tPisar >= p.retraso) this._abrirTrampilla(it); }
          else if (it.meta === 0) it.tPisar = 0;
          if (it.meta === 1 && it.k === 1 && p.cerrarTras > 0) { it.tCerrar -= dt; if (it.tCerrar <= 0) { it.meta = 0; this._sonidoT(it, 'aterrizar', 1.4); } }
          if (it.k !== it.meta) {
            const v = dt / (it.meta ? 0.18 : 0.7);
            it.k = it.meta > it.k ? Math.min(1, it.k + v) : Math.max(0, it.k - v);
            f.pieza.rotation.z = -Math.PI / 2 * it.k;
            if (it.pieza) this.mundo.moverPieza(it.pieza);
          }
          // pinchos en el foso
          if (p.danoFoso > 0 && vivo) {
            const q = this._localT(it, C.pie);
            const dentro = Math.abs(q.x) <= p.ancho / 2 && Math.abs(q.z) <= p.largo / 2 && q.y < -0.4 && q.y > -12;
            if (dentro) { it.tFoso -= dt; if (it.tFoso <= 0) { it.tFoso = 1; j.danar && j.danar(p.danoFoso, 'trampa'); } } else it.tFoso = 0;
          }
        } else if (p.forma === 'trituradora') {
          if (!it.activa && it.fase === 'arriba') continue;   // apagada: se queda arriba
          it.t += dt;
          if (it.fase === 'arriba') { if (it.t >= p.esperaArriba) { it.fase = 'bajando'; it.t = 0; it.golpe = false; } }
          else if (it.fase === 'bajando') { it.k = Math.min(1, it.t / Math.max(0.05, p.bajar)); if (it.k >= 1) { it.fase = 'abajo'; it.t = 0; this._sonidoT(it, 'aterrizar', 0.5); } }
          else if (it.fase === 'abajo') { if (it.t >= p.esperaAbajo) { it.fase = 'subiendo'; it.t = 0; } }
          else { it.k = 1 - Math.min(1, it.t / Math.max(0.1, p.subir)); if (it.k <= 0) { it.k = 0; it.fase = 'arriba'; it.t = 0; } }
          const y = -p.recorrido * it.k;
          if (f.pieza.position.y !== y) { f.pieza.position.y = y; if (it.pieza) this.mundo.moverPieza(it.pieza); }
          // aplasta: debajo del bloque y con la cabeza tocándolo mientras baja
          if (!it.golpe && (it.fase === 'bajando' || it.fase === 'abajo')) {
            const aplasta = (pie, radio, altura) => {
              const q = this._localT(it, pie, f.pieza), abajo = -p.alto / 2;
              return Math.abs(q.x) <= p.ancho / 2 + radio * 0.3 && Math.abs(q.z) <= p.largo / 2 + radio * 0.3 && q.y < abajo && q.y + altura > abajo - 0.25;
            };
            if (vivo && aplasta(C.pie, C.radio, C.altura)) { it.golpe = true; j.danar && j.danar(p.dano, 'aplastar'); }
            if (this.juego.enemigos) for (const E of this.juego.enemigos.lista) {
              if (!E.muerto && !E.reserva && E.cuerpo && aplasta(E.cuerpo.pie, E.c.radio, E.c.altura)) this.juego.enemigos.danar(E, p.dano, { tipo: 'normal' });
            }
          }
        } else {
          if (!it.activa || p.disparo === 'mecanismo') continue;
          it.tDisparo -= dt;
          if (it.tDisparo > 0) continue;
          const o = it.obj.getWorldPosition(this._q);
          const cerca = p.disparo === 'siempre' || (vivo && C.pie.distanceTo(o) < p.distancia);
          if (cerca) { this._disparar(it); it.tDisparo = p.cadencia; } else it.tDisparo = 0.2;
        }
      }
      if (this.clavos.length) this._clavos(dt, vivo ? j : null);
    }

    // ➶ un clavo (se reutilizan)
    _disparar(it) {
      const o = it.obj;
      o.updateMatrixWorld(true);
      let c = this.clavos.find((x) => !x.vivo);
      if (!c) {
        if (!Mecanismos._geoClavo) Mecanismos._geoClavo = new T.BoxGeometry(0.025, 0.025, 0.3);
        const malla = new T.Mesh(Mecanismos._geoClavo, F.Render.matRetro('#c8ccd4'));
        this.juego.vista.escena.add(malla);
        c = { malla, pos: new T.Vector3(), dir: new T.Vector3() };
        this.clavos.push(c);
      }
      const n = this.clavos.filter((x) => x.vivo).length;
      if (n > 40) return;   // nunca más de 40 en el aire
      c.vivo = true; c.rec = 0; c.p = it.p;
      c.pos.set((Math.random() - 0.5) * 0.24, (Math.random() - 0.5) * 0.16, -0.15).applyMatrix4(o.matrixWorld);
      c.dir.set(0, 0, -1).transformDirection(o.matrixWorld);
      c.malla.position.copy(c.pos);
      c.malla.lookAt(this._q.copy(c.pos).add(c.dir));
      c.malla.visible = true;
      this._sonidoT(it, 'disparo', 2.2);
    }

    _clavos(dt, j) {
      const M = this.mundo;
      for (const c of this.clavos) {
        if (!c.vivo) continue;
        const paso = c.p.velocidad * dt;
        const pared = M && M.rayo(c.pos.x, c.pos.y, c.pos.z, c.dir.x, c.dir.y, c.dir.z, paso);
        const largo = pared ? pared.t : paso;
        // ¿da al jugador? (el tramo de este cuadro contra su cápsula)
        if (j) {
          const C = j.cuerpo, P = C.pie;
          for (let s = 0; s <= 1; s += 0.25) {
            const x = c.pos.x + c.dir.x * largo * s, y = c.pos.y + c.dir.y * largo * s, z = c.pos.z + c.dir.z * largo * s;
            if ((x - P.x) ** 2 + (z - P.z) ** 2 < (C.radio + 0.1) ** 2 && y > P.y && y < P.y + C.altura) {
              j.danar && j.danar(c.p.danoClavo, 'trampa');
              c.vivo = false;
              break;
            }
          }
        }
        if (!c.vivo || pared || (c.rec += paso) > c.p.alcance) { c.vivo = false; c.malla.visible = false; continue; }
        c.pos.addScaledVector(c.dir, paso);
        c.malla.position.copy(c.pos);
      }
    }

    /* ---------- 🏺 Pedestales ---------- */
    _ped(x) { return this.pedestales.find((it) => it === x || it.ent === x || it.ent.id === x) || null; }
    _defObjeto(id) { return (this.juego.proyecto.objetos || []).find((o) => o.id === id) || null; }
    _casilla(id) {
      const inv = this.juego.jugador && this.juego.jugador.inventario;
      return inv ? inv.items.findIndex((x) => x && x.k === 'obj' && x.id === id) : -1;
    }

    _textoPedestal(ent) {
      const it = this._ped(ent);
      if (!it) return null;
      const def = this._defObjeto(it.p.objeto);
      if (it.puesto) return it.p.gastar && it.p.sePuedeQuitar ? 'Coger ' + (def ? def.nombre : 'el objeto') : null;
      if (this._casilla(it.p.objeto) >= 0) return 'Colocar ' + (def ? def.nombre : 'el objeto');
      return 'Examinar ' + (ent.nombre || 'pedestal');
    }

    usarPedestal(x) {
      const it = this._ped(x);
      if (!it) return;
      const def = this._defObjeto(it.p.objeto);
      const inv = this.juego.jugador && this.juego.jugador.inventario;
      if (it.puesto) {
        if (!(it.p.gastar && it.p.sePuedeQuitar)) return;
        if (inv && inv.agregar('obj', it.p.objeto, 1) > 0) { this._mensaje('No tienes sitio'); return; }
        this.ponerPedestal(it, false);
        if (def) this._mensaje('Cogiste: ' + def.nombre);
        return;
      }
      const i = this._casilla(it.p.objeto);
      if (i < 0) { this._mensaje(it.p.avisoVacio || (def ? 'Aquí encaja: ' + def.nombre : 'Aquí falta algo')); return; }
      if (it.p.gastar) inv.quitar(i, 1);
      this.ponerPedestal(it, true);
      if (def) this._mensaje('Colocaste: ' + def.nombre);
    }

    ponerPedestal(x, puesto) {
      const it = this._ped(x);
      if (!it || it.puesto === puesto) return;
      it.puesto = puesto;
      it.fig.poner(puesto);
      F.Audio.sintetico(puesto ? 'golpe' : 'recoger', { volumen: 0.6, tono: 0.7 });
      F.emitir('pedestal', { juego: this.juego, ent: it.ent, puesto });
      this.ejecutar(it.p.acciones, puesto);
      this._tCond = 0;   // las condiciones se miran ya
    }

    /* ---------- ⚙ Condiciones (puzles) ---------- */
    _cumple(r) {
      const J = this.juego;
      switch (r.tipo) {
        case 'palanca': { const it = this._pal(r.a); return !!it && it.on === (r.estado !== 'off'); }
        case 'pedestal': { const it = this._ped(r.a); return !!it && it.puesto === (r.estado !== 'off'); }
        case 'puerta': { const it = this._it(r.a); return !!it && (it.meta > 0.5 && it.k > 0.99) === (r.estado !== 'off'); }
        case 'disparador': { const it = this.disparadores.find((d) => d.ent.id === r.a); return !!it && it.usado; }
        case 'enemigo': {
          if (!J.enemigos) return false;
          const E = J.enemigos.lista.find((x) => x.ent && x.ent.id === r.a && !x.generado);
          return E ? E.muerto : J.enemigos.muertos && J.enemigos.muertos.has(r.a);
        }
        case 'arena': { const A = J.enemigos && J.enemigos.aparecedores.find((x) => x.ent.id === r.a); return !!A && A.fase === 'fin' && !A.vivos.length; }
        case 'todos': return !!J.enemigos && !J.enemigos.lista.some((E) => !E.muerto && !E.reserva && (E.c.actitud || 'agresivo') === 'agresivo');
      }
      return false;
    }

    _condiciones() {
      for (const it of this.condiciones) {
        if ((it.p.unaVez && it.hecha) || !it.activa) continue;
        const rs = (it.p.requisitos || []).filter((r) => REQUISITO[r.tipo]);
        if (!rs.length) continue;
        const ok = it.p.modo === 'alguna' ? rs.some((r) => this._cumple(r)) : rs.every((r) => this._cumple(r));
        if (ok === it.cumplida) continue;
        it.cumplida = ok;
        F.emitir('condicion', { juego: this.juego, ent: it.ent, cumplida: ok });
        if (ok) { it.hecha = true; this.ejecutar(it.p.acciones, true); }
        else if (!it.p.unaVez) this.ejecutar(it.p.acciones, false);
      }
    }

    /* ---------- ⬚ Disparadores ---------- */
    activarDisparador(x, on = true) {
      const it = this.disparadores.find((d) => d === x || d.ent === x || d.ent.id === x);
      if (!it) return;
      it.activo = on;
      if (on) it.dentro = false;   // si ya estabas dentro, salta al volver a entrar... o ahora mismo (ver _disparadores)
    }

    // ¿este punto (pies) está dentro de la caja del disparador?
    _dentroDe(it, x, y, z) {
      const q = this._v.set(x, y + 0.3, z).applyMatrix4(it.inv);
      return Math.abs(q.x) <= 0.5 && Math.abs(q.z) <= 0.5 && q.y >= -0.25 && q.y <= 1;
    }

    _disparadores(dt) {
      if (!this.disparadores.length) return;
      const j = this.juego.jugador;
      // los enemigos se miran 10 veces por segundo (son muchos); el jugador cada cuadro
      this._tEnem -= dt;
      const verEnem = this._tEnem <= 0;
      if (verEnem) this._tEnem = 0.1;
      for (const it of this.disparadores) {
        if (it.tEspera > 0) it.tEspera -= dt;
        if (!it.activo || (it.p.cuando === 'una' && it.usado)) { if (!it.activo) it.dentro = false; continue; }
        let dentro = it.dentro;
        if (it.p.quien !== 'enemigos' || verEnem) {
          dentro = false;
          if ((it.p.quien === 'jugador' || it.p.quien === 'todos' || it.p.quien === 'jugadorObjetos') && j && !j.muerto) { const P = j.cuerpo.pie; dentro = this._dentroDe(it, P.x, P.y, P.z); }
          if (!dentro && (it.p.quien === 'enemigos' || it.p.quien === 'todos') && this.juego.enemigos) {
            for (const E of this.juego.enemigos.lista) {
              if (E.muerto || E.soloMolde || !E.cuerpo) continue;
              const P = E.cuerpo.pie;
              if (this._dentroDe(it, P.x, P.y, P.z)) { dentro = true; break; }
            }
          }
          if (it.p.quien === 'todos' && !verEnem && !dentro && it.dentro) dentro = true;   // los enemigos se revisan luego
          // 🧱 objetos movibles (cajas, estatuas): su base dentro de la zona
          if (!dentro && (it.p.quien === 'objetos' || it.p.quien === 'jugadorObjetos') && this.juego.empujables) {
            const EM = this.juego.empujables;
            for (const o of EM.lista) {
              if (EM.cargado === o || o.k < 1 || (it.p.etiqueta && o.p.etiqueta !== it.p.etiqueta)) continue;
              const P = o.obj.position;
              if (this._dentroDe(it, P.x, P.y, P.z)) { dentro = true; break; }
            }
          }
        }
        if (dentro && !it.dentro) {
          if (it.p.cuando !== 'cada' || it.tEspera <= 0) {
            it.usado = true;
            it.tEspera = it.p.espera;
            F.emitir('disparador', { juego: this.juego, ent: it.ent, dentro: true });
            this.ejecutar(it.p.acciones, true);
          }
        } else if (!dentro && it.dentro && it.p.cuando === 'entrarSalir') {
          F.emitir('disparador', { juego: this.juego, ent: it.ent, dentro: false });
          this.ejecutar(it.p.acciones, false);
        }
        it.dentro = dentro;
        const pl = it.obj.userData.placa;
        if (pl) { const meta = dentro ? 0.01 : 0.04; pl.position.y += (meta - pl.position.y) * Math.min(1, dt * 12); }
      }
    }

    /* ---------- Acciones ("Qué hace") ----------
       on = false: lo contrario (solo lo que tiene "inv"). Con retraso: espera en this.pendientes */
    ejecutar(acciones, on = true) {
      for (const a of acciones || []) {
        if (!a || !ACCION[a.que]) continue;
        if (a.retraso > 0) this.pendientes.push({ t: a.retraso, a, on });
        else this._hacer(a, on);
      }
    }

    _hacer(a, on) {
      const J = this.juego;
      let que = a.que;
      if (!on) { que = ACCION[que].inv; if (!que) return; }
      switch (que) {
        case 'abrir': this.abrir(a.a, true); break;
        case 'cerrar': this.cerrar(a.a); break;
        case 'alternar': this.alternar(a.a); break;
        case 'bloquear': this.bloquear(a.a); break;
        case 'desbloquear': this.desbloquear(a.a); break;
        case 'despertar': if (J.enemigos && J.enemigos.despertar) J.enemigos.despertar(a.a); break;
        case 'condOn': case 'condOff': { const it = this.condiciones.find((c) => c.ent.id === a.a); if (it) it.activa = que === 'condOn'; break; }
        case 'luzOn': case 'luzOff': case 'luzAlt': {
          const L = J.vista && J.vista.luces;
          if (L && L.encender) L.encender(a.a, que === 'luzOn' ? true : que === 'luzOff' ? false : null);
          this._tocadas = this._tocadas || new Set();
          this._tocadas.add(a.a);
          break;
        }
        case 'marcaOn': if (J.brujula) J.brujula.marcar(a.a, true); break;
        case 'marcaOff': if (J.brujula) J.brujula.marcar(a.a, false); break;
        case 'apaOn': if (J.enemigos && J.enemigos.activarAparecedor) J.enemigos.activarAparecedor(a.a, true); break;
        case 'apaOff': if (J.enemigos && J.enemigos.activarAparecedor) J.enemigos.activarAparecedor(a.a, false); break;
        case 'platIr': case 'platVolver': case 'platAlt': {
          const it = this.plataformas.find((x) => x.ent.id === a.a);
          if (it) this.moverPlataforma(it, que === 'platIr' ? 1 : que === 'platVolver' ? 0 : it.meta > 0.5 ? 0 : 1);
          break;
        }
        case 'platOn': case 'platOff': { const it = this.plataformas.find((x) => x.ent.id === a.a); if (it) it.encendida = que === 'platOn'; break; }
        case 'matar': { const j = J.jugador; if (j && j.danar && !j.muerto) j.danar(a.cantidad > 0 ? a.cantidad : 9999, 'ambiente'); break; }
        case 'trampaOn': case 'trampaOff': { const it = this._trampa(a.a); if (it) it.activa = que === 'trampaOn'; break; }
        case 'mision': {
          // ⭐ pantalla de puntuación; luego: a otro nivel (si se eligió) o fin de la partida (menú principal)
          if (this._misionHecha) break;
          this._misionHecha = true;
          const fin = () => {
            if (a.destino && J.salidas) J.salidas.activar({ id: 'accion-nivel', tipo: 'salida', nombre: 'Viaje', salida: { ...F.Niveles.SALIDA, destino: a.destino, llegada: a.llegada || '', transicion: a.transicion || 'negro' } });
            else F.emitir('partida-fin', J);
          };
          if (J.misiones && J.misiones.activa) J.misiones.final(null).then(fin); else fin();
          break;
        }
        case 'sonOn': case 'sonOff': { if (J.sonidos) J.sonidos.encender(a.a, que === 'sonOn'); break; }
        case 'victoria': if (!this._misionHecha) { this._misionHecha = true; F.emitir('partida-fin', J); } break;
        case 'bombaOn': { if (J.tactico) J.tactico.activarBomba(a.a); break; }
        case 'camara': { if (J.camarasFijas) J.camarasFijas.activar(a.a); break; }
        case 'trampaDisparar': { const it = this._trampa(a.a); if (it) this.dispararTrampa(it); break; }
        case 'disOn': this.activarDisparador(a.a, true); break;
        case 'disOff': this.activarDisparador(a.a, false); break;
        case 'palOn': this.ponerPalanca(a.a, true); break;
        case 'palOff': this.ponerPalanca(a.a, false); break;
        case 'mensaje': if (a.texto) this._mensaje(a.texto); break;
        case 'cine': if (J.cine && a.cine) J.cine.reproducir(a.cine); break;
        case 'explosion': {
          const p = F.Explosiones && F.Explosiones.puntoDe(J, a.donde || this._entidadDe(a));
          if (p) F.Explosiones.lanzar(J, p, { tam: a.tam || 'media', dano: a.dano || 0, humo: a.humo !== false, sonido: a.asset || '' });
          break;
        }
        case 'barOn': case 'barOff': case 'barAlt': if (F.Campo) F.Campo.encenderBarrera(J, a.a, que === 'barOn' ? true : que === 'barOff' ? false : 'alternar'); break;
        case 'partOn': case 'partOff': case 'partAlt': if (F.Particulas && F.Particulas.encender) F.Particulas.encender(J, a.a, que === 'partOn' ? true : que === 'partOff' ? false : 'alternar'); break;
        case 'efectos': if (F.Efectos) F.Efectos.aplicarAccion(J.vista, a.estilo || 'nivel', a.barras || 0); break;
        case 'efectosNivel': if (J.vista && J.vista.forzarEfectos) J.vista.forzarEfectos(null); break;
        case 'lluviaOn': case 'lluviaOff': case 'rayo': case 'hora': if (J.clima) J.clima.accion(que, a); break;
        case 'sonido': if (a.asset) F.Audio.efecto(a.asset); break;
        case 'musica': F.Audio.musica(a.asset || '', { volumen: a.volumen ?? 1, inicio: a.inicio || 0, fin: a.fin || 0, fundido: a.fundido ?? 1 }); break;   // '' = silencio
        case 'musicaNivel': F.Audio.musicaNivel(J.escena.nivel, a.fundido ?? 1); break;
        case 'nivel':
          if (a.destino && J.salidas) J.salidas.activar({ id: 'accion-nivel', tipo: 'salida', nombre: 'Viaje', salida: { ...F.Niveles.SALIDA, destino: a.destino, llegada: a.llegada || '', transicion: a.transicion || 'negro' } });
          break;
        case 'canal': this.emitir(a.canal, on); break;
      }
    }

    // la entidad que hace la acción (para "explosión aquí mismo" sin elegir dónde)
    _entidadDe(a) { return a._de || ''; }

    // 📡 canal: lo escuchan puertas (abren / cierran) y palancas (se encienden / apagan)
    emitir(canal, on = true) {
      const c = String(canal || '').trim().toLowerCase();
      if (!c) return;
      this._prof = (this._prof || 0) + 1;
      if (this._prof > 20) { this._prof--; return; }   // un canal que se avisa a sí mismo en bucle
      for (const it of this.puertas) if ((it.p.canal || '').trim().toLowerCase() === c) (on ? this.abrir(it, true) : this.cerrar(it));
      for (const it of this.palancas) if ((it.p.canal || '').trim().toLowerCase() === c) this.ponerPalanca(it, on);
      for (const it of this.disparadores) if ((it.p.canal || '').trim().toLowerCase() === c) this.activarDisparador(it, on);
      for (const it of this.trampas) if ((it.p.canal || '').trim().toLowerCase() === c) it.activa = on;
      F.emitir('canal', { juego: this.juego, canal: c, on });
      this._prof--;
    }

    // ⬛ corte a negro: fundido, apareces al otro lado mirando hacia delante, fundido de vuelta
    async _cruzar(it) {
      const j = this.juego.jugador;
      this.cruzando = true;
      j.sinControl = true;
      const capa = this._capa();
      const t = Math.max(0, it.p.fundido);
      this._sonido(it, true);
      capa.style.transitionDuration = t + 's';
      void capa.offsetWidth;
      capa.style.opacity = 1;
      await new Promise((ok) => setTimeout(ok, t * 1000 + 60));
      if (!this.juego.enMarcha) { this.cruzando = false; return; }
      const q = this._local(it, j.cuerpo.pie);
      const lado = q.z < 0 ? 1 : -1;                       // al lado contrario
      const dist = it.fig.D / 2 + j.cuerpo.radio + 0.45;
      const local = new T.Vector3(0, 0.05, lado * dist);
      local.x /= it.obj.scale.x; local.y /= it.obj.scale.y; local.z /= it.obj.scale.z;
      const w = local.applyMatrix4(it.obj.matrixWorld);
      // hacia dónde mira: alejándose de la puerta
      const o = it.obj.getWorldPosition(new T.Vector3());
      const dx = w.x - o.x, dz = w.z - o.z;
      j.teletransportar(w.x, w.y, w.z, Math.atan2(-dx, -dz), 0);
      F.emitir('puerta-cruzada', { juego: this.juego, ent: it.ent });
      await new Promise((ok) => setTimeout(ok, 120));
      capa.style.opacity = 0;
      await new Promise((ok) => setTimeout(ok, t * 1000));
      j.sinControl = false;
      this.cruzando = false;
    }

    _capa() {
      const cont = this.juego.vista.contenedor;
      if (this.capa && this.capa.parentNode === cont) return this.capa;
      const c = document.createElement('div');
      c.style.cssText = 'position:absolute;inset:0;background:#000;opacity:0;pointer-events:none;z-index:27;transition-property:opacity;transition-timing-function:linear';
      cont.appendChild(c);
      this.capa = c;
      return c;
    }

    actualizar(dt) {
      const j = this.juego.jugador;
      // acciones con retraso
      if (this.pendientes.length) {
        for (const x of this.pendientes) x.t -= dt;
        const listas = this.pendientes.filter((x) => x.t <= 0);
        if (listas.length) { this.pendientes = this.pendientes.filter((x) => x.t > 0); for (const x of listas) this._hacer(x.a, x.on); }
      }
      this._disparadores(dt);
      for (const c of this.cofres) if (c.abierto && c.k < 1 && c.tapa) { c.k = Math.min(1, c.k + dt * 3); c.tapa.rotation.x = -1.7 * c.k * (2 - c.k); }
      if (this.plataformas.length) this._plataformas(dt);
      if (this.trampas.length || this.clavos.length) this._trampas(dt);
      // condiciones: 4 veces por segundo (y al momento tras usar algo)
      this._tCond -= dt;
      if (this._tCond <= 0 && this.condiciones.length) { this._tCond = 0.25; this._condiciones(); }
      // palancas: se mueven hacia su posición y las de temporizador vuelven solas
      for (const it of this.palancas) {
        const meta = it.on ? 1 : 0;
        if (it.k !== meta) { it.k = meta > it.k ? Math.min(1, it.k + dt * 6) : Math.max(0, it.k - dt * 6); it.fig.poner(it.k); }
        if (it.p.modo === 'volver' && it.on) { it.tVolver -= dt; if (it.tVolver <= 0) this.ponerPalanca(it, false); }
      }
      for (const it of this.puertas) {
        const p = it.p;
        // 🚶 se abre sola al acercarte (si tienes la llave)
        if (p.abrir === 'cerca' && j && !j.muerto) {
          const q = this._local(it, j.cuerpo.pie);
          const cerca = Math.hypot(q.x, q.z) < p.distancia + it.fig.W / 2 && q.y > -1.5 && q.y < it.fig.H + 1;
          if (cerca && !it.cerca && it.meta < 0.5) { if (this._llave(it)) { if (p.estilo === 'negro') this._cruzar(it); else this.abrir(it); } }
          it.cerca = cerca;
          if (cerca) it.tCerrar = p.cerrarTras;
        }
        // se cierra sola
        if (it.meta === 1 && p.cerrarTras > 0 && !(p.abrir === 'cerca' && it.cerca)) {
          it.tCerrar -= dt;
          if (it.tCerrar <= 0 && !this._estorba(it)) this.cerrar(it);
        }
        if (it.mixer) it.mixer.update(dt);
        if (it.k === it.meta) continue;
        // cerrando con el jugador en medio: espera (no lo aplasta ni lo empuja fuera del mapa)
        if (it.meta < it.k && this._estorba(it)) continue;
        const vel = dt / Math.max(0.05, it.animAbrir ? it.animAbrir.getClip().duration : p.tiempo);
        it.k = it.meta > it.k ? Math.min(it.meta, it.k + vel) : Math.max(it.meta, it.k - vel);
        this._poner(it);
        if (it.pieza) {
          it.pieza.activa = this._choca(it);
          if (it.pieza.activa) this.mundo.moverPieza(it.pieza);
        }
      }
    }

    // ¿el jugador está en el hueco de la puerta?
    _estorba(it) {
      const j = this.juego.jugador;
      if (!j) return false;
      const q = this._local(it, j.cuerpo.pie), r = j.cuerpo.radio + 0.1;
      const ancho = it.p.estilo === 'bisagra' ? it.fig.hueco + r : it.fig.W / 2 + r;
      return Math.abs(q.x) < ancho && Math.abs(q.z) < (it.p.estilo === 'bisagra' ? it.fig.hueco : it.fig.D / 2) + r && q.y > -0.5 && q.y < it.fig.H;
    }

    // para guardar: qué puertas están abiertas o ya no piden llave (las que se cierran solas no cuentan)
    estado() {
      const puertas = {};
      for (const it of this.puertas) {
        const abierta = it.meta > 0.5 && !(it.p.cerrarTras > 0);
        const inicial = it.p.empiezaAbierta && it.p.estilo !== 'negro';
        if (abierta !== inicial || (it.p.llave && it.desbloqueada) || it.bloqueada) puertas[it.ent.id] = { abierta, desbloqueada: it.desbloqueada, signo: it.signo, bloqueada: it.bloqueada, antesAbierta: it.antesAbierta };
      }
      const palancas = {};
      for (const it of this.palancas) if (it.on !== !!it.p.empiezaEncendida || it.usada) palancas[it.ent.id] = { on: it.p.modo === 'volver' ? false : it.on, usada: it.usada };
      const disparadores = {};
      for (const it of this.disparadores) if (it.usado || it.activo !== (it.p.activo !== false)) disparadores[it.ent.id] = { usado: it.usado, activo: it.activo };
      const pedestales = {};
      for (const it of this.pedestales) if (it.puesto !== !!it.p.empiezaPuesto) pedestales[it.ent.id] = { puesto: it.puesto };
      const condiciones = {};
      for (const it of this.condiciones) if (it.hecha || it.cumplida || it.activa !== (it.p.activa !== false)) condiciones[it.ent.id] = { cumplida: it.cumplida, hecha: it.hecha, activa: it.activa };
      const plataformas = {};
      for (const it of this.plataformas) plataformas[it.ent.id] = { k: it.p.modo === 'pisar' && it.p.volver ? 0 : it.meta, encendida: it.encendida };
      const cofres = {};
      for (const it of this.cofres) if (it.abierto) cofres[it.ent.id] = true;
      const trampas = {};
      for (const it of this.trampas) if (it.activa !== (it.p.activa !== false)) trampas[it.ent.id] = { activa: it.activa };
      return { puertas, palancas, disparadores, pedestales, condiciones, plataformas, cofres, trampas };
    }

    detener() {
      for (const it of this.puertas) {
        it.k = it.meta = 0;
        it.bloqueada = false;
        if (it.mixer) { it.mixer.stopAllAction(); it.fig.modelo.traverse((o) => { if (o.isSkinnedMesh) o.skeleton.pose(); }); }
        it.animAbrir = null;
        this._poner(it);
        for (const mt of it.fig.mats) mt.opacity = mt.userData.op ?? mt.opacity;
        it.fig.cuerpo.visible = true;
      }
      for (const it of this.palancas) it.fig.poner(it.p.empiezaEncendida ? 1 : 0);
      for (const it of this.pedestales) it.fig.poner(true);
      for (const it of this.plataformas) it.obj.position.copy(it.base);
      for (const it of this.trampas) { if (it.fig.pieza) { it.fig.pieza.rotation.z = 0; it.fig.pieza.position.y = 0; if (it.p.forma === 'trampilla') it.fig.pieza.position.x = -it.p.ancho / 2; } }
      for (const c of this.clavos) if (c.malla.parent) c.malla.parent.remove(c.malla);
      this.clavos = [];
      for (const c of this.cofres) if (c.tapa) c.tapa.rotation.x = 0;   // vuelve a su sitio en el editor   // en el editor se ve el objeto (para colocarlo bien)
      // las luces que se tocaron vuelven a como están en el editor
      const L = this.juego.vista && this.juego.vista.luces;
      if (L && L.fuentes) for (const f of L.fuentes) f.apagada = false;   // también las que empezaban apagadas
      if (this.capa) this.capa.remove();
    }
  }

  F.Mecanismos = Mecanismos;
  Mecanismos.PUERTA = PUERTA;
  Mecanismos.ESQUEMA_PUERTA = ESQUEMA_PUERTA;
  Mecanismos.figuraPuerta = figura;
  Mecanismos.PALANCA = PALANCA;
  Mecanismos.ESQUEMA_PALANCA = ESQUEMA_PALANCA;
  Mecanismos.ACCIONES = ACCIONES;
  Mecanismos.ACCION = ACCION;
  Mecanismos.accionNueva = accionNueva;
  Mecanismos.figuraPalanca = figuraPalanca;
  Mecanismos.DISPARADOR = DISPARADOR;
  Mecanismos.PLATAFORMA = PLATAFORMA;
  Mecanismos.TRAMPA = TRAMPA;
  Mecanismos.ESQUEMA_TRAMPA = ESQUEMA_TRAMPA;
  Mecanismos.figuraTrampa = figuraTrampa;
  Mecanismos.ESQUEMA_PLATAFORMA = ESQUEMA_PLATAFORMA;
  Mecanismos.figuraPlataforma = figuraPlataforma;
  Mecanismos.PEDESTAL = PEDESTAL;
  Mecanismos.ESQUEMA_PEDESTAL = ESQUEMA_PEDESTAL;
  Mecanismos.figuraPedestal = figuraPedestal;
  Mecanismos.CONDICION = CONDICION;
  Mecanismos.REQUISITOS = REQUISITOS;
  Mecanismos.REQUISITO = REQUISITO;
  Mecanismos.requisitoNuevo = requisitoNuevo;
  Mecanismos.figuraCondicion = figuraCondicion;
  Mecanismos.ESQUEMA_DISPARADOR = ESQUEMA_DISPARADOR;
  Mecanismos.figuraDisparador = figuraDisparador;
})(window.FORJA);
