/* =========================================================
   FORJA · ALIADOS (equipo estilo SWAT 4, máx. 3)
   Un aliado es una criatura (motor/enemigos.js) con actitud 'aliado': ve, oye, dispara y muere igual que un
   enemigo, pero ataca a los enemigos y nunca al jugador. Este gestor le da las ÓRDENES de todo el equipo:
     1 Seguirme  · en fila sobre tu rastro (sin búsqueda de caminos: pisan por donde pasaste)
     2 Esperar   · se quedan donde están y vigilan
     3 Ir ahí    · al punto que señalas con la mira
     4 Abrir y limpiar · la 🚧 puerta táctica que miras: uno la abre (patada si está cerrada) y entran a despejar
   Menú rápido: mantén G (o el botón 👥 táctil) y elige con 1-4 o tocando. Barato: las metas se recalculan 5 veces/s.
   ========================================================= */
(function (F) {
  'use strict';
  const T = THREE;
  const MAX = 3;
  const ORDENES = [
    ['seguir', '1', 'Seguirme'],
    ['esperar', '2', 'Esperar aquí'],
    ['ir', '3', 'Ir ahí'],
    ['limpiar', '4', 'Abrir y limpiar'],
  ];
  const NOMBRE = { seguir: 'Siguiendo', esperar: 'Esperando', ir: 'Yendo', limpiar: 'Limpiando', combate: 'Combate' };

  const CSS = `
  .fal-menu { position: absolute; left: 50%; top: 50%; transform: translate(-50%, -50%); z-index: 27; display: none; gap: .5em;
    flex-direction: column; font-family: var(--fh-fuente); font-weight: bold; color: var(--fh-texto, #e8e2d0); }
  .fal-menu.fal-ver { display: flex; }
  .fal-menu h4 { margin: 0 0 .2em; text-align: center; letter-spacing: .15em; font-size: .85em; color: var(--fh-sel, #e8a33d); text-shadow: .1em .1em 0 #000; }
  .fal-menu button { font: inherit; color: inherit; background: rgba(0,0,0,.78); border: .12em solid rgba(255,255,255,.25); padding: .55em 1.2em;
    min-width: 13em; text-align: left; cursor: pointer; pointer-events: auto; }
  .fal-menu button:hover, .fal-menu button.fal-sel { border-color: var(--fh-sel, #e8a33d); color: var(--fh-sel, #e8a33d); }
  .fal-menu button[disabled] { opacity: .4; }
  .fal-aviso { position: absolute; left: 50%; top: 70%; transform: translateX(-50%); font-weight: bold; color: var(--fh-sel, #e8a33d);
    text-shadow: .1em .1em 0 #000; pointer-events: none; transition: opacity .4s; z-index: 6; white-space: nowrap; }
  .fal-equipo { position: absolute; align-items: flex-start; z-index: 6; font-size: .72em; pointer-events: none; display: flex; flex-direction: column; gap: .25em; text-shadow: .12em .12em 0 #000; }
  .fal-equipo div { background: rgba(0,0,0,.4); padding: .15em .5em; min-width: 11em; }
  .fhud.fh-fondo .fal-equipo div { background: var(--fh-fondo); }
  .fh-sin-sombra .fal-equipo { text-shadow: none; }
  .fal-equipo i { display: block; height: .3em; background: var(--fh-sel, #e8a33d); margin-top: .15em; }
  .fal-equipo .fal-muerto { opacity: .45; text-decoration: line-through; }
  /* posición automática: el hueco libre de cada distribución del HUD */
  .fh-al-auto.fh-pos-esquinas .fal-equipo { left: var(--fh-b); bottom: calc(var(--fh-b) + 5.5em); }
  .fh-al-auto.fh-pos-barra .fal-equipo { left: var(--fh-b); bottom: calc(var(--fh-alto) + var(--fh-b)); }
  /* arriba a la izq. va la lista de objetivos de la misión: allí no */
  .fh-al-auto.fh-pos-arriba .fal-equipo { left: var(--fh-b); bottom: calc(var(--fh-b) + 4em); }
  .fh-al-auto.fh-pos-arcade .fal-equipo,
  .fh-al-auto.fh-pos-centro .fal-equipo, .fh-al-auto.fh-pos-discreto .fal-equipo, .fh-al-abajo-izq .fal-equipo { left: var(--fh-b); bottom: var(--fh-b); }
  .fh-al-arriba-izq .fal-equipo { left: var(--fh-b); top: var(--fh-b); }
  .fh-al-arriba-der .fal-equipo { right: var(--fh-b); top: var(--fh-b); align-items: flex-end; }
  .fh-al-abajo-der .fal-equipo { right: var(--fh-b); bottom: var(--fh-b); align-items: flex-end; }
  `;
  let css = false;

  class Gestor {
    constructor(juego) {
      this.juego = juego;
      const EN = juego.enemigos;
      this.lista = EN && EN.aliados ? EN.aliados.slice(0, MAX) : [];
      this.hay = this.lista.length > 0;
      if (!this.hay) return;
      this.rastro = [];
      this.t = 0;
      this.menu = false;
      this.orden = { tipo: 'seguir' };
      this.lista.forEach((E, i) => {
        E.orden = { tipo: E.c.seguirAlEmpezar === false ? 'esperar' : 'seguir' };
        E.metaOrden = E.cuerpo.pie.clone();
        E.idxEquipo = i;
      });
      // los que pasen de 3 no reciben órdenes (se quedan quietos donde están)
      for (const E of EN.aliados.slice(MAX)) { E.orden = { tipo: 'esperar' }; E.metaOrden = E.cuerpo.pie.clone(); }
      estilo();
      this.menuEl = F.Hud.pieza(juego, 'fal-menu');
      this.equipoEl = F.Hud.pieza(juego, 'fal-equipo');
      this._pintarMenu();
      if (F.Tactil) F.Tactil.ponerContexto('ordenes', true);
    }

    /* ---------- Menú rápido ---------- */
    _pintarMenu() {
      const el = this.menuEl;
      el.innerHTML = '<h4>ÓRDENES AL EQUIPO</h4>' + ORDENES.map(([k, n, t]) => `<button data-o="${k}">${n} · ${t}</button>`).join('');
      el.querySelectorAll('button').forEach((b) => {
        b.onpointerdown = (e) => { e.stopPropagation(); e.preventDefault(); this.dar(b.dataset.o); this.cerrarMenu(); };
      });
    }
    abrirMenu(porTecla) {
      this.menu = true; this.porTecla = porTecla;
      const puerta = this._puertaMirada();
      const bl = this.menuEl.querySelector('[data-o="limpiar"]');
      if (bl) bl.disabled = !puerta;
      this.menuEl.classList.add('fal-ver');
    }
    cerrarMenu() { this.menu = false; this.menuEl.classList.remove('fal-ver'); }

    /* ---------- Dar una orden a todo el equipo ---------- */
    dar(tipo) {
      const J = this.juego, j = J.jugador;
      const o = { tipo };
      if (tipo === 'ir') {
        const p = this._puntoMira();
        if (!p) { this._decir('No hay dónde ir'); return; }
        o.punto = p;
      } else if (tipo === 'limpiar') {
        const d = this._puertaMirada();
        if (!d) { this._decir('Mira una puerta táctica'); return; }
        if (d.cerrada && !d.p.patada) { this._decir('Está cerrada'); return; }
        o.puerta = d; o.fase = 'ir'; o.t = 0;
        // lado del equipo (el del jugador) y dentro de la sala (el otro)
        d.obj.updateMatrixWorld(true);
        const pos = new T.Vector3().setFromMatrixPosition(d.obj.matrixWorld);
        const n = new T.Vector3(0, 0, 1).applyQuaternion(d.obj.getWorldQuaternion(new T.Quaternion())).setY(0).normalize();
        const lado = Math.sign(n.dot(new T.Vector3().subVectors(j.cuerpo.pie, pos))) || 1;
        const lat = new T.Vector3(n.z, 0, -n.x);
        // en fila frente a la puerta (uno detrás de otro) y, dentro, cada uno a su esquina
        o.pos = pos; o.n = n; o.lado = lado;
        o.fila = [0, 1, 2].map((i) => pos.clone().addScaledVector(n, lado * (1.2 + i * 1.1)));
        o.fuera = o.fila[0];
        o.dentro = [-1.4, 1.4, 0].map((k, i) => pos.clone().addScaledVector(n, -lado * (2.4 + (i === 2 ? 1.4 : 0))).addScaledVector(lat, k));
        o.mirar = pos.clone().addScaledVector(n, -lado * 8);
      } else if (tipo === 'esperar') {
        o.mirar = new T.Vector3(j.cuerpo.pie.x - Math.sin(j.yaw) * 10, j.cuerpo.pie.y, j.cuerpo.pie.z - Math.cos(j.yaw) * 10);
      }
      this.orden = o;
      for (const E of this.lista) {
        if (E.muerto) continue;
        E.orden = o;
        E.mirarOrden = o.mirar || null;
        if (tipo === 'esperar') E.metaOrden.copy(E.cuerpo.pie);
        // dejar de pelear para obedecer (salvo si están atacando en este momento)
        if (E.estado === 'perseguir' && tipo !== 'esperar') { E.blanco = E.amenaza = E.presa = null; E.estado = 'orden'; }
      }
      F.Audio.sintetico('recoger', { volumen: 0.4, tono: 1.6 });
      this._decir(ORDENES.find((x) => x[0] === tipo)[2]);
      F.emitir('orden-equipo', { juego: J, tipo });
    }

    // punto del suelo que señala la mira (rayo de la cámara)
    _puntoMira() {
      const J = this.juego, cam = J.camara, M = J.mundo;
      const o = new T.Vector3(), d = new T.Vector3();
      cam.getWorldPosition(o); cam.getWorldDirection(d);
      const g = M.rayo(o.x, o.y, o.z, d.x, d.y, d.z, 40);
      if (!g) return null;
      const p = o.addScaledVector(d, Math.max(0, g.t - 0.4));
      const s = M.rayo(p.x, p.y + 0.5, p.z, 0, -1, 0, 6);
      if (s) p.y = p.y + 0.5 - s.t;
      return p;
    }

    // 🚧 puerta táctica que estás mirando (a menos de 12 m, casi de frente)
    _puertaMirada() {
      const TA = this.juego.tactico;
      if (!TA || !TA.brechas || !TA.brechas.length) return null;
      const cam = this.juego.camara, o = new T.Vector3(), d = new T.Vector3(), p = new T.Vector3();
      cam.getWorldPosition(o); cam.getWorldDirection(d);
      let mejor = null, md = 0.85;
      for (const b of TA.brechas) {
        if (b.rota || b.k > 0.5) continue;
        b.obj.getWorldPosition(p); p.y += 1;
        const v = p.sub(o), l = v.length();
        if (l > 12) continue;
        const k = v.dot(d) / l;
        if (k > md) { md = k; mejor = b; }
      }
      return mejor;
    }

    _decir(t) {
      const el = F.Hud.pieza(this.juego, 'fal-aviso');
      el.style.opacity = '1';
      el.textContent = '📻 ' + t;
      clearTimeout(this._tDecir); this._tDecir = setTimeout(() => { el.style.opacity = '0'; }, 1400);
    }

    /* ---------- Cada cuadro ---------- */
    actualizar(dt) {
      if (!this.hay) return;
      const J = this.juego, j = J.jugador, E = F.Entrada;
      if (!j) return;
      // menú: mantener G (teclado) · pulsar 👥 (táctil: abre / cierra)
      if (E.pulsado('ordenes')) { if (this.menu && !this.porTecla) this.cerrarMenu(); else this.abrirMenu(!F.Tactil || !F.Tactil.visible); }
      if (this.menu) {
        const tc = E.teclasCuadro;
        if (tc) for (let n = 1; n <= ORDENES.length; n++) if (tc.has('Digit' + n)) { const k = ORDENES[n - 1][0]; const b = this.menuEl.querySelector(`[data-o="${k}"]`); if (!b.disabled) { this.dar(k); this.cerrarMenu(); } break; }
        if (this.menu && this.porTecla && !E.mantenido('ordenes')) this.cerrarMenu();
      }
      // rastro del jugador (para seguirle): un punto cada 0,5 m, hasta 40
      const P = j.cuerpo.pie, u = this.rastro[0];
      if (!u || (P.x - u.x) ** 2 + (P.z - u.z) ** 2 > 0.25) { this.rastro.unshift(P.clone()); if (this.rastro.length > 40) this.rastro.pop(); }
      // metas de la orden: 5 veces por segundo
      this.t -= dt;
      if (this.t > 0) return;
      this.t = 0.2; this._metas(j);
      // HUD del equipo: 5 veces por segundo y solo si cambia
      const txt = this.lista.map((A) => `${A.ent.nombre}|${Math.ceil(A.vida)}|${A.muerto}|${A.estado === 'orden' ? A.orden.tipo : 'combate'}`).join(';');
      if (txt !== this._txt) {
        this._txt = txt;
        this.equipoEl.innerHTML = this.lista.map((A) => `<div class="${A.muerto ? 'fal-muerto' : ''}">🛡 ${A.ent.nombre || 'Aliado'} · ${A.muerto ? 'Caído' : NOMBRE[A.estado === 'orden' ? A.orden.tipo : 'combate']}<i style="width:${A.muerto ? 0 : Math.max(0, A.vida / A.c.vida) * 100}%"></i></div>`).join('');
      }
    }

    _metas(j) {
      const vivos = this.lista.filter((A) => !A.muerto);
      vivos.forEach((A, i) => {
        const o = A.orden || { tipo: 'seguir' };
        if (o.tipo === 'seguir') {
          // en fila: el 1º a ~1,8 m de ti, el 2º a ~3 m… sobre tu rastro
          const atras = 1.8 + i * 1.3, R = this.rastro;
          let acum = 0, q = R[0] || j.cuerpo.pie;
          for (let k = 1; k < R.length; k++) { acum += R[k].distanceTo(R[k - 1]); q = R[k]; if (acum >= atras) break; }
          const dYo = Math.hypot(A.cuerpo.pie.x - j.cuerpo.pie.x, A.cuerpo.pie.z - j.cuerpo.pie.z);
          if (dYo < atras - 0.4) A.metaOrden.copy(A.cuerpo.pie);   // ya está cerca: quieto (no te empuja)
          else A.metaOrden.copy(q);
          A.mirarOrden = null;
        } else if (o.tipo === 'ir') {
          const k = i - (vivos.length - 1) / 2;
          A.metaOrden.set(o.punto.x + k * 1.2, o.punto.y, o.punto.z + (i % 2) * 0.8);
        } else if (o.tipo === 'limpiar') this._limpiar(A, o, i, vivos);
      });
    }

    // 🚧 abrir y limpiar: todos a la puerta → el primero la abre → entran a sus puntos → esperan vigilando
    _limpiar(A, o, i, vivos) {
      const d = o.puerta, TA = this.juego.tactico;
      // ¿de qué lado de la puerta está? (>0 = el del equipo, <0 = ya dentro)
      const ladoDe = (B) => ((B.cuerpo.pie.x - o.pos.x) * o.n.x + (B.cuerpo.pie.z - o.pos.z) * o.n.z) * o.lado;
      if (o.fase === 'ir') {
        A.metaOrden.copy(o.fila[i % o.fila.length]);
        A.mirarOrden = o.pos;
        // cuando el primero llega (o tras 8 s), la abre
        const P = vivos[0];
        if (P && (Math.hypot(P.cuerpo.pie.x - o.fuera.x, P.cuerpo.pie.z - o.fuera.z) < 1.3 || (o.t += 0.2) > 8)) {
          if (!d.rota && d.k < 0.5) { if (d.cerrada) TA._patada(d); else TA._abrir(d, 1.2); }
          o.fase = 'entrar';
          this._decir('¡Entrando!');
        }
      } else if (o.fase === 'entrar') {
        // de uno en uno: cada uno sale cuando el de delante ya cruzó; primero al hueco de la puerta, luego a su punto
        o.tEntrar = (o.tEntrar || 0) + 0.2 / vivos.length;
        const delante = vivos[i - 1];
        const turno = i === 0 || (delante && ladoDe(delante) < -0.3 && o.tEntrar > i * 0.5);
        if (!turno) A.metaOrden.copy(o.fila[i % o.fila.length]);
        else if (ladoDe(A) > -0.2) A.metaOrden.copy(o.pos).addScaledVector(o.n, -o.lado * 0.6);   // cruzar por el centro del hueco
        else A.metaOrden.copy(o.dentro[i % o.dentro.length]);
        A.mirarOrden = o.mirar;
        if (vivos.every((B, k) => Math.hypot(B.cuerpo.pie.x - o.dentro[k % o.dentro.length].x, B.cuerpo.pie.z - o.dentro[k % o.dentro.length].z) < 1)) {
          o.fase = 'hecho';
          this._decir('Sala despejada');
        }
      }
    }

    detener() {
      if (!this.hay) return;
      this.cerrarMenu();
      if (F.Tactil) F.Tactil.ponerContexto('ordenes', false);
    }
  }

  function estilo() { if (!css) { css = true; const st = document.createElement('style'); st.textContent = CSS; document.head.appendChild(st); } }
  F.Aliados = { Gestor, MAX, ORDENES, estilo };
})(window.FORJA);
