/* =========================================================
   FORJA · GESTOR DE ENTIDADES (optimización al jugar)
   Lo crea el Juego al empezar y lo para al terminar. En el editor no cambia nada.
   - Juntar lo quieto: los marcos de puerta (piezas que nunca se mueven y comparten material) se dibujan como UNA
     malla por material. Las piezas de verdad siguen ahí (chocan igual); solo dejan de dibujarse.
   - No dibujar lo lejano: recogibles, palancas, cofres, puertas, salidas, props pequeños… más allá de
     ajustes.distObjetos (0 = la distancia de dibujo).
   - No dibujar lo tapado: un rayo contra la colisión (paredes y puertas cerradas) de la cámara al objeto. Se revisa
     un trozo de la lista cada cuadro (cada cosa unas 4 veces por segundo), así cuesta lo mismo con 50 que con 500.
   - Enemigos tapados: E.tapado → no se dibujan, se animan menos y piensan menos si están tranquilos (enemigos.js).
   Ocultar usa la CAPA 7 de three.js (la cámara solo ve la 0): no pisa el "visible" que usan los demás sistemas
   (recogido, roto, energía de puertas…).
   ========================================================= */
(function (F) {
  'use strict';
  const T = THREE;
  const CAPA_OCULTA = 7;
  // estas no se dibujan al jugar o las lleva otro sistema
  const FUERA = new Set(['camara', 'sonido', 'inicio', 'carpeta', 'luz', 'disparador', 'condicion', 'agua', 'enemigo', 'punto', 'aparecedor', 'suelo', 'montable']);
  const RADIO_MAX = 6;
  const CERCA = 10;               // a menos de esto nada se esconde por estar tapado            // más grandes (el nivel, edificios) no se ocultan: casi siempre se ve algún trozo
  const _a = new T.Vector3(), _b = new T.Vector3(), _l = new T.Vector3(), _c = new T.Box3(), _s = new T.Sphere();

  class Gestor {
    constructor(juego) {
      this.juego = juego;
      const aj = juego.ajustes || juego.proyecto.ajustes || {};
      this.ocultarTapado = aj.ocultarTapado !== false;
      const dd = F.Render.Vista.distanciaDibujo(juego.escena.ambiente);
      this.dist = +aj.distObjetos > 0 ? Math.min(+aj.distObjetos, dd) : dd;
      this.lista = [];
      this.juntas = [];           // mallas unidas (se quitan al terminar)
      this.escondidas = [];       // piezas que dibuja una malla unida
      this.i = 0; this.iE = 0;
      this.cuenta = { ocultos: 0, lejos: 0, tapados: 0, enemTapados: 0 };
      this._unida = new Set();
      this.todo = true;
      this._quitar = F.on('puerta-abierta', () => { this.todo = true; });
      if (aj.juntarQuietos !== false) this._juntar();
      this._registrar();
    }

    // las mallas propias de una entidad (sin entrar en entidades hijas)
    _mallas(obj) {
      const out = [];
      const rec = (o) => { if (o.isMesh && !o.userData.ayudaEditor) out.push(o); for (const h of o.children) if (!h.userData.entId) rec(h); };
      rec(obj);
      return out;
    }

    _registrar() {
      const J = this.juego;
      J.vista.escena.updateMatrixWorld(true);
      for (const ent of J.escena.entidades) {
        if (FUERA.has(ent.tipo)) continue;
        const obj = J.objetos.get(ent.id);
        if (!obj) continue;
        const mallas = this._mallas(obj).filter((m) => !this._unida.has(m));
        if (!mallas.length) continue;
        _c.makeEmpty();
        for (const m of mallas) { if (!m.geometry.boundingBox) m.geometry.computeBoundingBox(); _c.union(m.geometry.boundingBox.clone().applyMatrix4(m.matrixWorld)); }
        if (_c.isEmpty()) continue;
        _c.getBoundingSphere(_s);
        if (_s.radius > RADIO_MAX) continue;
        const mueve = ent.tipo === 'plataforma' || ent.tipo === 'trampa' || ent.tipo === 'rehen';
        this.lista.push({ ent, obj, mallas, centro: _s.center.clone(), off: mueve ? _s.center.clone().sub(obj.getWorldPosition(new T.Vector3())) : null, radio: _s.radius, oculto: false });
      }
    }

    // 🧱 juntar los marcos de puerta (mismo material compartido = una malla)
    _juntar() {
      const J = this.juego;
      this._unida = new Set();
      J.vista.escena.updateMatrixWorld(true);
      const porMat = new Map();
      for (const ent of J.escena.entidades) {
        if (ent.tipo !== 'puerta') continue;
        const obj = J.objetos.get(ent.id);
        const marco = obj && obj.userData.marcoPuerta;
        if (!marco || !marco.visible) continue;
        marco.updateMatrixWorld(true);
        for (const m of marco.children) {
          if (!m.isMesh || !m.material || !m.material.userData.compartido) continue;
          const g = m.geometry.index ? m.geometry.toNonIndexed() : m.geometry.clone();
          for (const k of Object.keys(g.attributes)) if (!['position', 'normal', 'uv'].includes(k)) g.deleteAttribute(k);
          g.applyMatrix4(m.matrixWorld);
          if (!porMat.has(m.material)) porMat.set(m.material, { geos: [], sombra: m.castShadow, recibe: m.receiveShadow });
          porMat.get(m.material).geos.push(g);
          this.escondidas.push(m);
          this._unida.add(m);
        }
      }
      for (const [mat, x] of porMat) {
        const geo = T.mergeGeometries(x.geos);
        x.geos.forEach((g) => g.dispose());
        if (!geo) continue;
        const malla = new T.Mesh(geo, mat);
        malla.name = 'forja_juntas';
        malla.castShadow = x.sombra; malla.receiveShadow = x.recibe;
        malla.matrixAutoUpdate = false;
        J.vista.escena.add(malla);
        this.juntas.push(malla);
      }
      for (const m of this.escondidas) m.layers.set(CAPA_OCULTA);
    }

    _ocultar(it, si) {
      if (it.oculto === si) return;
      it.oculto = si;
      for (const m of it.mallas) m.layers.set(si ? CAPA_OCULTA : 0);
    }

    // desde dónde se mira: la cámara, donde estará en un momento (va con el jugador) y un poco a cada lado.
    // Si CUALQUIERA ve el objeto, se dibuja: así aparece antes de que asomes la esquina (sin "pop")
    _ojos(cam) {
      const J = this.juego, j = J.jugador;
      const o = this._oj || (this._oj = [new T.Vector3(), new T.Vector3(), new T.Vector3(), new T.Vector3()]);
      o[0].copy(cam);
      o[1].copy(cam);
      const v = j && j.cuerpo && j.cuerpo.velocidad;
      if (v) { o[1].x += v.x * 0.4; o[1].z += v.z * 0.4; }
      J.camara.getWorldDirection(_l);
      const lx = -_l.z, lz = _l.x, h = Math.hypot(lx, lz) || 1;
      o[2].set(cam.x + lx / h * 0.7, cam.y, cam.z + lz / h * 0.7);
      o[3].set(cam.x - lx / h * 0.7, cam.y, cam.z - lz / h * 0.7);
      return o;
    }

    // ¿algo de la colisión tapa el punto p (radio r) desde TODOS los ojos?
    _tapado(ojos, p, r) {
      const M = this.juego.mundo;
      const d0 = ojos[0].distanceTo(p);
      if (!M || d0 < Math.max(r + 4, CERCA)) return false;   // lo cercano nunca se esconde
      for (let e = 0; e < ojos.length; e++) {
        const cam = ojos[e];
        // desde la cámara: centro, arriba, abajo y los dos lados; desde los otros ojos basta centro y arriba
        const lado = _l.set(p.z - cam.z, 0, cam.x - p.x).normalize().multiplyScalar(r * 0.85);
        // puntos a revisar sin crear listas nuevas en cada llamada
        const np = e === 0 ? 5 : 2;
        for (let q = 0; q < np; q++) {
          const ox = q === 3 ? lado.x : q === 4 ? -lado.x : 0, oz = q === 3 ? lado.z : q === 4 ? -lado.z : 0;
          const oy = q === 1 ? r * 0.8 : q === 2 ? -r * 0.6 : 0;
          _b.set(p.x + ox - cam.x, p.y + oy - cam.y, p.z + oz - cam.z);
          const dd = _b.length();
          _b.multiplyScalar(1 / dd);
          if (!M.rayo(cam.x, cam.y, cam.z, _b.x, _b.y, _b.z, dd - r * 0.9)) return false;   // por ahí se ve
        }
      }
      return true;
    }

    actualizar(dt = 1 / 60) {
      const J = this.juego, cam = J.camara.getWorldPosition(_a);
      // salto grande de la cámara (teletransporte, otro nivel) o se abrió una puerta: se revisa todo YA
      if (this._cam && this._cam.distanceToSquared(cam) > 9) this.todo = true;
      (this._cam || (this._cam = new T.Vector3())).copy(cam);
      const ojos = this._ojos(cam);
      const L = this.lista, n = L.length;
      // un trozo de la lista cada cuadro (cada cosa ~6 veces por segundo a 60 fps)
      // por TIEMPO, no por cuadros: cada objeto ~5 veces por segundo y cada enemigo ~6, vayas a 60 o a 300 fps
      // (antes era una parte fija por cuadro: a 140 fps cada enemigo se revisaba ~35 veces por segundo, con hasta 11 rayos)
      this._acO = (this._acO || 0) + n * 5 * dt;
      let paso = this.todo ? n : Math.floor(this._acO);
      this._acO -= paso;
      paso = Math.min(paso, n);
      for (let k = 0; k < paso && n; k++) {
        const it = L[this.i++ % n];
        if (it.off) it.centro.copy(it.obj.getWorldPosition(_b)).add(it.off);
        const d = cam.distanceTo(it.centro);
        const lejos = d - it.radio > this.dist;
        const tapado = !lejos && this.ocultarTapado && this._tapado(ojos, it.centro, it.radio);
        // aparece al momento; para esconderse tiene que salir tapado dos veces seguidas
        it.nT = tapado ? (it.nT || 0) + 1 : 0;
        it.lejos = lejos; it.tapado = it.nT >= 2;
        this._ocultar(it, lejos || it.tapado);
      }
      // enemigos (los mueve su gestor: solo se marca E.tapado)
      const EL = J.enemigos ? J.enemigos.lista : [], ne = EL.length;
      if (this.ocultarTapado && ne) {
        this._acE = (this._acE || 0) + ne * 6 * dt;
        let pasoE = this.todo ? ne : Math.floor(this._acE);
        this._acE -= pasoE;
        pasoE = Math.min(pasoE, ne);
        for (let k = 0; k < pasoE; k++) {
          const E = EL[this.iE++ % ne];
          if (E.muerto || E.reserva) { E.tapado = false; E._nT = 0; continue; }
          _c.min.copy(E.cuerpo.pie); _c.min.y += E.c.altura * 0.5;
          const t = this._tapado(ojos, _c.min, Math.max(0.6, E.c.altura * 0.6));
          E._nT = t ? (E._nT || 0) + 1 : 0;
          E.tapado = E._nT >= 2;
        }
      }
      this.todo = false;
      // cuenta (para la depuración)
      if ((this._t = (this._t || 0) + 1) % 30 === 0) {
        let o = 0, l = 0, t = 0, et = 0;
        for (const it of L) if (it.oculto) { o++; if (it.lejos) l++; else t++; }
        for (const E of EL) if (E.tapado && !E.muerto) et++;
        this.cuenta = { ocultos: o, lejos: l, tapados: t, enemTapados: et };
      }
    }

    resumen() {
      const c = this.cuenta;
      return `gestor: ${this.lista.length - c.ocultos}/${this.lista.length} objetos dibujados (${c.lejos} lejos, ${c.tapados} tapados) · ` +
        `enemigos tapados ${c.enemTapados} · juntas ${this.juntas.length} mallas (${this.escondidas.length} piezas)`;
    }

    detener() {
      if (this._quitar) { this._quitar(); this._quitar = null; }
      for (const it of this.lista) this._ocultar(it, false);
      for (const m of this.escondidas) m.layers.set(0);
      for (const m of this.juntas) { m.parent && m.parent.remove(m); m.geometry.dispose(); }
      const EL = this.juego.enemigos ? this.juego.enemigos.lista : [];
      for (const E of EL) E.tapado = false;
      this.lista = []; this.juntas = []; this.escondidas = [];
    }
  }

  F.Gestor = Gestor;
})(window.FORJA);
