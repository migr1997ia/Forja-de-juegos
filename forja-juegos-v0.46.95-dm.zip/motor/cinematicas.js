/* =========================================================
   FORJA · CINEMÁTICAS 🎬
   Cada nivel guarda sus cinemáticas en escena.cinematicas = [CINE…]. Una cinemática es una lista de PASOS;
   cada paso empieza "después del anterior" (cuando todo lo de antes terminó) o "a la vez que el anterior".
   El taller del editor (editor/taller-cine.js) la muestra como lista de pasos y como línea de tiempo: son
   los mismos datos.

   Mientras se ve, el mundo se queda quieto (jugador, enemigos y mecanismos no piensan); solo se mueven la
   cámara de la cinemática, las animaciones de los modelos y lo que hagan sus pasos.
   Se puede SALTAR (manteniendo Saltar / Usar / Esc, o el botón ⏭): lo que cambia el nivel (puertas, luces…)
   se aplica igual, así nada queda a medias.

   Cómo empieza: "al empezar el nivel" (alEmpezar) o con la acción "🎬 Ver cinemática" de una palanca o
   disparador. Al terminar: volver al juego, ir a otro nivel o seguir con otra cinemática.

   Este archivo solo se mete en el juego exportado si algún nivel tiene cinemáticas (editor/exportar.js):
   el resto del motor pregunta siempre "if (F.Cine)".
   ========================================================= */
(function (F) {
  'use strict';
  const T = THREE;

  /* ---------- Datos ---------- */
  const CINE = {
    nombre: 'Cinemática',
    alEmpezar: false,          // se ve sola al empezar el nivel
    unaVez: true,              // solo la primera vez por partida
    saltar: 'siempre',         // 'siempre' | 'vista' (solo si ya la viste alguna vez en este navegador)
    barras: 0.12,              // barras de cine mientras dura (0 = sin barras)
    alTerminar: 'juego',       // 'juego' | 'nivel' | 'cine'
    destino: '', llegada: '', transicion: 'negro',   // con 'nivel'
    siguiente: '',             // con 'cine': id de la siguiente
    pasos: [],
  };

  /* Tipos de paso. dur: si tiene duración propia. def: valores de un paso nuevo.
     cat: para agrupar los botones de añadir en el taller */
  const PASOS = {
    camara:  { e: '🎥 Cámara a un punto', cat: 'Cámara', dur: true, def: { destino: '', modo: 'viaje', dur: 2, mirar: '' } },
    mirar:   { e: '👁 Mirar / seguir a alguien', cat: 'Cámara', dur: false, def: { mirar: '' } },
    temblor: { e: '📳 Temblor de cámara', cat: 'Cámara', dur: true, def: { fuerza: 0.4, dur: 1 } },
    zoom:    { e: '🔍 Zoom', cat: 'Cámara', dur: true, def: { fov: 35, dur: 1.5 } },
    fundido: { e: '🎞 Transición (tapar / destapar)', cat: 'Imagen', dur: true, def: { trans: 'negro', tapar: true, dur: 0.8 } },
    barras:  { e: '🎬 Barras de cine', cat: 'Imagen', dur: false, def: { grosor: 0.12 } },
    efectos: { e: '📼 Filtro (VHS, anime…)', cat: 'Imagen', dur: false, def: { estilo: 'vhs' } },
    dialogo: { e: '💬 Diálogo', cat: 'Texto', dur: true, def: { quien: '', texto: '', dur: 3, esperar: false } },
    titulo:  { e: '🅰 Título grande', cat: 'Texto', dur: true, def: { texto: '', sub: '', dur: 3 } },
    sonido:  { e: '🔊 Sonido', cat: 'Audio', dur: false, def: { asset: '' } },
    musica:  { e: '🎵 Música', cat: 'Audio', dur: false, def: { asset: '' } },
    explosion: { e: '💥 Explosión', cat: 'Nivel', dur: false, def: { donde: '', tam: 'media', dano: 0, humo: true, asset: '' } },
    particulas: { e: '✨ Partículas (encender / apagar)', cat: 'Nivel', dur: false, def: { a: '', encender: true } },
    hacer:   { e: '⚙ Hacer algo del nivel', cat: 'Nivel', dur: false, def: { acciones: [] } },
    esperar: { e: '⏳ Esperar', cat: 'Nivel', dur: true, def: { dur: 1 } },
  };

  function cineNueva(nombre = 'Cinemática') {
    return { id: F.util.uid(), ...F.util.copiar(CINE), nombre };
  }
  function pasoNuevo(tipo, extra = {}) {
    const P = PASOS[tipo] || PASOS.esperar;
    return { id: F.util.uid(), tipo, cuando: 'despues', ...F.util.copiar(P.def), ...extra };
  }
  // segundos que dura un paso (los instantáneos 0; la cámara en corte también)
  function duracion(p) {
    const P = PASOS[p.tipo];
    if (!P || !P.dur) return 0;
    if (p.tipo === 'camara' && p.modo === 'corte') return 0;
    return Math.max(0, +p.dur || 0);
  }
  /* Horario: cuándo empieza y termina cada paso → { filas: [{ paso, inicio, fin }], total } */
  function horario(cine) {
    const filas = [];
    let finTodo = 0, inicioAnt = 0;
    for (const p of cine.pasos || []) {
      const inicio = p.cuando === 'alavez' ? inicioAnt : finTodo;
      const fin = inicio + duracion(p);
      filas.push({ paso: p, inicio, fin });
      finTodo = Math.max(finTodo, fin);
      inicioAnt = inicio;
    }
    return { filas, total: finTodo };
  }

  /* Vistas (para "saltar solo si ya la viste"): en el navegador del jugador, por juego */
  const claveVistas = (proyecto) => `forja:${F.util.slug(proyecto.nombre || 'juego')}:cine-vistas`;
  function leerVistas(proyecto) { try { return new Set(JSON.parse(localStorage.getItem(claveVistas(proyecto)) || '[]')); } catch (e) { return new Set(); } }
  function marcarVista(proyecto, id) {
    const s = leerVistas(proyecto); s.add(id);
    try { localStorage.setItem(claveVistas(proyecto), JSON.stringify([...s])); } catch (e) { /* sin almacenamiento */ }
  }
  // "solo una vez por partida": se reinicia al empezar partida nueva (o ▶ Jugar del editor)
  let vistasPartida = new Set();
  function reiniciarPartida() { vistasPartida = new Set(); }

  /* ---------- Capa en pantalla (diálogos, títulos, saltar) ---------- */
  let cssPuesto = false;
  function css() {
    if (cssPuesto) return;
    cssPuesto = true;
    const st = document.createElement('style');
    st.textContent = `
  .fc-capa { position: absolute; inset: 0; z-index: 27; pointer-events: none; font-family: var(--fn-fuente, ui-monospace, Consolas, monospace); }
  .fc-cine .fhud, .fc-cine .ft-tactil { display: none !important; }
  .fc-dialogo { position: absolute; left: 8%; right: 8%; bottom: 15%; padding: .8em 1.1em; background: rgba(0,0,0,.72); color: #f2f2f2;
    border: 2px solid rgba(255,255,255,.25); font-size: clamp(14px, 2.6vmin, 26px); line-height: 1.35; display: none; text-shadow: 2px 2px 0 #000; }
  .fc-dialogo b { display: block; color: #ffd166; margin-bottom: .25em; }
  .fc-dialogo .fc-sigue { position: absolute; right: .6em; bottom: .3em; animation: fc-parpadeo .8s steps(2) infinite; display: none; }
  .fc-titulo { position: absolute; inset: 0; display: none; flex-direction: column; align-items: center; justify-content: center; color: #fff;
    text-align: center; text-shadow: 3px 3px 0 #000; transition: opacity .5s; }
  .fc-titulo h1 { font-size: clamp(26px, 7vmin, 80px); margin: 0; letter-spacing: .06em; }
  .fc-titulo p { font-size: clamp(14px, 2.8vmin, 28px); margin: .4em 0 0; opacity: .85; }
  .fc-saltar { position: absolute; right: 2.2%; bottom: 3%; color: #fff; font-size: clamp(11px, 1.8vmin, 16px); background: rgba(0,0,0,.55);
    padding: .4em .8em; border-radius: 3px; pointer-events: auto; cursor: pointer; user-select: none; overflow: hidden; opacity: .75; }
  .fc-saltar i { position: absolute; left: 0; bottom: 0; height: 3px; background: #ffd166; width: 0; }
  @keyframes fc-parpadeo { 50% { opacity: 0; } }`;
    document.head.appendChild(st);
  }

  /* ---------- Reproductor (uno por juego: juego.cine) ---------- */
  const _v = new T.Vector3(), _q = new T.Quaternion(), _m = new T.Matrix4(), _arriba = new T.Vector3(0, 1, 0);

  class Reproductor {
    constructor(juego) {
      this.juego = juego;
      this.activo = null;           // la cinemática que se está viendo
      this.camara = new T.PerspectiveCamera(60, 1, 0.05, 1500);
      juego.vista.usarCamara(this.camara);
      this.pendiente = null;        // pedida mientras otra cosa tapa la pantalla (briefing de misión)
      this._primerCuadro = true;
    }

    lista() { return this.juego.escena.cinematicas || []; }
    buscar(id) { return this.lista().find((c) => c.id === id) || null; }

    /* Empieza una cinemática por id. Devuelve false si no existe o ya se vio (unaVez) */
    reproducir(id, forzar = false) {
      const c = this.buscar(id);
      if (!c || !(c.pasos || []).length) return false;
      const clave = this.juego.escena.id + ':' + c.id;
      if (!forzar && c.unaVez && vistasPartida.has(clave)) return false;
      if (this.activo) { this.pendiente = id; return true; }
      vistasPartida.add(clave);
      const J = this.juego;
      css();
      const cam = J.camara;
      this.camara.fov = cam.fov; this.camara.near = cam.near; this.camara.far = cam.far; this.camara.aspect = cam.aspect;
      this.camara.position.copy(cam.position); this.camara.quaternion.copy(cam.quaternion);
      this.camara.updateProjectionMatrix();
      this.base = { pos: cam.position.clone(), quat: cam.quaternion.clone(), fov: cam.fov };
      this.mirar = null;
      this.temblores = [];
      const hor = horario(c);
      this.activo = { cine: c, t: 0, filas: hor.filas.map((f) => ({ ...f, estado: 0 })), total: hor.total, retenido: null };
      this.fxAntes = J.vista.fxForzado;   // para devolver los efectos como estaban
      if (F.Efectos && c.barras > 0) F.Efectos.aplicarAccion(J.vista, 'nivel', c.barras);
      // capa en pantalla
      const cont = J.vista.contenedor;
      cont.classList.add('fc-cine');
      if (!this.capa || this.capa.parentNode !== cont) {
        if (this.capa) this.capa.remove();
        this.capa = document.createElement('div');
        this.capa.className = 'fc-capa';
        this.capa.innerHTML = '<div class="fc-dialogo"><b></b><span></span><em class="fc-sigue">▼</em></div><div class="fc-titulo"><h1></h1><p></p></div><div class="fc-saltar"><i></i><span></span></div>';
        cont.appendChild(this.capa);
        const bs = this.capa.querySelector('.fc-saltar');
        bs.addEventListener('pointerdown', () => { this.tocando = true; });
        for (const ev of ['pointerup', 'pointerleave', 'pointercancel']) bs.addEventListener(ev, () => { this.tocando = false; });
      }
      this.capa.style.display = '';
      this.puedeSaltar = c.saltar !== 'vista' || leerVistas(J.proyecto).has(c.id);
      const bs = this.capa.querySelector('.fc-saltar');
      bs.style.display = this.puedeSaltar ? '' : 'none';
      bs.querySelector('span').textContent = '⏭ Mantén ' + (F.Entrada.tactil ? 'aquí' : (F.Entrada.textoTeclado('saltar') || 'Espacio')) + ' para saltar';
      this.mantener = 0;
      this.tocando = false;
      this._dialogo(null);
      this._titulo(null);
      F.Entrada.limpiar();
      F.emitir('cine-empieza', { juego: J, cine: c });
      return true;
    }

    // Lo llama juego.js cada cuadro mientras hay cinemática (el mundo quieto). Devuelve la cámara para dibujar
    actualizar(dt) {
      const A = this.activo;
      if (!A) return null;
      const J = this.juego;
      // ⏭ saltar: mantener Saltar / Usar / Esc (o el botón) ~0,7 s
      if (this.puedeSaltar) {
        const E = F.Entrada;
        const quiere = this.tocando || E.mantenido('saltar') || E.mantenido('interactuar') || E.mantenido('pausa');
        this.mantener = quiere ? this.mantener + dt : 0;
        this.capa.querySelector('.fc-saltar i').style.width = Math.min(100, this.mantener / 0.7 * 100) + '%';
        if (this.mantener >= 0.7) { this.saltar(); return J.camara; }
      }
      // diálogo que espera una tecla: el tiempo no avanza hasta pulsarla
      if (A.retenido) {
        const E = F.Entrada;
        if (E.pulsado('interactuar') || E.pulsado('saltar') || E.pulsado('atacar')) { A.retenido = null; this.capa.querySelector('.fc-sigue').style.display = 'none'; }
      } else A.t += dt;
      for (const f of A.filas) {
        if (f.estado === 0 && A.t >= f.inicio) { f.estado = 1; this._empezar(f); }
        if (f.estado === 1) {
          const dur = f.fin - f.inicio;
          const k = dur > 0 ? Math.min(1, (A.t - f.inicio) / dur) : 1;
          this._avanzar(f, k);
          if (k >= 1) {
            if (f.paso.tipo === 'dialogo' && f.paso.esperar && !f.esperado) {
              f.esperado = true; A.retenido = f; this.capa.querySelector('.fc-sigue').style.display = 'block';
              continue;
            }
            f.estado = 2; this._terminar(f);
          }
        }
      }
      this._colocarCamara(dt);
      for (const { mx } of J.mixers) mx.update(dt);
      if (A.t >= A.total && !A.retenido && A.filas.every((f) => f.estado === 2)) this.fin();
      return this.camara;
    }

    // ---------- pasos ----------
    _obj(id) { return id ? this.juego.objetos.get(id) : null; }
    _ent(id) { return (this.juego.escena.entidades || []).find((e) => e.id === id) || null; }
    // a dónde se mira de una cosa: los personajes a la altura de la cara
    _puntoDe(id, out) {
      const J = this.juego;
      if (id === '__jugador') {
        const j = J.jugador;
        return out.copy(j.cuerpo.pie).add(_v.set(0, j.alturaOjos || 1.6, 0));
      }
      const o = this._obj(id);
      if (!o) return null;
      o.getWorldPosition(out);
      const e = this._ent(id);
      if (e && /^(enemigo|npc|rehen|inicio|tienda)$/.test(e.tipo)) out.y += 1.4;
      return out;
    }

    _empezar(f) {
      const p = f.paso, J = this.juego;
      switch (p.tipo) {
        case 'camara': {
          f.desdePos = this.base.pos.clone(); f.desdeQuat = this.base.quat.clone(); f.desdeFov = this.base.fov;
          f.aPos = this.base.pos.clone(); f.aQuat = this.base.quat.clone(); f.aFov = this.base.fov;
          if (p.destino === '__jugador') {
            f.aPos.copy(J.camara.position); f.aQuat.copy(J.camara.quaternion); f.aFov = J.camara.fov;
          } else {
            const o = this._obj(p.destino), e = this._ent(p.destino);
            if (o) {
              o.updateWorldMatrix(true, false);
              o.getWorldPosition(f.aPos);
              if (e && e.tipo === 'camara') { o.getWorldQuaternion(f.aQuat); f.aFov = (e.camara && e.camara.fov) || f.aFov; }
            }
          }
          this.mirar = p.mirar || null;
          if (p.modo === 'corte') { this.base.pos.copy(f.aPos); this.base.quat.copy(f.aQuat); this.base.fov = f.aFov; }
          break;
        }
        case 'mirar': this.mirar = p.mirar || null; break;
        case 'temblor': this.temblores.push(f); break;
        case 'zoom': f.desdeFov = this.base.fov; break;
        case 'fundido': if (F.Efectos) F.Efectos.transicion(J.vista, { tipo: p.trans || 'negro', a: p.tapar ? 1 : 0, segundos: f.fin - f.inicio }); break;
        case 'barras': if (F.Efectos) F.Efectos.aplicarAccion(J.vista, 'nivel', p.grosor || 0); break;
        case 'efectos': if (F.Efectos) F.Efectos.aplicarAccion(J.vista, p.estilo || 'nivel', (J.vista.pase && J.vista.pase.barrasMeta) || 0); break;
        case 'dialogo': this._dialogo(p); f.letras = 0; break;
        case 'titulo': this._titulo(p); break;
        case 'sonido': if (p.asset) F.Audio.efecto(p.asset); break;
        case 'musica': if (p.asset) F.Audio.musica(p.asset); else F.Audio.pararMusica(); break;
        case 'hacer': if (J.mecanismos) J.mecanismos.ejecutar((p.acciones || []).filter((a) => a.que !== 'cine'), true); break;
        case 'explosion': {
          const pt = F.Explosiones && F.Explosiones.puntoDe(J, p.donde, new T.Vector3());
          if (pt) F.Explosiones.lanzar(J, pt, { tam: p.tam, dano: p.dano || 0, humo: p.humo !== false, sonido: p.asset || '' });
          break;
        }
        case 'particulas': if (F.Particulas && F.Particulas.encender && p.a) F.Particulas.encender(J, p.a, p.encender !== false); break;
      }
    }

    // 📳 temblor extra (explosiones durante la cinemática)
    sacudir(fuerza, segundos) {
      const A = this.activo;
      if (!A) return;
      this.temblores.push({ paso: { fuerza }, inicio: A.t, fin: A.t + segundos });
    }

    _avanzar(f, k) {
      const p = f.paso;
      const s = k * k * (3 - 2 * k);   // suave al empezar y al terminar
      if (p.tipo === 'camara' && p.modo !== 'corte') {
        this.base.pos.lerpVectors(f.desdePos, f.aPos, s);
        this.base.quat.slerpQuaternions(f.desdeQuat, f.aQuat, s);
        this.base.fov = f.desdeFov + (f.aFov - f.desdeFov) * s;
      } else if (p.tipo === 'zoom') {
        this.base.fov = f.desdeFov + ((+p.fov || 60) - f.desdeFov) * s;
      } else if (p.tipo === 'dialogo') {
        // máquina de escribir: el texto sale en el primer 60 % del paso
        const n = Math.ceil(String(p.texto || '').length * Math.min(1, k / 0.6));
        if (n !== f.letras) { f.letras = n; this.capa.querySelector('.fc-dialogo span').textContent = String(p.texto || '').slice(0, n); }
      } else if (p.tipo === 'titulo') {
        const el = this.capa.querySelector('.fc-titulo');
        el.style.opacity = String(Math.min(1, Math.min(k, 1 - k) * 5));
      }
    }

    _terminar(f) {
      const p = f.paso;
      if (p.tipo === 'dialogo') this._dialogo(null);
      if (p.tipo === 'titulo') this._titulo(null);
      if (p.tipo === 'temblor') this.temblores = this.temblores.filter((x) => x !== f);
    }

    _colocarCamara() {
      const c = this.camara, b = this.base;
      c.position.copy(b.pos);
      if (this.mirar && this._puntoDe(this.mirar, _v)) {
        _m.lookAt(b.pos, _v, _arriba);
        _q.setFromRotationMatrix(_m);
        c.quaternion.copy(_q);
        b.quat.copy(_q);   // así un viaje que sigue parte de aquí
      } else c.quaternion.copy(b.quat);
      // 📳 temblores (se apagan al final de su paso); "Reducir movimiento" del jugador los quita
      if (this.temblores.length && !this.juego.vista.sinMovimiento) {
        const A = this.activo;
        let f = 0;
        for (const x of this.temblores) {
          const dur = Math.max(0.01, x.fin - x.inicio), k = Math.min(1, (A.t - x.inicio) / dur);
          f = Math.max(f, (+x.paso.fuerza || 0) * (1 - k));
        }
        c.position.x += (Math.random() - 0.5) * f * 0.3;
        c.position.y += (Math.random() - 0.5) * f * 0.3;
        c.rotateZ((Math.random() - 0.5) * f * 0.05);
      }
      const asp = this.juego.camara.aspect;
      if (c.fov !== b.fov || c.aspect !== asp) { c.fov = b.fov; c.aspect = asp; c.updateProjectionMatrix(); }
    }

    _dialogo(p) {
      const el = this.capa && this.capa.querySelector('.fc-dialogo');
      if (!el) return;
      if (!p) { el.style.display = 'none'; return; }
      el.style.display = 'block';
      el.querySelector('b').textContent = p.quien || '';
      el.querySelector('b').style.display = p.quien ? '' : 'none';
      el.querySelector('span').textContent = '';
      el.querySelector('.fc-sigue').style.display = 'none';
    }
    _titulo(p) {
      const el = this.capa && this.capa.querySelector('.fc-titulo');
      if (!el) return;
      if (!p) { el.style.display = 'none'; return; }
      el.style.display = 'flex'; el.style.opacity = '0';
      el.querySelector('h1').textContent = p.texto || '';
      el.querySelector('p').textContent = p.sub || '';
    }

    /* ⏭ Saltar: lo que cambia el nivel se aplica igual (acciones, música); lo demás se descarta */
    saltar() {
      const A = this.activo;
      if (!A) return;
      const J = this.juego;
      for (const f of A.filas) {
        if (f.estado === 2) continue;
        const p = f.paso;
        if (f.estado === 0) {
          if (p.tipo === 'hacer' && J.mecanismos) J.mecanismos.ejecutar((p.acciones || []).filter((a) => a.que !== 'cine'), true);
          if (p.tipo === 'particulas' && F.Particulas && F.Particulas.encender && p.a) F.Particulas.encender(J, p.a, p.encender !== false);
          if (p.tipo === 'musica') { if (p.asset) F.Audio.musica(p.asset); else F.Audio.pararMusica(); }
        }
        f.estado = 2;
      }
      A.saltada = true;
      this.fin();
    }

    fin() {
      const A = this.activo;
      if (!A) return;
      const J = this.juego, c = A.cine;
      this.activo = null;
      marcarVista(J.proyecto, c.id);
      J.vista.contenedor.classList.remove('fc-cine');
      if (this.capa) this.capa.style.display = 'none';
      // los efectos vuelven a como estaban antes de la cinemática
      J.vista.fxForzado = this.fxAntes || null;
      J.vista._elegirFx();
      F.Entrada.limpiar();
      F.emitir('cine-termina', { juego: J, cine: c, saltada: !!A.saltada });
      // qué sigue
      const tapada = J.vista.pase && J.vista.pase.trans.meta > 0;
      if (c.alTerminar === 'cine' && c.siguiente && this.reproducir(c.siguiente, true)) return;
      if (c.alTerminar === 'nivel' && c.destino && J.salidas) {
        J.salidas.activar({ id: 'cine-nivel', tipo: 'salida', nombre: 'Cinemática', salida: { ...F.Niveles.SALIDA, destino: c.destino, llegada: c.llegada || '', transicion: c.transicion || 'negro' } });
        return;
      }
      // de vuelta al juego: si quedó tapada (o se saltó a medio fundido), se destapa
      if (F.Efectos && (tapada || (J.vista.pase && J.vista.pase.trans.v > 0))) F.Efectos.transicion(J.vista, { tipo: 'negro', a: 0, segundos: 0.4 });
      if (this.pendiente) { const id = this.pendiente; this.pendiente = null; this.reproducir(id); }
    }

    // Lo llama juego.js en el primer cuadro: las de "al empezar el nivel"
    alEmpezar() {
      for (const c of this.lista()) if (c.alEmpezar && this.reproducir(c.id)) return true;
      return false;
    }

    detener() {
      if (this.activo) { this.activo = null; this.juego.vista.contenedor.classList.remove('fc-cine'); }
      if (this.capa) this.capa.remove();
      this.capa = null;
      this.juego.vista.camaras.delete(this.camara);
    }
  }

  F.Cine = { CINE, PASOS, cineNueva, pasoNuevo, duracion, horario, Reproductor, reiniciarPartida, leerVistas };
})(window.FORJA);
