/* =========================================================
   FORJA · MENÚS DEL JUEGO
   Portada ("Pulsa cualquier tecla"), menú principal, pausa, opciones, controles y partidas.
   Se dibujan con HTML encima del juego; se manejan con ratón, teclado, mando o dedo.
   Qué botones hay y cómo se ven lo decide el creador en el editor (proyecto.menus).
     const menu = new FORJA.MenuJuego({ contenedor, proyecto, opciones, enEditor, alAccion(accion, boton, origen) });
     menu.mostrar('principal')  ·  menu.abrir('opciones')  ·  menu.atras()  ·  menu.ocultar()  ·  menu.actualizar(dt)
   origen = 'raton' | 'teclado' | 'mando' (el cursor solo se puede bloquear tras ratón o teclado)
   ========================================================= */
(function (F) {
  'use strict';

  /* Acciones que puede tener un botón. en: en qué menú tiene sentido. */
  const ACCIONES = {
    nueva:          { e: 'Nueva partida', en: ['principal', 'victoria'] },
    continuar:      { e: 'Continuar (última partida)', en: ['principal'] },
    misiones:       { e: '🗺 Misiones (elegir nivel)', en: ['principal', 'pausa', 'victoria'] },
    cargar:         { e: 'Cargar partida', en: ['principal', 'pausa', 'gameover'] },
    guardar:        { e: 'Guardar partida', en: ['pausa'] },
    mapa:           { e: '🗺 Mapa del nivel', en: ['pausa'] },
    capitulos:      { e: '📚 Capítulos (elegir episodio)', en: ['principal', 'victoria'] },
    borrar:         { e: '🗑 Borrar partida guardada', en: ['principal', 'pausa'] },
    opciones:       { e: 'Opciones', en: ['principal', 'pausa'] },
    escena:         { e: 'Ir a una escena…', en: ['principal', 'pausa', 'gameover', 'victoria'] },
    reanudar:       { e: 'Volver al juego', en: ['pausa'] },
    reiniciar:      { e: 'Reiniciar nivel / reintentar', en: ['pausa', 'gameover'] },
    menu_principal: { e: 'Ir al menú principal', en: ['pausa', 'gameover', 'victoria'] },
    salir:          { e: 'Salir del juego (en navegador: a la portada)', en: ['principal', 'pausa', 'gameover', 'victoria'] },
  };

  /* Plantillas: un punto de partida de colores y forma (el creador luego cambia lo que quiera) */
  const PLANTILLAS = {
    clasico: { nombre: 'Clásico PS1', colorTexto: '#e8e2d0', colorSel: '#e8a33d', colorFondo: '#000000', opacidadFondo: 0.55, alineacion: 'centro', mayusculas: true, tamano: 22 },
    survival: { nombre: 'Survival horror', colorTexto: '#a9a397', colorSel: '#d23a2a', colorFondo: '#050303', opacidadFondo: 0.82, alineacion: 'izquierda', mayusculas: true, tamano: 19 },
    arcade: { nombre: 'Arcade', colorTexto: '#ffffff', colorSel: '#ffd23a', colorFondo: '#0a1660', opacidadFondo: 0.6, alineacion: 'centro', mayusculas: true, tamano: 26 },
  };

  const CSS = `
  .fm { position: absolute; inset: 0; z-index: 30; display: flex; flex-direction: column; justify-content: center;
    padding: 6% 8%; box-sizing: border-box; color: var(--fm-texto); font-family: var(--fm-fuente);
    font-size: calc(var(--fm-tam) * var(--fm-escala) * 1px); user-select: none; -webkit-user-select: none;
    touch-action: manipulation; overflow: hidden; line-height: 1.25; }
  .fm.centro { align-items: center; text-align: center; }
  .fm.izquierda { align-items: flex-start; text-align: left; }
  .fm.mayus .fm-titulo, .fm.mayus .fm-item, .fm.mayus .fm-sub, .fm.mayus .fm-pulsar { text-transform: uppercase; }
  .fm-fondo { position: absolute; inset: 0; z-index: -1; background: var(--fm-fondo); }
  .fm-imagen { position: absolute; inset: 0; z-index: -2; background-size: cover; background-position: center; image-rendering: pixelated; }
  .fm-logo { max-width: 70%; max-height: 32%; image-rendering: pixelated; margin-bottom: .6em; }
  .fm-titulo { font-size: 2.3em; letter-spacing: .08em; margin: 0 0 .15em; text-shadow: .12em .12em 0 #000; font-weight: bold; }
  .fm-sub { opacity: .75; margin-bottom: 1.4em; font-size: .8em; letter-spacing: .1em; }
  .fm-lista { display: flex; flex-direction: column; gap: .28em; min-width: 40%; max-height: 62%; overflow-y: auto; scrollbar-width: none; }
  .fm.centro .fm-lista { align-items: stretch; }
  .fm-item { padding: .18em .6em; cursor: pointer; white-space: nowrap; text-shadow: .08em .08em 0 #000; position: relative; }
  .fm-item.sel { color: var(--fm-sel); }
  .fm-item.apagado { opacity: .35; cursor: default; }
  .fm-item.separado { margin-top: .6em; }
  .fm-fila { display: flex; gap: 1.2em; justify-content: space-between; align-items: center; }
  .fm-fila .fm-valor { opacity: .9; min-width: 7em; text-align: right; }
  .fm-flecha { opacity: 0; padding: 0 .3em; cursor: pointer; }
  .fm-item.sel .fm-flecha { opacity: 1; }
  .fm-celda { min-width: 6.5em; text-align: center; padding: 0 .3em; opacity: .75; }
  .fm-celda.sel { opacity: 1; color: var(--fm-sel); outline: .08em solid var(--fm-sel); }
  .fm-mapeo { font-size: .68em; min-width: 70%; }
  .fm-map, .fm-cab { display: grid; grid-template-columns: 1fr 10em 10em; gap: .6em; align-items: center; text-align: left; }
  .fm-cab { opacity: .55; font-size: .6em; padding: 0 .6em; min-width: 70%; box-sizing: border-box; }
  .fm-map .fm-celda, .fm-cab .fm-celda { min-width: 0; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
  .fm.mayus .fm-cab { text-transform: uppercase; }
  /* "Volver" fijo debajo de la lista e indicadores de que hay más */
  .fm-pie { display: flex; flex-direction: column; min-width: 40%; margin-top: .3em; }
  .fm.centro .fm-pie { align-items: stretch; }
  .fm-mas { font-size: .72em; opacity: 0; height: 1.3em; line-height: 1.3em; pointer-events: none; color: var(--fm-sel); transition: opacity .2s; }
  .fm-mas.ver { opacity: .9; pointer-events: auto; cursor: pointer; animation: fm-rebote 1s ease-in-out infinite; }
  @keyframes fm-rebote { 50% { transform: translateY(.2em); } }
  .fm-lista.fm-corte-abajo { -webkit-mask-image: linear-gradient(#000 82%, transparent); mask-image: linear-gradient(#000 82%, transparent); }
  .fm-lista.fm-corte-arriba { -webkit-mask-image: linear-gradient(transparent, #000 18%); mask-image: linear-gradient(transparent, #000 18%); }
  .fm-lista.fm-corte-arriba.fm-corte-abajo { -webkit-mask-image: linear-gradient(transparent, #000 15%, #000 85%, transparent); mask-image: linear-gradient(transparent, #000 15%, #000 85%, transparent); }
  /* pantalla vertical (celular de pie): más ancho útil, textos que pueden partirse, columnas que se encogen */
  .fm.vertical { padding: 8% 5%; }
  .fm.vertical .fm-lista, .fm.vertical .fm-pie { min-width: 92%; max-height: 64%; }
  .fm.vertical .fm-titulo { font-size: 1.9em; }
  .fm.vertical .fm-item { white-space: normal; }
  .fm.vertical .fm-fila { gap: .5em; }
  .fm.vertical .fm-fila .fm-valor { min-width: 4.5em; }
  .fm.vertical .fm-mapeo, .fm.vertical .fm-cab { min-width: 96%; }
  .fm.vertical .fm-map, .fm.vertical .fm-cab { grid-template-columns: minmax(0, 1fr) minmax(3.5em, 7em) minmax(3.5em, 7em); gap: .35em; }
  .fm.vertical .fm-celda { min-width: 0; }
  .fm-ayuda { position: absolute; bottom: 3%; left: 0; right: 0; text-align: center; font-size: .55em; opacity: .55; }
  .fm-pulsar { margin-top: 2.5em; animation: fm-parpadeo 1.1s steps(2) infinite; }
  .fm-aviso { position: absolute; bottom: 9%; left: 50%; transform: translateX(-50%); background: rgba(0,0,0,.75);
    padding: .3em .9em; font-size: .7em; border: .06em solid var(--fm-sel); }
  .fm-ranura-info { font-size: .62em; opacity: .7; display: block; text-transform: none; }
  @keyframes fm-parpadeo { 50% { opacity: 0; } }
  /* Clásico: flecha delante del elegido */
  .fm.p-clasico .fm-item.sel::before { content: '▶'; position: absolute; left: -.9em; font-size: .8em; top: .3em; }
  .fm.p-clasico.centro .fm-item.sel::before { left: auto; margin-left: -1.2em; }
  /* Survival: sobrio, con raya bajo el elegido */
  .fm.p-survival .fm-titulo { font-weight: normal; letter-spacing: .25em; text-shadow: none; }
  .fm.p-survival .fm-item { letter-spacing: .18em; text-shadow: none; }
  .fm.p-survival .fm-item.sel { border-bottom: .06em solid var(--fm-sel); }
  /* Arcade: grueso y el elegido parpadea */
  .fm.p-arcade .fm-titulo { font-weight: 900; text-shadow: .1em .1em 0 #000, -.04em -.04em 0 var(--fm-sel); }
  .fm.p-arcade .fm-item { font-weight: bold; }
  .fm.p-arcade .fm-item.sel { animation: fm-parpadeo .5s steps(2) infinite; }
  `;

  function hexARgba(hex, a) {
    const h = (hex || '#000000').replace('#', '');
    const n = parseInt(h.length === 3 ? h.split('').map((c) => c + c).join('') : h, 16) || 0;
    return `rgba(${(n >> 16) & 255},${(n >> 8) & 255},${n & 255},${a})`;
  }
  const fmtFecha = (t) => {
    const d = new Date(t);
    const dos = (n) => String(n).padStart(2, '0');
    return `${dos(d.getDate())}/${dos(d.getMonth() + 1)}/${d.getFullYear()} ${dos(d.getHours())}:${dos(d.getMinutes())}`;
  };
  const fmtTiempo = (s) => {
    s = Math.floor(s || 0);
    const h = Math.floor(s / 3600), m = Math.floor((s % 3600) / 60);
    return h ? `${h} h ${m} min` : `${m} min ${s % 60} s`;
  };

  class MenuJuego {
    constructor({ contenedor, proyecto, opciones, enEditor = false, alAccion = () => {} }) {
      this.contenedor = contenedor;
      this.proyecto = proyecto;
      this.opciones = opciones;
      this.enEditor = enEditor;
      this.alAccion = alAccion;
      this.pila = [];
      this.items = [];
      this.indice = 0;
      this.columna = 0;            // en Controles: 0 = teclado, 1 = mando
      this.capturando = null;      // { accion, tipo, desde }
      this.bloqueoHasta = 0;
      this.mandoPrevio = [];
      this.repeticion = { dir: '', t: 0 };

      if (!document.getElementById('estilos-forja-menu')) {
        const st = document.createElement('style');
        st.id = 'estilos-forja-menu';
        st.textContent = CSS;
        document.head.appendChild(st);
      }
      if (getComputedStyle(contenedor).position === 'static') contenedor.style.position = 'relative';
      this.raiz = document.createElement('div');
      this.raiz.className = 'fm';
      this.raiz.style.display = 'none';
      contenedor.appendChild(this.raiz);

      this._tecla = (e) => this.alTecla(e);
      this._raton = (e) => this.alRaton(e);
      this._tam = () => this.ajustarEscala();
      window.addEventListener('keydown', this._tecla, true);
      this.raiz.addEventListener('mousedown', this._raton);
      window.addEventListener('resize', this._tam);
    }

    get visible() { return this.raiz.style.display !== 'none'; }
    get actual() { return this.pila[this.pila.length - 1] || null; }

    /* ---------- Pantallas ---------- */
    mostrar(tipo, datos = {}) {
      this.pila = [{ tipo, datos }];
      this.indice = 0;
      this.raiz.style.display = 'flex';
      this.bloqueoHasta = performance.now() + 250;   // que la tecla que abrió el menú no lo cierre
      this.pintar();
    }

    abrir(tipo, datos = {}) {
      if (this.actual) this.actual.indice = this.indice;
      this.pila.push({ tipo, datos });
      this.indice = 0;
      this.columna = 0;
      this.pintar();
    }

    atras() {
      if (this.capturando) { this.capturando = null; this.pintar(); return; }
      if (this.pila.length > 1) {
        this.pila.pop();
        this.indice = this.actual.indice || 0;
        this.pintar();
        return;
      }
      // en el primer nivel: en pausa, atrás = volver al juego
      if (this.actual && (this.actual.tipo === 'pausa' || (this.actual.datos && this.actual.datos.desdePunto))) this.alAccion('reanudar', null, this.origen || 'teclado');
    }

    ocultar() {
      this.raiz.style.display = 'none';
      this.pila = [];
      this.capturando = null;
    }

    destruir() {
      window.removeEventListener('keydown', this._tecla, true);
      window.removeEventListener('resize', this._tam);
      this.raiz.remove();
    }

    aviso(texto) {
      const el = document.createElement('div');
      el.className = 'fm-aviso';
      el.textContent = texto;
      this.raiz.appendChild(el);
      setTimeout(() => el.remove(), 2200);
    }

    ajustarEscala() {
      const h = this.raiz.clientHeight || this.contenedor.clientHeight || 600;
      const w = this.raiz.clientWidth || this.contenedor.clientWidth || 800;
      // la letra se ajusta al lado que más limite: en vertical (celular de pie) manda el ancho
      const esc = Math.min(h / 600, w / 640);
      this.raiz.style.setProperty('--fm-escala', Math.max(0.5, Math.min(2.2, esc)).toFixed(3));
      this.raiz.classList.toggle('vertical', w < h);
      for (const l of this.raiz.querySelectorAll('.fm-lista')) if (l._ind) l._ind();
    }

    // Colores, fuente y forma según proyecto.menus.tema
    aplicarTema() {
      const t = this.proyecto.menus.tema;
      const fuente = t.fuente && F.Assets && F.Assets.mapa.get(t.fuente);
      const r = this.raiz.style;
      r.setProperty('--fm-texto', t.colorTexto);
      r.setProperty('--fm-sel', t.colorSel);
      r.setProperty('--fm-tam', t.tamano || 22);
      r.setProperty('--fm-fuente', (fuente && fuente.familia ? `'${fuente.familia}', ` : '') + 'ui-monospace, Consolas, monospace');
      this.raiz.className = `fm p-${t.plantilla || 'clasico'} ${t.alineacion === 'izquierda' ? 'izquierda' : 'centro'}${t.mayusculas ? ' mayus' : ''}`;
      this.ajustarEscala();
    }

    pintar() {
      const p = this.actual;
      if (!p) return;
      this.aplicarTema();
      const t = this.proyecto.menus.tema;
      const mp = this.proyecto.menus.principal;
      this.raiz.innerHTML = '';
      this.items = [];
      const fondo = document.createElement('div');
      fondo.className = 'fm-fondo';
      // Menú principal sin escena de fondo: color sólido o imagen. Encima del juego (pausa): translúcido.
      const sobreJuego = p.datos.sobreJuego;
      const enPrincipal = !sobreJuego && ['portada', 'principal'].includes(this.pila[0].tipo);
      let opacidad = t.opacidadFondo;
      if (enPrincipal && mp.fondo === 'color') opacidad = 1;
      if (enPrincipal && p.tipo === 'portada' && mp.fondo === 'escena') opacidad = Math.min(opacidad, 0.25);
      fondo.style.background = hexARgba(t.colorFondo, opacidad);
      this.raiz.appendChild(fondo);
      if (enPrincipal && mp.fondo === 'imagen' && mp.imagen) {
        const a = F.Assets.mapa.get(mp.imagen);
        if (a && a.url) {
          const img = document.createElement('div');
          img.className = 'fm-imagen';
          img.style.backgroundImage = `url("${a.url}")`;
          this.raiz.appendChild(img);
        }
      }
      const fn = this['p_' + p.tipo];
      if (fn) fn.call(this, p.datos);
      const ayuda = document.createElement('div');
      ayuda.className = 'fm-ayuda';
      ayuda.textContent = p.tipo === 'portada' ? '' : p.tipo === 'mapeo'
        ? '↑↓ elegir · ←→ teclado / mando · Enter / A cambiar · Esc / B volver'
        : '↑↓ elegir · ←→ cambiar · Enter / A aceptar · Esc / B volver';
      this.raiz.appendChild(ayuda);
      if (this.indice >= this.items.length) this.indice = 0;
      if (this.items[this.indice] && this.items[this.indice].apagado) this.mover(1, true);
      this.marcar();
    }

    marcar() {
      this.items.forEach((it, i) => {
        it.el.classList.toggle('sel', i === this.indice);
        if (it.celdas) it.celdas.forEach((c, j) => c.classList.toggle('sel', i === this.indice && j === this.columna));
      });
      const el = this.items[this.indice] && this.items[this.indice].el;
      if (el && el.scrollIntoView) el.scrollIntoView({ block: 'nearest' });
      this.indicadores();
      for (const l of this.raiz.querySelectorAll('.fm-lista')) if (l._ind) l._ind();
    }

    /* ---------- Piezas ---------- */
    cabecera(titulo, sub, logo) {
      if (logo) {
        const a = F.Assets.mapa.get(logo);
        if (a && a.url) {
          const img = document.createElement('img');
          img.className = 'fm-logo';
          img.src = a.url;
          this.raiz.appendChild(img);
        }
      }
      if (titulo) {
        const h = document.createElement('div');
        h.className = 'fm-titulo';
        h.textContent = titulo;
        this.raiz.appendChild(h);
      }
      if (sub) {
        const s = document.createElement('div');
        s.className = 'fm-sub';
        s.textContent = sub;
        this.raiz.appendChild(s);
      }
    }

    lista() {
      const l = document.createElement('div');
      l.className = 'fm-lista';
      this.raiz.appendChild(l);
      return l;
    }

    // it: { texto, activar(origen), izq(), der(), apagado, separado, valor() }
    item(lista, it) {
      const el = document.createElement('div');
      el.className = 'fm-item' + (it.apagado ? ' apagado' : '') + (it.separado ? ' separado' : '');
      it.el = el;
      if (it.valor) {
        el.classList.add('fm-fila');
        const et = document.createElement('span');
        et.textContent = it.texto;
        const v = document.createElement('span');
        v.className = 'fm-valor';
        const izq = document.createElement('span');
        izq.className = 'fm-flecha';
        izq.textContent = '◀';
        const der = document.createElement('span');
        der.className = 'fm-flecha';
        der.textContent = '▶';
        const txt = document.createElement('span');
        v.append(izq, txt, der);
        it.refrescar = () => { txt.textContent = it.valor(); };
        it.refrescar();
        izq.onclick = (e) => { e.stopPropagation(); this.origen = 'raton'; it.izq && it.izq(); it.refrescar(); };
        der.onclick = (e) => { e.stopPropagation(); this.origen = 'raton'; it.der && it.der(); it.refrescar(); };
        el.append(et, v);
      } else {
        el.textContent = it.texto;
      }
      const i = this.items.length;
      el.onmouseenter = () => { if (!it.apagado && this.indice !== i) { this.indice = i; this.marcar(); } };
      el.onclick = () => {
        if (it.apagado || performance.now() < this.bloqueoHasta) return;
        this.indice = i;
        this.origen = 'raton';
        this.activar();
      };
      // "Volver" va debajo de la lista, fuera de la parte que se desplaza: siempre a la vista (en el celular quedaba escondido)
      if (it.texto === 'Volver' && lista.classList.contains('fm-lista')) {
        if (!lista._pie) {
          lista._pie = document.createElement('div');
          lista._pie.className = 'fm-pie';
          lista.after(lista._pie);
        }
        lista._pie.appendChild(el);
      } else {
        lista.appendChild(el);
      }
      this.items.push(it);
      return it;
    }

    /* Si una lista no cabe: flechas ▲ ▼ y bordes difuminados que dicen que hay más (se actualizan al desplazar) */
    indicadores() {
      for (const l of this.raiz.querySelectorAll('.fm-lista')) {
        if (l._ind) continue;
        const arriba = document.createElement('div'), abajo = document.createElement('div');
        arriba.className = 'fm-mas fm-mas-arriba'; arriba.textContent = '▲';
        abajo.className = 'fm-mas fm-mas-abajo'; abajo.textContent = '▼ más abajo';
        l.before(arriba);
        l.after(abajo);
        arriba.onclick = () => l.scrollBy({ top: -l.clientHeight * 0.7, behavior: 'smooth' });
        abajo.onclick = () => l.scrollBy({ top: l.clientHeight * 0.7, behavior: 'smooth' });
        const ver = () => {
          const hayArriba = l.scrollTop > 2, hayAbajo = l.scrollTop + l.clientHeight < l.scrollHeight - 2;
          arriba.classList.toggle('ver', hayArriba);
          abajo.classList.toggle('ver', hayAbajo);
          l.classList.toggle('fm-corte-arriba', hayArriba);
          l.classList.toggle('fm-corte-abajo', hayAbajo);
        };
        l.addEventListener('scroll', ver, { passive: true });
        l._ind = ver;
        requestAnimationFrame(ver);
      }
    }

    botonesDe(menu) {
      const conf = this.proyecto.menus[menu];
      const hay = F.Partidas.hay(this.proyecto);
      const l = this.lista();
      for (const b of conf.botones) {
        // En navegador una página no se puede cerrar sola: "Salir" lleva a la portada. En el menú principal no tiene sentido.
        if (b.accion === 'salir' && menu === 'principal' && !this.enEditor && !window.FORJA_ESCRITORIO) continue;
        // 💾 solo en puntos del mapa: sin "Guardar" en la pausa
        if (b.accion === 'guardar' && menu === 'pausa' && ((this.proyecto.menus.guardado || {}).donde === 'puntos')) continue;
        const apagado = (b.accion === 'continuar' || b.accion === 'cargar') && !hay;
        this.item(l, {
          texto: b.accion === 'salir' && this.enEditor ? `${b.texto} (al editor)` : b.texto,
          apagado,
          activar: (origen) => this.accionBoton(b, origen),
        });
      }
    }

    accionBoton(b, origen) {
      this.efecto('sonidoAceptar');
      if (b.accion === 'opciones') this.abrir('opciones');
      else if (b.accion === 'misiones') this.abrir('misiones');
      else if (b.accion === 'mapa') this.abrir('mapa');
      else if (b.accion === 'capitulos') this.abrir('capitulos');
      else if (b.accion === 'borrar') this.abrir('ranuras', { modo: 'borrar' });
      else if (b.accion === 'cargar') this.abrir('ranuras', { modo: 'cargar' });
      else if (b.accion === 'guardar') this.abrir('ranuras', { modo: 'guardar' });
      else this.alAccion(b.accion, b, origen);
    }

    efecto(cual) {
      const id = this.proyecto.menus.tema[cual];
      if (id && F.Audio) F.Audio.efecto(id);
    }

    /* ---------- Cada pantalla ---------- */
    p_portada() {
      const mp = this.proyecto.menus.principal;
      this.cabecera(mp.titulo || this.proyecto.nombre, mp.subtitulo, mp.logo);
      const t = document.createElement('div');
      t.className = 'fm-pulsar';
      t.textContent = mp.textoPulsar || 'PULSA CUALQUIER TECLA';
      this.raiz.appendChild(t);
    }

    p_principal() {
      const mp = this.proyecto.menus.principal;
      this.cabecera(mp.titulo || this.proyecto.nombre, mp.subtitulo, mp.logo);
      this.botonesDe('principal');
    }

    // Game Over: Reintentar · Cargar partida (si hay) · Menú principal
    p_gameover(d = {}) {
      const g = this.proyecto.menus.gameover || {};
      this.cabecera(g.titulo || 'HAS MUERTO', g.subtitulo || '');
      if (d.checkpoint) this.item(this.lista(), { texto: 'Continuar desde el punto de control', activar: (origen) => { this.efecto('sonidoAceptar'); this.alAccion('checkpoint', null, origen); } });
      this.botonesDe('gameover');
    }

    /* 🗺 Misiones: un nivel por fila con sus mejores estrellas (★★☆). Bloqueados (🔒) hasta acabar el anterior si así se
       eligió. El progreso es del navegador (localStorage): estrellas y niveles acabados. */
    /* 📚 Capítulos (episodios de Doom / Quake): los niveles con el mismo "capítulo" (📚 en el editor), en el orden de la
       lista. Elegir uno empieza partida nueva en su primer nivel. Bloqueado hasta haber llegado a él (salvo el primero)
       si menus.capitulos.bloquear (de serie sí). */
    // ¿todo abierto para probar? (solo en el editor: el juego exportado sigue bloqueando)
    _todoAbierto() { return this.enEditor && !!(this.proyecto.menus.misiones || {}).desbloquearTodo; }
    _capitulos() {
      const caps = [];
      for (const esc of this.proyecto.escenas) {
        if (!esc.capitulo) continue;
        let c = caps.find((x) => x.nombre === esc.capitulo);
        if (!c) caps.push(c = { nombre: esc.capitulo, escenas: [] });
        c.escenas.push(esc);
      }
      return caps;
    }
    _progreso() {
      const P = this.proyecto, k = P.id || P.nombre, r = { vistos: {}, llegados: {}, hechos: {} };
      try {
        r.vistos = JSON.parse(localStorage.getItem('forja-capitulos-' + k) || '{}');
        r.llegados = JSON.parse(localStorage.getItem('forja-niveles-' + k) || '{}');
        r.hechos = JSON.parse(localStorage.getItem('forja-hechos-' + k) || '{}');
      } catch (e) { /* nada */ }
      return r;
    }
    p_capitulos() {
      const v = this.proyecto.menus.capitulos || {};
      this.cabecera(v.titulo || 'CAPÍTULOS');
      const caps = this._capitulos(), pr = this._progreso(), abierto = v.bloquear === false || this._todoAbierto();
      const l = this.lista();
      if (!caps.length) this.item(l, { texto: '(ningún nivel tiene capítulo: ponlo con 📚 en el editor)', apagado: true });
      caps.forEach((c, i) => {
        const bloq = !abierto && i > 0 && !pr.vistos[c.nombre] && !c.escenas.some((e) => pr.llegados[e.id]);
        this.item(l, { texto: bloq ? `🔒 ${c.nombre}` : (v.verCuantos === false ? c.nombre : `${c.nombre}   (${c.escenas.length} nivel${c.escenas.length === 1 ? '' : 'es'})`), apagado: bloq,
          activar: () => { this.efecto('sonidoAceptar'); this.abrir('capitulo', { nombre: c.nombre }); } });
      });
      this.item(l, { texto: 'Volver', separado: true, activar: () => this.atras() });
    }
    /* Niveles de un capítulo: el primero abierto; cada uno se abre al acabar el anterior (llegar al siguiente por su
       salida, o completar su misión). */
    p_capitulo() {
      const v = this.proyecto.menus.capitulos || {}, nom = (this.actual && this.actual.datos.nombre) || '';
      const c = this._capitulos().find((x) => x.nombre === nom);
      this.cabecera(nom || 'CAPÍTULO');
      const pr = this._progreso(), abierto = v.bloquear === false || this._todoAbierto();
      const l = this.lista();
      (c ? c.escenas : []).forEach((esc, i) => {
        const ant = i > 0 && c.escenas[i - 1];
        const bloq = !abierto && i > 0 && !pr.llegados[esc.id] && !pr.hechos[ant.id];
        const nombre = (esc.mision && esc.mision.activa && esc.mision.titulo) || esc.nombre;
        this.item(l, { texto: bloq ? `🔒 ${i + 1}. ${nombre}` : `${i + 1}. ${nombre}`, apagado: bloq,
          activar: (origen) => { this.efecto('sonidoAceptar'); this.alAccion('escena', { escena: esc.id }, origen); } });
      });
      this.item(l, { texto: 'Volver', separado: true, activar: () => this.atras() });
    }

    p_misiones() {
      const v = this.proyecto.menus.misiones || {}, P = this.proyecto;
      this.cabecera(v.titulo || 'MISIONES');
      const k = P.id || P.nombre;
      let est = {}, hechos = {};
      try { est = JSON.parse(localStorage.getItem('forja-estrellas-' + k) || '{}'); hechos = JSON.parse(localStorage.getItem('forja-hechos-' + k) || '{}'); } catch (e) { /* nada */ }
      const lista = P.escenas.filter((e) => v.soloConMision === false || (e.mision && e.mision.activa));
      const l = this.lista();
      if (!lista.length) this.item(l, { texto: '(ningún nivel tiene misión)', apagado: true });
      lista.forEach((esc, i) => {
        const n = est[esc.id] || 0, bloq = v.bloquear !== false && !this._todoAbierto() && i > 0 && !hechos[lista[i - 1].id];
        const nombre = (esc.mision && esc.mision.titulo) || esc.nombre;
        this.item(l, { texto: bloq ? `🔒 ${i + 1}. ${nombre}` : `${i + 1}. ${nombre}   ${'★'.repeat(n)}${'☆'.repeat(3 - n)}`, apagado: bloq,
          activar: (origen) => { this.efecto('sonidoAceptar'); this.alAccion('escena', { escena: esc.id }, origen); } });
      });
      const borrar = { texto: 'Borrar progreso', separado: true, activar: () => {
        if (!this._seguroBorrar) { this._seguroBorrar = true; borrar.el.textContent = '¿Seguro? Otra vez para borrar'; return; }
        this._seguroBorrar = false;
        try { for (const pre of ['forja-estrellas-', 'forja-hechos-', 'forja-niveles-', 'forja-capitulos-']) localStorage.removeItem(pre + k); } catch (e) { /* nada */ }
        this.pintar();
      } };
      this.item(l, borrar);
      this.item(l, { texto: 'Volver', activar: () => this.atras() });
    }

    // 🏆 Juego completado: tiempo total, rango (por tiempo, estilo Resident Evil) y estrellas de las misiones
    p_victoria() {
      const v = this.proyecto.menus.victoria || {}, d = (this.actual && this.actual.datos) || {};
      this.cabecera(v.titulo || 'JUEGO COMPLETADO', v.subtitulo || '');
      const t = Math.floor(d.tiempo || 0), hh = Math.floor(t / 3600), mm = Math.floor((t % 3600) / 60), ss = t % 60;
      const reloj = (hh ? hh + ':' + String(mm).padStart(2, '0') : mm) + ':' + String(ss).padStart(2, '0');
      const filas = [];
      if (v.tiempo !== false) filas.push(['TIEMPO', reloj]);
      if (v.estrellas !== false && d.estrellas && d.estrellas.max) filas.push(['ESTRELLAS', d.estrellas.n + ' / ' + d.estrellas.max + ' ★']);
      if (v.rango !== false) filas.push(['RANGO', Menus.rango(v, t)]);
      if (filas.length) {
        const caja = document.createElement('div');
        caja.className = 'fm-sub';
        caja.style.cssText = 'display:grid;grid-template-columns:auto auto;gap:6px 28px;justify-content:center;margin:10px 0 18px;font-size:1.1em';
        for (const [k, val] of filas) {
          const a = document.createElement('span'); a.textContent = k; a.style.opacity = '0.7';
          const b = document.createElement('b'); b.textContent = val;
          if (k === 'RANGO') { b.style.fontSize = '2.2em'; b.style.color = 'var(--fn-sel, #e8a33d)'; b.style.lineHeight = '1'; }
          caja.append(a, b);
        }
        this.raiz.appendChild(caja);
      }
      this.botonesDe('victoria');
    }

    // Esconde el menú un momento (acomodar botones táctiles) y luego vuelve igual que estaba
    esconderUnMomento() { this.raiz.style.display = 'none'; }
    volverAMostrar() { this.raiz.style.display = 'flex'; this.bloqueoHasta = performance.now() + 250; this.pintar(); }

    p_pausa() {
      this.cabecera(this.proyecto.menus.pausa.titulo || 'PAUSA');
      this.botonesDe('pausa');
    }

    /* 🗺 Mapa: el nivel visto desde arriba (suelos rellenos y paredes en claro, sacados de la colisión), los 📌 marcadores
       de la brújula que estén visibles y el jugador como flecha. Se dibuja UNA vez al abrirlo (un lienzo 2D). */
    p_mapa() {
      this.cabecera('Mapa');
      const J = F.juegoActual, M = J && J.mundo;
      if (!M) { const n = document.createElement('div'); n.className = 'fm-sub'; n.textContent = 'El mapa se ve jugando (aquí no hay partida en marcha)'; this.raiz.appendChild(n); }
      const lado = Math.min(420, Math.round(Math.min(window.innerWidth, window.innerHeight) * 0.62));
      const cv = document.createElement('canvas');
      cv.width = cv.height = lado;
      cv.style.cssText = 'display:block;margin:6px auto;image-rendering:pixelated;border:2px solid rgba(255,255,255,.35);background:#0c0f14';
      this.raiz.appendChild(cv);
      if (M && M.t) {
        const t = M.t, nor = M.nor, n = nor.length / 3;
        const pj = J.jugador && J.jugador.cuerpo.pie;
        // límites del nivel (solo lo que está cerca de la altura del jugador: no se pinta el techo ni otros pisos)
        let x0 = 1e9, x1 = -1e9, z0 = 1e9, z1 = -1e9;
        const yJ = pj ? pj.y : 0, cerca = (y) => y > yJ - 4 && y < yJ + 3;
        for (let i = 0; i < n * 3; i++) {
          const o = i * 3;
          if (!cerca(t[o + 1])) continue;
          x0 = Math.min(x0, t[o]); x1 = Math.max(x1, t[o]); z0 = Math.min(z0, t[o + 2]); z1 = Math.max(z1, t[o + 2]);
        }
        if (x1 > x0) {
          const esc = (lado - 20) / Math.max(x1 - x0, z1 - z0), ox = 10 - x0 * esc, oz = 10 - z0 * esc;
          const g = cv.getContext('2d');
          const tri = (k, color) => {
            const o = k * 9;
            g.fillStyle = color; g.beginPath();
            g.moveTo(t[o] * esc + ox, t[o + 2] * esc + oz); g.lineTo(t[o + 3] * esc + ox, t[o + 5] * esc + oz); g.lineTo(t[o + 6] * esc + ox, t[o + 8] * esc + oz);
            g.closePath(); g.fill();
          };
          // suelos (miran arriba) y luego paredes (verticales) por encima, como líneas gruesas
          for (let k = 0; k < n; k++) if (nor[k * 3 + 1] > 0.6 && cerca(t[k * 9 + 1])) tri(k, '#2c3a4a');
          g.strokeStyle = '#9fb3c8'; g.lineWidth = 2;
          for (let k = 0; k < n; k++) {
            if (Math.abs(nor[k * 3 + 1]) > 0.3) continue;
            const o = k * 9;
            if (!cerca(t[o + 1]) && !cerca(t[o + 4])) continue;
            g.beginPath(); g.moveTo(t[o] * esc + ox, t[o + 2] * esc + oz); g.lineTo(t[o + 3] * esc + ox, t[o + 5] * esc + oz); g.lineTo(t[o + 6] * esc + ox, t[o + 8] * esc + oz); g.stroke();
          }
          // marcadores visibles de la brújula
          g.textAlign = 'center'; g.textBaseline = 'middle'; g.font = '16px sans-serif';
          for (const m of (J.brujula && J.brujula.marcadores) || []) {
            if (!m.visible) continue;
            const x = m.pos.x * esc + ox, y = m.pos.z * esc + oz;
            g.fillStyle = m.c.color || '#ffd23a'; g.fillText(m.c.icono || '◆', x, y);
            if (m.c.texto) { g.font = '10px monospace'; g.fillText(m.c.texto, x, y + 13); g.font = '16px sans-serif'; }
          }
          // el jugador: flecha hacia donde mira
          if (pj) {
            const x = pj.x * esc + ox, y = pj.z * esc + oz, a = J.jugador.yaw || 0;
            g.save(); g.translate(x, y); g.rotate(-a);
            g.fillStyle = '#ff5a3a'; g.beginPath(); g.moveTo(0, -9); g.lineTo(6, 7); g.lineTo(0, 3); g.lineTo(-6, 7); g.closePath(); g.fill();
            g.restore();
          }
        }
      }
      const l = this.lista();
      this.item(l, { texto: 'Volver', activar: () => this.atras() });
    }

    p_opciones() {
      this.cabecera('Opciones');
      const o = this.proyecto.menus.opciones;
      const l = this.lista();
      const grupos = F.Opciones.ESQUEMA.filter((d) => d.grupo && o[d.grupo] !== false);
      for (const g of grupos) this.item(l, { texto: g.e, activar: () => this.abrir('grupo', { grupo: g.grupo, titulo: g.e }) });
      if (o.mapeo !== false) this.item(l, { texto: 'Asignar controles', activar: () => this.abrir('mapeo') });
      this.item(l, { texto: 'Volver', separado: true, activar: () => this.atras() });
    }

    p_grupo({ grupo, titulo }) {
      this.cabecera(titulo);
      const l = this.lista();
      let dentro = false;
      const op = this.opciones;
      for (const d of F.Opciones.ESQUEMA) {
        if (d.grupo) { dentro = d.grupo === grupo; continue; }
        if (!dentro) continue;
        const cambiar = (v) => {
          op.poner(d.k, v);
          this.efecto('sonidoMover');
          this.alAccion('opciones-cambiaron');
        };
        let it;
        if (d.t === 'bool') {
          it = { valor: () => (op.valores[d.k] ? 'Sí' : 'No'), izq: () => cambiar(!op.valores[d.k]), der: () => cambiar(!op.valores[d.k]) };
          it.activar = () => { it.der(); it.refrescar(); };
        } else if (d.t === 'sel') {
          const paso = (s) => {
            let i = d.op.findIndex(([v]) => String(v) === String(op.valores[d.k]));
            i = (i + s + d.op.length) % d.op.length;
            cambiar(d.op[i][0]);
          };
          it = { valor: () => (d.op.find(([v]) => String(v) === String(op.valores[d.k])) || ['', '?'])[1], izq: () => paso(-1), der: () => paso(1) };
          it.activar = () => { it.der(); it.refrescar(); };
        } else {
          const paso = (s) => cambiar(+F.util.clamp((op.valores[d.k] ?? 0) + s * d.paso, d.min, d.max).toFixed(2));
          const barra = () => {
            const n = Math.round(((op.valores[d.k] - d.min) / (d.max - d.min)) * 10);
            return '■'.repeat(n) + '□'.repeat(10 - n);
          };
          it = { valor: barra, izq: () => paso(-1), der: () => paso(1), activar: () => {} };
        }
        it.texto = d.e;
        this.item(l, it);
      }
      if (grupo === 'tactil') {
        this.item(l, { texto: 'Mover botones en pantalla', separado: true, activar: () => this.alAccion('tactil-acomodar') });
      }
      this.item(l, {
        texto: 'Restablecer', separado: grupo !== 'tactil',
        activar: () => { op.restablecerGrupo(grupo); this.alAccion('opciones-cambiaron'); this.aviso('Valores de fábrica'); this.pintar(); },
      });
      this.item(l, { texto: 'Volver', activar: () => this.atras() });
    }

    p_mapeo() {
      this.cabecera('Asignar controles');
      const cab = document.createElement('div');
      cab.className = 'fm-cab';
      cab.innerHTML = '<span>Acción</span><span class="fm-celda">Teclado / ratón</span><span class="fm-celda">Mando</span>';
      this.raiz.appendChild(cab);
      const l = this.lista();
      l.classList.add('fm-mapeo');
      const E = F.Entrada;
      for (const accion of Object.keys(E.ETIQUETAS)) {
        const el = document.createElement('div');
        const it = { texto: E.ETIQUETAS[accion] };
        it.el = el;
        el.className = 'fm-item fm-map';
        const et = document.createElement('span');
        et.textContent = it.texto;
        const c0 = document.createElement('span');
        const c1 = document.createElement('span');
        c0.className = c1.className = 'fm-celda';
        const cap = this.capturando;
        c0.textContent = cap && cap.accion === accion && cap.tipo === 'teclado' ? 'Pulsa…' : E.textoTeclado(accion);
        c1.textContent = cap && cap.accion === accion && cap.tipo === 'mando' ? 'Pulsa…' : E.textoMando(accion);
        el.append(et, c0, c1);
        it.celdas = [c0, c1];
        const i = this.items.length;
        it.izq = () => { this.columna = 0; };
        it.der = () => { this.columna = 1; };
        it.activar = () => this.empezarCaptura(accion, this.columna === 0 ? 'teclado' : 'mando');
        el.onmouseenter = () => { if (this.indice !== i) { this.indice = i; this.marcar(); } };
        c0.onclick = (e) => { e.stopPropagation(); this.indice = i; this.columna = 0; this.origen = 'raton'; it.activar(); };
        c1.onclick = (e) => { e.stopPropagation(); this.indice = i; this.columna = 1; this.origen = 'raton'; it.activar(); };
        l.appendChild(el);
        this.items.push(it);
      }
      this.item(l, {
        texto: 'Restablecer controles', separado: true,
        activar: () => { this.opciones.restablecerControles(); this.aviso('Controles de fábrica'); this.pintar(); },
      });
      this.item(l, { texto: 'Volver', activar: () => this.atras() });
    }

    empezarCaptura(accion, tipo) {
      this.capturando = { accion, tipo, desde: performance.now() };
      this.mandoPrevio = this.botonesMando();   // lo que ya está pulsado no cuenta
      this.pintar();
    }

    terminarCaptura(entrada) {
      const c = this.capturando;
      this.capturando = null;
      if (entrada) {
        this.opciones.asignar(c.accion, c.tipo, entrada);
        this.efecto('sonidoAceptar');
      }
      this.bloqueoHasta = performance.now() + 200;
      this.pintar();
    }

    p_ranuras({ modo }) {
      this.cabecera(modo === 'guardar' ? 'Guardar partida' : modo === 'borrar' ? 'Borrar partida' : 'Cargar partida');
      const l = this.lista();
      // 💾 autoguardado (solo para cargar)
      const au = F.Partidas.leer(this.proyecto, F.Partidas.AUTO);
      if (modo === 'cargar' && au) this.item(l, { texto: `AUTOGUARDADO · ${au.nombreEscena || au.escena}`, activar: (origen) => this.alAccion('cargar-ranura', { ranura: F.Partidas.AUTO }, origen) });
      F.Partidas.lista(this.proyecto).forEach((p, i) => {
        const it = this.item(l, {
          texto: '',
          apagado: (modo === 'cargar' || modo === 'borrar') && !p,
          activar: (origen) => {
            if (modo === 'cargar') { this.alAccion('cargar-ranura', { ranura: i }, origen); return; }
            if (modo === 'borrar') {
              this.abrir('confirmar', { texto: `¿Borrar la partida de la ranura ${i + 1}? No se puede deshacer.`,
                si: () => { F.Partidas.borrar(this.proyecto, i); this.pila.pop(); this.aviso && this.aviso('Partida borrada'); this.pintar(); } });
              return;
            }
            if (p) {
              this.abrir('confirmar', {
                texto: `¿Sobrescribir la ranura ${i + 1}?`,
                si: () => { this.pila.pop(); this.alAccion('guardar-ranura', { ranura: i }, origen); },
              });
            } else {
              this.alAccion('guardar-ranura', { ranura: i }, origen);
            }
          },
        });
        it.el.textContent = `Ranura ${i + 1} — ${p ? p.nombreEscena || 'Partida' : 'vacía'}`;
        if (p) {
          const info = document.createElement('span');
          info.className = 'fm-ranura-info';
          info.textContent = `${fmtFecha(p.fecha)} · ${fmtTiempo(p.tiempo)} jugados`;
          it.el.appendChild(info);
        }
      });
      this.item(l, { texto: 'Volver', separado: true, activar: () => this.atras() });
    }

    p_confirmar({ texto, si }) {
      this.cabecera(texto);
      const l = this.lista();
      this.item(l, { texto: 'No', activar: () => this.atras() });
      this.item(l, { texto: 'Sí', activar: () => si() });
    }

    /* ---------- Navegación ---------- */
    mover(dir, silencio = false) {
      const n = this.items.length;
      if (!n) return;
      for (let k = 0; k < n; k++) {
        this.indice = (this.indice + dir + n) % n;
        if (!this.items[this.indice].apagado) break;
      }
      if (!silencio) this.efecto('sonidoMover');
      this.marcar();
    }

    lado(dir) {
      const it = this.items[this.indice];
      if (!it) return;
      if (dir < 0 && it.izq) it.izq();
      if (dir > 0 && it.der) it.der();
      if (it.refrescar) it.refrescar();
      this.marcar();
    }

    activar() {
      const it = this.items[this.indice];
      if (!it || it.apagado || !it.activar) return;
      it.activar(this.origen || 'teclado');
      if (it.refrescar) it.refrescar();
    }

    alTecla(e) {
      if (!this.visible) return;
      if (this.capturando) {
        e.preventDefault();
        e.stopPropagation();
        if (e.code === 'Escape') { this.terminarCaptura(null); return; }
        if (this.capturando.tipo === 'teclado') this.terminarCaptura({ tecla: e.code });
        return;
      }
      const usadas = ['ArrowUp', 'ArrowDown', 'ArrowLeft', 'ArrowRight', 'KeyW', 'KeyS', 'KeyA', 'KeyD', 'Enter', 'Space', 'Escape', 'Backspace', 'NumpadEnter'];
      if (!usadas.includes(e.code)) {
        if (this.actual && this.actual.tipo === 'portada' && performance.now() >= this.bloqueoHasta) this.alAccion('portada', null, 'teclado');
        return;
      }
      e.preventDefault();
      e.stopPropagation();
      if (performance.now() < this.bloqueoHasta || e.repeat && ['Enter', 'Space', 'Escape'].includes(e.code)) return;
      this.origen = 'teclado';
      if (this.actual && this.actual.tipo === 'portada') { this.alAccion('portada', null, 'teclado'); return; }
      if (e.code === 'ArrowUp' || e.code === 'KeyW') this.mover(-1);
      else if (e.code === 'ArrowDown' || e.code === 'KeyS') this.mover(1);
      else if (e.code === 'ArrowLeft' || e.code === 'KeyA') this.lado(-1);
      else if (e.code === 'ArrowRight' || e.code === 'KeyD') this.lado(1);
      else if (e.code === 'Enter' || e.code === 'Space' || e.code === 'NumpadEnter') this.activar();
      else this.atras();
    }

    alRaton(e) {
      if (this.capturando && this.capturando.tipo === 'teclado' && performance.now() - this.capturando.desde > 150) {
        e.preventDefault();
        e.stopPropagation();
        this.terminarCaptura({ raton: e.button });
        return;
      }
      if (this.actual && this.actual.tipo === 'portada' && performance.now() >= this.bloqueoHasta) this.alAccion('portada', null, 'raton');
    }

    botonesMando() {
      const gp = F.Entrada.leerMando();
      return gp ? gp.buttons.map((b) => b && b.pressed) : [];
    }

    // Se llama cada cuadro: mando (cruceta / stick con repetición, A aceptar, B volver)
    actualizar(dt) {
      if (!this.visible) return;
      const gp = F.Entrada.leerMando();
      if (!gp) return;
      const ahora = gp.buttons.map((b) => b && b.pressed);
      const nuevo = (i) => ahora[i] && !this.mandoPrevio[i];
      if (this.capturando) {
        if (this.capturando.tipo === 'mando') {
          const i = ahora.findIndex((v, j) => v && !this.mandoPrevio[j]);
          if (i >= 0) this.terminarCaptura({ boton: i });
        }
        this.mandoPrevio = ahora;
        return;
      }
      if (performance.now() < this.bloqueoHasta) { this.mandoPrevio = ahora; return; }
      this.origen = 'mando';
      if (this.actual && this.actual.tipo === 'portada') {
        if (ahora.some((v, j) => v && !this.mandoPrevio[j])) this.alAccion('portada', null, 'mando');
        this.mandoPrevio = ahora;
        return;
      }
      if (nuevo(0)) this.activar();
      else if (nuevo(1) || nuevo(9)) this.atras();
      // dirección: cruceta o stick, con repetición al mantener
      const ly = gp.axes[1] || 0, lx = gp.axes[0] || 0;
      const dir = ahora[12] || ly < -0.55 ? 'arriba' : ahora[13] || ly > 0.55 ? 'abajo'
        : ahora[14] || lx < -0.55 ? 'izq' : ahora[15] || lx > 0.55 ? 'der' : '';
      const r = this.repeticion;
      if (dir !== r.dir) { r.dir = dir; r.t = 0.38; if (dir) this.direccion(dir); }
      else if (dir) {
        r.t -= dt;
        if (r.t <= 0) { r.t = 0.11; this.direccion(dir); }
      }
      this.mandoPrevio = ahora;
    }

    direccion(d) {
      if (d === 'arriba') this.mover(-1);
      else if (d === 'abajo') this.mover(1);
      else if (d === 'izq') this.lado(-1);
      else this.lado(1);
    }
  }

  F.MenuJuego = MenuJuego;
  // rango por tiempo: "S:300, A:480, B:720" (minutos como máximo para cada letra, en orden); si no llega a ninguna, rangoPeor
  function rango(v, segundos) {
    const min = segundos / 60;
    for (const parte of String(v.rangos || '').split(',')) {
      const [letra, lim] = parte.split(':').map((x) => x.trim());
      if (letra && +lim > 0 && min <= +lim) return letra;
    }
    return v.rangoPeor || 'C';
  }
  const Menus = F.Menus = { ACCIONES, PLANTILLAS, rango };
  // 📚 capítulo alcanzado: al empezar un nivel con capítulo, queda desbloqueado en el menú de capítulos
  // y el nivel queda como "alcanzado" (abre ese nivel en la lista del capítulo)
  F.on('juego-iniciado', (J) => {
    const E = J && J.escena, P = J && J.proyecto;
    if (!E || !P || !E.capitulo) return;
    try {
      const id = P.id || P.nombre;
      const k = 'forja-capitulos-' + id, v = JSON.parse(localStorage.getItem(k) || '{}');
      if (!v[E.capitulo]) { v[E.capitulo] = true; localStorage.setItem(k, JSON.stringify(v)); }
      const kn = 'forja-niveles-' + id, n = JSON.parse(localStorage.getItem(kn) || '{}');
      if (E.id && !n[E.id]) { n[E.id] = true; localStorage.setItem(kn, JSON.stringify(n)); }
    } catch (e) { /* sin almacenamiento */ }
  });
})(window.FORJA);
