/* =========================================================
   FORJA · OPCIONES DEL JUGADOR Y PARTIDAS GUARDADAS
   Lo que el JUGADOR cambia en el menú Opciones (no el creador del juego):
   imagen (resolución, dither, filtro N64, temblor, FPS), sonido, sensibilidad y controles.
   Se guardan en el navegador del jugador, aparte para cada juego.
   Los valores de partida salen de los ajustes del proyecto: lo que el creador eligió.

   Partidas: 3 ranuras fijas por juego. Cada una guarda escena, posición, giro y tiempo jugado.
   ========================================================= */
(function (F) {
  'use strict';

  const RANURAS = 3;

  /* Esquema del menú Opciones. grupo = pestaña. desde = clave en proyecto.ajustes de donde sale el valor inicial.
     op de 'sel' igual que en los esquemas del editor. */
  const ESQUEMA_OPCIONES = [
    { grupo: 'video', e: 'Imagen' },
    { k: 'resolucion', t: 'sel', e: 'Resolución', desde: 'resolucion',
      op: [[240, '240p (PS1)'], [288, '288p'], [360, '360p'], [480, '480p'], [0, 'Nativa']] },
    { k: 'dither', t: 'bool', e: 'Dither', desde: 'dither' },
    { k: 'filtroN64', t: 'bool', e: 'Filtro N64', desde: 'filtroN64' },
    { k: 'snap', t: 'rango', e: 'Temblor', min: 0, max: 1, paso: 0.1, desde: 'snap' },
    { k: 'afin', t: 'rango', e: 'Deformación textura', min: 0, max: 1, paso: 0.1, desde: 'afin' },
    { k: 'limiteFps', t: 'sel', e: 'Límite de FPS', desde: 'limiteFps',
      op: [[0, 'Sin límite'], [30, '30'], [60, '60'], [120, '120'], [144, '144']] },
    { k: 'lucesExtra', t: 'bool', e: 'Luces y sombras', desde: 'lucesExtra' },
    { k: 'efectosPantalla', t: 'bool', e: 'Efectos de pantalla (VHS / CRT)', def: true },
    { k: 'reducirMovimiento', t: 'bool', e: 'Reducir movimiento de pantalla', def: false },
    { k: 'sombrasSol', t: 'sel', e: 'Calidad sombras', desde: 'sombrasSol',
      op: [[0, 'Sin sombras'], [512, 'Baja'], [1024, 'Media'], [2048, 'Alta']] },
    { grupo: 'audio', e: 'Sonido' },
    { k: 'volGeneral', t: 'rango', e: 'Volumen general', min: 0, max: 1, paso: 0.1, def: 1 },
    { k: 'volMusica', t: 'rango', e: 'Música', min: 0, max: 1, paso: 0.1, def: 0.8 },
    { k: 'volEfectos', t: 'rango', e: 'Efectos', min: 0, max: 1, paso: 0.1, def: 1 },
    { grupo: 'controles', e: 'Controles' },
    { k: 'sensRaton', t: 'rango', e: 'Sensibilidad ratón', min: 0.2, max: 3, paso: 0.1, def: 1 },
    { k: 'sensMando', t: 'rango', e: 'Sensibilidad mando', min: 0.2, max: 3, paso: 0.1, def: 1 },
    { k: 'invertirY', t: 'bool', e: 'Invertir vertical', def: false },
    { grupo: 'tactil', e: 'Controles táctiles' },
    { k: 'tactil', t: 'sel', e: 'Mostrar', desde: 'controlesTactiles',
      op: [['auto', 'Automático'], ['siempre', 'Siempre'], ['nunca', 'Nunca']] },
    { k: 'sensTactil', t: 'rango', e: 'Sensibilidad mirar', min: 0.2, max: 3, paso: 0.1, def: 1 },
    { k: 'tactilEscala', t: 'rango', e: 'Tamaño botones', min: 0.6, max: 1.6, paso: 0.1, def: 1 },
    { k: 'tactilOpacidad', t: 'rango', e: 'Transparencia', min: 0.2, max: 1, paso: 0.1, def: 0.9 },
  ];

  // El editor usa otro prefijo: probar los menús no toca las opciones ni partidas del juego exportado
  let prefijo = 'forja';
  const clave = (proyecto, que) => `${prefijo}:${F.util.slug(proyecto.nombre)}:${que}`;
  function leer(k) {
    try { return JSON.parse(localStorage.getItem(k) || 'null'); } catch (err) { return null; }
  }
  function escribir(k, v) {
    try { localStorage.setItem(k, JSON.stringify(v)); return true; } catch (err) { return false; }
  }

  // Valores "de fábrica" de este juego (los que eligió el creador en el proyecto)
  function deFabrica(proyecto) {
    const aj = proyecto.ajustes || {};
    const v = {};
    for (const d of ESQUEMA_OPCIONES) {
      if (!d.k) continue;
      v[d.k] = d.desde ? aj[d.desde] : d.def;
    }
    return v;
  }

  class Opciones {
    constructor(proyecto, { guardar = true } = {}) {
      this.proyecto = proyecto;
      this.guardar = guardar;         // en el editor (vista previa) también se guardan, aparte del juego exportado
      const guardado = guardar ? leer(clave(proyecto, 'opciones')) : null;
      this.valores = { ...deFabrica(proyecto), ...((guardado && guardado.valores) || {}) };
      this.controles = (guardado && guardado.controles) || {};   // solo lo que el jugador cambió
    }

    // Ajustes de render del proyecto con lo que eligió el jugador encima
    ajustes() {
      const ef = { ...this.proyecto.ajustes };
      for (const d of ESQUEMA_OPCIONES) if (d.desde) ef[d.desde] = this.valores[d.k];
      ef.fxJugadorApagado = this.valores.efectosPantalla === false;   // 📼 el jugador puede quitarlos
      ef.fxSinMovimiento = !!this.valores.reducirMovimiento;          // sin sacudidas, mareo, ondas ni temblor de cinta
      return ef;
    }

    // Aplica a la entrada y al audio (la imagen la aplica quien dibuja con ajustes())
    aplicar() {
      const v = this.valores;
      F.Entrada.multRaton = v.sensRaton ?? 1;
      F.Entrada.multMando = v.sensMando ?? 1;
      F.Entrada.invertirJugador = !!v.invertirY;
      F.Entrada.sensTactil = v.sensTactil ?? 1;
      if (F.Tactil) F.Tactil.preferencias({ escala: v.tactilEscala ?? 1, opacidad: v.tactilOpacidad ?? 0.9, pos: v.tactilPos || {} });
      if (F.Tactil) F.Tactil.modo = v.tactil || 'auto';
      F.Entrada.usarMapa(this.controles);
      F.Audio.volGeneral = v.volGeneral;
      F.Audio.volMusica = v.volMusica;
      F.Audio.volEfectos = v.volEfectos;
      F.Audio.aplicarVolumen();
    }

    poner(k, v) {
      this.valores[k] = v;
      this.salvar();
    }

    // Controles: cambiar lo que activa una acción. tipo 'teclado' (tecla o botón del ratón) o 'mando'
    asignar(accion, tipo, entrada) {
      const base = F.Entrada.mapaBase()[accion];
      if (!base) return;
      const actual = { ...base, ...(this.controles[accion] || {}) };
      if (tipo === 'mando') {
        actual.botones = [entrada.boton];
      } else if (entrada.raton !== undefined) {
        actual.teclas = [];
        actual.raton = [entrada.raton];
      } else {
        actual.teclas = [entrada.tecla];
        actual.raton = [];
      }
      // Quitar esa misma tecla / botón de otras acciones (no se pueden pisar dos acciones)
      const mapa = F.Entrada.mapaBase();
      for (const [k, m] of Object.entries(mapa)) {
        if (k === accion) continue;
        const otro = { ...m, ...(this.controles[k] || {}) };
        let cambio = false;
        if (tipo === 'mando' && (otro.botones || []).includes(entrada.boton)) { otro.botones = otro.botones.filter((b) => b !== entrada.boton); cambio = true; }
        if (tipo !== 'mando' && entrada.tecla && (otro.teclas || []).includes(entrada.tecla)) { otro.teclas = otro.teclas.filter((t) => t !== entrada.tecla); cambio = true; }
        if (tipo !== 'mando' && entrada.raton !== undefined && (otro.raton || []).includes(entrada.raton)) { otro.raton = otro.raton.filter((b) => b !== entrada.raton); cambio = true; }
        if (cambio) this.controles[k] = { teclas: otro.teclas || [], raton: otro.raton || [], botones: otro.botones || [] };
      }
      this.controles[accion] = { teclas: actual.teclas || [], raton: actual.raton || [], botones: actual.botones || [] };
      this.aplicar();
      this.salvar();
    }

    restablecerControles() {
      this.controles = {};
      this.aplicar();
      this.salvar();
    }

    // Vuelve a lo de fábrica una pestaña ('video' | 'audio' | 'controles')
    restablecerGrupo(grupo) {
      const fab = deFabrica(this.proyecto);
      let actual = '';
      for (const d of ESQUEMA_OPCIONES) {
        if (d.grupo) { actual = d.grupo; continue; }
        if (actual === grupo) this.valores[d.k] = fab[d.k];
      }
      if (grupo === 'tactil') delete this.valores.tactilPos;   // los botones vuelven a su lugar
      this.aplicar();
      this.salvar();
    }

    salvar() {
      if (this.guardar) escribir(clave(this.proyecto, 'opciones'), { valores: this.valores, controles: this.controles });
    }
  }

  /* ---------- Partidas guardadas (3 ranuras fijas) ---------- */
  const Partidas = {
    RANURAS,
    AUTO: RANURAS,   // índice de la ranura de Autoguardado (después de las fijas)
    _todas(proyecto) {
      const l = leer(clave(proyecto, 'partidas'));
      const r = [];
      for (let i = 0; i <= RANURAS; i++) r.push((l && l[i]) || null);
      return r;
    },
    lista(proyecto) { return Partidas._todas(proyecto).slice(0, RANURAS); },
    leer(proyecto, i) { return Partidas._todas(proyecto)[i] || null; },
    guardar(proyecto, i, datos) {
      const l = Partidas._todas(proyecto);
      l[i] = { ...datos, fecha: Date.now() };
      return escribir(clave(proyecto, 'partidas'), l);
    },
    borrar(proyecto, i) {
      const l = Partidas._todas(proyecto);
      l[i] = null;
      escribir(clave(proyecto, 'partidas'), l);
    },
    // La más reciente (para "Continuar"), incluido el autoguardado
    ultima(proyecto) {
      let mejor = -1, fecha = 0;
      Partidas._todas(proyecto).forEach((p, i) => { if (p && p.fecha > fecha) { fecha = p.fecha; mejor = i; } });
      return mejor;
    },
    hay(proyecto) {
      return Partidas._todas(proyecto).some((p) => p);
    },
  };

  F.Opciones = Opciones;
  F.Opciones.ESQUEMA = ESQUEMA_OPCIONES;
  F.Opciones.deFabrica = deFabrica;
  F.Opciones.usarPrefijo = (p) => { prefijo = p; };
  F.Partidas = Partidas;
})(window.FORJA);
