/* =========================================================
   FORJA · SONIDOS COLOCADOS 🔊 (sonido 3D sencillo)
   Entidad 'sonido': un archivo de audio en un punto del nivel. Suena más fuerte cerca y por el lado en que está
   (izquierda / derecha según hacia dónde miras). Fuera de su radio no suena (ni gasta).
   - En bucle (un generador, una cascada, la lluvia de una ventana) o de vez en cuando (gotas, cuervos: cada X-Y s).
   - La acción "🔊 Encender / apagar sonido" lo controla desde disparadores y palancas.
   Se revisa 10 veces por segundo.
   ========================================================= */
(function (F) {
  'use strict';
  const T = THREE;
  const SONIDO = { asset: '', volumen: 1, cerca: 2, radio: 14, bucle: true, cadaMin: 4, cadaMax: 10, encendido: true };
  const ESQ_SONIDO = [
    { k: 'asset', t: 'asset', tipoAsset: 'audio', e: 'Sonido', vacio: '(elige uno)' },
    { k: 'volumen', t: 'rango', e: 'Volumen', min: 0, max: 2, paso: 0.05 },
    { k: 'cerca', t: 'num', e: 'A todo volumen hasta (m)', paso: 0.5, min: 0 },
    { k: 'radio', t: 'num', e: 'Se oye hasta (m)', paso: 1, min: 1, ayuda: 'El círculo del editor' },
    { k: 'bucle', t: 'bool', e: 'En bucle', ayuda: 'Si no: suena de vez en cuando (cada X-Y segundos)' },
    { k: 'cadaMin', t: 'num', e: 'Cada (s) mínimo', paso: 0.5, min: 0.2, si: (v) => !v.bucle },
    { k: 'cadaMax', t: 'num', e: 'Cada (s) máximo', paso: 0.5, min: 0.2, si: (v) => !v.bucle },
    { k: 'encendido', t: 'bool', e: 'Suena desde el principio', ayuda: 'Si no: lo enciende la acción "🔊 Encender sonido"' },
  ];

  function figura(ent) {
    const c = { ...SONIDO, ...(ent.sonido || {}) }, g = new T.Group();
    const m = new T.MeshBasicMaterial({ color: 0x7fd4ff, wireframe: true, fog: false });
    const caja = new T.Mesh(new T.BoxGeometry(0.25, 0.3, 0.25), m);
    const cono = new T.Mesh(new T.ConeGeometry(0.2, 0.25, 8, 1, true).rotateZ(-Math.PI / 2).translate(0.22, 0, 0), m);
    const pts = [];
    for (let i = 0; i <= 48; i++) { const a = i / 48 * Math.PI * 2; pts.push(new T.Vector3(Math.cos(a) * c.radio, 0, Math.sin(a) * c.radio)); }
    const aro = new T.Line(new T.BufferGeometry().setFromPoints(pts), new T.LineBasicMaterial({ color: 0x7fd4ff, transparent: true, opacity: 0.35, fog: false }));
    aro.position.y = -0.3;
    for (const o of [caja, cono, aro]) { o.userData.ayudaEditor = true; g.add(o); }
    return g;
  }

  class Gestor {
    constructor(juego) {
      this.juego = juego;
      this.lista = [];
      for (const ent of juego.escena.entidades) {
        if (ent.tipo !== 'sonido' || ent.visible === false) continue;
        const obj = juego.objetos.get(ent.id);
        const c = { ...SONIDO, ...(ent.sonido || {}) };
        if (!obj || !c.asset) continue;
        this.lista.push({ ent, c, pos: obj.getWorldPosition(new T.Vector3()), h: null, on: !!c.encendido, sonando: false, t: c.cadaMin + Math.random() * (c.cadaMax - c.cadaMin) });
      }
      this.reloj = 0;
      this._d = new T.Vector3(); this._r = new T.Vector3();
    }
    encender(id, si) { const s = this.lista.find((x) => x.ent.id === id); if (s) { s.on = si == null ? !s.on : si; if (!s.on && s.h) { s.h.parar(); s.sonando = false; } } }
    actualizar(dt) {
      if (!this.lista.length) return;
      for (const s of this.lista) if (!s.c.bucle) s.t -= dt;
      if ((this.reloj -= dt) > 0) return;
      this.reloj = 0.1;
      const cam = this.juego.camara;
      cam.getWorldDirection(this._d);
      const der = this._r.set(-this._d.z, 0, this._d.x).normalize();   // derecha de la cámara (horizontal)
      for (const s of this.lista) {
        const dx = s.pos.x - cam.position.x, dy = s.pos.y - cam.position.y, dz = s.pos.z - cam.position.z, d = Math.hypot(dx, dy, dz);
        const dentro = s.on && d < s.c.radio;
        if (!dentro) { if (s.sonando && s.h) { s.h.parar(); s.sonando = false; } continue; }
        if (!s.h) s.h = F.Audio.fuente(s.c.asset, s.c.bucle);
        if (!s.h) continue;
        const k = d <= s.c.cerca ? 1 : Math.max(0, 1 - (d - s.c.cerca) / Math.max(0.01, s.c.radio - s.c.cerca));
        const lado = d > 0.3 ? (dx * der.x + dz * der.z) / d * 0.85 : 0;
        s.h.poner(s.c.volumen * k * k, lado);
        if (s.c.bucle) { if (!s.sonando) { s.h.tocar(false); s.sonando = true; } }
        else if (s.t <= 0) { s.t = s.c.cadaMin + Math.random() * Math.max(0, s.c.cadaMax - s.c.cadaMin); s.h.tocar(true); }
      }
    }
    detener() { for (const s of this.lista) if (s.h) s.h.quitar(); this.lista = []; }
  }

  F.Sonidos = { SONIDO, ESQ_SONIDO, figura, Gestor };
})(window.FORJA);
