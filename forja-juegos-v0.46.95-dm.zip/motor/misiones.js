/* =========================================================
   FORJA · MISIONES Y ESTRELLAS ⭐ (estilo juego de móvil) + BRIEFING
   Cada nivel puede tener una misión (escena.mision): título, briefing (texto e imagen) y objetivos. Cada objetivo
   dice a qué estrella pertenece (1, 2 o 3). Estrellas ganadas = la más alta N tal que todos los objetivos de las
   estrellas 1..N están cumplidos (sin objetivos de la ★1, acabar el nivel ya la da).
   - Al empezar el nivel: pantalla de briefing (el mundo quieto hasta pulsar Empezar).
   - Mientras juegas: Tab muestra los objetivos (y salen solos un momento al cumplir uno); reloj si hay tiempo límite.
   - Al salir por una 🚪 salida (o con la acción "🏁 Terminar la misión"): pantalla de puntuación con las estrellas.
   La mejor marca de cada nivel se guarda en el navegador (localStorage).
   ========================================================= */
(function (F) {
  'use strict';

  const MISION = { activa: false, titulo: '', briefing: '', imagen: '', mostrarBriefing: true, mostrarPuntuacion: true, objetivos: [] };
  const TIPOS = [
    ['salir', '🚪 Llegar a la salida (acabar el nivel)'],
    ['matarTodos', '☠ Acabar con todos los enemigos'],
    ['matarJefe', '👑 Acabar con un enemigo concreto (jefe)'],
    ['tiempo', '⏱ Acabar en menos de… (tiempo)'],
    ['recoger', '✚ Recoger todos los… (llaves, objetos, vida…)'],
    ['tener', '🎒 Tener en la mochila (objeto y cantidad)'],
    ['leer', '📜 Leer todas las notas / carteles'],
    ['zona', '⬚ Llegar a un sitio (disparador)'],
    ['rescatar', '🧍 Rescatar a todos los rehenes'],
    ['sinAlerta', '🤫 Que no salte ninguna alarma (nadie te ve)'],
    ['ejecutar', '🗡 Ejecuciones silenciosas (cantidad)'],
    ['bombas', '💣 Desactivar todas las bombas'],
    ['canal', '📡 Al recibir un aviso de canal (bomba, palanca…)'],
  ];
  const NOMBRE_TIPO = Object.fromEntries(TIPOS);
  function objetivoNuevo(extra = {}) {
    return { id: 'o' + Math.random().toString(36).slice(2, 8), tipo: 'salir', estrella: 1, texto: '', a: '', segundos: 300, cantidad: 1, que: 'todos', canal: '', ...extra };
  }
  const reloj = (s) => { s = Math.max(0, Math.floor(s)); return Math.floor(s / 60) + ':' + String(s % 60).padStart(2, '0'); };

  let estilo = false;
  function ponerEstilo() {
    if (estilo) return;
    estilo = true;
    const st = document.createElement('style');
    st.textContent = `
.fmi-capa{position:absolute;inset:0;z-index:30;display:flex;align-items:center;justify-content:center;background:rgba(5,6,10,.82);
  font-family:var(--fn-fuente, ui-monospace, Consolas, monospace);color:#e8e2d0;opacity:0;transition:opacity .25s}
.fmi-capa.fmi-ver{opacity:1}
.fmi-caja{width:min(92vw,var(--fb-ancho,640px));max-height:88vh;overflow:auto;background:var(--fb-caja,#14161d);border:var(--fb-borde,2px solid #e8a33d);color:var(--fb-texto,inherit);padding:22px 26px;box-shadow:0 0 0 4px #000}
.fmi-caja h1{margin:0 0 4px;font-size:clamp(18px,3.4vmin,30px);letter-spacing:2px;text-transform:uppercase;color:var(--fb-titulo,#e8a33d)}
.fmi-sub{opacity:.7;font-size:12px;letter-spacing:2px;text-transform:uppercase;margin-bottom:12px}
.fmi-img{width:100%;max-height:30vh;object-fit:cover;margin:6px 0 12px;image-rendering:pixelated;border:1px solid #333}
.fmi-texto{white-space:pre-wrap;line-height:1.5;font-size:14px;margin:0 0 14px}
.fmi-obj{list-style:none;margin:0;padding:0;font-size:14px}
.fmi-obj li{display:flex;gap:10px;align-items:baseline;padding:5px 0;border-top:1px solid #262a33}
.fmi-obj .fmi-e{color:#e8c547;min-width:46px;letter-spacing:1px}
.fmi-obj .fmi-ok{color:#5fd38a}.fmi-obj .fmi-no{color:#e05a4a}
.fmi-obj .fmi-p{margin-left:auto;opacity:.7}
.fmi-estrellas{font-size:clamp(40px,10vmin,84px);text-align:center;letter-spacing:8px;margin:6px 0 2px}
.fmi-estrellas span{display:inline-block;color:#3a3d47;transform:scale(.6);transition:transform .35s cubic-bezier(.3,1.8,.5,1),color .2s}
.fmi-estrellas span.fmi-on{color:#ffd23f;transform:scale(1);text-shadow:0 0 18px rgba(255,210,63,.6)}
.fmi-datos{display:flex;justify-content:center;gap:22px;font-size:13px;opacity:.85;margin-bottom:12px}
.fmi-boton{display:block;margin:16px auto 0;padding:10px 26px;background:var(--fb-boton,#e8a33d);color:var(--fb-tboton,#14161d);border:0;font:inherit;font-weight:bold;letter-spacing:2px;text-transform:uppercase;cursor:pointer}
.fmi-pista{text-align:center;font-size:11px;opacity:.55;margin-top:6px}
.fmi-hud{position:absolute;left:12px;top:12px;z-index:6;pointer-events:none;font-family:var(--fh-fuente, ui-monospace, Consolas, monospace);
  font-size:.62em;color:var(--fh-texto,#e8e2d0);background:rgba(0,0,0,.55);padding:.6em .9em;max-width:min(30vw,16em);opacity:0;transition:opacity .3s}
.fmi-hud.fmi-ver{opacity:1}
.fmi-hud b{color:#e8a33d;letter-spacing:1px;text-transform:uppercase;font-size:.85em}
.fmi-hud div{padding:2px 0}.fmi-hud .fmi-ok{color:#5fd38a;text-decoration:line-through;opacity:.8}.fmi-hud .fmi-no{color:#e05a4a}
.fmi-reloj{position:absolute;top:12px;left:50%;transform:translateX(-50%);z-index:6;pointer-events:none;font-weight:bold;font-size:1em;
  color:var(--fh-texto,#e8e2d0);background:rgba(0,0,0,.55);padding:4px 12px}
.fmi-reloj.fmi-tarde{color:#e05a4a}`;
    document.head.appendChild(st);
  }

  class Misiones {
    constructor(juego) {
      this.juego = juego;
      const m = { ...MISION, ...((juego.escena && juego.escena.mision) || {}) };
      this.m = m;
      this.activa = !!(m.activa && (m.objetivos || []).length);
      this.t = 0;
      this.pantalla = null;      // 'briefing' | 'final' mientras se ve una (el mundo quieto)
      this.estado = {};          // id → { hecho, fallo }
      this.oyentes = [];
      if (!this.activa) return;
      Misiones.vivas.add(this);
      ponerEstilo();
      const J = juego;
      for (const o of m.objetivos) this.estado[o.id] = { hecho: false, fallo: false };
      this.ejecuciones = 0;
      this.leidos = new Set();
      this.oyentes = [
        F.on('enemigo-alerta', () => { for (const o of this._de('sinAlerta')) this._fallar(o); }),
        F.on('enemigo-ejecutado', () => { this.ejecuciones++; }),
        F.on('interactuar', ({ ent, juego: jj }) => { if (jj === J && ent && ent.interaccion && ent.interaccion.tipo === 'mensaje') this.leidos.add(ent.id); }),
        F.on('canal', ({ juego: jj, canal, on }) => { if (jj === J && on !== false) for (const o of this._de('canal')) if (o.canal && o.canal === canal) this._cumplir(o); }),
        F.on('rehen-rescatado', () => { this._revisar(true); }),
        F.on('rehen-muerto', ({ juego: jj }) => { if (jj === J) for (const o of this._de('rescatar')) this._fallar(o); }),
        F.on('bomba-explota', ({ juego: jj }) => { if (jj === J) for (const o of this._de('bombas')) this._fallar(o); }),
      ];
      // notas del nivel y zonas
      this.notas = juego.escena.entidades.filter((e) => e.interaccion && e.interaccion.tipo === 'mensaje').map((e) => e.id);
      this.zonas = {};
      for (const o of this._de('zona')) {
        const z = o.a && juego.objetos.get(o.a);
        if (z) { z.updateWorldMatrix(true, true); this.zonas[o.id] = new THREE.Box3().setFromObject(z); }
      }
      this._revisarCada = 0;
      this.hud = F.Hud.pieza(juego, 'fmi-hud');
      if (m.objetivos.some((o) => o.tipo === 'tiempo')) this.relojEl = F.Hud.pieza(juego, 'fmi-reloj');
      this.tHud = 0;
    }

    _de(tipo) { return this.m.objetivos.filter((o) => o.tipo === tipo); }
    _cumplir(o) { const e = this.estado[o.id]; if (!e || e.hecho || e.fallo) return; e.hecho = true; this._aviso(o); }
    _fallar(o) { const e = this.estado[o.id]; if (e && !e.fallo) { e.fallo = true; e.hecho = false; } }
    _aviso(o) { this.tHud = 3.5; this._pintarHud(); F.Audio.sintetico('recoger', { volumen: 0.6, tono: 1.5 }); }

    texto(o) {
      if (o.texto) return o.texto;
      const J = this.juego, ent = o.a && J.escena.entidades.find((e) => e.id === o.a);
      switch (o.tipo) {
        case 'salir': return ent ? 'Llega a ' + ent.nombre : 'Llega a la salida';
        case 'matarTodos': return 'Acaba con todos los enemigos';
        case 'matarJefe': return 'Acaba con ' + (ent ? ent.nombre : 'el jefe');
        case 'tiempo': return 'Termina en menos de ' + reloj(o.segundos);
        case 'recoger': return 'Recoge todos los ' + (o.que === 'todos' ? 'objetos' : o.que.indexOf('obj:') === 0 ? (((J.proyecto.objetos || []).find((x) => x.id === o.que.slice(4)) || {}).nombre || 'objetos') : o.que);
        case 'tener': return 'Consigue ' + (o.cantidad > 1 ? o.cantidad + ' × ' : '') + ((((J.proyecto.objetos || []).find((x) => x.id === o.a)) || {}).nombre || 'el objeto');
        case 'leer': return 'Lee todas las notas';
        case 'zona': return 'Llega a ' + (ent ? ent.nombre : 'la zona');
        case 'rescatar': return 'Rescata a todos los rehenes';
        case 'sinAlerta': return 'Que nadie dé la alarma';
        case 'ejecutar': return 'Ejecuta en silencio a ' + o.cantidad;
        case 'bombas': return 'Desactiva todas las bombas';
        case 'canal': return o.canal || 'Objetivo';
      }
      return 'Objetivo';
    }

    // progreso "3/5" (o '') y si está cumplido ahora mismo
    _medir(o) {
      const J = this.juego, EN = J.enemigos;
      switch (o.tipo) {
        case 'matarTodos': {
          const L = EN ? EN.lista.filter((E) => !E.reserva && E.c.actitud !== 'pacifico' && E.c.actitud !== 'aliado') : [];
          const m = L.filter((E) => E.muerto).length;
          return { ok: L.length > 0 && m === L.length, p: m + '/' + L.length };
        }
        case 'matarJefe': {
          const E = EN && EN.lista.find((x) => x.ent && x.ent.id === o.a);
          return { ok: !!(E ? E.muerto : EN && EN.muertos && EN.muertos.has(o.a)), p: '' };
        }
        case 'recoger': {
          const R = J.recogibles, L = J.escena.entidades.filter((e) => e.tipo === 'recogible' && e.recogible && (o.que === 'todos' ||
            (o.que.indexOf('obj:') === 0 ? e.recogible.tipo === 'objeto' && e.recogible.objeto === o.que.slice(4) : e.recogible.tipo === o.que)));
          const m = L.filter((e) => R && R.recogidos.has(e.id)).length;
          return { ok: L.length > 0 && m === L.length, p: m + '/' + L.length };
        }
        case 'tener': {
          const inv = J.jugador && J.jugador.inventario, n = inv ? inv.contar('objeto', o.a) : 0, k = Math.max(1, o.cantidad | 0);
          return { ok: n >= k, p: Math.min(n, k) + '/' + k };
        }
        case 'leer': { const m = this.notas.filter((id) => this.leidos.has(id)).length; return { ok: this.notas.length > 0 && m === this.notas.length, p: m + '/' + this.notas.length }; }
        case 'zona': {
          const z = this.zonas[o.id], j = J.jugador;
          return { ok: !!(z && j && z.containsPoint(j.cuerpo.pie.clone().setY(j.cuerpo.pie.y + 0.5))), p: '' };
        }
        case 'rescatar': {
          const H = J.rehenes, L = H ? H.lista : [], m = L.filter((h) => h.estado === 'rescatado').length;
          return { ok: L.length > 0 && m === L.length, p: m + '/' + L.length };
        }
        case 'bombas': { const L = J.tactico ? J.tactico.bombas : [], m = L.filter((b) => b.estado === 'desactivada').length; return { ok: L.length > 0 && m === L.length, p: m + '/' + L.length }; }
        case 'ejecutar': { const k = Math.max(1, o.cantidad | 0); return { ok: this.ejecuciones >= k, p: Math.min(this.ejecuciones, k) + '/' + k }; }
      }
      return { ok: false, p: '' };
    }

    _revisar(forzar) {
      for (const o of this.m.objetivos) {
        if (['salir', 'tiempo', 'sinAlerta', 'canal'].includes(o.tipo)) continue;
        if (this.estado[o.id].hecho) continue;
        if (this._medir(o).ok) this._cumplir(o);
      }
      if (forzar) this._pintarHud();
    }

    // ¿lo bloquea una pantalla? (Juego no mueve el mundo)
    get bloquea() { return !!this.pantalla; }

    empezar() {
      if (!this.activa) return;
      if (this.m.mostrarBriefing !== false) this.briefing();
      else { this.tHud = 4; this._pintarHud(); }
    }

    actualizar(dt) {
      if (!this.activa) return;
      if (this.pantalla) { this._teclasPantalla(); return; }
      this.t += dt;
      if ((this._revisarCada -= dt) <= 0) { this._revisarCada = 0.25; this._revisar(false); }
      for (const o of this._de('tiempo')) if (this.t > o.segundos) this._fallar(o);
      if (F.Entrada.pulsado('objetivos')) { this.fijo = !this.fijo; this._pintarHud(); }
      if (this.tHud > 0) { this.tHud -= dt; if (this.tHud <= 0) this._pintarHud(); }
      if ((this._hudCada = (this._hudCada || 0) - dt) <= 0) { this._hudCada = 0.5; if (this.fijo || this.tHud > 0) this._pintarHud(); }
      if (this.relojEl) {
        const lim = Math.min(...this._de('tiempo').map((o) => o.segundos));
        this.relojEl.textContent = '⏱ ' + reloj(this.t) + ' / ' + reloj(lim);
        this.relojEl.classList.toggle('fmi-tarde', this.t > lim);
      }
    }

    _pintarHud() {
      if (!this.hud) return;
      const ver = this.fijo || this.tHud > 0;
      this.hud.classList.toggle('fmi-ver', ver);
      if (!ver) return;
      const tecla = F.Entrada.textoTeclado ? F.Entrada.textoTeclado('objetivos').split(' / ')[0] : 'Tab';
      this.hud.innerHTML = `<b>${this.m.titulo || 'Objetivos'}</b>` + this.m.objetivos.map((o) => {
        const e = this.estado[o.id], md = this._medir(o);
        return `<div class="${e.hecho ? 'fmi-ok' : e.fallo ? 'fmi-no' : ''}">${'★'.repeat(o.estrella || 1)} ${this.texto(o)}${md.p && !e.hecho ? ' · ' + md.p : ''}</div>`;
      }).join('') + (this.fijo ? '' : `<div style="opacity:.5;font-size:11px">${tecla}: ver objetivos</div>`);
    }

    /* estrellas: cada una se gana sola con TODOS sus objetivos cumplidos (fallar la ★ no quita la ★★ ni la ★★★).
       Una estrella sin objetivos se gana al acabar el nivel. Devuelve cuántas; this.ganadas = [true/false ×3] */
    estrellas() {
      this.ganadas = [1, 2, 3].map((k) => this.m.objetivos.filter((o) => (o.estrella || 1) === k).every((o) => this.estado[o.id].hecho));
      return this.ganadas.filter(Boolean).length;
    }

    /* ---------- Pantallas ---------- */
    _capa(html) {
      const J = this.juego, c = document.createElement('div');
      c.className = 'fmi-capa';
      c.innerHTML = `<div class="fmi-caja">${html}</div>`;
      J.vista.contenedor.appendChild(c);
      requestAnimationFrame(() => c.classList.add('fmi-ver'));
      F.Entrada.silencioLiberar = true;
      F.Entrada.soltarBloqueo();
      F.Entrada.limpiar && F.Entrada.limpiar();
      this.capaEl = c;
      // las teclas se miran aquí mismo (durante un viaje el Juego no se actualiza): Enter / Espacio / E y botón A del mando
      const bucle = () => {
        if (!this.pantalla || this.capaEl !== c) return;
        const pads = navigator.getGamepads ? [...navigator.getGamepads()].filter(Boolean) : [];
        const a = pads.some((g) => g.buttons[0] && g.buttons[0].pressed);
        if (a && !this._padAntes) this._enter = true;
        this._padAntes = a;
        if (this._enter && performance.now() >= (this._listoTeclas || 0)) { this._enter = false; this._cerrar(); return; }
        requestAnimationFrame(bucle);
      };
      this._padAntes = true;
      requestAnimationFrame(bucle);
      return c;
    }

    _lista(final) {
      return '<ul class="fmi-obj">' + this.m.objetivos.slice().sort((a, b) => (a.estrella || 1) - (b.estrella || 1)).map((o) => {
        const e = this.estado[o.id], md = this._medir(o);
        const marca = !final ? '' : e.hecho ? '<span class="fmi-ok">✔</span>' : '<span class="fmi-no">✘</span>';
        return `<li><span class="fmi-e">${'★'.repeat(o.estrella || 1)}</span>${marca}<span>${this.texto(o)}</span><span class="fmi-p">${final && md.p ? md.p : ''}</span></li>`;
      }).join('') + '</ul>';
    }

    briefing() {
      const m = this.m, img = m.imagen && F.Assets && F.Assets.mapa.get(m.imagen);
      this.pantalla = 'briefing';
      const B = F.Misiones.estiloBriefing(this.juego.proyecto), esc = (t) => String(t).replace(/[&<>]/g, (x) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;' }[x]));
      const c = this._capa(`<div class="fmi-sub">${esc(B.textoSub)}</div><h1>${m.titulo || this.juego.escena.nombre}</h1>
        ${img && img.url ? `<img class="fmi-img" src="${img.url}">` : ''}
        ${m.briefing ? `<p class="fmi-texto"></p>` : ''}
        ${B.verObjetivos !== false ? `<div class="fmi-sub">${esc(B.textoObjetivos)}</div>${this._lista(false)}` : ''}
        <button class="fmi-boton">${esc(B.textoBoton)}</button>${B.verPista !== false ? '<div class="fmi-pista">Saltar / Usar / Enter</div>' : ''}`);
      const rgba = (h, o) => { h = (h || '#000000').replace('#', ''); return `rgba(${parseInt(h.slice(0, 2), 16)},${parseInt(h.slice(2, 4), 16)},${parseInt(h.slice(4, 6), 16)},${o})`; };
      const st = c.style;
      st.setProperty('--fb-ancho', B.ancho + 'px');
      st.setProperty('--fb-caja', rgba(B.colorCaja, B.opacidadCaja ?? 1));
      st.setProperty('--fb-borde', (B.grosorBorde || 0) + 'px solid ' + B.colorBorde);
      st.setProperty('--fb-titulo', B.colorTitulo); st.setProperty('--fb-texto', B.colorTexto);
      st.setProperty('--fb-boton', B.colorBoton); st.setProperty('--fb-tboton', B.colorTextoBoton);
      st.background = rgba(B.colorFondo, B.fondo === 'color' ? 1 : B.opacidadFondo);
      st.backdropFilter = st.webkitBackdropFilter = B.fondo !== 'color' && B.difuminado ? `blur(${B.difuminado}px)` : '';
      if (B.sonidoAbrir) F.Audio.efecto(B.sonidoAbrir);
      if (m.briefing) c.querySelector('.fmi-texto').textContent = m.briefing;
      c.querySelector('.fmi-boton').onclick = () => this._cerrar();
      this._listoTeclas = performance.now() + 400;
      return new Promise((ok) => { this._alCerrar = ok; });
    }

    // al salir del nivel (o con la acción 🏁): marca 'salir', cierra el tiempo y las estrellas
    final(ent) {
      if (!this.activa) return Promise.resolve(0);
      for (const o of this._de('salir')) if (!o.a || !ent || o.a === ent.id) this._cumplir(o);
      for (const o of this._de('tiempo')) { if (this.t <= o.segundos) this._cumplir(o); else this._fallar(o); }
      for (const o of this._de('sinAlerta')) this._cumplir(o);
      this._revisar(false);
      const n = this.estrellas();
      // mejor marca (en este navegador)
      let mejor = 0;
      try {
        const k = 'forja-estrellas-' + (this.juego.proyecto.id || this.juego.proyecto.nombre), d = JSON.parse(localStorage.getItem(k) || '{}');
        mejor = d[this.juego.escena.id] || 0;
        if (n > mejor) { d[this.juego.escena.id] = n; localStorage.setItem(k, JSON.stringify(d)); }
        // nivel acabado (para desbloquear el siguiente en el menú de misiones)
        const kh = 'forja-hechos-' + (this.juego.proyecto.id || this.juego.proyecto.nombre), h = JSON.parse(localStorage.getItem(kh) || '{}');
        if (!h[this.juego.escena.id]) { h[this.juego.escena.id] = true; localStorage.setItem(kh, JSON.stringify(h)); }
      } catch (e) { /* sin almacenamiento */ }
      F.emitir('mision-terminada', { juego: this.juego, estrellas: n });
      if (this.m.mostrarPuntuacion === false) return Promise.resolve(n);
      const EN = this.juego.enemigos, muertos = EN ? EN.lista.filter((E) => E.muerto && E.c.actitud !== 'aliado').length : 0;
      this.pantalla = 'final';
      const c = this._capa(`<div class="fmi-sub">Misión ${n > 0 ? 'cumplida' : 'terminada'}</div><h1>${this.m.titulo || this.juego.escena.nombre}</h1>
        <div class="fmi-estrellas"><span>★</span><span>★</span><span>★</span></div>
        <div class="fmi-datos"><span>⏱ ${reloj(this.t)}</span><span>☠ ${muertos}</span>${mejor ? `<span>Mejor: ${'★'.repeat(Math.max(mejor, n))}</span>` : ''}</div>
        ${this._lista(true)}<button class="fmi-boton">Continuar</button><div class="fmi-pista">Saltar / Usar / Enter</div>`);
      c.querySelector('.fmi-boton').onclick = () => this._cerrar();
      const est = c.querySelectorAll('.fmi-estrellas span');
      // se encienden de izquierda a derecha las que se ganaron (cada una es la de sus objetivos)
      let k = 0;
      this.ganadas.forEach((si, i) => { if (si) { const d = 450 + k++ * 380; setTimeout(() => { est[i].classList.add('fmi-on'); F.Audio.sintetico('recoger', { volumen: 0.7, tono: 1.2 + i * 0.25 }); }, d); } });
      this._listoTeclas = performance.now() + 450 + n * 380;
      return new Promise((ok) => { this._alCerrar = () => ok(n); });
    }

    _teclasPantalla() {
      F.Entrada.actualizar && 0;
      if (performance.now() < (this._listoTeclas || 0)) return;
      const E = F.Entrada;
      // las teclas cierran desde su propio keydown (un gesto del usuario: así el navegador deja volver a bloquear el ratón)
    }

    _cerrar() {
      if (!this.pantalla) return;
      const era = this.pantalla;
      this.pantalla = null;
      const c = this.capaEl;
      if (c) { c.classList.remove('fmi-ver'); setTimeout(() => c.remove(), 260); }
      F.Entrada.limpiar && F.Entrada.limpiar();
      if (!F.Entrada.tactil) F.Entrada.pedirBloqueo();
      if (era === 'briefing') { this.tHud = 4; this._pintarHud(); }
      const fn = this._alCerrar; this._alCerrar = null;
      if (fn) fn();
    }

    detener() {
      Misiones.vivas.delete(this);
      for (const q of this.oyentes) q();
      this.oyentes = [];
      if (this.capaEl) this.capaEl.remove();
      this.pantalla = null;
    }
  }

  // Enter también cierra las pantallas (no es una acción del juego)
  addEventListener('keydown', (e) => { if (/^(Enter|NumpadEnter|Space|KeyE)$/.test(e.code)) for (const m of [...Misiones.vivas]) if (m.pantalla && performance.now() >= (m._listoTeclas || 0)) { e.preventDefault(); m._cerrar(); } });
  Misiones.vivas = new Set();

  Misiones.estiloBriefing = (proyecto) => ({ ...F.Escena.menusPorDefecto().briefing, ...((proyecto.menus && proyecto.menus.briefing) || {}) });
  Misiones.MISION = MISION;
  Misiones.TIPOS = TIPOS;
  Misiones.NOMBRE_TIPO = NOMBRE_TIPO;
  Misiones.objetivoNuevo = objetivoNuevo;
  F.Misiones = Misiones;
  Misiones.ponerEstilo = ponerEstilo;
})(window.FORJA);
