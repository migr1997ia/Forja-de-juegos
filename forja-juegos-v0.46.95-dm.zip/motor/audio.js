/* =========================================================
   FORJA · AUDIO
   Por ahora: música (una pista a la vez, en bucle) y sonidos sueltos de los menús.
   Volúmenes: general × música / general × efectos (los cambia el jugador en Opciones).
     FORJA.Audio.musica(idAsset)   ·   FORJA.Audio.pararMusica()   ·   FORJA.Audio.efecto(idAsset)
   El navegador no deja sonar nada hasta que el jugador hace clic o pulsa una tecla:
   por eso el juego empieza con "Pulsa cualquier tecla".
   ========================================================= */
(function (F) {
  'use strict';

  const A = {
    volGeneral: 1,
    volMusica: 0.8,
    volEfectos: 1,
  };

  let pista = null;        // HTMLAudioElement de la música
  let idPista = '';
  let cfgPista = { volumen: 1, inicio: 0, fin: 0 };
  let ganancia = 1, metaGan = 1, velGan = 0;   // fundido de entrada / salida (0..1)
  const saliendo = [];      // pistas viejas apagándose (fundido cruzado)
  let reloj = 0;

  /* 🎵 Música en bucle. op: { volumen (0..1, de esta pista), inicio (s: desde dónde vuelve el bucle),
     fin (s: dónde termina el bucle; 0 = al final del archivo), fundido (s: entrar / cruzarse con la anterior) }.
     La primera vez suena desde el principio (la intro) y después repite de "inicio" a "fin". */
  A.musica = function (idAsset, op = {}) {
    const fundido = Math.max(0, op.fundido || 0);
    if (!idAsset) { A.pararMusica(fundido); return; }
    const cfg = { volumen: op.volumen ?? 1, inicio: Math.max(0, op.inicio || 0), fin: Math.max(0, op.fin || 0) };
    if (idPista === idAsset && pista) {
      cfgPista = cfg;   // misma pista: solo cambian volumen y bucle (no vuelve a empezar)
      metaGan = 1; velGan = fundido > 0 ? 1 / fundido : 99;
      if (pista.paused) pista.play().catch(() => {});
      A.aplicarVolumen(); vigilar();
      return;
    }
    const a = F.Assets && F.Assets.mapa.get(idAsset);
    if (pista) {
      // la anterior se apaga poco a poco (o de golpe sin fundido)
      if (fundido > 0) saliendo.push({ el: pista, gan: ganancia, vol: cfgPista.volumen, vel: 1 / fundido });
      else { pista.pause(); pista.src = ''; }
    }
    pista = null; idPista = '';
    if (!a || !a.url) { vigilar(); return; }
    pista = new Audio(a.url);
    pista.loop = !(cfg.inicio > 0 || cfg.fin > 0);   // con bucle propio lo lleva vigilar()
    idPista = idAsset; cfgPista = cfg;
    ganancia = fundido > 0 ? 0 : 1; metaGan = 1; velGan = fundido > 0 ? 1 / fundido : 99;
    pista.addEventListener('ended', () => { if (pista && !pista.loop) { pista.currentTime = cfgPista.inicio || 0; pista.play().catch(() => {}); } });
    A.aplicarVolumen();
    pista.play().catch(() => { /* sin clic previo: sonará en cuanto se pueda */ });
    vigilar();
  };

  A.pararMusica = function (fundido = 0) {
    if (pista) {
      if (fundido > 0) saliendo.push({ el: pista, gan: ganancia, vol: cfgPista.volumen, vel: 1 / fundido });
      else { pista.pause(); pista.src = ''; }
    }
    pista = null;
    idPista = '';
    vigilar();
  };

  // la música de un nivel (Nivel ▸ Música: volumen, bucle y fundido)
  A.musicaNivel = function (nivel, fundido) {
    const n = nivel || {};
    A.musica(n.musica || '', { volumen: n.musicaVolumen ?? 1, inicio: n.musicaInicio || 0, fin: n.musicaFin || 0, fundido: fundido ?? n.musicaFundido ?? 0 });
  };
  // dónde va la música ahora (para el editor: "probar")
  A._pista = () => pista;
  A.musicaActual = () => (pista ? { id: idPista, t: pista.currentTime, dur: pista.duration || 0 } : null);

  // cada 25 ms mientras hace falta: el bucle con su inicio y fin, y los fundidos
  function vigilar() {
    const falta = (pista && (!pista.loop || ganancia !== metaGan)) || saliendo.length;
    if (falta && !reloj) reloj = setInterval(paso, 25);
    else if (!falta && reloj) { clearInterval(reloj); reloj = 0; }
  }
  function paso() {
    const dt = 0.025;
    if (pista) {
      const c = cfgPista;
      if (!pista.loop && c.fin > 0 && pista.currentTime >= c.fin) pista.currentTime = c.inicio || 0;
      if (ganancia !== metaGan) { ganancia = metaGan > ganancia ? Math.min(metaGan, ganancia + velGan * dt) : Math.max(metaGan, ganancia - velGan * dt); A.aplicarVolumen(); }
    }
    for (let i = saliendo.length - 1; i >= 0; i--) {
      const x = saliendo[i];
      x.gan -= x.vel * dt;
      if (x.gan <= 0) { x.el.pause(); x.el.src = ''; saliendo.splice(i, 1); continue; }
      x.el.volume = F.util.clamp(A.volGeneral * A.volMusica * x.vol * x.gan, 0, 1);
    }
    vigilar();
  }

  /* Efecto de sonido. op: { volumen (0..1), tono (1 = normal) }.
     Reutiliza hasta 4 reproductores por archivo (pasos, disparos… no crean basura cada vez) */
  const grupos = new Map();
  A.efecto = function (idAsset, op = {}) {
    const a = idAsset && F.Assets && F.Assets.mapa.get(idAsset);
    if (!a || !a.url) return;
    let g = grupos.get(idAsset);
    if (!g || g.url !== a.url) { g = { url: a.url, lista: [], i: 0 }; grupos.set(idAsset, g); }
    let s = g.lista[g.i];
    if (!s) { s = new Audio(a.url); s.preservesPitch = false; g.lista[g.i] = s; }
    g.i = (g.i + 1) % 4;
    // bajo el agua (A.bajoAgua, lo pone motor/agua.js): más bajo y más grave
    const agua = A.bajoAgua ? 0.45 : 1;
    s.volume = F.util.clamp(A.volGeneral * A.volEfectos * (op.volumen ?? 1) * agua, 0, 1);
    s.playbackRate = (op.tono || 1) * (A.bajoAgua ? 0.75 : 1);
    try { s.currentTime = 0; } catch (err) { /* aún cargando */ }
    s.play().catch(() => {});
  };

  /* Sonidos hechos por el motor (sin archivo): un golpe de ruido corto y grave, estilo pasos de PS1 */
  let ctx = null, ruido = null;
  function contexto() {
    if (ctx) return ctx;
    const C = window.AudioContext || window.webkitAudioContext;
    if (!C) return null;
    ctx = new C();
    ruido = ctx.createBuffer(1, Math.floor(ctx.sampleRate * 0.25), ctx.sampleRate);
    const d = ruido.getChannelData(0);
    for (let i = 0; i < d.length; i++) d[i] = Math.random() * 2 - 1;
    return ctx;
  }
  // tipo: 'paso' | 'aterrizar' | 'golpe'
  A.sintetico = function (tipo = 'paso', op = {}) {
    const c = contexto();
    if (!c) return;
    if (c.state === 'suspended') c.resume().catch(() => {});
    const t = c.currentTime;
    const fuente = c.createBufferSource();
    fuente.buffer = ruido;
    fuente.playbackRate.value = op.tono || 1;
    const filtro = c.createBiquadFilter();
    filtro.type = 'lowpass';
    const T = { paso: [650, 0.07, 0.5], aterrizar: [380, 0.16, 0.9], golpe: [900, 0.07, 0.5], disparo: [2600, 0.13, 0.7],
      explosion: [260, 0.7, 1], recarga: [1800, 0.04, 0.4], vacio: [3200, 0.03, 0.35], impacto: [1400, 0.05, 0.35], recoger: [5200, 0.14, 0.45] }[tipo] || [650, 0.07, 0.5];
    filtro.frequency.value = A.bajoAgua ? Math.min(T[0], 420) : T[0];   // bajo el agua: apagado
    const gan = c.createGain();
    const dur = T[1];
    const vol = F.util.clamp(A.volGeneral * A.volEfectos * (op.volumen ?? 1), 0, 1) * T[2];
    gan.gain.setValueAtTime(vol, t);
    gan.gain.exponentialRampToValueAtTime(0.001, t + dur);
    fuente.connect(filtro).connect(gan).connect(c.destination);
    fuente.start(t, Math.random() * 0.1, dur + 0.02);
  };

  /* 🔊 Sonido colocado en el nivel (motor/sonidos.js): un reproductor propio por fuente, con volumen y lado
     (izquierda / derecha) que cambian con la distancia. h = A.fuente(idAsset, bucle) → { poner(vol, lado), tocar(), parar(), quitar() } */
  A.fuente = function (idAsset, bucle) {
    const a = idAsset && F.Assets && F.Assets.mapa.get(idAsset);
    const c = contexto();
    if (!a || !a.url || !c) return null;
    const el = new Audio(a.url);
    el.loop = !!bucle;
    el.crossOrigin = 'anonymous';
    let pan = null, gan = null;
    try {
      const src = c.createMediaElementSource(el);
      pan = c.createStereoPanner ? c.createStereoPanner() : null;
      gan = c.createGain();
      (pan ? src.connect(pan).connect(gan) : src.connect(gan)).connect(c.destination);
    } catch (err) { /* sin Web Audio: solo volumen */ }
    return {
      el,
      poner(vol, lado) {
        const v = F.util.clamp(vol * A.volGeneral * A.volEfectos * (A.bajoAgua ? 0.45 : 1), 0, 1);
        if (gan) gan.gain.value = v; else el.volume = v;
        if (pan) pan.pan.value = F.util.clamp(lado || 0, -1, 1);
      },
      tocar(desdeCero) { if (c.state === 'suspended') c.resume().catch(() => {}); if (desdeCero) { try { el.currentTime = 0; } catch (e) { /* cargando */ } } el.play().catch(() => {}); },
      parar() { el.pause(); },
      quitar() { el.pause(); el.src = ''; },
    };
  };

  A.aplicarVolumen = function () {
    if (pista) pista.volume = F.util.clamp(A.volGeneral * A.volMusica * (cfgPista.volumen ?? 1) * ganancia * (A.bajoAgua ? 0.35 : 1), 0, 1);
  };

  // Reintentar la música tras el primer gesto del jugador (política de autoplay)
  const desbloquear = () => { if (pista && pista.paused) pista.play().catch(() => {}); };
  window.addEventListener('pointerdown', desbloquear);
  window.addEventListener('keydown', desbloquear);

  A.contexto = contexto;   // para sonidos hechos por el motor en otros archivos (lluvia y truenos del clima)
  F.Audio = A;
})(window.FORJA);
