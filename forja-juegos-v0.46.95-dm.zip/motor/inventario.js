/* =========================================================
   FORJA · INVENTARIO
   Biblioteca de OBJETOS del proyecto (proyecto.objetos) y RECETAS (proyecto.recetas), la MOCHILA del jugador
   (F.Inventario) y su PANTALLA (F.InventarioUI), más el BAÚL (entidad 📦 'baul': lo que guardas en uno sale en todos).

   Estilos (los elige el creador en el módulo Inventario del jugador):
     · 'casillas' (Resident Evil 1-3): pocas casillas, un objeto por casilla (lo que se apila, hasta su "pila");
       se amplía con mochilas. Si no cabe, no lo recoges.
     · 'lista': sin límite, con cantidades.
   Armas y munición DENTRO (estilo RE, opcional): ocupan casilla; la munición de las armas es la de la mochila
   (recargar la gasta de ahí) y combinar munición + arma recarga.
   Qué hay en una casilla: { k: 'obj', id, n } · { k: 'arma', id } · { k: 'mun', id, n }   (id de la biblioteca,
   de proyecto.armas o de proyecto.municiones). Se guarda tal cual en la partida (estado del jugador).
   ========================================================= */
(function (F) {
  'use strict';
  const T = THREE;

  /* ---------- Biblioteca ---------- */
  const OBJETO = {
    nombre: 'Objeto',
    tipo: 'cura',             // 'cura' | 'llave' | 'clave' (puzle) | 'nota' | 'mochila' | 'otro'
    icono: '✚',               // carácter o emoji para la casilla
    color: '#5fbf4a',
    descripcion: '',
    pila: 1,                  // cuántos caben en una casilla
    vida: 25, armadura: 0,    // cura
    casillas: 2,              // mochila: casillas que añade
    texto: '',                // nota: lo que se lee al usarla
    forma: 'frasco',          // figura del motor: 'frasco' | 'hierba' | 'llave' | 'caja' | 'papel' | 'bolsa'
    modelo: '',               // GLB propio (se ve en el mapa y al examinarlo)
    sonido: '',
  };
  function objetoNuevo(extra = {}) { return { id: F.util.uid(), ...F.util.copiar(OBJETO), ...extra }; }
  function objetosPorDefecto() {
    const o = (id, v) => ({ ...F.util.copiar(OBJETO), id, ...v });
    return [
      o('ob_hierba_verde', { nombre: 'Hierba verde', tipo: 'cura', icono: '🌿', color: '#4fae3a', forma: 'hierba', vida: 25, descripcion: 'Una hierba medicinal. Cura un poco. Combinada vale más.' }),
      o('ob_hierba_roja', { nombre: 'Hierba roja', tipo: 'otro', icono: '🌺', color: '#c83a3a', forma: 'hierba', vida: 0, descripcion: 'Sola no sirve. Combínala con una verde.' }),
      o('ob_mezcla', { nombre: 'Mezcla de hierbas', tipo: 'cura', icono: '🍀', color: '#c8a03a', forma: 'hierba', vida: 100, descripcion: 'Verde y roja juntas: cura del todo.' }),
      o('ob_spray', { nombre: 'Spray de primeros auxilios', tipo: 'cura', icono: '🧴', color: '#e8e8e8', forma: 'frasco', vida: 100, descripcion: 'Cura del todo.' }),
      o('ob_llave', { nombre: 'Llave', tipo: 'llave', icono: '🗝', color: '#d8b33a', forma: 'llave', vida: 0, descripcion: 'Abre una puerta.' }),
      o('ob_mochila', { nombre: 'Mochila', tipo: 'mochila', icono: '🎒', color: '#7a5a3a', forma: 'bolsa', vida: 0, casillas: 2, descripcion: 'Dos casillas más.' }),
      o('ob_gema', { nombre: 'Gema roja', tipo: 'clave', icono: '💎', color: '#d8304a', forma: 'caja', vida: 0, descripcion: 'Una gema tallada. Parece encajar en algún sitio.' }),
      o('ob_nota', { nombre: 'Nota', tipo: 'nota', icono: '📄', color: '#e8e0c8', forma: 'papel', vida: 0, descripcion: 'Una hoja escrita a mano.', texto: 'Escribe aquí lo que dice la nota.' }),
    ];
  }
  function recetasPorDefecto() {
    return [{ a: 'ob_hierba_verde', b: 'ob_hierba_roja', da: 'ob_mezcla', n: 1 }];
  }

  /* ---------- Figura del motor para un objeto (en el mapa y al examinarlo) ---------- */
  function figuraObjeto(ob, escala = 1) {
    const g = new T.Group();
    const a = ob.modelo && F.Assets && F.Assets.mapa.get(ob.modelo);
    if (a && a.gltf) { const m = T.SkeletonUtils.clone(a.gltf.scene); g.add(m); g.scale.setScalar(escala); return g; }
    const mat = (c) => F.Render.matRetro(c);
    const color = ob.color || '#c8b07a', oscuro = new T.Color(color).multiplyScalar(0.6), m1 = mat(color), m2 = mat(oscuro);
    const caja = (w, h, d, x, y, z, m) => { const o = new T.Mesh(new T.BoxGeometry(w, h, d), m); o.position.set(x, y, z); g.add(o); return o; };
    switch (ob.forma) {
      case 'hierba':   // maceta con hojas
        caja(0.18, 0.12, 0.18, 0, 0.06, 0, mat('#8a5a3a'));
        for (let i = 0; i < 5; i++) { const h = caja(0.05, 0.18, 0.02, 0, 0.2, 0, m1); h.rotation.set(0.5, (i / 5) * Math.PI * 2, 0); h.position.set(Math.sin((i / 5) * 6.28) * 0.04, 0.2, Math.cos((i / 5) * 6.28) * 0.04); }
        break;
      case 'llave':
        caja(0.05, 0.05, 0.22, 0, 0.03, 0, m1); caja(0.12, 0.05, 0.12, 0, 0.03, -0.14, m1); caja(0.05, 0.05, 0.05, 0.04, 0.03, 0.09, m1);
        break;
      case 'papel':
        caja(0.2, 0.01, 0.26, 0, 0.005, 0, m1); caja(0.14, 0.012, 0.01, 0, 0.006, 0.05, m2); caja(0.14, 0.012, 0.01, 0, 0.006, 0, m2);
        break;
      case 'bolsa':
        caja(0.28, 0.3, 0.16, 0, 0.15, 0, m1); caja(0.22, 0.1, 0.17, 0, 0.26, 0, m2);
        break;
      case 'caja':
        caja(0.26, 0.18, 0.18, 0, 0.09, 0, m1); caja(0.27, 0.03, 0.19, 0, 0.12, 0, m2);
        break;
      default:         // frasco
        caja(0.1, 0.2, 0.1, 0, 0.1, 0, m1); caja(0.05, 0.05, 0.05, 0, 0.225, 0, m2);
    }
    g.scale.setScalar(escala);
    return g;
  }

  /* ---------- Lo que se ve al EXAMINAR: el modelo real ----------
     1) el modelo de su ficha (objeto, arma) · 2) si no tiene, el modelo del recogible que lo da en algún nivel
     (así lo que ves en el suelo es lo que examinas) · 3) la figura del motor (la del recogible para armas y munición) */
  function modeloExamen(juego, it, d) {
    const P = juego.proyecto, A = F.Assets.mapa;
    const glb = (id) => { const a = id && A.get(id); return a && a.gltf ? T.SkeletonUtils.clone(a.gltf.scene) : null; };
    if (it.k === 'obj' && d && d.modelo) { const m = glb(d.modelo); if (m) return m; }
    if (it.k === 'arma' && d && d.arma && d.arma.modelo) { const m = glb(d.arma.modelo); if (m) return m; }
    // el recogible del mapa que da esto
    for (const esc of P.escenas || []) for (const e of esc.entidades || []) {
      const r = e.tipo === 'recogible' && e.recogible;
      if (!r || !r.modelo) continue;
      const da = (it.k === 'obj' && r.tipo === 'objeto' && r.objeto === it.id) || (it.k === 'arma' && r.tipo === 'arma' && r.arma === it.id) ||
        (it.k === 'mun' && r.tipo === 'municion' && r.municionTipo === it.id);
      if (da) { const m = glb(r.modelo); if (m) return m; }
    }
    if (it.k === 'obj' && d) return figuraObjeto(d);
    // arma / munición sin modelo: la figura de su recogible
    if (F.Recogibles && F.Recogibles.figura) {
      const g = F.Recogibles.figura({ tipo: 'recogible', recogible: { ...F.Recogibles.BASE, tipo: it.k === 'arma' ? 'arma' : 'municion', brillo: 0 } }, P);
      return g;
    }
    return figuraObjeto({ forma: 'caja', color: d ? d.color : '#9aa0a8' });
  }

  /* ---------- Baúl (entidad 📦): figura del motor ---------- */
  function figuraBaul(ent) {
    const g = new T.Group();
    const mat = (c) => F.Render.matRetro(c);
    const madera = mat((ent.baul && ent.baul.color) || '#7a5636'), metal = mat('#3a3a3a');
    const caja = (w, h, d, x, y, z, m) => { const o = new T.Mesh(new T.BoxGeometry(w, h, d), m); o.position.set(x, y, z); g.add(o); return o; };
    caja(1.0, 0.55, 0.6, 0, 0.275, 0, madera);
    // tapa con bisagra atrás (el cofre de premio la abre: userData.tapa.rotation.x)
    const tapa = new T.Group();
    tapa.position.set(0, 0.55, -0.31);
    g.add(tapa);
    const t = new T.Mesh(new T.BoxGeometry(1.02, 0.18, 0.62), madera);
    t.position.set(0, 0.09, 0.31);
    tapa.add(t);
    for (const x of [-0.42, 0.42]) { caja(0.06, 0.55, 0.63, x, 0.275, 0, metal); const f = new T.Mesh(new T.BoxGeometry(0.06, 0.19, 0.63), metal); f.position.set(x, 0.095, 0.31); tapa.add(f); }   // flejes
    caja(0.12, 0.12, 0.04, 0, 0.5, 0.31, mat('#d8b33a'));       // cerradura
    g.userData.tapa = tapa;
    return g;
  }

  /* =========================================================
     LA MOCHILA (j.inventario)
     ========================================================= */
  class Inventario {
    constructor(juego, p) {
      this.juego = juego;
      this.p = p;
      this.estilo = p.estilo === 'lista' ? 'lista' : 'casillas';
      this.armasDentro = !!p.armasDentro;
      this.n = this.estilo === 'lista' ? Infinity : Math.max(1, p.casillas | 0);
      this.items = [];          // casillas: largo n (null = vacía) · lista: solo las ocupadas
      if (this.estilo === 'casillas') this.items = new Array(this.n).fill(null);
      this.baul = [];           // lo guardado en los baúles (el mismo en todos)
    }

    // definición de lo que hay en una casilla: { nombre, icono, color, descripcion, pila, tipo… }
    def(it) {
      const pr = this.juego.proyecto;
      if (!it) return null;
      if (it.k === 'arma') { const a = (pr.armas || []).find((x) => x.id === it.id); return a && { nombre: a.nombre, icono: a.icono || ({ cuerpo: '🗡', proyectil: '🚀' }[a.tipo] || '🔫'), color: '#9aa0a8', tipo: 'arma', pila: 1, descripcion: a.descripcion || 'Un arma. Úsala para equiparla; combínala con su munición para recargar.', arma: a }; }
      if (it.k === 'mun') { const m = (pr.municiones || []).find((x) => x.id === it.id); return m && { nombre: m.nombre, icono: m.icono || '▮', color: '#d8b33a', tipo: 'municion', pila: m.maxima || 99, descripcion: 'Munición. Combínala con un arma para recargarla.', municion: m }; }
      const o = (pr.objetos || []).find((x) => x.id === it.id);
      return o && { ...OBJETO, ...o };
    }

    /* Ordenar: junta lo que se apila (hasta su pila) y lo pone por tipo y nombre (armas, munición, curas,
       llaves, objetos clave, notas, el resto). En casillas los huecos quedan al final */
    ordenar() {
      const ORDEN = { arma: 0, municion: 1, cura: 2, llave: 3, clave: 4, nota: 5, mochila: 6, otro: 7 };
      const juntos = [];
      for (const it of this.items) {
        if (!it) continue;
        const d = this.def(it), pila = it.k === 'arma' ? 1 : Math.max(1, (d && d.pila) || 1);
        let n = it.k === 'arma' ? 1 : it.n || 1;
        if (it.k !== 'arma') for (const q of juntos) {
          if (n <= 0) break;
          if (q.k === it.k && q.id === it.id && q.n < pila) { const pasa = Math.min(n, pila - q.n); q.n += pasa; n -= pasa; }
        }
        if (n > 0) juntos.push(it.k === 'arma' ? { ...it } : { ...it, n });
      }
      const clave = (it) => { const d = this.def(it) || {}; return [ORDEN[d.tipo] ?? 8, d.nombre || '']; };
      juntos.sort((a, b) => { const x = clave(a), y = clave(b); return x[0] - y[0] || x[1].localeCompare(y[1]); });
      if (this.estilo === 'casillas') { this.items = new Array(this.n).fill(null); juntos.forEach((it, i) => { if (i < this.n) this.items[i] = it; }); }
      else this.items = juntos;
    }

    // mover: cambia de sitio dos casillas
    intercambiar(a, b) {
      if (a === b || a < 0 || b < 0 || a >= this.items.length || b >= this.items.length) return;
      const t = this.items[a]; this.items[a] = this.items[b]; this.items[b] = t;
    }

    ocupadas() { return this.items.filter(Boolean).length; }
    libres() { return this.estilo === 'lista' ? Infinity : this.items.filter((x) => !x).length; }

    // ¿cuántos hay de algo? (k, id)
    contar(k, id) { let n = 0; for (const it of this.items) if (it && it.k === k && it.id === id) n += it.k === 'arma' ? 1 : it.n || 1; return n; }

    /* Meter algo. Devuelve lo que NO cupo (0 = todo dentro) */
    agregar(k, id, n = 1) {
      const pila = k === 'arma' ? 1 : Math.max(1, (this.def({ k, id }) || {}).pila || 1);
      let resto = k === 'arma' ? 1 : n;
      // primero en las casillas que ya tienen eso
      if (k !== 'arma') for (const it of this.items) {
        if (!resto) break;
        if (it && it.k === k && it.id === id && it.n < pila) { const cabe = Math.min(pila - it.n, resto); it.n += cabe; resto -= cabe; }
      }
      // luego en casillas libres
      while (resto > 0) {
        const nuevo = k === 'arma' ? { k, id } : { k, id, n: Math.min(pila, resto) };
        if (this.estilo === 'lista') this.items.push(nuevo);
        else { const i = this.items.indexOf(null); if (i < 0) break; this.items[i] = nuevo; }
        resto -= nuevo.n || 1;
      }
      F.emitir('inventario-cambio', this);
      return Math.max(0, resto);
    }
    // ¿cabría entero?
    cabe(k, id, n = 1) {
      if (this.estilo === 'lista') return true;
      const pila = k === 'arma' ? 1 : Math.max(1, (this.def({ k, id }) || {}).pila || 1);
      let hueco = this.libres() * pila;
      if (k !== 'arma') for (const it of this.items) if (it && it.k === k && it.id === id) hueco += pila - it.n;
      return hueco >= (k === 'arma' ? 1 : n);
    }

    // quitar n de una casilla (o la casilla entera)
    quitar(i, n = Infinity) {
      const it = this.items[i];
      if (!it) return 0;
      const q = it.k === 'arma' ? 1 : Math.min(it.n, n);
      if (it.k !== 'arma') it.n -= q;
      if (it.k === 'arma' || it.n <= 0) { if (this.estilo === 'lista') this.items.splice(i, 1); else this.items[i] = null; }
      F.emitir('inventario-cambio', this);
      return q;
    }
    // quitar n de lo que sea (de varias casillas si hace falta): para gastar munición al recargar
    gastar(k, id, n) {
      let falta = n;
      for (let i = this.items.length - 1; i >= 0 && falta > 0; i--) {
        const it = this.items[i];
        if (it && it.k === k && it.id === id) falta -= this.quitar(i, falta);
      }
      return n - falta;
    }

    ampliar(mas) {
      if (this.estilo === 'lista') return;
      const max = Math.max(this.n, this.p.casillasMax | 0 || 24);
      const nuevo = Math.min(max, this.n + mas);
      for (let i = this.n; i < nuevo; i++) this.items.push(null);
      this.n = nuevo;
      F.emitir('inventario-cambio', this);
    }

    // receta para dos casillas (en cualquier orden): { da, n } o null
    receta(a, b) {
      if (!a || !b || a.k !== 'obj' || b.k !== 'obj') return null;
      for (const r of this.juego.proyecto.recetas || []) {
        if ((r.a === a.id && r.b === b.id) || (r.a === b.id && r.b === a.id)) return r;
      }
      return null;
    }

    serializar() { return { n: this.n, items: F.util.copiar(this.items), baul: F.util.copiar(this.baul), baulDivisas: { ...(this.baulDivisas || {}) } }; }
    cargar(d) {
      if (!d) return;
      if (this.estilo === 'casillas') {
        this.n = Math.max(this.n, d.n || 0);
        const items = (d.items || []).filter(Boolean);
        this.items = new Array(this.n).fill(null);
        items.slice(0, this.n).forEach((it, i) => { this.items[i] = it; });
      } else this.items = (d.items || []).filter(Boolean);
      this.baul = Array.isArray(d.baul) ? d.baul : [];
      this.baulDivisas = d.baulDivisas && typeof d.baulDivisas === 'object' ? { ...d.baulDivisas } : {};
    }
  }

  /* =========================================================
     LA PANTALLA (estilo RE: casillas a la izquierda, ficha a la derecha, acciones abajo)
     Teclado: flechas / WASD mueven · E / Enter / Espacio = acción · Q / Esc / Tab / I = volver o cerrar.
     Ratón y toque también. Mientras está abierta el jugador no se mueve; con "pausa" el mundo se para.
     ========================================================= */
  const CSS = `
  .finv { position: absolute; inset: 0; z-index: 30; display: none; align-items: center; justify-content: center; background: rgba(0,0,0,.72);
    font-family: var(--fh-fuente, ui-monospace, Consolas, monospace); color: var(--fh-texto, #e8e2d0); font-size: calc(2.4vmin * var(--fi-t, 1)); }
  .finv.fi-ver { display: flex; }
  .finv .fi-caja { width: min(94%, 62em); max-height: 92%; display: grid; grid-template-columns: 1.15fr 1fr; gap: 1.2em; padding: 1.2em;
    background: rgba(12,12,16,.9); border: .15em solid var(--fh-sel, #e8a33d); box-sizing: border-box; }
  .finv h2 { grid-column: 1 / -1; margin: 0; font-size: 1.3em; letter-spacing: .2em; font-weight: normal; color: var(--fh-sel, #e8a33d); display: flex; justify-content: space-between; }
  .finv h2 small { font-size: .6em; letter-spacing: .08em; color: var(--fh-texto, #e8e2d0); opacity: .75; align-self: center; }
  .finv .fi-rejilla { display: grid; grid-template-columns: repeat(var(--fi-col, 4), 1fr); gap: .4em; align-content: start; overflow: auto; max-height: 60vh; }
  .finv .fi-cas { aspect-ratio: 1; border: .12em solid rgba(255,255,255,.25); background: rgba(255,255,255,.04); position: relative; display: flex;
    align-items: center; justify-content: center; font-size: 1.9em; cursor: pointer; user-select: none; }
  .finv .fi-cas.fi-vacia { opacity: .45; }
  .finv .fi-cas.fi-sel { border-color: var(--fh-sel, #e8a33d); background: rgba(232,163,61,.18); }
  .finv .fi-cas.fi-marca { outline: .12em dashed #7fd4ff; outline-offset: -.35em; }
  .finv .fi-cas small { position: absolute; right: .25em; bottom: .1em; font-size: .38em; }
  .finv .fi-cas .fi-eq { position: absolute; left: .25em; top: .1em; font-size: .34em; color: var(--fh-sel, #e8a33d); }
  .finv .fi-lista { display: flex; flex-direction: column; gap: .2em; overflow: auto; max-height: 60vh; }
  .finv .fi-fila { display: flex; gap: .6em; align-items: center; padding: .3em .5em; border: .1em solid transparent; cursor: pointer; }
  .finv .fi-fila.fi-sel { border-color: var(--fh-sel, #e8a33d); background: rgba(232,163,61,.18); }
  .finv .fi-fila .fi-ic { width: 1.6em; text-align: center; font-size: 1.3em; }
  .finv .fi-fila .fi-n { margin-left: auto; opacity: .8; }
  .finv .fi-ficha { display: flex; flex-direction: column; gap: .6em; min-width: 0; }
  .finv .fi-grande { font-size: 3.4em; text-align: center; line-height: 1.2; min-height: 1.2em; }
  .finv .fi-nombre { font-size: 1.15em; color: var(--fh-sel, #e8a33d); }
  .finv .fi-desc { opacity: .9; line-height: 1.35; white-space: pre-wrap; min-height: 3em; }
  .finv .fi-acc { display: flex; flex-wrap: wrap; gap: .4em; }
  .finv .fi-acc button, .finv .fi-pie button { font: inherit; color: inherit; background: rgba(255,255,255,.06); border: .1em solid rgba(255,255,255,.3); padding: .35em .7em; cursor: pointer; }
  .finv .fi-acc button.fi-sel { border-color: var(--fh-sel, #e8a33d); background: rgba(232,163,61,.25); }
  .finv .fi-estado { display: flex; gap: 1em; align-items: center; font-size: .85em; opacity: .9; }
  .finv .fi-barra { width: 7em; height: .55em; background: rgba(0,0,0,.6); border: .1em solid rgba(255,255,255,.5); }
  .finv .fi-barra div { height: 100%; background: #e23b3b; }
  .finv .fi-aviso { min-height: 1.3em; color: #7fd4ff; }
  .finv .fi-pie { grid-column: 1 / -1; display: flex; justify-content: space-between; font-size: .8em; opacity: .75; }
  .finv .fi-examinar { position: absolute; inset: 0; display: none; align-items: center; justify-content: center; flex-direction: column; background: rgba(0,0,0,.85); gap: .8em; }
  .finv .fi-examinar.fi-ver { display: flex; }
  .finv .fi-examinar canvas { width: min(70vmin, 520px); height: min(70vmin, 520px); image-rendering: pixelated; cursor: grab; }
  .finv .fi-dos { display: grid; grid-template-columns: 1fr 1fr; gap: 1em; }
  .finv .fi-caja.fi-con-baul { grid-template-columns: 2.2fr 1fr; width: min(96%, 74em); }
  .finv .fi-dos h3 { margin: 0 0 .3em; font-size: .9em; font-weight: normal; letter-spacing: .12em; opacity: .8; }
  .finv .fi-lado.fi-activo h3 { color: var(--fh-sel, #e8a33d); opacity: 1; }
  `;
  function asegurarCss() {
    if (document.getElementById('estilos-forja-inventario')) return;
    const st = document.createElement('style');
    st.id = 'estilos-forja-inventario';
    st.textContent = CSS;
    document.head.appendChild(st);
  }

  class InventarioUI {
    constructor(j, mod) {
      this.j = j;
      this.mod = mod;                 // el módulo (usar, equipar, recargar…)
      this.inv = j.inventario;
      this.abierto = false;
      this.sel = 0;
      this.modo = 'elegir';           // 'elegir' | 'acciones' | 'combinar' | 'examinar'
      this.acc = 0;
      this.baulAbierto = false;
      this.lado = 'mochila';          // en el baúl: 'mochila' | 'baul'
    }

    _montar() {
      asegurarCss();
      const capa = F.Hud.capa(this.j.juego);
      const el = document.createElement('div');
      el.className = 'finv';
      el.innerHTML = '<div class="fi-caja"></div><div class="fi-examinar"><canvas width="160" height="160"></canvas><div>Arrastra para girarlo · Esc para volver</div></div>';
      // el HUD no recibe clics; el inventario sí
      el.style.pointerEvents = 'auto';
      capa.appendChild(el);
      this.el = el;
      this.cajaEl = el.firstChild;
      this.exEl = el.lastChild;
      el.addEventListener('pointerdown', (e) => e.stopPropagation());
    }

    abrir(baul = false) {
      if (!this.el || !this.el.isConnected) this._montar();
      this.abierto = true;
      this.baulAbierto = baul;
      this.lado = 'mochila';
      this.modo = 'elegir';
      this.marca = -1;
      this.aviso = '';
      this.sel = Math.min(this.sel, Math.max(0, this.lista().length - 1));
      this.el.classList.add('fi-ver');
      // soltar el ratón para poder pinchar (sin que el editor o la partida lo tomen por "pausa")
      F.Entrada.silencioLiberar = true;
      F.Entrada.soltarBloqueo();
      F.Entrada.limpiar && F.Entrada.limpiar();
      this.pintar();
      F.emitir('inventario-abierto', this.j);
    }

    cerrar() {
      this.abierto = false;
      this.modo = 'elegir';
      this._cerrarExamen();
      if (this.el) this.el.classList.remove('fi-ver');
      F.Entrada.limpiar && F.Entrada.limpiar();
      // vuelve a tomar el ratón para mirar (al cerrar con tecla o con el botón Cerrar el navegador lo permite)
      if (!F.Entrada.tactil) F.Entrada.pedirBloqueo();
      F.emitir('inventario-cerrado', this.j);
    }

    // lo que se ve en el lado activo
    lista() {
      if (this.baulAbierto && this.lado === 'baul') return this.inv.baul;
      return this.inv.items;
    }
    actual() { return this.lista()[this.sel] || null; }

    acciones(it) {
      if (!it) return [];
      const d = this.inv.def(it);
      if (this.baulAbierto) return [this.lado === 'mochila' ? ['guardar', 'Guardar en el baúl'] : ['sacar', 'Sacar']];
      const a = [];
      if (it.k === 'arma') a.push(['usar', this.j.armaEquipada === it.id ? 'Quitar' : 'Equipar']);
      else if (d && (d.tipo === 'cura' || d.tipo === 'mochila' || d.tipo === 'nota')) a.push(['usar', d.tipo === 'nota' ? 'Leer' : 'Usar']);
      a.push(['examinar', 'Examinar'], ['combinar', 'Combinar']);
      if (this.inv.estilo === 'casillas') a.push(['mover', 'Mover']);
      a.push(['tirar', 'Tirar']);
      return a;
    }

    /* ---------- Entrada (la llama el módulo cada cuadro mientras está abierta) ---------- */
    actualizar(dt) {
      const E = F.Entrada, t = E.teclasCuadro || new Set();
      // teclado (teclas de este cuadro) o mando (cruceta = moverse, A = aceptar, B = volver)
      const arriba = t.has('ArrowUp') || t.has('KeyW') || E.pulsado('adelante'), abajo = t.has('ArrowDown') || t.has('KeyS') || E.pulsado('atras');
      const izq = t.has('ArrowLeft') || t.has('KeyA') || E.pulsado('izquierda'), der = t.has('ArrowRight') || t.has('KeyD') || E.pulsado('derecha');
      const ok = t.has('KeyE') || t.has('Enter') || t.has('Space') || E.pulsado('interactuar') || E.pulsado('saltar');
      const atras = t.has('KeyQ') || t.has('Escape') || t.has('Backspace') || E.pulsado('agachar');
      const cerrar = t.has('Tab') || t.has('KeyI') || E.pulsado('inventario');
      if (this.modo === 'examinar') { this._girarExamen(dt, izq, der, arriba, abajo); if (atras || ok || cerrar) { this._cerrarExamen(); this.modo = 'elegir'; this.pintar(); } return; }
      if (cerrar && this.modo !== 'acciones') { this.cerrar(); return; }
      if (this.modo === 'acciones') {
        const acc = this.acciones(this.actual());
        if (izq || arriba) { this.acc = (this.acc - 1 + acc.length) % acc.length; this.pintar(); }
        if (der || abajo) { this.acc = (this.acc + 1) % acc.length; this.pintar(); }
        if (ok && acc[this.acc]) this.hacer(acc[this.acc][0]);
        if (atras || cerrar) { this.modo = 'elegir'; this.pintar(); }
        return;
      }
      const L = this.lista(), n = L.length, col = this.inv.estilo === 'casillas' && !this.baulAbierto ? this._columnas() : 1;
      if (this.baulAbierto && (izq || der)) { this.lado = this.lado === 'mochila' ? 'baul' : 'mochila'; this.sel = 0; this.pintar(); return; }
      if (n) {
        let s = this.sel;
        if (izq) s -= 1; if (der) s += 1; if (arriba) s -= col; if (abajo) s += col;
        if (s !== this.sel) { this.sel = (s + n) % n; this.pintar(); }
      }
      if ((t.has('KeyR') || E.pulsado('recargar')) && !this.baulAbierto && this.modo === 'elegir') { this.ordenarMochila(); return; }
      if (ok && this.modo === 'mover') { this._moverA(this.sel); return; }
      if (ok) {
        if (this.modo === 'combinar') this._combinarCon(this.sel);
        else if (this.actual()) { this.modo = 'acciones'; this.acc = 0; this.pintar(); }
      }
      if (atras) { if (this.modo === 'combinar' || this.modo === 'mover') { this.modo = 'elegir'; this.marca = -1; this.aviso = ''; this.pintar(); } else this.cerrar(); }
    }

    _columnas() { return this.inv.n <= 6 ? 3 : this.inv.n <= 12 ? 4 : 6; }

    /* ---------- Acciones ---------- */
    hacer(que) {
      const it = this.actual(), inv = this.inv;
      if (!it) return;
      if (que === 'usar') this.aviso = this.mod.usarObjeto(this.j, this.sel) || '';
      else if (que === 'examinar') { this._examinar(it); return; }
      else if (que === 'combinar') { this.modo = 'combinar'; this.marca = this.sel; this.aviso = 'Elige con qué combinarlo'; this.pintar(); return; }
      else if (que === 'mover') { this.modo = 'mover'; this.marca = this.sel; this.aviso = 'Elige a qué casilla'; this.pintar(); return; }
      else if (que === 'tirar') { this.aviso = this.mod.tirarObjeto(this.j, this.sel) || ''; }
      else if (que === 'guardar') { const q = inv.items[this.sel]; if (q) { inv.baul.push(F.util.copiar(q)); inv.quitar(this.sel); this.aviso = 'Guardado en el baúl'; } }
      else if (que === 'sacar') {
        const q = inv.baul[this.sel];
        if (q) {
          const resto = inv.agregar(q.k, q.id, q.k === 'arma' ? 1 : q.n);
          if (resto && resto === (q.n || 1)) this.aviso = 'No tienes sitio';
          else { if (resto) q.n = resto; else inv.baul.splice(this.sel, 1); this.aviso = 'Sacado'; this.mod.sincronizar(this.j); }
        }
      }
      this.modo = 'elegir';
      this.sel = Math.min(this.sel, Math.max(0, this.lista().length - 1));
      this.pintar();
    }

    _moverA(i) {
      this.inv.intercambiar(this.marca, i);
      this.modo = 'elegir'; this.marca = -1; this.aviso = ''; this.sel = i;
      this.pintar();
    }

    ordenarMochila() {
      this.inv.ordenar();
      this.mod.sincronizar && this.mod.sincronizar(this.j);
      this.sel = 0; this.aviso = 'Ordenado';
      F.Audio.sintetico('recoger', { volumen: 0.3, tono: 1.4 });
      this.pintar();
    }

    _combinarCon(i) {
      const a = this.marca;
      this.modo = 'elegir';
      this.marca = -1;
      if (i === a) { this.aviso = ''; this.pintar(); return; }
      this.aviso = this.mod.combinar(this.j, a, i) || '';
      this.sel = Math.min(this.sel, Math.max(0, this.lista().length - 1));
      this.pintar();
    }

    /* ---------- Examinar: el objeto en 3D, girando (su modelo o la figura del motor) ---------- */
    _examinar(it) {
      const d = this.inv.def(it);
      this.modo = 'examinar';
      this.exEl.classList.add('fi-ver');
      const cv = this.exEl.querySelector('canvas');
      if (!this.r3) {
        this.r3 = new T.WebGLRenderer({ canvas: cv, antialias: false, alpha: true });
        this.r3.setPixelRatio(1);
        this.esc3 = new T.Scene();
        this.esc3.add(new T.HemisphereLight(0xffffff, 0x404050, 1.2));
        const sol = new T.DirectionalLight(0xffffff, 1.4); sol.position.set(1, 2, 2); this.esc3.add(sol);
        this.cam3 = new T.PerspectiveCamera(35, 1, 0.01, 50);
        let arrastra = null;
        cv.addEventListener('pointerdown', (e) => { arrastra = [e.clientX, e.clientY]; cv.setPointerCapture(e.pointerId); });
        cv.addEventListener('pointermove', (e) => { if (!arrastra || !this.pieza) return; this.pieza.rotation.y += (e.clientX - arrastra[0]) * 0.01; this.pieza.rotation.x += (e.clientY - arrastra[1]) * 0.01; arrastra = [e.clientX, e.clientY]; });
        cv.addEventListener('pointerup', () => { arrastra = null; });
      }
      if (this.pieza) { this.esc3.remove(this.pieza); this.pieza = null; }
      const pieza = modeloExamen(this.j.juego, it, d);
      // centrar y encuadrar
      const caja = new T.Box3().setFromObject(pieza), c = caja.getCenter(new T.Vector3()), tam = caja.getSize(new T.Vector3()).length() || 0.3;
      const grupo = new T.Group();
      pieza.position.sub(c);
      grupo.add(pieza);
      this.esc3.add(grupo);
      this.pieza = grupo;
      this.cam3.position.set(0, tam * 0.25, tam * 1.9);
      this.cam3.lookAt(0, 0, 0);
      const bucle = () => {
        if (this.modo !== 'examinar') return;
        this.r3.render(this.esc3, this.cam3);
        requestAnimationFrame(bucle);
      };
      bucle();
    }
    _girarExamen(dt, izq, der, arriba, abajo) {
      if (!this.pieza) return;
      const E = F.Entrada, m = E.mover || { x: 0, y: 0 };
      this.pieza.rotation.y += ((der ? 1 : 0) - (izq ? 1 : 0)) * 0.3 + m.x * dt * 2.5 + dt * 0.4;   // y gira solo, despacio
      this.pieza.rotation.x += ((abajo ? 1 : 0) - (arriba ? 1 : 0)) * 0.3 - m.y * dt * 2.5;
    }
    _cerrarExamen() {
      if (this.exEl) this.exEl.classList.remove('fi-ver');
      if (this.pieza && this.esc3) { this.esc3.remove(this.pieza); this.pieza = null; }
    }

    // 💰 fila de divisas (y en el baúl: guardar / sacar las que el creador permita)
    _divisasHtml(h) {
      const D = F.Divisas, P = this.j.juego.proyecto, L = D.lista(P), inv = this.inv, bd = inv.baulDivisas || (inv.baulDivisas = {});
      const ver = L.filter((d, i) => D.tiene(this.j, d.id) > 0 || (this.baulAbierto && d.enBaul) || (i === 0 && L.length === 1 && D.tiene(this.j, d.id) > 0));
      if (!ver.length) return '';
      return `<div class="fi-divisas" style="display:flex;flex-wrap:wrap;gap:.4em .9em;margin-bottom:.4em">` + ver.map((d) => {
        let s = `<span style="color:${d.color}">${D.html(d)} ${D.tiene(this.j, d.id)}</span>`;
        if (this.baulAbierto && d.enBaul) s += ` <small style="opacity:.75">(baúl ${bd[d.id] || 0})</small> <button data-dv-guardar="${h(d.id)}">Guardar</button><button data-dv-sacar="${h(d.id)}">Sacar</button>`;
        return `<span>${s}</span>`;
      }).join('') + '</div>';
    }

    /* ---------- Dibujo (solo al cambiar algo) ---------- */
    pintar() {
      if (!this.el) return;
      const inv = this.inv, j = this.j;
      const h = (s) => String(s ?? '').replace(/[&<>"]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
      const casilla = (it, i, lado) => {
        const d = it && inv.def(it);
        const sel = (!this.baulAbierto || this.lado === lado) && i === this.sel;
        const cls = 'fi-cas' + (it ? '' : ' fi-vacia') + (sel ? ' fi-sel' : '') + (lado === 'mochila' && i === this.marca ? ' fi-marca' : '');
        const n = it && it.k !== 'arma' && (it.n > 1 || it.k === 'mun') ? `<small>${it.n}</small>` : '';
        const eq = it && it.k === 'arma' && j.armaEquipada === it.id ? '<span class="fi-eq">E</span>' : '';
        return `<div class="${cls}" data-i="${i}" data-lado="${lado}" title="${h(d ? d.nombre : '')}" style="${d ? 'color:' + d.color : ''}">${d ? h(d.icono) : ''}${n}${eq}</div>`;
      };
      const fila = (it, i, lado) => {
        const d = inv.def(it) || { nombre: '?', icono: '?' };
        const sel = (!this.baulAbierto || this.lado === lado) && i === this.sel;
        return `<div class="fi-fila${sel ? ' fi-sel' : ''}${lado === 'mochila' && i === this.marca ? ' fi-marca' : ''}" data-i="${i}" data-lado="${lado}">` +
          `<span class="fi-ic" style="color:${d.color}">${h(d.icono)}</span><span>${h(d.nombre)}${it.k === 'arma' && j.armaEquipada === it.id ? ' (equipada)' : ''}</span><span class="fi-n">${it.k === 'arma' ? '' : '×' + it.n}</span></div>`;
      };
      const pintarLado = (lista, lado) => {
        if (inv.estilo === 'casillas' && lado === 'mochila') return `<div class="fi-rejilla" style="--fi-col:${this._columnas()}">${lista.map((it, i) => casilla(it, i, lado)).join('')}</div>`;
        return `<div class="fi-lista">${lista.length ? lista.map((it, i) => fila(it, i, lado)).join('') : '<div style="opacity:.6">(vacío)</div>'}</div>`;
      };
      const it = this.actual(), d = it && inv.def(it);
      const acc = this.modo === 'acciones' ? this.acciones(it) : [];
      const vida = j.vidaMax ? Math.max(0, Math.round((j.vida / j.vidaMax) * 100)) : 0;
      const pm = j.props('inventario') || {};
      const verVida = pm.verVida !== false && j.vidaMax, verArm = pm.verArmadura !== false && j.armaduraMax > 0;
      const arm = verArm ? Math.max(0, Math.round((j.armadura / j.armaduraMax) * 100)) : 0;
      const arma = j.armas && j.armas[j.armaActual];
      const titulo = this.baulAbierto ? 'BAÚL' : 'INVENTARIO';
      const libres = inv.estilo === 'casillas' ? `${inv.ocupadas()} / ${inv.n} casillas` : `${inv.items.length} objetos`;
      const izquierda = this.baulAbierto
        ? `<div class="fi-dos"><div class="fi-lado${this.lado === 'mochila' ? ' fi-activo' : ''}"><h3>MOCHILA</h3>${pintarLado(inv.items.filter ? inv.items : [], 'mochila')}</div>` +
          `<div class="fi-lado${this.lado === 'baul' ? ' fi-activo' : ''}"><h3>BAÚL</h3>${pintarLado(inv.baul, 'baul')}</div></div>`
        : pintarLado(inv.items, 'mochila');
      this.cajaEl.classList.toggle('fi-con-baul', this.baulAbierto);
      this.cajaEl.innerHTML =
        `<h2>${titulo}<small>${libres}</small></h2>` +
        `<div>${izquierda}</div>` +
        `<div class="fi-ficha">` + this._divisasHtml(h) +
          `<div class="fi-estado">${verVida ? `♥ <div class="fi-barra"><div style="width:${vida}%"></div></div>` : ''}` +
          `${verArm ? `⛨ <div class="fi-barra"><div style="width:${arm}%;background:#3a86e0"></div></div>` : ''}${arma ? `<span>${h(arma.def.nombre)}${arma.def.cargador > 0 ? ' · ' + arma.cargador + '/' + arma.def.cargador : ''}</span>` : ''}</div>` +
          `<div class="fi-grande" style="color:${d ? d.color : 'inherit'}">${d ? h(d.icono) : ''}</div>` +
          `<div class="fi-nombre">${d ? h(d.nombre) + (it.k !== 'arma' && it.n > 1 ? ' ×' + it.n : '') : ''}</div>` +
          `<div class="fi-desc">${d ? h(d.descripcion) : ''}</div>` +
          `<div class="fi-acc">${acc.map(([k, t], i) => `<button data-acc="${k}" class="${i === this.acc ? 'fi-sel' : ''}">${h(t)}</button>`).join('')}</div>` +
          `<div class="fi-aviso">${h(this.aviso)}</div>` +
        `</div>` +
        `<div class="fi-pie"><span>Flechas: elegir · E: ${this.modo === 'combinar' ? 'combinar con este' : this.modo === 'mover' ? 'dejarlo aquí' : 'acciones'} · R: ordenar · Q: volver</span>` +
        `${this.baulAbierto ? '' : '<button data-ordenar="1">Ordenar (R)</button>'}<button data-cerrar="1">Cerrar (Tab)</button></div>`;
      // 💰 divisas al baúl (todo de golpe)
      const D = F.Divisas, bd = inv.baulDivisas || (inv.baulDivisas = {});
      this.cajaEl.querySelectorAll('[data-dv-guardar]').forEach((x) => { x.onclick = () => { const id = x.dataset.dvGuardar, n = D.tiene(j, id); if (n > 0) { bd[id] = (bd[id] || 0) + n; D.poner(j, id, 0); this.aviso = 'Guardado en el baúl'; } this.pintar(); }; });
      this.cajaEl.querySelectorAll('[data-dv-sacar]').forEach((x) => { x.onclick = () => { const id = x.dataset.dvSacar, n = bd[id] || 0; if (n > 0) { const antes = D.tiene(j, id), queda = D.poner(j, id, antes + n) - antes; bd[id] = n - queda; this.aviso = 'Sacado'; } this.pintar(); }; });
      // ratón / toque
      this.cajaEl.querySelectorAll('[data-i]').forEach((x) => {
        x.onclick = () => {
          const i = +x.dataset.i;
          if (this.baulAbierto) this.lado = x.dataset.lado;
          if (this.modo === 'combinar') { this._combinarCon(i); return; }
          if (this.modo === 'mover') { this._moverA(i); return; }
          if (this.sel === i && this.actual()) { this.modo = 'acciones'; this.acc = 0; } else { this.sel = i; this.modo = 'elegir'; }
          this.pintar();
        };
      });
      this.cajaEl.querySelectorAll('[data-acc]').forEach((x) => { x.onclick = () => this.hacer(x.dataset.acc); });
      const bo = this.cajaEl.querySelector('[data-ordenar]');
      if (bo) bo.onclick = () => this.ordenarMochila();
      const bc = this.cajaEl.querySelector('[data-cerrar]');
      if (bc) bc.onclick = () => this.cerrar();
    }

    quitar() {
      if (this.r3) { this.r3.dispose(); this.r3 = null; }
      if (this.el) this.el.remove();
      this.el = null;
    }
  }

  F.Inventario = Inventario;
  F.InventarioUI = InventarioUI;
  Inventario.OBJETO = OBJETO;
  Inventario.objetoNuevo = objetoNuevo;
  Inventario.objetosPorDefecto = objetosPorDefecto;
  Inventario.recetasPorDefecto = recetasPorDefecto;
  Inventario.figuraObjeto = figuraObjeto;
  Inventario.figuraBaul = figuraBaul;
  // modo: 'compartido' (Resident Evil: lo que guardas en uno sale en todos) | 'premio' (se abre una vez y da su contenido)
  // contenido (premio): [{ tipo: 'vida' | 'armadura' | 'municion' | 'arma' | 'objeto', cantidad, municionTipo, arma, objeto }]
  Inventario.BAUL = { color: '#7a5636', modo: 'compartido', contenido: [] };
})(window.FORJA);
