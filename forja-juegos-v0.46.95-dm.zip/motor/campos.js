/* =========================================================
   FORJA · ⬡ CAMPOS DE ENERGÍA
   Una esfera MUY low poly (icosaedro de 80 caras, caras planas) con un material transparente que brilla más
   en los bordes (como una burbuja) y dos estilos a elegir:
     · 'ondas': ondas que recorren la superficie
     · 'hex':   rejilla de hexágonos que se iluminan por zonas
     · 'rayos': arcos eléctricos que saltan · 'anillos': aros que suben · 'plasma': manchas que fluyen
   Al recibir un golpe, destello y un anillo que se abre desde ese punto. Mezcla aditiva y sin escribir
   profundidad: no tapa lo de detrás ni hay que ordenarlo. Todo se mueve en la GPU (uTiempo compartido).

   Se usa en:
     · 🛡 hechizo escudo (arma tipo 'escudo', jugador/modulos/armas.js)
     · 🛡 burbuja del escudo de energía del jugador (jugador/modulos/salud.js, armadura tipo escudo)
     · ⬡ entidad BARRERA del nivel (esfera, cúpula o muro) que bloquea el paso y se apaga con palancas

   F.Campo.crear({ forma, estilo, color, fuerza }) → { malla, fuerza(v, segundos), golpe(puntoMundo), color(c) }
   ========================================================= */
(function (F) {
  'use strict';
  const T = THREE;

  const ESTILOS = [['ondas', '〰 Ondas + borde brillante'], ['hex', '⬡ Rejilla de hexágonos'], ['rayos', '⚡ Rayos eléctricos'], ['anillos', '◎ Anillos que recorren'], ['plasma', '🔥 Plasma que fluye']];
  const N_ESTILO = { ondas: 0, hex: 1, rayos: 2, anillos: 3, plasma: 4 };

  // geometrías compartidas (radio 1 / lado 1), hechas una vez
  const GEO = {};
  function geometria(forma) {
    if (GEO[forma]) return GEO[forma];
    let g;
    if (forma === 'cupula') g = new T.SphereGeometry(1, 10, 5, 0, Math.PI * 2, 0, Math.PI / 2);     // media esfera, pocas caras
    else if (forma === 'muro') { g = new T.PlaneGeometry(1, 1, 6, 6); g.translate(0, 0.5, 0); }        // panel de 1×1, apoyado en el suelo
    else g = new T.IcosahedronGeometry(1, 1);                                                             // 80 caras
    if (g.index) g = g.toNonIndexed();
    GEO[forma] = g;
    return g;
  }

  const VERT = `
    varying vec3 vMundo;
    varying vec3 vLocal;
    void main() {
      vLocal = position;
      vec4 m = modelMatrix * vec4(position, 1.0);
      vMundo = m.xyz;
      gl_Position = projectionMatrix * viewMatrix * m;
    }`;
  const FRAG = `
    uniform float uTiempo, uFuerza, uEstilo, uGolpeK, uPlano;
    uniform vec3 uColor, uGolpe;
    varying vec3 vMundo;
    varying vec3 vLocal;
    float azar(vec2 p) { return fract(sin(dot(p, vec2(12.9898, 78.233))) * 43758.5453); }
    // distancia al borde de la celda hexagonal (0 = borde) y el id de la celda
    vec3 hexa(vec2 p) {
      const vec2 r = vec2(1.0, 1.7320508);
      vec2 h = r * 0.5;
      vec2 a = mod(p, r) - h, b = mod(p - h, r) - h;
      vec2 g = dot(a, a) < dot(b, b) ? a : b;
      vec2 id = p - g;
      vec2 q = abs(g);
      float borde = 0.5 - max(dot(q, normalize(vec2(1.0, 1.7320508))), q.x);
      return vec3(borde, id);
    }
    void main() {
      // cara plana (low poly) y lo de frente / de canto respecto a la cámara
      vec3 n = normalize(cross(dFdx(vMundo), dFdy(vMundo)));
      vec3 v = normalize(cameraPosition - vMundo);
      float canto = 1.0 - abs(dot(n, v));
      float fres = uPlano > 0.5 ? 0.25 : canto * canto;
      vec3 d = normalize(vLocal + vec3(0.0, uPlano > 0.5 ? 0.0 : 1e-4, 0.0));
      float dibujo;
      if (uEstilo < 0.5) {
        // 〰 ondas que suben y se cruzan
        float base = uPlano > 0.5 ? vLocal.y * 8.0 + vLocal.x * 2.0 : d.y * 7.0 + sin(atan(d.z, d.x) * 3.0 + uTiempo) * 0.8;
        float w = 0.5 + 0.5 * sin(base - uTiempo * 3.2);
        dibujo = smoothstep(0.72, 1.0, w) * 0.9;
      } else if (uEstilo > 1.5) {
        vec2 uv = uPlano > 0.5 ? vLocal.xy * 3.0 : vec2(atan(d.z, d.x) * 1.6, d.y * 2.6);
        if (uEstilo < 2.5) {
          // ⚡ rayos: dos arcos quebrados que saltan a saltos (tiempo en escalones) y parpadean
          float tq = floor(uTiempo * 12.0);
          float f1 = abs(sin(uv.x * 2.0 + sin(uv.y * 5.0 + tq * 1.7) * 1.4 + sin(uv.y * 13.0 - tq * 2.3) * 0.35));
          float f2 = abs(sin(uv.y * 2.4 + sin(uv.x * 4.0 - tq * 1.3) * 1.2 + sin(uv.x * 11.0 + tq * 0.9) * 0.3 + 1.7));
          float parpa = 0.55 + 0.45 * step(0.35, fract(sin(tq * 12.9898) * 43758.5));
          dibujo = ((1.0 - smoothstep(0.0, 0.07, f1)) + (1.0 - smoothstep(0.0, 0.06, f2)) * 0.8) * parpa;
        } else if (uEstilo < 3.5) {
          // ◎ anillos: aros que suben por la esfera + meridianos tenues
          float y = uPlano > 0.5 ? vLocal.y : d.y;
          float w = fract(y * 2.2 - uTiempo * 0.9);
          float m = uPlano > 0.5 ? abs(fract(vLocal.x * 3.0) - 0.5) : abs(fract(atan(d.z, d.x) * 0.9549 + uTiempo * 0.05) - 0.5);
          dibujo = smoothstep(0.82, 0.97, w) * (1.0 - smoothstep(0.97, 1.0, w)) * 1.4 + (1.0 - smoothstep(0.0, 0.03, 0.5 - m)) * 0.35;
        } else {
          // 🔥 plasma: manchas que fluyen (suma de senos, muy barato)
          vec3 p = (uPlano > 0.5 ? vec3(vLocal.xy * 3.0, 0.0) : d * 3.0);
          float v = sin(p.x * 3.0 + uTiempo * 1.1) + sin(p.y * 4.0 - uTiempo * 1.4) + sin(p.z * 3.0 + uTiempo * 0.8) + sin((p.x + p.y + p.z) * 2.5 + uTiempo * 1.9);
          v = 0.5 + 0.5 * sin(v * 2.0);
          dibujo = smoothstep(0.45, 1.0, v) * 0.75 + smoothstep(0.93, 1.0, v) * 0.6;
        }
      } else {
        // ⬡ hexágonos: bordes finos y celdas que se encienden al azar
        vec2 uv = uPlano > 0.5 ? vLocal.xy * 6.0 : vec2(atan(d.z, d.x) * 2.2, d.y * 4.2);
        vec3 h = hexa(uv);
        float linea = 1.0 - smoothstep(0.0, 0.07, h.x);
        float celda = step(0.86, fract(azar(h.yz) + uTiempo * 0.35)) * 0.45;
        dibujo = linea * 0.8 + celda;
      }
      // 💥 golpe: destello alrededor del punto y un anillo que se abre
      float golpe = 0.0;
      if (uGolpeK > 0.0) {
        float a = uPlano > 0.5 ? length(vLocal.xy - uGolpe.xy) * 2.0 : acos(clamp(dot(d, uGolpe), -1.0, 1.0));
        golpe = (1.0 - smoothstep(0.0, 0.7, a)) * uGolpeK;
        float r = (1.0 - uGolpeK) * 1.6;
        golpe += (1.0 - smoothstep(0.0, 0.12, abs(a - r))) * uGolpeK * 0.8;
      }
      float alfa = uFuerza * (0.1 + 0.75 * fres + 0.55 * dibujo + 1.2 * golpe);
      gl_FragColor = vec4(uColor * alfa, alfa);
    }`;

  /* Crea un campo. forma: 'esfera' | 'cupula' | 'muro'. La malla mide 1 (escálala); la fuerza va de 0 a 1 */
  function crear(op = {}) {
    const forma = op.forma || 'esfera';
    const u = {
      uTiempo: F.Render.U.uTiempo,
      uFuerza: { value: op.fuerza ?? 1 }, uEstilo: { value: N_ESTILO[op.estilo] || 0 },
      uColor: { value: new T.Color(op.color || '#5fd0ff') }, uGolpe: { value: new T.Vector3(0, 1, 0) }, uGolpeK: { value: 0 },
      uPlano: { value: forma === 'muro' ? 1 : 0 },
    };
    const mat = new T.ShaderMaterial({ uniforms: u, vertexShader: VERT, fragmentShader: FRAG, transparent: true, depthWrite: false,
      side: T.DoubleSide, blending: T.AdditiveBlending });
    const malla = new T.Mesh(geometria(forma), mat);
    malla.renderOrder = 6;
    malla.userData.esCampo = true;
    // fuerza y golpe se animan justo antes de dibujar (también en el editor y en cinemáticas)
    const st = { meta: u.uFuerza.value, vel: 0, golpeT0: -1, ult: performance.now() };
    malla.onBeforeRender = () => {
      const ahora = performance.now(), dt = Math.min(0.1, (ahora - st.ult) / 1000);
      st.ult = ahora;
      const f = u.uFuerza;
      if (f.value !== st.meta) f.value = st.vel > 0 ? (f.value < st.meta ? Math.min(st.meta, f.value + dt * st.vel) : Math.max(st.meta, f.value - dt * st.vel)) : st.meta;
      if (st.golpeT0 >= 0) {
        const k = 1 - (ahora - st.golpeT0) / 450;
        u.uGolpeK.value = Math.max(0, k);
        if (k <= 0) st.golpeT0 = -1;
      }
    };
    const _inv = new T.Matrix4(), _p = new T.Vector3();
    return {
      malla,
      // 0..1 en "segundos" (0 = de golpe)
      fuerza(v, segundos = 0) { st.meta = v; st.vel = segundos > 0 ? 1 / segundos : 0; if (!(segundos > 0)) u.uFuerza.value = v; },
      valor() { return u.uFuerza.value; },
      // destello donde pegó (punto en el mundo; sin punto, en un sitio al azar)
      golpe(punto) {
        if (punto) {
          malla.updateMatrixWorld(true);
          _p.copy(punto).applyMatrix4(_inv.copy(malla.matrixWorld).invert());
          if (forma === 'muro') u.uGolpe.value.set(_p.x, _p.y, 0); else u.uGolpe.value.copy(_p).normalize();
        } else u.uGolpe.value.set(Math.random() - 0.5, Math.random() * 0.5, Math.random() - 0.5).normalize();
        st.golpeT0 = performance.now();
      },
      color(c) { u.uColor.value.set(c); },
      estilo(e) { u.uEstilo.value = N_ESTILO[e] || 0; },
    };
  }

  /* ---------- ⬡ Entidad BARRERA (escala = tamaño) ---------- */
  const BARRERA = { forma: 'cupula', estilo: 'ondas', color: '#5fd0ff', fuerza: 0.8, activa: true, sonido: true };
  const ESQ_BARRERA = [
    { k: 'forma', t: 'sel', e: 'Forma', def: 'cupula', op: [['cupula', '◓ Cúpula'], ['esfera', '⬤ Esfera'], ['muro', '▮ Muro (plano)']],
      ayuda: 'Su tamaño es la escala (R): ancho × alto × fondo. Bloquea el paso mientras está encendida' },
    { k: 'estilo', t: 'sel', e: 'Aspecto', def: 'ondas', op: ESTILOS },
    { k: 'color', t: 'color', e: 'Color', def: '#5fd0ff' },
    { k: 'fuerza', t: 'rango', e: 'Brillo', def: 0.8, min: 0.1, max: 1.5, paso: 0.05 },
    { k: 'activa', t: 'bool', e: 'Encendida al empezar', def: true, ayuda: 'Se apaga / enciende con una palanca, disparador o cinemática (acción ⬡ Barrera)' },
    { k: 'sonido', t: 'bool', e: 'Zumbido al encender / apagar', def: true },
  ];

  function figuraBarrera(ent) {
    const b = { ...BARRERA, ...(ent.barrera || {}) };
    const g = new T.Group();
    const c = crear({ forma: b.forma, estilo: b.estilo, color: b.color, fuerza: b.fuerza });
    // la geometría mide 1 de radio: la escala de la entidad es el tamaño completo
    if (b.forma === 'muro') c.malla.scale.set(1, 1, 1);
    else if (b.forma === 'cupula') c.malla.scale.set(0.5, 1, 0.5);   // el alto de la escala = alto de la cúpula
    else { c.malla.scale.setScalar(0.5); c.malla.position.y = 0.5; }
    g.add(c.malla);
    g.userData.campo = c;
    g.userData.fuerzaBarrera = b.fuerza;
    return g;
  }

  // ---------- al jugar: encender / apagar (con su colisión) ----------
  function encenderBarrera(juego, id, on) {
    const ent = juego.escena.entidades.find((e) => e.id === id);
    const g = juego.objetos.get(id);
    if (!ent || !g || !g.userData.campo) return;
    juego.barrerasOff = juego.barrerasOff || new Set();
    const estaba = !juego.barrerasOff.has(id);
    const quiere = on === 'alternar' ? !estaba : !!on;
    if (quiere === estaba) return;
    if (quiere) juego.barrerasOff.delete(id); else juego.barrerasOff.add(id);
    const b = { ...BARRERA, ...(ent.barrera || {}) };
    g.userData.campo.fuerza(quiere ? b.fuerza : 0, 0.5);
    if (b.sonido !== false) F.Audio.sintetico('disparo', { volumen: 0.3, tono: quiere ? 0.6 : 0.4 });
    if (juego.reconstruirColision) juego.reconstruirColision();
  }
  function prepararBarreras(juego) {
    let cambio = false;
    for (const e of juego.escena.entidades) {
      if (e.tipo !== 'barrera' || !e.barrera || e.barrera.activa !== false) continue;
      juego.barrerasOff = juego.barrerasOff || new Set();
      juego.barrerasOff.add(e.id);
      const g = juego.objetos.get(e.id);
      if (g && g.userData.campo) g.userData.campo.fuerza(0);
      cambio = true;
    }
    if (cambio && juego.reconstruirColision) juego.reconstruirColision();
  }

  F.Campo = { ESTILOS, crear, geometria, BARRERA, ESQ_BARRERA, figuraBarrera, encenderBarrera, prepararBarreras };
})(window.FORJA);
