/* =========================================================
   FORJA · AGUA
   Entidad 💧 'agua' (ent.agua = AGUA): una caja de 1×1×1 sobre el suelo que se agranda con la escala; su cara de
   arriba es la SUPERFICIE (figura del motor: textura retro de ondas que fluye sola por el shader, sin coste de CPU).
   juego.agua (una por partida):
     en(x, y, z)          → el volumen de agua que contiene ese punto (o null). Caja rápida + matriz inversa.
     superficie(vol)      → altura del agua (metros, mundo)
     actualizar(dt)       → efectos bajo el agua si la CÁMARA está dentro (tinte, niebla, sonido apagado),
                            daño por segundo si el agua quema (lava, ácido)
   Lo usan el módulo Nadar del jugador y los enemigos (nadan, se quedan en la orilla, o son acuáticos).
   La niebla bajo el agua no recompila shaders: si el nivel tiene agua y no tenía niebla, se crea una niebla
   "apagada" al empezar (lejísimos) y bajo el agua solo se cambian sus valores.
   ========================================================= */
(function (F) {
  'use strict';
  const T = THREE;

  /* Líquidos de serie: elegir uno pone sus valores (luego se pueden cambiar) */
  const LIQUIDOS = {
    agua: { nombre: '💧 Agua', color: '#2f6fa8', opacidad: 0.65, tinte: '#1d5a8a', niebla: 14, dano: 0, nadable: true, corriente: 0.04 },
    lava: { nombre: '🔥 Lava', color: '#ff6a1a', opacidad: 1, tinte: '#ff4a10', niebla: 2.5, dano: 60, nadable: false, corriente: 0.015 },
    acido: { nombre: '☣ Ácido', color: '#86d23a', opacidad: 0.8, tinte: '#4f9a1f', niebla: 5, dano: 15, nadable: true, corriente: 0.02 },
    // ☠ zona de peligro sin nada que se vea: gas, radiación, fuego invisible… (caminas normal y te va quitando vida)
    veneno: { nombre: '☠ Zona de peligro (gas, sin superficie)', color: '#7fd14a', opacidad: 0.1, tinte: '#4f7a2a', niebla: 9, dano: 10, nadable: false, corriente: 0.01, sonidoApagado: false, superficie: false },
  };
  // ¿qué líquido es una malla por el nombre de su material (o de la malla)? Creador de terrenos: "agua" / "agua_<pieza>"
  const sinTildes = (t) => String(t || '').toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g, '');
  function liquidoDeNombre(nombre) {
    const n = sinTildes(nombre);
    if (/lava|magma/.test(n)) return 'lava';
    if (/acido|acid|toxic|veneno/.test(n)) return 'acido';
    if (/agua|water|liquid|ocean|oceano|\blago|\brio\b|\bmar\b/.test(n)) return 'agua';
    return null;
  }

  const AGUA = {
    liquido: 'agua',         // 'agua' | 'lava' | 'acido' (pone los valores de serie de ese líquido)
    nadable: true,           // se nada dentro (la lava no: te quema y caminas por el fondo)
    color: '#2f6fa8',        // de la superficie
    opacidad: 0.65,
    textura: '',             // asset de textura propia ('' = ondas del motor)
    mosaico: 2,              // metros que ocupa la textura
    corriente: 0.04,         // lo que fluye la textura (0 = quieta)
    tinte: '#1d5a8a',        // color de la vista bajo el agua
    niebla: 14,              // metros que se ve bajo el agua
    sonidoApagado: true,
    dano: 0,                 // vida por segundo dentro (lava, ácido) · 0 = agua normal
    superficie: true,        // false: no se dibuja la superficie (zona de gas / peligro)
    nube: true,              // sin superficie: cubo translúcido del color (parece gas) · false = invisible
    nubeOpacidad: 0.22,
    nubeTramado: false,      // true: transparencia por tramado (PS1): opaca con puntos, sin mezclar colores
    olas: false,             // 🌊 la superficie sube y baja en olas (en la GPU)
    olaAltura: 0.4, olaLargo: 8, olaVel: 1.2, olaDir: 0,
    olasJuego: false,        // el juego también las nota: nadar, botes y enemigos suben y bajan con ellas
  };

  const ESQUEMA_AGUA = [
    { k: 'liquido', t: 'sel', e: 'Líquido', def: 'agua', op: Object.entries(LIQUIDOS).map(([k, v]) => [k, v.nombre]),
      ayuda: 'Pone los valores de serie de ese líquido: el agua se nada y ahoga poco a poco; la lava quema al instante' },
    { k: 'nadable', t: 'bool', e: 'Se nada dentro', def: true, av: true },
    { k: 'superficie', t: 'bool', e: 'Se ve la superficie', def: true, ayuda: 'Quítalo para una zona de peligro invisible (gas, radiación): solo daña y tiñe la vista' },
    { k: 'nube', t: 'bool', e: 'Se ve la nube', def: true, si: (v) => v.superficie === false, ayuda: 'Cubo translúcido del color del gas que respira despacio. Quítalo para que sea invisible' },
    { k: 'nubeOpacidad', t: 'rango', e: 'Densidad de la nube', def: 0.22, min: 0.05, max: 0.8, paso: 0.01, si: (v) => v.superficie === false && v.nube !== false },
    { k: 'nubeTramado', t: 'bool', e: 'Tramado PS1', def: false, si: (v) => v.superficie === false && v.nube !== false,
      ayuda: 'Transparencia por tramado como la PS1: la nube es opaca con un patrón de puntos. Más barata (sin mezclar colores) y más retro' },
    { grupo: 'Superficie', si: (v) => v.superficie !== false || v.nube !== false },
    { k: 'color', t: 'color', e: 'Color', def: '#2f6fa8', ayuda: 'De la superficie (o de la nube de gas)' },
    { k: 'opacidad', t: 'rango', e: 'Transparencia', def: 0.65, min: 0.1, max: 1, paso: 0.05, ayuda: '1 = opaca (lava, barro)', si: (v) => v.superficie !== false },
    { k: 'textura', t: 'asset', e: 'Textura', def: '', tipoAsset: 'textura', vacio: '(ondas del motor)', si: (v) => v.superficie !== false },
    { k: 'mosaico', t: 'num', e: 'Tamaño de la textura (m)', def: 2, paso: 0.25, min: 0.25, si: (v) => v.superficie !== false },
    { k: 'corriente', t: 'num', e: 'Movimiento de la textura', def: 0.04, paso: 0.01, ayuda: '0 = quieta. Más = río', si: (v) => v.superficie !== false },
    { k: 'olas', t: 'bool', e: '🌊 Oleaje', def: false, si: (v) => v.superficie !== false, ayuda: 'La superficie sube y baja en olas. Se dibuja partida en trozos de 1 m (máx. 64 × 64)' },
    { k: 'olaAltura', t: 'num', e: 'Altura de las olas (m)', def: 0.4, paso: 0.05, min: 0, si: (v) => v.superficie !== false && v.olas },
    { k: 'olaLargo', t: 'num', e: 'Largo de onda (m)', def: 8, paso: 0.5, min: 0.5, si: (v) => v.superficie !== false && v.olas },
    { k: 'olaVel', t: 'num', e: 'Velocidad (m/s)', def: 1.2, paso: 0.1, min: 0, si: (v) => v.superficie !== false && v.olas },
    { k: 'olaDir', t: 'rango', e: 'Dirección (°)', def: 0, min: 0, max: 360, paso: 5, si: (v) => v.superficie !== false && v.olas },
    { k: 'olasJuego', t: 'bool', e: 'El juego las nota (flotar)', def: false, si: (v) => v.superficie !== false && v.olas,
      ayuda: 'Nadando, en bote o los enemigos que nadan suben y bajan con las olas. Apagado = solo se ven (un poco más barato)' },
    { grupo: 'Dentro' },
    { k: 'tinte', t: 'color', e: 'Color de la vista', def: '#1d5a8a' },
    { k: 'niebla', t: 'num', e: 'Se ve hasta (m)', def: 14, paso: 1, min: 1 },
    { k: 'sonidoApagado', t: 'bool', e: 'Sonido apagado', def: true },
    { k: 'ondulacion', t: 'rango', e: 'Ondulación de la vista', def: 0.5, min: 0, max: 1, paso: 0.05,
      ayuda: 'Dentro, la imagen ondula como vista a través del agua. 0 = nada' },
    { grupo: 'Peligro' },
    { k: 'dano', t: 'num', e: 'Daño por segundo', def: 0, paso: 1, min: 0, ayuda: '0 = agua normal. Con daño: lava, ácido, agua helada' },
  ];

  /* ---------- Figura del motor: superficie con ondas retro (32 px, sin suavizar) ---------- */
  const texturas = new Map();
  function texOndas(color) {
    if (texturas.has(color)) return texturas.get(color);
    const c = document.createElement('canvas');
    c.width = c.height = 32;
    const g = c.getContext('2d');
    const base = new T.Color(color), claro = base.clone().lerp(new T.Color('#ffffff'), 0.35), oscuro = base.clone().multiplyScalar(0.75);
    g.fillStyle = '#' + base.getHexString(); g.fillRect(0, 0, 32, 32);
    // ondas: líneas cortas claras y oscuras en zigzag (se repiten sin costura)
    for (let fila = 0; fila < 4; fila++) {
      const y = fila * 8 + 2;
      for (let x = 0; x < 32; x++) {
        const dy = Math.round(Math.sin(((x + fila * 5) / 32) * Math.PI * 4) * 1.5);
        g.fillStyle = '#' + claro.getHexString(); g.fillRect(x, (y + dy + 32) % 32, 1, 1);
        g.fillStyle = '#' + oscuro.getHexString(); g.fillRect(x, (y + dy + 4 + 32) % 32, 1, 1);
      }
    }
    const t = new T.CanvasTexture(c);
    t.wrapS = t.wrapT = T.RepeatWrapping;
    t.magFilter = T.NearestFilter; t.minFilter = T.NearestFilter; t.colorSpace = T.SRGBColorSpace;
    texturas.set(color, t);
    return t;
  }

  // material de superficie del motor (ondas retro que fluyen en la GPU). La lava brilla sola.
  function materialLiquido(c) {
    const propia = c.textura && F.Assets && F.Assets.textura(c.textura, 'color');
    const tex = (propia || texOndas(c.color)).clone();
    tex.wrapS = tex.wrapT = T.RepeatWrapping;
    tex.needsUpdate = true;
    const opacidad = c.opacidad ?? 0.65;
    const mat = F.Render.hacerRetro(new T.MeshLambertMaterial({
      map: tex, color: propia ? c.color : '#ffffff', transparent: opacidad < 1, opacity: opacidad,
      depthWrite: opacidad >= 1, side: T.DoubleSide,
    }));
    if (c.liquido === 'lava') mat.emissive.set(c.color).multiplyScalar(0.75);
    mat.userData.uDesplazUV.value.set(c.corriente ?? 0.04, (c.corriente ?? 0.04) * 0.6);
    if (c.olas) F.Render.aplicarMovimiento(mat, c);   // 🌊 oleaje en la GPU
    return mat;
  }

  /* Mallas de líquido dentro de un MODELO (GLB del creador de terrenos, Blender…): se reconocen por el nombre del
     material. Se marcan (userData.esAgua = líquido) para que la física no las haga sólidas y Agua las use como
     superficie; con aspecto 'motor' llevan el material del motor con UV planas (la textura no se estira).
     ent.aguaModelo = AGUA_MODELO. Lo llama Escena.crearObjeto al crear el modelo (editor y juego). */
  const _n = new T.Vector3();
  const AGUA_MODELO = { activo: true, liquido: 'auto', aspecto: 'auto', mosaico: 2 };   // auto: si el agua trae textura se ve como la manda el modelo; si no, ondas del motor
  function marcarModelo(obj, ent) {
    const cfg = { ...AGUA_MODELO, ...(ent.aguaModelo || {}) };
    const mallas = [];
    obj.traverse((o) => {
      if (!o.isMesh || o.isSkinnedMesh) return;
      const m0 = Array.isArray(o.material) ? o.material[0] : o.material;
      // manda el nombre del material; el de la malla solo si el material no tiene nombre ("fondo_lava" no es lava)
      const tipo = m0 && m0.name ? liquidoDeNombre(m0.name) : liquidoDeNombre(o.name);
      if (tipo) mallas.push({ o, tipo });
    });
    obj.userData.liquidos = mallas.length ? mallas.map((x) => x.tipo) : null;
    if (!mallas.length || cfg.activo === false) return;
    obj.updateMatrixWorld(true);   // aún sin su transform de la escena: coordenadas del propio modelo
    const esc = ent.esc || [1, 1, 1], v = new T.Vector3();
    for (const { o, tipo } of mallas) {
      const liq = cfg.liquido === 'auto' || !LIQUIDOS[cfg.liquido] ? tipo : cfg.liquido;
      o.userData.esAgua = liq;
      const m0 = Array.isArray(o.material) ? o.material[0] : o.material;
      if (cfg.aspecto === 'modelo' || (cfg.aspecto === 'auto' && m0 && m0.map)) continue;
      // UV planas en metros (vista desde arriba) para que las ondas tengan el mismo tamaño en todo el lago
      const g = o.geometry.clone(), pos = g.attributes.position, nor = g.attributes.normal, uv = new Float32Array(pos.count * 2);
      for (let i = 0; i < pos.count; i++) {
        v.fromBufferAttribute(pos, i).applyMatrix4(o.matrixWorld);
        // caras verticales (cascadas, bordes): UV de lado (horizontal, altura) para que no salgan como rayas
        const ny = nor ? Math.abs(_n.fromBufferAttribute(nor, i).transformDirection(o.matrixWorld).y) : 1;
        uv[i * 2] = ((ny < 0.5 ? v.x * esc[0] + v.z * esc[2] : v.x * esc[0])) / (cfg.mosaico || 2);
        uv[i * 2 + 1] = ((ny < 0.5 ? v.y * esc[1] : v.z * esc[2])) / (cfg.mosaico || 2);
      }
      g.setAttribute('uv', new T.BufferAttribute(uv, 2));
      o.geometry = g;
      o.material = materialLiquido({ ...AGUA, ...LIQUIDOS[liq], liquido: liq });
      // 🌊 el movimiento que se le puso al material del modelo (oleaje, ondular…) se queda
      if (m0) { F.Render.copiarMovimiento(m0, o.material); o.material.userData.movCfg = m0.userData.movCfg || null; }
      o.renderOrder = 2;
    }
  }

  function figura(ent) {
    const c = { ...AGUA, ...(ent.agua || {}) };
    const g = new T.Group();
    // ayudas del editor: la caja del volumen
    const geo = new T.BoxGeometry(1, 1, 1);
    geo.translate(0, 0.5, 0);
    const bordes = new T.LineSegments(new T.EdgesGeometry(geo), new T.LineBasicMaterial({ color: 0x4fb3ff, transparent: true, opacity: 0.6, fog: false }));
    bordes.userData.ayudaEditor = true;
    g.add(bordes);
    // superficie (la cara de arriba de la caja): se ve al jugar
    const mat = materialLiquido(c), tex = mat.map;
    // con oleaje la superficie va partida en trozos de ~1 m para que pueda ondular
    const esc = ent.esc || [1, 1, 1], partes = (l) => (c.olas ? Math.min(64, Math.max(2, Math.ceil(Math.abs(l)))) : 1);
    const sup = new T.Mesh(new T.PlaneGeometry(1, 1, partes(esc[0]), partes(esc[2])).rotateX(-Math.PI / 2).translate(0, 1, 0), mat);
    sup.renderOrder = 2;
    sup.userData.superficieAgua = true;
    if (c.superficie === false) {
      sup.visible = false;   // ☠ zona sin superficie
      // ☁ nube de gas: la caja translúcida del color (1 dibujo, sin escribir profundidad); respira despacio
      if (c.nube !== false) {
        const base = c.nubeOpacidad ?? 0.22;
        const tram = !!c.nubeTramado;
        const mn = new T.MeshBasicMaterial({ color: c.color, transparent: !tram, opacity: base, depthWrite: tram, side: T.DoubleSide, fog: true });
        if (tram) {
          // ▦ tramado PS1: se queda solo una parte de los píxeles (patrón 4×4 fijo en pantalla); el resto se descarta
          mn.onBeforeCompile = (sh) => {
            sh.fragmentShader = 'float bayerTram(vec2 p) { p = floor(mod(p, 4.0)); float a = 2.0 * mod(p.x, 2.0) + 3.0 * mod(p.y, 2.0) - 4.0 * mod(p.x, 2.0) * mod(p.y, 2.0);' +
              ' vec2 q = floor(p / 2.0); float b = 2.0 * q.x + 3.0 * q.y - 4.0 * q.x * q.y; return (4.0 * a + b + 0.5) / 16.0; }\n' +
              sh.fragmentShader.replace('#include <alphatest_fragment>', 'if (bayerTram(gl_FragCoord.xy) > diffuseColor.a) discard;\ndiffuseColor.a = 1.0;');
          };
          mn.customProgramCacheKey = () => 'gas-tramado';
        }
        const nube = new T.Mesh(geo, mn);
        nube.renderOrder = 3;
        nube.userData.esAgua = true;
        nube.userData.nubeGas = true;
        nube.raycast = () => {};   // no estorba al elegir en el editor ni a los rayos
        nube.onBeforeRender = () => { mn.opacity = base * (0.85 + 0.15 * Math.sin(F.Render.U.uTiempo.value * 0.9)); };
        g.add(nube);
      }
    }
    // la textura se repite según el tamaño real de la caja (se recalcula si la escalas)
    let ultimo = '';
    sup.onBeforeRender = function () {
      const e = g.scale, clave = e.x.toFixed(2) + ',' + e.z.toFixed(2);
      if (clave === ultimo) return;
      ultimo = clave;
      tex.repeat.set(Math.max(0.05, e.x / c.mosaico), Math.max(0.05, e.z / c.mosaico));
    };
    g.add(sup);
    return g;
  }

  /* =========================================================
     EL AGUA DE UNA ESCENA EN JUEGO (juego.agua)
     ========================================================= */
  const _p = new T.Vector3();
  const PROF_CAJA = 40;
  // ¿este punto del editor queda dentro del agua de una caja 💧? (para avisar en el Inspector)
  function dentroDeCaja(objCaja, punto) {
    objCaja.updateWorldMatrix(true, false);
    const q = punto.clone().applyMatrix4(objCaja.matrixWorld.clone().invert());
    const alto = Math.max(0.01, objCaja.scale.y);
    return Math.abs(q.x) <= 0.5 && Math.abs(q.z) <= 0.5 && q.y <= 1 && q.y >= -PROF_CAJA / alto;
  }
  class Agua {
    constructor(juego) {
      this.juego = juego;
      this.lista = [];
      this.bajo = null;          // volumen en el que está la cámara (efectos encendidos)
      this.tDano = 0;
      for (const ent of juego.escena.entidades) {
        if (ent.tipo !== 'agua') continue;
        const obj = juego.objetos.get(ent.id);
        if (!obj) continue;
        obj.updateWorldMatrix(true, false);
        const m = obj.matrixWorld;
        const caja = new T.Box3();
        for (const x of [-0.5, 0.5]) for (const y of [0, 1]) for (const z of [-0.5, 0.5]) caja.expandByPoint(_p.set(x, y, z).applyMatrix4(m));
        // bajo la superficie cuenta como agua hasta 40 m de hondo (aunque la caja sea más baja: hoyos, piscinas hundidas)
        const alto = Math.max(0.01, caja.max.y - caja.min.y);
        caja.min.y -= PROF_CAJA;
        const c = { ...AGUA, ...(ent.agua || {}) };
        // 🌊 olas que el juego nota: la caja crece lo que suben las crestas
        const olas = c.olas && c.olasJuego && c.superficie !== false ? Math.max(0, c.olaAltura || 0) : 0;
        caja.max.y += olas * 0.75;
        this.lista.push({ ent, obj, c, inv: m.clone().invert(), caja, top: caja.max.y - olas * 0.75, top0: caja.max.y - olas * 0.75, fondoLocal: -PROF_CAJA / alto,
          olas, olaLocal: olas * 0.75 / alto });
      }
      // líquidos de los modelos (lagos y ríos del creador de terrenos): un mapa de alturas de su superficie
      for (const ent of juego.escena.entidades) {
        if (ent.tipo !== 'modelo') continue;
        const obj = juego.objetos.get(ent.id);
        if (!obj || !obj.userData.liquidos) continue;
        for (const liq of new Set(obj.userData.liquidos)) {
          const vol = this._mapaAlturas(ent, obj, liq);
          if (vol) this.lista.push(vol);
        }
      }
      // niebla "apagada" preparada (crear la niebla después obligaría a recompilar todos los shaders: tirón)
      const esc = juego.vista.escena, U = F.Render.U;
      this.niebla0 = esc.fog ? { color: esc.fog.color.clone(), near: esc.fog.near, far: esc.fog.far, cerca: U.uNieblaCerca.value, lejos: U.uNieblaLejos.value } : null;
      if (this.lista.length && !esc.fog) {
        esc.fog = new T.Fog(0x000000, 1e5, 1e5 + 1);
        this.nieblaCreada = true;
        this.cerca0 = U.uNieblaCerca.value; this.lejos0 = U.uNieblaLejos.value;
        U.uNieblaCerca.value = 1e5; U.uNieblaLejos.value = 1e5 + 1;
      }
      this.lados = [];
      try { this._lados(); } catch (e) { console.warn('[agua] lados', e); }
    }

    /* 🌊 Lados del agua (al jugar): las cajas 💧 solo dibujan la superficie (los lagos de los modelos ya traen sus caras). Por cada borde
       de la superficie se baja una "pared de agua" hasta el suelo que tiene debajo (rayo), en trozos de 1,5 m; los
       trozos pegados a una pared u orilla (rayo hacia fuera) no se ponen. Mismo material (se ve también por dentro). */
    _lados() {
      const M = this.juego.mundo;
      if (!M || !M.rayo) return;
      const bordes = [];   // { a, b, c (punto de dentro), vol }
      for (const v of this.lista) {
        if (v.ent.tipo === 'agua') {
          if (v.c.superficie === false) continue;
          const m = v.obj.matrixWorld, q = [[-0.5, -0.5], [0.5, -0.5], [0.5, 0.5], [-0.5, 0.5]].map(([x, z]) => new T.Vector3(x, 1, z).applyMatrix4(m));
          const c = new T.Vector3(0, 1, 0).applyMatrix4(m);
          for (let i = 0; i < 4; i++) bordes.push({ a: q[i], b: q[(i + 1) % 4], c, vol: v });
        } else if (v.malla && false) {   // los lagos de los modelos ya traen sus caras del generador
          // bordes de la malla: aristas que solo usa un triángulo (vértices soldados al centímetro)
          const aristas = new Map(), k = (p) => Math.round(p.x * 100) + ',' + Math.round(p.y * 100) + ',' + Math.round(p.z * 100);
          v.obj.traverse((o) => {
            if (!o.isMesh || o.userData.esAgua !== v.c.liquido) return;
            const pos = o.geometry.attributes.position, ind = o.geometry.index, n = ind ? ind.count : pos.count;
            for (let i = 0; i + 2 < n; i += 3) {
              const t = [0, 1, 2].map((j) => new T.Vector3().fromBufferAttribute(pos, ind ? ind.getX(i + j) : i + j).applyMatrix4(o.matrixWorld));
              const cx = (t[0].x + t[1].x + t[2].x) / 3, cz = (t[0].z + t[1].z + t[2].z) / 3;
              if (Math.abs((t[1].x - t[0].x) * (t[2].z - t[0].z) - (t[2].x - t[0].x) * (t[1].z - t[0].z)) < 1e-6) continue;   // vertical
              for (let j = 0; j < 3; j++) {
                const a = t[j], b = t[(j + 1) % 3], ka = k(a), kb = k(b), clave = ka < kb ? ka + '|' + kb : kb + '|' + ka;
                const x = aristas.get(clave);
                if (x) x.n++; else aristas.set(clave, { n: 1, a, b, c: new T.Vector3(cx, (a.y + b.y) / 2, cz) });
              }
            }
          });
          for (const x of aristas.values()) if (x.n === 1) bordes.push({ a: x.a, b: x.b, c: x.c, vol: v });
        }
      }
      if (!bordes.length || bordes.length > 4000) return;
      const porVol = new Map(), P = new T.Vector3(), Q = new T.Vector3();
      const fondo = (x, y, z) => { const r = M.rayo(x, y - 0.05, z, 0, -1, 0, 40); return r ? y - 0.05 - r.t - 0.02 : y - 3; };
      for (const { a, b, c, vol } of bordes) {
        const dx = b.x - a.x, dz = b.z - a.z, largo = Math.hypot(dx, dz);
        if (largo < 0.05) continue;
        let ox = dz / largo, oz = -dx / largo;   // hacia fuera (lejos del punto de dentro)
        if (ox * (c.x - a.x) + oz * (c.z - a.z) > 0) { ox = -ox; oz = -oz; }
        const n = Math.ceil(largo / 1.5), mos = vol.c.mosaico || 2;
        for (let i = 0; i < n; i++) {
          P.lerpVectors(a, b, i / n); Q.lerpVectors(a, b, (i + 1) / n);
          const mx = (P.x + Q.x) / 2, my = (P.y + Q.y) / 2, mz = (P.z + Q.z) / 2;
          if (M.rayo(mx - ox * 0.1, my - 0.15, mz - oz * 0.1, ox, 0, oz, 0.4)) continue;   // pegado a una pared / orilla
          const f0 = fondo(P.x - ox * 0.1, P.y, P.z - oz * 0.1), f1 = fondo(Q.x - ox * 0.1, Q.y, Q.z - oz * 0.1);
          if (P.y - f0 < 0.05 && Q.y - f1 < 0.05) continue;
          let L = porVol.get(vol);
          if (!L) porVol.set(vol, (L = { pos: [], uv: [] }));
          const u0 = (largo * i / n) / mos, u1 = (largo * (i + 1) / n) / mos;
          L.pos.push(P.x, P.y, P.z, Q.x, Q.y, Q.z, Q.x, f1, Q.z, P.x, P.y, P.z, Q.x, f1, Q.z, P.x, f0, P.z);
          L.uv.push(u0, P.y / mos, u1, Q.y / mos, u1, f1 / mos, u0, P.y / mos, u1, f1 / mos, u0, f0 / mos);
        }
      }
      const esc = this.juego.vista.escena;
      for (const [vol, L] of porVol) {
        const g = new T.BufferGeometry();
        g.setAttribute('position', new T.Float32BufferAttribute(L.pos, 3));
        g.setAttribute('uv', new T.Float32BufferAttribute(L.uv, 2));
        g.computeVertexNormals();
        const malla = new T.Mesh(g, materialLiquido(vol.c));
        malla.name = 'forja_lados_agua';
        malla.renderOrder = 2;
        malla.userData.esAgua = vol.c.liquido || 'agua';
        esc.add(malla);
        this.lados.push(malla);
      }
    }

    /* Superficie de las mallas de un líquido rasterizada en celdas (altura máxima por celda). Se hace una vez al
       empezar; luego saber si un punto está dentro cuesta una resta y una lectura (nada de rayos contra la malla). */
    _mapaAlturas(ent, obj, liq) {
      obj.updateMatrixWorld(true);
      const tri = [], a = new T.Vector3(), b = new T.Vector3(), c = new T.Vector3();
      let x0 = Infinity, z0 = Infinity, x1 = -Infinity, z1 = -Infinity, yMin = Infinity, yMax = -Infinity;
      let olaCfg = null;
      obj.traverse((o) => {
        if (!o.isMesh || o.userData.esAgua !== liq) return;
        // 🌊 su material tiene oleaje que el juego nota (Movimiento ▸ Oleaje ▸ "El juego las nota")
        const mo = (Array.isArray(o.material) ? o.material[0] : o.material);
        if (!olaCfg && mo && mo.userData.movCfg && mo.userData.movCfg.olasJuego) olaCfg = mo.userData.movCfg;
        const pos = o.geometry.attributes.position, ind = o.geometry.index, n = ind ? ind.count : pos.count;
        for (let i = 0; i + 2 < n; i += 3) {
          for (const [k, vv] of [[0, a], [1, b], [2, c]]) {
            vv.fromBufferAttribute(pos, ind ? ind.getX(i + k) : i + k).applyMatrix4(o.matrixWorld);
            x0 = Math.min(x0, vv.x); x1 = Math.max(x1, vv.x); z0 = Math.min(z0, vv.z); z1 = Math.max(z1, vv.z);
            yMin = Math.min(yMin, vv.y); yMax = Math.max(yMax, vv.y);
          }
          tri.push(a.x, a.y, a.z, b.x, b.y, b.z, c.x, c.y, c.z);
        }
      });
      if (!tri.length) return null;
      const area = Math.max(1, (x1 - x0) * (z1 - z0));
      const celda = Math.max(0.5, Math.sqrt(area / 250000));   // como mucho ~250.000 celdas (1 MB)
      const nx = Math.ceil((x1 - x0) / celda) + 1, nz = Math.ceil((z1 - z0) / celda) + 1;
      const h = new Float32Array(nx * nz).fill(-Infinity);
      const marcar = (ix, iz, y) => { if (ix >= 0 && iz >= 0 && ix < nx && iz < nz) { const i = ix + iz * nx; if (y > h[i]) h[i] = y; } };
      for (let t = 0; t < tri.length; t += 9) {
        const ax = tri[t], ay = tri[t + 1], az = tri[t + 2], bx = tri[t + 3], by = tri[t + 4], bz = tri[t + 5], cx = tri[t + 6], cy = tri[t + 7], cz = tri[t + 8];
        // los vértices marcan su celda (triángulos más pequeños que una celda no dejan huecos)
        marcar(Math.floor((ax - x0) / celda), Math.floor((az - z0) / celda), ay);
        marcar(Math.floor((bx - x0) / celda), Math.floor((bz - z0) / celda), by);
        marcar(Math.floor((cx - x0) / celda), Math.floor((cz - z0) / celda), cy);
        const d = (bz - cz) * (ax - cx) + (cx - bx) * (az - cz);
        if (Math.abs(d) < 1e-9) continue;   // triángulo vertical (orilla): no es superficie
        // cascadas y cantos (caras de lado, aunque estén algo inclinadas): no son superficie, solo se ven
        { const ux = bx - ax, uy = by - ay, uz = bz - az, vx = cx - ax, vy = cy - ay, vz = cz - az;
          const nx_ = uy * vz - uz * vy, ny_ = uz * vx - ux * vz, nz_ = ux * vy - uy * vx;
          if (Math.abs(ny_) < 0.5 * Math.hypot(nx_, ny_, nz_)) continue; }
        const ix0 = Math.floor((Math.min(ax, bx, cx) - x0) / celda), ix1 = Math.floor((Math.max(ax, bx, cx) - x0) / celda);
        const iz0 = Math.floor((Math.min(az, bz, cz) - z0) / celda), iz1 = Math.floor((Math.max(az, bz, cz) - z0) / celda);
        for (let iz = iz0; iz <= iz1; iz++) {
          const pz = z0 + (iz + 0.5) * celda;
          for (let ix = ix0; ix <= ix1; ix++) {
            const px = x0 + (ix + 0.5) * celda;
            const l1 = ((bz - cz) * (px - cx) + (cx - bx) * (pz - cz)) / d, l2 = ((cz - az) * (px - cx) + (ax - cx) * (pz - cz)) / d, l3 = 1 - l1 - l2;
            if (l1 < -0.02 || l2 < -0.02 || l3 < -0.02) continue;
            marcar(ix, iz, l1 * ay + l2 * by + l3 * cy);
          }
        }
      }
      const PROF = 40;   // hasta cuánto por debajo de la superficie cuenta como "dentro" (bajo un lago no hay otro lago)
      const caja = new T.Box3(new T.Vector3(x0, yMin - PROF, z0), new T.Vector3(x1, yMax, z1));
      if (olaCfg) caja.max.y += olaCfg.olaAltura * 0.75;   // las crestas suben por encima
      return { ent, obj, malla: { x0, z0, celda, nx, nz, h, prof: PROF }, c: { ...AGUA, ...LIQUIDOS[liq], liquido: liq }, caja, top: yMax, olaCfg };
    }

    // ¿qué agua contiene este punto? (cajas 💧 y líquidos de modelos)
    en(x, y, z) {
      for (const v of this.lista) {
        const b = v.caja;
        if (x < b.min.x || x > b.max.x || y < b.min.y || y > b.max.y || z < b.min.z || z > b.max.z) continue;
        if (v.malla) {
          const M = v.malla, ix = Math.floor((x - M.x0) / M.celda), iz = Math.floor((z - M.z0) / M.celda);
          if (ix < 0 || iz < 0 || ix >= M.nx || iz >= M.nz) continue;
          let hh = M.h[ix + iz * M.nx];
          if (v.olaCfg && hh > -Infinity) hh += F.Render.alturaOla(v.olaCfg, x, z);   // 🌊 sube y baja con las olas
          if (hh > -Infinity && y <= hh && y >= this._fondo(v, M.x0 + (ix + 0.5) * M.celda, M.z0 + (iz + 0.5) * M.celda, hh, M.prof)) { v.top = hh; return v; }
          continue;
        }
        _p.set(x, y, z).applyMatrix4(v.inv);
        if (v.olas) {
          // 🌊 la superficie en este punto: la misma cuenta que el shader (sube y baja con las olas)
          v.top = v.top0 + F.Render.alturaOla(v.c, x, z);
          if (Math.abs(_p.x) <= 0.5 && Math.abs(_p.z) <= 0.5 && _p.y >= (v.fondoLocal ?? 0) && y <= v.top) {
            if (_p.y < 0 && y < this._fondo(v, x, z, v.top0, PROF_CAJA)) continue;
            return v;
          }
          continue;
        }
        if (Math.abs(_p.x) <= 0.5 && Math.abs(_p.z) <= 0.5 && _p.y >= (v.fondoLocal ?? 0) && _p.y <= 1) {
          // por debajo de la caja solo cuenta hasta el primer suelo (hoyo, piscina hundida), no la sala de abajo
          if (_p.y < 0 && y < this._fondo(v, x, z, v.top, PROF_CAJA)) continue;
          return v;
        }
      }
      return null;
    }

    /* Fondo del agua en (x, z): el primer suelo que hay bajo la superficie (rayo contra la colisión, una vez por sitio).
       Sin esto, un lago del piso 2 "mojaba" la sala del piso 1 que tiene debajo. Sin suelo: prof metros */
    _fondo(v, x, z, top, prof) {
      const k = Math.round(x * 2) * 100003 + Math.round(z * 2);
      v.fondos = v.fondos || new Map();
      let f = v.fondos.get(k);
      if (f === undefined) {
        const M = this.juego.mundo;
        const r = M && M.rayo ? M.rayo(x, top - 0.05, z, 0, -1, 0, prof) : null;
        f = r ? top - 0.05 - r.t - 0.3 : top - prof;   // 0,3 m por debajo del fondo: de pie en el fondo sigues dentro
        if (M) v.fondos.set(k, f);
      }
      return f;
    }

    superficie(v) { return v ? v.top : -Infinity; }

    actualizar(dt) {
      if (!this.lista.length) return;
      // efectos si la cámara está bajo el agua
      const cam = this.juego.camara;
      _p.setFromMatrixPosition(cam.matrixWorld);
      const v = this.en(_p.x, _p.y, _p.z);
      if (v !== this.bajo) this._efectos(v);
      // agua que quema (lava, ácido): al jugador si tiene los pies dentro
      const j = this.juego.jugador;
      if (j && !j.muerto && j.danar) {
        const P = j.cuerpo.pie, w = this.en(P.x, P.y + 0.2, P.z);
        if (w && w.c.dano > 0) {
          if (!this.tocando) this.tDano = 0.5;   // al entrar quema al instante (lava); luego cada medio segundo
          this.tocando = true;
          this.tDano += dt;
          if (this.tDano >= 0.5) { j.danar(w.c.dano * 0.5, w.c.liquido === 'lava' ? 'lava' : w.c.liquido === 'veneno' ? 'veneno' : 'agua'); this.tDano = 0; }
        } else { this.tDano = 0; this.tocando = false; }
      }
    }

    _efectos(v) {
      const esc = this.juego.vista.escena, U = F.Render.U;
      if (!this.capa) {
        this.capa = document.createElement('div');
        this.capa.style.cssText = 'position:absolute;inset:0;pointer-events:none;z-index:15;mix-blend-mode:multiply;display:none';
        const cont = this.juego.vista.contenedor;
        if (getComputedStyle(cont).position === 'static') cont.style.position = 'relative';
        cont.appendChild(this.capa);
      }
      if (v) {
        if (!this.bajo) this.guardado = { color: esc.fog.color.clone(), near: esc.fog.near, far: esc.fog.far, cerca: U.uNieblaCerca.value, lejos: U.uNieblaLejos.value };
        esc.fog.color.set(v.c.tinte);
        esc.fog.near = 0.5; esc.fog.far = v.c.niebla;
        U.uNieblaCerca.value = 0.5; U.uNieblaLejos.value = v.c.niebla;
        this.capa.style.background = new T.Color(v.c.tinte).lerp(new T.Color('#ffffff'), 0.45).getStyle();
        this.capa.style.display = 'block';
        F.Audio.bajoAgua = !!v.c.sonidoApagado;
        F.Audio.aplicarVolumen();
      } else if (this.guardado) {
        const g = this.guardado;
        esc.fog.color.copy(g.color); esc.fog.near = g.near; esc.fog.far = g.far;
        U.uNieblaCerca.value = g.cerca; U.uNieblaLejos.value = g.lejos;
        this.capa.style.display = 'none';
        F.Audio.bajoAgua = false;
        F.Audio.aplicarVolumen();
      }
      // 💥 la imagen ondula (motor/efectos.js)
      if (F.Efectos) F.Efectos.momento(this.juego.vista, 'onda', v ? (v.c.ondulacion ?? 0.5) : 0);
      this.bajo = v;
      F.emitir('camara-agua', { juego: this.juego, dentro: !!v });
    }

    detener() {
      if (this.bajo) this._efectos(null);
      if (this.capa) this.capa.remove();
      this.capa = null;
      const esc = this.juego.vista.escena, U = F.Render.U;
      if (this.nieblaCreada) { esc.fog = null; U.uNieblaCerca.value = this.cerca0; U.uNieblaLejos.value = this.lejos0; }
      F.Audio.bajoAgua = false;
      if (F.Efectos) F.Efectos.momento(this.juego.vista, 'onda', 0);
      for (const m of this.lados || []) { m.parent && m.parent.remove(m); m.geometry.dispose(); m.material.dispose(); }
      this.lados = [];
    }
  }

  Agua.AGUA = AGUA;
  Agua.LIQUIDOS = LIQUIDOS;
  Agua.AGUA_MODELO = AGUA_MODELO;
  Agua.marcarModelo = marcarModelo;
  Agua.liquidoDeNombre = liquidoDeNombre;
  Agua.dentroDeCaja = dentroDeCaja;
  Agua.ESQUEMA_AGUA = ESQUEMA_AGUA;
  Agua.figura = figura;
  F.Agua = Agua;
})(window.FORJA);
