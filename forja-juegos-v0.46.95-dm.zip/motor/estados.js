/* =========================================================
   FORJA · EFECTOS DE ESTADO (quemado, envenenado, congelado, aturdido, lento)
   Salen del TIPO DE DAÑO del golpe (fuego → quemado, veneno → envenenado, hielo → congelado, eléctrico → aturdido)
   o del campo "efecto" del arma / del enemigo. Sirven para enemigos y para el jugador.
   · Enemigo: motor/enemigos.js llama a Estados.enemigo(G, E, ...) al recibir daño y Estados.ticEnemigo cada cuadro
     (solo si tiene alguno: E.est). Si su resistencia a ese tipo es 0, es inmune.
   · Jugador: salud.js llama a Estados.jugador(j, ...) al recibir daño de un enemigo y Estados.ticJugador cada cuadro.
     j.lentoEstado multiplica su velocidad (movimiento.js). HUD: pieza 'fh-estados' junto a la vida.
   ========================================================= */
(function (F) {
  'use strict';

  const ESTADOS = {
    quemado:    { nombre: 'Quemado',    icono: '🔥', seg: 3,   dps: 5,   tipo: 'fuego' },
    envenenado: { nombre: 'Envenenado', icono: '☠', seg: 6,   dps: 2.5, tipo: 'veneno' },
    congelado:  { nombre: 'Congelado',  icono: '❄', seg: 2,   lento: 0.35 },   // enemigo: quieto · jugador: muy lento
    aturdido:   { nombre: 'Aturdido',   icono: '⚡', seg: 0.8, lento: 0.15 },
    lento:      { nombre: 'Lento',      icono: '🐌', seg: 3,   lento: 0.5 },
  };
  const POR_TIPO = { fuego: 'quemado', veneno: 'envenenado', hielo: 'congelado', electrico: 'aturdido' };
  const OPCIONES = [['auto', 'Según el tipo de daño'], ['ninguno', 'Ninguno'],
    ...Object.entries(ESTADOS).map(([k, e]) => [k, e.icono + ' ' + e.nombre])];

  // qué estado deja un golpe: cfg = arma o config del enemigo (efecto, efectoSeg, efectoProb)
  function resolver(cfg, tipo) {
    const ef = (cfg && cfg.efecto) || 'auto';
    const k = ef === 'auto' ? POR_TIPO[tipo] : ef === 'ninguno' ? null : ef;
    if (!k || !ESTADOS[k]) return null;
    if (cfg && cfg.efectoProb != null && Math.random() > cfg.efectoProb) return null;
    return { k, seg: (cfg && cfg.efectoSeg > 0) ? cfg.efectoSeg : ESTADOS[k].seg };
  }

  /* ---------- enemigos ---------- */
  function enemigo(G, E, cfg, tipo) {
    const r = resolver(cfg, tipo);
    if (!r || (E.c['res_' + (ESTADOS[r.k].tipo || tipo)] ?? 1) <= 0) return;
    E.est = E.est || {};
    E.est[r.k] = Math.max(E.est[r.k] || 0, r.seg);
    if (r.k === 'congelado' || r.k === 'aturdido') G.aturdir(E, r.seg);
    if (r.k === 'congelado') { E.flashCol = 'escudo'; E.flash = r.seg; }   // azul mientras dura
  }
  function ticEnemigo(G, E, dt) {
    let hay = false;
    for (const k in E.est) {
      const t = E.est[k] - dt, d = ESTADOS[k];
      if (t <= 0) { delete E.est[k]; continue; }
      E.est[k] = t; hay = true;
      if (d.dps && !E.muerto) G.danar(E, d.dps * dt, { tipo: d.tipo, tic: true });
    }
    if (!hay) E.est = null;
  }

  /* ---------- jugador ---------- */
  function jugador(j, cfg, tipo) {
    const r = resolver(cfg, tipo);
    if (!r || j.muerto) return;
    j.efectos = j.efectos || {};
    j.efectos[r.k] = Math.max(j.efectos[r.k] || 0, r.seg);
  }
  function ticJugador(j, dt) {
    const est = j.efectos;
    let lento = 1, txt = '';
    if (est) {
      for (const k in est) {
        const t = est[k] - dt, d = ESTADOS[k];
        if (t <= 0 || j.muerto) { delete est[k]; continue; }
        est[k] = t;
        if (d.lento) lento = Math.min(lento, d.lento);
        if (d.dps && j.danar) {
          // a tirones (con corazones cada 20 = ½ corazón; si no, de 1 en 1). Daño de ambiente: no da invencibilidad
          const paso = j.props('salud').modoVida === 'corazones' ? 20 : 1;
          j._dot = (j._dot || 0) + d.dps * dt;
          if (j._dot >= paso) { j._dot -= paso; j.danar(paso, 'veneno'); }
        }
        txt += `<span>${d.icono}<small>${Math.ceil(t)}</small></span>`;
      }
    }
    j.lentoEstado = lento;
    // 💥 estados en pantalla (motor/efectos.js): solo se toca la vista cuando cambia qué estados hay
    const conPantalla = F.Efectos && j.juego && (j.props ? j.props('salud').efectosEstado !== false : true);
    const clave = conPantalla && est ? Object.keys(est).sort().join(',') : '';
    if (clave !== (j._fxEst || '') && j.juego && F.Efectos) {
      j._fxEst = clave;
      const v = j.juego.vista, e = est || {};
      F.Efectos.momento(v, 'mareo', e.envenenado ? 1 : 0);
      F.Efectos.momento(v, 'doble', e.aturdido ? 1 : 0);
      if (e.quemado) F.Efectos.momento(v, 'borde', 0.8, '#ff6a1a');
      else if (e.congelado) F.Efectos.momento(v, 'borde', 0.8, '#8fd0ff');
      else F.Efectos.momento(v, 'borde', 0);
    }
    if (txt !== (j._estTxt || '') && j.juego) {
      j._estTxt = txt;
      const el = F.Hud.pieza(j.juego, 'fh-estados');
      el.innerHTML = txt;
      el.style.display = txt ? 'flex' : 'none';
    }
  }

  F.Estados = { ESTADOS, POR_TIPO, OPCIONES, resolver, enemigo, ticEnemigo, jugador, ticJugador };
})(window.FORJA);
