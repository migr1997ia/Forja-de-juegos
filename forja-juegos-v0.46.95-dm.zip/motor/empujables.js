/* =========================================================
   FORJA · OBJETOS MOVIBLES (entidad 🧱 'empujable') para puzles
   Sin física: se deslizan por un eje (el de la cara que tocas), sin girar, como en RE.
     · Empujar: camina contra una cara.
     · Jalar: usar para agarrarlo (interruptor), retrocede; usar otra vez lo suelta.
     · Cargar: usar para levantarlo (entre las manos); otra vez para soltarlo delante.
   No se mueve si delante hay pared, otro objeto o no hay suelo. Solo lo mueve el jugador.
   Volver: tras X segundos sin tocarlo regresa a donde lo pusiste (Bugs Bunny Lost in Time).
   Choca como PIEZA MÓVIL del mundo (motor/mecanismos.js alMundo). Las placas (⬚ disparador "objetos") los detectan.
   ========================================================= */
(function (F) {
  'use strict';
  const T = THREE;

  const EMPUJABLE = {
    empujar: true,
    tirar: true,
    cargar: false,
    velocidad: 1.2,           // m/s al empujar o jalar (más bajo = más pesado)
    agarradoEmpuja: true,     // agarrado (jalando) también se puede empujar hacia delante
    volver: 0,                // segundos sin tocarlo para volver a su sitio (0 = nunca)
    verTiempo: true,          // ⏳ cuenta atrás sobre el objeto mientras espera para volver (Bugs Bunny Lost in Time)
    iconoTiempo: '⏳',
    etiqueta: '',             // las placas pueden pedir una etiqueta concreta
    forma: 'caja',            // 'caja' | 'barril' | 'roca'
    color: '#8a6a44',
    modelo: '',
  };

  const ESQUEMA = [
    { grupo: '🧱 Objeto movible' },
    { k: 'empujar', t: 'bool', e: 'Se puede empujar', ayuda: 'Camina contra él' },
    { k: 'tirar', t: 'bool', e: 'Se puede jalar', ayuda: 'Usar = agarrarlo · retrocede para jalarlo · usar otra vez = soltarlo' },
    { k: 'agarradoEmpuja', t: 'bool', e: 'Agarrado también se empuja', si: (v) => v.tirar && !v.cargar, ayuda: 'Mientras lo tienes agarrado, caminar hacia él lo empuja' },
    { k: 'cargar', t: 'bool', e: 'Se puede cargar', ayuda: 'Usar = levantar · usar otra vez = soltar delante. Si está activo, el botón de usar carga en vez de agarrar' },
    { k: 'velocidad', t: 'num', e: 'Velocidad (m/s)', paso: 0.1, min: 0.2, ayuda: 'Al empujar o jalar. Más bajo = más pesado' },
    { k: 'volver', t: 'num', e: 'Vuelve a su sitio tras (s)', paso: 1, min: 0, ayuda: '0 = se queda donde lo dejes' },
    { k: 'verTiempo', t: 'bool', e: 'Mostrar cuenta atrás', si: (v) => v.volver > 0, ayuda: 'Un icono con los segundos que le quedan, encima del objeto' },
    { k: 'iconoTiempo', t: 'texto', e: 'Icono', si: (v) => v.volver > 0 && v.verTiempo !== false, ayuda: '⏳ ⏱ 🔨 ★… un emoji o carácter' },
    { k: 'etiqueta', t: 'texto', e: 'Etiqueta', ayuda: 'Para placas que solo acepten este objeto (ej. "estatua")' },
    { grupo: 'Cómo se ve' },
    { k: 'forma', t: 'sel', e: 'Forma', op: [['caja', 'Caja'], ['barril', 'Barril'], ['roca', 'Roca']], si: (v) => !v.modelo },
    { k: 'modelo', t: 'asset', e: 'Modelo', tipoAsset: 'modelo', vacio: '(figura del motor)' },
    { k: 'color', t: 'color', e: 'Color' },
  ];

  // Figura 1×1×1 apoyada en el suelo: la escala de la entidad le da el tamaño
  function figura(ent) {
    const s = { ...EMPUJABLE, ...(ent.empujable || {}) };
    const g = new T.Group();
    const a = s.modelo && F.Assets && F.Assets.mapa.get(s.modelo);
    if (a && a.gltf) {
      const m = T.SkeletonUtils.clone(a.gltf.scene);
      g.add(m);
      return g;
    }
    const mat = F.Render.matRetro(s.color), osc = F.Render.matRetro(new T.Color(s.color).multiplyScalar(0.6).getStyle());
    let geo;
    if (s.forma === 'barril') geo = new T.CylinderGeometry(0.5, 0.5, 1, 8);
    else if (s.forma === 'roca') geo = new T.DodecahedronGeometry(0.55, 0).scale(1, 0.85, 1);
    else geo = new T.BoxGeometry(1, 1, 1);
    const cuerpo = new T.Mesh(geo, mat);
    cuerpo.position.y = 0.5;
    g.add(cuerpo);
    if (s.forma === 'caja') {   // tablones cruzados
      for (const z of [0.505, -0.505]) {
        const t = new T.Mesh(new T.BoxGeometry(1.0, 0.12, 0.02), osc); t.position.set(0, 0.5, z); t.rotation.z = 0.78; g.add(t);
        const t2 = t.clone(); t2.rotation.z = -0.78; g.add(t2);
      }
    }
    return g;
  }

  class Gestor {
    constructor(juego, inicio) {
      this.juego = juego;
      this.lista = [];
      this.cargado = null;
      this.agarre = null;     // { it, cx, cz, ox, oz } jalando (interruptor)
      const mem = (inicio && inicio.empujables) || {};
      for (const ent of juego.escena.entidades) {
        if (ent.tipo !== 'empujable') continue;
        const obj = juego.objetos.get(ent.id);
        if (!obj) continue;
        const p = { ...EMPUJABLE, ...(ent.empujable || {}) };
        // el origen es SIEMPRE el de la entidad (el editor comparte el objeto 3D: nunca se queda movido)
        obj.position.fromArray(ent.pos || [0, 0, 0]);
        obj.rotation.y = ((ent.rot || [0, 0, 0])[1] || 0) * Math.PI / 180;
        const it = { ent, obj, p, origen: obj.position.clone(), rot0: obj.rotation.y, tApretar: 0, tQuieto: 0, volviendo: 0, desde: new T.Vector3() };
        if (mem[ent.id]) obj.position.fromArray(mem[ent.id]);
        this.lista.push(it);
      }
    }

    // al terminar la prueba / el nivel: todo vuelve a donde está la entidad
    detener() {
      this.cargado = null; this.agarre = null;
      if (this.juego.jugador) this.juego.jugador.pasoForzado = 0;
      for (const it of this.lista) { it.obj.position.copy(it.origen); it.obj.rotation.y = it.rot0; it.volviendo = 0; }
      if (this.avisoEl) this.avisoEl.style.display = 'none';
      for (const it of this.lista) if (it.relojEl) it.relojEl.style.display = 'none';
    }

    _aviso(t) {
      if (!this.avisoEl) { this.avisoEl = F.Hud.pieza(this.juego, 'fe-aviso'); this.avisoEl.classList.add('fh-aviso'); }
      if (this._tAviso === t) return;
      this._tAviso = t;
      this.avisoEl.textContent = t || '';
      this.avisoEl.style.display = t ? 'block' : 'none';
    }

    estado() { const r = {}; for (const it of this.lista) if (!it.obj.position.equals(it.origen)) r[it.ent.id] = it.obj.position.toArray().map((v) => +v.toFixed(3)); return r; }

    _medio(it) { return { x: Math.abs(it.obj.scale.x) / 2, z: Math.abs(it.obj.scale.z) / 2, y: Math.abs(it.obj.scale.y) }; }

    // ¿cabe en (x, y, z)? sin paredes en medio (si se desplaza por un eje), sin otro objeto y con suelo debajo
    _libre(it, x, y, z, dx, dz) {
      const M = this.juego.mundo, h = this._medio(it), pz = it.pieza;
      const antes = pz && pz.activa;
      if (pz) pz.activa = false;
      let ok = true;
      if (dx || dz) {
        const dist = Math.hypot(x - it.obj.position.x, z - it.obj.position.z) + (dx ? h.x : h.z) + 0.02;
        const lat = dx ? h.z * 0.8 : h.x * 0.8;
        for (const fy of [0.15, 0.5, 0.9]) {
          for (const l of [-lat, 0, lat]) {
            const ox = it.obj.position.x + (dx ? 0 : l), oz = it.obj.position.z + (dz ? 0 : l);
            if (M.rayo(ox, it.obj.position.y + h.y * fy, oz, dx, 0, dz, dist)) { ok = false; break; }
          }
          if (!ok) break;
        }
      }
      if (ok && !M.rayo(x, y + 0.3, z, 0, -1, 0, 0.6)) ok = false;   // suelo debajo
      if (ok) for (const o of this.lista) {
        if (o === it || o === this.cargado) continue;
        const ho = this._medio(o);
        if (Math.abs(o.obj.position.x - x) < ho.x + h.x - 0.02 && Math.abs(o.obj.position.z - z) < ho.z + h.z - 0.02 && Math.abs(o.obj.position.y - y) < Math.max(ho.y, h.y)) { ok = false; break; }
      }
      if (pz) pz.activa = antes;
      return ok;
    }

    // desplazamiento libre por un eje (dx, dz = ±1/0), d metros. Devuelve lo que se movió
    _desplazar(it, dx, dz, d) {
      const o = it.obj.position, x = o.x + dx * d, z = o.z + dz * d;
      if (!this._libre(it, x, o.y, z, dx, dz)) return 0;
      o.x = x; o.z = z;
      if (it.pieza) this.juego.mundo.moverPieza(it.pieza);
      it.tQuieto = 0; it.volviendo = 0;
      it._movido = true;
      return d;
    }

    // ¿el jugador está pegado a una cara? { dx, dz } = del jugador hacia el objeto
    _cara(it, P, r) {
      const h = this._medio(it), o = it.obj.position;
      const qx = P.x - o.x, qz = P.z - o.z;
      if (P.y > o.y + h.y - 0.1 || P.y < o.y - 0.6) return null;
      const fx = Math.abs(qx) - h.x, fz = Math.abs(qz) - h.z;
      if (fx > r + 0.15 || fz > r + 0.15) return null;
      if (fx > fz) { if (Math.abs(qz) > h.z) return null; return { dx: qx > 0 ? -1 : 1, dz: 0 }; }
      if (Math.abs(qx) > h.x) return null;
      return { dx: 0, dz: qz > 0 ? -1 : 1 };
    }

    _levantar(it) {
      this.cargado = it;
      if (it.pieza) it.pieza.activa = false;
      it.tQuieto = 0; it.volviendo = 0;
      F.Audio.sintetico('recoger', { volumen: 0.5, tono: 0.6 });
    }
    _soltar() {
      const it = this.cargado, j = this.juego.jugador, c = j.cuerpo.pie, M = this.juego.mundo;
      const yaw = this._yawCuerpo(j), fx = -Math.sin(yaw), fz = -Math.cos(yaw), h = this._medio(it), r = j.cuerpo.radio || 0.35;
      const d = Math.max(h.x, h.z) + r + 0.15, x = c.x + fx * d, z = c.z + fz * d;
      const g = M.rayo(x, c.y + 1, z, 0, -1, 0, 3);
      if (!g) { this._avisoNo(); return; }
      const y = c.y + 1 - g.t;
      let pared = false;
      for (const hy of [0.4, 1.0]) if (M.rayo(c.x, c.y + hy, c.z, fx, 0, fz, d + Math.max(h.x, h.z))) pared = true;
      const guarda = it.obj.position.clone(), rot = it.obj.rotation.y;
      it.obj.position.set(x, y, z); it.obj.rotation.y = it.rot0;
      if (pared || !this._libre(it, x, y, z, 0, 0)) { it.obj.position.copy(guarda); it.obj.rotation.y = rot; this._avisoNo(); return; }
      this.cargado = null;
      it.tQuieto = 0;
      if (it.pieza) { it.pieza.activa = true; M.moverPieza(it.pieza); }
      F.Audio.sintetico('paso', { volumen: 0.6, tono: 0.4 });
      F.emitir('objeto-movido', { juego: this.juego, ent: it.ent });
    }
    _avisoNo() { F.Audio.sintetico('golpe', { volumen: 0.3, tono: 0.6 }); }

    // hacia dónde mira el CUERPO (en 3ª persona el modelo; si no, la cámara)
    _yawCuerpo(j) {
      if (j.modelo && j.modoCamara !== 'fps') { const q = j.modelo.getWorldQuaternion(this._q || (this._q = new T.Quaternion())); const v = (this._v || (this._v = new T.Vector3())).set(0, 0, 1).applyQuaternion(q); return Math.atan2(-v.x, -v.z); }
      return j.yaw;
    }

    // 📦 cargado: entre las manos del personaje (3ª persona) o delante del pecho
    _ponerCargado(j) {
      const it = this.cargado, c = j.cuerpo.pie, h = this._medio(it), r = j.cuerpo.radio || 0.35;
      const yaw = this._yawCuerpo(j), fx = -Math.sin(yaw), fz = -Math.cos(yaw);
      it.obj.rotation.y = yaw;
      const mi = j.modelo && j.modoCamara !== 'fps' && j.modelo.getObjectByName('hand_L'), md = j.modelo && j.modoCamara !== 'fps' && j.modelo.getObjectByName('hand_R');
      if (mi && md && j.modelo.visible !== false) {
        j.modelo.updateMatrixWorld(true);
        const a = mi.getWorldPosition(new T.Vector3()), b = md.getWorldPosition(new T.Vector3());
        const m = a.add(b).multiplyScalar(0.5);
        // el objeto entre las palmas: su centro un poco por delante de las manos y a su altura
        it.obj.position.set(m.x + fx * h.z * 0.6, m.y - h.y * 0.5, m.z + fz * h.z * 0.6);
      } else {
        const d = Math.max(h.x, h.z) + r + 0.1;
        it.obj.position.set(c.x + fx * d, c.y + (j.cuerpo.altura || 1.8) * 0.45, c.z + fz * d);
      }
    }

    actualizar(dt) {
      if (!this.lista.length) return;
      const J = this.juego, j = J.jugador, E = F.Entrada, M = J.mundo;
      // texto de la tecla: se calcula 1 vez por segundo (no cada cuadro)
      if (!(this._tTecla > 0)) { this._tTecla = 1; this._tecla = F.Tactil && F.Tactil.visible ? '' : E.textoTeclado('interactuar').split(' / ')[0] + ': '; }
      this._tTecla -= dt;
      const tecla = this._tecla;
      let aviso = '', usado = false;
      for (const it of this.lista) it._movido = false;
      // 📦 cargando
      if (this.cargado) {
        aviso = tecla + 'Soltar';
        if (E.pulsado('interactuar')) { usado = true; this._soltar(); }
        if (this.cargado) { if (j.muerto) this._soltarDonde(this.cargado); else this._ponerCargado(j); }
      }
      // ✋ agarrado (jalar): interruptor
      const A = this.agarre;
      if (A) {
        const it = A.it, P = j.cuerpo.pie, empuje = A.modo === 'empuje';
        const dir = j.direccion || { x: 0, z: 0 }, dl = Math.hypot(dir.x, dir.z);
        const a = dl > 0.3 ? (dir.x * A.cx + dir.z * A.cz) / dl : 0;   // + hacia el objeto · − alejándose
        if (!empuje) aviso = tecla + 'Soltar';
        // empujando (RE / Tomb Raider): mientras sigas caminando hacia él vais juntos; al dejar de empujar se suelta solo
        if (empuje && (a <= 0.4 || j.muerto)) this.agarre = null;
        else if (j.muerto || (!empuje && !usado && E.pulsado('interactuar'))) { usado = true; this.agarre = null; }
        else {
          const d = (it.p.velocidad || 1.2) * dt;
          A._ultimo = a > 0.4 ? 1 : a < -0.4 ? -1 : 0;
          if (empuje) this._desplazar(it, A.cx, A.cz, d);
          else if (a < -0.4) {
            // jalar: que detrás de ti no haya pared
            const r = j.cuerpo.radio || 0.35;
            if (!M.rayo(P.x, P.y + 0.5, P.z, -A.cx, 0, -A.cz, r + d + 0.05)) this._desplazar(it, -A.cx, -A.cz, d);
          } else if (a > 0.4 && it.p.agarradoEmpuja) this._desplazar(it, A.cx, A.cz, d);
          // el jugador sigue pegado a su cara
          const o = it.obj.position;
          j.cuerpo.velocidad.x = 0; j.cuerpo.velocidad.z = 0;
          P.x = o.x + A.ox; P.z = o.z + A.oz;   // sin teletransportar (que siga "en el suelo" y las piernas caminen)
        }
      }
      for (const it of this.lista) {
        if (this.cargado === it || (this.agarre && this.agarre.it === it)) continue;
        // ⏱ volver a su sitio (deslizándose)
        if (it.volviendo > 0) {
          it.volviendo = Math.min(1, it.volviendo + dt / 0.6);
          it.obj.position.lerpVectors(it.desde, it.origen, it.volviendo);
          if (it.pieza) M.moverPieza(it.pieza);
          if (it.volviendo >= 1) { it.volviendo = 0; F.emitir('objeto-movido', { juego: J, ent: it.ent }); }
          continue;
        }
        if (it.p.volver > 0 && !it.obj.position.equals(it.origen)) {
          it.tQuieto += dt;
          if (it.tQuieto >= it.p.volver) { it.desde.copy(it.obj.position); it.volviendo = 0.0001; it.tQuieto = 0; continue; }
        }
        if (!j || j.muerto || this.cargado || this.agarre) continue;
        { const o = it.obj.position, P = j.cuerpo.pie; if ((o.x - P.x) ** 2 + (o.z - P.z) ** 2 > 16) { it.tApretar = 0; continue; } }   // lejos: ni se mira
        const cara = this._cara(it, j.cuerpo.pie, j.cuerpo.radio || 0.35);
        if (!cara) { it.tApretar = 0; continue; }
        // 📦 cargar / ✋ agarrar: botón de usar pegado a una cara
        if (it.p.cargar) {
          if (!aviso) aviso = tecla + 'Levantar' + (it.ent.nombre ? ' ' + it.ent.nombre : '');
          if (!usado && E.pulsado('interactuar')) { usado = true; this._levantar(it); aviso = tecla + 'Soltar'; continue; }
        } else if (it.p.tirar) {
          if (!aviso) aviso = tecla + 'Agarrar';
          if (!usado && E.pulsado('interactuar')) {
            usado = true;
            const P = j.cuerpo.pie, o = it.obj.position;
            this.agarre = { it, cx: cara.dx, cz: cara.dz, ox: P.x - o.x, oz: P.z - o.z };
            aviso = tecla + 'Soltar';
            continue;
          }
        }
        // ➡ empujar libre: caminar contra la cara
        const dir = j.direccion || { x: 0, z: 0 }, dl = Math.hypot(dir.x, dir.z);
        const hacia = dl > 0.3 ? (dir.x * cara.dx + dir.z * cara.dz) / dl : 0;
        if (it.p.empujar && hacia > 0.7) {
          it.tApretar += dt;
          // tras un instante apretando: modo empujar, el jugador queda pegado a la cara y se mueven juntos (sin choques que tiemblen)
          if (it.tApretar >= 0.15) { const P = j.cuerpo.pie, o = it.obj.position; this.agarre = { it, cx: cara.dx, cz: cara.dz, ox: P.x - o.x, oz: P.z - o.z, modo: 'empuje' }; it.tApretar = 0; }
        } else it.tApretar = 0;
      }
      // piernas del personaje: como si caminara mientras el objeto se mueve (modelo.js usa j.pasoForzado)
      if (j) { const A2 = this.agarre; j.pasoForzado = A2 && A2.it._movido ? (A2.it.p.velocidad || 1.2) : 0; if (A2) A2._hacia = A2.modo === 'empuje' ? 1 : (A2._ultimo || 0); }
      // ruido de arrastre y aviso a las placas
      for (const it of this.lista) {
        if (it._movido) {
          it._tRuido = (it._tRuido || 0) - dt;
          if (it._tRuido <= 0) { it._tRuido = 0.35; F.Audio.sintetico('paso', { volumen: 0.35, tono: 0.4 }); }
        } else if (it._antesMovido) F.emitir('objeto-movido', { juego: J, ent: it.ent });
        it._antesMovido = it._movido;
      }
      this._aviso(j && !j.muerto ? aviso : '');
      this._cuentas();
    }

    // ⏳ cuenta atrás encima de los objetos que van a volver (solo los que esperan: barato)
    _cuentas() {
      const J = this.juego, cam = J.camara, cont = J.vista.contenedor;
      const W = cont.clientWidth, H = cont.clientHeight;
      for (const it of this.lista) {
        const p = it.p, espera = p.volver > 0 && p.verTiempo !== false && this.cargado !== it && !(this.agarre && this.agarre.it === it)
          && it.volviendo === 0 && !it.obj.position.equals(it.origen);
        if (!espera) { if (it.relojEl) it.relojEl.style.display = 'none'; continue; }
        if (!it.relojEl) {
          it.relojEl = F.Hud.pieza(J, 'fe-reloj-' + it.ent.id);
          it.relojEl.style.cssText = 'position:absolute;transform:translate(-50%,-100%);font:bold 16px ui-monospace,Consolas,monospace;color:#ffe08a;text-shadow:2px 2px 0 #000;pointer-events:none;white-space:nowrap;z-index:5';
        }
        const v = (this._vp || (this._vp = new T.Vector3())).copy(it.obj.position);
        v.y += Math.abs(it.obj.scale.y) + 0.35;
        v.project(cam);
        // fuera de la vista: se queda pegado al borde de la pantalla (siempre sabes cuánto queda)
        if (v.z > 1) { v.x = -v.x; v.y = -1; }
        v.x = Math.max(-0.92, Math.min(0.92, v.x)); v.y = Math.max(-0.85, Math.min(0.9, v.y));
        const resta = Math.max(0, Math.ceil(p.volver - it.tQuieto));
        const txt = (p.iconoTiempo || '⏳') + ' ' + resta;
        if (it.relojEl._t !== txt) { it.relojEl._t = txt; it.relojEl.textContent = txt; it.relojEl.style.color = resta <= 3 ? '#ff6a5a' : '#ffe08a'; }
        it.relojEl.style.left = ((v.x + 1) / 2 * W).toFixed(0) + 'px';
        it.relojEl.style.top = ((1 - v.y) / 2 * H).toFixed(0) + 'px';
        it.relojEl.style.display = 'block';
      }
    }

    _soltarDonde(it) {
      this.cargado = null;
      it.obj.rotation.y = it.rot0;
      const g = this.juego.mundo.rayo(it.obj.position.x, it.obj.position.y, it.obj.position.z, 0, -1, 0, 5);
      if (g) it.obj.position.y -= g.t;
      if (it.pieza) { it.pieza.activa = true; this.juego.mundo.moverPieza(it.pieza); }
    }
  }

  F.Empujables = { EMPUJABLE, ESQUEMA, figura, Gestor };
})(window.FORJA);
