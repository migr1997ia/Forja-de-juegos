/* =========================================================
   FORJA · NÚCLEO
   Namespace global, utilidades, eventos y registro de módulos.
   Todo el motor vive dentro de window.FORJA (como los autoload de Godot).
   ========================================================= */
window.FORJA = window.FORJA || {};

(function (F) {
  'use strict';

  F.VERSION = '0.46.95-dm';
  F.DEG = Math.PI / 180;

  /* ---------- Utilidades ---------- */
  F.util = {
    uid() {
      return Math.random().toString(36).slice(2, 10);
    },

    clamp(v, a, b) {
      return v < a ? a : v > b ? b : v;
    },

    fmt(n) {
      return Math.round(n).toLocaleString('es-MX');
    },

    slug(s) {
      return (s || 'juego').toLowerCase().normalize('NFD').replace(/[̀-ͯ]/g, '')
        .replace(/[^a-z0-9]+/g, '_').replace(/^_|_$/g, '') || 'juego';
    },

    descargarBlob(blob, nombre) {
      const a = document.createElement('a');
      a.href = URL.createObjectURL(blob);
      a.download = nombre;
      a.click();
      setTimeout(() => URL.revokeObjectURL(a.href), 3000);
    },

    bufferABase64(buffer) {
      return new Promise((resolver) => {
        const lector = new FileReader();
        lector.onload = () => resolver(String(lector.result).split(',')[1] || '');
        lector.readAsDataURL(new Blob([buffer]));
      });
    },

    async base64ABuffer(b64) {
      const r = await fetch('data:application/octet-stream;base64,' + b64);
      return r.arrayBuffer();
    },

    copiar(obj) {
      return JSON.parse(JSON.stringify(obj));
    },
  };

  /* ---------- Límite de FPS ----------
     const lim = new FORJA.LimiteFps();   en el bucle:  if (!lim.listo(ahora, 30)) return;
     El navegador dibuja a la velocidad del monitor; esto salta cuadros para no pasar del límite (0 = sin límite). */
  /* Rendimiento REAL, aunque el monitor limite a 60 Hz: cuánto tarda cada cuadro en hacerse.
     CPU = lógica + preparar el dibujo (lo mide Juego.actualizar). GPU = lo que tarda la tarjeta en dibujar
     (Vista.render, solo si el navegador da EXT_disjoint_timer_query_webgl2; Chrome/Edge de escritorio sí).
     "fps posibles" = 1000 / el más lento de los dos: lo que daría con un monitor sin límite. */
  F.Rendimiento = {
    cpu: 0, cpuMax: 0, gpu: -1, _suma: 0, _max: 0, _n: 0, _t: 0,
    cuadro(ms) {
      this._suma += ms; this._n++; if (ms > this._max) this._max = ms;
      const ahora = performance.now();
      if (ahora - this._t >= 500) {
        this._cerrarSistemas();
        this.cpu = this._n ? this._suma / this._n : 0;
        this.cpuMax = this._max;
        this._suma = 0; this._n = 0; this._max = 0; this._t = ahora;
      }
    },
    // ms por sistema (jugador, enemigos, render…): medias de medio segundo
    sis: {}, _sis: {},
    medir(nombre, t0) {
      const d = performance.now() - t0;
      this._sis[nombre] = (this._sis[nombre] || 0) + d;
      return d;
    },
    _cerrarSistemas() {
      const n = Math.max(1, this._n);
      this.sis = {};
      for (const k in this._sis) this.sis[k] = this._sis[k] / n;
      this._sis = {};
    },
    textoSistemas() {
      return Object.entries(this.sis).sort((a, b) => b[1] - a[1]).map(([k, v]) => `${k} ${v.toFixed(2)}`).join('  ');
    },
    posibles() {
      const peor = Math.max(this.cpu, this.gpu > 0 ? this.gpu : 0);
      return peor > 0 ? Math.round(1000 / peor) : 0;
    },
    texto(corto = false) {
      const gpu = this.gpu >= 0 ? `GPU ${this.gpu.toFixed(1)} ms` : 'GPU ?';
      if (corto) return `cuadro ${this.cpu.toFixed(1)} ms · ${gpu} · ≈ ${this.posibles()} fps posibles`;
      // CPU y GPU se solapan solo en parte (y el navegador pone lo suyo): lo real cae ENTRE los dos números
      const suma = this.cpu + (this.gpu > 0 ? this.gpu : 0), bajo = suma > 0 ? Math.round(1000 / suma) : 0;
      return `CPU ${this.cpu.toFixed(2)} ms (peor ${this.cpuMax.toFixed(1)})  ${gpu}\n≈ ${bajo}–${this.posibles()} fps posibles sin límite de monitor (lo real suele quedar entre los dos)`;
    },
  };

  F.LimiteFps = class {
    constructor() { this.ultimo = -1e9; }
    listo(ahora, fps) {
      if (!fps || fps <= 0) { this.ultimo = ahora; return true; }
      const intervalo = 1000 / fps;
      const pasado = ahora - this.ultimo;
      if (pasado < intervalo - 1.5) return false;           // 1.5 ms de margen: el monitor no es exacto
      this.ultimo = pasado > intervalo * 2 ? ahora : this.ultimo + intervalo;
      return true;
    }
  };

  /* ---------- Eventos (como las señales de Godot) ----------
     FORJA.on('nombre', fn)   ·   FORJA.emitir('nombre', ...datos)   */
  const oyentes = {};
  F.on = function (nombre, fn) {
    (oyentes[nombre] = oyentes[nombre] || []).push(fn);
    return () => F.off(nombre, fn);
  };
  F.off = function (nombre, fn) {
    oyentes[nombre] = (oyentes[nombre] || []).filter((f) => f !== fn);
  };
  F.emitir = function (nombre, ...datos) {
    for (const fn of oyentes[nombre] || []) {
      try { fn(...datos); } catch (err) { console.error(`[FORJA] error en evento "${nombre}"`, err); }
    }
  };

  // Avisos al usuario: el editor los muestra como notificaciones; el juego, en consola
  F.aviso = function (html, tipo = '') {
    F.emitir('aviso', html, tipo);
  };

  /* ---------- Esquemas de propiedades ----------
     Cada módulo o componente describe sus propiedades con una lista como esta,
     y el inspector se construye solo (como @export en GDScript):

       { grupo: 'Título de sección' }
       { k: 'velocidad', t: 'num',   e: 'Velocidad', def: 4.5, paso: 0.1, ayuda: 'm/s' }
       { k: 'activo',    t: 'bool',  e: 'Activo',    def: true }
       { k: 'fuerza',    t: 'rango', e: 'Fuerza',    def: 0.5, min: 0, max: 1, paso: 0.05 }
       { k: 'modo',      t: 'sel',   e: 'Modo',      def: 'fps', op: [['fps', 'Primera persona'], ['tps', 'Tercera']] }
       { k: 'tinte',     t: 'color', e: 'Color',     def: '#ffffff' }
       { k: 'modelo',    t: 'asset', e: 'Modelo',    def: '', tipoAsset: 'modelo' }
       { k: 'nombre',    t: 'texto', e: 'Nombre',    def: '' }
  */
  F.valoresPorDefecto = function (props) {
    const v = {};
    for (const p of props || []) if (p.k) v[p.k] = p.def;
    return v;
  };

  /* ---------- Registro de MÓDULOS DEL JUGADOR ----------
     Equivalen a los nodos de tu carpeta core/modules en Godot.

     FORJA.registrarModulo({
       nombre: 'salto',                 // identificador único
       etiqueta: 'Salto',               // nombre visible
       descripcion: 'Qué hace',         // ayuda en el editor
       orden: 30,                       // menor = se ejecuta antes
       obligatorio: false,              // true = no se puede desactivar
       props: [ ...esquema... ],
       iniciar(j, p, s) {},             // al empezar a jugar
       entrada(j, p, s, dt) {},         // leer controles, decidir intenciones
       fisica(j, p, s, dt) {},          // cambiar j.cuerpo.velocidad (antes de moverYDeslizar)
       despues(j, p, s, dt) {},         // cámara, animación, efectos (después de moverse)
       detener(j, p, s) {},             // al terminar
     });

     j = el jugador · p = propiedades del módulo · s = estado privado del módulo */
  F.modulos = {};
  F.registrarModulo = function (def) {
    if (!def || !def.nombre) throw new Error('registrarModulo: falta "nombre"');
    def.orden = def.orden ?? 50;
    def.props = def.props || [];
    def.etiqueta = def.etiqueta || def.nombre;
    F.modulos[def.nombre] = def;
  };
  F.modulosOrdenados = function () {
    return Object.values(F.modulos).sort((a, b) => a.orden - b.orden);
  };

  /* ---------- Registro de COMPONENTES de entidades ----------
     Comportamientos que se le ponen a cualquier objeto de la escena
     (puerta, plataforma móvil, trigger…). Se usan desde el paso 0.2.

     FORJA.registrarComponente({
       nombre, etiqueta, descripcion, props,
       iniciar(ent, obj, p, s, juego) {}, actualizar(ent, obj, p, s, dt, juego) {}, detener(...) {}
     }); */
  F.componentes = {};
  F.registrarComponente = function (def) {
    if (!def || !def.nombre) throw new Error('registrarComponente: falta "nombre"');
    def.props = def.props || [];
    def.etiqueta = def.etiqueta || def.nombre;
    F.componentes[def.nombre] = def;
  };
})(window.FORJA);
