/* =========================================================
   FORJA · LUCES Y SOMBRAS
   Todo esto solo existe con Proyecto → "Luces y sombras" activado. Apagado, el juego se ve y rinde como siempre
   (solo luz ambiente + sol sin sombras).

   Cómo se mantiene rápido (pensado como la calidad baja de Godot):
   - Un grupo FIJO de luces puntuales (Proyecto → "Luces a la vez", 8 por defecto). Cambiar cuántas luces hay
     obliga a recompilar los shaders, así que nunca cambia: cada ~0.2 s se reparten entre las fuentes más cercanas a la cámara.
     Puede haber cientos de antorchas en el nivel; solo las cercanas alumbran.
   - Solo el sol hace sombras: un único mapa de sombras que sigue a la cámara (área "Alcance sombras").
     Calidad baja = 512 px sin suavizar: sombras pixeladas, muy de la época y muy baratas.
   - Las luces puntuales no hacen sombras (eso sí es caro: 6 pasadas por luz).
   - El juego dibuja a 240p: el costo por píxel de cada luz es muy bajo.

   Fuentes de luz:
   - Entidad "Luz" (💡) en la escena: color, fuerza, alcance y parpadeo (antorcha).
   - Materiales de un modelo con "Emite luz": cada grupo de triángulos de ese material (cada lámpara o antorcha
     del nivel) se vuelve una fuente en su centro. Así un nivel exportado de la forja trae sus luces solo.
   ========================================================= */
(function (F) {
  'use strict';
  const T = THREE;

  // Valores de una luz (entidad o material)
  // halo = fuerza del aura (0 = sin aura) · haloTam = su tamaño en metros
  const LUZ_BASE = { color: '#ffc27a', fuerza: 1.5, alcance: 7, parpadeo: 0, velocidad: 8, halo: 0.5, haloTam: 1.2, haloForma: 'circulo', apagada: false, soloNoche: false };   // apagada: empieza apagada al jugar
  const PRESETS = {
    lampara: { nombre: 'Lámpara', color: '#ffe0b0', fuerza: 1.4, alcance: 8, parpadeo: 0, velocidad: 8, halo: 0.45, haloTam: 1 },
    antorcha: { nombre: 'Antorcha', color: '#ff9a40', fuerza: 1.8, alcance: 7, parpadeo: 0.35, velocidad: 9, halo: 0.6, haloTam: 1.3 },
    fogata: { nombre: 'Fogata', color: '#ff7a2a', fuerza: 2.6, alcance: 11, parpadeo: 0.45, velocidad: 6, halo: 0.75, haloTam: 2.4 },
    fluorescente: { nombre: 'Fluorescente roto', color: '#d8f0ff', fuerza: 1.6, alcance: 9, parpadeo: 0.8, velocidad: 22, halo: 0.5, haloTam: 1.4 },
    magia: { nombre: 'Magia', color: '#7a6bff', fuerza: 1.6, alcance: 6, parpadeo: 0.15, velocidad: 3, halo: 0.8, haloTam: 1.6 },
  };

  /* Textura del aura: círculo en 6 escalones (no un degradado perfecto: así se veían en PS1 / N64) */
  function crearTexturaHalo() {
    const c = document.createElement('canvas');
    c.width = c.height = 64;
    const g = c.getContext('2d');
    const PASOS = 6;
    for (let i = PASOS; i >= 1; i--) {
      const r = i / PASOS;
      const a = Math.pow(1 - r + 1 / PASOS, 2);    // más fuerte al centro
      g.fillStyle = `rgba(255,255,255,${Math.min(1, a).toFixed(3)})`;
      g.beginPath();
      g.arc(32, 32, r * 31, 0, Math.PI * 2);
      g.fill();
    }
    const t = new T.CanvasTexture(c);
    t.magFilter = T.NearestFilter;
    t.minFilter = T.LinearFilter;
    return t;
  }

  // ✦ estrella: núcleo redondo + 4 rayos largos y 4 cortos (destello de lente de la época), en escalones
  function crearTexturaEstrella() {
    const c = document.createElement('canvas');
    c.width = c.height = 64;
    const g = c.getContext('2d');
    for (let i = 4; i >= 1; i--) { g.fillStyle = `rgba(255,255,255,${(0.18 * (5 - i)).toFixed(2)})`; g.beginPath(); g.arc(32, 32, i * 3.2, 0, Math.PI * 2); g.fill(); }
    const rayo = (ang, largo, ancho, a) => {
      g.save(); g.translate(32, 32); g.rotate(ang);
      for (let k = 0; k < 3; k++) { g.fillStyle = `rgba(255,255,255,${(a * (k + 1) / 3).toFixed(2)})`; const l = largo * (1 - k * 0.3), w = ancho * (1 - k * 0.3); g.beginPath(); g.moveTo(-l, 0); g.lineTo(0, -w); g.lineTo(l, 0); g.lineTo(0, w); g.closePath(); g.fill(); }
      g.restore();
    };
    rayo(0, 31, 3, 0.55); rayo(Math.PI / 2, 31, 3, 0.55); rayo(Math.PI / 4, 18, 2, 0.35); rayo(-Math.PI / 4, 18, 2, 0.35);
    const t = new T.CanvasTexture(c);
    t.magFilter = T.NearestFilter;
    t.minFilter = T.LinearFilter;
    return t;
  }

  // Parpadeo suave y algo caótico (suma de senos con fase propia): 0..1
  function parpadeo(t, vel, fase) {
    const s = Math.sin(t * vel + fase) * 0.5 + Math.sin(t * vel * 2.31 + fase * 1.7) * 0.3 + Math.sin(t * vel * 5.07 + fase * 3.1) * 0.2;
    return 0.5 + 0.5 * s;
  }

  // Centros de los grupos de triángulos de un material, en el espacio del modelo (se calcula una vez por archivo)
  const cacheCentros = new Map();
  F.on && F.on('assets-cambiaron', () => cacheCentros.clear());

  function centrosDeMaterial(raizModelo, mat, agrupar, claveCache) {
    if (cacheCentros.has(claveCache)) return cacheCentros.get(claveCache);
    raizModelo.updateMatrixWorld(true);
    const inversa = raizModelo.matrixWorld.clone().invert();
    const grupos = [];   // { suma: Vector3, n }
    const a = new T.Vector3(), b = new T.Vector3(), c = new T.Vector3(), cen = new T.Vector3(), m = new T.Matrix4();
    const radio2 = agrupar * agrupar;
    raizModelo.traverse((o) => {
      if (!o.isMesh || o.userData.ayudaEditor) return;
      const mats = Array.isArray(o.material) ? o.material : [o.material];
      if (!mats.includes(mat)) return;
      m.multiplyMatrices(inversa, o.matrixWorld);
      const pos = o.geometry.attributes.position, ind = o.geometry.index;
      const rangos = Array.isArray(o.material)
        ? o.geometry.groups.filter((g) => o.material[g.materialIndex] === mat).map((g) => [g.start, g.start + g.count])
        : [[0, ind ? ind.count : pos.count]];
      for (const [ini, fin] of rangos) {
        for (let i = ini; i + 2 < fin; i += 3) {
          const v = (k) => (ind ? ind.getX(k) : k);
          a.fromBufferAttribute(pos, v(i)); b.fromBufferAttribute(pos, v(i + 1)); c.fromBufferAttribute(pos, v(i + 2));
          cen.copy(a).add(b).add(c).divideScalar(3).applyMatrix4(m);
          // al grupo más cercano dentro de "agrupar" metros, o uno nuevo
          let mejor = null, dMejor = radio2;
          for (const g of grupos) {
            const d = g.centro.distanceToSquared(cen);
            if (d < dMejor) { dMejor = d; mejor = g; }
          }
          if (mejor) { mejor.suma.add(cen); mejor.n++; mejor.centro.copy(mejor.suma).divideScalar(mejor.n); }
          else grupos.push({ suma: cen.clone(), n: 1, centro: cen.clone() });
          if (grupos.length > 400) break;   // un material enorme (el suelo marcado por error) no congela todo
        }
      }
    });
    const centros = grupos.map((g) => g.centro);
    cacheCentros.set(claveCache, centros);
    return centros;
  }

  class Luces {
    constructor(vista) {
      this.vista = vista;
      this.activo = false;
      this.pool = [];             // PointLight fijas
      this.asignadas = [];        // fuente de cada luz del grupo (o null)
      this.fuentes = [];          // { obj, local, cfg, fase }
      this.t = 0;
      this.reparto = 0;
      this.tamSombra = -1;
      this.distSombras = 35;
      this.sombrasSol = false;
      this._v = new T.Vector3();
      this._centro = new T.Vector3();
      // Auras (sprites que siempre miran a la cámara, suma de luz) y marcas del editor
      this.texHalo = crearTexturaHalo();
      this.texEstrella = crearTexturaEstrella();
      this.halos = new T.Group();
      this.halos.name = 'auras-de-luz';
      vista.escena.add(this.halos);
      this.multHalo = 1;
      this.mostrarMarcas = false;   // el editor las enciende: puntos donde un material crea luces
      this.enJuego = false;         // FORJA.Juego lo pone mientras se juega (sin marcas)
      this.marcas = null;
    }

    /* Ajustes del proyecto (o del jugador) + ambiente de la escena */
    configurar(aj, amb) {
      const r = this.vista.renderer, sol = this.vista.sol;
      this.activo = !!aj.lucesExtra;
      const tam = this.activo && amb.solSombra !== false ? Number(aj.sombrasSol) || 0 : 0;
      this.sombrasSol = tam > 0;
      this.distSombras = Math.max(5, aj.distanciaSombras || 35);
      if (tam !== this.tamSombra) {
        this.tamSombra = tam;
        r.shadowMap.enabled = tam > 0;
        r.shadowMap.type = tam <= 512 ? T.BasicShadowMap : tam <= 1024 ? T.PCFShadowMap : T.PCFSoftShadowMap;
        sol.castShadow = tam > 0;
        if (tam > 0) sol.shadow.mapSize.set(tam, tam);
        if (sol.shadow.map) { sol.shadow.map.dispose(); sol.shadow.map = null; }
        // el tipo de sombra va dentro del shader: recompilar una vez
        this.vista.escena.traverse((o) => {
          if (!o.material) return;
          for (const m of Array.isArray(o.material) ? o.material : [o.material]) m.needsUpdate = true;
        });
      }
      this.multHalo = aj.halos ?? 1;
      // las auras pueden ir aunque las luces estén apagadas (Render ▸ Auras sin luces): son baratas y dan mucho ambiente
      this.halos.visible = (this.activo || !!aj.aurasSinLuces) && this.multHalo > 0;
      if (this.marcas) this.marcas.visible = this.activo && this.mostrarMarcas && !this.enJuego;
      const n = this.activo ? Math.max(0, Math.round(aj.maxLuces || 0)) : 0;
      if (n !== this.pool.length) {
        for (const l of this.pool) this.vista.escena.remove(l);
        this.pool = [];
        this.asignadas = [];
        for (let i = 0; i < n; i++) {
          const l = new T.PointLight(0xffffff, 0, 1, 1);   // decay 1: caída suave, más retro que la física
          l.userData.ayudaEditor = true;
          this.vista.escena.add(l);
          this.pool.push(l);
          this.asignadas.push(null);
        }
        this.reparto = 0;
      }
    }

    // 💡 encender / apagar una luz de la escena por id de entidad (palancas, interruptores…). on = null: alternar
    encender(entId, on = true) {
      for (const f of this.fuentes) {
        if (f.entId !== entId) continue;
        f.apagada = on === null ? !f.apagada : !on;
        this.reparto = 0;   // se reparte otra vez ya (si no, la luz apagada seguiría encendida 0,2 s)
      }
    }

    /* Fuentes de una escena ya construida (entidades "luz" y materiales que emiten luz) */
    registrar(entidades, objetos) {
      this.fuentes = [];
      for (const h of [...this.halos.children]) { this.halos.remove(h); h.material.dispose(); }
      for (const ent of entidades || []) {
        const obj = objetos.get(ent.id);
        if (!obj) continue;
        if (ent.tipo === 'luz') {
          // se usa el mismo objeto de la entidad: lo que se cambie en el inspector se ve al instante
          const cfg = ent.luz && ent.luz.alcance !== undefined ? ent.luz : { ...LUZ_BASE, ...(ent.luz || {}) };
          this.fuentes.push({ obj, local: new T.Vector3(), cfg, fase: Math.random() * 100, entId: ent.id, apagada: !!(this.enJuego && cfg.apagada) });
        } else if (ent.tipo === 'modelo') {
          const vistos = new Set();
          obj.traverse((o) => {
            if (!o.isMesh) return;
            for (const mat of Array.isArray(o.material) ? o.material : [o.material]) {
              const cl = mat && mat.userData.cfgLuz;
              if (!cl || vistos.has(mat)) continue;
              vistos.add(mat);
              const centros = centrosDeMaterial(obj, mat, Math.max(0.2, cl.agrupar || 1.5), `${ent.asset}|${mat.uuid}|${cl.agrupar}`);
              for (const c of centros) this.fuentes.push({ obj, local: c, cfg: cl, fase: Math.random() * 100, mat });
            }
          });
        }
      }
      this.reparto = 0;
      for (let i = 0; i < this.asignadas.length; i++) this.asignadas[i] = null;
      // un aura por fuente que la tenga
      for (const f of this.fuentes) {
        if (!(f.cfg.halo > 0)) continue;
        const sp = new T.Sprite(new T.SpriteMaterial({
          map: f.cfg.haloForma === 'estrella' ? this.texEstrella : this.texHalo, color: f.cfg.color, transparent: true, blending: T.AdditiveBlending, depthWrite: false, fog: true,
        }));
        sp.renderOrder = 10;
        sp.userData.ayudaEditor = true;
        sp.raycast = () => {};
        sp.visible = false;
        f.halo = sp;
        this.halos.add(sp);
      }
      this.pintarMarcas();
    }

    // Editor: un punto donde cada material "Emite luz" puso una fuente (para ver que sí se crearon)
    pintarMarcas() {
      if (this.marcas) { this.vista.escena.remove(this.marcas); this.marcas.geometry.dispose(); this.marcas = null; }
      if (!this.mostrarMarcas) return;
      const deMaterial = this.fuentes.filter((f) => f.mat);
      if (!deMaterial.length) return;
      const pos = new Float32Array(deMaterial.length * 3), col = new Float32Array(deMaterial.length * 3);
      const c = new T.Color(), v = new T.Vector3();
      deMaterial.forEach((f, i) => {
        f.obj.updateMatrixWorld(true);
        v.copy(f.local).applyMatrix4(f.obj.matrixWorld);
        pos.set([v.x, v.y, v.z], i * 3);
        c.set(f.cfg.color);
        col.set([c.r, c.g, c.b], i * 3);
      });
      const geo = new T.BufferGeometry();
      geo.setAttribute('position', new T.BufferAttribute(pos, 3));
      geo.setAttribute('color', new T.BufferAttribute(col, 3));
      this.marcas = new T.Points(geo, new T.PointsMaterial({ size: 9, sizeAttenuation: false, vertexColors: true, depthTest: false, fog: false }));
      this.marcas.renderOrder = 1e6;
      this.marcas.userData.ayudaEditor = true;
      this.marcas.raycast = () => {};
      this.marcas.visible = this.activo && !this.enJuego;
      this.vista.escena.add(this.marcas);
    }

    // Cuántas fuentes creó un material (para el inspector)
    cuantasDe(mat) {
      return this.fuentes.filter((f) => f.mat === mat).length;
    }

    // Cada cuadro, antes de dibujar
    actualizar(dt, cam) {
      if (this.sombrasSol) this.seguirSol(cam);
      if (!this.activo || !this.pool.length) { if (this.halos.visible) { this.t += dt; this.actualizarHalos(cam); } return; }
      this.t += dt;
      this.reparto -= dt;
      const pc = cam.position;
      if (this.reparto <= 0) {
        this.reparto = 0.2;
        // las más cercanas (restando su alcance: una fogata grande lejos gana a una vela cerca)
        const lista = [];
        for (const f of this.fuentes) {
          if (!f.obj.parent || f.apagada) continue;
          f.mundo = (f.mundo || new T.Vector3()).copy(f.local).applyMatrix4(f.obj.matrixWorld);
          const d = f.mundo.distanceTo(pc) - f.cfg.alcance;
          if (d < 80) lista.push([d, f]);
        }
        lista.sort((x, y) => x[0] - y[0]);
        const elegidas = new Set(lista.slice(0, this.pool.length).map((x) => x[1]));
        // las que siguen elegidas se quedan en su luz (sin saltos); las nuevas ocupan los huecos
        for (let i = 0; i < this.asignadas.length; i++) {
          if (this.asignadas[i] && elegidas.has(this.asignadas[i])) elegidas.delete(this.asignadas[i]);
          else this.asignadas[i] = null;
        }
        const nuevas = [...elegidas];
        for (let i = 0; i < this.asignadas.length && nuevas.length; i++) {
          if (!this.asignadas[i]) { this.asignadas[i] = nuevas.shift(); this.pool[i].userData.fundido = 0; }
        }
      }
      for (let i = 0; i < this.pool.length; i++) {
        const l = this.pool[i], f = this.asignadas[i];
        if (!f) { l.intensity = 0; continue; }
        const c = f.cfg;
        l.position.copy(f.local).applyMatrix4(f.obj.matrixWorld);
        l.color.set(c.color);
        l.distance = c.alcance;
        // aparece en 0.25 s para que no "salte" al repartirse
        l.userData.fundido = Math.min(1, (l.userData.fundido || 0) + dt * 4);
        let k = 1;
        if (c.parpadeo > 0) {
          k = 1 - c.parpadeo * parpadeo(this.t, c.velocidad || 8, f.fase);
          l.position.y += (k - 0.5) * 0.04 * c.parpadeo;   // la llama "baila" un poco
        }
        // fuerza 1 ≈ el sol a media distancia del alcance
        l.intensity = c.fuerza * Math.PI * (c.alcance * 0.5) * k * l.userData.fundido;
      }
      this.actualizarHalos(cam);
    }

    /* Auras: se ven aunque su luz no esté entre las "a la vez" (son baratas). Parpadean con su luz.
       Se acercan un poco a la cámara para que la pared o la antorcha no las corten por la mitad. */
    actualizarHalos(cam) {
      if (!this.halos.visible) return;
      if (this.marcas) this.marcas.visible = this.mostrarMarcas && !this.enJuego;
      const pc = cam.position, v = this._v;
      for (const f of this.fuentes) {
        const sp = f.halo;
        if (!sp) continue;
        if (!f.obj.parent || f.apagada) { sp.visible = false; continue; }
        sp.position.copy(f.local).applyMatrix4(f.obj.matrixWorld);
        const d = sp.position.distanceTo(pc);
        const c = f.cfg;
        if (d > 70 || !(c.halo > 0)) { sp.visible = false; continue; }
        sp.visible = true;
        const k = c.parpadeo > 0 ? 1 - c.parpadeo * parpadeo(this.t, c.velocidad || 8, f.fase) : 1;
        const tam = (c.haloTam || 1.2) * (0.85 + 0.15 * k);
        v.copy(pc).sub(sp.position).normalize();
        sp.position.addScaledVector(v, Math.min(tam * 0.5, d * 0.5));
        sp.scale.set(tam, tam, 1);
        sp.material.color.set(c.color);
        // de cerca se apaga un poco: si no, al pasar junto a una antorcha tapa la pantalla
        const cerca = Math.min(1, Math.max(0.15, (d - tam * 0.5) / (tam * 2)));
        sp.material.opacity = Math.min(1, c.halo * this.multHalo * k * cerca);
      }
    }

    /* El mapa de sombras del sol cubre un cuadro alrededor de la cámara y se mueve a saltos de un píxel
       de sombra (si no, los bordes "titilan" al caminar) */
    seguirSol(cam) {
      const sol = this.vista.sol, d = this.distSombras;
      const dir = this._v.copy(this.vista.direccionSol).normalize();
      const adelante = cam.isOrthographicCamera ? 1000 : d * 0.35;   // vistas orto del editor: la cámara está a 1 km
      const centro = this._centro.set(0, 0, -adelante).applyQuaternion(cam.quaternion).add(cam.position);
      if (!this._base) this._base = new T.Matrix4();
      this._base.lookAt(new T.Vector3(), dir.clone().negate(), Math.abs(dir.y) > 0.99 ? new T.Vector3(0, 0, 1) : new T.Vector3(0, 1, 0));
      const inv = this._base.clone().invert();
      const texel = (2 * d) / (this.tamSombra || 1024);
      centro.applyMatrix4(inv);
      centro.x = Math.round(centro.x / texel) * texel;
      centro.y = Math.round(centro.y / texel) * texel;
      centro.applyMatrix4(this._base);
      sol.target.position.copy(centro);
      sol.position.copy(centro).addScaledVector(dir, d * 2 + 20);
      const sc = sol.shadow.camera;
      if (sc.right !== d || sc.far !== d * 4 + 40) {
        sc.left = -d; sc.right = d; sc.top = d; sc.bottom = -d;
        sc.near = 0.5; sc.far = d * 4 + 40;
        sc.updateProjectionMatrix();
        sol.shadow.bias = -0.0004;
        sol.shadow.normalBias = texel * 1.2;
      }
      sol.target.updateMatrixWorld();
    }
  }

  /* Sombras de un objeto de la escena: proyecta si la entidad lo dice y su material no es transparente; recibe siempre */
  function aplicarSombras(obj, proyecta) {
    obj.traverse((o) => {
      if (!o.isMesh) return;
      if (o.userData.ayudaEditor) { o.castShadow = o.receiveShadow = false; return; }
      const mats = Array.isArray(o.material) ? o.material : [o.material];
      o.castShadow = proyecta && !mats.some((m) => m && (m.transparent || m.blending === T.AdditiveBlending));
      o.receiveShadow = true;
    });
  }

  F.Luces = Luces;
  F.Luces.LUZ_BASE = LUZ_BASE;
  F.Luces.PRESETS = PRESETS;
  F.Luces.aplicarSombras = aplicarSombras;
})(window.FORJA);
