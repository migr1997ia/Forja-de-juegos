/* =========================================================
   FORJA · ENTRADA (≈ Input Map de Godot)
   Los módulos nunca leen teclas directamente: preguntan por ACCIONES.
     FORJA.Entrada.mantenido('correr')   → true mientras se pulsa
     FORJA.Entrada.pulsado('saltar')     → true solo en el cuadro en que se pulsa
     FORJA.Entrada.mover                 → { x, y }  (y positivo = adelante)
     FORJA.Entrada.mirar                 → { x, y }  giro de cámara de este cuadro
   Mandos: distribución estándar (Xbox / PlayStation):
     0 A/✕  1 B/○  2 X/□  3 Y/△  4 LB/L1  5 RB/R1  6 LT/L2  7 RT/R2
     8 Back/Share  9 Start/Options  10 L3  11 R3  12-15 cruceta
   ========================================================= */
(function (F) {
  'use strict';

  const MAPA_BASE = {
    adelante:       { teclas: ['KeyW', 'ArrowUp'], botones: [12] },
    atras:          { teclas: ['KeyS', 'ArrowDown'], botones: [13] },
    izquierda:      { teclas: ['KeyA', 'ArrowLeft'], botones: [14] },
    derecha:        { teclas: ['KeyD', 'ArrowRight'], botones: [15] },
    saltar:         { teclas: ['Space'], botones: [0] },
    correr:         { teclas: ['ShiftLeft', 'ShiftRight'], botones: [10] },
    esquivar:       { teclas: ['KeyQ'], botones: [4] },
    agachar:        { teclas: ['ControlLeft', 'KeyC'], botones: [1] },
    interactuar:    { teclas: ['KeyE'], botones: [2] },
    inventario:     { teclas: ['Tab', 'KeyI'], botones: [] },
    linterna:       { teclas: ['KeyF'], botones: [11] },
    atacar:         { teclas: [], raton: [0], botones: [7] },
    apuntar:        { teclas: [], raton: [2], botones: [6] },
    recargar:       { teclas: ['KeyR'], botones: [5] },
    cambiar_camara: { teclas: ['KeyV'], botones: [8] },
    // ratón 10 / 11 = rueda abajo / arriba
    arma_siguiente: { teclas: [], raton: [10], botones: [3] },
    arma_anterior:  { teclas: [], raton: [11], botones: [] },
    depurar:        { teclas: ['F3'], botones: [] },
    pausa:          { teclas: ['Escape'], botones: [9] },
    objetivos:      { teclas: ['KeyO'], botones: [] },
    asomar_izq:     { teclas: ['KeyZ'], botones: [] },
    asomar_der:     { teclas: ['KeyX'], botones: [] },
    ordenes:        { teclas: ['KeyG'], botones: [] },
    especial:       { teclas: ['KeyB'], raton: [1], botones: [] },
    fijar:          { teclas: ['KeyT'], botones: [] },
    bloquear:       { teclas: ['KeyH'], botones: [] },
    escudo:         { teclas: ['KeyN'], botones: [] },
  };

  // Nombres para mostrar (menú de Opciones → Controles). El orden es el de la lista.
  const ETIQUETAS = {
    adelante: 'Adelante', atras: 'Atrás', izquierda: 'Izquierda', derecha: 'Derecha',
    saltar: 'Saltar', correr: 'Correr', esquivar: 'Esquivar / dash', agachar: 'Agacharse', interactuar: 'Usar / interactuar', inventario: 'Inventario', linterna: 'Linterna',
    atacar: 'Atacar / disparar', apuntar: 'Apuntar', recargar: 'Recargar',
    arma_siguiente: 'Arma siguiente', arma_anterior: 'Arma anterior', cambiar_camara: 'Cambiar cámara', pausa: 'Pausa', ordenes: 'Órdenes al equipo', objetivos: 'Ver objetivos', asomar_izq: 'Asomarse a la izquierda', asomar_der: 'Asomarse a la derecha', especial: 'Ataque especial (área)', fijar: 'Fijar objetivo', bloquear: 'Bloquear / guardia', escudo: 'Guardar / sacar el escudo',
  };

  const E = {
    mapa: F.util.copiar(MAPA_BASE),
    mover: { x: 0, y: 0 },
    mirar: { x: 0, y: 0 },
    sensRaton: 1,
    sensMando: 1,
    invertirY: false,
    zonaMuerta: 0.15,
    mandoPermitido: typeof navigator.getGamepads === 'function',
    mando: null,
    bloqueado: false,          // cursor bloqueado (pointer lock)
    sinBloqueo: false,         // el navegador no deja bloquear: se mira arrastrando
  };

  /* Entrada virtual: la llenan los controles táctiles (motor/tactil.js) igual que si fuera un mando */
  const virtual = { x: 0, y: 0, mx: 0, my: 0, acciones: new Set(), toques: new Set() };
  E.virtual = virtual;
  E.sensTactil = 1;
  E.multRaton = 1;           // Opciones del jugador (se multiplican a las del módulo Cámara)
  E.multMando = 1;
  E.invertirJugador = false;
  E.tactil = false;          // controles táctiles a la vista: no se intenta bloquear el cursor

  const teclas = new Set();
  const botonesRaton = new Set();
  // Pulsaciones desde el último cuadro: un toque rapidísimo (bajar y subir entre dos cuadros) no se pierde
  const toques = new Set();
  const toquesRaton = new Set();
  let ratonDX = 0, ratonDY = 0, arrastrando = false;
  let estadoPrevio = {}, estadoActual = {};
  let elemento = null;

  function leerMando() {
    if (!E.mandoPermitido) return null;
    let lista;
    try {
      lista = navigator.getGamepads() || [];
    } catch (err) {
      E.mandoPermitido = false;
      F.aviso('El mando está bloqueado aquí (la página está dentro de otro marco). Abre el archivo directo en el navegador para usarlo.', 'error');
      return null;
    }
    for (const gp of lista) if (gp && gp.connected) return gp;
    return null;
  }

  const zm = (v) => (Math.abs(v) < E.zonaMuerta ? 0 : (v - Math.sign(v) * E.zonaMuerta) / (1 - E.zonaMuerta));

  // Se llama una vez por cuadro, antes que los módulos
  E.actualizar = function (dt) {
    const gp = (E.mando = leerMando());
    neutro = false;
    estadoPrevio = estadoActual;
    estadoActual = {};
    for (const [accion, m] of Object.entries(E.mapa)) {
      let activo = (m.teclas || []).some((t) => teclas.has(t) || toques.has(t)) ||
        (m.raton || []).some((b) => botonesRaton.has(b) || toquesRaton.has(b));
      if (!activo && gp) activo = (m.botones || []).some((i) => gp.buttons[i] && gp.buttons[i].pressed);
      if (!activo) activo = virtual.acciones.has(accion) || virtual.toques.has(accion);
      estadoActual[accion] = activo;
    }
    E.teclasCuadro = new Set(toques);   // teclas pulsadas desde el cuadro anterior (para 1-9 de las armas)
    toques.clear();
    virtual.toques.clear();
    toquesRaton.clear();

    // Movimiento: acciones adelante/atrás/izquierda/derecha (teclado o cruceta) + stick izquierdo
    let mx = 0, my = 0;
    if (estadoActual.adelante) my += 1;
    if (estadoActual.atras) my -= 1;
    if (estadoActual.derecha) mx += 1;
    if (estadoActual.izquierda) mx -= 1;
    if (gp) {
      const lx = zm(gp.axes[0] || 0), ly = zm(gp.axes[1] || 0);
      if (lx || ly) { mx = lx; my = -ly; }
    }
    if (virtual.x || virtual.y) { mx = virtual.x; my = virtual.y; }
    const l = Math.hypot(mx, my);
    if (l > 1) { mx /= l; my /= l; }
    E.mover.x = mx;
    E.mover.y = my;

    // Mirar: ratón + stick derecho
    // sensibilidad = la del módulo Cámara × la que eligió el jugador en Opciones
    const sr = E.sensRaton * E.multRaton, sm = E.sensMando * E.multMando;
    let gx = ratonDX * 0.0022 * sr, gy = ratonDY * 0.0022 * sr;
    ratonDX = ratonDY = 0;
    gx += virtual.mx * 0.0035 * E.sensTactil;
    gy += virtual.my * 0.0035 * E.sensTactil;
    virtual.mx = virtual.my = 0;
    if (gp) {
      gx += zm(gp.axes[2] || 0) * 2.8 * sm * dt;
      gy += zm(gp.axes[3] || 0) * 2.2 * sm * dt;
    }
    E.mirar.x = gx;
    E.mirar.y = E.invertirY !== E.invertirJugador ? -gy : gy;
  };

  // Sin control este cuadro (jugador muerto, leyendo un mensaje…): nada se mueve ni se pulsa
  // OJO: no se borra el estado de las teclas, solo se "tapa" este cuadro. Si se borrara, un botón que sigue
  // pulsado (dedo en la pantalla) parecería pulsarse otra vez en el cuadro siguiente (abría el mensaje sin parar).
  let neutro = false;
  E.neutralizar = function () {
    E.mover.x = E.mover.y = 0;
    E.mirar.x = E.mirar.y = 0;
    neutro = true;
  };

  E.mantenido = (accion) => !neutro && !!estadoActual[accion];
  E.pulsado = (accion) => !neutro && !!estadoActual[accion] && !estadoPrevio[accion];
  E.soltado = (accion) => !neutro && !estadoActual[accion] && !!estadoPrevio[accion];

  E.limpiar = function () {
    teclas.clear();
    botonesRaton.clear();
    toques.clear();
    toquesRaton.clear();
    ratonDX = ratonDY = 0;
    virtual.x = virtual.y = virtual.mx = virtual.my = 0;
    virtual.acciones.clear();
    virtual.toques.clear();
    estadoPrevio = estadoActual = {};
  };

  /* ---------- Bloqueo del cursor (pointer lock) con respaldo por arrastre ---------- */
  let avisado = false;
  function sinBloqueo() {
    E.sinBloqueo = true;           // mientras tanto se mira arrastrando
    if (avisado) return;
    avisado = true;
    F.aviso('El navegador no deja bloquear el cursor aquí: <b>arrastra con el ratón</b> para mirar. Abriendo el archivo directo en Chrome/Edge se bloquea normal.', 'error');
  }

  E.pedirBloqueo = function () {
    if (!elemento || E.bloqueado || E.tactil) return;
    try {
      const pr = elemento.requestPointerLock();
      if (pr && pr.catch) pr.catch(sinBloqueo);
    } catch (err) {
      sinBloqueo();
    }
  };

  E.soltarBloqueo = function () {
    if (document.pointerLockElement) document.exitPointerLock();
  };

  /* ---------- Escuchar el dispositivo ----------
     elemento: el canvas del juego. Se llama una sola vez. */
  E.escuchar = function (el) {
    elemento = el;
    const evitar = ['Space', 'ArrowUp', 'ArrowDown', 'ArrowLeft', 'ArrowRight', 'F3', 'Tab'];
    window.addEventListener('keydown', (e) => {
      if (!E.activo) return;
      teclas.add(e.code);
      toques.add(e.code);
      if (evitar.includes(e.code)) e.preventDefault();
    });
    window.addEventListener('keyup', (e) => teclas.delete(e.code));
    window.addEventListener('blur', () => E.limpiar());
    // Rueda del ratón como "botones" 10 (abajo) y 11 (arriba): sirven para cambiar de arma
    el.addEventListener('wheel', (e) => {
      if (!E.activo) return;
      toquesRaton.add(e.deltaY > 0 ? 10 : 11);
    }, { passive: true });
    el.addEventListener('mousedown', (e) => {
      if (!E.activo) return;
      // el clic que vuelve a capturar el ratón (tras el inventario, un menú…) no dispara: solo captura
      if (!E.bloqueado && !E.sinBloqueo && !E.tactil) { E.pedirBloqueo(); return; }
      botonesRaton.add(e.button);
      toquesRaton.add(e.button);
      arrastrando = true;
      if (!E.bloqueado) E.pedirBloqueo();
    });
    window.addEventListener('mouseup', (e) => {
      botonesRaton.delete(e.button);
      arrastrando = false;
    });
    el.addEventListener('contextmenu', (e) => { if (E.activo) e.preventDefault(); });
    document.addEventListener('mousemove', (e) => {
      if (!E.activo) return;
      if (E.bloqueado || arrastrando) {
        ratonDX += e.movementX || 0;
        ratonDY += e.movementY || 0;
      }
    });
    document.addEventListener('pointerlockchange', () => {
      const antes = E.bloqueado;
      E.bloqueado = document.pointerLockElement === elemento;
      if (E.bloqueado) E.sinBloqueo = false;
      // el inventario suelta el ratón a propósito (silencioLiberar): eso no es "pausa"
      if (antes && !E.bloqueado) { if (E.silencioLiberar) E.silencioLiberar = false; else F.emitir('cursor-liberado'); }
    });
    document.addEventListener('pointerlockerror', sinBloqueo);
  };

  E.activo = false;   // solo se leen controles mientras se juega

  E.mapaBase = () => F.util.copiar(MAPA_BASE);
  E.ETIQUETAS = ETIQUETAS;

  /* Controles personalizados del jugador: { accion: { teclas, raton, botones } } solo con lo que cambió.
     usarMapa(null) = los de fábrica. */
  E.usarMapa = function (personal) {
    const m = F.util.copiar(MAPA_BASE);
    for (const [k, v] of Object.entries(personal || {})) if (m[k]) Object.assign(m[k], F.util.copiar(v));
    E.mapa = m;
  };

  /* ---------- Nombres de teclas y botones (para los menús) ---------- */
  const NOMBRES_TECLA = {
    Space: 'Espacio', ShiftLeft: 'Shift', ShiftRight: 'Shift der.', ControlLeft: 'Ctrl', ControlRight: 'Ctrl der.',
    AltLeft: 'Alt', AltRight: 'Alt Gr', Escape: 'Esc', Enter: 'Enter', Tab: 'Tab', Backspace: 'Retroceso',
    ArrowUp: '↑', ArrowDown: '↓', ArrowLeft: '←', ArrowRight: '→', CapsLock: 'Bloq Mayús',
  };
  E.nombreTecla = function (code) {
    if (NOMBRES_TECLA[code]) return NOMBRES_TECLA[code];
    if (/^Key[A-Z]$/.test(code)) return code.slice(3);
    if (/^Digit\d$/.test(code)) return code.slice(5);
    if (/^Numpad/.test(code)) return 'Num ' + code.slice(6);
    return code;
  };
  const NOMBRES_RATON = ['Clic izq.', 'Clic central', 'Clic der.', 'Ratón 4', 'Ratón 5', '', '', '', '', '', 'Rueda ↓', 'Rueda ↑'];
  const NOMBRES_BOTON = ['A / ✕', 'B / ○', 'X / □', 'Y / △', 'LB / L1', 'RB / R1', 'LT / L2', 'RT / R2',
    'Back / Share', 'Start / Options', 'L3', 'R3', 'Cruceta ↑', 'Cruceta ↓', 'Cruceta ←', 'Cruceta →'];
  E.nombreBoton = (i) => NOMBRES_BOTON[i] || 'Botón ' + i;
  // Texto de lo que activa una acción: "Espacio" · "Clic izq." · "A / ✕"
  E.textoTeclado = function (accion) {
    const m = E.mapa[accion] || {};
    const partes = [...(m.teclas || []).map(E.nombreTecla), ...(m.raton || []).map((b) => NOMBRES_RATON[b] || 'Ratón ' + b)];
    return partes.join(' / ') || '—';
  };
  E.textoMando = function (accion) {
    const m = E.mapa[accion] || {};
    return (m.botones || []).map(E.nombreBoton).join(' / ') || '—';
  };
  E.leerMando = leerMando;
  F.Entrada = E;
})(window.FORJA);
