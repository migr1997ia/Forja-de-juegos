/* =========================================================
   FORJA · EFECTOS DE CÁMARA (VHS, CRT, cámara de video de los 90, Game Boy, cámara de seguridad)
   Una capa encima de la imagen final: el nivel se dibuja en una textura pequeña (la resolución retro)
   y luego un solo pase a pantalla completa le pone líneas de barrido, curvatura, sangrado de color,
   ruido, temblor de cinta (tracking), viñeta, paleta de colores limitada, color y tono, y el letrero
   (● REC de cámara casera o CAM 03 de cámara de seguridad) con fecha y hora.

   Dónde se configura:
     · Proyecto ▸ Imagen y rendimiento ▸ 📼 Efectos de cámara  → lo de todo el juego
     · Escena ▸ 📼 Efectos de cámara ▸ "Efectos propios en este nivel" → ese nivel usa los suyos
   Estilos listos que rellenan los controles finos; cada control tiene su ↺ que vuelve al valor del estilo.

   💥 Momentos (efectos que pone el juego un rato, aunque el nivel no tenga estilo):
     golpe (daño: sacudida y colores corridos), gris (muerte: blanco y negro), onda (bajo el agua),
     mareo (envenenado), doble (aturdido: vista doble) y tinte de bordes (quemado, congelado).
     F.Efectos.momento(vista, 'golpe', 1) · los ponen salud.js, agua.js y estados.js.

   Coste: un pase de pantalla. Sin estilo y sin momentos no existe: el motor dibuja como siempre.
   Para las cinemáticas: vista.forzarEfectos(cfg | null) pone otros efectos encima de los del nivel.
   ========================================================= */
(function (F) {
  'use strict';
  const T = THREE;

  /* ---------- Paletas listas (hasta 16 colores) ---------- */
  const PALETAS = {
    gameboy: ['#0f380f', '#306230', '#8bac0f', '#9bbc0f'],
    grises: ['#000000', '#555555', '#aaaaaa', '#ffffff'],
    fosforo: ['#031a05', '#0b4a14', '#22a63a', '#7dff8f'],
    cga: ['#000000', '#55ffff', '#ff55ff', '#ffffff'],
    sepia: ['#2b1d0e', '#5a3d1e', '#8c6239', '#b98d5a', '#e0c194', '#f6e7c8'],
    noche: ['#05070f', '#141a2e', '#24345a', '#3f5a8a', '#7f95d6', '#c8d6ff'],
    nes: ['#000000', '#7c7c7c', '#bcbcbc', '#fcfcfc', '#a81000', '#f83800', '#fca044', '#f8b800',
      '#00a800', '#58d854', '#0058f8', '#3cbcfc', '#6844fc', '#d800cc', '#503000', '#ac7c00'],
    pico8: ['#000000', '#1d2b53', '#7e2553', '#008751', '#ab5236', '#5f574f', '#c2c3c7', '#fff1e8',
      '#ff004d', '#ffa300', '#ffec27', '#00e436', '#29adff', '#83769c', '#ff77a8', '#ffccaa'],
  };
  const OP_PALETAS = [['no', 'Sin paleta (todos los colores)'], ['gameboy', '🟩 Game Boy (4 verdes)'], ['grises', '⬜ Grises (4)'],
    ['fosforo', '📟 Fósforo verde (4)'], ['cga', '💠 CGA (4)'], ['sepia', '🟫 Sepia (6)'], ['noche', '🌙 Noche azul (6)'],
    ['nes', '🎮 NES (16)'], ['pico8', '🕹 PICO-8 (16)'], ['propia', '✏ Propia (hasta 8)']];

  /* ---------- Estilos listos ----------
     Cada uno da valor a todos los controles finos (menos los colores de la paleta propia). */
  const NEUTRO = {
    fxLineas: 0, fxCurva: 0, fxSangrado: 0, fxRuido: 0, fxTracking: 0, fxVineta: 0, fxRec: false, fxLetrero: 'casera',
    fxPaleta: 'no', fxTramado: 0.5, fxSaturacion: 1, fxContraste: 1, fxBrillo: 0, fxTinte: '#ffffff', fxTinteFuerza: 0,
    fxBarras: 0, fxToon: 0, fxToonSombra: 0.45, fxContorno: 0, fxContornoColor: '#000000', fxContornoGrosor: 1,
  };
  const ESTILOS = {
    vhs:       { ...NEUTRO, fxLineas: 0.25, fxCurva: 0.15, fxSangrado: 0.7, fxRuido: 0.25, fxTracking: 0.5, fxVineta: 0.4, fxSaturacion: 1.15 },
    crt:       { ...NEUTRO, fxLineas: 0.7, fxCurva: 0.6, fxSangrado: 0.2, fxRuido: 0.1, fxVineta: 0.55, fxContraste: 1.1 },
    camara90:  { ...NEUTRO, fxLineas: 0.15, fxCurva: 0.1, fxSangrado: 0.5, fxRuido: 0.2, fxTracking: 0.25, fxVineta: 0.3, fxRec: true, fxSaturacion: 0.85 },
    gameboy:   { ...NEUTRO, fxLineas: 0.2, fxVineta: 0.15, fxPaleta: 'gameboy', fxTramado: 0.6, fxContraste: 1.1 },
    seguridad: { ...NEUTRO, fxLineas: 0.5, fxCurva: 0.35, fxSangrado: 0.2, fxRuido: 0.55, fxTracking: 0.15, fxVineta: 0.6,
      fxRec: true, fxLetrero: 'seguridad', fxSaturacion: 0, fxContraste: 1.3, fxBrillo: -0.05, fxTinte: '#b8ffc0', fxTinteFuerza: 0.35 },
    anime:     { ...NEUTRO, fxToon: 3, fxToonSombra: 0.5, fxContorno: 1, fxContornoGrosor: 1, fxSaturacion: 1.2, fxContraste: 1.05, fxBrillo: 0.03 },
    propio:    { ...NEUTRO },
  };

  const hayFx = (v) => v.fxEstilo && v.fxEstilo !== 'ninguno';

  /* Esquema de los efectos, con sus 3 secciones. Lo usan el Proyecto (todo el juego) y el ambiente de cada
     escena (con fxPropio, que escena.js mete al principio de la primera sección). */
  const ESQUEMA = [
    { grupo: '📼 Efectos de cámara (VHS / CRT)' },
    { k: 'fxEstilo', t: 'sel', e: 'Estilo', def: 'ninguno',
      op: [['ninguno', 'Apagado'], ['vhs', '📼 VHS'], ['crt', '📺 CRT arcade'], ['camara90', '🎥 Cámara de video 90s'],
        ['gameboy', '🟩 Game Boy'], ['seguridad', '📟 Cámara de seguridad'], ['anime', '🎌 Anime (cel shading)'], ['propio', '✏ Propio (empieza vacío)']],
      ayuda: 'Elegir un estilo rellena todos los controles (también paleta y tono). Luego puedes mover cada uno; su ↺ lo vuelve al valor del estilo' },
    { k: 'fxLineas', t: 'rango', e: 'Líneas CRT', def: 0, min: 0, max: 1, paso: 0.05, si: hayFx,
      ayuda: 'Las rayas horizontales de una tele de tubo (una por cada línea de la resolución) y la rejilla de colores' },
    { k: 'fxCurva', t: 'rango', e: 'Curvatura', def: 0, min: 0, max: 1, paso: 0.05, si: hayFx,
      ayuda: 'La pantalla se abomba como un tubo de cristal; las esquinas quedan negras' },
    { k: 'fxSangrado', t: 'rango', e: 'Sangrado de color', def: 0, min: 0, max: 1, paso: 0.05, si: hayFx,
      ayuda: 'El rojo y el azul se corren a los lados y el color se emborrona, como una cinta VHS' },
    { k: 'fxRuido', t: 'rango', e: 'Ruido / grano', def: 0, min: 0, max: 1, paso: 0.05, si: hayFx,
      ayuda: 'Grano que se mueve en toda la imagen' },
    { k: 'fxTracking', t: 'rango', e: 'Temblor de cinta', def: 0, min: 0, max: 1, paso: 0.05, si: hayFx,
      ayuda: 'La imagen tiembla de lado y una franja de interferencia baja por la pantalla (tracking de VHS)' },
    { k: 'fxVineta', t: 'rango', e: 'Viñeta', def: 0, min: 0, max: 1, paso: 0.05, si: hayFx,
      ayuda: 'Oscurece los bordes de la pantalla' },
    { k: 'fxBarras', t: 'rango', e: 'Barras de cine', def: 0, min: 0, max: 0.25, paso: 0.01, si: hayFx,
      ayuda: 'Franjas negras arriba y abajo, como en el cine. 0.12 ≈ pantalla de película. Las cinemáticas también las pueden poner' },
    { k: 'fxRec', t: 'bool', e: 'Letrero en pantalla', def: false, si: hayFx,
      ayuda: 'Cámara casera: ● REC, pila, fecha y hora · Cámara de seguridad: nombre de la cámara, ● REC, fecha y hora. La hora avanza mientras juegas' },
    { k: 'fxLetrero', t: 'sel', e: 'Tipo de letrero', def: 'casera', si: (v) => hayFx(v) && v.fxRec,
      op: [['casera', '🎥 Cámara casera'], ['seguridad', '📟 Cámara de seguridad']] },
    { k: 'fxCamNombre', t: 'texto', e: 'Nombre de la cámara', def: 'CAM 03', si: (v) => hayFx(v) && v.fxRec && v.fxLetrero === 'seguridad',
      ayuda: 'Arriba a la izquierda (ej. CAM 01 · PASILLO B)' },
    { k: 'fxRecFecha', t: 'texto', e: 'Fecha', def: 'OCT. 16 1997', si: (v) => hayFx(v) && v.fxRec,
      ayuda: 'El texto de la fecha, tal cual (ej. ENE. 03 1999)' },
    { k: 'fxRecHora', t: 'texto', e: 'Hora al empezar', def: '11:47 PM', si: (v) => hayFx(v) && v.fxRec,
      ayuda: 'Formato 23:47 o 11:47 PM. Los segundos avanzan solos desde ahí' },

    { grupo: '🎨 Paleta de colores limitada', si: hayFx },
    { k: 'fxPaleta', t: 'sel', e: 'Paleta', def: 'no', op: OP_PALETAS,
      ayuda: 'Todo el juego se dibuja solo con estos colores, como las consolas viejas' },
    { k: 'fxTramado', t: 'rango', e: 'Tramado', def: 0.5, min: 0, max: 1, paso: 0.05, si: (v) => v.fxPaleta && v.fxPaleta !== 'no',
      ayuda: 'Mezcla dos colores de la paleta con un patrón de puntos para que los degradados no se vean a manchas. 0 = manchas planas' },
    { k: 'fxPaletaN', t: 'sel', e: 'Cuántos colores', def: 4, si: (v) => v.fxPaleta === 'propia',
      op: [[2, '2'], [3, '3'], [4, '4'], [5, '5'], [6, '6'], [7, '7'], [8, '8']] },
    ...['#000000', '#3a2a4a', '#7a4a5a', '#c08060', '#f0d0a0', '#ffffff', '#4a7ab0', '#80c070'].map((c, i) => ({
      k: 'fxColor' + (i + 1), t: 'color', e: 'Color ' + (i + 1), def: c, si: (v) => v.fxPaleta === 'propia' && (v.fxPaletaN || 4) > i })),

    { grupo: '🎌 Anime / cel shading', si: hayFx },
    { k: 'fxToon', t: 'sel', e: 'Luz en tonos', def: 0, op: [[0, 'Apagado (luz normal)'], [2, '2 tonos (anime clásico)'], [3, '3 tonos'], [4, '4 tonos']],
      ayuda: 'La luz cae en escalones duros en vez de degradado, como en un dibujo animado. Las texturas no cambian' },
    { k: 'fxToonSombra', t: 'rango', e: 'Claridad de la sombra', def: 0.45, min: 0.15, max: 0.85, paso: 0.05, si: (v) => v.fxToon > 0,
      ayuda: 'Lo más oscuro que queda una cara a la sombra. Alto = sombras suaves de anime · bajo = sombras duras' },
    { k: 'fxContorno', t: 'rango', e: 'Contorno', def: 0, min: 0, max: 1, paso: 0.05,
      ayuda: 'Línea alrededor de personajes y objetos (donde termina uno y empieza lo que está detrás). 0 = sin línea' },
    { k: 'fxContornoColor', t: 'color', e: 'Color del contorno', def: '#000000', si: (v) => v.fxContorno > 0 },
    { k: 'fxContornoGrosor', t: 'sel', e: 'Grosor', def: 1, op: [[1, 'Fino (1 píxel)'], [2, 'Grueso (2 píxeles)']], si: (v) => v.fxContorno > 0,
      ayuda: 'En píxeles de la resolución retro: a 240p un píxel ya se ve grueso' },

    { grupo: '🌗 Color y tono', si: hayFx },
    { k: 'fxSaturacion', t: 'rango', e: 'Saturación', def: 1, min: 0, max: 2, paso: 0.05, ayuda: '0 = blanco y negro · 1 = normal · 2 = colores muy vivos' },
    { k: 'fxContraste', t: 'rango', e: 'Contraste', def: 1, min: 0.5, max: 1.6, paso: 0.05 },
    { k: 'fxBrillo', t: 'rango', e: 'Brillo', def: 0, min: -0.5, max: 0.5, paso: 0.05 },
    { k: 'fxTinte', t: 'color', e: 'Tinte', def: '#ffffff', ayuda: 'Color que tiñe toda la imagen (verde tipo niebla de terror, ámbar de atardecer…)' },
    { k: 'fxTinteFuerza', t: 'rango', e: 'Fuerza del tinte', def: 0, min: 0, max: 1, paso: 0.05 },
  ];
  const CLAVES = ESQUEMA.filter((d) => d.k).map((d) => d.k);
  const DEF = Object.fromEntries(ESQUEMA.filter((d) => d.k).map((d) => [d.k, d.def]));

  /* Valores que da el estilo elegido (para el ↺ de cada control). Sin estilo: los de serie del esquema */
  function defectosDe(estilo) {
    const v = { ...DEF, ...(ESTILOS[estilo] || {}) };
    v.fxEstilo = 'ninguno';
    return v;
  }

  /* Pone los valores del estilo en un objeto (ajustes del proyecto o ambiente de la escena) */
  function aplicarEstilo(obj, estilo) {
    const e = ESTILOS[estilo];
    if (!e) return;
    for (const [k, v] of Object.entries(e)) obj[k] = v;
  }

  /* Los efectos que valen: los del nivel si tiene propios; si no, los del proyecto. null = sin efectos */
  function efectivos(ajustes, amb) {
    const fuente = amb && amb.fxPropio ? amb : ajustes;
    if (!fuente || !hayFx(fuente) || (ajustes && ajustes.fxJugadorApagado)) return null;
    const c = {};
    for (const k of CLAVES) c[k] = fuente[k] ?? DEF[k];
    // si todo está en neutro, es como apagado (no gastar el pase)
    const algo = c.fxLineas || c.fxCurva || c.fxSangrado || c.fxRuido || c.fxTracking || c.fxVineta || c.fxRec
      || (c.fxPaleta && c.fxPaleta !== 'no') || c.fxSaturacion !== 1 || c.fxContraste !== 1 || c.fxBrillo || c.fxTinteFuerza > 0
      || c.fxBarras > 0 || c.fxToon > 0 || c.fxContorno > 0;
    return algo ? c : null;
  }

  /* Colores de la paleta elegida (texto #rrggbb) */
  function coloresPaleta(c) {
    if (!c || !c.fxPaleta || c.fxPaleta === 'no') return [];
    if (c.fxPaleta === 'propia') {
      const n = Math.max(2, Math.min(8, c.fxPaletaN || 4)), L = [];
      for (let i = 1; i <= n; i++) L.push(c['fxColor' + i] || DEF['fxColor' + i]);
      return L;
    }
    return PALETAS[c.fxPaleta] || [];
  }
  // '#rrggbb' → [r, g, b] de 0 a 1 en sRGB (como se ve en pantalla; el pase trabaja así)
  function rgb(hex) {
    const n = parseInt(String(hex || '#ffffff').replace('#', '').padEnd(6, '0').slice(0, 6), 16) || 0;
    return [((n >> 16) & 255) / 255, ((n >> 8) & 255) / 255, (n & 255) / 255];
  }

  /* "23:47" o "11:47 PM" → segundos del día */
  function leerHora(txt) {
    const m = String(txt || '').trim().match(/^(\d{1,2})(?::(\d{2}))?(?::(\d{2}))?\s*([AaPp][Mm])?$/);
    if (!m) return 0;
    let h = +m[1] % 24;
    const pm = m[4] && m[4].toUpperCase() === 'PM';
    if (m[4]) { h = h % 12; if (pm) h += 12; }
    return h * 3600 + (+m[2] || 0) * 60 + (+m[3] || 0);
  }
  function escribirHora(seg, conAmPm) {
    seg = Math.floor(seg) % 86400;
    let h = Math.floor(seg / 3600);
    const mi = Math.floor(seg / 60) % 60, s = seg % 60;
    const dd = (n) => String(n).padStart(2, '0');
    if (!conAmPm) return `${dd(h)}:${dd(mi)}:${dd(s)}`;
    const pm = h >= 12;
    h = h % 12 || 12;
    return `${h}:${dd(mi)}:${dd(s)} ${pm ? 'PM' : 'AM'}`;
  }

  /* ---------- Shader del pase ---------- */
  const VERT = `
    varying vec2 vUv;
    void main() { vUv = uv; gl_Position = vec4(position.xy, 0.0, 1.0); }`;

  const FRAG = `
    uniform sampler2D tImagen;
    uniform sampler2D tTexto;
    uniform vec2 uTam;        // tamaño de la imagen retro (px)
    uniform vec2 uSalida;     // tamaño de la pantalla (px)
    uniform float uTiempo;
    uniform float uLineas, uCurva, uSangrado, uRuido, uTracking, uVineta, uTexto;
    // 🎨 paleta y 🌗 tono
    uniform vec3 uPal[16];
    uniform int uPalN;
    uniform float uTramado, uSaturacion, uContraste, uBrillo, uTinteF;
    uniform vec3 uTinte;
    // 💥 momentos
    uniform float uGolpe, uGris, uOnda, uMareo, uDoble, uBordeF;
    // 🎌 contorno (con la profundidad de la imagen) y barras de cine
    uniform sampler2D tProf;
    uniform float uContorno, uGrosor, uCerca, uLejos, uBarras;
    uniform vec3 uContornoColor;
    // 🎞 transiciones (cambio de nivel, cinemáticas): uTrans 0 = nada · 1 = pantalla cubierta
    uniform float uTrans, uTransTipo;
    uniform vec3 uTransColor;
    uniform vec3 uBorde;
    varying vec2 vUv;

    float azar(vec2 p) { return fract(sin(dot(p, vec2(12.9898, 78.233))) * 43758.5453); }

    // de lineal a sRGB (todo el pase trabaja en los colores "como se ven")
    vec3 aPantalla(vec3 c) {
      c = max(c, 0.0);
      return mix(c * 12.92, 1.055 * pow(c, vec3(1.0 / 2.4)) - 0.055, step(0.0031308, c));
    }

    // lectura con píxel grande (como el resto del motor: nada de suavizado)
    vec3 leer(vec2 uv) {
      vec2 px = (floor(uv * uTam) + 0.5) / uTam;
      return aPantalla(texture2D(tImagen, px).rgb);
    }

    // profundidad en metros desde la cámara
    float metros(vec2 uv) {
      float d = texture2D(tProf, (floor(uv * uTam) + 0.5) / uTam).x;
      return (uCerca * uLejos) / max(1e-6, uLejos - d * (uLejos - uCerca));
    }

    // patrón de tramado Bayer 4×4 (0..1)
    float bayer2(vec2 a) { a = floor(a); return fract(dot(a, vec2(0.5, a.y * 0.75))); }
    float bayer4(vec2 a) { return bayer2(0.5 * a) * 0.25 + bayer2(a); }

    void main() {
      vec2 uv = vUv;

      // 📺 curvatura del tubo
      if (uCurva > 0.0) {
        vec2 c = uv * 2.0 - 1.0;
        c *= 1.0 + dot(c, c) * uCurva * 0.12;
        c.x *= 1.0 + c.y * c.y * uCurva * 0.06;
        c.y *= 1.0 + c.x * c.x * uCurva * 0.06;
        uv = c * 0.5 + 0.5;
        if (uv.x < 0.0 || uv.x > 1.0 || uv.y < 0.0 || uv.y > 1.0) { gl_FragColor = vec4(0.0, 0.0, 0.0, 1.0); return; }
      }
      vec2 uvPantalla = uv;   // para el letrero y la viñeta (no se mueven con el mareo ni el agua)

      // 🎞 transición pixelado: los píxeles crecen hasta bloques enormes
      if (uTrans > 0.0 && abs(uTransTipo - 3.0) < 0.5) {
        float bloques = mix(uTam.y, 5.0, smoothstep(0.0, 0.75, uTrans));
        vec2 cel = vec2(bloques * uTam.x / uTam.y, bloques);
        uv = (floor(uv * cel) + 0.5) / cel;
      }

      // 💥 bajo el agua: la imagen ondula
      if (uOnda > 0.0) {
        uv.x += sin(uv.y * 22.0 + uTiempo * 2.2) * 0.0045 * uOnda;
        uv.y += cos(uv.x * 16.0 + uTiempo * 1.7) * 0.0035 * uOnda;
      }
      // 💥 mareo (envenenado): la vista se balancea y respira
      if (uMareo > 0.0) {
        vec2 c = uv - 0.5;
        float ang = sin(uTiempo * 1.3) * 0.035 * uMareo;
        c = mat2(cos(ang), -sin(ang), sin(ang), cos(ang)) * c;
        c *= 1.0 - (0.5 + 0.5 * sin(uTiempo * 0.9)) * 0.04 * uMareo;
        uv = c + 0.5;
      }
      // 💥 golpe: sacudida de lado
      if (uGolpe > 0.0) uv.x += sin(uTiempo * 90.0) * 0.008 * uGolpe;

      // 📼 temblor de cinta: cada línea se corre un poco y una franja de interferencia baja
      float banda = 0.0;
      if (uTracking > 0.0) {
        float linea = floor(uv.y * uTam.y);
        float cuadro = floor(uTiempo * 24.0);
        uv.x += (azar(vec2(linea, cuadro)) - 0.5) * 0.0025 * uTracking;
        float pos = 1.0 - fract(uTiempo * 0.09);
        banda = smoothstep(0.06, 0.0, abs(uv.y - pos)) * uTracking;
        uv.x += banda * 0.02 * sin(uv.y * 180.0 + uTiempo * 30.0);
        float salto = step(0.985, azar(vec2(floor(uTiempo * 4.0), 7.0)));
        uv.y += salto * 0.01 * uTracking;
      }

      // 🌈 sangrado de color: rojo y azul corridos y el color emborronado a lo ancho (+ el golpe los separa)
      vec3 col;
      float sang = uSangrado + uGolpe;
      if (sang > 0.0) {
        float o = (uSangrado * 2.2 + uGolpe * 5.0) / uTam.x;
        vec3 c0 = leer(uv);
        vec3 cI = leer(uv - vec2(o, 0.0));
        vec3 cD = leer(uv + vec2(o, 0.0));
        vec3 cI2 = leer(uv - vec2(o * 2.0, 0.0));
        float luz = dot(c0, vec3(0.299, 0.587, 0.114));
        vec3 croma = (c0 + cI + cD + cI2) * 0.25;
        float luzCroma = dot(croma, vec3(0.299, 0.587, 0.114));
        col = mix(c0, croma - luzCroma + luz, min(1.0, uSangrado * 0.8));
        float s2 = min(1.0, sang * 0.6);
        col.r = mix(col.r, cD.r, s2);
        col.b = mix(col.b, cI2.b, s2);
      } else {
        col = leer(uv);
      }

      // 💥 vista doble (aturdido)
      if (uDoble > 0.0) {
        vec2 d = vec2(sin(uTiempo * 2.7), cos(uTiempo * 1.9)) * 0.012 * uDoble;
        col = mix(col, leer(uv + d), 0.45 * uDoble);
      }

      // 🌗 color y tono
      float l = dot(col, vec3(0.299, 0.587, 0.114));
      col = mix(vec3(l), col, uSaturacion);
      col = (col - 0.5) * uContraste + 0.5 + uBrillo;
      if (uTinteF > 0.0) col = mix(col, col * uTinte * 1.25, uTinteF);
      // 💥 muerte: se va a blanco y negro
      if (uGris > 0.0) col = mix(col, vec3(dot(col, vec3(0.299, 0.587, 0.114))), uGris);
      // 💥 bordes teñidos (quemado: naranja · congelado: azul)
      if (uBordeF > 0.0) {
        vec2 q = min(uvPantalla, 1.0 - uvPantalla);
        float borde = 1.0 - smoothstep(0.0, 0.16, min(q.x, q.y));
        float latido = 0.75 + 0.25 * sin(uTiempo * 6.0);
        col = mix(col, uBorde, borde * uBordeF * latido * 0.8);
      }
      col = clamp(col, 0.0, 1.0);

      // 🎌 contorno: donde la distancia salta de golpe entre vecinos hay un borde de objeto
      if (uContorno > 0.0) {
        vec2 p = uGrosor / uTam;
        float z0 = metros(uv);
        float zi = metros(uv - vec2(p.x, 0.0)), zd = metros(uv + vec2(p.x, 0.0));
        float za = metros(uv + vec2(0.0, p.y)), zb = metros(uv - vec2(0.0, p.y));
        float salto = max(max(abs(zi - z0), abs(zd - z0)), max(abs(za - z0), abs(zb - z0))) / max(z0, 0.05);
        float borde = smoothstep(0.06, 0.14, salto);
        borde *= 1.0 - smoothstep(uLejos * 0.45, uLejos * 0.75, z0);   // lo muy lejano sin rayas (sería ruido)
        col = mix(col, uContornoColor, borde * uContorno);
      }

      // 🎨 paleta limitada: el color más cercano (y el segundo, para el tramado)
      if (uPalN > 0) {
        vec3 a = uPal[0], b = uPal[0];
        float da = 1e9, db = 1e9;
        for (int i = 0; i < 16; i++) {
          if (i >= uPalN) break;
          vec3 d3 = (col - uPal[i]) * vec3(0.9, 1.2, 0.6);   // el ojo nota más el verde
          float d = dot(d3, d3);
          if (d < da) { db = da; b = a; da = d; a = uPal[i]; }
          else if (d < db) { db = d; b = uPal[i]; }
        }
        float t = sqrt(da) / max(1e-5, sqrt(da) + sqrt(db));   // 0 = justo el color · 0.5 = entre los dos
        float umbral = bayer4(floor(uv * uTam));
        col = (t * 2.0 * uTramado > umbral + 0.001) ? b : a;
      }

      // letrero (dibujado encima de la imagen, así también le afectan líneas, ruido y curvatura)
      if (uTexto > 0.0) {
        vec4 tx = texture2D(tTexto, uvPantalla);
        col = mix(col, aPantalla(tx.rgb), tx.a);
      }

      // franja de interferencia: más clara y con ruido
      if (banda > 0.0) col += (azar(uv * uSalida + uTiempo) * 0.5 + 0.1) * banda * 0.35;

      // ruido / grano
      if (uRuido > 0.0) {
        float g = azar(floor(uv * uTam) + fract(uTiempo * 13.0) * 100.0) - 0.5;
        col += g * uRuido * 0.22;
      }

      // líneas de barrido (una por línea de la imagen retro) y rejilla RGB de la pantalla
      if (uLineas > 0.0) {
        float y = uvPantalla.y * uTam.y;
        float raya = 0.5 + 0.5 * cos(y * 6.2831853);
        col *= 1.0 - uLineas * 0.5 * (1.0 - raya);
        float m = mod(gl_FragCoord.x, 3.0);
        vec3 rejilla = m < 1.0 ? vec3(1.0, 0.8, 0.8) : m < 2.0 ? vec3(0.8, 1.0, 0.8) : vec3(0.8, 0.8, 1.0);
        col *= mix(vec3(1.0), rejilla, uLineas * 0.3);
        col *= 1.0 + uLineas * 0.2;   // devolver el brillo que quitan las rayas
      }

      // viñeta
      if (uVineta > 0.0) {
        vec2 v = uvPantalla * (1.0 - uvPantalla.yx);
        col *= clamp(pow(v.x * v.y * 16.0, uVineta * 0.45), 0.0, 1.0);
      }

      // 🎞 transiciones: cuánto tapa el color de la transición en este píxel
      if (uTrans > 0.0) {
        float tapa = uTrans;                                  // 1 negro · 2 blanco: fundido
        int tipo = int(uTransTipo + 0.5);
        if (tipo == 3) tapa = smoothstep(0.6, 1.0, uTrans);   // pixelado: al final se apaga
        else if (tipo == 4) tapa = smoothstep(uTrans * 1.1 - 0.05, uTrans * 1.1, 1.0 - vUv.x) ;   // barrido de derecha a izquierda
        else if (tipo == 5) {                                 // círculo que se cierra al centro
          vec2 d = (vUv - 0.5) * vec2(uSalida.x / uSalida.y, 1.0);
          float r = (1.0 - uTrans) * 0.95 - 0.02;
          tapa = smoothstep(r, r + 0.01, length(d));
        } else if (tipo == 6) {                               // estática de tele
          float n = azar(floor(vUv * uSalida / 3.0) + floor(uTiempo * 30.0));
          col = mix(col, vec3(n), smoothstep(0.0, 0.55, uTrans));
          tapa = smoothstep(0.7, 1.0, uTrans);
        } else if (tipo == 7) tapa = step(fract(vUv.y * 10.0), uTrans);   // persianas
        col = mix(col, uTransColor, clamp(tapa, 0.0, 1.0));
      }

      // 🎬 barras de cine (sobre la pantalla, sin curvatura)
      if (uBarras > 0.0 && (vUv.y < uBarras || vUv.y > 1.0 - uBarras)) col = vec3(0.0);

      gl_FragColor = vec4(clamp(col, 0.0, 1.0), 1.0);   // ya está en sRGB: va directo a la pantalla
    }`;

  /* ---------- El pase (lo usa Vista en motor/render.js) ---------- */
  const MOMENTOS = ['golpe', 'gris', 'onda', 'mareo', 'doble', 'borde'];

  class Pase {
    constructor() {
      this.rt = new T.WebGLRenderTarget(4, 4, { minFilter: T.NearestFilter, magFilter: T.NearestFilter, depthBuffer: true });
      this.rt.texture.colorSpace = T.SRGBColorSpace;
      // profundidad como textura: el contorno del estilo Anime la lee
      this.rt.depthTexture = new T.DepthTexture(4, 4);
      this.rt.depthTexture.type = T.UnsignedIntType;
      this.lienzo = document.createElement('canvas');
      this.lienzo.width = 320; this.lienzo.height = 240;
      this.cx = this.lienzo.getContext('2d');
      this.texTexto = new T.CanvasTexture(this.lienzo);
      this.texTexto.minFilter = this.texTexto.magFilter = T.NearestFilter;
      this.texTexto.colorSpace = T.SRGBColorSpace;
      this.mat = new T.ShaderMaterial({
        uniforms: {
          tImagen: { value: this.rt.texture }, tTexto: { value: this.texTexto },
          uTam: { value: new T.Vector2(4, 4) }, uSalida: { value: new T.Vector2(4, 4) }, uTiempo: { value: 0 },
          uLineas: { value: 0 }, uCurva: { value: 0 }, uSangrado: { value: 0 }, uRuido: { value: 0 },
          uTracking: { value: 0 }, uVineta: { value: 0 }, uTexto: { value: 0 },
          uPal: { value: Array.from({ length: 16 }, () => new T.Vector3()) }, uPalN: { value: 0 },
          uTramado: { value: 0.5 }, uSaturacion: { value: 1 }, uContraste: { value: 1 }, uBrillo: { value: 0 },
          uTinte: { value: new T.Vector3(1, 1, 1) }, uTinteF: { value: 0 },
          uGolpe: { value: 0 }, uGris: { value: 0 }, uOnda: { value: 0 }, uMareo: { value: 0 }, uDoble: { value: 0 },
          uBorde: { value: new T.Vector3(1, 0.4, 0.1) }, uBordeF: { value: 0 },
          tProf: { value: this.rt.depthTexture }, uContorno: { value: 0 }, uGrosor: { value: 1 },
          uCerca: { value: 0.1 }, uLejos: { value: 300 }, uBarras: { value: 0 }, uContornoColor: { value: new T.Vector3() },
          uTrans: { value: 0 }, uTransTipo: { value: 1 }, uTransColor: { value: new T.Vector3() },
        },
        vertexShader: VERT, fragmentShader: FRAG, depthTest: false, depthWrite: false,
      });
      this.quad = new T.Mesh(new T.PlaneGeometry(2, 2), this.mat);
      this.quad.frustumCulled = false;
      this.escena = new T.Scene();
      this.escena.add(this.quad);
      this.cam = new T.OrthographicCamera(-1, 1, 1, -1, 0, 1);
      this.cfg = null;
      this.reloj = 0;           // segundos desde que empezó (para la hora del letrero)
      this._ultimoTexto = '';
      this.mom = { golpe: 0, gris: 0, onda: 0, mareo: 0, doble: 0, borde: 0 };
      this.trans = { v: 0, meta: 0, vel: 2 };   // 🎞 transición: valor, a dónde va y cuánto por segundo
      this.barras = 0;                         // 🎬 las barras entran y salen deslizándose
      this.barrasMeta = 0;
      this.sinMovimiento = false;              // opción del jugador "Reducir movimiento de pantalla"
    }

    // cfg = efectos del nivel (o null: solo momentos)
    configurar(cfg) {
      const u = this.mat.uniforms, c = cfg || NEUTRO;
      const cambioHora = !this.cfg || !cfg || this.cfg.fxRecHora !== cfg.fxRecHora;
      this.cfg = cfg;
      u.uLineas.value = c.fxLineas || 0;
      u.uCurva.value = c.fxCurva || 0;
      u.uSangrado.value = c.fxSangrado || 0;
      u.uRuido.value = c.fxRuido || 0;
      u.uTracking.value = c.fxTracking || 0;
      u.uVineta.value = c.fxVineta || 0;
      u.uTexto.value = c.fxRec ? 1 : 0;
      const pal = coloresPaleta(c);
      u.uPalN.value = Math.min(16, pal.length);
      pal.slice(0, 16).forEach((h, i) => u.uPal.value[i].fromArray(rgb(h)));
      u.uTramado.value = c.fxTramado ?? 0.5;
      u.uSaturacion.value = c.fxSaturacion ?? 1;
      u.uContraste.value = c.fxContraste ?? 1;
      u.uBrillo.value = c.fxBrillo || 0;
      u.uTinte.value.fromArray(rgb(c.fxTinte || '#ffffff'));
      u.uTinteF.value = c.fxTinteFuerza || 0;
      u.uContorno.value = c.fxContorno || 0;
      u.uGrosor.value = c.fxContornoGrosor || 1;
      u.uContornoColor.value.fromArray(rgb(c.fxContornoColor || '#000000'));
      this.barrasMeta = Math.min(0.45, c.fxBarras || 0);
      if (!this._barrasIniciadas) { this.barras = this.barrasMeta; this._barrasIniciadas = true; }
      this.trackingBase = c.fxTracking || 0;
      u.uTracking.value = this.sinMovimiento ? 0 : this.trackingBase;
      if (cambioHora) this.reloj = 0;
      this._ultimoTexto = '';   // repintar el letrero
      if (!c.fxRec) { this.cx.clearRect(0, 0, this.lienzo.width, this.lienzo.height); }
    }

    // ¿hay algún momento puesto? (entonces el pase se usa aunque el nivel no tenga estilo)
    momentoActivo() {
      const m = this.mom;
      return m.golpe > 0 || m.gris > 0 || m.onda > 0 || m.mareo > 0 || m.doble > 0 || m.borde > 0
        || this.trans.v > 0 || this.trans.meta > 0 || this.barras > 0.001 || this.barrasMeta > 0;
    }

    tamano(wRetro, hRetro, wSalida, hSalida) {
      wRetro = Math.max(1, Math.round(wRetro)); hRetro = Math.max(1, Math.round(hRetro));
      if (this.rt.width !== wRetro || this.rt.height !== hRetro) this.rt.setSize(wRetro, hRetro);
      this.mat.uniforms.uTam.value.set(wRetro, hRetro);
      this.mat.uniforms.uSalida.value.set(wSalida, hSalida);
      // el letrero a 240 de alto con el ancho de la pantalla (letras sin estirar)
      const wl = Math.max(160, Math.round(240 * (wSalida / Math.max(1, hSalida))));
      if (this.lienzo.width !== wl) { this.lienzo.width = wl; this.texTexto.dispose(); this._ultimoTexto = ''; }
    }

    // Letrero: se repinta solo cuando cambia el texto (2 veces por segundo)
    pintarTexto() {
      const c = this.cfg;
      if (!c || !c.fxRec) return;
      const parpadeo = Math.floor(this.reloj * 2) % 2 === 0;
      const ampm = /[ap]m/i.test(c.fxRecHora || '');
      const hora = escribirHora(leerHora(c.fxRecHora) + this.reloj, ampm);
      const seg = c.fxLetrero === 'seguridad';
      const bar = Math.round(this.barras * 240);   // con barras de cine el letrero baja / sube para no quedar tapado
      const clave = [parpadeo, hora, c.fxRecFecha, c.fxLetrero, c.fxCamNombre, this.lienzo.width, bar].join('|');
      if (clave === this._ultimoTexto) return;
      this._ultimoTexto = clave;
      const g = this.cx, W = this.lienzo.width, H = this.lienzo.height, m = 14;
      g.clearRect(0, 0, W, H);
      g.save();
      g.translate(0, bar);
      const Hb = H - bar * 2;   // alto libre entre las barras
      g.font = 'bold 13px "Courier New", monospace';
      g.textBaseline = 'top';
      const texto = (t, x, y, alin = 'left', color = '#f4f4f4') => {
        g.textAlign = alin;
        g.fillStyle = 'rgba(0,0,0,0.85)';
        g.fillText(t, x + 1, y + 1);
        g.fillStyle = color;
        g.fillText(t, x, y);
      };
      const punto = (x, y) => {
        if (!parpadeo) return;
        g.fillStyle = 'rgba(0,0,0,0.85)'; g.beginPath(); g.arc(x + 1, y + 1, 4.5, 0, Math.PI * 2); g.fill();
        g.fillStyle = '#ff2a2a'; g.beginPath(); g.arc(x, y, 4.5, 0, Math.PI * 2); g.fill();
      };
      if (seg) {
        // 📟 cámara de seguridad: nombre arriba a la izquierda, ● REC arriba a la derecha, fecha y hora abajo a la derecha
        texto(c.fxCamNombre || 'CAM 01', m, m);
        punto(W - m - 38, m + 7);
        texto('REC', W - m, m, 'right');
        texto(c.fxRecFecha || '', W - m, Hb - m - 30, 'right');
        texto(hora, W - m, Hb - m - 14, 'right');
      } else {
        // 🎥 cámara casera: ● REC arriba a la izquierda, pila arriba a la derecha, fecha y hora abajo a la izquierda
        punto(m + 5, m + 7);
        texto('REC', m + 14, m);
        g.fillStyle = 'rgba(0,0,0,0.85)'; g.fillRect(W - m - 27, m + 3, 26, 12);
        g.strokeStyle = '#f4f4f4'; g.lineWidth = 2; g.strokeRect(W - m - 28, m + 2, 24, 11);
        g.fillStyle = '#f4f4f4'; g.fillRect(W - m - 4, m + 5, 3, 5);
        for (let i = 0; i < 3; i++) g.fillRect(W - m - 25 + i * 7, m + 5, 5, 5);
        texto(c.fxRecFecha || '', m, Hb - m - 30);
        texto(hora, m, Hb - m - 14);
      }
      g.restore();
      this.texTexto.needsUpdate = true;
    }

    // Dibuja la imagen retro (rt) en la pantalla con los efectos
    dibujar(renderer, dt, cam) {
      this.reloj += dt;
      const u = this.mat.uniforms, m = this.mom;
      if (cam) { u.uCerca.value = cam.near; u.uLejos.value = cam.far; }
      u.uTiempo.value = (u.uTiempo.value + dt) % 1000;
      // el golpe se apaga solo en ~⅓ de segundo
      if (m.golpe > 0) m.golpe = Math.max(0, m.golpe - dt * 3);
      // 🎞 transición y 🎬 barras se mueven hacia su meta
      const tr = this.trans;
      if (tr.v !== tr.meta) tr.v = tr.v < tr.meta ? Math.min(tr.meta, tr.v + dt * tr.vel) : Math.max(tr.meta, tr.v - dt * tr.vel);
      u.uTrans.value = tr.v;
      if (this.barras !== this.barrasMeta) {
        const paso = dt * 0.4;
        this.barras = this.barras < this.barrasMeta ? Math.min(this.barrasMeta, this.barras + paso) : Math.max(this.barrasMeta, this.barras - paso);
      }
      u.uBarras.value = this.barras;
      // "Reducir movimiento": sin sacudidas, mareo, ondas ni vista doble (los colores sí)
      const mov = this.sinMovimiento ? 0 : 1;
      u.uGolpe.value = m.golpe * mov; u.uGris.value = m.gris; u.uOnda.value = m.onda * mov;
      u.uMareo.value = m.mareo * mov; u.uDoble.value = m.doble * mov; u.uBordeF.value = m.borde;
      this.pintarTexto();
      renderer.setRenderTarget(null);
      renderer.render(this.escena, this.cam);
    }
  }

  /* 💥 Pone un momento en la vista: k = 'golpe' | 'gris' | 'onda' | 'mareo' | 'doble' | 'borde' (0..1).
     color: para 'borde' ('#ff6a1a' quemado, '#7fc8ff' congelado). Crea el pase la primera vez. */
  function momento(vista, k, v, color) {
    if (!vista || !MOMENTOS.includes(k)) return;
    if (!vista.pase) {
      if (!(v > 0)) return;   // nada que quitar
      vista.pase = new Pase();
      vista.pase.configurar(vista.fx);
      vista.ajustarTamano();
    }
    vista.pase.mom[k] = Math.max(0, Math.min(1.5, v || 0));
    if (color) vista.pase.mat.uniforms.uBorde.value.fromArray(rgb(color));
  }
  // Quita todos los momentos (al empezar o terminar una partida). La transición no: el cambio de nivel la deja puesta
  function limpiarMomentos(vista) {
    if (!vista || !vista.pase) return;
    for (const k of MOMENTOS) vista.pase.mom[k] = 0;
  }

  /* 🎞 Transiciones (cambio de nivel y cinemáticas). Lo que no es 'negro' lo dibuja el pase.
     transicion(vista, { tipo, a: 1 tapar | 0 destapar, segundos }) → promesa que acaba cuando termina */
  const TRANSICIONES = [['negro', '⬛ Fundido a negro'], ['blanco', '⬜ Fundido a blanco'], ['pixelado', '🟫 Pixelado'],
    ['barrido', '➡ Barrido de lado'], ['circulo', '⭕ Círculo que se cierra'], ['estatica', '📺 Estática de tele'], ['persiana', '☰ Persianas']];
  const TIPO_N = { negro: 1, blanco: 2, pixelado: 3, barrido: 4, circulo: 5, estatica: 6, persiana: 7 };
  function transicion(vista, { tipo = 'negro', a = 1, segundos = 0.5 } = {}) {
    if (!vista) return Promise.resolve();
    if (!vista.pase) {
      if (!(a > 0)) return Promise.resolve();
      vista.pase = new Pase();
      vista.pase.configurar(vista.fx);
      vista.ajustarTamano();
    }
    const P = vista.pase, u = P.mat.uniforms;
    u.uTransTipo.value = TIPO_N[tipo] || 1;
    u.uTransColor.value.fromArray(tipo === 'blanco' ? [1, 1, 1] : [0, 0, 0]);
    P.trans.meta = a > 0 ? 1 : 0;
    if (!(segundos > 0)) { P.trans.v = P.trans.meta; return Promise.resolve(); }
    P.trans.vel = 1 / segundos;
    // si no se dibujan cuadros (cargando), igual termina a tiempo
    return new Promise((res) => setTimeout(() => { P.trans.v = P.trans.meta; res(); }, segundos * 1000));
  }

  /* 📼 Acción "Cambiar efectos" de palancas y disparadores (y cinemáticas): estilo + barras encima del nivel.
     estilo: 'nivel' (los del nivel) · 'ninguno' (sin efectos) · uno de ESTILOS */
  function aplicarAccion(vista, estilo, barras) {
    if (!vista) return;
    let cfg;
    if (estilo === 'ninguno') cfg = { ...NEUTRO, fxEstilo: 'propio' };
    else if (estilo && ESTILOS[estilo]) cfg = { ...DEF, ...ESTILOS[estilo], fxEstilo: estilo };
    else cfg = vista.fxNivel ? { ...vista.fxNivel } : { ...DEF, ...NEUTRO, fxEstilo: 'propio' };
    cfg.fxBarras = Math.max(0, barras || 0);
    vista.forzarEfectos(cfg);
  }

  F.Efectos = { ESQUEMA, ESTILOS, PALETAS, CLAVES, DEF, NEUTRO, defectosDe, aplicarEstilo, efectivos, hayFx, Pase, momento, limpiarMomentos, MOMENTOS,
    TRANSICIONES, transicion, aplicarAccion };
})(window.FORJA);
