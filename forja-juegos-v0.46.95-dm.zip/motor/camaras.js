/* =========================================================
   FORJA · CÁMARAS FIJAS 📷 (estilo Resident Evil / Silent Hill)
   Entidad 'camara': se coloca y se gira en el editor (mira hacia su -Z, la flecha del dibujo).
   - modo 'fija': el plano no se mueve · 'sigue': se queda en su sitio pero gira para seguir al jugador.
   - zona: un ⬚ disparador del nivel; mientras el jugador está dentro, manda esta cámara. Sin zona, entra en juego
     cuando ninguna zona te contiene: la más cercana que te ve.
   Se usa con Jugador ▸ Cámara ▸ Modo "Cámaras fijas" (jugador/modulos/camara.js).
   ========================================================= */
(function (F) {
  'use strict';
  const T = THREE;
  /* activacion: 'zona' (su propia caja, dibujada en el editor) | 'disparador' (la enciende la acción "📷 Cambiar a
     cámara" de un disparador, palanca o condición). Zona: ancho × alto × largo, centrada "delante" m por delante de la
     cámara (solo su giro horizontal) y "abajo" m por debajo de ella. inicial: la que manda al empezar el nivel. */
  const CAMARA = { modo: 'fija', fov: 50, activacion: 'zona', zAncho: 6, zAlto: 3, zLargo: 6, zDelante: 4, zAbajo: 2, suave: 0.12, inicial: false };

  const _e = new T.Euler(), _q = new T.Quaternion(), _qy = new T.Quaternion(), _v = new T.Vector3();
  // giro horizontal de la cámara (yaw) a partir de su rotación completa
  function yawDe(quat) { _v.set(0, 0, -1).applyQuaternion(quat); return Math.atan2(-_v.x, -_v.z); }

  function figura(ent) {
    const g = new T.Group();
    const c = { ...CAMARA, ...(ent.camara || {}) };
    const mat = new T.MeshBasicMaterial({ color: 0xe8c547, wireframe: true, fog: false });
    const cuerpo = new T.Mesh(new T.BoxGeometry(0.35, 0.25, 0.45), mat);
    const lente = new T.Mesh(new T.CylinderGeometry(0.09, 0.12, 0.18, 8).rotateX(Math.PI / 2).translate(0, 0, -0.3), mat);
    // el cono de lo que ve (4 m)
    const a = Math.tan((c.fov || 50) * Math.PI / 360) * 4, b = a * 0.75;
    const pts = [[0, 0, 0], [-a, -b, -4], [0, 0, 0], [a, -b, -4], [0, 0, 0], [a, b, -4], [0, 0, 0], [-a, b, -4],
      [-a, -b, -4], [a, -b, -4], [a, -b, -4], [a, b, -4], [a, b, -4], [-a, b, -4], [-a, b, -4], [-a, -b, -4]].flat();
    const geo = new T.BufferGeometry();
    geo.setAttribute('position', new T.Float32BufferAttribute(pts, 3));
    const cono = new T.LineSegments(geo, new T.LineBasicMaterial({ color: 0xe8c547, transparent: true, opacity: 0.6, fog: false }));
    for (const o of [cuerpo, lente, cono]) { o.userData.ayudaEditor = true; g.add(o); }
    // 🟨 su zona (solo con activación "zona"): caja con el giro horizontal de la cámara, sin su inclinación
    if (c.activacion === 'zona') {
      const r = ent.rot || [0, 0, 0];
      _q.setFromEuler(_e.set(r[0] * Math.PI / 180, r[1] * Math.PI / 180, r[2] * Math.PI / 180));
      const yaw = yawDe(_q);
      _qy.setFromAxisAngle(_v.set(0, 1, 0), yaw);
      const inv = _q.clone().invert();
      const caja = new T.LineSegments(new T.EdgesGeometry(new T.BoxGeometry(c.zAncho, c.zAlto, c.zLargo)),
        new T.LineBasicMaterial({ color: 0xffb020, transparent: true, opacity: 0.8, fog: false }));
      // en el mundo: centro = cámara + (delante en su giro) − abajo · giro = solo el horizontal
      caja.position.set(-Math.sin(yaw) * c.zDelante, -c.zAbajo, -Math.cos(yaw) * c.zDelante).applyQuaternion(inv);
      caja.quaternion.copy(inv).multiply(_qy);
      caja.userData.ayudaEditor = true;
      g.add(caja);
    }
    return g;
  }

  /* Al jugar: qué cámara manda. Sin peleas: cada cámara es de zona O de disparador.
     - Al ENTRAR en la zona de una cámara de zona, manda esa (y sigue mandando hasta otra zona u otra acción).
     - La acción "📷 Cambiar a cámara" pone la que diga.
     - Al empezar: la marcada "inicial"; si no, la zona en la que estés; si no, la más cercana que te ve. */
  class Gestor {
    constructor(juego) {
      this.juego = juego;
      this.lista = [];
      this.actual = null;
      for (const ent of juego.escena.entidades) {
        if (ent.tipo !== 'camara') continue;
        if (ent.camara && ent.camara.activacion === 'cine') continue;   // 🎬 solo para cinemáticas
        const obj = juego.objetos.get(ent.id);
        if (!obj) continue;
        obj.updateWorldMatrix(true, false);
        const c = { ...CAMARA, ...(ent.camara || {}) };
        const k = { ent, c, pos: obj.getWorldPosition(new T.Vector3()), quat: obj.getWorldQuaternion(new T.Quaternion()), q: new T.Quaternion(), dentro: false, caja: null };
        if (c.zona) {
          // (v0.31) zona = un disparador: se sigue respetando como zona
          const z = juego.objetos.get(c.zona);
          if (z) { z.updateWorldMatrix(true, true); k.cajaMundo = new T.Box3().setFromObject(z); }
        } else if (c.activacion === 'zona') {
          const yaw = yawDe(k.quat);
          k.zYaw = yaw;
          k.zCentro = k.pos.clone().add(new T.Vector3(-Math.sin(yaw) * c.zDelante, -c.zAbajo, -Math.cos(yaw) * c.zDelante));
        }
        this.lista.push(k);
      }
      this._p = new T.Vector3(); this._d = new T.Vector3(); this._m = new T.Matrix4();
    }

    get hay() { return this.lista.length > 0; }

    _en(k, p) {
      if (k.cajaMundo) return k.cajaMundo.containsPoint(p);
      if (!k.zCentro) return false;
      const dx = p.x - k.zCentro.x, dz = p.z - k.zCentro.z, cy = Math.cos(k.zYaw), sy = Math.sin(k.zYaw);
      const lx = dx * cy - dz * sy, lz = dx * sy + dz * cy;   // al giro de la cámara
      return Math.abs(lx) <= k.c.zAncho / 2 && Math.abs(lz) <= k.c.zLargo / 2 && Math.abs(p.y - k.zCentro.y) <= k.c.zAlto / 2;
    }

    // la acción "📷 Cambiar a cámara"
    activar(id) { const k = this.lista.find((x) => x.ent.id === id); if (k) this.actual = k; }

    elegir(p) {
      let entra = null;
      for (const k of this.lista) {
        const d = this._en(k, p);
        if (d && !k.dentro) entra = k;     // acaba de entrar en su zona
        k.dentro = d;
      }
      if (entra) this.actual = entra;
      // salió de la zona de la actual y está dentro de otra (zonas que se tocan)
      if (this.actual && (this.actual.zCentro || this.actual.cajaMundo) && !this.actual.dentro) {
        const otra = this.lista.find((k) => k.dentro);
        if (otra) this.actual = otra;
      }
      if (!this.actual) {
        this.actual = this.lista.find((k) => k.c.inicial) || this.lista.find((k) => k.dentro) || this._cercana(p) || this.lista[0];
      }
      return this.actual;
    }

    _cercana(p) {
      const M = this.juego.mundo;
      let mejor = null, md = Infinity;
      for (const k of this.lista) {
        const d = this._d.copy(p).sub(k.pos), L = d.length();
        if (L * L >= md) continue;
        if (L > 1e-3 && M && M.rayo(k.pos.x, k.pos.y, k.pos.z, d.x / L, d.y / L, d.z / L, L - 0.3)) continue;
        md = L * L; mejor = k;
      }
      return mejor;
    }

    // coloca la cámara del juego; devuelve si cambió de plano (corte)
    colocar(cam, p, dt) {
      const antes = this.actual, k = this.elegir(p), corte = k !== antes || !this._puesta;
      this._puesta = true;
      cam.position.copy(k.pos);
      if (k.c.modo === 'sigue') {
        this._m.lookAt(k.pos, p, cam.up);
        k.q.setFromRotationMatrix(this._m);
        if (corte) cam.quaternion.copy(k.q); else cam.quaternion.slerp(k.q, Math.min(1, dt / Math.max(0.01, k.c.suave)));
      } else cam.quaternion.copy(k.quat);
      if (cam.fov !== k.c.fov) { cam.fov = k.c.fov; cam.updateProjectionMatrix(); }
      return corte;
    }

    // hacia dónde mira la cámara en horizontal (para mover "relativo a la cámara")
    yaw(cam) { cam.getWorldDirection(this._d); return Math.atan2(-this._d.x, -this._d.z); }
  }

  F.Camaras = { CAMARA, figura, Gestor };
})(window.FORJA);
