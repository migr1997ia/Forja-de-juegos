# NOTAS-CLAUDE — mapa del proyecto Forja de Juegos

Leer ESTO al empezar cada sesión, y luego solo los archivos que se vayan a tocar.
Carpeta en la PC de Miguel: `C:\Users\migue\Documents\Videojuegos\Claude\`
- `forja-juegos\` = versión de trabajo (la carpeta cambiará de nombre en el futuro)
- `Respaldos\` = un zip por versión (`forja-juegos-vX.Y.zip`)

## Reglas de trabajo (acordadas con Miguel)
- Su framework de Godot dice **QUÉ** debe poder hacer el motor; el **CÓMO** lo decide Claude para HTML. No traducir sus scripts.
- Prioridad: estética retro PS1/N64 siempre, pero con soluciones simples de entender y usar.
- Editor fácil para alguien sin experiencia (pocas tardes para hacer una demo), con inspiración en Godot para que se sienta familiar.
- Código largo y legible, en español, archivos completos. Solo se escriben en la PC los archivos que cambian.
- Cada entrega: actualizar `forja-juegos\`, zip en `Respaldos\`, y este archivo (mapa + cambios).
- En cada versión subir V en archivos.js, F.VERSION y los ?v= de editor.html / index.html (evita archivos viejos en caché).
- DESPUÉS de cualquier cambio en motor/, jugador/, index.html o juego/arranque.js: `node herramientas/empaquetar.js`
  (regenera editor/empaque.js; si no, el .html exportado sale con el motor viejo y el editor avisa por versión distinta).
- Cada propiedad lleva su ↺ (formulario lo pone solo si hay def o opciones.defectos); el general va en la cabecera fija de cada panel (cabeceraPanel en inspector.js), no al final.
- Probar siempre con Chromium headless desde `file://` (editor.html e index.html exportado) antes de entregar.
- Juegos objetivo: PC, Android, iOS vía web (itch.io). Guardado en el navegador + exportar/importar partida.

## Reglas detalladas (léelas enteras: el chat de la v0.15 no las siguió y Miguel quedó descontento)
1. ENTENDER ANTES DE PROGRAMAR. Si la petición deja dudas de diseño (qué ve el jugador, qué elige el creador), preguntar con
   opciones concretas (AskUserQuestion, 2-4 opciones, la recomendada primero) ANTES de escribir código. Miguel paga el uso:
   no gastar en suposiciones. Si algo "no funciona", primero REPRODUCIRLO (prueba headless) y explicar la causa; no reescribir.
2. TODO TIENE UNA FIGURA DE BASE DEL MOTOR por si no hay modelo: jugador (muñeco de pruebas de choque, para que se note
   que es provisional), enemigos (persona / animal / volador / torreta), recogibles, salidas (puerta / portal), marcadores.
   Al crear algo NUEVO que se ve en el juego (agua, nadadores, puertas de la Fase 5, cofres…) hay que hacerle su figura de
   base con primitivas retro (cajas, flatShading, hacerRetro, texturas de 16-32 px con NearestFilter) ANTES de darlo por
   terminado. El modelo GLB propio es opcional y la sustituye; los colores de la figura se editan en el Inspector.
   Si cambias una figura o un valor de serie, migra los proyectos viejos SOLO si conservaban el valor viejo de serie
   (normalizarProyecto en escena.js), nunca pises lo que el creador cambió.
3. "A ELECCIÓN DEL CREADOR": cuando hay dos estilos razonables (Quake vs Halo, RE vs lista, tira vs círculo), hacer los dos
   con un selector, no imponer uno. Lo de serie debe funcionar ya sin tocar nada.
4. NADA DE ESCRIBIR NOMBRES A MANO para referirse a otra cosa: bibliotecas + selectores (Juego ▸ Criaturas, Armas, Munición;
   rutas de 📍 puntos, niveles, llegadas). Si algo se reutiliza, va a una biblioteca del proyecto con vínculo.
5. EL INSPECTOR AVISA de lo que impide que algo funcione (⚠ en la nota): sin destino, módulo apagado, caja tapada, nombre
   que ya no existe… Mejor un aviso claro que un "no pasa nada" silencioso.
6. PRINCIPIANTE: cada campo con texto 'ayuda' corto; lo fino con av:true (se esconde en 🧭 Sencillo); ↺ por campo.
   Borrar siempre deshacible (Ctrl+Z) y con confirmación fácil (🗑 de dos clics en el árbol).
7. NO TRADUCIR EL FW DE GODOT: leer qué hace, decir qué sirve y qué no, y proponer la versión HTML. Carpeta del FW solo lectura.
8. RENDIMIENTO 144 fps: medir en ms (enemigos.actualizar, cuadro completo) cuando se toca algo que corre cada cuadro.
   Pools en vez de crear/destruir; tocar el HTML del HUD solo si cambia el valor.
9. PROBAR COMO JUGADOR, no solo la API: caminar con teclas (keyboard.down('KeyW')), pulsar E, en ▶ Jugar, en "Probar con
   menús" (Ed.probarMenus() + partida.nuevaPartida) y, si toca el juego, en el .html exportado. Capturas de la UI nueva.
   Sin errores de consola. No decir "listo" sin haberlo probado.
10. ENTREGA A LA PC en tandas pequeñas (el puente se corta con archivos grandes): primero los .js/.html chicos, luego
   editor/empaque.js SOLO, luego editor-completo.html SOLO, luego el zip SOLO; reintentar los rechazados.
   Nunca sobrescribir juego/datos.js. Antes de trabajar, si otro chat tocó la PC: traer los archivos (device_stage_files),
   comparar con la copia local y partir de lo de la PC.
11. RESPUESTAS: en español sencillo, cortas, sin jerga interna; decir qué cambió, dónde se toca en el editor y qué falta.
12. LO ÚTIL VIENE ACTIVADO: los módulos que casi todo juego necesita (moverse, cámara, saltar, Interactuar…) vienen
   encendidos de serie (activoPorDefecto). El orden de las categorías del panel Jugador va de lo más usado a lo menos.

## Cómo trabajo cada petición (paso a paso)
a) Leer este archivo; si otro chat tocó la PC, traer y comparar sus archivos (regla 10).
b) Si hay dudas de diseño: preguntar con opciones (regla 1). Si es un fallo: reproducirlo primero (regla 1).
c) Programar en la copia local (/home/claude/forja-juegos), solo los archivos necesarios, código largo y legible.
d) Figura de base para todo lo nuevo que se vea (regla 2); avisos ⚠ en el Inspector (regla 5); ayudas y av (regla 6).
e) Probar como jugador en Chromium headless con capturas (regla 9) y medir ms si corre cada cuadro (regla 8).
f) Subir versión (archivos.js V, F.VERSION, ?v= de editor.html e index.html) → node herramientas/empaquetar.js.
g) Apuntar la versión en el Historial de este archivo (qué, cómo, dónde, qué se probó, qué falta).
h) Zip en Respaldos y copiar a la PC en tandas (regla 10). i) Responder corto: qué cambió, dónde tocarlo, qué falta.

## Estructura
```
editor.html        editor (doble clic, sin internet)
index.html         juego exportado (lee juego/datos.js; sin datos acepta soltar un .forja.json)
archivos.js        LISTA ÚNICA de scripts del motor (document.write); módulos nuevos se añaden aquí
lib/three-forja.js Three r160 + GLTFLoader, OrbitControls, TransformControls, SkeletonUtils, mergeGeometries (IIFE → window.THREE)
motor/
  nucleo.js   FORJA namespace, F.VERSION, F.util (uid, clamp, fmt, slug, descargarBlob, base64), eventos F.on/F.emitir/F.aviso,
              F.registrarModulo / F.modulosOrdenados, F.registrarComponente (aún sin uso), F.valoresPorDefecto(esquema),
              F.LimiteFps (new → .listo(ahora, fps) en el bucle; lo usan editor al jugar e index.html con ajustes.limiteFps)
  render.js   U (uniforms globales retro), hacerRetro(mat) parche de shader: snap vértices, afín, dither 15 bits,
              niebla lineal (por vértice / bandas), SIN_LUZ, desplazamiento UV (uDesplazUV por material, uTiempo global).
              aplicarConfig(mat,cfg) modos opaco/recorte/translucido/aditivo, opacidad, prioridad(renderOrder), dobleCara, sinLuz, tinte.
              aplicarPrioridad(raiz), convertirMateriales(raiz) (GLB→Lambert retro, guarda userData.original con el modo del GLB),
              texCuadros, Vista (renderer, escena, hemi, sol, cielo cúpula con shader degradado+textura esfera/plano+scroll),
              Vista.aplicar(render, ambiente, retro, conNiebla), Vista.distanciaDibujo(amb), MODOS_MATERIAL.
              Vista acepta cámaras ortográficas (userData.mitadAlto; el cielo se oculta con ellas)
  luces.js    F.Luces(vista) (vista.luces): configurar(aj, amb) (shadowMap tipo/tamaño, grupo FIJO de maxLuces PointLight →
              sin recompilar), registrar(entidades, objetos) (entidades 'luz' usan ent.luz por referencia; materiales con
              mat.userData.cfgLuz → centrosDeMaterial(): agrupa centroides de triángulos a < agrupar m, caché por asset|mat),
              actualizar(dt, cam) (reparto cada 0.2 s a las más cercanas, parpadeo, fundido), seguirSol(cam) (caja ±dist
              alrededor de la cámara, ajustada a texel). LUZ_BASE, PRESETS, aplicarSombras(obj, proyecta) (no proyecta si
              transparente/aditivo). Ajustes: lucesExtra, sombrasSol (0/512 Basic/1024 PCF/2048 PCFSoft), distanciaSombras,
              maxLuces. Ambiente: solColor, solSombra. Entidad: sombra (bool), tipo 'luz' con luz{color,fuerza,alcance,parpadeo,velocidad}.
              Vista.aplicar → luces.configurar; Vista.render → luces.actualizar; Juego.iniciar / Partida.prepararFondo → registrar;
              editor: refrescarLuces en 'escena-reconstruida', guardarLocal (200 ms), al detener juego/partida.
  fisica.js   BVH (recoger caja, rayo), distancias Ericson, triangulosDe(entidades, objetos) → Float32Array,
              construirMundo(entidades, objetos) = new BVH(triangulosDe(...)) (no entra en entidades hijas),
              CuerpoCinematico (≈CharacterBody3D): pie, velocidad, enSuelo, tAire, visY, moverYDeslizar(dt).
              Cápsula elevada sobre el escalón + 5 rayos al suelo (sube escalones, se pega al bajar).
  tactil.js   F.Tactil: overlay .ft (stick flotante izq. 45 %, mirar der., BOTONES [{accion, texto, etiqueta, clase, modo pulsar|alternar}],
              LUGAR en vmin, pausa → F.emitir('juego-pausa')). Llena F.Entrada.virtual {x,y,mx,my,acciones,toques}.
              Se muestra en 'juego-iniciado' / 'partida-jugando' (modo = ajustes.controlesTactiles auto|siempre|nunca, seToco),
              se oculta en 'partida-pausa' / 'juego-detenido'. Con él visible F.Entrada.tactil = true (no pide pointer lock).
  entrada.js  F.Entrada: acciones (adelante/atras/izquierda/derecha (v0.5, cruceta 12-15), saltar, correr, agachar, interactuar, atacar, apuntar, recargar, cambiar_camara, depurar, pausa),
              mover/mirar, mantenido/pulsado/soltado, toques rápidos no se pierden, mando estándar Xbox/PS,
              pointer lock con respaldo por arrastre, escuchar(canvas), activo, usarMapa(personal), ETIQUETAS,
              nombreTecla/nombreBoton/textoTeclado/textoMando, leerMando
  assets.js   F.Assets: DB (IndexedDB 'forja-juegos': assets, apps, proyecto), mapa, importar (mismo nombre = reemplaza),
              reemplazar, renombrar, quitar, textura(id,'color'|'normal'), desglose(a), materialesDe(a),
              configMaterial / aplicarMaterialesAsset / aplicarMateriales(proyecto), serializar/deserializar, de(tipo)
  escena.js   F.Escena: ESQUEMA_RENDER (proyecto), ESQUEMA_AMBIENTE (por escena: cielo, niebla, distancia, luz),
              PARAMS_PRIMITIVA, entidadNueva, escenaNueva, proyectoNuevo, normalizarProyecto (migra v0.1/v0.2),
              hijos, subarbol, crearObjeto, construirEscena(escena, raiz, proyecto)→Map, aplicarTransform, mapaAcciones
  juego.js    F.Juego(vista, proyecto, escena, objetos, {ajustes}): iniciar(inicio?{pos,yaw,pitch | llegada, jugador, rotos…})
              (BVH, visibilidad, mixers, jugador, salidas, far), puntoDeLlegada(id), irALlegada(id), actualizar(dt),
              detener({seguir}) (seguir = viaje: no suelta el cursor), estado() → {escena,pos,yaw,pitch,rotos,…,jugador}.
              ponerEstadoJugador: vida y armadura por separado (lo que falta queda como al empezar). this.ajustes = imagen efectiva.
  audio.js    F.Audio: musica(id) en bucle, pararMusica, efecto(id), volGeneral/volMusica/volEfectos, aplicarVolumen
  opciones.js F.Opciones(proyecto): valores (ESQUEMA con grupo video/audio/controles; 'desde' = clave de proyecto.ajustes),
              controles (solo lo cambiado), ajustes() efectivos, aplicar() → Entrada/Audio, poner, asignar(accion,'teclado'|'mando',
              {tecla|raton|boton}) (quita la misma tecla de otras acciones), restablecerControles, restablecerGrupo.
              localStorage `${prefijo}:${slug(nombre)}:opciones|partidas`; usarPrefijo('forja-editor') en el editor.
              F.Partidas: RANURAS=3, lista, guardar(i,datos), borrar, ultima, hay.
  menus.js    F.MenuJuego (DOM .fm encima del contenedor; CSS inyectado): pila de pantallas portada/principal/pausa/opciones/
              grupo/mapeo/ranuras/confirmar (métodos p_<tipo>), items {texto, activar, izq, der, valor, apagado}; teclado en captura
              en window, mando por sondeo en actualizar(dt), ratón/táctil por clic. alAccion(accion, boton|datos, origen).
              F.Menus.ACCIONES (qué puede hacer un botón y en qué menú), F.Menus.PLANTILLAS (clasico, survival, arcade).
  niveles.js  F.Niveles (gestor de niveles, uno por partida / por ▶ Jugar): memoria {idEscena:{rotos,recogidos,enemigosMuertos}},
              entrada (foto al entrar al nivel → reinicio()), inicioPara(id, llegada, jugador, escena), marcarEntrada,
              recordar(juego), aplicarReinicios, serializar/cargar (en la ranura: datos.niveles), viajar({juego, ent, cambiar})
              async: fundido (.fn-viaje z 28 en vista.contenedor) → cartel → recordar → cambiar(id, inicio) → compile → fundido.
              Misma escena = juego.irALlegada (teletransporte). aparecer(juego) = fundido de entrada.
              F.Niveles.Salidas (juego.salidas): cajas 1×1×1 escaladas (matrixWorld invertida), 'tocar' con armado (si llegas
              dentro no dispara hasta salir), activar(ent) → evento 'salida' {juego, ent}, liberar(). SALIDA, NIVEL,
              ESQUEMA_NIVEL, ESQUEMA_SALIDA, figura(ent), inicios(esc), inicioDe(esc, llegada) (llegada → principal → primero).
  partida.js  F.Partida({vista, proyecto, contenedor, enEditor, alSalir}): grupo propio con la escena cargada, camMenu orbitando,
              estado menu|jugando|pausa|muerte|viajando, arrancar(pantalla), nuevaPartida(id, origen) (olvida niveles),
              empezar(idEscena, guardado, origen), _entrar(id, inicio) (Juego + música del nivel), viajar(ent) (escucha 'salida';
              cursor liberado a medio viaje → pausa al llegar), pausar, reanudar, accion(...) ('reiniciar' = niveles.reinicio),
              listo(ahora) (límite FPS del jugador), actualizar(dt), destruir(). Escucha 'juego-pausa' y 'cursor-liberado'.
jugador/
  jugador.js  F.Jugador: orquesta módulos: entrada → fisica → cuerpo.moverYDeslizar → despues.
              teletransportar(x,y,z,yaw,pitch) sube j.saltos (Salud no lo cuenta como caída); reaparecer() lo usa
  modulos/    cuerpo(0, oblig.), camara(10, oblig.), balanceo(12), sprint(15), movimiento(20), salto(30), gravedad(40), modelo(60),
              sombra(65, activoPorDefecto:false: mancha bajo el jugador con rayo al BVH)
editor/
  inspector.js formularios desde esquema (controlEsquema, formulario), inspector de entidad, inspector de ARCHIVO
              (preview, desglose, materiales editables, usos), paneles Escena / Jugador / Proyecto
  apps.js     apps HTML en pestañas (iframe blob + script inyectado que captura a.download), versiones ⟳/↶ manuales
  proyectos.js carpeta de proyectos (File System Access, Chrome/Edge PC): raíz elegida una vez (handle en IndexedDB 'proyecto'/
              'carpetaProyectos'), Proyectos/<nombre>/{proyecto.json, miniatura.png, archivos/<carpetas>/<archivo>}.
              guardar() en fila, solo escribe assets a.sucio o movidos, borra los quitados; autoguardado 2 min; Ctrl+S;
              ventana Proyectos (listar, abrir, nuevo, guardar copia, importar/exportar .forja.json). Sin API → .forja.json.
              v0.3.3: guardarArchivo() (showSaveFilePicker recordado en DB 'archivoForja' → sobrescribe; si no, descarga),
              respaldar() cada 5 min si hubo cambios (carpeta: guardar + respaldo.forja.json; o archivo elegido; o aviso),
              abrirDesdeSeleccion() con <input webkitdirectory> (cualquier navegador, solo lectura; varios proyectos → tarjetas).
  editor.js   visor, cámara de vuelo (clic der.+WASD), gizmo, escenas, árbol con arrastrar, archivos, colocar sobre superficie,
              al suelo, deshacer por escena, probar, guardar/abrir/exportar, atajos.
              v0.4: Ed.seleccionados (Set) + Ed.seleccion (principal); seleccionar(id, silencioso, 'solo'|'alternar'|'agregar'),
              Ed.seleccionarVarios(ids), raicesSeleccion() (sin hijos de otros seleccionados); con >1 el gizmo va en `pivote`
              y moverVarios() aplica delta = pivote·inv(pivote inicial) a cada matrixWorld guardado en mouseDown.
              clonarSubarbol(id), porProfundidad(lista) (padres primero; subarbol NO garantiza que la raíz vaya primero).
              Ed.copiarSeleccion/cortarSeleccion/pegar (raíces con transform del mundo), duplicarSeleccion, duplicarEnFila (Ed.dialogo),
              agruparSeleccion (Ctrl+G), seleccionarTodo, enfocar/alSuelo con varios. Rectángulo: Shift+arrastrar (listener en #vista
              en captura para apagar orbit antes que él). Vistas: camOrto + Ed.ponerVista('persp'|'superior'|'frontal'|'lateral'),
              camVista() = la que se usa para rayos/render; en orto LEFT=PAN, sin girar, sin niebla, rejilla girada.
              Ed.alternarEspacio() (T). Expuestos para el menú: Ed.deshacer, rehacer, agregarEntidad, escenaNueva/Renombrar/
              Duplicar/Borrar, cambiarEscena, exportarJuego, iniciarJuego, alternarSnap, modoGizmo, vistaActual().
              Eventos: 'seleccion-cambiada', 'escena-reconstruida', 'entidad-reconstruida', 'editor-vista'.
  colisiones.js "Ver colisiones": malla verde con F.Fisica.triangulosDe; envuelve Ed.guardarLocal para rehacerla (250 ms).
  panel-menus.js pestaña Menús (Ed.construirPanelMenus): formularios de proyecto.menus + editor de botones.
              Ed.probarMenus(pantalla) en editor.js: esconde objetos del editor, crea Ed.partida en #vista, Ed.jugando = true;
              Ed.detenerJuego() la destruye (detenerPartida).
  menu.js     menú superior: lista MENUS [{t, a, fn, si, marca}] → añadir opción = una línea. Ayuda/atajos (F1).
  inspector.js también: pintarInspectorVarios (varios seleccionados) y Ed.dialogo(titulo, esquema, valores, textoAceptar) → Promise
  editor.css
juego/datos.js datos opcionales para index.html (window.FORJA_JUEGO)
juego/arranque.js runtime de index.html (Partida + bucle); el exportador lo mete inline
herramientas/empaquetar.js  node → editor/empaque.js = window.FORJA_EMPAQUE {version, lista, archivos{ruta: texto}}
editor/exportar.js  Ed.Exportar.exportar(): diálogo html | zip (index.html, ZIP sin compresión con CRC32 propio) | datos.js.
              construirHtml(): index.html con sus <script src> (archivos.js, juego/datos.js, juego/arranque.js) cambiados
              por el código inline (fuente(): fetch si http, si no FORJA_EMPAQUE). archivos.js expone window.FORJA_ARCHIVOS.
componentes/   vacío (paso futuro)
```

## Modelo de datos (proyecto)
```
{ formato:'forja-juegos', version, nombre,
  ajustes: {resolucion, snap, afin, dither, filtroN64, limiteFps, vistaRetroEditor, nieblaEditor},
  jugador: { modulos: { nombre: { activo, ...props } } },
  escenas: [ { id, nombre, ambiente:{...ESQUEMA_AMBIENTE}, nivel:{memoria 'recordar'|'reiniciar', musica}, entidades:[...] } ],
  escenaInicial: id,
  carpetasArchivos: [ { id, nombre, rol ('modelos'|'texturas'|'musica'|'sonidos'|'fuentes'|''), padre, plegada } ],
  menus: { tema:{plantilla, fuente, colorTexto, colorSel, colorFondo, opacidadFondo, tamano, alineacion, mayusculas, sonidoMover, sonidoAceptar},
           principal:{activo, titulo, subtitulo, logo, textoPulsar, fondo('escena'|'imagen'|'color'), escena, velGiro, imagen, musica, botones:[{texto, accion, escena?}]},
           pausa:{titulo, botones}, opciones:{video, audio, controles, mapeo} }   (S.menusPorDefecto / S.normalizarMenus)
  materiales: { idAsset: { índiceMaterial: {modo, opacidad, prioridad, dobleCara, sinLuz, tinte, textura, normal, desplazX, desplazY} } } }
entidad: { id, tipo (cubo|suelo|rampa|escalera|inicio|modelo|carpeta|luz|recogible|enemigo|punto|aparecedor|marcador|salida),
           nombre, padre, plegado, pos, rot(°), esc,
           inicio:{principal} (varios ⚑ por escena) · salida:{destino, llegada, activar tocar|usar, aviso, sonido, fundido,
           cartel, cartelTitulo, cartelTexto, cartelImagen, cartelTiempo, llenarVida, quitarArmadura, inventarioInicial, olvidarNiveles},
           colision (malla|caja|ninguna), visible, color, textura, normal, fuerzaNormal, mosaico,
           material:{modo, opacidad, prioridad, dobleCara, sinLuz, desplazX, desplazY}, params:{...}, asset? }
```
`_camara` en escenas es solo del editor (no se guarda en archivo).
Asset (IndexedDB y .forja.json): { id, nombre, tipo (modelo|textura|audio|midi|fuente), mime, datos, carpeta } —
`carpeta` undefined = aún sin acomodar → Ed.carpetaPorDefecto (S.rolDeAsset: audio > 20 s = música). Fuentes: FontFace 'forja_<id>' (a.familia).

## Contrato de módulo del jugador
`FORJA.registrarModulo({ nombre, etiqueta, descripcion, orden, obligatorio, props:[esquema], iniciar(j,p,s), entrada(j,p,s,dt), fisica(j,p,s,dt), despues(j,p,s,dt), detener(j,p,s) })`
j = Jugador (cuerpo, yaw, pitch, modoCamara, direccion, modVelocidad, corriendo, saltando, camara, mundo, escena, props(n))

## Esquema de propiedades (inspector automático)
`{grupo}` · `{k, t:'num'|'rango'|'bool'|'sel'|'color'|'asset'|'texto', e, def, min, max, paso, op, tipoAsset, vacio, ayuda, si}`
`si: (valores) => bool` esconde la fila; en un `{grupo, si}` esconde todo el grupo (se reevalúa al cambiar cualquier valor).

## Historial
- v0.1 (un HTML): editor + BVH + controlador + apps integradas.
- v0.2: carpeta, Three local, módulos del jugador, capa de entrada, mapas normales, exportar juego.
- v0.3: escenas múltiples, jerarquía con carpetas y arrastrar, panel Archivos (filtros, peso, usos, sin usar),
  inspector de archivo con materiales editables, transparencia corregida (antes alphaTest 0.5 borraba el agua),
  modos de material + prioridad + sin luz + UV que fluye, cielo con textura (esfera/plano, escala, movimiento),
  niebla PS1 (lineal, por vértice, bandas, distancia de dibujado), cámara de vuelo, colocar sobre superficie,
  arrastrar modelo/textura al visor, al suelo (Fin).
- v0.3.1: carpetas en Archivos (Modelos, Texturas, Música, Sonidos, Fuentes; crear/anidar/renombrar/borrar, arrastrar archivos
  y carpetas), acomodo automático por tipo al importar, fuentes .ttf/.otf/.woff con vista previa, duración de audios.
- v0.3.2: botones ↺ Valores por defecto (entidad, materiales, escena, jugador, proyecto), materiales/texturas del modelo
  en el inspector de la entidad (cambiar textura), proyectos en carpeta con ventana Proyectos, miniatura, ● sin guardar,
  Ctrl+S, autoguardado; F.emitir('assets-cambiaron') en assets.js marca sin guardar.
- v0.3.3: selector "Abrir carpeta…" para cualquier navegador, respaldo automático cada 5 min sobrescrito
  (respaldo.forja.json en la carpeta del proyecto), "Guardar archivo .forja.json…" que pregunta y luego sobrescribe.
- v0.3.5: ↺ por propiedad (fila(…, revertir) + formulario(cont, esquema, valores, alCambiar(k,v,definitivo,anterior),
  {defectos, antes})). Inspector de entidad usa formulario (colisión, visible, material, medidas) con antes = marcarCambio.
- v0.9: Fase 2. proyecto.armas (S.ESQUEMA_ARMA, armaNueva, armasPorDefecto; editor/panel-armas.js = pestaña Armas).
  jugador/modulos/armas.js (orden 55): j.armas [{def,cargador,reserva}], j.armaActual, j.apuntando (0..1, la usa Cámara: acerca y
  corre al hombro), j.darArma(id|nombre), j.darMunicion, j.temblor. Disparo: rayo desde la cámara (en TPS empieza a la altura
  del jugador) → _trazar (BVH + Raycaster contra juego.objetivos) → en TPS segundo rayo cañón→punto. Pools: chispas 14, marcas 40,
  balas 16, explosiones 4. Evento 'disparo'. Juego: objetivos (entidades con vida > 0: {ent,obj,vida,danar}), rotos,
  romper(o), reconstruirColision() (actualiza jugador.mundo y cuerpo.mundo). Entidad.vida. Entrada: arma_siguiente (rueda 10 / Y),
  arma_anterior (rueda 11), cambiar_camara pasó a Back (8), E.teclasCuadro. Audio.sintetico: disparo, explosion, recarga, vacio, impacto.
  Menús: gameover con botones (botonesDe('gameover')), ACCIONES.en incluye 'gameover'; 'salir' en navegador → portada;
  Partida.arrancar('gameover') para la vista previa.
- v0.8.2: Entrada.neutralizar ya no borra estadoActual (flag 'neutro' por cuadro): borrarlo hacía que un botón mantenido
  (dedo en pantalla) se "pulsara" de nuevo cada cuadro.
- v0.8.1: menus.mensaje (estilo de la caja; Hud.estiloMensaje), máquina de escribir, interaccion.titulo, Jugador.pulsoUsar,
  interactuar.cerrarCon ('interactuar' | 'cualquiera').
- v0.8: Fase 1 del jugador. Módulos salud(5), agachar(16), esquiva(22), interactuar(50), pasos(70) (activoPorDefecto:false).
  Jugador: sinControl (Entrada.neutralizar), muerto, agachado, esquivando, bajarCamara, pulsoContinuar, danar/curar (de Salud),
  vacío = muerte si hay Salud. Juego.conPartida → Game Over (Partida.gameOver, estado 'muerte', menú p_gameover,
  menus.gameover.titulo). motor/hud.js: F.Hud.pieza(juego, clase) (.fh-barras, .fh-aviso, .fh-mensaje, .fh-rojo, .fh-negro;
  usa fuente/colores del tema). Entidad.interaccion {tipo:'mensaje', verbo, texto, mostrarNombre, unaVez}; evento 'interactuar'.
  Audio.efecto(id,{volumen,tono}) con grupo de 4 reproductores; Audio.sintetico('paso'|'aterrizar'|'golpe').
  Tactil: BOTONES con modulo/contextual/lugar/tam; ajustes tb_<accion>; configurar(ajustes, jugador), preferencias({escala,
  opacidad, pos}), ponerContexto, acomodar()/terminarAcomodo (Opciones grupo 'tactil', accion 'tactil-acomodar').
  Entrada: acción esquivar (Q / LB), multRaton/multMando/invertirJugador (Opciones) × sens del módulo Cámara.
  controlEsquema: t 'textoLargo' (textarea).
- v0.7: controles táctiles (motor/tactil.js), opciones sensTactil / tactil, ajuste controlesTactiles.
- v0.6.3: PARCHE en lib/three-forja.js (OrbitControls getZoomScale: 100*(devicePixelRatio|0) → 100*Math.max(1,…|0);
  con zoom del navegador < 100 % daba división entre cero → cámara NaN, visor gris). Si se regenera three-forja.js, volver a parcharlo.
  editor-completo.html (lo genera empaquetar.js): css + motor + editor inline (scripts con data-ruta, FORJA_UN_ARCHIVO,
  FORJA_TEXTOS = index.html y arranque.js en JSON con < escapado); exportar.js lee de ahí. Sin empaque.js dentro.
  repararCamara() en editor.js (NaN → vista por defecto), orbit min/maxDistance y min/maxZoom, avisos webglcontextlost/restored.
- v0.6.2: sección de luz por material (seccionLuzMaterial en inspector.js: Tipo = PRESETS + ESQUEMA_LUZ_MATERIAL), guardarMaterial(a,i,m,cambios)
  guarda solo lo que cambió (antes el formulario del archivo podía pisar los valores de luz).
- v0.6.1: auras (Sprite aditivo por fuente, textura en 6 escalones, halo/haloTam en luz y luzHalo/luzHaloTam en material,
  ajuste global 'halos'), marcas Points de fuentes de material (luces.mostrarMarcas en editor, enJuego en Juego/Partida),
  luces.cuantasDe(mat), avisos en inspector (Ed.actualizarAvisosLuces), "Emite luz" en el inspector de la entidad.
- v0.6: luces y sombras apagables (sol con sombras que sigue a la cámara, entidad Luz con parpadeo, materiales que emiten luz,
  grupo fijo de luces), módulo Sombra (mancha), opciones del jugador para luces/sombras.
- v0.5.1: Exportar juego = un solo .html con todo dentro (o zip para itch.io); antes datos.js (Windows lo bloqueaba al abrirlo).
- v0.5: menús del juego (portada, principal, pausa, opciones, asignar controles, 3 ranuras), pestaña Menús, Probar con menús,
  index.html usa F.Partida. Acciones de movimiento en Entrada (remapeables).
- v0.4: menú superior, multiselección (Ctrl/Shift/rectángulo, gizmo en pivote), copiar/cortar/pegar entre escenas,
  agrupar (Ctrl+G), duplicar en fila, vistas orto (Num 7/1/3/5), gizmo local/global (T), ver colisiones (C), límite de FPS.
- v0.3.4: botones "↺ Por defecto" en cabecera fija de cada panel; ?v= en las rutas de scripts/CSS contra caché.

- v0.9.1: jugador/modulos/balanceo.js (orden 12, apagado por defecto, solo 1ª persona). Estilo 'ligero' (vaivén de pasos
  que la cámara persigue con lerp) o 'inercia' (muelle rigidez 70/peso, amortiguación 11/√peso: retraso al acelerar/frenar,
  hundirse al aterrizar, flotar en el aire, inclinar al girar y de lado). Suma offset a cam.position (ejes de la vista sin pitch)
  y pone cam.rotation.z. Qué hace sale de headbobmodule.gd + headswaymodule.gd del FW. Formularios: propiedad `si`.

- v0.9.2: balanceo del ARMA con valores fijos caminar/correr (ritmoCaminar/fuerzaCaminar, ritmoCorrer/fuerzaCorrer, usa
  j.corriendo) en vez de seguir la velocidad (a 10 m/s vibraba). s.balF suaviza el paso de uno a otro.

- v0.9.3: Pasos con ritmo fijo (temporizador): ritmoCaminar 2/s, ritmoCorrer 3/s (j.corriendo), sonidos propios de correr
  (correr1/correr2, si faltan usa los de caminar) y volCorrer. Ya no usa 'distancia' (metros por paso).

- v0.10: RECOGIBLES. motor/recogibles.js (F.Recogibles: BASE, PRESETS, COLOR_TIPO, figura(ent)). Entidad 'recogible'
  (ICONO ✚, SIN_COLISION, sombra off) con ent.recogible {tipo vida|armadura|arma|municion, cantidad, arma(id), recoger tocar|usar,
  soloSiFalta, reaparece s, modelo, color, girar, flotar, brillo, radio, aviso, texto, sonido}. Figuras retro con color por vértice
  (geometría/material compartidos por tipo/color) + aura Sprite aditiva. juego.recogibles: preparar(guardado), actualizar(dt)
  (distancia al cuerpo, sin rayos), recoger(ent|id) → bool; emite 'recogido'. 'usar' lo hace Interactuar (lista con recogible:true,
  "No lo necesitas ahora"); su raycaster lleva .camera (sprites). darArma/darMunicion devuelven si algo cambió.
  Guardado: juego.estado() añade rotos, recogidos y jugador {vida, armadura, armas[{id,cargador,reserva}], armaActual};
  iniciar(guardado) los restaura (ponerEstadoJugador). HUD: .fh-recogidos (arriba izq.) y .fh-tinte (destello). Audio 'recoger'.
  Salud: tipoArmadura 'absorbe' (Quake) | 'escudo' (Halo, escudoTraspasa), regenArmadura (vel, espera, sonidoRecarga),
  sonidoEscudoRoto; emite 'jugador-sin-armadura'. Inspector: pintarRecogible (preajustes arriba, avisos de módulos que faltan).

- v0.11: MUNICIÓN, HUD y EDITOR ORDENADO.
  · proyecto.municiones (S.ESQUEMA_MUNICION, municionNueva, paqueteArmas() = armas+municiones de ejemplo enlazadas, TIPOS_DANO).
    Arma.municion = id de tipo ('' = propia, como antes). Reserva compartida en j.municion[id] (máx del tipo); armas.js usa
    _tipo/_res/_ponerRes/_max/_sumar/_dano. Daño = arma.dano × tipo.multDano; o.danar(cantidad, punto, {tipo, arma, jugador})
    y 'objetivo-danado' lleva info (los enemigos usarán info.tipo para resistencias). Arma sin tipo: arma.tipoDano.
    j.darArma(id, extra): si ya la tienes da 'extra' (recogible.cantidad) o su reserva. j.darMunicion(idTipo|idArma, n).
    Módulo Armas: alIniciar 'ficha'|'ninguna'|'todas'. Guardado: jugador.municion. Recogible.municionTipo.
  · proyecto.hud (S.ESQUEMA_HUD, PLANTILLAS_HUD, hudPorDefecto). motor/hud.js: aplicarEstilo pone clases en .fhud
    (fh-pos-esquinas|barra|arriba|arcade|discreto, fh-est-*, fh-mira-*, fh-no-*, fh-fondo, fh-auto) y vars (--fh-u, --fh-m…).
    Hud.cambio(juego, el) = mostrar un rato (ocultarTras). Hud.actualizar(juego) cada cuadro: solo la mira (fh-mira).
    Hud.vistaPrevia(cont, proyecto) para el editor. El #mira viejo del editor/index ya no se muestra.
  · Editor: pestañas Inspector · Escena · Jugador · Juego ▾ (subpestañas Ajustes=panelProyecto, Menús, HUD, Armas; Ed.abrirPanel(id)).
    editor/panel-hud.js. Modo 🧭 Sencillo / 🧰 Completo (Ed.modoSencillo, localStorage 'forja-editor:modo'): formulario salta
    props/grupos con av:true; marcas en inspector.js (AVANZADO por módulo, marcarAvanzados para render/ambiente/hud/munición).
    Jugador por CATEGORIAS. Secciones de la izquierda plegables (y Apps oculta en sencillo). "Primeros pasos" en Inspector vacío.

- v0.11.1: HUD Quake rehecho (franja en 3 casillas armadura · vida · munición, números grandes y nombre debajo),
  posición 'centro' + plantilla Centrado, hud.avisoBajo: .fh-bajo (rojo + parpadeo) en vida (salud.js) y munición (armas.js).

- v0.11.2: el arma en 1ª persona ya no atraviesa paredes. Vista.primerPlano() = escena aparte {escena, hemi, sol, camara,
  activo, fov} que render() dibuja DESPUÉS del nivel con clearDepth() en el mismo búfer (sin otra textura, sombras sin
  recalcular). armas.js mete s.vista ahí en fps y en j.escena en tps; prop fovArma (0 = el de la cámara). Si el cañón queda
  dentro de una pared, boca = punto justo antes de la pared (cohetes/fogonazo). En el FW: SubViewport aparte + shader de z.

- v0.11.3: F.Rendimiento (nucleo.js): CPU por cuadro (Juego.actualizar → _actualizar), GPU con EXT_disjoint_timer_query_webgl2
  en Vista.render (vista.medirGpu = true al jugar; consultas sin bloquear, hasta 4 en vuelo), posibles() = 1000 / el peor.
  Sale en F3 y en la barra de estado del editor al jugar. Vista.render ahora envuelve a _render.

- v0.12: ENEMIGOS (Fase 4a). motor/enemigos.js: F.Enemigos (BASE, PRESETS zombi/demonio/soldado/torreta/saltarin/murcielago/
  gargola, RESISTENCIAS, figura(ent)). Entidad 'enemigo' (☠, SIN_COLISION) con ent.enemigo. juego.enemigos = gestor:
  preparar(guardado) (enemigosMuertos), actualizar(dt) cada cuadro (antes de recogibles), detener() devuelve cada objeto a su
  padre/transform (editor). Pensar cada 0.1-0.14 s (lod 0, <25 m) o 0.5 s (lod 1, <50 m); lod 2 duerme (salvo persiguiendo).
  Ver = alcance + cono (persiguiendo 360°) + 1 rayo BVH; también al perseguir; memoria → última posición → buscar.
  Oír: pasos del jugador (0/1/2 según quieto-agachado/caminar/correr) y evento 'disparo' (cuerpo a cuerpo ×0.25).
  Estados: quieto/deambular/buscar/alerta/perseguir/anticipar/atacar/aturdido/muerto. Ataques cuerpo/disparo/proyectil
  (pool 20 sprites)/embestida (termina con contactoPared, no con el suelo)/salto (balístico g=20, 0.8 s)/picado; pegado
  (<1.8 m) los de carrera hacen golpe corto. Cada uno usa F.Fisica.CuerpoCinematico (volador: escalón 0.02, alto 2r,
  muelle de altura sobre sueloY con rayo abajo/arriba cada 0.5 s). Objetivo para armas: rayo(ori,dir,max) y distancia(p,out)
  contra cápsula (armas.js usa o.rayo/o.distancia si existen). Resistencias res_<tipo> multiplican el daño (info.tipo).
  Pisable (Mario). Al morir: suelta un preset de recogible (juego.recogibles.soltar(pr, pos); limpiar() al parar).
  Eventos: enemigo-danado, enemigo-muerto, enemigo-alerta, jugador-golpeado. Inspector: pintarEnemigo. Formulario: corregido
  el cierre de siGrupo (const sg). Rendimiento medido: 40 enemigos ≈ +1.6 ms de CPU.

- v0.12.1: APPS. Las apps del usuario están en C:\Users\migue\Documents\Videojuegos\Claude\Apps (forja_personajes, entorno-terreno,
  trovador). Forja de personajes v0.16 (copia de v0.15, nunca pisar la anterior): #forjaEnlace (solo dentro del editor:
  window.parent !== window) con "📤 Enviar a la Forja" y "En vivo" (envía 1.2 s después de cada cambio en #ui). ENVIO global:
  downloadBlob y exportGLB mandan postMessage {__forja:'export', nombre, blob, vivo} en vez de descargar; nombres fijos
  personaje_<nombre>.glb / enemigo_<nombre>.glb / arma_<nombre>.glb / objeto_<nombre>.glb → el editor reemplaza el mismo asset
  (Assets.importar por nombre). La app usa three 0.160 por CDN (jsdelivr): necesita internet.
  Motor: mapaAcciones con ALIAS_ANIM (hit↔hurt, death↔die, walk_c↔crouch_walk, dash→roll/dodge, attack, fly→walk), quita
  prefijo "Armature|" y -loop, y pone LoopOnce+clamp a jump/hit/death/attack*/slash*/stab/spear/axe/block/dash/recoil/reload.
  Enemigos: _anim usa reset().fadeIn().play() + fadeOut (crossFadeTo dejaba la acción apagada con peso 0 → pose T).
  Editor: refrescarUsos también reconstruye enemigos/recogibles que usan el modelo; importarArchivo(…, vivo) avisa solo la 1ª vez.

- v0.12.2: Bicho saltarín: el salto apunta a donde VAS a estar (P + vJugador·tv), tv = 0.55 + 0.045·dist (0.6–1.05 s), máx 16 m/s,
  y en el aire corrige hasta 7 m/s² hacia ti. Picado: adelanta la mitad. Modelo del jugador (modelo.js): variantes *_p con arma de
  fuego, capa mezclada (recoil al disparar, reload con evento 'arma-recarga' de armas.js, hit con 'jugador-dano'), bloqueo exclusivo
  para cuerpo a cuerpo (slash1→2→3 en combo < 0.9 s, stab/attack, attack_melee_c agachado), en 3ª persona mira hacia la cámara al
  apuntar o 0.6 s tras disparar. App Forja de personajes v0.16 SIN INTERNET: importmap con three r160 + OrbitControls + GLTFExporter
  + TextureUtils embebidos como data: URLs (base64). Sin usar aún: block, climb, spear, axe.

- v0.12.3: Respaldos cuando un modelo NO trae una animación (modelo.js guarda userData.animaciones/acciones en el clon):
  agacharse encoge solo si falta crouch/walk_c; morir tumba el modelo solo si falta death/die; esquivar se inclina si falta
  dash/roll; enemigo con GLB sin attack/hit se inclina (_figuraViva(…, soloInclinar)) y sin die se cae de lado.
  En 1ª persona el cuerpo del jugador no se anima (acumula dt hasta 0.5 s para retomar en 3ª).

- v0.12.4: IDA Y VUELTA con la Forja de personajes. Al enviar, la app guarda {app:'forja-personajes', v, estado} en
  root.userData.forja (personaje: charState(); arma: {kind:'arma',…stripDef(WDEF)}) → extras del GLB → userData al cargar.
  Editor (apps.js): Ed.Apps.datosForja(asset), Ed.Apps.editarEnApp(idAsset): abre la app más nueva cuyo nombre/título
  diga "Forja de personajes" y le manda {__forja:'editar', estado, archivo}; la app avisa {__forja:'app-lista'} al cargar
  (si tarda > 8 s: aviso de versión vieja). La app aplica el estado, fija DESTINO = archivo (reenvía con ese nombre; "soltar"
  lo quita) y activa En vivo. Botón ✎ en el inspector del archivo, de la entidad modelo y del enemigo.
  Sin modelo, el jugador es una figura retro (modelo.js _figura/_animarFigura): hombros, codos, caderas y rodillas
  animados por código (caminar, correr, saltar, agachar, apuntar con arma, retroceso, golpe, dolor); colores en el módulo.

- (sin subir versión) Apps se ve siempre (antes el modo sencillo la escondía). Arma en 3ª persona pegada al hueso hand_R/Hand_R
  del modelo (armas.js _mano); sin hueso, a un costado como antes. Pendiente probarlo con un GLB real de la Forja de personajes.

- v0.12.5: Arma en 3ª persona pegada a la mano DE ESTE CUADRO: armas.js marca s.tps y Modelo llama a j.alColocarModelo
  al terminar de mover/animar → _colocarTps (updateMatrixWorld del modelo + posición del hueso hand_R; giro = cámara).
  La figura del motor tiene un nodo 'hand_R' al final del antebrazo derecho (derecha = -X mirando a +Z).
  Puños: props punos/danoPunos/alcancePunos/cadenciaPunos → arma '__punos' (tipo cuerpo, infinita) primera de la lista;
  j.armasExtra para guardar/cargar; en 1ª persona dos puños de cajas, en 3ª no se ve arma. cambiarSinBalas (def. sí):
  al vaciarse sin reserva pasa a la siguiente usable (_cambiarConBalas). Menús: "Volver" va en .fm-pie (fuera del scroll),
  .fm-mas ▲/▼ "más abajo" + máscara difuminada cuando la lista no cabe (indicadores() en marcar), escala por
  min(alto/600, ancho/640) y clase .vertical (celular de pie): más ancho, textos que se parten, columnas de mapeo flexibles.

- v0.12.6: arma de 3ª persona orientada por el PERSONAJE (yaw = modelo.rotation.y + PI, −PI si girar180), casi recta
  (pitch −0.12); solo apuntando o 0.6 s tras disparar (modelo.tApuntar) toma el pitch de la cámara (suavizado 0.35/cuadro).

- v0.12.7: arma en la mano ajustable: campos por arma tpsX/tpsY/tpsZ/tpsEscala (grupo "En la mano (3ª persona)", se ven
  en vivo mientras juegas) y módulo Armas manoTps derecha|izquierda (hand_R / hand_L). Escala FPS se restaura al volver.

- v0.12.8: la mano agarra la EMPUÑADURA: _modelo guarda obj.userData.grip (GLB: nodo "Grip" de la Forja de personajes;
  armas de cajas: punto de su mango) y en 3ª persona m.position = ajuste − grip·escala girado. Nuevos por arma
  tpsGiroX/Y/Z (°) para modelos cuyo arma queda de lado (p. ej. Y = 90). tpsZ de serie ahora 0.

- v0.12.9: arma de 3ª persona como PARTE DEL BRAZO (pedido de Miguel): _colocarTps orienta el cañón (−Z) en la dirección
  antebrazo → mano (hueso padre → hand_R), "arriba" del arma = mezcla de +Y y el frente del personaje según lo vertical del
  brazo; posición = muñeca + 5 cm en esa dirección. Ya NO usa yaw/pitch de cámara (sustituye a v0.12.6). Brazo caído = arma al
  suelo; si la animación sube el brazo (idle_p, aim), apunta al frente. tpsGiroX/Y/Z siguen como ajuste fino (0 de serie).

- v0.12.10: cambio de arma: animCambio (apagada = al instante, s.cambio 0) y dirCambio 'arriba' (de serie: sube y baja) | 'abajo'.

- v0.13.0: FASE 4b+4c (actitudes, manadas, patrulla, jefe, aparecedor). Todo en motor/enemigos.js:
  · BASE nuevos: actitud 'agresivo'|'neutral'|'pacifico'|'depredador', etiqueta, caza (lista por comas; "jugador" vale),
    avisar (radio a los de su MISMA etiqueta), huirConVida (0..1 → E.asustado), patrulla (ruta), jefe/nombreJefe,
    soloMolde (no sale; solo lo copian aparecedores), forma 'humano'|'animal' (geomAnimal, 4 patas).
    PRESETS animales: conejo (pacífico, presa), vaca (neutral, ganado, embiste), lobo (depredador presa+ganado), oso (agresivo).
  · Blanco genérico: E.blanco es el jugador o E.yo de otro enemigo ({enemigo, cuerpo, muerto, danar(c, origen, de)}): todo
    _mover/_atacar/_pegar/_golpeContacto/balas funciona con cualquiera. E.amenaza = quien le pegó o le marcaron (manda).
    _elegirBlanco: amenaza → blanco actual si está en ACTIVOS → jugador (agresivo/pacífico) o presa más cercana (busca 2/s).
    _reaccionar: _huye (pacífico o asustado) → estado 'huir' (_rumbo: contrario + desvío al chocar/atascarse) o alerta/perseguir.
    _avisar a la manada; _alertar marca a la presa (huye o se defiende). Al matar, el depredador come 3 s. _calmar al perderte.
    danar(E, c, info.de) y objetivo-danado siguen igual para las armas. Lejos (lod 2) solo duerme si está tranquilo (IDLE).
  · Entidad 'punto' (📍, ent.punto {ruta, orden, espera}): rutas de patrulla y sitios de aparición. Ayuda solo en el editor.
  · Entidad 'aparecedor' (🥚, ent.aparecedor = APARECEDOR): modo 'zona' (maximo, cada, alInicio, activa, desaparecerLejos:
    los lejanos que no ves se retiran) u 'oleadas' (forma auto: inicial+crecer, total 0=infinitas | lista: una línea por oleada;
    fuerza % de vida y daño por oleada, jefe cada N (sale el último), descanso, vivosMax, empezar entrar|inicio). Comunes:
    enemigos "conejo x3, vaca" (leerLista), radio, aparicion fuera|siempre (_enVista: frustum + rayo desde la cámara),
    distanciaMin, puntos (ruta). Moldes: enemigos de la escena por nombre o preajustes (por clave o nombre, sin tildes).
    Generados: E.generado, no se guardan en la partida; al morir desaparecen (8 s si desaparecer=0) y van a this.reserva por
    molde y se REUTILIZAN (_reiniciar, sin clonar ni compilar). En oleadas E.sabe = siempre conoce tu posición.
    Eventos: oleada-inicio {aparecedor, oleada, enemigos}, oleada-fin, arena-completa. Las oleadas no se guardan (empiezan de 0).
  · HUD (hud.js CSS): .fh-jefe (barra arriba, la pone _hudJefe cada 4 cuadros si hayJefes), .fh-oleadas (contador),
    .fh-cartel ("OLEADA 3", "¡ARENA SUPERADA!").
  · Editor: grupo Comportamiento en el enemigo, Patrulla (select de rutas), Figura; pintarPunto (＋ Siguiente punto) y
    pintarAparecedor (avisa nombres que no existen). Botones 🥚 y 📍 en Escena y en el menú.
  · Medido: 40 criaturas de zona → enemigos.actualizar 0.2 ms (p95 0.4). Lobo alcanza conejo (7.8 vs 5.2 m/s).
  · Pendiente: criaturas de agua (con el nado), guardar el estado de las oleadas, dibujar la línea de la ruta en el editor.

- v0.13.1: BIBLIOTECA DE CRIATURAS (pedido de Miguel: no escribir nombres a mano en los aparecedores).
  · proyecto.criaturas = [{ id, nombre, enemigo }] (escena.js criaturaNueva / criaturasPorDefecto: una por preajuste con id fijo
    cr_<preajuste> / aplicarCriaturas(p, id?): los enemigos con ent.criatura copian su config en ent.enemigo; se llama al normalizar
    el proyecto y al editar una criatura → el motor no sabe nada de vínculos).
  · Aparecedor: salen [{criatura, n}], oleadas [[{criatura, n}]…] (lista), jefe = id de criatura. Ya no hay texto.
    normalizarEntidad convierte lo de la v0.13.0 (enemigos/lista/jefe en texto) con Enemigos.textoACriaturas.
    Runtime: _molde(ref) busca primero la criatura por id en juego.proyecto.criaturas (clave 'c:'+id), luego nombre (respaldo).
  · Editor: panel Juego ▸ Criaturas (editor/panel-criaturas.js): lista con actitud y usos, ＋ Nueva, Duplicar, ☠ Poner en la
    escena (vinculado), Borrar (vinculados → copia propia; aparecedores la quitan), Nueva desde preajuste; mismo formulario
    que el inspector (Ed.formEnemigo, esquemaEnemigo, VISUAL_ENEMIGO). Inspector del enemigo: select 📚 Criatura; vinculado =
    edita la criatura (Ed.propagarCriatura rehace los de esta escena); propio = preajustes + "📚 Guardar como criatura".
    Aparecedor: filasCriaturas (select × número ✕, ＋ Criatura), en lista una cabecera por oleada (＋ Oleada copia la última +1).

- v0.13.2: árbol de la escena (panel Escena): 🗑 en la fila seleccionada (ponerPapelera, la llaman pintarArbol y
  marcarSeleccionEnArbol). Dos clics: el 1º la arma ("¿Borrar?" en rojo 2,5 s), el 2º llama a Ed.borrarSeleccion (Ctrl+Z deshace).

- v0.14.0 / v0.14.1: BRÚJULA (motor/brujula.js, F.Brujula; juego.brujula se crea tras los enemigos y se actualiza tras el HUD).
  hud.brujula 'no'|'tira'|'circulo', brujulaEsquina, brujulaTam, brujulaMarcadores, brujulaDistancia, norte (° ; 0 = −Z).
  Tira: cinta de −180°..540° (400% de ancho) que se desliza con translateX; círculo: rosa con --rb (letras contra-giradas).
  Rumbo = camara.getWorldDirection → atan2(x, −z). Entidad 'marcador' (📌, ent.marcador = Brujula.MARCADOR: icono, color,
  texto, alEmpezar, radioLlegar). juego.brujula.marcar(idONombre, visible) para la Fase 5; evento 'marcador-alcanzado'.
  Con tira, .fhud.fh-con-tira baja la barra del jefe y el contador de oleadas. Vista previa en Juego ▸ HUD.
  Rendimiento medido (v0.13.2): 88 criaturas en 3 aparecedores → enemigos 0.3–0.4 ms/cuadro, cuadro CPU ~1 ms.

- v0.15.0: GESTOR DE NIVELES (motor/niveles.js). Del FW (LevelManager.gd + Game.gd + leveldoor2.gd) se tomó el QUÉ:
  spawn por nombre, el jugador conserva vida/armas, cada nivel recuerda muertos/recogidos/rotos, fundido + pantalla de
  carga, sonido, resets por puerta. NO se copió: lista LEVELS en código, caché LRU de 20 solo en RAM (en el FW se perdía
  al cargar partida: aquí va en la ranura), fundido creado por cada puerta, espera fija de carga, process_mode/grupos.
  · Entidad 🚪 'salida' (SIN_COLISION, esc [2,2.5,1] = tamaño de la caja; azul tocar / naranja usar). Interactuar la lista
    (aviso "Ir a <nivel>" o salida.aviso) y _usar → juego.salidas.activar. Misma escena = teletransporte.
  · ⚑ varios inicios: inicio.principal (verde) / llegadas (amarillo). agregarEntidad('inicio') ya NO borra el anterior.
  · escena.nivel (Panel Escena → "🚪 Nivel": memoria y música; enlaces a salidas y a quién llega). Música por escena
    también en ▶ Jugar (F.Audio.musica; pararMusica al detener).
  · Inspector: pintarSalida (Nivel, Llegada, ESQUEMA_SALIDA, "↔ Crear la vuelta" = ⚑ aquí delante de la salida + ⚑ y 🚪
    de vuelta en el otro nivel, "⚑ Ver la llegada"), pintarInicio (principal, "Aquí llegan"). Escala ↺ = la del tipo.
  · Editor ▶ Jugar: Ed.niveles + Ed.escenaAlJugar; el evento 'salida' → cambiarEscena + iniciarJuego(inicio, true);
    durante el fundido el bucle solo dibuja; Detener vuelve a la escena donde se pulsó ▶.
  · Partida: nueva/escena/sin menú → nuevaPartida; guardar añade niveles; cargar → niveles.cargar(datos) (partidas viejas:
    entrada = punto guardado); empezar() hace un fundido de entrada de 0.35 s.
  · Probado (Chromium headless, file://): ida 1→2 con vida 37, reiniciar en 2 vuelve con 37, vuelta 2→1 en la llegada
    con la caja rota, guardar/cargar con memoria de los 2 niveles, puerta con E ("E: Ir a Sótano"), cartel, teletransporte,
    ▶ Jugar ida y Detener vuelve, juego exportado (.html) viaja. Sin errores de consola.
  · Pendiente: salida con llave (cuando existan las llaves), salidas activadas por evento/trigger, misiones por nivel.
    Las oleadas siguen sin guardarse (al volver empiezan de 0).

- v0.15.1: SALIDA CON MODELO (pedido de Miguel: puerta con o sin animación). salida.modelo (GLB) + modeloEscala/X/Y/Z/Giro.
  figura(): soporte con updateMatrixWorld propio que deshace la escala de la caja (el modelo no se estira) → giro (girar/
  flotar) → modelo (userData.modeloSalida). modeloChoca: fisica.triangulosDe mete solo la malla del modelo (skinned no
  choca: aviso en el Inspector). animReposo (bucle) / animUsar (una vez, clamp) por nombre exacto de clip (selects con los
  clips del GLB); esperarAnim = el fundido espera la duración del clip. girar (vueltas/s), flotar (m), ritmo (cps retro,
  como target_fps del leveldoor2). Salidas.animar(dt) cada cuadro y durante el viaje (bucle rAF propio en viajar),
  abrir(ent) → segundos, detener() vuelve a la pose. Probado con un GLB de puerta con clips abrir/reposo.

- v0.15.2: SALIDAS CON FIGURA DEL MOTOR (regla 2). salida.figura 'auto' (puerta si se usa / portal si se toca) | 'puerta' |
  'portal' | 'ninguna'; colorMarco, colorPuerta, colorPortal. figuraMotor() en niveles.js: soporte que deshace la escala de la
  caja y arma marco + hoja (bisagra) + tirador o marco + velo aditivo EN METROS (colocar(W,H,D) se recalcula si cambias la
  escala). userData.puertaMotor {bisagra|velo}; Salidas.animar abre la hoja (0.5 s) o hace latir el velo; abrir() espera 0.45 s.
  La puerta del motor es modeloSalida (con "Choca" tapa el paso). Inspector: avisos de "no lleva a ningún nivel", "Choca"
  con "al entrar en la caja", destino sin ⚑ y ⚑ dentro de la caja. Revisión: las salidas de la v0.15.1 SÍ funcionaban
  (tocar, usar y con menús, probado); si a Miguel no le van, pedir cómo la configuró (probable: sin Nivel elegido).

- v0.15.3: PUERTA "USAR" SÓLIDA DE SERIE (Miguel: "no funciona tipo Resident"). Causa reproducida: la puerta no chocaba,
  el jugador la atravesaba y la dejaba atrás. salida.choca 'auto' (sólida si activar = 'usar') | 'si' | 'no' sustituye a
  modeloChoca (si una salida vieja lo tenía en true, cuenta como sólida). Niveles.chocaDe(s) lo usa fisica.triangulosDe.
  Probado caminando con W y pulsando E en 1ª y 3ª persona dentro de una pared con hueco.

- v0.16.0: Interactuar activado de serie (activoPorDefecto: true; proyectos guardados conservan lo suyo) y su categoría
  "Interacción con el mundo" justo después de "Lo básico". Figura del jugador = MUÑECO DE PRUEBAS DE CHOQUE (modelo.js _figura):
  amarillo, juntas negras (cuello, cinturón, hombros, codos, rodillas, pies), marcas de cuartos (canvas 16 px, Nearest)
  en pecho/espalda, lados de la cabeza y de los muslos, ojos negros, sin pelo. Nuevo colorJuntas. Migración: si el
  proyecto tenía los 3 colores viejos de serie pasan a los nuevos. Reglas 2 y 12 + "Cómo trabajo" ampliados; copia de
  las reglas en el Proyecto de Claude "Motor de juegos" (claude/reglas-forja-de-juegos.md).

- v0.17.0: AGUA Y NADO (Miguel eligió: los dos estilos, aire opcional, cada criatura decide, acuáticos que saltan opcional).
  · motor/agua.js (F.Agua, juego.agua se crea ANTES del jugador): entidad 💧 'agua' (ent.agua = AGUA: color, opacidad,
    textura, mosaico, corriente, tinte, niebla, sonidoApagado, dano). Caja 1×1×1 escalada, cara de arriba = superficie
    (figura del motor: ondas 32 px; fluye con uDesplazUV·uTiempo en la GPU; repeat según la escala en onBeforeRender).
    en(x,y,z) caja rápida + matriz inversa; actualizar(): efectos si la CÁMARA está dentro (niebla con U.uNieblaCerca/Lejos y
    fog.color, capa multiply, F.Audio.bajoAgua: volumen y tono bajos, filtro 420 Hz en los sintéticos) y daño (lava/ácido).
    Si el nivel tiene agua y no tenía niebla se crea una niebla "apagada" al empezar (evita recompilar al bucear).
  · jugador/modulos/nadar.js (orden 14, activo de serie): estilo 'libre' (Quake: hacia donde miras, Saltar sube,
    Agacharse baja, se hunde despacio) | 'superficie' (flota con la cabeza fuera, mantener Agacharse = bucear). Saltar
    con el pecho cerca de la superficie = salir (impulso). j.nadando / j.bajoAgua. Aire opcional (barra .fh-aire, daño por s).
    Movimiento, Salto, Gravedad, Agacharse y Pasos se apartan si j.nadando; Salud no cuenta la caída al agua.
    modelo.js: pose de nado de la figura (brazadas/patadas) y el cuerpo se tumba (rotation.order YXZ); anim 'swim' si el GLB la trae.
  · enemigos.js: BASE enAgua 'nadar'|'orilla'|'fondo' (terrestres), tipo 'acuatico' (E.nada, usa el cuerpo del volador),
    saltaFuera + alcanceSalto (_saltoFuera: llega a ti en lo alto y cae; varado = saltitos hacia su casa). _moverAcuatico:
    profundidad propia, sube a tu altura persiguiendo, huir = al fondo, no sale por los lados (rebota). Muertos flotan
    panza arriba. Presets pez / tiburon / pirana (figura de pez con cola que se mueve). Zombi 'fondo'; demonio, soldado
    y conejo 'orilla'. Aparecedor: acuáticos solo dentro del agua, los demás nunca dentro.
  · Medido: 49 criaturas acuáticas → enemigos.actualizar 0.2 ms (p95 0.5), agua.actualizar ~0 ms.
  · Pendiente: criaturas de serie nuevas no entran solas en bibliotecas viejas (botón ↺ de Juego ▸ Criaturas las añade);
    corrientes que arrastren; olas en la geometría.

- v0.18.0: LÍQUIDOS DE LOS MODELOS + LAVA (Miguel: prioridad agua del creador de terrenos; lava instantánea, agua con aire).
  · agua.js: LIQUIDOS agua / lava / acido (color, opacidad, tinte, niebla, dano, nadable, corriente). ent.agua.liquido
    (el Inspector pone los valores de serie al elegirlo). La lava NO se nada (quemas y pisas el fondo) y brilla (emissive).
  · Modelos: marcarModelo(obj, ent) en Escena.crearObjeto: mallas cuyo MATERIAL se llama agua/water/lava/ácido… (el
    nombre de la malla solo si el material no tiene nombre) → userData.esAgua = líquido; fisica las salta (no son sólidas);
    aspecto 'motor' = material del motor con UV planas en metros. ent.aguaModelo = AGUA_MODELO {activo, liquido auto|…,
    aspecto, mosaico}; sección "💧 Líquidos del modelo" en el Inspector (solo si el modelo trae alguno).
    Agua._mapaAlturas: rasteriza la superficie en celdas (≥0,5 m, ≤250k celdas, vértices marcan su celda) → en() = lectura
    de celda (y ≤ h y ≥ h − 40 m). Probado con un terreno de prueba: lago nadable, peces dentro, lava que quema.
  · Daño del entorno (origen 'lava' | 'agua' | 'ahogo') no respeta ni da invencibilidad (salud.js); al entrar quema ya.
  · Enemigos: daño de lava (tipo fuego) y ácido (veneno) según sus resistencias, sin culpar al jugador (info.liquido);
    nadie entra en lava/ácido (salvo res_fuego 0 en lava); se mira el líquido delante también 0,8 m más abajo.
    Acuáticos solo en líquidos sin daño. Nadar: aire ENCENDIDO de serie (proyectos 0.17 con aire=false pasan a true).
  · Pendiente del creador de terrenos (decidido, para después del inventario): B) convertir sus marcadores
    (jugador_inicio, enemigo_*, salida, municion, salud, llave_*) en entidades; C) enlace en vivo "📤 Enviar a la Forja"
    (y que la app funcione sin internet: hoy carga three r128 y GLTFExporter de jsdelivr); y conectar lo que ya trae la
    mazmorra (botones, puertas con llave, ascensores, hoja de puerta "puerta_hoja") con la Fase 5.

- v0.19.0: INVENTARIO (Miguel eligió: RE 1 objeto = 1 casilla o lista; usar/equipar, examinar, combinar —también
  munición + arma = recargar—, tirar; baúl opcional; abrir con pausa o en tiempo real a elección del creador).
  · motor/inventario.js: OBJETO (tipo cura|llave|clave|nota|mochila|otro, icono, color, descripcion, pila, vida, armadura,
    casillas, texto, forma de la figura, modelo), objetosPorDefecto (ids ob_*: hierbas verde/roja, mezcla, spray, llave,
    mochila, nota), recetasPorDefecto ({a, b, da, n}). figuraObjeto (frasco/hierba/llave/caja/papel/bolsa) y figuraBaul.
    F.Inventario (j.inventario): items de {k:'obj'|'arma'|'mun', id, n}; agregar → lo que NO cupo; cabe; quitar; gastar;
    ampliar; receta; serializar/cargar (con el baúl: el mismo en todos). F.InventarioUI: DOM sobre el HUD (tema de Menús),
    casillas + ficha + acciones; teclado (flechas/WASD, E/Enter/Espacio, Q/Esc, Tab/I) y mando (cruceta, A, B), ratón/toque;
    examinar = WebGLRenderer propio pequeño (arrastrar gira). Al abrir suelta el ratón con Entrada.silencioLiberar
    (no dispara 'cursor-liberado').
  · jugador/modulos/inventario.js (orden 57, apagado de serie): estilo, casillas, casillasMax, armasDentro, abrir
    pausa|tiempo, tamano, sonido. Con armasDentro envuelve j.darArma / j.darMunicion (a la mochila; "No tienes sitio") y en
    despues() iguala j.municion a la mochila (la recarga del módulo Armas gasta de ahí); sincronizar() = j.armas desde la
    mochila (+ puños), armaEquipada. usarObjeto / tirarObjeto (recogible suelto delante) / combinar.
  · juego.js: con el inventario abierto, pausa = solo dibujar; tiempo real = Entrada.neutralizar(). estado() guarda
    jugador.inventario + armaEquipada; ponerEstadoJugador los carga (viajan entre niveles).
  · Recogible tipo 'objeto' (objeto = id; figura del objeto; "No tienes sitio" con recogibles.mensaje). Entidad 📦 'baul'
    (colisión caja; Interactuar: "E: Abrir baúl" → abrir(…, true)). Acción 'inventario' (Tab / I) y botón táctil 🎒.
  · Editor: Juego ▸ Objetos (editor/panel-objetos.js): biblioteca, ✚ Poner en la escena, recetas A + B → resultado ×n.
    Módulos Inventario y Nadar en "Interacción con el mundo".
  · Probado: recoger 4 objetos, Tab abre y pausa (no te mueves), verde + roja = mezcla, curar 30 → 100, leer nota, examinar,
    recargar con la mochila (48 → 36), tirar (aparece el recogible), mochila llena, baúl con E, guardar/cargar.
  · Pendiente: llaves que abren puertas (Fase 5), objetos de inicio, ordenar la mochila, atajos de curación.
  · Creador de terrenos: existe la v2.47 (Apps/entorno-terreno-v2_47.html; solo arreglos de geometría, atlas IA y
    dibujar a demanda; exporta el agua igual). Usarla de base para el enlace en vivo.

- v0.19.1: peces "varados" en una 💧 (Miguel). Causa: estaban por debajo del FONDO de la caja (la caja de serie mide 1,5 m;
  hundida en un hoyo más hondo, lo de abajo quedaba fuera). Ahora una caja 💧 cuenta como agua todo lo que está BAJO SU
  SUPERFICIE hasta 40 m (PROF_CAJA; fondoLocal en el volumen), como los lagos de los modelos. Inspector del enemigo
  acuático: ⚠ si no está bajo ninguna superficie de agua (Agua.dentroDeCaja). Ojo: una sala justo debajo de una caja de
  agua contaría como "bajo el agua" (raro; si pasa, añadir un "fondo" opcional a la caja).
- v0.19.2: al cerrar mochila/baúl el ratón no volvía a la cámara y el clic de recuperarlo disparaba (Miguel).
  InventarioUI.cerrar() pide el bloqueo (pedirBloqueo, en el mismo gesto de tecla); y en entrada.js el mousedown sin
  bloqueo SOLO captura el ratón (return, no dispara). Jugador ▸ Inventario: verVida / verArmadura (barras ♥ ⛨ en la mochila).

- v0.19.3: PLANTILLAS de proyecto nuevo (editor/plantillas.js, F.Plantillas.crear): ＋ Nuevo proyecto pide nombre y
  plantilla: 'ejemplo' (el de siempre), 'demo' = "Campo de pruebas" (losas de 3 m sobre un suelo a -3 → fosos reales:
  piscina con escalera y peces, lava con puente; recogibles, nota propia ob_nota_demo, baúl, cajas rompibles, parkour con
  rellano y mesa para agacharse, zombi con ruta1, soldado, torreta, animales, arena de oleadas, brújula tira con marcadores,
  puerta 'usar' al Nivel 2 y portal de vuelta a un ⚑ secundario) y 'vacio' (suelo + ⚑). Probado jugando.
  Muñeco del motor: caminar agachado (pasos cortos alrededor de la postura; fase más rápida).
  ARREGLO: la patrulla de un enemigo VINCULADO es de ese enemigo (aplicarCriaturas la conserva; inspector "Solo este
  enemigo"; formEnemigo(..., deCriatura=true) quita la patrulla del formulario de la criatura).
- v0.20.0 FASE 5 · parte 1: 🔒 PUERTA (motor/mecanismos.js, entidad 'puerta', F.Mecanismos; juego.mecanismos).
  Decidido con Miguel: abrir 'usar' | 'cerca' | 'mecanismo'; llave = objeto tipo llave/clave, gastarLlave elige el creador;
  estilos bisagra (se abre lejos del jugador) / deslizar / arriba / negro (corte a negro RE: te pasa al otro lado) /
  energia (transparente, se apaga) / modelo propio como hoja (+animAbrir/animCerrar); cerrarTras (0 = se queda).
  Caja = hueco (esc); soporte deshace la escala (como la salida). Marco → mundo fijo (triangulosDe), hoja → PIEZA MÓVIL:
  fisica.js BVH.reservarMoviles(piezas)/moverPieza(m) (tramo al final de t/nor, recoger y rayo las miran aparte;
  triangulosLocales). Tras romper algo juego.reconstruirColision → mecanismos.alMundo. Cerrando con el jugador en
  el hueco espera (_estorba). Memoria del nivel/partida: est.mecanismos.puertas {abierta, desbloqueada, signo}.
  Interactuar: aviso Abrir/Cerrar (textoUsar), las de mecanismo dicen "No se abre desde aquí". Campo de pruebas:
  muro con puerta con llave (llave en la arena). 0,001 ms/cuadro. Pendiente Fase 5: palancas/botones con lista
  "Qué hace" (selects + línea en el visor) y CANALES; disparadores (una vez / cada vez / entrar y salir); plataformas
  y elevadores; puzles (varias palancas, matar a todos, objeto clave en pedestal); acción "cambiar de nivel".
- (pendiente, lado del editor) FORJA DE SONIDOS: Miguel la hace con su otra cuenta con el encargo
  encargo_forja_sonidos.txt. Protocolo: <title> "Forja de Sonidos vX", app-lista, export {nombre, blob, vivo},
  editar {estado, archivo}; ajustes dentro del .wav en un chunk RIFF "forj" (JSON {app:'forja-sonidos', estado}).
  A hacer aquí: leer el chunk al importar audio, botón "✎ Editar en Forja de sonidos" en audios (como datosForja/
  editarEnApp de personajes, buscando la app por /forja de sonidos/i), y grupos de variaciones nombre_1..4.
- (pendiente, decidido) RECETAS: el creador elegirá por recurso "Receta (ligero)" o "Archivo" al exportar.
  Encargo al otro Claude: encargo_recetas_y_terrenos.txt. Formato .receta.json {formato:'forja-receta', app,
  appVersion, generador, semilla, estado, manual, salida}; generador en <script id="forja-generador" data-app
  data-generador> registrado en window.FORJA_GENERADORES['app@N'].generar(receta, THREE) → {grupo, marcadores, info}
  (sonidos: → {buffer, sampleRate}). GLB lleva userData.forja = {app, estado}. Lado del editor (mío): importar
  .receta.json, sacar el generador del HTML de la app guardada, ejecutarlo en el juego, caché en IndexedDB,
  medidor de peso al exportar. Metas de peso propuestas: chico < 5 MB, mediano < 15-20 MB.
- (pendiente, lado del editor) CONEXIÓN TERRENOS: encargo_conexion_terrenos.txt (el otro Claude lee editor-completo.html,
  no lo toca). Pide: app-lista, 📤 Enviar (export/vivo), editar ↔ userData.forja en el GLB, three/exporters dentro del
  HTML (sin CDN), materiales estables y en orden, líquidos = solo superficie con material agua/lava/acido, marcadores =
  nodos vacíos con userData.forja = {marcador, id, ...datos} (tabla en el txt). A hacer aquí: "✎ Editar en Entorno de
  Niveles", "Convertir marcadores en entidades", mallas "deco_" fuera de la colisión, importar .receta.json.
- v0.21.0 FASE 5 · parte 2: 🕹 PALANCA (entidad 'palanca': forma palanca/boton/interruptor; modo alternar/una/volver;
  alApagar invertir|nada) con lista "Qué hace" = ACCIONES (mecanismos.js: abrir/cerrar/alternar puerta, luzOn/Off/Alt,
  marcaOn/Off, apaOn/Off, palOn/Off, mensaje, sonido, nivel, canal; cada una con retraso; inv = lo contrario).
  📡 CANALES: acción 'canal' → escuchan puertas (puerta.canal: on abre / off cierra) y palancas (palanca.canal).
  APIs nuevas: luces.encender(entId, on|null) + luz.apagada (empieza apagada); enemigos.activarAparecedor(entId, on)
  + aparecedor.empezar 'mecanismo' (oleadas) y encendido:false (zona). Zona invisible de uso en la palanca (el rayo
  pasaba por encima del palo). editor/conexiones.js: líneas naranja (acciones) y cian (canales) de la selección.
  Inspector: tarjetas de acción con selectores de este nivel + avisos (nadie escucha el canal, puerta de palanca que
  nadie abre). Memoria: palancas {on, usada}; al volver se reponen luces y marcadores (mecanismos.reponer()).
  Campo de pruebas: botón rojo en la columna de la arena (empieza las oleadas) y palanca de la farola.
  Siguiente: parte 3 disparadores (zona invisible: una vez / cada vez / entrar y salir, misma lista).
- v0.21.1: (Miguel) las líneas de las palancas se veían al jugar: ahora solo en el editor (se esconden con
  juego-iniciado y en el bucle mientras Ed.jugando / Ed.partida, también en el menú de "Probar con menús").
  Puerta "ya no se cierra con E": al pasar a 'cerca' se ponía cerrarTras = 1 y eso escondía "Usar otra vez la cierra";
  ahora la opción vale también con cierre automático, y al volver de 'cerca' a 'usar' se quita ese 1.
- v0.21.2: (Miguel) con palanca de temporizador el aviso "Abrir" salía mientras la puerta aún se cerraba (o esperaba a
  que el jugador saliera del hueco): textoUsar/usar solo actúan con la puerta QUIETA (k === meta).
- v0.22.0 FASE 5 · parte 3: ⬚ DISPARADOR (entidad 'disparador', caja 1×1×1 × escala, solo se ve en el editor):
  cuando 'una' | 'cada' (espera) | 'entrarSalir' (al salir ejecuta acciones con on=false); quien jugador | enemigos |
  todos (enemigos a 10 Hz); activo + canal (escucha: on enciende / off apaga); acciones 'disOn' / 'disOff'.
  Inspector: editarAcciones() común a palancas y disparadores; avisos (⚑ dentro de la zona, apagado sin quien lo encienda).
  Memoria: disparadores {usado, activo}. Campo de pruebas: "Entrada de la arena" muestra el marcador de la salida.
  0,0006 ms/cuadro. Siguiente: parte 4 plataformas / elevadores (piezas móviles + llevar al jugador encima),
  parte 5 puzles (varias palancas, matar a todos, objeto clave en pedestal). Antes: revisar el generador de terrenos.
- v0.23.0 FASE 5 · parte 5 (puzles): 🏺 PEDESTAL (entidad 'pedestal': objeto que encaja, gastar, sePuedeQuitar,
  acciones; al quitar deshace; "Examinar" sin el objeto → "Aquí encaja: X") y ⚙ CONDICIÓN (entidad 'condicion', solo
  editor: modo todas|alguna, unaVez, requisitos REQUISITOS = palanca on/off, pedestal on/off, enemigo muerto (jefe),
  arena (aparecedor fase 'fin' y sin vivos), todos (agresivos vivos = 0), disparador usado, puerta abierta/cerrada;
  se evalúa 4 veces/s y al momento tras palanca/pedestal; si no es unaVez, al dejar de cumplirse → acciones off).
  Líneas VERDES requisito → condición. Objeto de serie ob_gema (tipo clave). Memoria: pedestales {puesto},
  condiciones {cumplida, hecha}. Campo de pruebas: sala del tesoro (gema en el fondo de la piscina → pedestal →
  puerta 'arriba'), "Arena superada". FALTA de la Fase 5: parte 4 plataformas / elevadores (va con el generador
  de terrenos: elevadores de la mazmorra).
- v0.23.1: Campo de pruebas · Nivel 2 rehecho: sala con muros, el portal de vuelta en una cámara con reja ('arriba',
  mecanismo); puzle de combinación con 3 palancas (lados encendidas, centro apagada; la del centro empieza encendida),
  cada una enciende su luz; ⚙ "Combinación" (unaVez) abre la reja, avisa y muestra el marcador del portal; cartel con la pista.
- v0.24.0 FASE 5 · parte 4 + GENERADOR DE TERRENOS v2.48 (revisado: sin CDN, origen fijo, mallas por material en
  orden, líquidos solo superficie, deco_, marcadores con userData.forja, 📤 Enviar, editar). OJO: solo el tipo
  "Mazmorra" (mazmorra2) y el "Mapa de sectores" emiten marcadores; "Instancia" (el viejo) no.
  ⇅ PLATAFORMA (entidad 'plataforma': modo pisar|vaiven|mecanismo, dx/dy/dz, tiempo, espera, volver, tamaño;
  pieza móvil = el objeto de la entidad; fuera del mundo fijo; lleva al jugador y enemigos sumando el delta;
  acciones platIr/platVolver/platAlt/platOn/platOff; memoria plataformas {k, encendida}). Acción 'matar' (cantidad).
  fisica: mallas deco_ no chocan. apps.js: APPS_EDITAR por userData.forja.app (forja-terrenos → Entorno de Niveles,
  forja-sonidos, personajes por defecto) + textoEditar(). editor/marcadores.js: "🏷 Convertir en entidades" en el
  inspector del modelo (carpeta hija del modelo, ent.deMarcador = id del marcador; "Actualizar" solo recoloca y añade;
  ent.marcadores='convertidos' → escena.crearObjeto quita el grupo «marcadores» del GLB). Mapeo: inicio (pasa a
  principal), llegadas, luz, munición/salud/armadura/arma/secreto, llave_* → objeto llave en la biblioteca
  (ob_<id>), puerta (llave, secreta → mecanismo sin marco), botones (abren lo de "abre"), enemigos (cr_<criatura>,
  emboscada/enjaulado/francotirador → quieto, jefe), elevador → plataforma pisar, teletransporte → salida a la misma
  escena con su llegada, salida, zona_muerte → disparador 'matar', marcador_brujula, aparecedor.
  Mazmorra real de prueba: 213 marcadores → 180 entidades, 62 puertas móviles, cuadro 4,8 ms, mecanismos 0,002 ms.
  Pendiente (pedido al otro Claude): dirección del jugador_inicio, qué significa disparador_arena (32 sin convertir).
- v0.24.1 (respuestas al Claude del terreno, v2.49 probada): MATERIALES POR NOMBRE (assets.js claveMaterial =
  'n:<nombre>' si es único en el modelo, si no la posición; migrarMateriales pasa los viejos una vez;
  guardarConfigMaterial / borrarConfigMaterial). Recogibles de marcadores con radio 1,2 (baldas). 📦 BAÚL con modo
  'compartido' (RE) | 'premio' (Mecanismos.cofres: se abre una vez, da contenido[] con recogibles._aplicar, tapa con
  bisagra; memoria cofres). Marcador 'cofre' → baúl según proyecto.ajustesMarcadores.cofres (elige el creador en el
  inspector del modelo). Puerta 'mecanismo' con avisoMecanismo (false = sin aviso; los muros secretos lo llevan:
  si no, se delataban). v2.49: jugador_inicio con angulo → aparece mirando a la primera puerta. Campo de pruebas: cofre.
  Siguiente: PAQUETE DE TRAMPAS (trampilla, trituradora con daño al aplastar, lanzaclavos) + disparador_arena.
- v0.25.0 RECETAS (lado del editor): motor/generadores.js (F.Generadores: leer, generar con caché en memoria,
  obtener 'app@n' de window.FORJA_GENERADORES o del código guardado en proyecto.generadores[clave]; la receta entera
  queda en el userData.forja.estado del nodo raíz → "Editar en la app" le devuelve la receta). assets.js: nombre
  *.receta.json = tipo 'modelo' que se genera (a.esReceta, a.faltaGenerador, a.infoReceta); regenerarRecetas()
  tras cargar el proyecto (el editor carga assets antes que el proyecto). editor.js: al importar una receta copia
  el bloque <script id="forja-generador"> de la app en Apps (Ed.Apps.codigoGenerador) al proyecto. El juego
  exportado trae proyecto.generadores (arranque.js usarProyecto antes de deserializar). Inspector: "🧾 Receta" con
  ms, triángulos y peso. Probado con una app de juguete: 0,2 KB, 5 ms, convertir marcadores, jugar, recargar y
  juego exportado. editor-completo ahora se llama editor-completo-v<versión>.html (empaquetar borra los anteriores).
  Pendiente: caché en IndexedDB si los niveles reales tardan; medidor de peso al exportar; paquete de trampas.
- v0.26.0 (terreno v2.51 con recetas, probado: receta 6 KB vs GLB 1087 KB, mismos triángulos, 250-650 ms en
  swiftshader). ARENAS: acciones nuevas 'bloquear'/'desbloquear' (puerta encerrada: nada la abre, ni jugador ni
  cerca ni canales; al liberar vuelve a como estaba con antesAbierta; memoria), 'despertar' (enemigos.despertar:
  sabe dónde estás y va a por ti), 'condOn'/'condOff' (condición.activa: apagada no se revisa). Marcador
  disparador_arena → disparador 'una' (bloquea sus puertas, despierta sus enemigos, enciende la condición de la
  sala, apaga las otras entradas) + una condición por sala ('arena_sala_N', apagada; todos sus enemigos muertos →
  desbloquear). Juego exportado: generadores solo los usados y en gzip+base64 (proyecto.generadoresGz,
  Generadores.empaquetar/desempaquetar con CompressionStream): 1,46 MB → ~0,55 MB.
- v0.26.1 AGUA POR PISOS: el agua contaba "dentro" hasta 40 m bajo su superficie → un lago del piso 2 mojaba la sala
  del piso 1. Ahora agua.en() corta en el primer suelo bajo la superficie (_fondo: rayo contra la colisión una vez por
  sitio, cacheado en v.fondos; 0,3 m de margen). Vale para líquidos de modelos y cajas 💧. Reproducido y probado.
- v0.26.2 EMPUJÓN ENTRE PLANTAS (reporte de Miguel, su Nivel 3): enemigos._separar solo miraba que el jugador
  estuviera por debajo de la cabeza del enemigo → un demonio del piso 2 (y 3,9) empujaba 0,5 m al jugador del piso 1
  (y 0). Ahora exige solape vertical (P.y + altura del jugador > pie del enemigo + 0,2); la separación entre enemigos
  ignora a los de otra planta. Misma planta: sigue empujando (0,55 m).
- v0.26.3 INSPECTOR: Posición con su ↺ (como rotación y escala; va a 0,0,0); el "↺ Por defecto" de la cabecera
  sigue conservando la posición (lo dice el aviso). Pasos: posición 0,1 en el campo. Gizmo: con imán 0,25 m · 15° ·
  0,1; sin imán 0,1 m · 1° · 0,05 (antes libre con 3 decimales); Shift mientras arrastras = fino (0,01 m · 0,5°).
  Posición guardada con 2 decimales.
- v0.27.0 OPTIMIZACIÓN (F0, F1, gestor) + TRAMPAS.
  F0: depuración (tecla depurar) con ms por sistema (Rendimiento.medir/textoSistemas), materiales y programas, y
  el resumen del gestor. F1: Render.matRetro(color, opciones) = materiales COMPARTIDOS (userData.compartido) en
  figuras de puertas, palancas, pedestales, cofres, plataformas, salidas, enemigos del motor; enemigos con modelo
  comparten los del asset y solo durante el destello llevan copia propia (enemigos._destello). Nivel 3: puertas
  216→58 materiales, enemigos 34→3. GESTOR (motor/gestor.js, juego.gestor): junta los marcos de puerta en una malla
  por material (156 piezas → 1), oculta con la CAPA 7 (no toca .visible) lo lejano (ajustes.distObjetos, 0 = la de
  dibujo) y lo tapado (5 rayos contra el BVH de la cámara al objeto, por trozos: cada cosa ~4 veces/s), y marca
  E.tapado en enemigos (no se dibujan, piensan y se animan menos). Ajustes en Render ▸ Optimización (juntarQuietos,
  ocultarTapado, distObjetos, distEnemigos = antes 25/50 fijo). Probado píxel a píxel en 72 vistas del Nivel 3:
  imagen igual (peor 0,03 %) y draw calls 86 → 32 de media.
  ⚠ TRAMPAS (entidad 'trampa', Mecanismos.TRAMPA, figuraTrampa; piezas móviles en el BVH): trampilla (pisar o
  mecanismo, retraso, cerrarTras, danoFoso por s), trituradora (bajar/subir/esperas/desfase, dano al aplastar con
  origen 'aplastar' que ignora la invencibilidad; también a enemigos), lanzaclavos (cerca/siempre/mecanismo,
  cadencia, clavos reutilizados ≤40, chocan con paredes). Acciones trampaOn/Off/Disparar, canal, memoria trampas.
  Marcadores trampa_* → trampas: tamaño de trampa_pieza; el generador NO manda recorrido ni dirección (solo los usa
  dentro): se deducen con rayos contra el nivel (suelo bajo la trituradora; la pared más cercana detrás del
  lanzaclavos). Pedido al otro Claude que los mande (encargo_terrenos_v252.txt).
- v0.27.1 (Miguel: 150→168 fps, poca mejora y pop-in feo; embestida lo dejaba pegado a la pared).
  Gestor sin pop: 4 ojos (cámara, cámara + velocidad·0,4 s, ±0,7 m a los lados; si cualquiera ve, se dibuja), lo
  que está a menos de 10 m nunca se esconde, esconder pide 2 revisiones seguidas tapado, revisión completa al abrirse
  una puerta o saltar la cámara > 3 m, objetos cada ~10 cuadros y enemigos cada 4. Medido paseando 3.800 cuadros
  por el Nivel 3: cuadros con algo escondido que debía verse 57→8 (objetos) y 22→9 (enemigos); coste 0,19→0,67 ms
  (swiftshader). Enemigos._separar: el empujón jugador-enemigo ya no mete al jugador en la pared (rayos a 0,3 y 1 m;
  lo que no cabe lo retrocede el enemigo y una embestida se corta). PENDIENTE: que Miguel pase la línea de
  depuración (ms por sistema y GPU) de su PC para saber qué limita de verdad los 168 fps.
- 📁 CARPETA DEL PROYECTO EN EL PC (desde v0.28.0): C:\Users\migue\Documents\Videojuegos\Claude\Forja de juegos actual
  (la vieja "forja-juegos" la borra Miguel). Ahí van los commits; los editor-completo a Claude\Respaldos\Editores y los
  zip a Claude\Respaldos. Su juego\datos.js no se pisa nunca.
- ⚠ Miguel abría el editor-completo.html VIEJO (v0.24.1, sin número) de la carpeta forja-juegos: por eso "volvieron"
  el empujón y el agua y la optimización no hacía nada. Desde v0.27.1 empaquetar.js deja el editor completo en
  ../Respaldos/Editores (fuera del proyecto); en forja-juegos solo la versión de carpetas. Sus capturas de depuración
  sin "ms:" ni "materiales" = versión vieja.
  Su PC con TODO al máximo (resolución nativa, sombras 2048, 16 luces, auras 2): CPU 4,5 ms, GPU 6,5 ms → el límite
  es la GPU = las LUCES por píxel (cada malla mira hasta maxLuces luces en cada píxel). Plan: luz por vértice (Gouraud
  PS1) opcional, menos luces por objeto, sombras más baratas.
- v0.28.0 LINTERNA, INVENTARIO, ENEMIGOS (élite).
  🔦 jugador/modulos/linterna.js (F / R3, botón táctil): SpotLight siempre en la escena (apagada = intensidad 0, sin
  recompilar), retraso al girar, sombras opcionales, batería opcional (duración, carga inicial, parpadeo; barra LUZ;
  recogible 'bateria' + preajuste 'pilas'; se guarda en pj.linterna). j.linterna {on,pos,dir,alcance,angulo,veEnemigo}:
  los enemigos (c.veLinterna) te ven a 1,6× su visión y, si los alumbras, aunque no miren.
  🎒 Mochila: ordenar (botón / R; junta pilas y ordena por tipo), mover (acción, casillas), objetos al empezar
  (proyecto.inventarioInicial [{k:'obj'|'mun', id, n}], Juego ▸ Objetos), examinar con el modelo real (su ficha, o el
  del recogible del mapa que lo da, o la figura del recogible para armas/munición). Combinar ya existía (recetas).
  ☠ Oleadas guardadas (enemigos.estadoOleadas → est.oleadas; a medias se repite la que iba, terminadas siguen
  terminadas; también en la memoria de niveles). Ruta de patrulla en el editor (línea amarilla al seleccionar un 📍,
  un enemigo con patrulla o un aparecedor con puntos). Botín: suelta/suelta2/suelta3 con su probabilidad, preajustes
  u objetos de la mochila 'obj:<id>' (cantidad). TÁCTICA ÉLITE: escudo (absorbe, destello azul, recarga tras
  escudoEspera), esquiva lateral (al verse apuntado — sin rayos — o al recibir daño; 1 rayo para no chocar), cubrirse
  al romperse el escudo (≈30 rayos solo entonces: punto al que llega y desde el que no lo ves; estado 'cubrirse'),
  paso lateral al disparar. Criatura de serie 'elite'. Coste medido 0,02 ms/cuadro.
- v0.28.1 💡 LUZ POR VÉRTICE (Render ▸ luzVertice, de serie sí): render.js hacerRetro quita del fragment el bucle de
  las luces de PUNTO (chunk lights_fragment_begin recortado) y las calcula en el vertex (lights_pars_begin tras
  <common>, getPointLightInfo con transformedNormal, varying vLuzPV); sol, ambiente y focos (linterna) siguen por
  píxel. customProgramCacheKey con '-pv'; Vista.aplicar recompila al cambiar. Nivel 3 de Miguel, 16 luces, sala con
  antorchas: render 5,6 → 2,0 ms. Pega: en paredes grandes de pocos vértices se pierde el foco alrededor de la
  antorcha (PS1 real). Mejora futura: que el generador parta las caras grandes (≈2 m) para que la luz por vértice
  tenga dónde pintar.
- v0.29.0 (Miguel: con luz por vértice 118 → 181 fps en el mismo punto).
  🔥 HORNEADO (motor/horneado.js, Render ▸ hornear, de serie NO): al empezar a jugar, color por vértice en modelos sin
  animación, cubos, suelos, rampas y escaleras = ambiente + hemisferio + sol + luces de punto (fórmula de three r160:
  I = fuerza·π·alcance/2, caída decay 1 con corte, /π) con rayos de sombra al BVH (se ignoran los últimos 0,8 m: la luz
  suele estar dentro de su lámpara). Esas mallas pasan a MeshBasic retro con vertexColors (geometría clonada; se
  restaura al detener). No se hornean luces tocadas por acciones luz*, apagadas o con parpadeo > 0,5. El sol deja de
  proyectar mientras está horneado. Caché en memoria por escena + luces. Nivel 3: 31.411 vértices, 40.174 rayos,
  ≈250 ms; render 2,0 → 1,4 ms (vs luz por vértice). Diferencia de aspecto: lo horneado tiene sombras de verdad (la
  luz en vivo atraviesa paredes); queda algo más oscuro.
  ⚫ manchasEnemigos (de serie sí): sombras de mancha de todos los enemigos en UNA InstancedMesh (128), sin rayos
  (suelo que ya conocen). 🌟 aurasSinLuces: auras aunque "Luces y sombras" esté apagado. Recetas de personajes:
  assets.js usa r.escena.animations (lo pidió el Claude de personajes). Probado y DESCARTADO: congelar matrices
  (matrixAutoUpdate=false) — 0,39 vs 0,41 ms, three recorre el árbol igual.
  Apps nuevas guardadas: entorno-terreno-v2_52 (manda recorrido/dirX/pinchos en las trampas), forja_personajes v0.31
  (receta 'forja-personajes@1'; clips nuevos stab2/3, spear2/3, axe2/3, attack2/3; aim_pistol/rifle/knife solo
  torso y brazos para mezclar encima de la locomoción; mira a +Z). PENDIENTE: encadenar los combos nuevos, mezclar
  las posturas de apuntado, y pedir al de terrenos partir caras grandes (~2 m) para el horneado.
- v0.29.1 (Miguel: con horneado el punto que daba 118 → 181 → ≥260 fps).
  ✦ Auras: haloForma 'circulo' | 'estrella' (luz y material emisor luzHaloForma; dos texturas fijas, nada procedural).
  🔦 Linterna: modo 'imagen' (div con radial-gradient y mix-blend-mode:screen, sin SpotLight; tamImagen) y en 3ª
  persona apunta del pecho al punto de la mira (rayo de la cámara), no paralela a la cámara.
  🎯 Apuntado 3ª persona (modelo.js): _prepararApuntado copia cada clip de locomoción SIN los huesos de las aim_*
  ('<clip>#piernas'); al apuntar / tras disparar se reproducen piernas + aim_pistol|rifle|shoulder (fallbacks hombro→
  rifle→pistola). Arma: postura3p (auto por nombre/tipo/perdigones/automática | pistola | rifle | hombro | ninguna).
  Disparo: shoot_pistol|rifle|shoulder si el modelo los trae (pedidos al Claude de personajes); si no, retroceso
  procedural (giro de Chest y UpperArm_R/L hacia atrás sobre el eje derecho del personaje). Cuerpo a cuerpo:
  golpe3p (slash/stab/spear/axe/attack) y combos de hasta 3 (stab, stab2, stab3…).
  Partir caras grandes (medido en su Nivel 3): 18.221 tris → 30.601 (3 m) / 53.131 (2 m). Encargos:
  Encargos/encargo_terrenos_v253.txt (detalle de luz) y encargo_personajes_v032.txt (aim_shoulder, shoot_*).
- 📁 CARPETAS (desde el 12 oct): ESTABLE = Claude\Forja de juegos actual (solo se toca cuando Miguel aprueba una versión).
  EXPERIMENTAL = Claude\Forja de juego Experimental (aquí se copian SIEMPRE los cambios nuevos). Editores completos en
  Respaldos\Editores con sufijo: editor-completo-vX-experimental.html / -estable.html. Zips en Respaldos\Forjas
  (forja-juegos-vX-experimental.zip / -ESTABLE.zip). Versiones rechazadas: Respaldos\No aprobados.
- v0.42.0 (experimental) 📚 CAPÍTULOS: escena.capitulo (botón 📚 junto al selector de escenas; se conserva en
  normalizarProyecto); acción de menú 'capitulos' (p_capitulos: agrupa niveles por capítulo en el orden de la lista,
  elegir = partida nueva en su primer nivel; bloqueado hasta llegar si menus.capitulos.bloquear !== false; alcanzados en
  localStorage forja-capitulos-<proyecto> al 'juego-iniciado'). ▲▼ ordenan niveles. Acción 'borrar' (ranuras modo borrar
  con confirmación → F.Partidas.borrar). Selector de escenas muestra [capítulo].
  PENDIENTE JUEVES (elegido por Miguel): editor con PESTAÑAS A LA IZQUIERDA (Escena: entidades por tipo con nombre y
  buscador · Niveles · Archivos; derecha Inspector/Jugador/Juego) + las 3 optimizaciones: enemigos en lote con animación
  horneada en GPU, IA/física en Web Workers, distancia "cerca" ajustable (Miguel: 105 enemigos GLB, 75 cerca, enemigos
  2,18 ms, render 3,29 ms; CPU-limitado, la GPU espera).
- v0.41.5 (experimental) F3 barato: texto 4 veces/s (antes se armaba y pintaba cada cuadro: 255 → 113 fps al abrirlo) y solo se reescribe si cambia; consultas de tiempo de GPU solo con F3 abierto.
- v0.41.4 (experimental) GESTOR por tiempo: objetos ~5/s y enemigos ~6/s (antes n/10 y ne/4 POR CUADRO: a 137 fps cada
  enemigo 34 veces/s con hasta 11 rayos; en el nivel de Miguel 1,45 ms con 88 enemigos). Sin arrays nuevos en _tapado.
  F3: "fps posibles" como rango 1000/(cpu+gpu) – 1000/max(cpu,gpu) (Miguel: 137 reales con 178 "posibles").
  REGLA: todo lo que se reparte "un poco cada cuadro" debe ir por TIEMPO (dt), nunca por cuadros.
- v0.41.3 (experimental) Lotes de recogibles con esfera de recorte (antes frustumCulled=false: se dibujaban siempre).
  Medido campo de pruebas vs 0.40.4 (2 pasadas): render igual o mejor; ENEMIGOS DEL NIVEL 1 con PICO INTERMITENTE de ~4 ms
  en AMBAS versiones (a veces 0,4) → investigar el jueves (¿visión/camino de algún enemigo o aparecedor?).
- v0.41.2 (experimental) F3: tiempos por sistema (+ recogibles, tactico, clima, hud, agua) y línea "entidades" (enemigos
  cerca/medio/dormidos/se ven, recogibles activos/lotes, partículas, luces vivas) — juego._conteo() cada 0,5 s. Destello de
  daño COMPARTIDO: enemigos._flashMats (una copia roja/azul por material original, reutilizada; antes se clonaba y tiraba
  en cada golpe). Orillas: lateral colgado corregido (D = derecha mirando a la pared).
- v0.41.1 (experimental) OPTIMIZACIÓN: enemigos piensan por niveles EN TIEMPO (cerca y activo/viéndote 8/s · cerca
  tranquilo 4/s · media o tapado 2/s · lejos duerme), repartidos (tPensar aleatorio); animación a ritmo fijo 30/s cerca,
  15/s media, nada fuera de cámara (antes por cuadros: a 300 fps animaba 300/s). Recogibles: _juntar() → InstancedMesh
  por forma+material y Points por aura (≥3 iguales), matrices = base fija × giro (sin recorrer padres). Medido en la misma
  pasada vs 0.40.4: 100 recogibles 196→4 dibujos, CPU 2,55→1,47 ms, 36→42 fps; 10 enemigos atacando lógica 1,08→0,81 ms.
- v0.41.0 🧗 Módulo ORILLAS (jugador/modulos/orillas.js, orden 14, apagado de serie): en el aire, empujando adelante,
  3 rayos (pared al pecho, borde hacia abajo desde manos+alcance, sitio arriba) → agarre. Modo 'colgar' (TR: 0,3 s colgado,
  saltar/adelante sube, atrás/agachar suelta, lateral por el borde revalidando) o 'auto' (Doom Eternal). Usa j.trepando
  (sin gravedad/movimiento) + j.colgado (modelo: 'hang' o climb parado) + j.mirarEscala.
  Calcomanías: sangre SOLO en enemigos (E.objetivo.esEnemigo); objetos con Vida → agujero pegado al objeto (obj.attach);
  'objetivo-roto' esconde las calcomanías sobre lo roto; 'puerta-abierta' las pega a la pieza (hoja) que tocan;
  tactico.explosion emite 'explosion' → quemadura. Marcas recicladas vuelven a la escena (escena.attach).
  RENDIMIENTO medido (swiftshader, hornear): base 114 fps 2 dibujos · 10 enem 100 · 30 enem 85 (25 dibujos, lógica 0,24 ms)
  · 30 lejos 94 (ya se recortan) · 10 atacando 59 (CPU 0,74 ms: el coste NO es lógica → efectos/DOM, investigar) ·
  100 recogibles 54 fps, 196 dibujos (2 por recogible) = lo más caro → instancias.
- v0.40.4 Escopeta: solo 3 agujeros por disparo (los 3 primeros perdigones en pared, ×0.65). Arreglo viejo: la marca de bala usaba s.v1 (dirección del disparo) en lookAt y desviaba los perdigones siguientes contra paredes.
- v0.40.3 Calcomanías con vectores propios (cdir/cn/cm): usaban s.v1-v3 del disparo y desviaban los perdigones siguientes de la escopeta.
- v0.40.2 Mapa = acción de menú 'mapa' (botón en Pausa de serie; se añade en Juego ▸ Menús). Sin partida en marcha avisa.
- v0.40.1 Partículas: tope de tamaño en pantalla (12% del alto) y se desvanecen pegadas a la cámara (menos sobrepintado).
- v0.40.0 (sobre la 0.38.2 estable; las 0.39.x del otro chat están en Respaldos/No aprobados).
  ✨ Entidad 'particulas' (motor/particulas.js): humo/chispas/fuego/polvo, un Points por emisor, movimiento en el vertex
  shader con uTiempo y semilla por punto (cero CPU), tamaño en px con uAltoPx (getDrawingBufferSize), cuadradas PS1.
  🩸 Calcomanías (armas): grupo fijo de 24 recicladas, sangre detrás del herido (rayo en la dirección del disparo; si no,
  al suelo) y quemadura bajo la explosión. Props armas calcomanias / colorSangre. 🗺 Mapa en el menú de pausa (p_mapa):
  lienzo 2D dibujado una vez desde los triángulos de colisión cerca de la altura del jugador (suelos rellenos, paredes en
  líneas) + marcadores visibles de la brújula + flecha del jugador. F.juegoActual = juego en marcha.
- v0.38.2 Armas a dos manos: hacia la otra mano SOLO apuntando (al caminar las manos se cruzan y el arma giraba).
  Antorcha en 1ª persona en el primer plano (pp de la vista, j.antorchaPP → armas mantiene pp.activo), mano izq. con vaivén.
- v0.38.1 3ª persona: retroceso procedural ya no se acumula (se deshace lo puesto el cuadro anterior si la animación no
  tocó el hueso; tope 0,3 rad). Armas a dos manos (_dosManos: rifle/hombro/automática/escopeta/rayo/proyectil): el cañón
  va de la mano del gatillo a la otra mano si está delante (aim_rifle); si no, sigue al antebrazo. Antorcha pegada a la
  mano libre (j.alColocarAntorcha, lo llama Modelo tras animar, igual que las armas). Maniquí base con hand_L.
- v0.38.0 ⚡ ARMA DE RAYO CONTINUO (tipo 'rayo', del beam_emitter.gd del FW: el QUÉ): 1-3 haces en abanico (eje = arriba
  de la cámara), 1-3 capas (núcleo/cuerpo/halo, cilindros de 6 lados aditivos reutilizados), dano = por segundo en golpes
  de 0,12 s repartido entre haces, consumo munición/s, duracionMax + recuperacion (proporcional al soltar), orbe en el
  cañón, zumbido sintético o sonido del arma en bucle, emite 'disparo' cada 0,5 s. HUD ♨ al enfriar. En 1ª persona
  grosor ×0.4. Paquete de armas: + Rifle de asalto (automático, postura rifle) + Rayo de energía + munición Energía.
  🔥 Linterna modo 'antorcha': uLinEsfera en render.js (luz alrededor por distancia, bandas PS1, alumbra lo horneado),
  temblor del flashlight_module.gd (3 senos + bajones), palo + llama en la mano izq., batería = combustible (HUD FUEGO).
  Cache retro-v4.
- v0.37.2 Gas: el inspector reconstruye la figura al cambiar superficie / nube / nubeOpacidad / nubeTramado (antes no
  hacía nada). AGUA.nubeTramado: nube opaca con descarte Bayer 4×4 en pantalla (transparencia por tramado PS1,
  sin mezcla ni doble pintado).
- v0.37.1 Horneado según el clima: F.Clima.porPartes(escena) = clima && (ciclo || lluvia != 'no' || alguna acción
  lluviaOn/lluviaOff/hora/rayo). Si no: horneado clásico a la hora elegida (vistaPrevia antes de hornear; lámparas
  soloNoche se hornean solo si esa hora es de noche, F.Clima.esNoche).
- v0.37.0 🌦 CLIMA (motor/clima.js, Escena ▸ Ambiente ▸ grupo Clima; apagado = no se crea nada). Hora 0-24 con
  4 paletas mezcladas (día = colores de la escena; amanecer/atardecer/noche editables, claves climaAma*/climaTar*/
  climaNoc*), recalculo a 4 Hz. Horneado POR PARTES si hay clima (una pasada): color = ambiente + lámparas fijas,
  aClima (sol·sombra, cielo/suelo), aLamN (lámparas luz.soloNoche); F.Clima.prepararMaterial inyecta en color_vertex
  vColor = color + mix(uClSuelo,uClCielo,y) + uClSol·x + aLamN·uClNoche. Charcos (CL_CHARCOS) en caras hacia arriba
  con uClMojado. Lluvia: LineSegments 600 que caen en la GPU alrededor de la cámara, techo por rayo hacia arriba cada
  0,3 s, color oscurecido de noche, sonido de lluvia y trueno sintéticos (F.Audio.contexto). Rayo: destello por
  cuadros + trueno retrasado. Gotas en pantalla (DOM). Acciones lluviaOn/lluviaOff/rayo/hora (a.hora).
  Vista.aplicar llama F.Clima.vistaPrevia (el editor muestra la hora) y resetea el color del hemisferio.
  Gas: AGUA.nube / nubeOpacidad → cubo translúcido del color que respira (sin superficie). Plantilla N3 con clima.
- v0.36.1 Plantilla Campo de pruebas: el portal del Nivel 2 lleva al NIVEL 3 "El bazar del páramo" (guía NPC que
  explica y abre la puerta del foso, tienda BAZAR con escopeta/munición/vida/armadura, 10 monedas + bolsa al final
  del pasillo de gas, 4 barriles junto a 2 zombis, foso con paredes para correr y escalera para salir, salida
  '__fin__' → victoria; misión: ★ salir, ★★ todas las monedas, ★★★ matar a todos). Botón "Misiones" en el principal
  con alTerminar 'seguir'. Correr por paredes y Asomarse activos en la plantilla. Inspector: 'moneda' en recoger.
- v0.36.0 🪙 Recogible tipo 'moneda' (j.monedas, presets moneda / bolsaMonedas, figura de moneda, viaja y se guarda
  en pj.monedas; contador .ft-monedas en el HUD si el nivel tiene tienda o monedas). 🏪 Entidad 'tienda' (tactico.js:
  articulos {que, ref, cantidad, precio, stock 0=∞}; menú congelado; compra con recogibles._aplicar(r, true) y sigue
  abierto; emite 'compra'). 🗣 Entidad 'npc' (figura de pie o modelo; nodos {texto, opciones {texto, siguiente '' |
  índice, acciones (mecanismos.ejecutar)}}; se gira hacia ti; _abrirMenu admite texto). Inspector: pintarTienda,
  pintarNpc (editarAcciones por respuesta). 🧗 Módulo CORRER POR LAS PAREDES (correrpared.js, orden 28: en el aire +
  adelante + pared a un lado (rayo lateral, normal de M.nor[k]) → avanza por la pared, gravedad fuera (j.enPared),
  máx. duración; Saltar = impulso fuera/arriba (j.saltoDePared lo consume Salto); ladeo de cámara). Probado todo.
- v0.35.0 ☠ Zona de peligro = líquido 'veneno' (superficie:false → no se dibuja, nadable:false, daño 'veneno' de
  ambiente, tinte verde dentro). Campo nuevo AGUA.superficie. 🛢 Primitiva 'barril' (cilindro radio/alto) con
  ent.explota (radio) y ent.danoExplosion: Juego.romper → tactico.explosion + daña a otros rompibles en el radio con
  retardo (cadena); cualquier rompible puede explotar (Inspector). 🗺 MENÚ DE MISIONES (menus.misiones: título,
  bloquear, soloConMision, alTerminar menu|seguir; acción de botón 'misiones'; p_misiones: "n. Nombre ★★☆", 🔒 si el
  anterior no está en 'forja-hechos-<proyecto>', borrar progreso con doble pulsación). misiones.final guarda
  hechos. Niveles.viajar: tras la puntuación, con alTerminar 'menu' y botón Misiones en el principal → emite
  'partida-misiones' → Partida vuelve al menú de misiones.
- v0.34.1 Salida con destino '__fin__' (🏆 Fin del juego): Niveles.viajar → misiones.final(ent) → 'partida-fin' (victoria).
  Plantilla Campo de pruebas: el portal del Nivel 2 ahora acaba el juego (puntuación → Juego completado).
- LISTA DEFINITIVA FW (11 oct): Claude/lista_pendientes_FW.txt. Falta: enemigos AdvEnemy (salto ataque, órbita,
  retirada, combos, híbrido, bordes, territorial), menú de misiones/selección de nivel con estrellas y bloqueo,
  barril explosivo, zona de peligro, NPC con diálogo, tienda+monedas, cinemáticas, lluvia/día-noche, wall run, rayo
  continuo, indicador de objetivo, límite de antorchas. FW completo en scratchpad/fw/Framework (127 .gd).
- v0.34.0 🙇 Módulo ASOMARSE (jugador/modulos/asomarse.js, orden 13, acciones asomar_izq Z / asomar_der X; corre la
  cámara de lado con rayo contra la pared y ladea en 1ª persona; j.asomado). 🔊 SONIDOS COLOCADOS (motor/sonidos.js,
  entidad 'sonido': asset, volumen, cerca, radio, bucle o cada X-Y s, encendido; acciones sonOn/sonOff; Audio.fuente
  = HTMLAudio → MediaElementSource → StereoPanner → Gain; volumen ∝ distancia², lado según la derecha de la cámara;
  fuera del radio se pausa). 🏆 MENÚ VICTORIA (menus.victoria: título, tiempo, estrellas = suma de mejores marcas de
  las escenas con misión, rango por tiempo "S:300, A:480, B:720" + rangoPeor; botones propios). Sale con la acción
  'victoria' o 'mision' sin destino ('partida-fin' → Partida.victoria; con ▶ Jugar sin menús: aviso y vuelve).
  Probar: Juego ▸ Menús ▸ "Victoria". misiones.js: clases CSS fm-* → fmi-* (chocaban con .fm-sub de menus.js).
- v0.33.3 Misiones: objetivo 'rescatar' miraba h.rescatado (no existe) → h.estado === 'rescatado'. ESTRELLAS
  INDEPENDIENTES (Miguel): cada una se gana con todos sus objetivos, fallar ★ no quita ★★/★★★; misiones.ganadas
  [3 bool]; una estrella sin objetivos se gana al acabar. Proyectos: 🗑 en cada tarjeta (raiz.removeEntry recursivo,
  doble confirmación; si era el abierto queda sin carpeta) y casilla "Mostrar al abrir el editor" (localStorage
  'forja-proyectosAlIniciar', de serie sí): la ventana de proyectos sale primero.
- v0.33.2 Arreglos: (1) pantallas de misión: el ratón no volvía a bloquearse → se cierran en el propio keydown (gesto
  del usuario; pointer lock solo se concede así), no desde el bucle del juego. (2) tactico.detener devuelve las figuras
  del editor a su estado (puertas tácticas, rehenes, bombas, carga C2): al volver a probar seguían abiertas / movidos.
- v0.33.1 Plantilla "Campo de pruebas" ▸ Nivel 2: anexo táctico al este (puerta táctica en el muro x=9,2; sala A con
  guardia de espaldas, rehén liberar, altillo con escalera de mano; sala B tras puerta cerrada, bomba de cables que
  arranca al entrar + cámara por disparador, 2 guardias, altillo con cuerda y bomba de mantener, rehén escolta →
  extracción junto al inicio; 3 cámaras fijas; cartel; misión "Operación Rescate" con 6 objetivos). Doble salto y
  Sigilo activos en la plantilla. ARREGLO: normalizarProyecto perdía escena.mision al cargar/guardar.
- v0.33.0 🧍💣🚧 TÁCTICO (motor/tactico.js, juego.tactico = juego.rehenes; se crea ANTES de Mecanismos porque sus
  hojas van en alMundo como piezas móviles). Entidades: 'rehen' (modo liberar|escolta, extraccion = id disparador,
  vida, perderMision; figura de rodillas, se levanta escalando el torso; sigue a 1,8 m con rayo de pared y suelo; se
  queda si te alejas >18 m; los enemigos en atacar/anticipar cerca le dañan), 'bomba' (cuenta atrás, activa o acción
  'bombaOn'; desactivar mantener N s | cables 2-4 con bueno fijo o al azar, fallo explota|acelera a 5 s; explosión en
  área a jugador/enemigos/rehenes, canal/canalExplota, perderMision → 'mision-fallida' → Partida.gameOver), 'brecha'
  (puerta táctica ≠ puerta: marco fijo (userData.marcoPuerta, física como puerta) + hoja pieza móvil; menú: abrir con
  cuidado/llave, patada (ruido 0,6 + aturdir a los de detrás), C2 (opcional gasta objeto; 2,5 s; revienta: pieza
  inactiva, daño 35 + aturdir detrás + explosión 2,2 m), ganzúa (mantener), espejo (sprites rojos 6 s sobre los de
  detrás)). Revisión cada 0,15 s y solo cerca; menús congelan el mundo (tactico.bloquea), teclas 1-5/↑↓/Enter/Esc y
  mando. enemigos.aturdir(E,s). Inspector: tipos 'ent' (tipoEnt) y 'objeto' en controlEsquema. Misiones: tipo
  'bombas'; 'rehen-muerto' falla 'rescatar', 'bomba-explota' falla 'bombas'. Probado todo jugando.
- v0.32.0 ⭐ MISIONES (motor/misiones.js, F.Misiones por Juego): escena.mision {activa, titulo, briefing, imagen,
  mostrarBriefing, mostrarPuntuacion, objetivos[{id,tipo,estrella 1-3,texto,a,segundos,cantidad,que,canal}]}. Tipos:
  salir, matarTodos (no pacíficos), matarJefe, tiempo, recoger (que: todos|tipo|obj:<id>), tener, leer (interaccion
  mensaje), zona (disparador), rescatar (juego.rehenes.lista[].rescatado; evento 'rehen-rescatado'), sinAlerta
  ('enemigo-alerta' la falla), ejecutar, canal. Estrellas = N más alta con todos los de 1..N cumplidos. Briefing al
  empezar (no al cargar con pos); Juego._actualizar: misiones.bloquea → mundo quieto. Niveles.viajar: await
  misiones.final(ent) antes de irse. Acción 'mision' (🏁; después: nivel o 'partida-fin' → Partida portada). HUD:
  O = objetivos (sale solo al cumplir uno), reloj si hay tiempo. Teclas de las pantallas: keydown propio (Enter /
  Espacio / E) + botón A del mando por rAF (en un viaje el Juego no se actualiza). Mejor marca: localStorage
  'forja-estrellas-<proyecto>'. Editor: Escena ▸ ⭐ Misión y estrellas. Probado: briefing → matar → salida → ★★★ →
  Nivel 2.
- v0.31.1 📷 Cámaras: camara.activacion 'zona' (caja propia zAncho/zAlto/zLargo, centrada zDelante por delante en su
  giro horizontal y zAbajo por debajo; dibujada naranja en el editor) | 'disparador' (acción nueva 'camara' en
  mecanismos → juego.camarasFijas.activar(id)). Manda la última: entrar en una zona o la acción; al salir de la zona
  actual y estar en otra, esa. Al empezar: 'inicial' → zona donde estás → la más cercana que te ve. Las de v0.31 con
  camara.zona (id de disparador) siguen valiendo como zona. 🪢 Escalera de mano ent.forma 'escalera' | 'cuerda'
  (cilindro con nudos y lazo; trepar.js: se agarra desde cualquier lado, s.lado; A/D giran alrededor).
  Probado: inicial A → disparador B → volver a zona A; cuerda 2,1 m en 0,9 s.
- v0.31.0 📷 CÁMARAS FIJAS (motor/camaras.js): entidad 'camara' (mira a su -Z; camara {modo fija|sigue, fov, zona =
  id de un ⬚ disparador, suave, prioridad}). Jugador ▸ Cámara ▸ modo 'fija' → j.camFija, j.modoCamara='tps' (el cuerpo
  se ve), F.Camaras.Gestor elige: la de la zona que te contiene (la actual si sigues dentro) o, sin zona, la más cercana
  que te ve (rayo). controlFija 'camara' (relativo: yawMov congelado hasta soltar; el cuerpo gira y avanza: j.yaw =
  cuerpo SIEMPRE) | 'tanque' (lados giran). Apuntando: solo gira. Armas: desde el pecho hacia j.yaw + _autoApuntar
  (enemigo a <40 m, ±50°, a la vista). Interactuar y linterna usan j.yaw. Emite 'camara-corte'. Probado: corte A→B,
  relativo (W en B lleva a -X), tanque. PRÓXIMO: misiones/estrellas (objetivos por estrella, elegidos por el creador)
  → briefing → rehenes → bombas → puertas tácticas.
- v0.30.0 🦘 Salto: saltos 1-5, modoSaltos 'aire' (doble salto Doom Eternal, fuerzaAire) | 'encadenado' (triple
  Mario: saltar ≤ ventana s tras aterrizar y corriendo, cada uno ×(1+subida)). 🗡 Módulo SIGILO (jugador/modulos/
  sigilo.js, orden 49): enemigos.ejecutable(E,j,dist,ang) = no te ve y no está en anticipar|atacar|perseguir|huir|
  cubrirse, detrás en el cono de su espalda; ejecutar(E) → _morir silencioso (E.silencioso), emite 'enemigo-ejecutado'.
  Criatura: ejecutable (Inspector ▸ Percibir). Interactuar no actúa si j.blancoSigilo / j.sinInteractuar. 🪜 Entidad
  'escala' (primitiva sin colisión, params alto/ancho, frente +Z) + módulo TREPAR (orden 15, j.trepando: gravedad,
  movimiento y salto se apartan; W/S suben, arriba sale hacia -Z, Saltar suelta hacia atrás; modelo: clip climb|ladder
  y mira a la escalera). Probado: 3 saltos en el aire, ejecución por la espalda, subir 3 m y salir arriba.
- v0.29.6 🌊 Cascadas: el fallo era del EXPORTADOR del entorno de terrenos (escenaDeNivel: `if (c.liquido && n[1] < 0.5)
  continue` quitaba todo lo que no mira arriba). Hecha la v2.53 del entorno (generador 3: n[1] < -0.5, solo fuera lo
  de abajo; gen 1 y 2 intactos). Motor: _mapaAlturas ignora caras con |n.y| < 0,5 (cascadas no son superficie);
  AGUA_MODELO.aspecto 'auto' (textura del modelo → como viene; sin textura → ondas). Proyecto de prueba:
  Claude/prueba agua.forja.json (acantilado 8, hondoRio 5, hondoLago 6): 678 tris de agua, 98 de lado, se ven.
- v0.29.5: lados del agua SOLO en cajas 💧 (en lagos de modelo salían caras dentro del agua). AGUA_MODELO.aspecto de
  serie 'modelo' (como lo manda el generador); con 'motor' las caras verticales llevan UV de lado. Visto en mi_juego:
  la malla 'agua' de nivel_1 (glb y receta) NO trae caras verticales (0 de 664): la cascada no se exporta → encargo
  Encargos/encargo_terrenos_agua.txt.
- v0.29.4 🌊 Lados del agua (agua.js _lados, solo al jugar): bordes de cajas 💧 y aristas de borde de los lagos de
  modelos (soldadas al cm) → paredes de agua en trozos de 1,5 m hasta el suelo (rayo abajo, sin suelo 3 m); trozo con
  pared/orilla a 0,4 m hacia fuera (rayo) no se pone. materialLiquido propio, UV en metros. Se quitan en detener.
  Probado: estanque 4×1,5×4 con un muro → 3 lados (9 trozos). PENDIENTE subir a carpetas del PC (no conectado).
- v0.29.3: arreglo cuadro negro en auras/sprites con linterna (LIN_OK solo en superficies, normal sin NaN).
- v0.29.2 🔦 Linterna PROYECTADA (modo por defecto): uniforms uLin* en F.Render.U que lee TODO material retro
  (render.js, antes de opaque_fragment): cono con textura 32×32 sin filtro (F.Render.texLinterna: redonda | anillo |
  vieja | suave), normal plana por dFdx/dFdy (cara PS1), caída (1-d/alcance)², bandas (uLinBandas 6, prop "bandas").
  vLinMundo = modelMatrix·(instance/batching)·transformed. Lo horneado (MeshBasic) lleva uEsHorneado=1 y usa el
  albedo SIN el color de vértice (linAlb, tomado tras map_fragment). Modo 'luz': SpotLight + el mismo término solo en
  lo horneado (uLinSolo=1, textura 'suave' según "suave"). Cache key 'retro-v3'. SIN_LUZ no recibe linterna.
  🗡 Golpes 3ª persona: arma.cuerpo3p auto | brazos | entero. s.superiores = huesos de aim_* + subárbol del primer
  hueso spine/chest; '#piernas' se crea con eso (ya no hace falta tener aim_*). brazos → copia '<clip>#brazos'
  (LoopOnce, clamp) como pose forzada de _apuntado encima de '#piernas'; entero → s.bloqueo + j.frenoGolpe
  (movimiento.js vmax×0,15). Auto: brazos si vh>0,3. kick y attack_melee_c siempre entero. Familia 'kick' añadida.
  Probado: proyectada sobre pared + suelo horneados, 4 variantes; golpe caminando → slash1#brazos + walk#piernas
  a 4,5 m/s; quieto → slash1 entero con freno; entero caminando → 0,67 m/s.
- DIAGNÓSTICO RENDIMIENTO (Nivel 3 de Miguel, ~150 fps sin límite en PC potente): 624 mallas (359 visibles),
  392 MATERIALES distintos, 31 programas, 171 draw calls, 19k triángulos, 10 luces. Por cuadro (swiftshader):
  render 2,7 ms, enemigos 0,77, jugador 0,23, mecanismos 0,06, resto ~0. El nivel en sí son ~24 mallas (una por
  material): el coste son las ENTIDADES (54 puertas con marco+hoja, 34 enemigos, 24 recogibles…), cada una con
  materiales propios. Plan: 1) caché de materiales compartidos en figuras (hacerRetro por clave color/tipo; ojo
  puertas 'energia' que tocan opacidad → material propio solo esas); 2) fusionar marcos de puerta estáticos en una
  malla por material; 3) instanciar recogibles/enemigos iguales o LOD/ocultar lejos y fuera de sala; 4) medir de nuevo.
- PLAN DE OPTIMIZACIÓN (acordado con Miguel, por fases; medir con su Nivel 3 antes/después de cada una):
  F0 Medidor: panel de rendimiento en el editor (fps, ms por sistema, draw calls, materiales, triángulos, entidades
     despiertas/dormidas) para ver el efecto de cada fase.
  F1 Compartir: caché de materiales (clave tipo+color+opciones; solo copia propia si se anima opacidad/color: energía,
     luces que parpadean) y de geometrías de figuras iguales (recogibles, palancas, hojas del mismo tamaño). Enemigos:
     mismo modelo = geometría y materiales compartidos (SkeletonUtils ya clona sin copiar geometría; revisar materiales).
  F2 Juntar lo quieto: al empezar, fusionar en una malla por material lo que no se mueve (marcos de puerta, cubos,
     rampas, props) ‑ BufferGeometryUtils.mergeGeometries; el editor no cambia (solo el juego).
  F3 Instancias: InstancedMesh para lo repetido sin esqueleto: recogibles del mismo tipo, árboles/rocas/deco del
     terreno (pino ×200 = 1 draw call). Pedir al generador de terrenos un grupo «instancias» (malla base + matrices)
     en GLB y receta; mientras, detectarlo nosotros por geometría igual.
  F4 GESTOR DE ENTIDADES (rejilla espacial): cada entidad con estado cerca / lejos / dormida.
     · Render: ocultar más allá de su distancia (por tipo, ajustable) + oclusión.
     · Oclusión: con recetas, SALAS Y PORTALES (el generador ya sabe las salas — 'sala' en los marcadores — y las
       puertas son los portales): solo se dibuja la sala donde estás y las que se ven por puertas abiertas. Sin
       salas (GLB ajeno, niveles a mano): rayos contra el BVH escalonados (unas pocas entidades por cuadro).
     · Lógica: enemigos lejos/no visibles se actualizan cada N cuadros, dormidos sin IA ni animación hasta que oyen o
       los avisan; animación de esqueleto a menos fps lejos; aparecedores y mecanismos igual (ya baratos).
     · Ajustes en el inspector del proyecto (distancias, "siempre activo" por entidad: jefes, mecanismos críticos).
  F5 Recetas: caché del nivel generado en IndexedDB (no regenerar en cada arranque); el generador manda salas,
     portales e instancias; medidor de peso al exportar.
  Encargo al Claude de terrenos (txt) cuando toque F3/F4: grupo «instancias» y grafo de salas/portales.
## Siguiente (acordado)
- (hecho en v0.5) MENÚS DEL JUEGO: tema común (fuente asset, colores, plantillas Clásico PS1 / Survival / Arcade),
  menú principal (título/logo, fondo color/imagen/escena en vivo con cámara orbitando, música, botones configurables; Salir oculto en web),
  pausa (Continuar, Opciones, Guardar/Cargar, Reiniciar, Menú principal), opciones con cosas DEL PROYECTO (no copiar el fw):
  remapear controles + "Restablecer", resolución, dither, filtro N64, temblor, límite FPS, volúmenes, sensibilidad, invertir Y;
  guardadas por jugador en el navegador. 3 slots de guardado fijos. Navegación ratón/teclado/mando/táctil. Pestaña Menús + "Ver en el visor".
- Pendiente del editor: consola de mensajes, paneles redimensionables, guía de primeros pasos.
- Pendiente luces: luz por vértice (Gouraud PS1) opcional, sombras de mancha para enemigos/objetos, luces que se apagan por trigger.
- Pendiente menús: misiones / puntuación (HUD, game over, música por escena y táctil ya hechos).
- Después: nodos especiales (sonido 3D, trigger, cámara fija; patrulla y aparecedor hechos en v0.13, salidas en v0.15), componentes, prefabs,
  plantillas de jugador (FPS arcade/táctico, plataformas 3ª, tanque, souls), táctil, multijugador LAN (WebRTC+QR).

## Límites conocidos
- En pendientes muy empinadas los pies del modelo se hunden un poco (la cápsula va elevada el alto del escalón).
- Prefabs, componentes y táctil aún no existen.

## Plan de mecánicas (acordado, v0.7): del framework de Godot se toma QUÉ hace cada módulo
Juegos guía: Quake (FPS arcade + plataformeo), SWAT 4 (táctico lento, rehenes), Resident Evil (inventario, baúl, llaves,
notas, puzzles, jefes), Zelda OoT (acción 3ª, fijar objetivo, cuerpo a cuerpo), Mario 64 (plataformas puras), Dino Squad (TPS móvil, oleadas, tienda).
Meta 144 fps: 240p, BVH para todo (rayos ~µs), IA de enemigos escalonada (piensan a 10 Hz, se mueven cada cuadro),
mezcladores de animación a menos Hz lejos / fuera de cámara, pools (proyectiles, chispas, sonidos), InstancedMesh para props repetidos,
componentes "dormidos" lejos del jugador, HUD DOM que solo se toca al cambiar un valor.
Fase 1 del jugador HECHA en v0.8 (salud, interactuar, agachar, esquiva, pasos). Fase 2 HECHA en v0.9 (armas + inventario de armas).
Fase 3: recogibles HECHOS en v0.10 y balanceo de cámara en v0.9.1. Quedan llaves (con puertas), linterna, inclinarse, nadar.
Fase 4a (enemigos + volador) HECHA en v0.12. Siguen 4b (patrulla por puntos, avisar a otros, huir, barra de jefe) y 4c (aparecedores, oleadas).
Fases: A base (salud/daño/HUD, interactuar, puertas/llaves/interruptores, pickups, pasos) → B combate (armas hitscan/proyectil,
enemigos + spawner + gestor, melee 3ª + fijar objetivo) → C movimiento extra (agachar, esquiva/dash, inclinarse, nadar,
escaleras de mano, wall run, Mario: triple salto / salto largo / salto de pared / golpe al suelo) → D género (inventario + baúl +
notas + mapa, objetivos/rehenes/puntuación, diálogos, tienda, cinemáticas, linterna) → plantillas de jugador (combos de módulos).
Objetos del nivel = F.registrarComponente (aún sin uso) con inspector desde esquema, igual que los módulos.

## v0.43.0 (experimental) — editor organizado
- Panel izquierdo en pestañas con riel vertical: 🎬 Escena · 🗺 Niveles · 📁 Archivos · 🧩 Apps (se recuerda la última; `Ed.abrirPestanaIzq(id)`).
- Escena: ＋ Añadir plegable y agrupado por temas (mismos botones reordenados en JS, `agruparAnadir`); vista 🌲 árbol (arrastrar) o 🗂 por tipo; buscador `#buscarEnt` (nombre o tipo).
- Niveles: lista por capítulo (`pintarNiveles`, llamada desde `pintarSelectorEscenas`), ＋✎⧉✕ ▲▼ 📚 y ★ Inicial (`btnEscenaInicial`).
- Ya no hay secciones plegables a la izquierda; el ancho izquierdo pasa a 290px.
- v0.43.1: niveles arrastrables en 🗺 Niveles (`zonaNivel`): sobre la cabecera de un capítulo = entra al principio; sobre un nivel = antes/después y toma su capítulo; hueco final = al final sin capítulo. Un capítulo sin niveles desaparece (se crea con 📚).

## v0.44.0 (experimental) — menús ordenados + capítulos con niveles
- Pestaña Menús como Armas: lista (Aspecto, Principal, Pausa, Opciones, Capítulos, Misiones, Game Over, Victoria, Mensajes, Partidas); clic = solo su formulario + vista previa (`previa()`: capítulos/misiones abren desde el principal). "⚠ sin botón" si falta la acción.
- Runtime: Capítulos → `p_capitulo` (niveles del capítulo). Nivel abierto si es el 1º, si se llegó a él (`forja-niveles-<proj>`, en juego-iniciado) o si se completó la misión del anterior (`forja-hechos-`).
- `menus.capitulos = { titulo, bloquear }` de serie; `menus.misiones.desbloquearTodo` (🧪 Para probar) abre todo SOLO en el editor (`_todoAbierto`, usa `enEditor`).
- "Borrar progreso" de misiones borra también capítulos y niveles alcanzados.

## v0.45.0 (experimental) — figura del jugador
- Capítulos: `menus.capitulos.verCuantos` (mostrar "(3 niveles)").
- Figura del motor (modelo.js): armas largas (postura rifle / hombro) con IK de dos huesos `_ikBrazo` (gatillo en el pecho, la otra mano en el cañón; sube al apuntar, sigue el pitch en 3ª, retroceso hacia atrás). `F.dosManos` → armas.js orienta el arma de mano a mano siempre con la figura.
  ¡Ojo! bug ya corregido: `a || (a = new X()).copy()` reutilizaba la inversa del otro brazo; usar variable aparte.
- Voltereta en el salto extra (evento `jugador-salto` con aire>0 → `F.flip` 0.5 s, giro alrededor del centro en despues()). GLB: double_jump / jump2 / flip si los trae.
- Colgado (brazos arriba, balanceo al moverse de lado), subiendo (`j.subiendoOrilla`, en orillas.js) y escalera de mano. GLB: ledge_climb / climb_up para la subida.

## v0.46.0 (experimental) — cuerpo a cuerpo: estilos, apuntar, bloquear
- Arma 'cuerpo': `estilo` (auto/corta/larga/dosManos/lanza; `F.Escena.estiloCuerpo(d)` por nombre), `clicDerecho` (ambos/bloquear/apuntar), `bloqueo` %, `parry` (s), `aturdeParry` (s). Ejemplos nuevos en paqueteArmas: Espada, Hacha, Lanza.
- Bloqueo: `j.bloqueando`; salud.js llama `j.alBloquear(cant, origen, de)` (armas.js): solo origen 'enemigo' y de frente (±70°); dentro de la ventana de parry = 0 daño + `enemigos.aturdir(de)` + evento 'parry'; si no, reduce %. Con guardia no se ataca. 1ª persona: el arma sube y se cruza.
- Figura: poses por estilo (IK a dos manos para dosManos/lanza, `F.cruzado` en guardia → armas.js orienta el arma de mano a mano de lado). Golpes: estocada, tajo, golpe por encima de la cabeza (0.55 s), empujón de lanza.
- GLB: `block`/`guard` en guardia; apuntar con cuerpo a cuerpo usa `aim_knife`.
- v0.46.1: hacha/mazo realista (`F.agarreIzq`: la izquierda en el extremo del mango, la derecha cerca de la cabeza; armas.js pone el arma en la mano izq. y la orienta izq.→der.). Arco: reposo → carga sobre el hombro der. → arriba → abajo delante (0.7 s). Atacar con la guardia puesta: `s.tGolpe` quita guardia y postura de apuntar mientras dura el golpe (sin parry gratis al volver). Guardia 1ª persona en diagonal (estilo Minecraft). Prueba de poses aislada: scratchpad/prueba/pose.mjs <estilo>.
- v0.46.2: 1ª persona cuerpo a cuerpo (`_fpCuerpo` en armas.js): reposo diagonal estilo Minecraft por estilo, golpe por estilo (estocada / tajo diagonal / carga y golpe / empujón) con `s.tGolpe`/`s.tGolpeTot`, guardia cruzada horizontal. Prueba: scratchpad/prueba/fp.mjs.
- v0.46.3: `_fpCuerpo` rehecho con poses [empuñadura xyz, dirección xyz, giro] en espacio de cámara (orientación por base, "arriba" del arma = arriba de pantalla → la cabeza del hacha ya no mira a la cámara). Apuntar ya no centra el arma cuerpo a cuerpo. Posición X/Y/Z del arma = ajuste sobre la pose (serie 0.22/−0.2/−0.42 = sin cambio). Probar en vista ANCHA (fp.mjs a 1700×800): en estrecha engaña.
- v0.46.4: 1ª persona: hacha con giro π (filo hacia fuera), espada más al frente con la cara plana a la vista (giro π/2), tajo diagonal suave, guardia estilo Minecraft 1.8. 3ª persona espada: guardia baja al frente y tajo con IK de la mano der. (hombro der. → delante → abajo izq.); con un solo brazo en IK el otro sigue con ir(). Pruebas: pose.mjs larga · fp.mjs.
- v0.46.5: alias de clips: roll ← dash/dodge (el generador exporta 'dash'), hang ← ledge_hang; UNA_VEZ incluye double_jump/jump2/flip/ledge_climb/climb_up/shoot_*/stab2…
  docs/ANIMACIONES-MUNECO.txt (esqueleto, ejes, medidas, contrato de clips, poses del muñeco, qué no coincide con el generador v0.16) y docs/base-generador-personajes.html (mismo esqueleto con nombres del generador, POSES + ikBrazo → clips → GLB).
- v0.46.6: 1ª persona espada de canto (giro 0) en reposo y ataque; la guardia sigue con la cara plana (π/2). 3ª persona: se quitó el tajo con IK de la espada (a Miguel le gustó menos): vuelve el tajo de arriba abajo y el reposo hombro −0.55 / codo −0.9. (El txt describe aún el tajo IK como alternativa.)
- v0.46.7: armas: `fpGiroX/Y/Z` (°) en Aspecto (1ª persona; en cuerpo a cuerpo se aplican sobre los ejes del arma tras la pose). `POSES_FP` es propiedad del módulo armas. Botón "📤 Guía para el generador" (pestaña Armas): descarga docs/ANIMACIONES-MUNECO.txt + punto 9 con las armas del proyecto, y base-generador-personajes.html. Las guías van dentro del editor en editor/guia-animaciones.js, que GENERA empaquetar.js desde docs/ (editar docs/, no ese archivo).
- v0.46.8: guía completa: txt con 4c (tabla de acoples por categoría → hueso, dirección, otra mano, clip), 4d (arma importada: −Z, nodo Grip), 4e (linterna/antorcha: posiciones exactas), 4f (modelo del jugador, timeScale, mezcla, retroceso), 5b (enemigos). El html enseña armas y antorcha pegadas con las reglas del motor (vista previa, no se exportan) y lee `/*FORJA_PROYECTO*/null`, que el editor sustituye al exportar (armas con categoría y ajuste "En la mano", mano izquierda, antorcha). El txt exportado añade mano del arma y linterna en el punto 9.
- v0.46.9: módulo Armas → `soloApuntando` (Resident Evil): armas de fuego (y rayo) solo disparan con apuntar mantenido y j.apuntando > 0.5; cuerpo a cuerpo no cambia.
- v0.46.10: módulo Armas → `soloApuntandoCuerpo`: cuerpo a cuerpo solo golpea con apuntar (clic derecho / LT) mantenido, sea cual sea su "Clic derecho".
- v0.46.11: `_boca` en 1ª persona sigue al arma al apuntar (x × (1−ap), y + 0.07·ap) y compensa el zoom (tan(fov/2)/tan(fov0/2)): el arma va en primer plano con fov0 y el fogonazo en el mundo con el fov del zoom. Medido: boca apuntando en NDC (0, −0.21) ≈ punta del arma.
- v0.46.12: arma `tamFogonazo` (1 normal, 0 = sin fogonazo).
- v0.46.13: boca del cañón real: `obj.userData.muzzle` (nodo Muzzle/Boca del GLB o extremo −Z de la pieza más adelantada) calculada al crear el modelo; `_boca` la transforma con m.matrix (vista) — 1ª persona con compensación de zoom, 3ª con s.vista.matrixWorld; si no hay modelo visible, la fórmula de antes. Fogonazo Y balas salen de ahí. Guía: 4d y punto 9 (color/tamaño del fogonazo).
- docs: punto 0 del txt = rigs base (humanoide, cuadrúpedo, acuático, tanque/montura con Mount/Turret_Yaw/Pitch) y opción planificada 'animaciones del editor / del modelo'.

## v0.46.21-dm (sobre la v0.46.13: generadores a1 / a2 y armas FPS/TPS)
- Base: v0.46.13 (Miguel volvió a ella). Se re-aplicó solo esto:
- Forja de personajes nueva (v1.8+) = generador 'forja-personajes@2' (personajes y armas); la vieja (v0.41) = '@1'. Cada receta trae su
  generador; motor/generadores.js busca el código por clave entre las apps cargadas (pestaña Apps): cargar las dos apps.
- editor/apps.js: "Editar en la app" abre la app que contiene el generador de esa receta.
- Armas a2: una escena con 'Arma_TPS' (sencilla) y 'Arma_FPS' (detallada), las dos con la punta a −Z, nodos Grip / Muzzle (TPS) y Grip_FPS / Muzzle_FPS.
  jugador/modulos/armas.js: _modelo() las detecta y despues() muestra la FPS en 1ª persona y la TPS en 3ª. Sin esos nodos, igual que antes.
- motor/escena.js: el campo se llama "Modelo del arma" (1ª y 3ª persona).
- El generador a2 usa las medidas del muñeco (cadera 0.47 H, rodilla 0.235 H, hombro 0.276 H sobre la cadera y x 0.155 H, brazo 0.36 H, muslo x 0.065 H)
  y por defecto exporta en el reposo del motor (brazos colgando).

## v0.46.22-dm (modelos sin animaciones animados por el muñeco)
- jugador/modulos/modelo.js → iniciar(): si el modelo (GLB o receta) es humanoide (hueso UpperArm_L) y NO trae clips, se crea el muñeco
  de siempre (_figura) con sus mallas ocultas y el modelo como hijo; despues(): tras _animarFigura se copian los giros locales de los
  pivotes (cadera, cabeza, hombro, codo, muslo, rodilla) a Hips, Head, UpperArm, Forearm, Thigh, Shin (muslos: × inversa de la cadera,
  porque en el muñeco cuelgan de la raíz) y el desplazamiento de la cadera a Hips. El muñeco NO se toca: mismas poses, golpes (hacha
  incluida), IK y arma en su mano (armas.js encuentra antes la hand_R del muñeco). El modelo debe estar en el reposo del motor
  (brazos colgando): en la Forja de personajes a2, "Reposo del motor" o "Del editor".
- Si el modelo trae clips, se usan los suyos como antes.

## v0.46.23-dm
- Muñeco · lanza: manos más al frente y juntas (der. -0.06,0.20,0.05 H · izq. 0.00,0.23,0.30 H) para que el asta vaya recta al frente y no de lado.

## v0.46.24-dm
- Aparecedor (zona): al salir del área (activa + radio) los que no te persiguen ni ves se retiran a la reserva; si no queda ninguno, A.lleno = false
  y al volver a entrar la zona se llena otra vez como al empezar (antes solo se llenaba una vez y los de antes seguían vivos lejos).
- Enemigos: la colisión (radio y altura del cuerpo) se multiplica por la escala de la entidad y, si tiene modelo, por su escalaModelo
  (E.kEsc; se vuelve a aplicar al reutilizarlos desde la reserva).

## v0.46.25/26-dm
- v0.46.25 (cartel de carga aéreo) DESHECHO a petición: niveles.js/partida.js como en v0.46.24.
- v0.46.26: pantalla de briefing de misión: toma aérea girando sobre el nivel (velGiro del menú principal) con color/opacidad del tema y blur. juego.js `_tomaAerea`.
- Pendiente: al escalar enemigos solo escala la colisión; falta alcance, altura de ojos/disparo, barra de vida, vuelo.

## v0.46.27-dm
- Menús → 🎯 Briefing de misión (proyecto.menus.briefing): fondo (toma aérea / vista jugador / color), giro, distancia, altura, color/opacidad/difuminado del fondo, ancho y colores de caja/borde/título/texto/botón, textos (encabezado, objetivos, botón), mostrar objetivos/pista, sonido al abrir. escena.js defaults · panel-menus.js ESQ_BRIEFING · misiones.js estiloBriefing + vars CSS --fb-* · juego.js _tomaAerea usa la config.

## v0.46.28-dm
- Menús → Briefing: vista previa en vivo en el panel (panel-menus.js previaBriefing), fondo de ejemplo según tipo.

## v0.46.29-dm
- Menús → Caja de mensajes: vista previa en vivo (usa Hud.estiloMensaje).
- Menús → Partidas guardadas: lista de ranuras con 🗑 por ranura, "Borrar todas las partidas" y "Borrar progreso de misiones" (forja-estrellas-/forja-hechos-).

## v0.46.30-dm
- Lanza (muñeco): nuevo REPOSO — mano derecha delante del vientre (no atraviesa el torso), izquierda adelante con codo doblado, asta al frente algo arriba. modelo.js rama `g < 0`. Golpe y guardia sin cambios.

## v0.46.31-dm — 💰 Divisas
- proyecto.divisas [{id,nombre,icono,imagen,color,max,enBaul}] (sin lista = solo 'monedas'). F.Divisas en recogibles.js (lista/de/tiene/poner/sumar/html/texto). j.divisas {id:n}; j.monedas = divisa 'monedas' (compat).
- Recogible tipo moneda: campo `divisa`. Tienda: artículo `divisa`. HUD (tactico.js) muestra cada divisa. Inventario: fila de divisas; en el baúl Guardar/Sacar si enBaul (inv.baulDivisas). Partida guarda pj.divisas (las viejas con pj.monedas se convierten).
- Editor: Juego ▸ Objetos ▸ 💰 Divisas (panel-objetos.js pintarDivisas).

## v0.46.32-dm — 💾 Puntos de guardado
- Nuevo motor/guardado.js (en archivos.js tras niveles.js): entidad 'guardado' (PUNTO: activar tocar/usar, hace menu/checkpoint/auto, unaVez, objeto+gastar, llenarVida, aviso, figura/modelo). Gestor por Juego (juego.guardado), emite 'punto-guardado'.
- proyecto.menus.guardado {donde ambos|pausa|puntos, alMorir gameover|reaparecer, alEntrarNivel, ranuraAuto}. Partida: checkpoint = instantanea() (todo el estado), acción 'checkpoint', Game Over con "Continuar desde el punto de control", reaparecer solo a 1,5 s.
- Partidas: ranura AUTO (índice RANURAS), leer(), ultima() la incluye; Cargar muestra AUTOGUARDADO. Pausa oculta "Guardar" con donde=puntos.
- Editor: Añadir ▸ Jugador y nivel ▸ 💾, inspector con F.Guardado.ESQUEMA, Menús ▸ Partidas guardadas con los ajustes.

## v0.46.33-dm
- Faltaba el botón 💾 en editor.html (data-anadir="guardado"): la barra Añadir sale de esos botones.

## v0.46.34-dm — 🧱 Objetos movibles + placas
- Nuevo motor/empujables.js (archivos.js tras guardado.js): entidad 'empujable' (empujar / tirar con usar mantenido / cargar-soltar), cuadrícula 0,5 m, tiempoPaso, volver (s), etiqueta, forma caja/barril/roca o modelo. Gestor juego.empujables (antes que mecanismos), piezas móviles en mecanismos.alMundo, excluido del mundo fijo (fisica.js). Estado guardado est.empujables.
- Disparador: quien 'objetos' | 'jugadorObjetos', etiqueta, placa visible (se hunde).
- Inspector: aviso si un punto de guardado pide objeto con Inventario apagado.

## v0.46.35-dm
- Movimiento: opción noDeslizar (rayos al frente a 2 alturas; pared casi de frente → velocidad horizontal 0).
- Empujables: avisos propios (.fe-aviso): "Mantén E y retrocede: Jalar", "E: Levantar", "E: Soltar"; cargar/soltar se maneja en empujables.js (no en Interactuar). Un uso del botón por cuadro. _libre restaura el estado previo de la pieza (antes reactivaba la del objeto cargado y no dejaba soltar).
- Origen = ent.pos/rot siempre; Gestor.detener() los devuelve (juego.detener). En el editor nunca se quedan movidos.

## v0.46.36-dm
- Empujables sin cuadrícula: empujar libre por el eje de la cara (velocidad m/s), jalar = interruptor (usar agarra / usar suelta, el jugador queda pegado y se teletransporta con el objeto; opción agarradoEmpuja), cargar entre las manos (hand_L/hand_R del modelo, orientado al cuerpo) y el muñeco pone las manos al frente (modelo.js). Volver se desliza en 0,6 s. 'objeto-movido' al parar.
- Movimiento: noDeslizar con anguloNoDeslizar (30°); con teclado en diagonal siempre resbala.

## v0.46.37-dm
- Empujar sin temblor: al empujar 0,15 s entra en modo "empuje" (agarre.modo=empuje): jugador pegado a la cara y movido con el objeto, velocidad 0 (antes chocaba y se frenaba cuadro sí/cuadro no). Se suelta solo al dejar de empujar.

## v0.46.38-dm
- Empujar/jalar: j.pasoForzado (velocidad del objeto) hace caminar las piernas (figura y clips walk por vh); el modelo gira de cara al objeto (modelo.js despues); inclinado al empujar, hacia atrás al jalar. Jugador pegado con P.x/P.z directo (teletransportar lo dejaba "en el aire" y no movía las piernas).

## v0.46.39-dm — 🛡 Aliados (SWAT, máx. 3)
- enemigos.js: actitud 'aliado' (+ fuegoAmigo, seguirAlEmpezar, preset 'agente'). Estado 'orden' (en IDLE): meta = E.metaOrden; ve enemigo → alerta/perseguir; 'buscar' → 'orden'. _blancoAliado (enemigo más cercano, cada 0,4 s; nunca el jugador). Agresivos también apuntan a aliados más cercanos (this.aliados). Fuego amigo bloqueado en objetivo.danar; nunca se vuelve contra el jugador. Con orden esperar/ir dispara sin moverse.
- Nuevo motor/aliados.js (archivos.js tras empujables): rastro del jugador (0,5 m, 40 pts), metas 5/s, órdenes seguir/esperar/ir/limpiar (puerta táctica: patada o abrir, entran a 3 puntos), menú rápido G (1-4) y botón táctil 👥 contextual, HUD del equipo. Entrada: acción 'ordenes' (G). armas.js ignora 1-9 con el menú abierto. Misiones no cuentan aliados.

## v0.46.40-dm
- Abrir y limpiar en fila: forman fila frente a la puerta (o.fila), entran de uno en uno (el siguiente sale cuando el anterior cruzó), cruzan por el centro del hueco y luego van a su punto.

## v0.46.41-dm — 🖼 Retratos + ❤ Vidas
- Retratos: NPC (npc.retrato, ladoRetrato, por diálogo nodo.retrato) en tactico._abrirMenu(…, retrato); mensajes (interaccion.retrato) en interactuar.
- Vidas: menus.vidas {activo, inicio, max, extraCada, divisa, gastar, icono, imagen}. partida.js: gameOver gasta una y reaparece (checkpoint o reiniciar) a 1,5 s; sin vidas Game Over y al continuar vuelven las de inicio (vidasAgotadas). Vida extra por divisa (evento 'monedas') o recogible 'vidaExtra' (evento 'vida-extra'). HUD .fh-vidas. Se guardan en ranuras/checkpoint (vidas, sigUmbral).

## v0.46.42-dm — ♥ Corazones + retrato automático
- Salud: modoVida 'corazones' (vida en medios corazones, vidaMax = corazones×2), danoCorazon medio/uno/fuerza (cada 20 = ½), curar: cada 25 = 1 corazón, sin armadura ni regenerar. j.sumarCorazon / j.sumarPieza (piezasCorazon para 1). HUD fila de corazones (medios con degradado) + pedazos. Se guardan vidaMax y piezasCorazon (juego.estado).
- Recogibles 'corazon' (contenedor) y 'piezaCorazon'.
- F.Retrato (tactico.js): foto 96×96 de la cabeza del modelo (clon), cache por NPC; npc.retratoAuto.

## v0.46.43-dm
- Salud en puntos: contenedor = +20 máx. y llena; pedazo = +20/pedazos (5) al máximo y cura eso. Props nuevas con valor por defecto en código (proyectos viejos no las traen). Comparado con v0.46.41 (absorbe, escudo, regenerar): idéntico.

## v0.46.44-dm
- Plantilla Campo de pruebas: 2 divisas (gemas enBaul), vidas activas (3, extra cada 50), noDeslizar, máquina de escribir y bandera-checkpoint (nivel 1), puzle caja→placa→jaula con 1UP/contenedor/pedazo, barril que se carga y vuelve, cartel; nivel 2: 2 agentes aliados; nivel 3: gemas, artículos en gemas, punto de guardado cristal, guía con retrato automático. Nota del nivel actualizada.

## v0.46.45-dm
- Plantilla: entrada de la jaula de 2,2 m (antes 0,6 m: los tramos de pared la tapaban).

## v0.46.46-dm
- Empujables: icono de cuenta atrás (⏳ + segundos, rojo en los 3 últimos) sobre los objetos que van a volver; si el objeto queda fuera de cámara, el icono se pega al borde de la pantalla. Opciones verTiempo / iconoTiempo.
- Plantilla: puzle con tiempo del barril (placa azul abre el nicho con 3 gemas, 10 s); punto de guardado del nivel 3 separado del cartel.

## v0.46.47-dm
- Aliados: el panel del equipo, el menú de órdenes y el aviso usan la fuente, colores, fondo, sombra y escala del HUD. Posición automática según la distribución del HUD (evita barras y objetivos de misión) u opción fija: HUD ▸ Panel de aliados (equipoPos).

## v0.46.48-dm
- HUD por zonas (hud.js: COMUN/ZONAS/colocar): 5 columnas (arriba izq/centro/der, abajo izq/der) donde se apilan vida, munición, vidas, divisas, objetivos, relojes, jefe, oleadas, recogidos, brújula y equipo según la distribución; nunca se pisan. Hud.pieza las coloca solas; la brújula también. Con táctil las zonas se apartan del botón de pausa y los controles.
- Vidas, divisas, objetivos y relojes de misión con fuente/colores/escala del HUD. Barra de progreso táctica bajada al 68%. Arcade: lo del centro baja un renglón.

## v0.46.49-dm
- HUD: vidas alineadas como una fila más (icono en la columna de iconos); opción HUD ▸ Vidas (vidasPos: junto a la vida o una esquina). Halo: barra del jefe abajo al centro (zona bc) y brújula abajo a la izq. en la plantilla.
- Vista previa del HUD con todo lo que el proyecto usa: vidas, divisas, objetivos y reloj de misión, bomba, jefe, aliados y corazones (si no se usa, no sale). Misiones/Tactico/Aliados exportan su CSS para la vista previa.

## v0.46.50-dm
- HUD arcade: brújula siempre redonda (la tira pasa abajo a la izq.), jefe abajo al centro; plantilla Arcade con brújula abajo-izq. Barra (Quake): relojes de misión y bomba arriba a la der. Centrado: objetivos abajo a la der. Hud.destino toma la esquina de la brújula de su clase.

## v0.46.51-dm
- HUD: plantilla Halo con brújula abajo a la der.; en arcade el panel de aliados va abajo a la der.

## v0.46.52-dm
- Enemigos: escalado completo (_escalar): radio, altura (ojos, disparo, barra de choque), alcance cuerpo a cuerpo (embestida √k), altura de vuelo, flotar y empuje. Opciones escalaVel (velocidad ×√k) y escalaFuerza (vida ×k², daño ×k). También al reaparecer en oleadas.

## v0.46.53-dm
- Maná: munición de serie ✦ (100, se recarga 2/s: campo "regenera" en tipos de munición) y campo "gasto" (munición por disparo). Hechizos de ejemplo: Bola de fuego y Rayo de hielo. Con munición, el tipo de daño del arma manda si no es Normal.
- Efectos de estado (motor/estados.js): quemado, envenenado, congelado, aturdido, lento. Salen del tipo de daño (fuego/veneno/hielo nuevo/eléctrico) o del campo efecto del arma o del enemigo; resistencia 0 = inmune. Enemigo: E.est, congelado = quieto y azul. Jugador: j.efectos, j.lentoEstado, daño a tirones (corazones cada 20), iconos en HUD fh-estados junto a la vida.

## v0.46.54-dm
- Recogible ⬆ Más munición máxima (tipo capacidad: munición, cantidad, además la llena). j.municionExtra se guarda en la partida; afecta a recogidas, regeneración y HUD. Presets bolsaBalas y frascoMana. Plantilla: bolsa de balas, Bola de fuego y frasco de maná en la fila de recogibles.

## v0.46.55-dm
- Optimización: aliados (metas y HUD 5 veces/s, antes el HUD armaba texto cada cuadro), divisas del HUD táctico (lista cacheada, revisión 10 veces/s), empujables (texto de tecla 1 vez/s y los que están a más de 4 m no se revisan).

## v0.46.56-dm
- Editor reorganizado: Vidas (arcade) pasan a Jugador ▸ Salud y muerte (Ed.formVidas); Menús agrupados en General / Pantallas / Durante el juego / Final; Ajustes en Juego (nombre, escena inicial, controles táctiles) e Imagen y rendimiento; pestañas Armas y maná, Objetos y divisas.

## v0.46.57-dm
- Editor: secciones plegables (acordeón) en todos los formularios: cada grupo del esquema es una caja que se abre/cierra (Ed.seccion), recordada por nombre en localStorage (forja-editor:plegables); la primera de cada formulario empieza abierta. CSS: .modulo.abierto > .modulo-cuerpo (anidadas).

## v0.46.58-dm
- Editor (editor/herramientas.js): 🔎 buscador de opciones arriba del panel derecho (filtra filas por nombre/ayuda y abre sus secciones; se reaplica al cambiar de pestaña); 🩺 Revisar proyecto (salidas sin destino, puertas 'mecanismo' que nada abre, acciones a objetos borrados, recogibles de armas/munición/objetos inexistentes o con su módulo apagado, guardado que pide objeto sin Inventario, escena sin inicio, criatura vinculada borrada; clic = ir al objeto); ▶ Desde aquí (Mayús+P): juega desde la cámara del editor. Ed.camaraEditor.

## v0.46.59-dm
- Montables (motor/montables.js, entidad 🐎 montable): montura, carro, bote (solo sobre agua) y vagoneta (sigue 📍 puntos 'Riel 1…'). Usar = subir/bajar (bajar a un lado libre; el bote busca orilla). j.montado: jugador.js salta módulos de andar (SALTAR) y llama a conducir; bote/riel colocan el pie directo (fijo). Aparcado choca (caja invisible como pieza móvil). Opciones: velocidad, reversa, aceleración, giro, salto, armas montado, atropello, al bajar quedarse/volver, asiento, esconder jugador, cámara extra (j.camExtra), sonido en bucle, modelo. Plantilla: Caballo, Jeep, Balsa y Vagoneta con su riel.\n- Editor: se quita el modo Sencillo; botón 🎬 Probar completo arriba (y el de Menús renombrado igual).

## v0.46.60-dm
- Montables arreglos: aviso de usar con clase fmt-aviso (chocaba con .fm-aviso de menús: caja gigante); el carro ya no salta (salto en SALTAR, la montura salta por su cuenta); el gestor de tapados ya no esconde montables (desaparecían); bote: se sube desde la orilla o nadando (alcance +2.2 m) y balsa más cerca del borde. Opciones: terceraPersona (pasa a 3ª al montar, vuelve al bajar) y 'Puede usar armas montado' también guarda la pose del arma. Postura de jinete (figura del motor): sentado, manos al frente que siguen el giro y se levantan al saltar. Botón Probar completo en verde.

## v0.46.61-dm
- Montables: montura, carro y vagoneta que entran al agua o la lava se destruyen (te bajas, desaparece y no se puede montar). Opción reaparecer (sí por defecto) y reaparecerTras (5 s): vuelve a su sitio para ir otra vez por él.

## v0.46.62-dm
- Montables: animación al destruirse (cae de costado en ½ s, se hunde si fue al agua, desaparece a los 2,5 s; reaparece no antes de eso).

## v0.46.63-dm
- Modelos importados (GLB del generador u otros): el editor les añade las animaciones del muñeco que les falten (motor/animbase.js, ahora cargado en archivos.js e incluido en el zip): apuntar, agarres hold_axe/hold_spear, doble salto, colgarse, golpes… (alias walk_c→crouch_walk, dash→dodge). Agarre en reposo como el muñeco: con arma de fuego la postura de su tipo; hacha y lanza su agarre a dos manos (posturas hacha/lanza); cuchillo y espada en la mano. Las piernas siguen su animación.

## v0.46.64-dm
- Armas en modelos importados: con la postura de agarre puesta (rifle, lanzacohetes, hacha, lanza) el arma se orienta como en el muñeco: de la mano del gatillo hacia la otra mano (hacha: desde la izquierda, la cabeza más allá de la derecha). Antes seguía al antebrazo: rifle de lado, hacha hacia fuera, lanza atravesando el cuerpo.

## v0.46.65-dm
- Modelos importados en reposo = muñeco: pistola colgando en la mano (antes brazos al frente), rifle cruzado al pecho (hold_rifle), lanzacohetes hold_shoulder, lanza con el reposo nuevo del muñeco (hold_spear actualizado en animbase.js). Posturas rifleR/hombroR; armas.js orienta a dos manos también con ellas.

## v0.46.66-dm
Táctil: botón ✋ Usar aparece para subir/bajar de montables (contextual sin depender del módulo). Editor en celular: paneles izquierdo/derecho como cajones (☰ / ⚙), barra desplazable, filas más compactas.

## v0.46.67-dm
- 📼 Efectos de cámara (motor/efectos.js, nuevo, en archivos.js tras render.js): líneas CRT (+ rejilla RGB), curvatura, sangrado de color, ruido, temblor de cinta (tracking + franja), viñeta y letrero ● REC con pila, fecha y hora que avanza (lienzo 2D repintado 2 veces/s, dentro del shader así le afectan los efectos).
- Cómo dibuja: con efectos, Vista dibuja el nivel (y el primer plano) en un WebGLRenderTarget a la resolución retro y un solo pase a pantalla nativa los aplica (F.Efectos.Pase). Apagado = como siempre, sin coste. Vistas orto del editor nunca los llevan. particulas.js toma uAltoPx del render target.
- Dónde: Proyecto ▸ Imagen y rendimiento ▸ 📼 Efectos de cámara (fxEstilo + controles fx…); Escena ▸ 📼 "Efectos propios en este nivel" (fxPropio, copia los del proyecto al encender). Estilos: Apagado, VHS, CRT arcade, Cámara de video 90s, Propio (todo 0). Elegir estilo rellena los controles; el ↺ de cada control vuelve al valor del estilo (formulario con opciones.defectos = F.Efectos.defectosDe). Avisos ⚠ si no se ven en el editor, si todo está en 0 o si el nivel usa los suyos.
- Vista del editor ▸ "Efectos de cámara en editor" (fxEnEditor, sí de serie). Menú Opciones del jugador ▸ Imagen ▸ "Efectos de pantalla (VHS / CRT)" (ajustes.fxJugadorApagado).
- Para cinemáticas: vista.forzarEfectos(cfg | null) pone efectos encima de los del nivel.
- Probado: editor con Cámara 90s y ▶ Jugar con CRT + REC en Chromium headless, sin errores de consola.

## v0.46.68-dm
- 📼 Efectos de cámara ampliados (motor/efectos.js): el esquema trae sus 3 secciones (📼 Efectos de cámara · 🎨 Paleta de colores limitada · 🌗 Color y tono); escena.js mete fxPropio en la primera.
- 🎨 Paleta: Game Boy, grises, fósforo verde, CGA, sepia, noche azul, NES (16), PICO-8 (16) o propia (2-8 colores con selector). Tramado Bayer 4×4 entre los dos colores más cercanos (fxTramado). Todo el pase trabaja en sRGB (aPantalla) y sale directo a pantalla.
- 🌗 Tono: saturación, contraste, brillo, tinte + fuerza.
- Estilos nuevos: 🟩 Game Boy y 📟 Cámara de seguridad (blanco y negro verdoso, ruido, letrero CAM 03 / ● REC / fecha y hora a la derecha). fxRec = "Letrero en pantalla" con fxLetrero casera|seguridad y fxCamNombre.
- 💥 Momentos (F.Efectos.momento(vista, k, v, color)): golpe (salud: sacudida + colores separados, se apaga solo), gris (salud: blanco y negro al morir), onda (agua: ondulación bajo el líquido, opción 'ondulacion' del líquido, 0.5 de serie), mareo (envenenado), doble (aturdido), borde naranja/azul (quemado/congelado) desde estados.ticJugador solo cuando cambia. Opciones en Jugador ▸ Salud ▸ Pantalla y sonido: golpeImagen, muerteGris, efectosEstado. Ya existían y se quedan: rojo al recibir daño, fundido a negro, tinte/niebla/sonido bajo el agua.
- Con solo momentos (nivel sin estilo) el pase usa la textura del mismo tamaño que la pantalla: nada cambia de tamaño al golpearte. juego.iniciar/detener limpian los momentos.
- Probado: ▶ Jugar con Game Boy, Cámara de seguridad y momentos (mareo + borde quemado), sin errores.

## v0.46.69-dm
- 🎌 Estilo Anime (cel shading) en efectos: sección "🎌 Anime / cel shading" con fxToon (0/2/3/4 tonos), fxToonSombra, fxContorno (fuerza), fxContornoColor, fxContornoGrosor (1/2 px retro).
- Tonos: en hacerRetro (render.js, cache 'retro-v5'), #define TOON_OK en materiales con luces; en opaque_fragment la luz (outgoingLight − emisión) / albedo se redondea a escalones con mínimo uToonSombra. U.uToon/uToonSombra los pone Vista._elegirFx según el efecto activo (0 sin efectos).
- Contorno: el render target del pase lleva DepthTexture; el shader linealiza (uCerca/uLejos de la cámara, pase.dibujar(r, dt, cam)) y marca saltos relativos de distancia entre vecinos; se apaga a lo lejos (45-75 % del far).
- 🎬 fxBarras (barras de cine, 0-0.25 por lado) en la primera sección; también para cinemáticas vía forzarEfectos.
- Probado: ▶ Jugar con Anime + barras en Chromium headless, sin errores de shader.

## v0.46.70-dm
- 📼 Acción "Cambiar efectos de cámara" (que 'efectos': estilo 'nivel' | 'ninguno' | un ESTILO, + barras 0-0.25) e inversa 'efectosNivel' en palancas, disparadores, pedestales y condiciones. F.Efectos.aplicarAccion → vista.forzarEfectos. Juego.iniciar quita lo forzado (no pasa al siguiente nivel); respeta "efectos apagados" del jugador.
- 🎬 Barras de cine entran/salen deslizándose (pase.barras → barrasMeta, 0.4/s). El letrero REC/CAM se mete entre las barras.
- 🎞 Transiciones (F.Efectos.transicion(vista, {tipo, a, segundos}) → promesa): negro, blanco, pixelado, barrido, círculo, estática, persianas; uTrans/uTransTipo en el pase. Salidas: campo 'transicion' (+ "Duración de la transición"); acción "Ir a otro nivel" con su transición. niveles._tapar: 'negro' = la capa CSS de siempre; las demás las dibuja el pase y la capa se pone de golpe debajo (cartel / carga). limpiarMomentos no toca la transición; detener (sin seguir) la quita.
- 📱 Con efectos, la salida tiene tope de 720 de alto en pantallas táctiles (pointer: coarse) y 1440 en PC.
- ♿ Opciones del jugador ▸ Imagen ▸ "Reducir movimiento de pantalla" (ajustes.fxSinMovimiento): sin temblor de cinta, sacudida, mareo, ondas ni vista doble (los colores sí).
- 🩺 Revisar: ahora revisa TODAS las acciones (antes el filtro por nombre no reconocía luzOn, palOn, platIr…): sin "a cuál", apunta a algo borrado, acción desconocida, nivel/canal/texto/sonido vacíos, clima sin clima; listas "Qué hace" vacías; aparecedores sin criaturas o con criaturas borradas; efectos propios en 0.
- Revisión general (script headless): 3 plantillas (revisar, 8 paneles, inspector de cada entidad de cada escena, jugar y detener), los 36 tipos de entidad creados y seleccionados y jugados, Probar con menús + nueva partida + pausa, exportar .html y jugarlo con Cámara 90s + barras: 0 errores de consola.

## v0.46.71-dm — 🎬 Cinemáticas (reproductor + taller)
- motor/cinematicas.js (F.Cine): escena.cinematicas = [CINE {nombre, alEmpezar, unaVez, saltar 'siempre'|'vista', barras, alTerminar 'juego'|'nivel'|'cine', destino, llegada, transicion, siguiente, pasos}]. Paso = {id, tipo, cuando 'despues'|'alavez', ...}. horario(): 'despues' empieza cuando todo lo anterior acabó; 'alavez' con el anterior.
- Tipos: camara (destino 📷 cámara / 📍 punto / '__jugador'; viaje o corte; mirar), mirar, temblor, zoom, fundido (trans + tapar; usa F.Efectos.transicion), barras, efectos (aplicarAccion), dialogo (máquina de escribir, esperar tecla), titulo, sonido, musica ('' = parar), hacer (lista "Qué hace" de mecanismos, sin 'cine'), esperar.
- Reproductor (juego.cine, solo si el nivel tiene cinemáticas): en juego._actualizar, si hay cinemática activa el mundo no se actualiza (solo cine.actualizar, clima, mixers) y se dibuja con su cámara propia. Alempezar en el 3er cuadro (o tras el briefing de misión). Saltar: mantener saltar/interactuar/pausa 0,7 s o el botón ⏭ (táctil); al saltar se ejecutan los 'hacer' y 'musica' que faltaban. fin(): efectos como antes (fxForzado), destapa si quedó tapada, alTerminar. HUD oculto con .fc-cine. Vistas: "una vez" por partida (reiniciarPartida en ▶ Jugar y nuevaPartida), "ya vista" en localStorage por juego.
- Acción '🎬 Ver cinemática' (que 'cine', a.cine). Cámaras: activacion 'cine' (🎬 Solo para cinemáticas): el gestor de cámaras fijas las ignora.
- editor/taller-cine.js: taller abajo del visor (Escena ▸ 🎬 Cinemáticas ▸ Abrir / ＋ Crear, o desde la acción). Lista de pasos con tiempos, ↑↓✕, ＋ Añadir paso (tras el elegido), línea de tiempo por pistas (Cámara/Imagen/Texto/Audio/Nivel; clic = elegir), formulario del paso con ↺, ⚙ Ajustes de la cinemática, 📷 Cámara aquí (crea cámara 'cine' en la vista del editor y la usa), ▶ Probar (▶ Jugar + reproducir; Detener vuelve al taller). Ed.editarAcciones(p, ent, dueno, texto, alRepintar).
- Exportar: motor/cinematicas.js solo entra si algún nivel tiene cinemáticas. 🩺 Revisar: pasos con avisos, "Ver cinemática" sin cinemática, al terminar sin nivel / sin siguiente.
- Probado: taller (crear, cámara aquí, pasos), ▶ Probar (corte + título + viaje), saltar, volver al taller, exportado con intro "al empezar" funcionando, exportado sin cinemáticas sin el archivo, revisión general 0 errores.
- Pendiente (siguiente): arrastrar/estirar bloques en la línea de tiempo; pasos de personajes y objetos (mover por ruta, animación del modelo, aparecer/quitar/crear); partículas/explosión como paso propio.

## v0.46.72-dm
- Botón 🎥 Cine en el riel izquierdo (abre / cierra el taller de cinemáticas; se marca activo). Antes solo se llegaba por Escena ▸ 🎬 Cinemáticas y Miguel no lo encontró.

## v0.46.73-dm — 💥 Explosiones + partículas encendibles + cinemática de prueba
- motor/explosiones.js (F.Explosiones): cada explosión = 1 Points (70 fuego + 30 chispas + 34 humo, geometría compartida, todo en GPU con uEdad puesto en onBeforeRender) + esfera de destello aditiva. Grupo fijo de 6 por vista (vista._explosiones), se recicla. lanzar(juego, punto, {tam pequena|media|grande, radio, dano, humo, sonido, temblor, color}): sonido sintético 'explosion', evento 'explosion' (quemaduras de armas.js), temblor (j.temblor jugando —solo se ve con el módulo Armas— o cine.sacudir en cinemática), daño con caída por distancia a jugador, enemigos (tipo explosivo) y rompibles (cadena de barriles). puntoDe(juego, id): entidad (+0,5 m) o '__jugador'.
- tactico.explosion (barriles, bombas, C2) usa F.Explosiones.efecto en vez de crear una esfera nueva cada vez.
- Partículas: opción 'activa' (Encendidas al empezar); F.Particulas.encender(juego, id, on|'alternar') esconde el material (el gestor no lo pisa); preparar(juego) en Juego.iniciar.
- Acciones nuevas: '💥 Explosión' (donde / aquí mismo vía a._de, tam, daño, humo) y '✨ Encender / Apagar / Alternar partículas'.
- Cinemáticas: pasos 'explosion' (donde, tamaño, humo, daño, sonido) y 'particulas' (a, encender); al saltar se aplican las partículas. cine.sacudir(fuerza, s).
- Campo de pruebas: carpeta "Cinemática de prueba" (2 cámaras de cine, 2 puntos en la lava, humo apagado) + cinemática "Prueba: explosión en la lava" (fundido, título, viaje, diálogo, 2 explosiones, humo, zoom, vuelta al jugador) que pone el disparador a 3,5 m del inicio (una vez por partida).
- 🩺 Revisar: un disparador sin acciones no avisa si otra cosa lo usa como zona (extracción del rehén).
- ⚠ Los scripts de prueba anteriores cargaban las plantillas mal (cargarDatosProyecto pide { proyecto }): la "revisión general" de v0.46.70 solo había probado el proyecto de serie. Repetida ahora bien: 3 plantillas (todas las escenas, inspector de cada entidad, 8 paneles, jugar), 36 tipos, Probar con menús, exportar → 0 errores.

## v0.46.74-dm
- 🖐 Filtro de selección del visor (select #selFiltro en la barra del visor, recordado en localStorage forja-editor:filtroSel): Todo · Solo objetos · Solo luces y efectos (luz, sonido, partículas) · Solo zonas y lógica (disparador, condición, salida, guardado, aparecedor, marcador, punto, agua, inicio) · Solo cámaras. Ed.categoriaDe(tipo), Ed.sePuedeElegir(ent). El clic atraviesa lo que no entra (sigue con el siguiente golpe del rayo) y el rectángulo (Shift+arrastrar) lo ignora; al cambiar de filtro se suelta lo elegido si ya no entra. El árbol elige todo. objetosPickables no se filtra (soltar modelos sobre superficies sigue igual).
- Probado: luz delante de un objeto → Todo elige la luz, Objetos atraviesa la luz, Luces elige la luz, Cámaras nada.

## v0.46.75-dm — 🪄 Armas mágicas, 🛡 escudos y ⬡ campos de energía
- motor/campos.js (F.Campo): esfera low poly (Icosaedro 1 = 80 caras; cúpula = media esfera 10×5; muro = plano 6×6), ShaderMaterial aditivo, DoubleSide, sin escribir profundidad. Cara plana con dFdx/dFdy, borde brillante (fresnel), estilo 'ondas' (bandas de seno que suben) o 'hex' (panal + celdas que se encienden), golpe = destello + anillo que se abre desde el punto (uGolpe/uGolpeK). crear() → { malla, fuerza(v, s), valor(), golpe(punto), color(), estilo() }; fuerza y golpe se animan en onBeforeRender.
- ⬡ Entidad 'barrera' (Mecanismos ▸ ⬡): forma cúpula / esfera / muro, aspecto, color, brillo, encendida al empezar, zumbido. Tamaño = escala. Choca con su malla; apagada no choca (juego.barrerasOff, excluida en reconstruirColision; prepararBarreras al iniciar). Acciones ⬡ Encender / Apagar / Alternar barrera (barOn/barOff/barAlt).
- 🪄 Armas: campo 'magia' (no | varita | baston | libro). Figuras de base en armas._figuraMagia (gema/cristal/orbe "boca" del color del hechizo), pose 1ª persona _poseMagiaFp (toque, empujón, libro que sube), _animMagia (gema que late y gira, cristal que flota, hoja que pasa; rápido al lanzar). Postura 3ª: bastón = rifle (dos manos), varita y libro = pistola; _dosManos solo el bastón. Proyectos viejos: armas con munición de maná ✦ pasan a varita.
- 🛡 Tipo de arma 'escudo' (hechizo): escudoSeg, escudoBloquea %, escudoAguante, escudoEstilo, escudoColor. Al lanzar, campo esfera alrededor del jugador; j.alEscudo (salud lo consulta tras alBloquear) para el daño salvo lava/agua/ahogo/aplastar/caída; golpe en el campo hacia el atacante; se rompe con el aguante. Evento 'escudo-magico'.
- 🛡 Salud ▸ "Burbuja de energía al recibir golpes" (no | ondas | hex) + color: con armadura, cada golpe hace brillar una esfera alrededor del jugador (más fuerte al romperse); titila mientras se recarga (regenerar armadura).
- Plantilla: Bola de fuego = varita, Rayo de hielo = bastón, Escudo arcano nuevo (libro, hex morado, 25 maná, 6 s); recogibles de Rayo de hielo y Escudo arcano; cúpula hexagonal con armadura dentro y "Palanca de la cúpula".
- Probado: las 3 formas en 1ª persona (capturas), escudo para 40 de daño (vida y armadura intactas), 3ª persona con escudo, burbuja del escudo de energía, cúpula: el rayo de colisión choca / no choca al apagarla / choca otra vez. Revisión general: 0 errores.

## v0.46.76-dm — 🛡 Escudo de fuerza de base y recogible
- Salud ▸ 🛡 Escudo de fuerza: fuerzaBase (el jugador lo tiene siempre, como la armadura), fuerzaAguante, fuerzaBloquea %, fuerzaEspera, fuerzaRecarga /s, fuerzaVer (golpe | siempre tenue), fuerzaEstilo, fuerzaColor, fuerzaBarra (barra ⬡ .fh-fza en el HUD). j.fuerza / j.fuerzaMax.
- Escudo temporal: j.activarEscudo({ seg, aguante, bloquea, estilo, color }) y j.escudoActivo(). Una sola esfera (s.campoF, motor/campos.js) en salud._actualizarFuerza. Orden del daño: bloqueo cuerpo a cuerpo → temporal → de base → (hechizo viejo sin Salud) → armadura → vida. Lava, agua, ahogo, aplastar, caída y veneno pasan.
- El hechizo 🛡 (armas._escudo) usa j.activarEscudo si el módulo Salud está activo (si no, su esfera propia como antes).
- ✚ Recogible tipo 'escudo' "🛡 Escudo de fuerza": escudoSeg (0 = hasta romperse), escudoAguante (0 = no se rompe), escudoBloquea, escudoEstilo, escudoColor; figura: gema octaedro + esfera de campo pequeña. Preset escudoFuerza. "Solo si lo necesita" = no se recoge con uno temporal activo.
- Plantilla: recogible "Escudo de fuerza" cerca del inicio (-3.5, 0.8, 11).
- Probado: de base para 30 (vida intacta, 50→20, barra), se recarga a 50, recogible activa y para 40, hechizo, figura con campo; revisión general 0 errores.

## v0.46.77-dm — 🛡 El escudo de fuerza de base es solo VISUAL de la armadura
- Miguel lo quería así: la armadura (Quake o Halo) sigue igual y solo se VE como escudo de fuerza. Se quitó el "escudo de base" con aguante propio de v0.46.76 (j.fuerza / fuerzaAguante…: ya no existen; un proyecto con fuerzaBase se lee como burbuja = fuerzaEstilo, color = fuerzaColor).
- Salud ▸ 🛡 Escudo de fuerza (cómo se ve la armadura) [solo con armadura máx > 0]: burbuja (Nada | hexágonos | ondas), burbujaVer (golpe | siempre tenue según armadura), colorBurbuja. Destello donde pega, más fuerte al romperse, titila mientras se recarga. Una sola esfera (s.campoF) para armadura y extra.
- Escudo EXTRA (✚ recogible o hechizo 🛡): para antes que la armadura y mientras dura sale una SEGUNDA barra ⬡ (.fh-fza) en su color (aguante restante, o segundos si no se rompe); la esfera usa su color. Si su color es igual al de la armadura, pasa a dorado #ffcc4a. Recogible de serie: dorado.
- Plantilla: la armadura del Campo de pruebas se ve como hexágonos.
- Probado: golpe con armadura → esfera cian hex; recogible → esfera dorada, armadura intacta, segunda barra 70/100 dorada; revisión general 0 errores.

## v0.46.78-dm — 💥 Explosión al impactar · ✸ Ataque de área · 🛡 Escudo de mano
- 💥 Armas con explosión (cohetes, granadas…): armas._explosion usa FORJA.Explosiones.efecto (fuego, chispas, humo, destello; grupo reciclado) del color de la bala. explosiones.lanzar ya no daña dos veces a los enemigos (se saltan los objetivos con esEnemigo).
- ✸ motor/area.js (F.Area): esfera F.Campo reciclada (máx. 3 por juego). 'onda' = crece hasta el radio en `crecer` s, golpea una vez a cada objetivo (50 % en el borde) y empuja; 'aura' = sigue al jugador `dura` s, daña 4 veces/s (dano = por segundo), empuja poco. Daño por distancia, sin física. juego.js lo actualiza y lo quita al terminar.
- Módulo 'especial' (Vida y combate, apagado de serie): tecla B / botón central (acción 'especial'), botón táctil ✸, recarga propia, indicador fh-especial (✸ B / Ns).
- Tipo de arma '✸ Área' (grupo ✸ Área: forma, radio, empujón, crecer, dura, aspecto, color). Arma del pack "Nova arcana" (bastón, maná).
- 🛡 Escudo de mano (Armas ▸ 🛡 Escudo de mano: no | medieval | antimotines, aguante, bloquea %, lentitud) y recogible 'escudoMano' (presets Escudo medieval 120 / antimotines 200). Va en la mano libre; con arma de una mano el clic derecho CUBRE en vez de apuntar (frente ±70°, solo daño de enemigos), barra fh-escudomano; se rompe y desaparece (evento 'escudo-mano-roto'). Con armas de dos manos se guarda (a la espalda en 3ª persona).
- Plantilla: B = aura de fuego, recogibles Nova arcana, Escudo medieval y Escudo antimotines.
- Probado: aura 200→148, Nova 200→94, explosión de cohete, escudo para 30 y se rompe, capturas 1ª persona; revisión general 0 errores.

## v0.46.79-dm — 🛡 Escudo de mano en 3ª persona en la mano · 3 aspectos nuevos · ◎ pulso
- 🛡 3ª persona: el escudo de mano va sujeto al antebrazo de la mano libre (armas._otraMano: hueso hand_L/hand_R), la cara hacia el costado (un poco al frente) en reposo y al frente cubriéndose. El muñeco del motor (modelo.js) dobla el brazo libre al costado con escudo y lo sube delante del pecho al cubrirse (ya no ayuda a sujetar la pistola). Modelo importado sin esa pose: cubriendo, el escudo pasa delante del pecho. Sin huesos: como antes. A dos manos: a la espalda.
- ⬡ motor/campos.js: 3 aspectos más para todos los campos (escudo de fuerza, hechizo escudo, recogible, barrera, ataque de área): ⚡ rayos (arcos quebrados que saltan y parpadean), ◎ anillos (aros que suben + meridianos), 🔥 plasma (manchas que fluyen, suma de senos). N_ESTILO: ondas 0, hex 1, rayos 2, anillos 3, plasma 4.
- ◎ Pulso (2 esferas) en el ataque de área (módulo especial: pulso · arma: areaPulso): onda = una 2ª esfera sale después (½ de "crecer") hasta el 80 % del radio; aura = una esfera que late hacia fuera cada 0,75 s. Solo visual (no más daño); x.eco por hueco del grupo, creada la primera vez.
- Probado: posición del escudo medida (reposo: costado, cara al lado; cubriendo: delante del pecho a 1,18 m, cara al frente), capturas de los 5 aspectos y del pulso; 0 errores.

## v0.46.80-dm — 🛡 El escudo de mano gira con el personaje en 3ª persona
- armas._colocarEscudoMano (3ª): el frente y el costado salen del giro del MODELO (j.modelo, eje +Z en el mundo), no de j.yaw (la cámara). Antes, al caminar de lado o hacia atrás el personaje giraba y el escudo se quedaba orientado a la cámara. Sin modelo: j.yaw como antes.
- Probado: quieto, caminando a la derecha (modelo a 90° de la cámara) y hacia atrás (180°): el escudo queda igual respecto al cuerpo (costado izq. 0,34 m, cara 0,94 al costado). 0 errores.

## v0.46.81-dm — 🛡 El escudo de mano ya no se queda atrás (correr, saltar, montado)
- Armas (orden 55) corre antes que Modelo (60): el escudo de 3ª se colocaba con el personaje del cuadro anterior. Ahora, como el arma, se vuelve a colocar en j.alColocarModelo (s.escPend = [p, a], dt 0) cuando Modelo ya movió y animó al personaje.
- La base (espalda / pecho) sale de la posición del modelo (montado va en el asiento, no en los pies).
- Probado: distancia escudo–mano 0,08 m fija quieto, corriendo, saltando y montado a caballo. 0 errores.

## v0.46.82-dm — ✥ HUD libre (arrastrar piezas) · 🌐 Brújula esfera 3D (King's Field)
- ✥ Juego ▸ HUD ▸ Posiciones "Libre": en la vista previa cada pieza (borde punteado) se arrastra con el ratón o el dedo; al soltar se guarda hud.libre[clase] = [x %, y %]. El punto es el borde o el centro según el tercio de la pantalla (cerca de la izquierda crece a la derecha, abajo crece hacia arriba…), así queda bien a cualquier tamaño. Lo no movido va como Esquinas (ZONAS.libre = esquinas). Botón "↺ Volver a colocar todo". La mira no se mueve.
- hud.js: colocar() marca cada pieza con data-fh-pieza (su primera clase; la brújula = fh-brujula) y en modo libre la pone suelta (.fh-libre, left/top en %). La vista previa añade ejemplos de ✸ especial y 🛡 escudo de mano si se usan.
- 🌐 Brújula 'esfera': canvas 80×80 pixelado; globo con luz arriba-izq., meridianos y paralelos cada 30° (ecuador marcado), letras sobre el ecuador (más grandes de frente, cardinales en el color de selección), lo de atrás tenue, marcadores como puntos, aguja fija abajo. Solo se redibuja si cambia rumbo, inclinación o marcadores. Opciones: Dónde (esquinas o "Abajo al centro", zona bc), Color de la esfera, "Se inclina al mirar arriba / abajo". Plantilla de HUD nueva "King's Field" (barras, esfera abajo al centro, sin mira).
- Probado: arrastre en la vista previa → libre {fh-municion:[50.4,13.4]} → en el juego la munición sale en ese sitio; esfera en juego girada e inclinada. 0 errores.

## v0.46.83-dm — 🌊 Materiales que se mueven · 🌬 Viento del nivel · 🍃 Hojas al viento · 🌐 Brújula en calidad baja
- render.js: grupo 🌊 Movimiento en la config de material (primitivas y modelos; lo usa aplicarConfig → aplicarMovimiento). Todo en la GPU con uTiempo y #define por efecto (sin efecto = sin coste): MOV_OLAS (dos trenes de olas en metros del mundo, eje Y del objeto), MOV_VIENTO (base quieta, punta con todo; dirección del mundo pasada al objeto; viento 'nivel' = U.uViento con ráfagas, o 'propio'), MOV_ONDEAR (onda a lo largo de X, fija en ondearBorde: en primitivas su borde izquierdo), MOV_ONDULAR (UV en ondas). Uniformes por material en mat.userData.mov; horneado.js los copia (copiarMovimiento). Con instancias/lotes usa su matriz.
- Primitivas con olas/viento/ondear se parten cada 0,5 m (máx. 64). Atajos en el inspector (movAtajo): Quieto, Río, Mar, Pasto, Árbol, Bandera, Lava. Solo visual: la colisión no se mueve.
- 🌬 Escena ▸ Ambiente ▸ Viento: dirección, fuerza, ráfagas → U.uViento (ponerViento al aplicar el ambiente; ráfagas en _render). Sin viento queda brisa fija 0,25. La lluvia (clima.js) cae inclinada y se desplaza con él.
- 💧 Agua: Oleaje (altura, largo, velocidad, dirección; superficie partida ~1 m, máx. 64×64) y "El juego las nota (flotar)": en(x,y,z) pone v.top = top0 + F.Render.alturaOla (misma cuenta que el shader) → nadar, botes y enemigos suben y bajan. Apagado: solo visual.
- ✨ Partículas tipo 🍃 Hojas al viento (modo 4): caen meciéndose, rombo que gira y se aplana al voltearse, color entre los dos, se las lleva el viento del nivel.
- 🌐 Brújula esfera: Calidad Alta (80 px) · Media (48 px, solo N E S O) · Baja/PS1 (28 px, 3 tonos planos, líneas cada 45°, solo las de delante).
- Campo de pruebas: bandera roja que ondea en el poste, hojas al viento, la piscina con oleaje que se nota al nadar.
- Probado: 3 materiales con movimiento compilan sin errores, olas en 3 puntos (−0,06 / −0,24 / −0,19 m), viento con ráfaga, capturas. 0 errores.

## v0.46.84-dm — 🌊 Movimiento también en el inspector de la entidad modelo
- Miguel no lo encontraba: en "Materiales y texturas" de un modelo (inspector de la entidad) solo salían textura y 💡. Ahora cada material trae un plegable "🌊 Movimiento" (Fluir X/Y + atajos + ondular, oleaje, viento, ondear; ESQUEMA_MOV). Se abre solo si ya tiene alguno ("· activo"). Guarda con guardarMaterial (afecta a todas las copias del modelo, como la textura).
- Probado: modelo de prueba con material "agua" → atajo Mar → config guardada (olas, ondular, fluir) y "· activo". 0 errores.

## v0.46.85-dm — 🌊 Flotar también en lagos y mares de MODELOS
- Antes solo la entidad 💧 Agua notaba las olas. Ahora el material de un modelo (Movimiento ▸ Oleaje) tiene "El juego las nota (flotar)" (olasJuego): aplicarMovimiento guarda mat.userData.movCfg; Agua._mapaAlturas lo lee de la malla del líquido (olaCfg, caja más alta por las crestas) y en() suma F.Render.alturaOla a la altura del mapa → nadar, botes y enemigos suben y bajan.
- Lagos con aspecto "ondas del motor" (marcarModelo cambia el material): ahora se quedan con el movimiento del material del modelo (copiarMovimiento + movCfg).
- Probado: lago de modelo con oleaje 0,6 m → la superficie para el juego cambia con el tiempo (+0,13 / +0,03 / −0,09). 0 errores.

## v0.46.86-dm — 🌾 Pasto encima de un material (matas en tarjetas)
- A Miguel no le convenció mecer un objeto entero. Nuevo motor/pasto.js: en el material (Movimiento ▸ 🌾 Pasto encima: matas/m², alto, ancho, color raíz y punta, variación, cuánto lo mueve el viento, se ve hasta) y al jugar se siembran matas en las caras de ese material que miran arriba (n.y ≥ 0,7). Funciona en primitivas y en modelos (terrenos).
- Mata = 2 planos cruzados con hojas recortadas (textura 32 px del motor), normales hacia arriba (se ilumina como el suelo), color raíz→punta en el shader, variación por mata (instanceColor). InstancedMesh por zona de 16 m (frustum culling por zona), las lejanas se encogen en el vértice hasta desaparecer (pastoLejos). Viento en la punta (MOV_VIENTO con vientoAlto 1 de la mata; del nivel o propio). Azar con semilla: siempre igual. Tope 30 000 matas.
- render.aplicarConfig guarda mat.userData.pastoCfg; juego.js siembra antes de hornear y quita al detener. El atajo "Pasto" ahora pone pasto encima (ya no mece el objeto); "Quieto" también lo quita.
- Solo se ve al jugar (no en la vista del editor).
- Probado: losas del Campo de pruebas con 4 matas/m² → 17 280 matas en 20 dibujos, capturas en 1ª y 3ª persona. 0 errores.

## v0.46.87-dm — 🌾 El pasto sale en modelos y también en el editor
- Miguel lo activó y no salía. Dos causas: (1) solo se sembraba al jugar; (2) "mira hacia arriba" salía de la cara (producto cruz), y en modelos exportados con el orden de vértices al revés daba hacia abajo → sin pasto. Ahora usa las normales del modelo si las trae (promedio de los 3 vértices con la matriz normal); si no, la cara.
- Vista previa en el editor: F.Pasto.vistaEditor(vista) siembra en la vista del editor ½ s después de cada cambio (escena / entidad reconstruida y guardarLocal) y lo quita al jugar (el juego siembra el suyo); al volver, se resiembra.
- Probado: terreno de modelo con vértices al revés y material con pasto → 400 matas en el editor, 400 al jugar, vuelve al detener. 0 errores.

## v0.46.88-dm — 🌾 Pasto por zonas alrededor de la cámara · 🧍 Jugador visible en el editor · rig del generador revisado
- Pasto: en el terreno de Miguel no salía. Causa probable: terreno grande → el tope de 30 000 matas se llenaba en el orden de los triángulos (lejos del jugador) y lo lejano se encoge → nada a la vista. Ahora motor/pasto.js guarda los triángulos que miran arriba por zonas de 16 m (los grandes se parten por su lado largo hasta caber) y un "sensor" (malla vacía con onBeforeRender, ~6 veces/s) llena las zonas cercanas a la cámara (≤ Se ve hasta + 12 m) y borra las lejanas. Mismo azar por zona. Sirve igual en el editor y al jugar, y para terrenos de cualquier tamaño. Máx. 4000 matas por zona.
- 🧍 Módulo Modelo ▸ "Verlo en el editor (en el inicio)" (verEnEditor, de serie sí): el marcador de inicio principal lleva el personaje (GLB: primer cuadro de idle si lo trae; sin modelo: el muñeco con sus colores) mirando hacia la flecha; la cápsula queda tenue. Se refresca al cambiar el módulo Modelo. Al jugar el marcador se esconde como siempre.
- Revisado generador_personajes_retro_v1.92 (carpeta Alternativa): humanoides con Hips, Spine, Chest, Neck, Head, UpperArm/Forearm/Hand(hand_ con la casilla de Godot)_L/R, Thigh/Shin/Foot_L/R = rig del motor; exporta de serie "Del generador · reposo del motor" (brazos colgando, huesos sin giro) y lleva DENTRO una copia de motor/animbase.js idéntica a la del motor; nombres de clips iguales a los que busca el módulo Modelo (alias walk_c/crouch_walk, dash/dodge, death/die). "Reposo en T" no recibe las animaciones extra del motor (avisado en el propio generador). No hizo falta cambiar nada.
- Probado: terreno de 300 m en 2 triángulos → 39 zonas vivas alrededor (≈37 000 matas), editor y juego; muñeco en el inicio del editor; 0 errores.

## v0.46.89-dm — ⚔ Combate · fase 1: sensación de golpe
- Plan de combate acordado con Miguel (todo con ajustes y estilos que elige el creador): 1) sensación de golpe ✔ · 2) clic derecho a elegir Apuntar / Fijar objetivo / Bloquear + tecla propia para cada uno, fijar objetivo · 3) enemigos que avisan antes de atacar + equilibrio (romperlo = aturdido) + remate · 4) habilidades: ataque cargado, en caída, contraataque tras parry, esquiva perfecta con cámara lenta · 5) animaciones base de combos cuerpo a cuerpo en el editor (motor/animbase.js) · 6) ritmo y premio: contador de combo/estilo, críticos y puntos débiles, botín, arenas.
- Nuevo módulo jugador/modulos/combate.js "Combate (sensación de golpe)" (Vida y combate, activo de serie, orden 54). Escucha 'enemigo-danado' (solo golpes del jugador: sin info.de, sin tic ni líquido): pausa de impacto (juego.lento(0.04, ms): cuerpo a cuerpo / a distancia / al matar), temblor, empujón hacia atrás (no a jefes ni fijos), números de daño opcionales (10 cajitas HTML recicladas, amarillos si quita ≥ 25 % de su vida).
- Estilo: Aventura / Souls / Acción / Propio (ESTILOS del módulo). Nuevo gancho de módulos alCambiar(k, v, valores): el inspector lo llama y repinta si devuelve true (el estilo pone sus valores; tocar otro valor pasa a Propio).
- juego.lento(k, seg): el mundo va a k de velocidad unos segundos reales (manda el más largo).
- Probado: golpe cuerpo a cuerpo con estilo Acción → pausa 90 ms, empujón 5 m/s, temblor, número "20". 0 errores.

## v0.46.90-dm — ⚔ Combate que sí se nota · 🌾 pasto apagado por ahora
- Miguel no notó nada del combate: (1) valores muy suaves (50 ms, temblor 0,15); (2) el empujón sumaba velocidad y la IA del enemigo la frenaba en ~0,1 s (casi no se movía); (3) los proyectos guardados se quedaban con esos valores.
- Ahora: estilos más fuertes (Aventura 90/25/180 ms, temblor 0,3, empujón 0,8 m; Souls 120/30/250; Acción 140/40/280, 1,6 m, números), retroceso de verdad en enemigos.js (E.retro: el enemigo deja de andar 0,22 s y sale echado los metros pedidos, frenando; se corta contra pared), sonido de golpe seco del motor (sonidoGolpe). Migración en normalizarProyecto (combate.v2): los proyectos con los valores viejos pasan a los del estilo.
- 🌾 Pasto apagado (parpadeaba): no se siembra al jugar ni en el editor y no sale en el material. El código sigue en motor/pasto.js para rehacerlo solo alrededor del jugador.
- Probado: proyecto con combate viejo → migrado; golpe real con clic y cuchillo → evento, pausa, retroceso 0,55 m. 0 errores.

## v0.46.91-dm — ⚔ Combate fase 2: clic derecho a elegir, fijar objetivo, tecla de bloquear · armas con el generador v1.95
- Combate ▸ 🎯 Clic derecho y fijar objetivo: clicDerecho = arma (como antes: apuntar / guardia según el arma) | apuntar | fijar | bloquear. Acciones nuevas en Entrada: fijar (T) y bloquear (H), con nombre en Opciones ▸ Controles. armas.entrada: con Combate, el clic derecho hace solo lo elegido y la tecla Bloquear siempre levanta la guardia (o cubre con el escudo de mano).
- 🔒 Fijar objetivo (combate.entrada): elige el enemigo vivo no aliado más centrado (±70°, ≤ fijarDistancia) y gira yaw/pitch del jugador hacia su pecho (fijarGiro); moverse de lado = rodearlo. Modo pulsar o mantener; se suelta si muere o se aleja 1,5×. Marca: rombo HTML (.fh-fijado) proyectado sobre su cabeza. j.fijado = el enemigo.
- 🦴 Probado con un personaje generado por generador_personajes_retro_v1.95 (su núcleo cargado en el editor: FORJA_GENERADORES['forja-personajes@2'].generar): 17 huesos del rig del motor, 15 clips + los del motor. Armas en la mano correctas en reposo y apuntando (pistola, rifle, rayo, cuchillo, espada, hacha, lanza). Corregido: en guardia la postura de apuntar le bajaba el brazo (arma de lado a la cintura) → ahora manda "block" (arma de pie delante, como el muñeco); hacha y lanza en guardia: postura nueva hold_guard2 en motor/animbase.js (mango cruzado delante con IK de las dos manos, = muñeco) y armas.js la trata como agarre a dos manos.
- ⚠ motor/animbase.js cambió (hold_guard2): el generador lleva una copia dentro; conviene actualizarla allí.
- Probado: clic derecho = fijar → fijado, giro 0,5 rad, marca; T suelta; H con espada = guardia. 0 errores.

## v0.46.92-dm — ⚔ Combate fase 3: enemigos que avisan, equilibrio y remate
- Combate ▸ ⚠ Enemigos: aviso, equilibrio y remate (también en los 3 estilos):
  - Aviso: enemigos.aviso = { color, minimo, sonido } (lo pone combate.iniciar). En 'anticipar' el enemigo parpadea en su color (destello compartido tipo 'a' en _destello) y suena un "ting" (si no tiene sonido de ataque propio); la anticipación dura al menos avisoMin.
  - Equilibrio: E.postura sube con cada golpe del jugador (cuerpo a cuerpo ×1, distancia ×0,35) hasta vida × equilibrioK (jefes ×2); lleno → EN.aturdir(aturdeEquilibrio), "¡ROTO!", evento 'enemigo-roto'. Se recupera ¼/s tras 2 s sin golpes. Barra amarilla bajo la marca de fijar objetivo (roja si está aturdido).
  - Remate: golpe cuerpo a cuerpo a un aturdido (equilibrio o parry) → cámara lenta 0,45 s, temblor fuerte, "¡REMATE!", mata (o ×3 si remateMata = no; los jefes nunca mueren de un remate). Aviso en pantalla "⚔ ¡REMÁTALO!" con un aturdido a < 3,5 m delante. Evento 'enemigo-rematado'.
- Botón táctil ◈ Fijar (módulo Combate).
- Probado: el enemigo entra en 'anticipar' con el destello de aviso; 7 golpes rompen el equilibrio (54) → aturdido; aviso de remate; el remate lo mata con cámara lenta. 0 errores.

## v0.46.93-dm — ⚔ Combate fases 4 y 5: habilidades y combos
- 🗡 Combos (Combate ▸ Combos): armas.js pregunta j.alGolpear(arma) en cada golpe cuerpo a cuerpo y recibe el movimiento { nombre, mult, alcance, cono, empuje, lanzar, aturde, avance, giro, dur, cadencia, anims, figura }. Movimientos (combate.MOVS): tajo, estocada, giro (cono −1: todo alrededor + vuelta entera del modelo), lanzador (sube al enemigo), barrido (aturde 0,9 s), fuerte. Combo por arma: Juego ▸ Armas ▸ ⚔ Combo / Combo con pausa (texto "tajo, tajo, giro"; vacío = el de su estilo: corta / larga / dosManos / lanza en combate.COMBOS). Ventana = cadencia del arma + 0,3 + comboVentana; con pausa (≥ 0,3 s más) sigue por la otra rama. Embestida al atacar corriendo (avance 7). Cola de golpe: un clic durante el golpe anterior se guarda 0,4 s.
- 💫 Habilidades: ataque cargado (mantener atacar ≥ cargaTiempo en tiempo real, anillo alrededor de la mira, "ting" al estar listo; al soltar, j.golpeEspecial → giro ×cargaMult a todo alrededor) · ataque en caída (atacar en el aire con cuerpo a cuerpo: picado a −22 m/s, al tocar suelo onda F.Area con el daño del arma × caidaMult, polvo, temblor; j.ataqueTomado evita el golpe normal) · contraataque (tras el evento 'parry', contraVentana s: el siguiente golpe ×contraMult y aturde) · esquiva perfecta ('jugador-esquiva' con un enemigo a < 4,5 m a punto de golpear → juego.lentoEnemigos(0,25, perfectaLento): solo los enemigos van lentos).
- La pausa de impacto y el empujón crecen con los golpes fuertes (info.golpe / info.empuje).
- Animaciones: motor/animbase.js con slash2 (tajo horizontal de vuelta), slash3 (fuerte desde arriba), upper (lanzador), sweep (barrido agachado), spin, plunge; modelo.js usa la que pida el movimiento (si el modelo la tiene) y hace la vuelta entera en el giro. El muñeco: variantes 'reves' (de abajo arriba) y 'bajo' (agachado) de su golpe.
- ⚠ motor/animbase.js cambió otra vez: actualizar la copia del generador.
- Probado: espada → tajo, tajo, giro y vuelve a empezar; cargado al soltar; caída con onda; contraataque tras parry; esquiva perfecta → enemigos a 0,25. 0 errores.

## v0.46.94-dm — 🛡 Parry con gracia, música del nivel, espadón y escudo a la espalda
- Parry estilo Doom TDA: Combate ▸ 🛡 Parry (parryGracia s extra, parryEscudo, parryProyectiles, parryVerde, parryPausa ms). armas.enParry() → 'escudo'/'arma'; j.alDesviar(b) devuelve balas frontales (b.devuelta, ×2 daño). enemigos: aviso verde/naranja, balas verdes = desviables.
- Música: F.Audio.musica(id,{volumen,inicio,fin,fundido}) con fundido cruzado y bucle por región (setInterval 25 ms). Nivel: musicaVolumen/Inicio/Fin/Fundido + botones probar. Mecanismos: acciones 'musica' y 'musicaNivel'.
- Espadón: estilo cuerpo 'espadon' (mandoble/claymore…), arma 'Mandoble' en pack; animbase hold_great, hold_great_g, great; combos propios.
- Escudo de mano: tecla N (acción 'escudo') guarda/saca; con arma a 2 manos o guardado cuelga en la espalda (j.escudoGuardado).
- motor/animbase.js cambió → actualizar la copia del generador.

## v0.46.95-dm — 🎵 Onda de la música (bucle visual tipo Godot)
- editor/onda-musica.js: Ed.ondaMusica(cont, idAsset, valores, {kIni,kFin,volumen,alCambiar,alSoltar}). Decodifica (cache por asset), dibuja la onda, asas verde (inicio) / roja (fin), clic = escuchar desde ahí, rueda = zoom, botón der./central o Mayús = desplazar, doble clic = todo; línea de reproducción; imán a cruce por cero ±15 ms; zoom se conserva (vistas).
- Usado en Escena ▸ Nivel (musicaInicio/musicaFin) y en la acción 🎵 Cambiar la música de los disparadores (inicio/fin). Sustituye los botones Probar.
