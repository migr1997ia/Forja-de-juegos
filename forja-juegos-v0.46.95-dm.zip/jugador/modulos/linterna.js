/* Módulo LINTERNA — F / R3 (o botón táctil) enciende y apaga.
   - Un foco (SpotLight) que sale de los ojos (1ª persona) o del pecho (3ª) hacia donde miras, con un poco de retraso
     al girar (se siente en la mano). Siempre está en la escena (apagada = intensidad 0): encender no recompila nada.
   - Batería opcional (el creador elige): se gasta encendida, parpadea al final y se apaga; las 🔋 pilas (recogible
     "Pilas") la recargan. Barra en el HUD solo si hay batería.
   - Sombras opcionales (apagadas de serie: con sombras cuesta GPU).
   - Los enemigos ven la luz (enemigos.js): te ven desde más lejos y, si los alumbras, aunque no miren hacia ti.
   Lo que usan los demás:  j.linterna = { on, pos, dir, alcance, angulo }  ·  j.recargarLinterna(cantidad, soloSiFalta) */
FORJA.registrarModulo({
  nombre: 'linterna',
  etiqueta: 'Linterna',
  descripcion: 'F / R3 la enciende. Batería opcional con pilas para recargar. Los enemigos ven su luz.',
  orden: 40,
  activoPorDefecto: false,
  props: [
    { k: 'modo', t: 'sel', e: 'Cómo alumbra', def: 'proyectada', op: [['proyectada', '🔦 Proyectada (retro, se pega a las paredes)'], ['luz', '💡 Luz de verdad (foco)'], ['imagen', '🖼 Imagen en pantalla (la más barata)'], ['antorcha', '🔥 Antorcha (luz alrededor que tiembla)']],
      ayuda: 'Proyectada: el círculo de la textura se pinta sobre paredes, suelo y enemigos, con luz en escalones estilo PS1; muy barata y alumbra también lo horneado. Luz de verdad: un foco de three.js (sombras opcionales, cuesta más GPU). Imagen: un círculo fijo en la pantalla que aclara, casi gratis. Los enemigos la ven igual en los tres' },
    { k: 'textura', t: 'sel', e: 'Forma del haz', def: 'redonda', si: (v) => !v.modo || v.modo === 'proyectada',
      op: [['redonda', '⚪ Redonda (escalones, borde marcado)'], ['anillo', '◎ Con anillo (reflector)'], ['vieja', '🟤 Vieja (cristal sucio, desigual)']] },
    { k: 'bandas', t: 'bool', e: 'Luz en escalones (PS1)', def: true, si: (v) => !v.modo || v.modo === 'proyectada' || v.modo === 'antorcha', ayuda: 'La luz baja en saltos en vez de degradado, como en la PS1' },
    { k: 'empiezaEncendida', t: 'bool', e: 'Empieza encendida', def: false },
    { k: 'color', t: 'color', e: 'Color de la luz', def: '#fff2d6', si: (v) => v.modo !== 'antorcha' },
    { k: 'intensidad', t: 'num', e: 'Intensidad', def: 6, paso: 0.5, min: 0.5 },
    { k: 'alcance', t: 'num', e: 'Alcance (m)', def: 18, paso: 1, min: 3, si: (v) => v.modo !== 'antorcha' },
    { k: 'angulo', t: 'num', e: 'Apertura (°)', def: 32, paso: 2, min: 8, max: 80, si: (v) => v.modo !== 'antorcha' },
    { k: 'suave', t: 'rango', e: 'Borde suave', def: 0.45, min: 0, max: 1, paso: 0.05, si: (v) => v.modo !== 'antorcha' },
    { k: 'retraso', t: 'rango', e: 'Retraso al girar', def: 0.35, min: 0, max: 0.9, paso: 0.05, ayuda: 'Un poco de inercia: la luz va detrás de la vista, como en la mano', si: (v) => v.modo !== 'antorcha' },
    { grupo: '🔥 Antorcha', si: (v) => v.modo === 'antorcha' },
    { k: 'colorFuego', t: 'color', e: 'Color del fuego', def: '#ffa04a' },
    { k: 'alcanceFuego', t: 'num', e: 'Alumbra hasta (m)', def: 9, paso: 0.5, min: 2, ayuda: 'Radio alrededor de la antorcha' },
    { k: 'tiembla', t: 'rango', e: 'Cuánto tiembla', def: 0.25, min: 0, max: 1, paso: 0.01, ayuda: '0 = fija · 1 = llega a apagarse un instante' },
    { k: 'velTiembla', t: 'rango', e: 'Velocidad del temblor', def: 8, min: 0.5, max: 20, paso: 0.5 },
    { k: 'chispazos', t: 'rango', e: 'Bajones bruscos', def: 0.15, min: 0, max: 1, paso: 0.01, ayuda: 'Probabilidad por segundo de un bajón fuerte de la llama' },
    { k: 'verAntorcha', t: 'bool', e: 'Se ve la antorcha', def: true, ayuda: 'Un palo con su llama en la mano izquierda' },
    { grupo: 'Luz', si: (v) => v.modo !== 'antorcha' },
    { k: 'tamImagen', t: 'rango', e: 'Tamaño del círculo', def: 0.45, min: 0.15, max: 1, paso: 0.05, si: (v) => v.modo === 'imagen' },
    { k: 'sombras', t: 'bool', e: 'Proyecta sombras', def: false, si: (v) => v.modo !== 'imagen' && v.modo !== 'antorcha', ayuda: 'Más bonita pero cuesta GPU (una sombra más que dibujar cada cuadro). Necesita "Luces y sombras" en Render' },
    { grupo: 'Batería' },
    { k: 'bateria', t: 'bool', e: 'Se gasta (batería / combustible)', def: false, ayuda: 'Se gasta encendida y se recarga con 🔋 Pilas (recogible). Sin esto dura para siempre. En la antorcha: el fuego se consume' },
    { k: 'duracion', t: 'num', e: 'Dura (s encendida)', def: 180, paso: 10, min: 5, si: (v) => v.bateria },
    { k: 'cargaInicial', t: 'rango', e: 'Carga al empezar', def: 1, min: 0, max: 1, paso: 0.05, si: (v) => v.bateria },
    { k: 'parpadeo', t: 'bool', e: 'Parpadea con poca carga', def: true, si: (v) => v.bateria },
    { grupo: 'Sonido' },
    { k: 'sonido', t: 'asset', e: 'Al encender / apagar', tipoAsset: 'audio', vacio: '(clic del motor)' },
    { k: 'enemigosLaVen', t: 'bool', e: 'Los enemigos ven la luz', def: true, ayuda: 'Encendida te ven desde más lejos, y si alumbras a uno te ve aunque no te mire. Apagarla es esconderse' },
  ],

  iniciar(j, p, s) {
    const T = THREE, esc = j.juego.vista.escena;
    s.pos = new T.Vector3();
    s.mira = new T.Vector3();
    s.proy = p.modo !== 'imagen';   // proyectada, y en "luz de verdad" para lo horneado (que el foco no alumbra)
    s.fuego = p.modo === 'antorcha';
    if (s.fuego) {
      // 🔥 la antorcha que se ve: un palo y su llama (sprite que tiembla); temblor como el del FW (3 senos + bajones)
      s.ft = 0; s.off = Math.random() * 100; s.spT = 0.5; s.spV = 0;
      if (p.verAntorcha !== false) {
        const c = document.createElement('canvas'); c.width = c.height = 32;
        const g = c.getContext('2d');
        for (let i = 4; i >= 1; i--) { g.fillStyle = `rgba(255,255,255,${(5 - i) / 4})`; g.beginPath(); g.ellipse(16, 18, i * 3.2, i * 3.9, 0, 0, 7); g.fill(); }
        const tex = new T.CanvasTexture(c); tex.magFilter = T.NearestFilter;
        s.antorcha = new T.Group();
        const palo = new T.Mesh(new T.BoxGeometry(0.035, 0.38, 0.035), FORJA.Render.hacerRetro(new T.MeshLambertMaterial({ color: 0x5a3a22 })));
        palo.position.y = -0.2;
        s.llama = new T.Sprite(new T.SpriteMaterial({ map: tex, color: p.colorFuego || '#ffa04a', transparent: true, blending: T.AdditiveBlending, depthWrite: false }));
        s.llama.scale.set(0.16, 0.22, 1);
        s.antorcha.add(palo, s.llama);
        s.antorcha.userData.ayudaEditor = true;
        s.antorcha.visible = false;
        s.texAntorcha = tex;
        esc.add(s.antorcha);
      }
    }
    if (p.modo === 'imagen') {
      // 🖼 un círculo de luz en pantalla que solo ACLARA (mezcla "trama": lo negro no cambia nada); sin luces ni GPU
      const c = new T.Color(p.color), rgb = `${Math.round(c.r * 255)},${Math.round(c.g * 255)},${Math.round(c.b * 255)}`;
      const r = Math.round(p.tamImagen * 100);
      s.capa = document.createElement('div');
      s.capa.style.cssText = `position:absolute;inset:0;pointer-events:none;z-index:2;mix-blend-mode:screen;opacity:0;transition:opacity .08s;
        background:radial-gradient(circle at 50% 50%, rgba(${rgb},.55) 0, rgba(${rgb},.38) ${r * 0.35}vmin, rgba(${rgb},.16) ${r * 0.7}vmin, rgba(${rgb},0) ${r}vmin);`;
      j.juego.vista.contenedor.appendChild(s.capa);
    } else if (p.modo === 'luz') {
      s.luz = new T.SpotLight(p.color, 0, p.alcance, p.angulo * FORJA.DEG / 2, p.suave, 1.4);
      s.luz.castShadow = !!p.sombras;
      if (p.sombras) { s.luz.shadow.mapSize.set(512, 512); s.luz.shadow.camera.near = 0.2; s.luz.shadow.bias = -0.002; }
      s.blanco = new T.Object3D();
      s.luz.target = s.blanco;
      esc.add(s.luz, s.blanco);
    }
    s.dir = new T.Vector3(0, 0, -1);
    s.tmp = new T.Vector3();
    s.on = !!p.empiezaEncendida;
    s.carga = p.bateria ? p.cargaInicial : 1;
    s.parp = 0;
    j.linterna = { on: s.on, pos: new T.Vector3(), dir: new T.Vector3(0, 0, -1), alcance: s.fuego ? p.alcanceFuego || 9 : p.alcance, angulo: s.fuego ? 360 : p.angulo, bateria: p.bateria ? s.carga : null, veEnemigo: p.enemigosLaVen !== false };
    // pilas: devuelve true si sirvió
    j.recargarLinterna = (cantidad, solo) => {
      if (!p.bateria) return !solo;
      if (solo && s.carga >= 0.999) return false;
      s.carga = Math.min(1, s.carga + (cantidad || 50) / 100);
      s.vista = -1;
      return true;
    };
    // 🔥 3ª persona: el módulo Modelo llama esto después de animar → la antorcha va pegada a la mano (como las armas)
    if (s.fuego) j.alColocarAntorcha = () => {
      if (!s.on || !j.modoCamara || j.modoCamara === 'fps') return;
      const mano = this._manoAntorcha(j, s);
      if (!mano) return;
      j.modelo.updateMatrixWorld(true);
      mano.getWorldPosition(s.pos);
      s.pos.y += 0.22;   // el puño agarra el palo por la mitad: la llama queda por encima de la mano
      if (s.antorcha) s.antorcha.position.copy(s.pos);
      FORJA.Render.U.uLinPos.value.copy(s.pos);
      if (j.linterna) j.linterna.pos.copy(s.pos);
    };
    // la partida guardada (juego.estado / ponerEstadoJugador)
    j.ponerCargaLinterna = (c) => { if (p.bateria && typeof c === 'number') { s.carga = Math.max(0, Math.min(1, c)); s.vista = -1; } };
  },

  entrada(j, p, s) {
    if (j.muerto) return;
    if (FORJA.Entrada.pulsado('linterna')) {
      if (!s.on && p.bateria && s.carga <= 0) { this._clic(p, 0.6); return; }   // sin pilas: solo el clic
      s.on = !s.on;
      this._clic(p, s.on ? 1.3 : 0.9);
    }
  },

  // 🔥 la mano libre para la antorcha: la contraria a la del arma (hand_L si el arma va en la derecha)
  _manoAntorcha(j, s) {
    const pa = j.props && j.props('armas'), armaIzq = !!(pa && pa.manoTps === 'izquierda');
    if (s.manoDe !== j.modelo || s.manoArmaIzq !== armaIzq) {
      s.manoDe = j.modelo; s.manoArmaIzq = armaIzq; s.mano = null;
      const re = armaIzq ? /^(hand_?r|mano_?d|righthand|hand\.r|mixamorig:righthand)$/i : /^(hand_?l|mano_?i|lefthand|hand\.l|mixamorig:lefthand)$/i;
      if (j.modelo) j.modelo.traverse((o) => { if (!s.mano && re.test(o.name)) s.mano = o; });
    }
    return s.mano;
  },

  _clic(p, tono) {
    if (p.sonido) FORJA.Audio.efecto(p.sonido);
    else FORJA.Audio.sintetico('golpe', { volumen: 0.25, tono: 2.5 * tono });
  },

  despues(j, p, s, dt) {
    const cam = j.camara;
    if ((!s.luz && !s.capa && !s.proy) || !cam) return;
    // batería
    if (s.on && p.bateria) {
      s.carga = Math.max(0, s.carga - dt / Math.max(1, p.duracion));
      if (s.carga <= 0) { s.on = false; this._clic(p, 0.6); }
    }
    // de dónde sale: 1ª persona los ojos (un poco abajo a la derecha, como en la mano); 3ª el pecho del jugador,
    // y en 3ª apunta al punto de la MIRA (lo que hay en el centro de la pantalla), no paralela a la cámara
    const tps = j.modoCamara && j.modoCamara !== 'fps';
    cam.getWorldDirection(s.tmp);
    if (j.camFija) s.tmp.set(-Math.sin(j.yaw), -0.08, -Math.cos(j.yaw)).normalize();   // 📷 cámaras fijas: hacia donde mira el cuerpo
    const meta = s.mira;
    if (tps) {
      s.pos.set(j.cuerpo.pie.x, j.cuerpo.pie.y + j.cuerpo.altura * 0.75, j.cuerpo.pie.z);
      const o = cam.getWorldPosition(meta), M = j.mundo;
      const g = M && M.rayo(o.x, o.y, o.z, s.tmp.x, s.tmp.y, s.tmp.z, p.alcance * 2);
      meta.addScaledVector(s.tmp, g ? g.t : p.alcance * 2).sub(s.pos).normalize();
    } else {
      cam.getWorldPosition(s.pos).addScaledVector(meta.set(s.tmp.z, 0, -s.tmp.x).normalize(), -0.12).y -= 0.1;
      meta.copy(s.tmp);
    }
    if (s.fuego) {
      // en la mano izquierda: 1ª persona abajo a la izquierda de la vista · 3ª al lado del pecho, un poco adelante
      const yaw = j.yaw || 0, izq = s.tmp2 || (s.tmp2 = new THREE.Vector3());
      if (tps && this._manoAntorcha(j, s)) {
        // la pone en la mano el módulo Modelo al terminar de animar (j.alColocarAntorcha): aquí no se toca
      } else if (tps) {
        izq.set(-Math.cos(yaw), 0, Math.sin(yaw));
        s.pos.set(j.cuerpo.pie.x, j.cuerpo.pie.y + j.cuerpo.altura * 0.78, j.cuerpo.pie.z).addScaledVector(izq, 0.32).add(meta.set(-Math.sin(yaw), 0, -Math.cos(yaw)).multiplyScalar(0.25));
      } else {
        cam.getWorldPosition(s.pos);
        izq.set(-1, 0, 0).applyQuaternion(cam.quaternion);
        s.pos.addScaledVector(izq, 0.2).addScaledVector(s.tmp, 0.5).y -= 0.12;
      }
      meta.copy(s.tmp);
    }
    const k = Math.min(1, dt * (1 - p.retraso) * 22 + (p.retraso === 0 ? 1 : 0));
    s.dir.lerp(meta, k).normalize();
    if (s.luz) { s.luz.position.copy(s.pos); s.blanco.position.copy(s.pos).addScaledVector(s.dir, 5); }
    // intensidad (y parpadeo con poca carga)
    let I = s.on ? p.intensidad : 0;
    if (s.on && p.bateria && p.parpadeo && s.carga < 0.15) {
      s.parp -= dt;
      if (s.parp <= 0) s.parp = 0.05 + Math.random() * (s.carga * 6);
      if (s.parp < 0.05) I *= 0.15;
    }
    if (s.fuego && I > 0) {
      s.ft += dt * (p.velTiembla || 8);
      let n = (Math.sin(s.ft + s.off) * 0.5 + Math.sin(s.ft * 1.73 + s.off * 0.7) * 0.3 + Math.sin(s.ft * 2.97 + s.off * 1.3) * 0.2) * 0.5 + 0.5;
      n = Math.pow(n, 0.6);   // más tiempo brillante que oscuro
      s.spT -= dt;
      if (s.spT <= 0) { s.spT = 0.3 + Math.random() * 0.7; if (Math.random() < (p.chispazos ?? 0.15)) s.spV = 0.4 + Math.random() * 0.5; }
      s.spV = Math.max(0, s.spV - dt * 12);
      const t = p.tiembla ?? 0.25;
      s.mult = (1 - t * (1 - n)) * (1 - s.spV * t * 2);
      I *= Math.max(0, s.mult);
    }
    // 🔥 1ª persona: la antorcha va en el PRIMER PLANO (como el arma: no se mete en las paredes), en la mano izquierda,
    // con el mismo vaivén al caminar; en 3ª va en el mundo, en la mano del modelo
    const ppOn = !!(s.antorcha && s.on && !tps && !j.muerto);
    j.antorchaPP = ppOn;
    if (s.antorcha) {
      const pp = j.juego.vista.primerPlano && j.juego.vista.primerPlano();
      const destino = ppOn && pp ? pp.escena : j.juego.vista.escena;
      if (s.antorcha.parent !== destino) destino.add(s.antorcha);
      if (ppOn && pp) {
        pp.activo = true;
        const c = j.cuerpo, vh = Math.hypot(c.velocidad.x, c.velocidad.z), mueve = c.enSuelo && vh > 0.3;
        if (mueve) s.paso = (s.paso || 0) + dt * Math.PI * 2 * (j.corriendo ? 1.5 : 1);
        s.balF = (s.balF || 0) + ((mueve ? (j.corriendo ? 1.6 : 1) : 0) - (s.balF || 0)) * Math.min(1, dt * 8);
        const bx = -Math.cos(s.paso || 0) * 0.012 * s.balF, by = -Math.abs(Math.sin(s.paso || 0)) * 0.012 * s.balF;
        const loc = s.tmp3 || (s.tmp3 = new THREE.Vector3());
        loc.set(-0.2 + bx, -0.1 + by, -0.4).applyQuaternion(cam.quaternion);
        cam.getWorldPosition(s.antorcha.position).add(loc);
        s.antorcha.quaternion.copy(cam.quaternion);
      } else s.antorcha.quaternion.identity();
    }
    if (s.antorcha) {
      s.antorcha.visible = s.on;
      if (s.on) { if (!ppOn) s.antorcha.position.copy(s.pos); s.llama.position.y = 0.04; const m = 0.8 + 0.4 * (s.mult ?? 1); s.llama.scale.set(0.1 * m, 0.15 * m, 1); }
    }
    if (s.luz) s.luz.intensity = I;
    if (s.proy) this._proyectar(p, s, I);
    if (s.capa) s.capa.style.opacity = I > 0 ? Math.min(1, I / Math.max(0.1, p.intensidad)).toFixed(2) : '0';
    const L = j.linterna;
    L.on = s.on; L.pos.copy(s.pos); L.dir.copy(s.dir); L.bateria = p.bateria ? s.carga : null;
    // HUD: barra de batería (solo si hay batería)
    if (p.bateria) {
      const pct = Math.round(s.carga * 20) * 5, ver = s.on || s.carga < 0.999;
      if (pct !== s.vista || ver !== s.verBarra) {
        s.vista = pct; s.verBarra = ver;
        if (!s.barra) {
          s.barra = FORJA.Hud.pieza(j.juego, 'fh-aire fh-linterna', '<span>' + (s.fuego ? 'FUEGO' : 'LUZ') + '</span><div class="fh-aire-caja"><div class="fh-aire-lleno"></div></div>');
          s.barra.style.setProperty('--fh-color', '#f2e08a');
        }
        s.barra.classList.toggle('fh-ver', ver);
        s.barra.classList.toggle('fh-bajo', s.carga < 0.15);
        s.barra.lastChild.firstChild.style.width = pct + '%';
      }
    }
  },

  // uniforms de la linterna proyectada (render.js: los usa todo material retro)
  _proyectar(p, s, I) {
    const U = FORJA.Render.U, luz = p.modo === 'luz';
    U.uLinI.value = I > 0 ? I * (luz ? 0.1 : 0.22) : 0;
    U.uLinEsfera.value = s.fuego ? 1 : 0;
    if (I <= 0) return;
    if (s.fuego) {
      if (!s.colLin) { s.colLin = new THREE.Color(p.colorFuego || '#ffa04a'); s.texLin = FORJA.Render.texLinterna('redonda'); }
      U.uLinTex.value = s.texLin;
      U.uLinSolo.value = 0;
      U.uLinBandas.value = p.bandas !== false ? 5 : 0;
      U.uLinColor.value.copy(s.colLin);
      U.uLinPos.value.copy(s.pos);
      U.uLinDir.value.copy(s.dir);
      U.uLinAlc.value = (p.alcanceFuego || 9) * (0.94 + 0.06 * (s.mult ?? 1));   // el círculo de luz también respira
      return;
    }
    if (!s.texLin) {
      s.texLin = FORJA.Render.texLinterna(luz ? 'suave' : p.textura || 'redonda', p.suave);
      s.colLin = new THREE.Color(p.color);
    }
    U.uLinTex.value = s.texLin;
    U.uLinSolo.value = luz ? 1 : 0;
    U.uLinBandas.value = !luz && p.bandas !== false ? 6 : 0;
    U.uLinColor.value.copy(s.colLin);
    U.uLinPos.value.copy(s.pos);
    const d = U.uLinDir.value.copy(s.dir);
    const der = U.uLinDer.value.set(0, 1, 0);
    if (Math.abs(d.y) > 0.98) der.set(1, 0, 0);
    der.crossVectors(d, der).normalize();
    U.uLinArr.value.crossVectors(der, d);
    // la textura llena el cono (luz de verdad: el borde suave cae dentro del ángulo del foco)
    U.uLinTan.value = Math.tan(p.angulo * FORJA.DEG / 2);
    U.uLinAlc.value = p.alcance;
  },

  detener(j, p, s) {
    FORJA.Render.U.uLinI.value = 0;
    FORJA.Render.U.uLinEsfera.value = 0;
    if (s.antorcha) { s.antorcha.parent && s.antorcha.parent.remove(s.antorcha); s.texAntorcha.dispose(); s.antorcha = null; }
    if (s.luz) { s.luz.parent && s.luz.parent.remove(s.luz); s.blanco.parent && s.blanco.parent.remove(s.blanco); s.luz.dispose && s.luz.dispose(); s.luz = null; }
    if (s.capa) { s.capa.remove(); s.capa = null; }
    if (s.barra) s.barra.classList.remove('fh-ver');
    j.linterna = null;
    j.recargarLinterna = null;
    j.ponerCargaLinterna = null;
    j.alColocarAntorcha = null;
    j.antorchaPP = false;
  },
});
