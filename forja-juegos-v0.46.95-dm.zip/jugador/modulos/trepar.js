/* Módulo TREPAR — escaleras de mano 🪜 y cuerdas 🪢 (entidad "Escalera de mano", modelo escalera o cuerda).
   Cuerda: se agarra desde cualquier lado; izquierda / derecha giran a su alrededor.
   Ponte delante de su frente y empuja hacia ella (o salta contra ella): te agarras. Adelante / atrás = subir / bajar;
   arriba del todo sales hacia delante (al tejado, la cornisa); abajo, al tocar el suelo, te sueltas; Saltar te suelta
   hacia atrás. Mientras trepas no hay gravedad ni movimiento normal (j.trepando). Con modelo: animación "climb". */
FORJA.registrarModulo({
  nombre: 'trepar',
  etiqueta: 'Trepar (escaleras de mano)',
  descripcion: 'Subir y bajar escaleras de mano 🪜 con adelante / atrás.',
  orden: 15,
  activoPorDefecto: true,
  props: [
    { k: 'velocidad', t: 'num', e: 'Velocidad (m/s)', def: 2.4, paso: 0.1, min: 0.3 },
    { k: 'agarrarAlCaer', t: 'bool', e: 'Agarrarse al caer o saltar contra ella', def: true },
    { k: 'sonido', t: 'asset', e: 'Sonido de cada peldaño', def: '', tipoAsset: 'audio', vacio: '(golpecito del motor)' },
  ],

  iniciar(j, p, s) {
    const T = THREE;
    s.escalas = [];
    for (const ent of j.juego.escena.entidades) {
      if (ent.tipo !== 'escala' || ent.visible === false) continue;
      const obj = j.juego.objetos.get(ent.id);
      if (obj) s.escalas.push({ ent, obj, inv: new T.Matrix4(), cuerda: ent.forma === 'cuerda', alto: Math.max(0.5, (ent.params || {}).alto || 3), ancho: Math.max(0.2, (ent.params || {}).ancho || 0.6) });
    }
    s.en = null; s.paso = 0; s.l = new T.Vector3(); s.w = new T.Vector3(); s.n = new T.Vector3(); s.lado = new T.Vector3();
  },

  // posición local del jugador respecto a una escala (x a lo ancho, y altura de los pies, z delante = +)
  _local(j, s, E) {
    E.obj.updateWorldMatrix(true, false);
    E.inv.copy(E.obj.matrixWorld).invert();
    const sc = E.obj.getWorldScale(s.w);
    s.l.copy(j.cuerpo.pie).applyMatrix4(E.inv);
    s.l.x *= sc.x; s.l.y *= sc.y; s.l.z *= sc.z;
    return s.l;
  },

  entrada(j, p, s) {
    if (!s.escalas.length || j.muerto || j.nadando) { if (s.en) this._soltar(j, s); return; }
    const IN = FORJA.Entrada, c = j.cuerpo;
    if (s.en) {
      if (IN.pulsado('saltar')) {   // soltarse hacia atrás
        const E = s.en; this._soltar(j, s);
        if (E.cuerda) s.n.copy(s.lado); else s.n.set(0, 0, 1).transformDirection(E.obj.matrixWorld);
        c.velocidad.set(s.n.x * 3, 4, s.n.z * 3);
        s.espera = 0.35;
      }
      return;
    }
    if (s.espera > 0) return;
    // ¿agarrarse? delante de una, empujando hacia ella (o en el aire contra ella)
    const mx = IN.mover.x, my = IN.mover.y;
    // dirección de la entrada en el mundo (como movimiento.js): adelante = (-sin, -cos)
    const sin = Math.sin(j.yaw), cos = Math.cos(j.yaw);
    const dx = mx * cos - my * sin, dz = -mx * sin - my * cos;
    const enAire = !c.enSuelo && p.agarrarAlCaer;
    for (const E of s.escalas) {
      const L = this._local(j, s, E);
      if (L.y < -0.3 || L.y > E.alto - 0.2) continue;
      if (E.cuerda) {
        // 🪢 cuerda: desde cualquier lado, cerca de su eje
        const d = Math.hypot(L.x, L.z);
        if (d > c.radio + 0.45) continue;
        const pie = E.obj.getWorldPosition(s.w);
        s.lado.set(c.pie.x - pie.x, 0, c.pie.z - pie.z);
        if (s.lado.lengthSq() < 1e-4) s.lado.set(Math.sin(j.yaw), 0, Math.cos(j.yaw));
        s.lado.normalize();
        const hacia = -(dx * s.lado.x + dz * s.lado.z);
        if (hacia > 0.5 || (enAire && L.y > 0.3)) { s.en = E; j.trepando = true; c.velocidad.set(0, 0, 0); s.paso = 0; break; }
        continue;
      }
      if (Math.abs(L.x) > E.ancho / 2 + 0.15 || L.z < -0.1 || L.z > c.radio + 0.45) continue;
      s.n.set(0, 0, 1).transformDirection(E.obj.matrixWorld);
      const hacia = -(dx * s.n.x + dz * s.n.z);
      if (hacia > 0.5 || (enAire && L.y > 0.3)) { s.en = E; j.trepando = true; c.velocidad.set(0, 0, 0); s.paso = 0; break; }
    }
  },

  fisica(j, p, s, dt) {
    if (s.espera > 0) s.espera -= dt;
    const E = s.en;
    if (!E) return;
    const IN = FORJA.Entrada, c = j.cuerpo, L = this._local(j, s, E);
    // subir / bajar con adelante / atrás (mirando a la escalera; de espaldas, al revés no: siempre W = subir)
    const v = IN.mover.y * p.velocidad;
    c.velocidad.set(0, v, 0);
    if (E.cuerda) {
      // 🪢 alrededor de la cuerda: izquierda / derecha te hacen girar a su alrededor; pegado a su eje
      const giro = -IN.mover.x * 2.2 * dt, cg = Math.cos(giro), sg = Math.sin(giro);
      s.lado.set(s.lado.x * cg + s.lado.z * sg, 0, -s.lado.x * sg + s.lado.z * cg).normalize();
      const pie = E.obj.getWorldPosition(s.w), r = c.radio + 0.1;
      const k = Math.min(1, dt * 10) / Math.max(dt, 1e-3) * 0.5;
      c.velocidad.x += (pie.x + s.lado.x * r - c.pie.x) * k;
      c.velocidad.z += (pie.z + s.lado.z * r - c.pie.z) * k;
      s.n.copy(s.lado);
    } else {
    // pegado al frente, centrado
    s.n.set(0, 0, 1).transformDirection(E.obj.matrixWorld);
    const meta = c.radio + 0.12;
    const ex = Math.max(-E.ancho / 2 + 0.1, Math.min(E.ancho / 2 - 0.1, L.x)) - L.x, ez = meta - L.z;
    const r = s.w.set(1, 0, 0).transformDirection(E.obj.matrixWorld);
    const k = Math.min(1, dt * 10);
    c.velocidad.x += (r.x * ex + s.n.x * ez) * k / Math.max(dt, 1e-3) * 0.5;
    c.velocidad.z += (r.z * ex + s.n.z * ez) * k / Math.max(dt, 1e-3) * 0.5;
    }
    // peldaños: un golpecito cada 30 cm
    s.paso += Math.abs(v) * dt;
    if (s.paso > 0.3) { s.paso = 0; if (p.sonido) FORJA.Audio.efecto(p.sonido, { volumen: 0.6 }); else FORJA.Audio.sintetico('golpe', { volumen: 0.15, tono: 1.8 }); }
    j.mirarEscala = Math.atan2(-s.n.x, -s.n.z);   // el modelo mira a la escalera
    // arriba del todo: sale hacia delante (al otro lado de la escalera) · abajo en el suelo: se suelta
    if (v > 0 && L.y > E.alto - c.altura * 0.35) {
      this._soltar(j, s);
      c.velocidad.set(-s.n.x * 2.5, 3.2, -s.n.z * 2.5);
      s.espera = 0.4;
    } else if (v < 0 && (c.enSuelo || L.y < 0.02)) {
      this._soltar(j, s);
      s.espera = 0.3;
    }
  },

  _soltar(j, s) { s.en = null; j.trepando = false; j.mirarEscala = null; },
  detener(j, p, s) { this._soltar(j, s); },
});
