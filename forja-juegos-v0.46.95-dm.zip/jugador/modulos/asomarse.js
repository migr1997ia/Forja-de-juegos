/* Módulo ASOMARSE (lean) — Z / X (o los que elijas en Opciones) inclinan la cabeza para mirar tras una esquina sin
   salir: la cámara se corre de lado y se ladea. Un rayo corto evita asomar la cabeza a través de la pared.
   En 3ª persona corre la cámara de hombro. No se puede corriendo ni con cámaras fijas. j.asomado = −1…1 */
FORJA.registrarModulo({
  nombre: 'asomarse',
  etiqueta: 'Asomarse (lean)',
  descripcion: 'Z / X: inclinarse a izquierda o derecha para mirar tras una esquina.',
  orden: 13,                 // después de Cámara (10) y Balanceo (12): parte de la cámara ya colocada
  activoPorDefecto: false,
  props: [
    { k: 'distancia', t: 'num', e: 'Cuánto se corre (m)', def: 0.45, paso: 0.05, min: 0.1, max: 1 },
    { k: 'angulo', t: 'num', e: 'Ladeo (°)', def: 12, paso: 1, min: 0, max: 30 },
    { k: 'rapidez', t: 'num', e: 'Rapidez', def: 9, paso: 0.5, min: 1 },
    { k: 'mantener', t: 'bool', e: 'Mantener pulsado', def: true, ayuda: 'Si no: una pulsación se inclina y otra vuelve' },
  ],

  iniciar(j, p, s) { s.k = 0; s.fijo = 0; s.der = new THREE.Vector3(); },

  entrada(j, p, s) {
    const E = FORJA.Entrada;
    let quiero = 0;
    if (p.mantener) quiero = (E.mantenido('asomar_der') ? 1 : 0) - (E.mantenido('asomar_izq') ? 1 : 0);
    else {
      if (E.pulsado('asomar_izq')) s.fijo = s.fijo === -1 ? 0 : -1;
      if (E.pulsado('asomar_der')) s.fijo = s.fijo === 1 ? 0 : 1;
      quiero = s.fijo;
    }
    if (j.corriendo || j.camFija || j.trepando || j.nadando || j.muerto) { quiero = 0; s.fijo = 0; }
    s.meta = quiero;
  },

  despues(j, p, s, dt) {
    s.k += ((s.meta || 0) - s.k) * Math.min(1, dt * p.rapidez);
    if (Math.abs(s.k) < 0.002) { s.k = 0; j.asomado = 0; return; }
    const cam = j.camara, M = j.mundo;
    // a la derecha de donde miras (en horizontal)
    const der = s.der.set(Math.cos(j.yaw), 0, -Math.sin(j.yaw));
    let d = p.distancia * s.k;
    // que no atraviese la pared: rayo de lado desde los ojos
    const signo = Math.sign(d), g = M && M.rayo(cam.position.x, cam.position.y, cam.position.z, der.x * signo, 0, der.z * signo, Math.abs(d) + 0.15);
    if (g) d = signo * Math.max(0, g.t - 0.15);
    cam.position.addScaledVector(der, d);
    if (j.modoCamara === 'fps') cam.rotation.z -= s.k * p.angulo * FORJA.DEG;
    j.asomado = s.k;
  },
});
