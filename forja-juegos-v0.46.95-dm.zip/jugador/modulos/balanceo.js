/* Módulo BALANCEO DE CÁMARA — la cabeza se mueve al caminar (solo 1ª persona).
   Dos estilos para elegir:
     · Ligero:     el clásico vaivén de pasos, suave y controlable (Quake, Doom, arcades rápidos).
     · Con inercia: la cabeza va "colgada" de un muelle: se queda atrás al arrancar, se adelanta al frenar,
                   se hunde al aterrizar, se inclina al girar y al ir de lado (survival, táctico, pesado).
   Solo mueve la cámara unos centímetros: nada de física ni rayos, cuesta casi cero. */
FORJA.registrarModulo({
  nombre: 'balanceo',
  etiqueta: 'Balanceo de cámara',
  descripcion: 'La cabeza se mueve al caminar en primera persona. Ligero (arcade) o con inercia (peso).',
  orden: 12,                 // justo después de Cámara: parte de la posición que ella deja
  activoPorDefecto: false,
  props: [
    { k: 'estilo', t: 'sel', e: 'Estilo', def: 'ligero', op: [['ligero', 'Ligero (vaivén de pasos)'], ['inercia', 'Con inercia (peso)']] },
    { k: 'intensidad', t: 'rango', e: 'Intensidad', def: 1, min: 0, max: 3, paso: 0.05, ayuda: 'Multiplica todos los efectos. 0 = apagado' },
    { k: 'frecuencia', t: 'num', e: 'Pasos (ritmo)', def: 8, paso: 0.5, min: 0, ayuda: 'Qué tan rápido se mece la cabeza al caminar' },
    { k: 'multCorrer', t: 'rango', e: 'Ritmo al correr', def: 1.3, min: 1, max: 2.5, paso: 0.05 },

    { grupo: 'Ligero', si: (v) => v.estilo === 'ligero' },
    { k: 'subeBaja', t: 'rango', e: 'Sube y baja', def: 1, min: 0, max: 3, paso: 0.05, ayuda: 'Cabeceo vertical de cada paso (muy sutil de serie)' },
    { k: 'ladoALado', t: 'rango', e: 'Lado a lado', def: 1, min: 0, max: 3, paso: 0.05, ayuda: 'Balanceo de hombros' },
    { k: 'inclinarLado', t: 'rango', e: 'Inclinar al ir de lado', def: 1, min: 0, max: 3, paso: 0.05, ayuda: 'La cabeza se apoya hacia donde caminas de lado' },
    { k: 'rollPaso', t: 'rango', e: 'Inclinar en cada paso', def: 1, min: 0, max: 3, paso: 0.05 },
    { k: 'suavizado', t: 'num', e: 'Suavizado', def: 10, paso: 0.5, min: 1, ayuda: 'Más alto = sigue el ritmo más pegado; más bajo = más blando' },

    { grupo: 'Con inercia', si: (v) => v.estilo === 'inercia' },
    { k: 'peso', t: 'rango', e: 'Peso de la cabeza', def: 1, min: 0.3, max: 3, paso: 0.05, ayuda: 'Más peso = reacciona más lento y rebota más, como cargar equipo' },
    { k: 'retraso', t: 'rango', e: 'Se queda atrás al arrancar', def: 1, min: 0, max: 3, paso: 0.05, ayuda: 'También se va hacia delante al frenar' },
    { k: 'aterrizaje', t: 'rango', e: 'Hundirse al aterrizar', def: 1, min: 0, max: 3, paso: 0.05, ayuda: 'Más fuerte cuanto más alta la caída' },
    { k: 'enAire', t: 'rango', e: 'Flotar en el aire', def: 1, min: 0, max: 3, paso: 0.05, ayuda: 'La cabeza se retrasa al subir y al caer' },
    { k: 'inclinarGiro', t: 'rango', e: 'Inclinar al girar', def: 1, min: 0, max: 3, paso: 0.05, ayuda: 'Al mover la vista rápido la cabeza se ladea' },
    { k: 'inclinarLadoI', t: 'rango', e: 'Inclinar al ir de lado', def: 1, min: 0, max: 3, paso: 0.05 },
    { k: 'pasosI', t: 'rango', e: 'Vaivén de pasos', def: 1, min: 0, max: 3, paso: 0.05 },
  ],

  iniciar(j, p, s) {
    s.t = 0;                                       // fase de los pasos
    s.ox = 0; s.oy = 0; s.oz = 0; s.roll = 0;      // desplazamiento actual (local a la vista)
    s.vx = 0; s.vy = 0; s.vz = 0; s.vr = 0;        // velocidad del muelle (solo estilo inercia)
    s.antX = 0; s.antY = 0; s.antZ = 0;            // velocidad del cuerpo el cuadro anterior
    s.antYaw = j.yaw;
    s.enSuelo = true;
    s.antModo = j.modoCamara;
  },

  despues(j, p, s, dt) {
    const cam = j.camara, c = j.cuerpo, v = c.velocidad;
    if (dt <= 0) return;
    // en 3ª persona no se aplica; al volver a 1ª empieza quieto
    if (j.modoCamara !== 'fps') { s.antModo = j.modoCamara; this._guardar(j, s); return; }
    if (s.antModo !== 'fps') { this.iniciar(j, p, s); }

    const d = Math.min(dt, 0.05);                  // un tirón de cuadros no dispara el muelle
    // ejes de la vista en horizontal: derecha y atrás (la cámara mira a -Z)
    const sy = Math.sin(j.yaw), cy = Math.cos(j.yaw);
    const derX = cy, derZ = -sy, atrX = sy, atrZ = cy;
    const vLado = v.x * derX + v.z * derZ;         // + = va a su derecha
    const vel = Math.hypot(v.x, v.z);
    const enSuelo = c.enSuelo && !j.muerto;
    const ritmo = p.frecuencia * (j.corriendo ? p.multCorrer : 1);
    const I = p.intensidad;

    if (p.estilo === 'inercia') this._inercia(j, p, s, d, { derX, derZ, atrX, atrZ, vLado, vel, enSuelo, ritmo, I });
    else this._ligero(p, s, d, { vLado, vel, enSuelo, ritmo, I });

    // aplicar: offset en ejes de la vista (sin el pitch, como un "cuello")
    cam.position.x += derX * s.ox + atrX * s.oz;
    cam.position.y += s.oy;
    cam.position.z += derZ * s.ox + atrZ * s.oz;
    cam.rotation.z = s.roll;
    this._guardar(j, s);
  },

  _guardar(j, s) {
    const v = j.cuerpo.velocidad;
    s.antX = v.x; s.antY = v.y; s.antZ = v.z;
    s.antYaw = j.yaw;
    s.enSuelo = j.cuerpo.enSuelo;
  },

  /* Ligero: un objetivo de vaivén por pasos y la cámara lo persigue suave (sin rebote) */
  _ligero(p, s, d, m) {
    let tx = 0, ty = 0, tr = 0;
    if (m.enSuelo && m.vel > 0.3) {
      s.t += d * m.ritmo;
      ty = Math.sin(s.t * 2) * 0.015 * p.subeBaja;           // dos subidas por ciclo: una por pie
      tx = Math.cos(s.t) * 0.03 * p.ladoALado;
      const lado = FORJA.util.clamp(m.vLado / 5, -1, 1);
      tr = -lado * 0.025 * p.inclinarLado + Math.cos(s.t) * 0.008 * p.rollPaso;
    }
    const k = Math.min(1, d * p.suavizado);
    s.ox += (tx * m.I - s.ox) * k;
    s.oy += (ty * m.I - s.oy) * k;
    s.oz += (0 - s.oz) * k;
    s.roll += (tr * m.I - s.roll) * k;
  },

  /* Con inercia: muelle con amortiguación. La cabeza quiere ir a un objetivo,
     pero tiene masa: llega tarde, se pasa un poco y vuelve. */
  _inercia(j, p, s, d, m) {
    const v = j.cuerpo.velocidad, I = m.I;
    // aceleración del cuerpo este cuadro (cuánto cambió la velocidad)
    const ax = (v.x - s.antX) / d, az = (v.z - s.antZ) / d;
    const aLado = ax * m.derX + az * m.derZ;
    const aAtras = ax * m.atrX + az * m.atrZ;
    // aterrizar: un golpe hacia abajo según lo rápido que caía
    if (m.enSuelo && !s.enSuelo) s.vy -= 2.6 * p.aterrizaje * I * FORJA.util.clamp(-s.antY / 12, 0, 1);

    let amp = 0;
    if (m.enSuelo && m.vel > 0.35) {
      s.t += d * m.ritmo;
      amp = FORJA.util.clamp(m.vel / 5, 0, 1.5);
    }
    const retraso = 0.035 * p.retraso * I, tope = 0.16 * I;
    const tx = FORJA.util.clamp(-aLado * retraso, -tope, tope) + Math.cos(s.t) * 0.022 * amp * p.pasosI * I;
    const ty = m.enSuelo ? 0 : FORJA.util.clamp(-v.y * 0.01 * p.enAire * I, -0.1, 0.1);
    const tz = FORJA.util.clamp(-aAtras * retraso, -tope, tope);
    // giro de la vista (rad/s) e ir de lado → inclinación
    let dyaw = j.yaw - s.antYaw;
    dyaw = Math.atan2(Math.sin(dyaw), Math.cos(dyaw));
    const tr = (FORJA.util.clamp(dyaw / d / 6, -1, 1) * 0.045 * p.inclinarGiro
              - FORJA.util.clamp(m.vLado / 5, -1, 1) * 0.075 * p.inclinarLadoI) * I;

    // muelle: rigidez y amortiguación salen del peso
    const peso = Math.max(0.3, p.peso);
    const kM = 70 / peso, cM = 11 / Math.sqrt(peso);
    s.vx += ((tx - s.ox) * kM - s.vx * cM) * d;
    s.vy += ((ty - s.oy) * kM - s.vy * cM) * d;
    s.vz += ((tz - s.oz) * kM - s.vz * cM) * d;
    s.vr += ((tr - s.roll) * kM - s.vr * cM) * d;
    s.ox += s.vx * d; s.oy += s.vy * d; s.oz += s.vz * d; s.roll += s.vr * d;
    // seguridad: un teletransporte o reaparecer no deja la cabeza volando
    if (Math.abs(s.ox) > 0.5 || Math.abs(s.oy) > 0.5 || Math.abs(s.oz) > 0.5) this.iniciar(j, p, s);
  },
});
