/* Módulo ORILLAS — agarrarse a los bordes y subir (como Tomb Raider, Doom Eternal, Uncharted).
   En el aire, de frente a una pared cuyo borde de arriba queda a tu alcance (entre el pecho y un poco por encima de la
   cabeza) y con sitio arriba: te agarras.
   - Modo "Subir solo" (Doom Eternal): trepa al instante, sin colgarse.
   - Modo "Colgarse" (Tomb Raider): quedas colgado. Saltar o adelante = subir · atrás o agachar = soltarse ·
     izquierda / derecha = moverse por el borde (mientras haya borde).
   Detección barata: 3 rayos contra la colisión (BVH) solo mientras estás en el aire. Mientras te agarras no hay
   gravedad ni movimiento normal (j.trepando, como las escaleras de mano). Con modelo: animaciones "hang" / "climb". */
FORJA.registrarModulo({
  nombre: 'orillas',
  etiqueta: 'Agarrar orillas',
  descripcion: 'En el aire, de frente a un borde alcanzable: te agarras y subes (Tomb Raider / Doom Eternal).',
  orden: 14,
  activoPorDefecto: false,
  props: [
    { k: 'modo', t: 'sel', e: 'Cómo sube', def: 'colgar', op: [['colgar', '🧗 Colgarse (Tomb Raider): saltar o adelante para subir'], ['auto', '⚡ Subir solo (Doom Eternal): trepa al instante']] },
    { k: 'alcance', t: 'num', e: 'Alcanza por encima de la cabeza (m)', def: 0.5, paso: 0.05, min: 0, ayuda: 'Hasta dónde llegan las manos por encima de la cabeza' },
    { k: 'tiempoSubir', t: 'num', e: 'Tarda en subir (s)', def: 0.45, paso: 0.05, min: 0.1 },
    { k: 'conAdelante', t: 'bool', e: 'Solo empujando hacia el borde', def: true, ayuda: 'Hay que ir hacia delante para agarrarse (así no te agarras sin querer al caer)' },
    { k: 'lateral', t: 'num', e: 'Moverse colgado (m/s)', def: 1.2, paso: 0.1, min: 0, si: (v) => v.modo === 'colgar', ayuda: '0 = no se mueve por el borde' },
    { k: 'sonido', t: 'asset', e: 'Sonido al agarrarse', def: '', tipoAsset: 'audio', vacio: '(golpe del motor)' },
  ],

  iniciar(j, p, s) {
    const T = THREE;
    s.estado = null;   // null · 'colgado' · 'subiendo'
    s.n = new T.Vector3(); s.f = new T.Vector3(); s.t = new T.Vector3(); s.meta = new T.Vector3();
    s.espera = 0; s.hy = 0; s.tSub = 0;
  },

  // ¿hay borde delante? → { hy (altura del borde), n (normal de la pared, hacia ti), dist } o null
  _buscar(j, p, s, fx, fz) {
    const M = j.mundo, c = j.cuerpo;
    if (!M) return null;
    const pecho = c.pie.y + c.altura * 0.55, alcance = c.radio + 0.45;
    // 1) pared delante a la altura del pecho (vertical)
    const g = M.rayo(c.pie.x, pecho, c.pie.z, fx, 0, fz, alcance);
    if (!g) return null;
    const k = g.k * 3, ny = M.nor[k + 1];
    let nx = M.nor[k], nz = M.nor[k + 2];
    if (nx * fx + nz * fz > 0) { nx = -nx; nz = -nz; }   // la normal hacia ti (da igual cómo esté orientado el triángulo)
    if (Math.abs(ny) > 0.35 || nx * fx + nz * fz > -0.5) return null;   // pared vertical y más o menos de frente
    // 2) el borde: un rayo hacia abajo un poco más allá de la pared, desde por encima de las manos
    const arriba = c.pie.y + c.altura + (p.alcance ?? 0.5);
    const px = c.pie.x + fx * (g.t + 0.2), pz = c.pie.z + fz * (g.t + 0.2);
    const b = M.rayo(px, arriba, pz, 0, -1, 0, arriba - pecho + 0.25);
    if (!b) return null;
    const kb = b.k * 3;
    if (M.nor[kb + 1] < 0.7) return null;   // tiene que ser una superficie para pisar
    const hy = arriba - b.t;
    if (hy < c.pie.y + c.altura * 0.45) return null;   // demasiado bajo: es un escalón, se sube andando
    // 3) sitio arriba para estar de pie (y que el rayo no empezara dentro de un techo)
    if (M.rayo(px, hy + 0.05, pz, 0, 1, 0, c.altura * 0.9)) return null;
    return { hy, nx, nz, dist: g.t };
  },

  entrada(j, p, s) {
    if (s.estado !== 'colgado') return;
    const IN = FORJA.Entrada;
    // un instante colgado antes de poder subir (si mantienes adelante desde el salto, se ve el agarre)
    if (s.tCol < 0.3) return;
    if (IN.pulsado('saltar') || IN.mover.y > 0.6) this._subir(j, p, s);
    else if (IN.pulsado('agachar') || IN.mover.y < -0.6) this._soltar(j, s, 0.45);
  },

  fisica(j, p, s, dt) {
    if (s.espera > 0) s.espera -= dt;
    const c = j.cuerpo;
    if (j.muerto || j.nadando) { if (s.estado) this._soltar(j, s, 0.3); return; }
    if (!s.estado) {
      // buscar solo en el aire, sin otro módulo mandando
      if (s.espera > 0 || c.enSuelo || j.trepando || j.enPared || c.velocidad.y > 3) return;
      const IN = FORJA.Entrada;
      if (p.conAdelante !== false && IN.mover.y < 0.3) return;
      const fx = -Math.sin(j.yaw), fz = -Math.cos(j.yaw);
      const o = this._buscar(j, p, s, fx, fz);
      if (!o) return;
      s.n.set(o.nx, 0, o.nz).normalize();
      s.hy = o.hy;
      j.trepando = true;
      j.mirarEscala = Math.atan2(s.n.x, s.n.z) + Math.PI;   // el modelo mira a la pared
      if (p.sonido) FORJA.Audio.efecto(p.sonido); else FORJA.Audio.sintetico('aterrizar', { volumen: 0.4, tono: 1.3 });
      if (p.modo === 'auto') this._subir(j, p, s);
      else { s.estado = 'colgado'; s.tCol = 0; j.colgado = true; c.velocidad.set(0, 0, 0); }
      return;
    }
    if (s.estado === 'colgado') {
      s.tCol += dt;
      // pegado a la pared, con las manos en el borde; izquierda / derecha por el borde
      const lado = s.t.set(s.n.z, 0, -s.n.x);   // a tu derecha mirando a la pared (D = derecha)
      let v = FORJA.Entrada.mover.x * (p.lateral ?? 1.2);
      if (v) {
        // ¿sigue habiendo borde un poco más allá? si no, no se mueve
        const sx = c.pie.x, sz = c.pie.z;
        c.pie.x += lado.x * Math.sign(v) * 0.3; c.pie.z += lado.z * Math.sign(v) * 0.3;
        const o = this._buscar(j, p, s, -s.n.x, -s.n.z);
        c.pie.x = sx; c.pie.z = sz;
        if (!o || Math.abs(o.hy - s.hy) > 0.3) v = 0; else s.hy = o.hy;
      }
      const yMeta = s.hy - c.altura * 0.95;
      const k = Math.min(1, dt * 12) / Math.max(dt, 1e-3) * 0.5;
      c.velocidad.set(lado.x * v - s.n.x * 0.6, (yMeta - c.pie.y) * k, lado.z * v - s.n.z * 0.6);
      return;
    }
    // subiendo: primero arriba (hasta el borde), luego hacia delante sobre él
    s.tSub += dt;
    const T = Math.max(0.1, p.tiempoSubir ?? 0.45);
    if (c.pie.y < s.hy + 0.03 && s.tSub < T * 1.5) {
      const falta = s.hy + 0.06 - c.pie.y;
      c.velocidad.set(-s.n.x * 0.3, Math.max(2, falta / Math.max(0.05, T * 0.6 - s.tSub)), -s.n.z * 0.3);
    } else {
      c.velocidad.set(-s.n.x * (0.9 / (T * 0.4)), 0, -s.n.z * (0.9 / (T * 0.4)));
      if (s.tSub > T * 1.1 || (c.enSuelo && s.tSub > T * 0.7)) this._soltar(j, s, 0.25);
    }
  },

  _subir(j, p, s) { s.estado = 'subiendo'; s.tSub = 0; j.colgado = false; j.subiendoOrilla = true; },
  _soltar(j, s, espera) { s.estado = null; s.espera = espera; j.trepando = false; j.colgado = false; j.subiendoOrilla = false; j.mirarEscala = null; },
  detener(j, p, s) { if (s.estado) this._soltar(j, s, 0); },
});
