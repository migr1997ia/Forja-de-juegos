/* Módulo AGACHARSE — cápsula más baja para pasar por huecos y esconderse.
   1ª persona: baja la vista · 3ª persona: animación "crouch" si el modelo la trae (si no, se encoge) y la cámara baja.
   No se levanta si hay techo encima. */
FORJA.registrarModulo({
  nombre: 'agachar',
  etiqueta: 'Agacharse',
  descripcion: 'Ctrl / C / B (○) / botón táctil. Más lento, cabe por huecos bajos y no se levanta bajo un techo.',
  orden: 16,
  activoPorDefecto: false,
  props: [
    { k: 'modo', t: 'sel', e: 'Botón', def: 'mantener', op: [['mantener', 'Mantener pulsado'], ['alternar', 'Pulsar = agachar / levantar']] },
    { k: 'altura', t: 'num', e: 'Altura agachado (m)', def: 1.0, paso: 0.05, min: 0.4 },
    { k: 'velocidad', t: 'rango', e: 'Velocidad agachado', def: 0.5, min: 0.1, max: 1, paso: 0.05 },
    { k: 'suave', t: 'num', e: 'Rapidez al bajar', def: 10, paso: 1, min: 1, ayuda: 'Qué tan rápido baja / sube la vista' },
    { k: 'saltar', t: 'bool', e: 'Puede saltar agachado', def: true },
  ],

  iniciar(j, p, s) {
    s.alto0 = j.cuerpo.altura;
    s.ojos0 = j.alturaOjos;
    s.k = 0;            // 0 = de pie · 1 = agachado (suavizado)
    s.quiere = false;
    j.agachado = false;
  },

  entrada(j, p, s) {
    const E = FORJA.Entrada;
    if (p.modo === 'alternar') { if (E.pulsado('agachar')) s.quiere = !s.quiere; }
    else s.quiere = E.mantenido('agachar');
    if (j.muerto || j.nadando) s.quiere = false;   // en el agua Agacharse es bajar / bucear (módulo Nadar)
    if (j.agachado) {
      j.modVelocidad = p.velocidad;     // pisa a "correr"
      j.corriendo = false;
    }
  },

  fisica(j, p, s, dt) {
    const c = j.cuerpo;
    if (s.quiere && !j.agachado) {
      j.agachado = true;
      c.altura = p.altura;
    } else if (!s.quiere && j.agachado) {
      // ¿cabe de pie? rayo hacia arriba desde la cabeza agachada
      const g = j.mundo.rayo(c.pie.x, c.pie.y + p.altura - 0.05, c.pie.z, 0, 1, 0, s.alto0 - p.altura + 0.1);
      if (!g) { j.agachado = false; c.altura = s.alto0; }
    }
    j.sinSalto = j.agachado && !p.saltar;
  },

  despues(j, p, s, dt) {
    const meta = j.agachado ? 1 : 0;
    s.k += (meta - s.k) * Math.min(1, dt * p.suave);
    if (!j.muerto) {
      const ojosAgachado = Math.max(0.3, p.altura - 0.2);
      j.alturaOjos = s.ojos0 + (ojosAgachado - s.ojos0) * s.k;
      j.bajarCamara = (s.alto0 - p.altura) * 0.6 * s.k;
    }
    // 3ª persona sin animación "crouch": el modelo se encoge (barato y se lee bien)
    const m = j.modelo;
    if (m && m.userData.escalaBase) {
      const conAnim = m.userData.animaciones && m.userData.animaciones.some((a) => /crouch|walk_c/i.test(a.name));
      const b = m.userData.escalaBase;
      m.scale.set(b, conAnim ? b : b * (1 - 0.4 * s.k), b);
    }
  },

  detener(j, p, s) {
    j.cuerpo.altura = s.alto0;
    j.agachado = false;
  },
});
