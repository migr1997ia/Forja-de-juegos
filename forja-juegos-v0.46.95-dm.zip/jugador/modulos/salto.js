/* Módulo SALTO — con coyote time, búfer y altura variable (soltar antes = salto corto, como Mario).
   Equivale a tu jump_module.gd. */
FORJA.registrarModulo({
  nombre: 'salto',
  etiqueta: 'Salto',
  descripcion: 'Saltar con Espacio / A. "Coyote" deja saltar un instante después de caer de un borde.',
  orden: 30,
  props: [
    { k: 'fuerza', t: 'num', e: 'Fuerza', def: 6, paso: 0.1, ayuda: 'Velocidad hacia arriba (m/s)' },
    { k: 'coyote', t: 'num', e: 'Coyote (s)', def: 0.12, paso: 0.01 },
    { k: 'bufer', t: 'num', e: 'Búfer (s)', def: 0.12, paso: 0.01, ayuda: 'Pulsar un poco antes de tocar el suelo también cuenta' },
    { k: 'alturaVariable', t: 'bool', e: 'Altura variable', def: true, ayuda: 'Soltar el botón corta el salto' },
    { k: 'corte', t: 'rango', e: 'Corte al soltar', def: 0.5, min: 0.1, max: 1, paso: 0.05 },
    { grupo: 'Varios saltos' },
    { k: 'saltos', t: 'num', e: 'Saltos (1-5)', def: 1, paso: 1, min: 1, max: 5, ayuda: '1 = salto normal. 2 = doble salto, 3 = triple…' },
    { k: 'modoSaltos', t: 'sel', e: 'Cómo se encadenan', def: 'aire', si: (v) => v.saltos > 1,
      op: [['aire', '🦘 En el aire (doble salto tipo Doom Eternal)'], ['encadenado', '🍄 Al caer, más alto (triple salto tipo Mario)']],
      ayuda: 'En el aire: vuelves a pulsar sin tocar el suelo. Al caer: saltas justo al aterrizar mientras corres y cada salto sube más' },
    { k: 'fuerzaAire', t: 'rango', e: 'Fuerza de los saltos en el aire', def: 0.9, min: 0.3, max: 1.5, paso: 0.05, si: (v) => v.saltos > 1 && v.modoSaltos !== 'encadenado' },
    { k: 'subida', t: 'rango', e: 'Cuánto más alto cada salto', def: 0.25, min: 0, max: 1, paso: 0.05, si: (v) => v.saltos > 1 && v.modoSaltos === 'encadenado' },
    { k: 'ventana', t: 'num', e: 'Tiempo para encadenar (s)', def: 0.25, paso: 0.05, min: 0.05, si: (v) => v.saltos > 1 && v.modoSaltos === 'encadenado', ayuda: 'Cuánto tiempo después de aterrizar cuenta como seguido' },
  ],

  iniciar(j, p, s) {
    s.bufer = 0;
    s.saltando = false;
    s.aire = 0;        // saltos dados en el aire (doble salto)
    s.cadena = 0;      // en qué salto de la cadena vas (triple salto)
    s.tSuelo = 99;     // tiempo desde que aterrizaste
  },

  entrada(j, p, s, dt) {
    const E = FORJA.Entrada;
    if (E.pulsado('saltar')) s.bufer = p.bufer;
    else s.bufer -= dt;
    if (p.alturaVariable && s.saltando && E.soltado('saltar') && j.cuerpo.velocidad.y > 0) {
      j.cuerpo.velocidad.y *= p.corte;
    }
  },

  fisica(j, p, s, dt) {
    const c = j.cuerpo;
    if (j.nadando || j.trepando) { s.bufer = 0; s.saltando = false; s.aire = 0; return; }
    if (j.saltoDePared) { j.saltoDePared = false; s.bufer = 0; s.saltando = true; s.aire = 0; j.saltando = true; return; }   // saltó de una pared (correrpared.js): cuenta como salto nuevo   // en el agua Saltar sube o te saca (módulo Nadar)
    const n = Math.max(1, Math.min(5, Math.round(p.saltos || 1)));
    if (c.enSuelo) {
      if (s.saltando || s.tSuelo > 50) s.tSuelo = 0;   // acaba de aterrizar
      else s.tSuelo += dt || 0;
      s.saltando = false; s.aire = 0;
      if (s.tSuelo > (p.ventana || 0.25)) s.cadena = 0;
    }
    const libre = !j.sinSalto && !j.muerto;
    const puede = libre && (c.enSuelo || (!s.saltando && c.tAire < p.coyote));
    if (s.bufer > 0 && puede) {
      let f = p.fuerza;
      if (n > 1 && p.modoSaltos === 'encadenado') {
        // triple salto: seguido (poco después de aterrizar) y corriendo, cada salto sube más; el último reinicia la cadena
        const corre = Math.hypot(c.velocidad.x, c.velocidad.z) > 1;
        s.cadena = s.cadena > 0 && s.cadena < n && corre && s.tSuelo <= (p.ventana || 0.25) ? s.cadena + 1 : 1;
        f *= 1 + (s.cadena - 1) * (p.subida ?? 0.25);
      }
      c.velocidad.y = f;
      c.enSuelo = false;
      s.saltando = true;
      s.bufer = 0;
      FORJA.emitir('jugador-salto', { cadena: s.cadena || 1 });
    } else if (s.bufer > 0 && libre && n > 1 && p.modoSaltos !== 'encadenado' && !c.enSuelo && s.aire < n - 1) {
      // doble salto: en el aire, otra vez (aunque hayas caído de un borde sin saltar)
      c.velocidad.y = p.fuerza * (p.fuerzaAire ?? 0.9);
      s.saltando = true;
      s.aire++;
      s.bufer = 0;
      FORJA.emitir('jugador-salto', { aire: s.aire });
    }
    j.saltando = s.saltando;
  },
});
