/* Módulo COMBATE — que pegar se SIENTA (y, por fases, más cosas del combate).
   Fase 1 · Sensación de golpe (cuando TÚ le das a un enemigo):
     · Pausa de impacto: el mundo casi se congela unos milisegundos (cuerpo a cuerpo más que a distancia; al matar, más).
     · Temblor pequeño de la cámara y empujón del enemigo hacia atrás.
     · Números de daño que saltan del enemigo (opcional; amarillos si el golpe fue fuerte).
   Estilo: elegir Aventura / Souls / Acción pone sus valores de serie (luego se ajusta lo que quieras).
   Barato: todo sale del evento 'enemigo-danado'; los números son 10 cajitas HTML que se reciclan. */
FORJA.registrarModulo({
  nombre: 'combate',
  etiqueta: 'Combate',
  descripcion: 'Sensación de golpe, clic derecho (apuntar, fijar objetivo o bloquear) y fijar objetivo. Elige un estilo y ajusta.',
  orden: 54,
  activoPorDefecto: true,
  ESTILOS: {
    aventura: { aviso: true, avisoMin: 0.45, equilibrio: true, equilibrioK: 0.6, aturdeEquilibrio: 2.5, remate: true, remateMata: true, pausaGolpe: 90, pausaDisparo: 25, pausaMuerte: 180, temblorGolpe: 0.3, empujonGolpe: 0.8, numeros: false, sonidoGolpe: true },
    souls: { aviso: true, avisoMin: 0.35, equilibrio: true, equilibrioK: 0.8, aturdeEquilibrio: 2, remate: true, remateMata: false, pausaGolpe: 120, pausaDisparo: 30, pausaMuerte: 250, temblorGolpe: 0.45, empujonGolpe: 0.6, numeros: false, sonidoGolpe: true },
    accion: { aviso: true, avisoMin: 0.25, equilibrio: true, equilibrioK: 0.4, aturdeEquilibrio: 1.8, remate: true, remateMata: true, pausaGolpe: 140, pausaDisparo: 40, pausaMuerte: 280, temblorGolpe: 0.5, empujonGolpe: 1.6, numeros: true, sonidoGolpe: true },
  },
  props: [
    { k: 'estilo', t: 'sel', e: 'Estilo', def: 'aventura', op: [['aventura', '🗡 Aventura (Zelda, King\'s Field)'], ['souls', '🛡 Souls (pesado, castiga)'], ['accion', '💥 Acción (DMC, God Hand)'], ['propio', '⚙ Propio']],
      ayuda: 'Pone los valores de serie de ese estilo. Si cambias algo a mano queda como "Propio"' },
    { grupo: '💥 Sensación de golpe' },
    { k: 'pausaGolpe', t: 'num', e: 'Pausa al pegar cuerpo a cuerpo (ms)', def: 90, paso: 5, min: 0, max: 200, ayuda: 'El mundo casi se congela un instante al acertar: da peso al golpe. 0 = nada' },
    { k: 'pausaDisparo', t: 'num', e: 'Pausa al acertar a distancia (ms)', def: 25, paso: 5, min: 0, max: 100 },
    { k: 'pausaMuerte', t: 'num', e: 'Pausa al matar (ms)', def: 180, paso: 10, min: 0, max: 300 },
    { k: 'temblorGolpe', t: 'rango', e: 'Temblor de cámara', def: 0.3, min: 0, max: 1, paso: 0.05 },
    { k: 'empujonGolpe', t: 'num', e: 'Empujón al enemigo (m)', def: 0.8, paso: 0.1, min: 0, ayuda: 'Cuánto sale echado hacia atrás con cada golpe cuerpo a cuerpo (a distancia, la mitad). Los jefes y los fijos no se mueven' },
    { k: 'sonidoGolpe', t: 'bool', e: 'Sonido de golpe seco', def: true, ayuda: 'Un "pum" del motor además del sonido del arma' },
    { k: 'numeros', t: 'bool', e: 'Números de daño', def: false },
    { k: 'colorNumeros', t: 'color', e: 'Color de los números', def: '#ffffff', si: (v) => v.numeros },
    { grupo: '⚠ Enemigos: aviso, equilibrio y remate' },
    { k: 'aviso', t: 'bool', e: 'Avisan antes de atacar', def: true, ayuda: 'Parpadean (y suena un "ting") mientras preparan el golpe: da tiempo a bloquear, esquivar o hacer parry' },
    { k: 'colorAviso', t: 'color', e: 'Color del aviso', def: '#ff8a1a', si: (v) => v.aviso },
    { k: 'avisoMin', t: 'num', e: 'Preparan el golpe al menos (s)', def: 0.45, paso: 0.05, min: 0, si: (v) => v.aviso, ayuda: 'Si un enemigo tiene menos anticipación, se alarga hasta esto (más = más fácil)' },
    { k: 'avisoSonido', t: 'bool', e: 'Sonido de aviso', def: true, si: (v) => v.aviso },
    { k: 'equilibrio', t: 'bool', e: 'Barra de equilibrio', def: true, ayuda: 'Cada golpe le quita equilibrio (cuerpo a cuerpo mucho, a distancia poco). Si se le acaba queda aturdido. Se recupera si dejas de pegarle' },
    { k: 'equilibrioK', t: 'rango', e: 'Equilibrio (parte de su vida)', def: 0.6, min: 0.1, max: 2, paso: 0.05, si: (v) => v.equilibrio, ayuda: '0.5 = se rompe al quitarle media vida de golpes seguidos. Los jefes tienen el doble' },
    { k: 'aturdeEquilibrio', t: 'num', e: 'Aturdido al romperse (s)', def: 2.5, paso: 0.25, min: 0.5, si: (v) => v.equilibrio },
    { k: 'remate', t: 'bool', e: 'Remate al aturdido', def: true, ayuda: 'Un golpe cuerpo a cuerpo a un enemigo aturdido (por equilibrio o por parry) es un remate: golpe fuerte con cámara lenta' },
    { k: 'remateMata', t: 'bool', e: 'El remate mata', def: true, si: (v) => v.remate, ayuda: 'No = hace el triple de daño (los jefes nunca mueren de un remate)' },
    { grupo: '🛡 Parry (como Doom: The Dark Ages)' },
    { k: 'parryGracia', t: 'num', e: 'Tiempo de gracia (s)', def: 0.15, paso: 0.05, min: 0, max: 1,
      ayuda: 'Se suma a la ventana de parry de cada arma (Juego ▸ Armas ▸ Parry) y del escudo: más = más fácil. Como el ajuste de dificultad del parry de Doom' },
    { k: 'parryEscudo', t: 'bool', e: 'Parry con el escudo de mano', def: true, ayuda: 'Levantar el escudo justo antes del golpe: no entra nada, no gasta escudo y el atacante queda aturdido' },
    { k: 'parryProyectiles', t: 'bool', e: 'Devolver proyectiles con un parry', def: true, ayuda: 'Un parry de frente a un proyectil enemigo lo devuelve, más rápido y con el doble de daño' },
    { k: 'parryVerde', t: 'bool', e: 'Verde = se puede hacer parry', def: true, ayuda: 'Si llevas algo con parry (arma o escudo), los avisos de ataque y los proyectiles enemigos salen en verde' },
    { k: 'parryPausa', t: 'num', e: 'Pausa al hacer parry (ms)', def: 160, paso: 10, min: 0 },
    { grupo: '🎯 Clic derecho y fijar objetivo' },
    { k: 'clicDerecho', t: 'sel', e: 'Clic derecho', def: 'arma', op: [['arma', 'Lo que diga cada arma (apuntar / guardia)'], ['apuntar', '🎯 Solo apuntar'], ['fijar', '🔒 Fijar objetivo'], ['bloquear', '🛡 Bloquear / guardia']],
      ayuda: 'Además, siempre hay una tecla para cada cosa: Fijar objetivo (T) y Bloquear (H). Se cambian en Opciones ▸ Controles' },
    { k: 'fijarModo', t: 'sel', e: 'Fijar objetivo', def: 'alternar', op: [['alternar', 'Pulsar para fijar / soltar'], ['mantener', 'Mientras se mantiene']] },
    { k: 'fijarDistancia', t: 'num', e: 'Distancia para fijar (m)', def: 18, paso: 1, min: 3 },
    { k: 'fijarGiro', t: 'rango', e: 'Rapidez al girar hacia él', def: 0.6, min: 0.1, max: 1, paso: 0.05, ayuda: '1 = la cámara se clava en el objetivo · menos = lo sigue suave' },
    { k: 'fijarMarca', t: 'bool', e: 'Marca sobre el objetivo', def: true },
    { k: 'colorMarca', t: 'color', e: 'Color de la marca', def: '#ff5a3a', si: (v) => v.fijarMarca },
    { grupo: '🗡 Combos (cuerpo a cuerpo)' },
    { k: 'combos', t: 'bool', e: 'Combos', def: true, ayuda: 'Pegando seguido se encadenan los golpes del combo de cada arma (Juego ▸ Armas ▸ Combo). Si no le pones uno, usa el de su estilo' },
    { k: 'comboVentana', t: 'num', e: 'Tiempo para seguir el combo (s)', def: 0.8, paso: 0.05, min: 0.2, si: (v) => v.combos },
    { k: 'comboPausa', t: 'bool', e: 'Combo con pausa', def: true, si: (v) => v.combos, ayuda: 'Si esperas un instante entre dos golpes (unos 0,3 s más de lo normal), el combo sigue por su otra rama (lanzador, giro…)' },
    { k: 'carrera', t: 'bool', e: 'Embestida al atacar corriendo', def: true, ayuda: 'Corriendo, el golpe es una estocada que te lanza hacia delante' },
    { grupo: '💫 Habilidades' },
    { k: 'carga', t: 'bool', e: 'Ataque cargado', def: true, ayuda: 'Mantén atacar con un arma cuerpo a cuerpo y suelta: golpe giratorio a todo alrededor (como el de Zelda)' },
    { k: 'cargaTiempo', t: 'num', e: 'Tiempo de carga (s)', def: 0.8, paso: 0.1, min: 0.2, si: (v) => v.carga },
    { k: 'cargaMult', t: 'num', e: 'Daño del cargado (×)', def: 2.5, paso: 0.25, min: 1, si: (v) => v.carga },
    { k: 'caida', t: 'bool', e: 'Ataque en caída', def: true, ayuda: 'Atacar en el aire con un arma cuerpo a cuerpo: caes en picado y al tocar el suelo sale una onda que daña y empuja' },
    { k: 'caidaMult', t: 'num', e: 'Daño de la caída (×)', def: 2, paso: 0.25, min: 0.5, si: (v) => v.caida },
    { k: 'caidaRadio', t: 'num', e: 'Radio de la onda (m)', def: 3, paso: 0.25, min: 1, si: (v) => v.caida },
    { k: 'contra', t: 'bool', e: 'Contraataque tras parry', def: true, ayuda: 'Después de un parry tienes un momento para un golpe que hace mucho más daño' },
    { k: 'contraVentana', t: 'num', e: 'Tiempo para contraatacar (s)', def: 1, paso: 0.1, min: 0.2, si: (v) => v.contra },
    { k: 'contraMult', t: 'num', e: 'Daño del contraataque (×)', def: 3, paso: 0.25, min: 1, si: (v) => v.contra },
    { k: 'esquivaPerfecta', t: 'bool', e: 'Esquiva perfecta', def: true, ayuda: 'Esquivar justo cuando un enemigo va a golpearte: los enemigos van a cámara lenta un momento (tú no)' },
    { k: 'perfectaVentana', t: 'num', e: 'Margen de la esquiva perfecta (s)', def: 0.25, paso: 0.05, min: 0.05, si: (v) => v.esquivaPerfecta },
    { k: 'perfectaLento', t: 'num', e: 'Cámara lenta (s)', def: 2, paso: 0.25, min: 0.25, si: (v) => v.esquivaPerfecta },
  ],

  /* 🗡 Movimientos de combo: daño (mult), alcance extra, cono (0.5 = delante · −1 = todo alrededor), empujón, efecto
     y animación (la primera que tenga el modelo; el muñeco usa su golpe con una variante) */
  MOVS: {
    tajo: { mult: 1, anims: ['slash1', 'slash2'] },
    estocada: { mult: 1.1, alcance: 0.4, cono: 0.8, anims: ['stab', 'spear'], dur: 0.8 },
    giro: { mult: 1.2, cono: -1.1, empuje: 1.6, anims: ['spin', 'slash2'], giro: true, dur: 1.4 },
    lanzador: { mult: 0.9, lanzar: 7, anims: ['upper', 'slash1'], figura: 'reves', dur: 1.1 },
    barrido: { mult: 0.8, cono: 0.2, aturde: 0.9, anims: ['sweep', 'slash2'], figura: 'bajo', dur: 1.2 },
    fuerte: { mult: 1.8, empuje: 2.2, anims: ['slash3', 'axe'], dur: 1.5, cadencia: 0.7 },
  },
  COMBOS: {   // de serie, por cómo se sujeta el arma: [normal, con pausa]
    corta: ['estocada,estocada,tajo', 'estocada,barrido'],
    larga: ['tajo,tajo,giro', 'tajo,lanzador'],
    dosManos: ['fuerte,fuerte', 'fuerte,barrido'],
    espadon: ['tajo,tajo,fuerte', 'tajo,lanzador'],
    lanza: ['estocada,estocada,barrido', 'estocada,lanzador'],
  },
  _lista(t) { return String(t || '').toLowerCase().split(/[,;\s]+/).map((x) => x.normalize('NFD').replace(/[\u0300-\u036f]/g, '')).filter((x) => this.MOVS[x]); },

  // el editor llama a esto al cambiar un valor: el estilo pone sus valores; tocar otro pasa a "Propio"
  alCambiar(k, v, valores) {
    if (k === 'estilo' && this.ESTILOS[v]) { Object.assign(valores, this.ESTILOS[v]); return true; }
    if (k !== 'estilo' && k in (this.ESTILOS.aventura) && valores.estilo !== 'propio') { valores.estilo = 'propio'; return true; }
    return false;
  },

  iniciar(j, p, s) {
    s.numeros = [];
    s.paso = 0; s.tUlt = 0; s.tCarga = 0; s.tContra = 0;
    // 🗡 qué golpe toca (lo pregunta armas.js al atacar con cuerpo a cuerpo)
    j.alGolpear = (d) => {
      const ahora = performance.now() / 1000;
      // 🔁 contraataque tras parry
      if (p.contra && s.tContra > 0) { s.tContra = 0; this._numero(j, p, s, null, 0, '¡CONTRAATAQUE!'); return { nombre: 'contra', mult: p.contraMult ?? 3, aturde: 1.2, empuje: 2, anims: ['slash3', 'stab', 'slash1'], dur: 1.1 }; }
      // ⚡ embestida: atacar corriendo
      const vh = Math.hypot(j.cuerpo.velocidad.x, j.cuerpo.velocidad.z);
      if (p.carrera && j.corriendo && vh > 3.5) { s.paso = 0; s.tUlt = ahora; return { nombre: 'embestida', mult: 1.3, alcance: 0.8, cono: 0.7, empuje: 2, avance: 7, anims: ['stab', 'spear'], dur: 1.2 }; }
      if (!p.combos) return null;
      const est = FORJA.Escena.estiloCuerpo(d) || 'corta', serie = this.COMBOS[est] || this.COMBOS.corta;
      const normal = this._lista(d.combo || serie[0]), pausa = this._lista(d.comboPausa || serie[1]);
      if (!normal.length) return null;
      const gap = ahora - s.tUlt, ventana = p.comboVentana ?? 0.8;
      // la ventana cuenta desde que el arma puede volver a golpear (su cadencia) + la pausa de impacto
      const espera = 1 / Math.max(0.1, d.cadencia || 2) + 0.3;
      if (gap > espera + ventana || s.armaCombo !== d) { s.paso = 0; s.rama = normal; }
      else {
        // pausa: esperaste un poco entre golpes → sigue por la otra rama (en el mismo punto)
        if (p.comboPausa && gap > espera + 0.3 && pausa.length > s.paso && s.rama === normal && s.paso >= 1) s.rama = pausa;
        if (s.paso >= s.rama.length) { s.paso = 0; s.rama = normal; }
      }
      s.armaCombo = d;
      const n = s.rama[s.paso] || normal[0];
      s.paso++; s.tUlt = ahora;
      const mv = { nombre: n, paso: s.paso, ...this.MOVS[n] };
      if (est === 'espadon' && !mv.giro && n !== 'lanzador' && n !== 'barrido') mv.anims = ['great', ...(mv.anims || [])];   // ⚔ a dos manos: su tajo
      return mv;
    };
    s.oyParry = (x) => {
      if (!x || x.jugador !== j) return;
      if (p.contra) s.tContra = p.contraVentana ?? 1;
      if (p.parryPausa > 0 && j.juego.lento) j.juego.lento(0.05, p.parryPausa / 1000);
      j.temblor = Math.max(j.temblor || 0, 0.35);
      this._numero(j, p, s, x.enemigo && x.enemigo.cuerpo ? x.enemigo : null, 0, x.proyectil ? '¡DEVUELTO!' : '¡PARRY!');
    };
    FORJA.on('parry', s.oyParry);
    // 💨 esquiva perfecta: un enemigo cerca a punto de golpear
    s.oyEsquiva = (jj) => {
      if (jj !== j || !p.esquivaPerfecta || !j.juego.enemigos) return;
      const V = p.perfectaVentana ?? 0.25;
      const cerca = j.juego.enemigos.lista.some((E) => !E.muerto && Math.hypot(E.cuerpo.pie.x - j.cuerpo.pie.x, E.cuerpo.pie.z - j.cuerpo.pie.z) < 4.5 &&
        ((E.estado === 'anticipar' && E.t <= V + 0.1) || (E.estado === 'atacar' && (E.c.anticipacion || 0) >= 0 && E.t > 0.2)));
      if (!cerca) return;
      j.juego.lentoEnemigos && j.juego.lentoEnemigos(0.25, p.perfectaLento ?? 2);
      j.juego.lento && j.juego.lento(0.15, 0.12);
      FORJA.Audio.sintetico('recoger', { volumen: 0.6, tono: 0.6 });
      this._numero(j, p, s, null, 0, '¡ESQUIVA PERFECTA!');
      FORJA.emitir('esquiva-perfecta', j);
    };
    FORJA.on('jugador-esquiva', s.oyEsquiva);
    // ⚠ el aviso lo pinta enemigos.js (parpadeo en 'anticipar'); aquí solo se le dice cómo
    if (j.juego.enemigos) j.juego.enemigos.aviso = p.aviso ? { color: p.colorAviso || '#ff8a1a', minimo: p.avisoMin ?? 0.45, sonido: p.avisoSonido !== false } : null;
    s.oyente = (E, real, info) => {
      if (!E || !(real > 0) || (info && info.de) || (info && (info.tic || info.liquido))) return;   // solo lo que hace el jugador
      const J = j.juego, cuerpo = info && info.arma && info.arma.tipo === 'cuerpo';
      // ⚔ remate: golpe cuerpo a cuerpo a un enemigo aturdido
      if (p.remate && cuerpo && !info.remate && E.estado === 'aturdido' && !E.muerto && E.vida > 0) {
        const extra = p.remateMata && !E.c.jefe ? E.vida * 20 + 999 : real * 2;   // mata aunque resista el tipo de daño
        J.lento && J.lento(0.25, 0.45);   // cámara lenta un momento
        j.temblor = Math.max(j.temblor || 0, 0.8);
        FORJA.Audio.sintetico('explosion', { volumen: 0.5, tono: 1.6 });
        this._numero(j, p, s, E, 0, '¡REMATE!');
        J.enemigos.danar(E, extra, { ...info, remate: true });
        FORJA.emitir('enemigo-rematado', E);
        return;
      }
      const muerto = E.muerto || E.vida <= 0;
      // ⚖ equilibrio: se va llenando con los golpes; lleno = aturdido
      if (p.equilibrio && !muerto && !info.remate && E.estado !== 'aturdido') {
        const max = Math.max(5, (E.c.vida || 100) * (p.equilibrioK ?? 0.6) * (E.c.jefe ? 2 : 1));
        E.postura = (E.postura || 0) + real * (cuerpo ? 1 : 0.35);
        E.tPostura = performance.now();
        E.posturaMax = max;
        if (E.postura >= max) {
          E.postura = 0;
          J.enemigos.aturdir(E, p.aturdeEquilibrio ?? 2.5);
          FORJA.Audio.sintetico('impacto', { volumen: 0.7, tono: 0.5 });
          this._numero(j, p, s, E, 0, '¡ROTO!');
          FORJA.emitir('enemigo-roto', E);
        }
      }
      // ⏱ pausa de impacto (la más larga si coinciden varias)
      const fuerteG = info.golpe && /^(fuerte|giro|cargado|caida|contra|embestida)$/.test(info.golpe);
      const ms = (muerto ? p.pausaMuerte : cuerpo ? p.pausaGolpe : p.pausaDisparo) * (fuerteG ? 1.5 : 1);
      if (ms > 0 && J.lento) J.lento(0.04, ms / 1000);
      // 📳 temblor (un poco más al matar)
      if (p.temblorGolpe > 0) j.temblor = Math.max(j.temblor || 0, p.temblorGolpe * (cuerpo ? 1 : 0.5) * (muerto ? 1.5 : 1));
      // 💨 empujón hacia atrás (desde el jugador)
      const c = E.cuerpo;
      if (p.empujonGolpe > 0 && c && !E.c.jefe && !E.fijo && !muerto) {
        // retroceso de verdad: el enemigo deja de andar un instante y sale echado (enemigos.js, E.retro)
        const dx = c.pie.x - j.cuerpo.pie.x, dz = c.pie.z - j.cuerpo.pie.z, L = Math.hypot(dx, dz) || 1;
        const m = p.empujonGolpe * (cuerpo ? 1 : 0.5) * (info.empuje || 1), t = 0.22;
        E.retro = { dx: dx / L, dz: dz / L, vel: (2 * m) / t, t, total: t };
      }
      if (p.sonidoGolpe !== false) FORJA.Audio.sintetico('golpe', { volumen: muerto ? 0.9 : 0.6, tono: cuerpo ? 0.75 : 1 });
      if (p.numeros) this._numero(j, p, s, E, real);
    };
    FORJA.on('enemigo-danado', s.oyente);
  },

  // ⬇ al tocar el suelo tras el picado: onda (motor/area.js) con el daño del arma, temblor y polvo
  _aterrizaPicado(j, p, s, a) {
    const J = j.juego, d = a && a.def;
    const dano = (d ? d.dano : 20) * (p.caidaMult ?? 2);
    if (FORJA.Area) FORJA.Area.lanzar(J, j, { forma: 'onda', radio: p.caidaRadio ?? 3, dano, tipoDano: 'normal', empuje: 9, crecer: 0.18, estilo: 'anillos', color: '#e8d9b0', arma: d ? { ...d, tipo: 'cuerpo' } : null });
    if (FORJA.Explosiones) FORJA.Explosiones.efecto(J, (s.vp || (s.vp = new THREE.Vector3())).set(j.cuerpo.pie.x, j.cuerpo.pie.y + 0.2, j.cuerpo.pie.z), 1.4, '#c8b48a', true);
    j.temblor = Math.max(j.temblor || 0, 0.9);
    J.lento && J.lento(0.05, 0.12);
    FORJA.Audio.sintetico('explosion', { volumen: 0.6, tono: 1.3 });
  },

  // ⚡ anillo de carga alrededor de la mira (una cajita HTML: solo cambia su fondo)
  _anilloCarga(j, p, s) {
    const k = Math.min(1, s.tCarga / (p.cargaTiempo ?? 0.8)), ver = s.tCarga > 0.15;
    if (!ver) { if (s.anillo) s.anillo.style.display = 'none'; return; }
    if (!s.anillo) {
      s.anillo = document.createElement('div');
      s.anillo.style.cssText = 'position:absolute;left:50%;top:50%;width:3.2em;height:3.2em;margin:-1.6em 0 0 -1.6em;border-radius:50%;pointer-events:none;z-index:2;-webkit-mask:radial-gradient(circle,transparent 58%,#000 60%);mask:radial-gradient(circle,transparent 58%,#000 60%)';
      FORJA.Hud.capa(j.juego).appendChild(s.anillo);
    }
    s.anillo.style.display = '';
    const col = k >= 1 ? '#ffd23a' : '#ffffffaa';
    s.anillo.style.background = `conic-gradient(${col} ${Math.round(k * 360)}deg, #0006 0)`;
  },

  // 🔢 número que salta del enemigo (10 cajitas recicladas; se coloca una vez y sube sola con CSS)
  _numero(j, p, s, E, real, texto) {
    const J = j.juego, T = THREE;
    if (!s.css) {
      s.css = true;
      if (!document.getElementById('estilos-forja-numeros')) {
        const st = document.createElement('style');
        st.id = 'estilos-forja-numeros';
        st.textContent = '.fh-num-dano{position:absolute;transform:translate(-50%,-50%);font-weight:bold;pointer-events:none;text-shadow:.1em .1em 0 #000,-.05em -.05em 0 #000;z-index:2;animation:fh-num-sube .8s steps(8) forwards;white-space:nowrap}' +
          '@keyframes fh-num-sube{0%{opacity:1;margin-top:0;scale:1.3}20%{scale:1}70%{opacity:1}100%{opacity:0;margin-top:-2.2em}}';
        document.head.appendChild(st);
      }
    }
    const capa = FORJA.Hud.capa(J);
    let el = s.numeros.find((x) => !x.isConnected || x._fin < performance.now());
    if (!el) { if (s.numeros.length >= 10) el = s.numeros.shift(); else el = document.createElement('div'); s.numeros.push(el); }
    const quien = E ? E.cuerpo : j.cuerpo;   // sin enemigo (esquiva perfecta, contraataque…): sobre el jugador
    const pos = (s.v || (s.v = new T.Vector3())).set(quien.pie.x, quien.pie.y + (quien.altura || 1.8) * (E ? 0.9 : 1.25), quien.pie.z).project(J.camara);
    if (pos.z > 1) return;
    const fuerte = !!texto || (E && real >= (E.c.vida || 100) * 0.25);
    el.className = 'fh-num-dano';
    el.style.cssText = `left:${(pos.x * 0.5 + 0.5) * 100 + (Math.random() - 0.5) * 3}%;top:${(-pos.y * 0.5 + 0.5) * 100}%;color:${fuerte ? '#ffd23a' : p.colorNumeros || '#fff'};font-size:${fuerte ? 1.5 : 1.1}em`;
    el.textContent = texto ? texto + (real > 0 ? Math.round(real) : '') : Math.round(real);
    el.style.animation = 'none'; void el.offsetWidth; el.style.animation = '';   // vuelve a empezar la animación
    el._fin = performance.now() + 800;
    if (el.parentNode !== capa) capa.appendChild(el);
  },

  /* 🔒 FIJAR OBJETIVO (como Zelda): elige al enemigo más cerca del centro de la vista; mientras está fijado el jugador
     (y la cámara) lo miran, así moverse de lado es rodearlo. Se suelta al pulsar otra vez, si muere o si se aleja mucho */
  entrada(j, p, s, dt) {
    const E = FORJA.Entrada;
    if (s.tContra > 0) s.tContra -= dt;
    const a = j.armas && j.armas[j.armaActual], cuerpo = a && a.def.tipo === 'cuerpo' && !j.muerto && !j.montado;
    const c = j.cuerpo;
    // ⬇ ataque en caída: atacar en el aire → picado; al tocar suelo, onda
    if (s.picado) {
      c.velocidad.y = Math.min(c.velocidad.y, -22); c.velocidad.x *= 0.9; c.velocidad.z *= 0.9;
      if (c.enSuelo) { s.picado = false; this._aterrizaPicado(j, p, s, a); }
    } else if (p.caida && cuerpo && !c.enSuelo && (c.tAire || 0) > 0.2 && !j.nadando && !j.trepando && E.pulsado('atacar')) {
      s.picado = true; j.ataqueTomado = true; s.tCarga = 0;
      FORJA.emitir('disparo', { jugador: j, arma: a.def, golpe: { nombre: 'caida', anims: ['plunge', 'slash3'], dur: 1.5 } });
    }
    // ⚡ ataque cargado: mantener atacar con cuerpo a cuerpo (el golpe normal sale al pulsar; el cargado al soltar)
    if (p.carga && cuerpo && !s.picado) {
      if (E.mantenido('atacar') && !j.bloqueando) {
        const antes = s.tCarga, ahora = performance.now();
        if (!s.cargaIni) s.cargaIni = ahora;
        s.tCarga = (ahora - s.cargaIni) / 1000;   // tiempo real (la pausa de impacto no la frena)
        if (antes < (p.cargaTiempo ?? 0.8) && s.tCarga >= (p.cargaTiempo ?? 0.8)) FORJA.Audio.sintetico('recoger', { volumen: 0.5, tono: 1.8 });   // ¡listo!
      } else {
        if (s.tCarga >= (p.cargaTiempo ?? 0.8) && j.golpeEspecial) {
          j.golpeEspecial({ nombre: 'cargado', mult: p.cargaMult ?? 2.5, alcance: 0.7, cono: -1.1, empuje: 2.5, giro: true, anims: ['spin', 'slash2'], dur: 1.4 });
          this._numero(j, p, s, null, 0, '¡GIRO!');
        }
        s.tCarga = 0; s.cargaIni = 0;
      }
      this._anilloCarga(j, p, s);
    } else if (s.tCarga) { s.tCarga = 0; this._anilloCarga(j, p, s); }
    const porClic = p.clicDerecho === 'fijar';
    const pulsa = E.pulsado('fijar') || (porClic && E.pulsado('apuntar'));
    const mantiene = E.mantenido('fijar') || (porClic && E.mantenido('apuntar'));
    if (p.fijarModo === 'mantener') {
      if (mantiene && !s.fijado) s.fijado = this._elegir(j, p);
      if (!mantiene) s.fijado = null;
    } else if (pulsa) s.fijado = s.fijado ? null : this._elegir(j, p);
    const F = s.fijado;
    if (F && (F.muerto || j.muerto || F.vida <= 0 || this._dist(j, F) > (p.fijarDistancia || 18) * 1.5)) s.fijado = null;
    j.fijado = s.fijado || null;
    if (!s.fijado) return;
    // girar hacia él (yaw del jugador = cámara) y un poco el pitch hacia su pecho
    const cf = s.fijado.cuerpo, pie = j.cuerpo.pie;
    const dx = cf.pie.x - pie.x, dz = cf.pie.z - pie.z, h = Math.hypot(dx, dz) || 0.01;
    const yaw = Math.atan2(-dx, -dz);
    let dy = (cf.pie.y + (cf.altura || 1.8) * 0.6) - (pie.y + (j.cuerpo.alturaOjos || 1.6));
    const pitch = Math.max(-0.6, Math.min(0.4, Math.atan2(dy, h))) * 0.7 - (j.modoCamara === 'tps' ? 0.12 : 0);
    const k = Math.min(1, dt * (4 + 22 * (p.fijarGiro ?? 0.6)));
    let d = yaw - j.yaw; d = Math.atan2(Math.sin(d), Math.cos(d));
    j.yaw += d * k;
    j.pitch += (pitch - j.pitch) * k;
  },

  despues(j, p, s, dt) {
    const EN = j.juego.enemigos, ahora = performance.now();
    // 🛡 verde = puedes hacer parry (arma con parry o escudo de mano)
    if (EN && EN.aviso && (s.cuadro || 0) % 10 === 0) {
      const a = j.armas && j.armas[j.armaActual], d = a && a.def;
      const puede = p.parryVerde !== false && ((d && d.tipo === 'cuerpo' && (d.parry ?? 0.25) > 0) || (j.escudoMano && !j.escudoGuardado && p.parryEscudo !== false));
      EN.aviso.color = puede ? '#3aff6a' : p.colorAviso || '#ff8a1a';
      EN.aviso.balas = puede && p.parryProyectiles !== false;
    }
    // ⚖ el equilibrio se recupera si dejas de pegarle 2 s (un cuarto por segundo)
    if (p.equilibrio && EN && (s.cuadro = (s.cuadro || 0) + 1) % 6 === 0) {
      for (const E of EN.lista) if (E.postura > 0 && ahora - (E.tPostura || 0) > 2000) E.postura = Math.max(0, E.postura - (E.posturaMax || 50) * 0.25 * dt * 6);
    }
    // ⚔ aviso de remate: un aturdido cerca y delante
    if (p.remate && EN && s.cuadro % 6 === 1) {
      let ve = null;
      const fx = -Math.sin(j.yaw), fz = -Math.cos(j.yaw);
      for (const E of EN.lista) {
        if (E.muerto || E.estado !== 'aturdido') continue;
        const dx = E.cuerpo.pie.x - j.cuerpo.pie.x, dz = E.cuerpo.pie.z - j.cuerpo.pie.z, d = Math.hypot(dx, dz);
        if (d < 3.5 && (dx * fx + dz * fz) / (d || 1) > 0.3) { ve = E; break; }
      }
      const a = j.armas && j.armas[j.armaActual], cuerpo = a && a.def.tipo === 'cuerpo';
      if (!s.avisoRem && ve && FORJA.Hud) { s.avisoRem = FORJA.Hud.pieza(j.juego, 'fh-remate', ''); s.avisoRem.style.cssText = 'position:absolute;left:50%;top:72%;transform:translateX(-50%);font-weight:bold;font-size:1.2em;color:#ffd23a;text-shadow:.1em .1em 0 #000;letter-spacing:.1em;pointer-events:none'; }
      if (s.avisoRem) { const t = ve ? (cuerpo ? '⚔ ¡REMÁTALO! (atacar)' : '⚔ Aturdido: remátalo cuerpo a cuerpo') : ''; if (s.avisoRem.textContent !== t) s.avisoRem.textContent = t; }
    }
    // la marca: un rombo que gira sobre el objetivo (una cajita HTML; solo se mueve su posición)
    if (!p.fijarMarca) return;
    const F = s.fijado;
    if (!s.marca) {
      if (!F) return;
      s.marca = document.createElement('div');
      s.marca.className = 'fh-fijado';
      s.marca.style.cssText = `position:absolute;width:1.4em;height:1.4em;margin:-.7em 0 0 -.7em;pointer-events:none;z-index:2`;
      s.marca.innerHTML = `<div style="position:absolute;inset:0;border:.2em solid ${p.colorMarca || '#ff5a3a'};transform:rotate(45deg);box-shadow:0 0 .3em #000"></div>` +
        (p.equilibrio ? '<div class="fh-eq" style="position:absolute;left:-1.3em;width:4em;top:1.9em;height:.35em;background:#000a;border:1px solid #000"><i style="display:block;height:100%;width:0;background:#ffd23a"></i></div>' : '');
      FORJA.Hud.capa(j.juego).appendChild(s.marca);
    }
    if (!F) { s.marca.style.display = 'none'; return; }
    const v = (s.vm || (s.vm = new THREE.Vector3())).set(F.cuerpo.pie.x, F.cuerpo.pie.y + (F.cuerpo.altura || 1.8) * 1.15, F.cuerpo.pie.z).project(j.juego.camara);
    if (v.z > 1) { s.marca.style.display = 'none'; return; }
    s.marca.style.display = '';
    const eq = p.equilibrio && s.marca.querySelector('.fh-eq i');
    if (eq) { const w = F.estado === 'aturdido' ? 100 : Math.round(100 * Math.min(1, (F.postura || 0) / (F.posturaMax || 1))); if (eq._w !== w) { eq._w = w; eq.style.width = w + '%'; eq.style.background = F.estado === 'aturdido' ? '#ff5a3a' : '#ffd23a'; } }
    s.marca.style.left = (v.x * 0.5 + 0.5) * 100 + '%';
    s.marca.style.top = (-v.y * 0.5 + 0.5) * 100 + '%';
  },

  _dist(j, E) { return Math.hypot(E.cuerpo.pie.x - j.cuerpo.pie.x, E.cuerpo.pie.z - j.cuerpo.pie.z); },

  // el enemigo vivo (no aliado) más cerca del centro de la vista, dentro de la distancia y delante (±70°)
  _elegir(j, p) {
    const EN = j.juego.enemigos;
    if (!EN) return null;
    const max = p.fijarDistancia || 18, fx = -Math.sin(j.yaw), fz = -Math.cos(j.yaw);
    let mejor = null, nota = Infinity;
    for (const E of EN.lista) {
      if (E.muerto || E.vida <= 0 || E.c.actitud === 'aliado' || E.oculto) continue;
      const dx = E.cuerpo.pie.x - j.cuerpo.pie.x, dz = E.cuerpo.pie.z - j.cuerpo.pie.z, d = Math.hypot(dx, dz);
      if (d > max || d < 0.01) continue;
      const cos = (dx * fx + dz * fz) / d;
      if (cos < 0.34) continue;
      const n = (1 - cos) * 3 + d / max;   // centrado pesa más que cerca
      if (n < nota) { nota = n; mejor = E; }
    }
    if (mejor) FORJA.Audio.sintetico('recoger', { volumen: 0.25, tono: 1.6 });
    return mejor;
  },

  detener(j, p, s) {
    if (s && s.marca) s.marca.remove();
    if (s && s.avisoRem) s.avisoRem.remove();
    if (s && s.anillo) s.anillo.remove();
    if (s && s.oyParry) FORJA.off('parry', s.oyParry);
    if (s && s.oyEsquiva) FORJA.off('jugador-esquiva', s.oyEsquiva);
    j.alGolpear = null;
    if (j.juego && j.juego.enemigos) j.juego.enemigos.aviso = null;
    j.fijado = null;
    if (s && s.oyente) FORJA.off ? FORJA.off('enemigo-danado', s.oyente) : null;
    if (s && s.numeros) for (const el of s.numeros) el.remove();
  },
});
