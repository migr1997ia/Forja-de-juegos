/* Módulo GRAVEDAD — caída con velocidad máxima; caída más pesada opcional (estilo Mario).
   Equivale a tu gravity_module.gd. */
FORJA.registrarModulo({
  nombre: 'gravedad',
  etiqueta: 'Gravedad',
  descripcion: 'Tira del jugador hacia abajo cuando no está en el suelo.',
  orden: 40,
  props: [
    { k: 'gravedad', t: 'num', e: 'Gravedad', def: 20, paso: 0.5, ayuda: 'm/s²' },
    { k: 'multCaida', t: 'num', e: 'Mult. al caer', def: 1, paso: 0.05, ayuda: '>1 = cae más rápido de lo que sube (salto más "pesado")' },
    { k: 'velMaxCaida', t: 'num', e: 'Caída máx.', def: 55, paso: 1, ayuda: 'm/s' },
  ],

  fisica(j, p, s, dt) {
    const c = j.cuerpo;
    if (c.enSuelo || j.nadando || j.trepando || j.enPared) return;   // en el agua manda el módulo Nadar
    const g = p.gravedad * (c.velocidad.y < 0 ? p.multCaida : 1);
    c.velocidad.y = Math.max(c.velocidad.y - g * dt, -p.velMaxCaida);
  },
});
