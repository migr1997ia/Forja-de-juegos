/* Módulo SALUD — vida, armadura, daño, caídas y muerte.
   Funciona igual en 1ª y 3ª persona. Otros sistemas hacen daño con  jugador.danar(cantidad, 'origen')
   y curan con  jugador.curar(vida, armadura).
   Al morir: sin control, la cámara cae (1ª persona) o el modelo se tumba (3ª), fundido a negro y luego:
   - en el juego / "Probar con menús": pantalla de Game Over (Reintentar, Cargar, Menú principal)
   - con ▶ Jugar del editor: vuelve a aparecer en el inicio. */
FORJA.registrarModulo({
  nombre: 'salud',
  etiqueta: 'Salud y muerte',
  descripcion: 'Vida y armadura con barra en pantalla, invencibilidad tras un golpe, daño por caída y Game Over.',
  orden: 5,
  activoPorDefecto: false,
  props: [
    { k: 'modoVida', t: 'sel', e: 'Tipo de vida', def: 'puntos', op: [['puntos', '▬ Puntos y barra (Doom, RE)'], ['corazones', '♥ Corazones (Zelda, arcade)']],
      ayuda: 'Corazones: cada golpe quita medio o un corazón (no cuenta cuánto pega). Contenedores y pedazos de corazón suben el máximo' },
    { k: 'corazones', t: 'num', e: 'Corazones al empezar', def: 3, paso: 1, min: 1, si: (v) => v.modoVida === 'corazones' },
    { k: 'corazonesMax', t: 'num', e: 'Corazones máximos', def: 20, paso: 1, min: 1, si: (v) => v.modoVida === 'corazones', ayuda: 'Tope con contenedores' },
    { k: 'danoCorazon', t: 'sel', e: 'Cada golpe quita', def: 'fuerza', si: (v) => v.modoVida === 'corazones',
      op: [['medio', '½ corazón siempre'], ['uno', '1 corazón siempre'], ['fuerza', 'Según la fuerza (½, 1, 2…)']], ayuda: 'Según la fuerza: cada 20 de daño = ½ corazón (mínimo ½)' },
    { k: 'piezasCorazon', t: 'num', e: 'Pedazos para un corazón', def: 4, paso: 1, min: 1, ayuda: 'Zelda: 4 pedazos = 1 contenedor. Con puntos: un contenedor da +20 de vida máxima y cada pedazo su parte (20 ÷ pedazos)' },
    { k: 'vidaMax', t: 'num', e: 'Vida máxima', def: 100, paso: 5, min: 1, si: (v) => v.modoVida !== 'corazones' },
    { k: 'armaduraMax', t: 'num', e: 'Armadura máxima', def: 100, paso: 5, min: 0, ayuda: '0 = el juego no usa armadura' },
    { k: 'armaduraInicial', t: 'num', e: 'Armadura al empezar', def: 0, paso: 5, min: 0 },
    { k: 'tipoArmadura', t: 'sel', e: 'Tipo de armadura', def: 'absorbe', op: [['absorbe', 'Absorbe una parte (Quake / Doom)'], ['escudo', 'Escudo: se gasta antes que la vida (Halo)']] },
    { k: 'absorbe', t: 'rango', e: 'La armadura absorbe', def: 0.66, min: 0, max: 1, paso: 0.05, ayuda: 'Parte del daño que se lleva la armadura (Quake: 2/3). El resto va a la vida', si: (v) => v.tipoArmadura !== 'escudo' },
    { k: 'escudoTraspasa', t: 'bool', e: 'El golpe que rompe el escudo pasa a la vida', def: true, ayuda: 'Si no, el último golpe solo rompe el escudo', si: (v) => v.tipoArmadura === 'escudo' },
    { k: 'invencible', t: 'num', e: 'Invencible tras golpe (s)', def: 0.6, paso: 0.1, min: 0 },
    { k: 'esquivaInvencible', t: 'bool', e: 'Invencible al esquivar', def: true },
    // 🛡 Escudo de fuerza: SOLO lo que se ve de la armadura (Quake o Halo): una esfera de energía alrededor del
    // jugador (motor/campos.js). Los escudos extra (✚ recogible o hechizo 🛡) se ven en su color y con su barra.
    { grupo: '🛡 Escudo de fuerza (cómo se ve la armadura)', si: (v) => v.armaduraMax > 0 },
    { k: 'burbuja', t: 'sel', e: 'La armadura se ve como', def: 'no',
      op: [['no', 'Nada (solo la barra)'], ['hex', '⬡ Escudo de fuerza: hexágonos'], ['ondas', '〰 Escudo de fuerza: ondas'], ['rayos', '⚡ Escudo de fuerza: rayos'], ['anillos', '◎ Escudo de fuerza: anillos'], ['plasma', '🔥 Escudo de fuerza: plasma']],
      ayuda: 'Solo visual: la armadura sigue funcionando igual (Quake o Halo). Cada golpe hace brillar la esfera donde pega, más fuerte al romperse; titila mientras se recarga' },
    { k: 'burbujaVer', t: 'sel', e: 'Se ve', def: 'golpe', si: (v) => v.burbuja && v.burbuja !== 'no',
      op: [['golpe', 'Solo al recibir golpes'], ['siempre', 'Siempre (tenue, más fuerte cuanto más armadura)']] },
    { k: 'colorBurbuja', t: 'color', e: 'Color', def: '#5fd0ff', si: (v) => v.burbuja && v.burbuja !== 'no',
      ayuda: 'Un escudo extra (recogible o hechizo) se ve en su propio color; si es el mismo, el motor lo cambia a dorado' },
    { grupo: 'Regenerar' },
    { k: 'regenerar', t: 'bool', e: 'Regenerar vida', def: false },
    { k: 'regenVel', t: 'num', e: 'Vida por segundo', def: 8, paso: 1, min: 0 },
    { k: 'regenEspera', t: 'num', e: 'Espera tras golpe (s)', def: 4, paso: 0.5, min: 0 },
    { k: 'regenHasta', t: 'rango', e: 'Regenera hasta', def: 1, min: 0.1, max: 1, paso: 0.05, ayuda: '1 = hasta la vida máxima · 0.3 = solo un 30 % (estilo survival)' },
    { k: 'regenArmadura', t: 'bool', e: 'Regenerar armadura', def: false, ayuda: 'Estilo Halo: el escudo se recarga solo si no te golpean un rato' },
    { k: 'regenArmVel', t: 'num', e: 'Armadura por segundo', def: 35, paso: 1, min: 0, si: (v) => v.regenArmadura },
    { k: 'regenArmEspera', t: 'num', e: 'Espera para recargar (s)', def: 3, paso: 0.5, min: 0, si: (v) => v.regenArmadura },
    { k: 'sonidoRecarga', t: 'asset', e: 'Sonido al recargar', def: '', tipoAsset: 'audio', vacio: '(ninguno)', si: (v) => v.regenArmadura },
    { k: 'sonidoEscudoRoto', t: 'asset', e: 'Sonido al vaciarse', def: '', tipoAsset: 'audio', vacio: '(chispazo del motor)', si: (v) => v.armaduraMax > 0 },
    { grupo: 'Caídas' },
    { k: 'caidas', t: 'bool', e: 'Daño por caída', def: true },
    { k: 'alturaSegura', t: 'num', e: 'Altura segura (m)', def: 5, paso: 0.5, min: 0 },
    { k: 'danoPorMetro', t: 'num', e: 'Daño por metro extra', def: 12, paso: 1, min: 0 },
    { grupo: 'Pantalla y sonido' },
    { k: 'barra', t: 'bool', e: 'Barra de vida', def: true },
    { k: 'colorVida', t: 'color', e: 'Color vida', def: '#d23a2a' },
    { k: 'colorArmadura', t: 'color', e: 'Color armadura', def: '#3a8ad2' },
    { k: 'flash', t: 'bool', e: 'Rojo al recibir daño', def: true },
    { k: 'golpeImagen', t: 'bool', e: 'Sacudida de imagen al recibir daño', def: true,
      ayuda: 'La imagen tiembla y los colores se separan un instante (más fuerte cuanto más duele)' },
    { k: 'muerteGris', t: 'bool', e: 'Blanco y negro al morir', def: true, ayuda: 'El color se va mientras la vista cae, antes del fundido' },
    { k: 'efectosEstado', t: 'bool', e: 'Estados en pantalla', def: true,
      ayuda: 'Envenenado = la vista se marea · Aturdido = vista doble · Quemado = bordes naranjas · Congelado = bordes azules' },
    { k: 'fundido', t: 'num', e: 'Fundido al morir (s)', def: 1.6, paso: 0.1, min: 0.1 },
    { k: 'sonidoDano', t: 'asset', e: 'Sonido de daño', def: '', tipoAsset: 'audio', vacio: '(golpe del motor)' },
    { k: 'sonidoMuerte', t: 'asset', e: 'Sonido de muerte', def: '', tipoAsset: 'audio', vacio: '(ninguno)' },
  ],

  iniciar(j, p, s) {
    const H = FORJA.Hud;
    // ♥ corazones: la vida se cuenta en MEDIOS corazones (3 corazones = 6)
    s.cor = p.modoVida === 'corazones';
    j.corazones = s.cor;
    j.vidaMax = s.cor ? Math.max(1, p.corazones || 3) * 2 : p.vidaMax;
    j.armaduraMax = s.cor ? 0 : p.armaduraMax;
    j.piezasCorazon = 0;
    // ♥ contenedor (+1 corazón, y te llena) y pedazo (X pedazos = 1 contenedor)
    j.sumarCorazon = (n = 1) => {
      if (!s.cor) { j.vidaMax += 20 * n; j.vida = j.vidaMax; s.pintado = ''; return true; }   // puntos: +20 al máximo y te llena
      const max = Math.max(1, p.corazonesMax || 20) * 2;
      if (j.vidaMax >= max) { j.vida = j.vidaMax; return true; }
      j.vidaMax = Math.min(max, j.vidaMax + 2 * n); j.vida = j.vidaMax;
      FORJA.emitir('corazon-nuevo', j);
      return true;
    };
    j.sumarPieza = (n = 1) => {
      if (!s.cor) {   // puntos: cada pedazo sube el máximo al momento (un contenedor = 20 → 4 pedazos = 5 cada uno) y cura eso
        const extra = (20 / Math.max(1, p.piezasCorazon || 4)) * n;
        j.vidaMax += extra; j.vida = Math.min(j.vidaMax, j.vida + extra); s.pintado = '';
        return true;
      }
      j.piezasCorazon += n;
      const k = Math.max(1, p.piezasCorazon || 4);
      while (j.piezasCorazon >= k) { j.piezasCorazon -= k; j.sumarCorazon(1); }
      s.pintado = '';
      return true;
    };
    s.ojos0 = j.alturaOjos;
    s.pintado = '';
    if (p.barra) {
      s.barras = H.pieza(j.juego, 'fh-barras',
        `<div class="fh-barra fh-vida" style="--fh-color:${p.colorVida}"><span class="fh-ico">♥</span><span class="fh-caja"><div class="fh-lleno"></div></span><span class="fh-num"></span></div>` +
        (p.armaduraMax > 0 && p.modoVida !== 'corazones' ? `<div class="fh-barra fh-arm" style="--fh-color:${p.colorArmadura}"><span class="fh-ico">⛨</span><span class="fh-caja"><div class="fh-lleno"></div></span><span class="fh-num"></span></div>` : '') +
        `<div class="fh-barra fh-fza" style="display:none"><span class="fh-ico">⬡</span><span class="fh-caja"><div class="fh-lleno"></div></span><span class="fh-num"></span></div>`);
    }
    // 🛡 escudo extra (recogible o hechizo): una segunda barra en su color mientras dura
    s.fTemp = null; s.fFlash = 0;
    // la armadura vista como escudo de fuerza (v0.46.76 tenía "escudo de base": se lee como su aspecto)
    s.burbuja = p.burbuja && p.burbuja !== 'no' ? p.burbuja : (p.fuerzaBase ? (p.fuerzaEstilo || 'hex') : 'no');
    s.colorArm = p.burbuja && p.burbuja !== 'no' ? (p.colorBurbuja || '#5fd0ff') : (p.fuerzaColor || p.colorBurbuja || '#5fd0ff');
    // op: { seg (0 = hasta romperse), aguante (0 = no se rompe), bloquea %, estilo, color }
    j.activarEscudo = (op = {}) => {
      let color = op.color || '#ffcc4a';
      if (s.burbuja !== 'no' && j.armaduraMax > 0 && color.toLowerCase() === String(s.colorArm).toLowerCase()) color = '#ffcc4a';   // otro color que la armadura
      const seg = op.seg > 0 ? op.seg : Infinity, vida = op.aguante > 0 ? op.aguante : Infinity;
      s.fTemp = { t: seg, seg, vida, max: vida, bloquea: Math.min(1, (op.bloquea ?? 100) / 100), estilo: op.estilo || 'hex', color };
      s.fFlash = 0.5;
      FORJA.Audio.sintetico('disparo', { volumen: 0.4, tono: 0.5 });
      FORJA.emitir('escudo-magico', { jugador: j, activo: true });
      return true;
    };
    j.escudoActivo = () => !!s.fTemp;
    s.rojo = H.pieza(j.juego, 'fh-rojo');
    s.negro = H.pieza(j.juego, 'fh-negro');
    this._revivir(j, p, s);

    // Lo que usan los demás (enemigos, trampas, pickups…). Devuelve el daño que entró a la vida.
    j.danar = (cantidad, origen = '', de = null) => {
      if (j.muerto || !(cantidad > 0)) return 0;
      // 🛡 bloqueo / parry con arma cuerpo a cuerpo (módulo Armas): puede reducirlo o pararlo entero
      if (j.alBloquear && origen !== 'vacio') { cantidad = j.alBloquear(cantidad, origen, de); if (!(cantidad > 0)) return 0; }
      // 🛡 escudo extra (recogible o hechizo): antes que la armadura
      cantidad = this._escudoFuerza(j, p, s, cantidad, origen, de);
      if (!(cantidad > 0)) return 0;
      // 🛡 hechizo escudo (módulo Armas): para todo o parte del golpe
      if (j.alEscudo && origen !== 'vacio') { cantidad = j.alEscudo(cantidad, origen, de); if (!(cantidad > 0)) return 0; }
      // el daño del entorno (lava, ácido, ahogarse) no respeta ni da invencibilidad: si no, la lava quemaría a medias
      const ambiente = origen === 'lava' || origen === 'agua' || origen === 'veneno' || origen === 'ahogo' || origen === 'aplastar';   // aplastar: trituradora
      if (!ambiente && origen !== 'vacio' && (s.invencible > 0 || (p.esquivaInvencible && j.esquivando))) return 0;
      let aVida = cantidad;
      if (j.armadura > 0 && origen !== 'vacio') {
        const habia = j.armadura;
        if (p.tipoArmadura === 'escudo') {
          // Halo: el escudo se lo come todo; lo que sobra pasa a la vida (o nada, si así se eligió)
          const aArmadura = Math.min(j.armadura, cantidad);
          j.armadura -= aArmadura;
          aVida = p.escudoTraspasa === false ? 0 : cantidad - aArmadura;
        } else {
          const aArmadura = Math.min(j.armadura, cantidad * p.absorbe);
          j.armadura -= aArmadura;
          aVida = cantidad - aArmadura;
        }
        this._burbuja(j, p, s, de, habia > 0 && j.armadura <= 0.001);   // 🛡 la burbuja del escudo brilla
        if (habia > 0 && j.armadura <= 0.001) {
          j.armadura = 0;
          if (p.sonidoEscudoRoto) FORJA.Audio.efecto(p.sonidoEscudoRoto);
          else FORJA.Audio.sintetico('impacto', { volumen: 0.7, tono: 1.4 });
          FORJA.emitir('jugador-sin-armadura', j);
        }
      }
      // ♥ corazones: no importa cuánto pegue, quita medio, uno o según la fuerza (cada 20 = ½)
      if (s.cor) aVida = p.danoCorazon === 'medio' ? 1 : p.danoCorazon === 'uno' ? 2 : Math.max(1, Math.round(aVida / 20));
      j.vida = Math.max(0, j.vida - aVida);
      if (origen === 'enemigo' && de && de.c && FORJA.Estados) FORJA.Estados.jugador(j, de.c, de.c.tipoDano || 'normal');
      if (!ambiente) s.invencible = p.invencible;
      s.desdeGolpe = 0;
      if (p.flash) {
        s.rojo.style.transition = 'none';
        s.rojo.style.opacity = Math.min(1, 0.35 + cantidad / p.vidaMax).toFixed(2);
        void s.rojo.offsetWidth;
        s.rojo.style.transition = '';
        s.rojo.style.opacity = 0;
      }
      // 💥 sacudida de imagen (motor/efectos.js)
      if (p.golpeImagen !== false && FORJA.Efectos && j.juego) FORJA.Efectos.momento(j.juego.vista, 'golpe', Math.min(1, 0.45 + cantidad / (p.vidaMax || 100)));
      if (p.sonidoDano) FORJA.Audio.efecto(p.sonidoDano, { tono: 0.9 + Math.random() * 0.2 });
      else FORJA.Audio.sintetico('golpe', { volumen: 0.8, tono: 0.7 });
      FORJA.emitir('jugador-dano', j, aVida, origen);
      if (j.vida <= 0) this._morir(j, p, s);
      return aVida;
    };
    s.recargando = false;
    j.curar = (vida = 0, armadura = 0) => {
      if (j.muerto) return false;
      const antes = j.vida + j.armadura;
      if (s.cor && vida > 0) vida = Math.max(1, Math.round(vida / 12.5));   // ♥ cada 25 de cura = 1 corazón
      j.vida = Math.min(j.vidaMax, j.vida + vida);
      j.armadura = Math.min(j.armaduraMax, j.armadura + armadura);
      return j.vida + j.armadura > antes;
    };
  },

  /* 🛡 Burbuja del escudo de energía (motor/campos.js): brilla donde pega el golpe; rota = destello fuerte */
  _burbuja(j, p, s, de, rota) {
    if (s.burbuja === 'no' || !FORJA.Campo) return;
    const pt = de && de.cuerpo && de.cuerpo.pie ? (s.vb || (s.vb = new THREE.Vector3())).copy(de.cuerpo.pie).setY(de.cuerpo.pie.y + 1.2) : null;
    this._campoF(j, s).golpe(pt);
    s.fFlash = Math.max(s.fFlash, rota ? 0.5 : 0.35);   // luego se apaga sola
  },

  /* 🛡 Escudo extra (recogible o hechizo): para el golpe antes que la armadura. Lo del entorno pasa igual */
  _escudoFuerza(j, p, s, cant, origen, de) {
    if (/^(vacio|lava|agua|ahogo|aplastar|caida|veneno)$/.test(origen || '')) return cant;
    const pt = de && de.cuerpo && de.cuerpo.pie ? (s.vf || (s.vf = new THREE.Vector3())).copy(de.cuerpo.pie).setY(de.cuerpo.pie.y + 1.2) : null;
    const T0 = s.fTemp;
    if (T0) {
      const para = cant * T0.bloquea;
      T0.vida -= para;
      cant -= para;
      this._campoF(j, s).golpe(pt);
      s.fFlash = 0.35;
      FORJA.Audio.sintetico('impacto', { volumen: 0.5, tono: 1.6 });
      if (T0.vida <= 0) { s.fTemp = null; s.fFlash = 0.5; FORJA.Audio.sintetico('impacto', { volumen: 0.8, tono: 0.7 }); FORJA.emitir('escudo-magico', { jugador: j, activo: false, roto: true }); }
      if (!(cant > 0)) return 0;
    }
    return cant;
  },
  _campoF(j, s) {
    if (!s.campoF) s.campoF = FORJA.Campo ? FORJA.Campo.crear({ forma: 'esfera', fuerza: 0 }) : { malla: new THREE.Object3D(), golpe() {}, fuerza() {}, color() {}, estilo() {}, valor() { return 0; } };
    if (s.campoF.malla.parent !== j.escena) j.escena.add(s.campoF.malla);
    return s.campoF;
  },
  // cada cuadro: recarga, tiempo del temporal y cómo se ve la esfera
  _actualizarFuerza(j, p, s, dt) {
    if (s.fTemp && (s.fTemp.t -= dt) <= 0) { s.fTemp = null; FORJA.emitir('escudo-magico', { jugador: j, activo: false }); }
    if (s.fFlash > 0) s.fFlash -= dt;
    // cuánto se ve: extra = fuerte en su color (se apaga en sus últimos 0,4 s) · armadura = al golpear, tenue siempre o
    // titilando mientras se recarga
    let meta = 0, estilo = s.burbuja !== 'no' ? s.burbuja : 'hex', color = s.colorArm;
    const conArm = s.burbuja !== 'no' && j.armaduraMax > 0;
    if (s.fTemp) { meta = Math.min(1, s.fTemp.t / 0.4); estilo = s.fTemp.estilo; color = s.fTemp.color; }
    else if (conArm) {
      if (p.burbujaVer === 'siempre' && j.armadura > 0) meta = 0.12 + 0.3 * (j.armadura / j.armaduraMax);
      if (s.recargando && !j.muerto) meta = Math.max(meta, 0.12 + 0.08 * Math.sin(performance.now() / 120));
    }
    if (s.fFlash > 0 && (s.fTemp || conArm)) meta = Math.max(meta, Math.min(1.2, s.fFlash * 3));
    if (meta <= 0 && !s.campoF) return;
    const c = this._campoF(j, s);
    if (s.fEst !== estilo) { s.fEst = estilo; c.estilo(estilo); }
    if (s.fCol !== color) { s.fCol = color; c.color(color); }
    if (Math.abs((s.fMeta ?? -1) - meta) > 0.02) { s.fMeta = meta; c.fuerza(meta, 0.15); }
    const pie = j.cuerpo.pie, alto = j.cuerpo.altura || 1.8;
    c.malla.position.set(pie.x, j.cuerpo.visY + alto * 0.5, pie.z);
    c.malla.scale.setScalar(Math.max(0.9, alto * 0.62));
    c.malla.visible = c.valor() > 0.001 || meta > 0;
  },

  _revivir(j, p, s) {
    j.vida = j.vidaMax;
    j.armadura = Math.min(p.armaduraInicial, j.armaduraMax);
    s.fTemp = null;
    j.muerto = false;
    j.sinControl = false;
    j.bajarCamara = 0;
    j.alturaOjos = s.ojos0;
    s.invencible = 0;
    s.desdeGolpe = 99;
    s.tMuerte = -1;
    s.altoMax = j.cuerpo.pie.y;
    s.negro.style.opacity = 0;
    if (FORJA.Efectos && j.juego) FORJA.Efectos.momento(j.juego.vista, 'gris', 0);
    if (j.modelo) j.modelo.rotation.z = 0;
  },

  _morir(j, p, s) {
    j.muerto = true;
    j.sinControl = true;
    s.tMuerte = 0;
    if (p.sonidoMuerte) FORJA.Audio.efecto(p.sonidoMuerte);
    FORJA.emitir('jugador-muriendo', j);
  },

  fisica(j, p, s, dt) {
    const c = j.cuerpo;
    if (s.invencible > 0) s.invencible -= dt;
    if ((j.efectos || j._estTxt) && FORJA.Estados) FORJA.Estados.ticJugador(j, dt);
    s.desdeGolpe += dt;
    if (j.muerto) {
      // al morir el cuerpo se frena (la gravedad lo sigue bajando)
      c.velocidad.x *= Math.max(0, 1 - dt * 6);
      c.velocidad.z *= Math.max(0, 1 - dt * 6);
      return;
    }
    if (p.regenerar && !s.cor && s.desdeGolpe > p.regenEspera && j.vida < j.vidaMax * p.regenHasta) {
      j.vida = Math.min(j.vidaMax * p.regenHasta, j.vida + p.regenVel * dt);
    }
    // armadura que se recarga sola (escudo estilo Halo)
    const recarga = p.regenArmadura && j.armaduraMax > 0 && s.desdeGolpe > p.regenArmEspera && j.armadura < p.armaduraMax;
    if (recarga) {
      if (!s.recargando && p.sonidoRecarga) FORJA.Audio.efecto(p.sonidoRecarga);
      j.armadura = Math.min(p.armaduraMax, j.armadura + p.regenArmVel * dt);
    }
    s.recargando = recarga;
  },

  despues(j, p, s, dt) {
    const c = j.cuerpo;
    // 🛡 escudo de fuerza (armadura vista como esfera y escudo extra): sigue al jugador
    this._actualizarFuerza(j, p, s, dt);
    // Caídas: altura máxima en el aire contra el punto donde aterriza (un teletransporte no cuenta)
    if (s.saltos !== j.saltos || j.nadando) { s.saltos = j.saltos; s.altoMax = c.pie.y; }   // caer al agua no duele
    if (!c.enSuelo) s.altoMax = Math.max(s.altoMax, c.pie.y);
    else {
      const caida = s.altoMax - c.pie.y;
      if (p.caidas && !j.muerto && caida > p.alturaSegura) j.danar((caida - p.alturaSegura) * p.danoPorMetro, 'caida');
      s.altoMax = c.pie.y;
    }

    if (j.muerto && s.tMuerte >= 0) {
      s.tMuerte += dt;
      const k = Math.min(1, s.tMuerte / 0.7);
      // 1ª persona: la vista cae al suelo · 3ª: el modelo se tumba y la cámara baja
      j.alturaOjos = s.ojos0 + (0.25 - s.ojos0) * k;
      j.bajarCamara = 0.9 * k;
      // 3ª persona sin animación de muerte: el modelo se tumba (con "death"/"die" la animación lo hace)
      const acc = j.modelo && j.modelo.userData.acciones;
      if (j.modelo && j.modoCamara === 'tps' && !(acc && (acc.death || acc.die))) j.modelo.rotation.z = (Math.PI / 2) * k;
      s.negro.style.opacity = Math.min(1, Math.max(0, (s.tMuerte - 0.4) / p.fundido)).toFixed(2);
      if (p.muerteGris !== false && FORJA.Efectos) FORJA.Efectos.momento(j.juego.vista, 'gris', Math.min(1, s.tMuerte / 0.8));
      if (s.tMuerte >= 0.4 + p.fundido && !s.avisado) {
        s.avisado = true;
        FORJA.emitir('jugador-muerto', j.juego, j);
        // Sin Partida (▶ Jugar del editor): volver a empezar en el inicio
        if (!j.juego.conPartida) {
          setTimeout(() => {
            if (!j.juego.enMarcha) return;
            j.reaparecer();
            this._revivir(j, p, s);
            s.avisado = false;
          }, 500);
        }
      }
    }

    // Barras: el HTML solo se toca cuando cambia el número
    if (s.barras) {
      const v = Math.ceil(j.vida), a = Math.ceil(j.armadura);
      const F0 = s.fTemp, fx = F0 ? (isFinite(F0.max) ? Math.ceil(Math.max(0, F0.vida)) : Math.ceil(Math.max(0, F0.t))) : -1;
      const clave = v + '|' + a + '|' + j.vidaMax + '|' + j.piezasCorazon + '|' + fx + '|' + (F0 ? F0.color : '');
      if (clave !== s.pintado && s.cor) {
        // ♥ fila de corazones (llenos, medios y vacíos) y los pedazos que llevas
        s.pintado = clave;
        const pv = s.barras.querySelector('.fh-vida');
        let h = '';
        for (let i = 0; i < j.vidaMax / 2; i++) {
          const q = Math.max(0, Math.min(2, v - i * 2));
          h += `<span style="display:inline-block;margin-right:.08em;${q === 1 ? `background:linear-gradient(90deg,${p.colorVida} 50%,#3a3a3a 50%);-webkit-background-clip:text;background-clip:text;color:transparent` : `color:${q === 2 ? p.colorVida : '#3a3a3a'}`}">♥</span>`;
          if (i % 10 === 9) h += '<br>';
        }
        const k = Math.max(1, p.piezasCorazon || 4);
        pv.innerHTML = `<span class="fh-corazones" style="font-size:1.3em;line-height:1.1;text-shadow:none;filter:drop-shadow(2px 2px 0 #000)">${h}</span>${j.piezasCorazon ? `<small style="margin-left:.5em;opacity:.85">◔ ${j.piezasCorazon}/${k}</small>` : ''}`;
        pv.classList.toggle('fh-bajo', v > 0 && v <= 2);
        FORJA.Hud.cambio(j.juego, s.barras);
      }
      if (clave !== s.pintado) {
        s.pintado = clave;
        const pv = s.barras.querySelector('.fh-vida');
        pv.querySelector('.fh-lleno').style.width = (100 * j.vida / j.vidaMax).toFixed(1) + '%';
        pv.querySelector('.fh-num').textContent = v;
        const bajo = (j.juego._hudCfg && j.juego._hudCfg.avisoBajo) ?? 0.25;
        pv.classList.toggle('fh-bajo', bajo > 0 && j.vida > 0 && j.vida <= j.vidaMax * bajo);
        const pa = s.barras.querySelector('.fh-arm');
        if (pa) {
          pa.querySelector('.fh-lleno').style.width = (100 * j.armadura / Math.max(1, j.armaduraMax)).toFixed(1) + '%';
          pa.querySelector('.fh-num').textContent = a;
          pa.style.opacity = a > 0 ? 1 : 0.45;
        }
        // ⬡ segunda barra mientras dura un escudo extra (recogible o hechizo), en su color: aguante o segundos
        const pf = s.barras.querySelector('.fh-fza');
        if (pf) {
          pf.style.display = F0 ? '' : 'none';
          if (F0) {
            pf.style.setProperty('--fh-color', F0.color);
            const k = isFinite(F0.max) ? F0.vida / F0.max : (isFinite(F0.seg) ? F0.t / F0.seg : 1);
            pf.querySelector('.fh-lleno').style.width = (100 * Math.max(0, Math.min(1, k))).toFixed(1) + '%';
            pf.querySelector('.fh-num').textContent = isFinite(F0.max) ? fx : (isFinite(F0.seg) ? fx + 's' : '∞');
          }
        }
        FORJA.Hud.cambio(j.juego, s.barras);
      }
    }
  },

  detener(j, p, s) {
    j.danar = null;
    j.curar = null;
    if (s && s.campoF && s.campoF.malla.parent) s.campoF.malla.parent.remove(s.campoF.malla);
    j.activarEscudo = null;
  },
});
