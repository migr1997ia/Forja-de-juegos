/* Módulo ESQUIVA / DASH — impulso corto hacia donde te mueves (o siempre hacia atrás).
   Con "Invencible al esquivar" del módulo Salud, no recibes daño mientras dura.
   1ª persona: la vista se estira un instante (FOV) · 3ª: animación "roll" / "dodge" si el modelo la trae. */
FORJA.registrarModulo({
  nombre: 'esquiva',
  etiqueta: 'Esquiva / dash',
  descripcion: 'Q / LB / botón táctil. Impulso rápido con espera entre usos.',
  orden: 22,
  activoPorDefecto: false,
  props: [
    { k: 'modo', t: 'sel', e: 'Dirección', def: 'mover', op: [['mover', 'Hacia donde te mueves (adelante si estás quieto)'], ['atras', 'Siempre hacia atrás'], ['camara', 'Hacia donde miras']] },
    { k: 'fuerza', t: 'num', e: 'Velocidad (m/s)', def: 14, paso: 0.5, min: 1 },
    { k: 'duracion', t: 'num', e: 'Duración (s)', def: 0.18, paso: 0.01, min: 0.05 },
    { k: 'espera', t: 'num', e: 'Espera entre usos (s)', def: 0.7, paso: 0.05, min: 0 },
    { k: 'enAire', t: 'bool', e: 'También en el aire', def: false },
    { k: 'subeFov', t: 'num', e: 'Estirar vista (1ª p.)', def: 8, paso: 1, min: 0, ayuda: 'Grados de FOV extra durante el dash' },
    { k: 'sonido', t: 'asset', e: 'Sonido', def: '', tipoAsset: 'audio', vacio: '(ninguno)' },
  ],

  iniciar(j, p, s) {
    s.t = 0;
    s.espera = 0;
    s.dir = new THREE.Vector3();
    s.fov0 = j.camara.fov;
    j.esquivando = false;
  },

  entrada(j, p, s) {
    const E = FORJA.Entrada, c = j.cuerpo;
    if (s.espera > 0 || s.t > 0 || j.muerto) return;
    if (!E.pulsado('esquivar') || (!c.enSuelo && !p.enAire)) return;
    const sin = Math.sin(j.yaw), cos = Math.cos(j.yaw);
    let mx = E.mover.x, my = E.mover.y;
    if (p.modo === 'atras') { mx = 0; my = -1; }
    else if (p.modo === 'camara' || (!mx && !my)) { mx = 0; my = 1; }
    s.dir.set(mx * cos - my * sin, 0, -mx * sin - my * cos).normalize();
    s.t = p.duracion;
    s.espera = p.espera;
    if (p.sonido) FORJA.Audio.efecto(p.sonido);
    FORJA.emitir('jugador-esquiva', j);
  },

  fisica(j, p, s, dt) {
    if (s.espera > 0) s.espera -= dt;
    j.esquivando = s.t > 0;
    if (s.t <= 0) return;
    // más fuerte al principio, se suaviza al final
    const k = Math.min(1, (s.t / p.duracion) * 1.6);
    j.cuerpo.velocidad.x = s.dir.x * p.fuerza * k;
    j.cuerpo.velocidad.z = s.dir.z * p.fuerza * k;
    s.t -= dt;
  },

  despues(j, p, s, dt) {
    const cam = j.camara;
    const meta = s.fov0 + (j.esquivando && j.modoCamara === 'fps' ? p.subeFov : 0);
    if (Math.abs(cam.fov - meta) > 0.05) {
      cam.fov += (meta - cam.fov) * Math.min(1, dt * 14);
      cam.updateProjectionMatrix();
    }
  },

  detener(j, p, s) {
    j.camara.fov = s.fov0;
    j.camara.updateProjectionMatrix();
    j.esquivando = false;
  },
});
