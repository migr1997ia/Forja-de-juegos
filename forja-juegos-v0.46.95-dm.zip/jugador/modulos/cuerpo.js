/* Módulo CUERPO — tamaño de la cápsula y límites de escalón y pendiente.
   Equivale al CollisionShape3D + CharacterBody3D de tu jugador en Godot. */
FORJA.registrarModulo({
  nombre: 'cuerpo',
  etiqueta: 'Cuerpo',
  descripcion: 'Tamaño de la cápsula de colisión, altura de los ojos, escalón y pendiente que puede subir.',
  orden: 0,
  obligatorio: true,
  props: [
    { k: 'radio', t: 'num', e: 'Radio', def: 0.35, paso: 0.01, ayuda: 'Grosor del jugador (m)' },
    { k: 'altura', t: 'num', e: 'Altura', def: 1.8, paso: 0.05, ayuda: 'Altura total (m)' },
    { k: 'alturaOjos', t: 'num', e: 'Altura ojos', def: 1.6, paso: 0.05, ayuda: 'Donde va la cámara en primera persona' },
    { k: 'escalon', t: 'num', e: 'Escalón máx.', def: 0.4, paso: 0.01, ayuda: 'Bordes más bajos se suben sin saltar' },
    { k: 'pendienteMax', t: 'num', e: 'Pendiente máx. °', def: 46, paso: 1, ayuda: 'Más inclinado que esto, resbala' },
  ],
});
