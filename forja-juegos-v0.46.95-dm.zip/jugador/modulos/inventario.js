/* Módulo INVENTARIO — la mochila del jugador (estilo Resident Evil o lista) y su pantalla (Tab / I).
   Los objetos y recetas son del proyecto (Juego ▸ Objetos); la mochila y la pantalla viven en motor/inventario.js.
   Con "Armas y munición dentro" (estilo RE) las armas y la munición ocupan casilla: la munición de las armas es la
   de la mochila (j.municion se iguala a ella cada cuadro) y combinar munición + arma recarga.
   Usar curas (Salud), mochilas (+casillas) y notas; examinar en 3D; combinar con recetas; tirar al suelo.
   Abrir: con pausa (RE clásico) o en tiempo real (el mundo sigue; tú no te mueves), a elección del creador. */
FORJA.registrarModulo({
  nombre: 'inventario',
  etiqueta: 'Inventario',
  descripcion: 'Mochila con casillas (Resident Evil) o lista. Usar, examinar, combinar y tirar. Tab / I la abre.',
  orden: 57,                  // después de Armas (55): se engancha a darArma / darMunicion
  activoPorDefecto: false,
  props: [
    { k: 'estilo', t: 'sel', e: 'Estilo', def: 'casillas', op: [['casillas', 'Casillas (Resident Evil 1-3)'], ['lista', 'Lista sin límite']],
      ayuda: 'Casillas: un objeto por casilla (se apila hasta su "pila"); si no cabe, no lo recoges' },
    { k: 'casillas', t: 'num', e: 'Casillas al empezar', def: 8, paso: 1, min: 1, si: (v) => v.estilo === 'casillas' },
    { k: 'casillasMax', t: 'num', e: 'Casillas como máximo', def: 20, paso: 1, min: 1, si: (v) => v.estilo === 'casillas', ayuda: 'Con mochilas se llega hasta aquí' },
    { k: 'armasDentro', t: 'bool', e: 'Armas y munición dentro', def: false,
      ayuda: 'Estilo RE: ocupan casilla, la recarga gasta la munición de la mochila y combinar munición + arma recarga. Apagado: van aparte como ahora' },
    { k: 'abrir', t: 'sel', e: 'Al abrirlo', def: 'pausa', op: [['pausa', 'El juego se para (RE clásico)'], ['tiempo', 'El mundo sigue (supervivencia, RE 7)']] },
    { k: 'verVida', t: 'bool', e: 'Ver la vida en el inventario', def: true },
    { k: 'verArmadura', t: 'bool', e: 'Ver la armadura en el inventario', def: true, ayuda: 'Solo si hay armadura (módulo Salud y muerte)' },
    { k: 'tamano', t: 'rango', e: 'Tamaño de la pantalla', def: 1, min: 0.6, max: 1.6, paso: 0.05, av: true },
    { k: 'sonido', t: 'asset', e: 'Sonido al abrir', def: '', tipoAsset: 'audio', vacio: '(del motor)', av: true },
  ],

  iniciar(j, p, s) {
    const inv = (j.inventario = new FORJA.Inventario(j.juego, p));
    s.ui = j.inventarioUI = new FORJA.InventarioUI(j, this);
    s.ui.pausa = p.abrir !== 'tiempo';
    j.armaEquipada = null;
    j.sincronizarInventario = () => this.sincronizar(j);
    // la mochila al empezar (Juego ▸ Objetos). Una partida cargada o el paso de nivel la reemplazan con lo que llevabas
    for (const x of j.juego.proyecto.inventarioInicial || []) {
      if (!x || !x.id) continue;
      if (x.k === 'mun' && !inv.armasDentro) { if (j.municion && x.id in j.municion) j.municion[x.id] += x.n || 1; continue; }
      inv.agregar(x.k || 'obj', x.id, Math.max(1, x.n | 0));
    }
    if (!inv.armasDentro) return;
    // Armas dentro: lo que ya traía el módulo Armas (armas del principio y su munición) entra en la mochila
    const proyecto = j.juego.proyecto;
    for (const a of j.armas || []) if (!(j.armasExtra || []).includes(a.def)) inv.agregar('arma', a.def.id);
    for (const [tipo, n] of Object.entries(j.municion || {})) if (n > 0) inv.agregar('mun', tipo, n);
    const actual = j.armas && j.armas[j.armaActual];
    j.armaEquipada = actual && !(j.armasExtra || []).includes(actual.def) ? actual.def.id : null;
    // recoger armas y munición: van a la mochila (si cabe)
    const darArma0 = j.darArma, darMunicion0 = j.darMunicion;
    j.darArma = (id, extra = 0) => {
      const d = (proyecto.armas || []).find((x) => x.id === id || x.nombre === id);
      if (!d) return false;
      if (inv.contar('arma', d.id)) {
        // ya la tienes: su munición a la mochila
        if (!d.municion) return darArma0 ? darArma0(id, extra) : false;
        const n = extra > 0 ? extra : d.reserva;
        return n > 0 && inv.agregar('mun', d.municion, n) < n;
      }
      if (!inv.cabe('arma', d.id)) { this._sinSitio(j); return false; }
      inv.agregar('arma', d.id);
      if (d.municion && d.reserva > 0) inv.agregar('mun', d.municion, d.reserva);
      if (!j.armaEquipada) j.armaEquipada = d.id;
      this.sincronizar(j);
      return true;
    };
    j.darMunicion = (id, n) => {
      const tipo = (proyecto.municiones || []).find((m) => m.id === id || m.nombre === id);
      if (!tipo) return darMunicion0 ? darMunicion0(id, n) : false;   // munición propia de un arma: como siempre
      const resto = inv.agregar('mun', tipo.id, n);
      if (resto === n) { this._sinSitio(j); return false; }
      this.sincronizar(j);
      return true;
    };
    this.sincronizar(j);
  },

  entrada(j, p, s) {
    if (s.ui.abierto || j.muerto || j.sinControl) return;
    if (FORJA.Entrada.pulsado('inventario')) this.abrir(j, p, s);
  },

  abrir(j, p, s, baul = false) {
    if (!s) s = j.estados.inventario;
    if (!p) p = j.props('inventario');
    s.ui.el && s.ui.el.style.setProperty('--fi-t', p.tamano || 1);
    s.ui.abrir(baul);
    if (s.ui.el) s.ui.el.style.setProperty('--fi-t', p.tamano || 1);
    if (p.sonido) FORJA.Audio.efecto(p.sonido); else FORJA.Audio.sintetico('recoger', { volumen: 0.4, tono: 0.7 });
  },

  despues(j, p, s) {
    const inv = j.inventario;
    if (!inv || !inv.armasDentro) return;
    // la recarga del módulo Armas gasta de j.municion: se descuenta de la mochila (y j.municion = lo que hay en ella)
    for (const m of j.juego.proyecto.municiones || []) {
      const enMochila = inv.contar('mun', m.id), enJ = j.municion[m.id] || 0;
      if (enJ < enMochila) inv.gastar('mun', m.id, enMochila - enJ);
      j.municion[m.id] = inv.contar('mun', m.id);
    }
    // cambiar de arma con 1-9 / rueda: la equipada es la que tienes en la mano
    const a = j.armas && j.armas[j.armaActual];
    if (a && !(j.armasExtra || []).includes(a.def)) j.armaEquipada = a.def.id;
  },

  // las armas del módulo Armas = las de la mochila (los puños siguen siempre)
  sincronizar(j) {
    const inv = j.inventario;
    if (!inv) return;
    if (inv.armasDentro && j.armas) {
      const defs = j.juego.proyecto.armas || [], extra = j.armasExtra || [];
      const antes = new Map(j.armas.map((a) => [a.def.id, a]));
      const deMochila = inv.items.filter((it) => it && it.k === 'arma').map((it) => {
        const def = defs.find((d) => d.id === it.id);
        return def && (antes.get(def.id) || { def, cargador: def.cargador > 0 ? def.cargador : 0, reserva: 0 });
      }).filter(Boolean);
      j.armas = [...j.armas.filter((a) => extra.includes(a.def)), ...deMochila];
      const i = j.armas.findIndex((a) => a.def.id === j.armaEquipada);
      j.armaActual = i >= 0 ? i : 0;
      for (const m of j.juego.proyecto.municiones || []) j.municion[m.id] = inv.contar('mun', m.id);
    }
  },

  _sinSitio(j) {
    const ahora = performance.now();
    if (this._tAviso && ahora - this._tAviso < 2000) return;
    this._tAviso = ahora;
    if (j.juego.recogibles && j.juego.recogibles.mensaje) j.juego.recogibles.mensaje('No tienes sitio');
  },

  /* ---------- Acciones de la pantalla (devuelven el texto del aviso) ---------- */
  usarObjeto(j, i) {
    const inv = j.inventario, it = inv.items[i], d = inv.def(it);
    if (!it || !d) return '';
    if (it.k === 'arma') {
      if (j.armaEquipada === it.id) { j.armaEquipada = null; this.sincronizar(j); return `${d.nombre}: guardada`; }
      j.armaEquipada = it.id;
      this.sincronizar(j);
      return `${d.nombre}: equipada`;
    }
    if (d.tipo === 'cura') {
      if (!j.curar) return 'Activa el módulo Salud y muerte para curarte';
      const hace = (d.vida > 0 && j.vida < j.vidaMax) || (d.armadura > 0 && j.armadura < (j.armaduraMax || 0));
      if (!hace) return 'No lo necesitas ahora';
      j.curar(d.vida || 0, d.armadura || 0);
      inv.quitar(i, 1);
      if (d.sonido) FORJA.Audio.efecto(d.sonido); else FORJA.Audio.sintetico('recoger', { volumen: 0.6, tono: 1.2 });
      return `Has usado: ${d.nombre}`;
    }
    if (d.tipo === 'mochila') {
      if (inv.estilo !== 'casillas') return 'Ya no hay límite de espacio';
      const antes = inv.n;
      inv.ampliar(d.casillas || 2);
      if (inv.n === antes) return 'Ya tienes todas las casillas';
      inv.quitar(i, 1);
      return `+${inv.n - antes} casillas`;
    }
    if (d.tipo === 'nota') return d.texto || d.descripcion || '(en blanco)';
    return 'Aquí no sirve';
  },

  tirarObjeto(j, i) {
    const inv = j.inventario, it = inv.items[i], d = inv.def(it);
    if (!it || !d) return '';
    const n = it.k === 'arma' ? 1 : it.n;
    inv.quitar(i);
    // al suelo, delante de ti (se puede volver a recoger)
    const R = j.juego.recogibles, P = j.cuerpo.pie;
    if (R) {
      const pos = new THREE.Vector3(P.x - Math.sin(j.yaw) * 1.1, P.y, P.z - Math.cos(j.yaw) * 1.1);
      const pr = it.k === 'obj' ? { nombre: d.nombre, tipo: 'objeto', objeto: it.id, cantidad: n }
        : it.k === 'arma' ? { nombre: d.nombre, tipo: 'arma', arma: it.id, cantidad: 0 }
          : { nombre: d.nombre, tipo: 'municion', municionTipo: it.id, cantidad: n };
      R.soltar({ ...pr, soloSiFalta: false, recoger: 'usar' }, pos);
    }
    if (it.k === 'arma' && j.armaEquipada === it.id) j.armaEquipada = null;
    this.sincronizar(j);
    return `Has tirado: ${d.nombre}`;
  },

  combinar(j, a, b) {
    const inv = j.inventario, A = inv.items[a], B = inv.items[b];
    if (!A || !B) return '';
    // munición + arma = recargar con la munición de la mochila
    const arma = A.k === 'arma' ? A : B.k === 'arma' ? B : null, mun = A.k === 'mun' ? A : B.k === 'mun' ? B : null;
    if (arma && mun) {
      const def = (j.juego.proyecto.armas || []).find((x) => x.id === arma.id);
      if (!def || def.municion !== mun.id) return 'Esta munición no le va';
      const ja = (j.armas || []).find((x) => x.def.id === def.id);
      if (!ja || !(def.cargador > 0)) return 'No se recarga';
      const falta = def.cargador - ja.cargador;
      if (falta <= 0) return 'Ya está cargada';
      ja.cargador += inv.gastar('mun', mun.id, falta);
      j.municion[mun.id] = inv.contar('mun', mun.id);
      if (def.sonidoRecarga) FORJA.Audio.efecto(def.sonidoRecarga); else FORJA.Audio.sintetico('recarga');
      return `${def.nombre} recargada: ${ja.cargador}/${def.cargador}`;
    }
    // misma munición en dos casillas: juntarlas
    if (A.k === 'mun' && B.k === 'mun' && A.id === B.id) {
      const pila = (inv.def(A) || {}).pila || 99, pasa = Math.min(A.n, pila - B.n);
      if (pasa <= 0) return 'Ya está llena';
      B.n += pasa; inv.quitar(a, pasa);
      return 'Juntadas';
    }
    // receta del proyecto (Juego ▸ Objetos)
    const r = inv.receta(A, B);
    if (!r) return 'No se pueden combinar';
    const res = (j.juego.proyecto.objetos || []).find((o) => o.id === r.da);
    if (!res) return 'La receta da un objeto que ya no existe';
    // quitar primero la de índice mayor (en la lista los índices se corren)
    for (const i of [a, b].sort((x, y) => y - x)) inv.quitar(i, 1);
    const resto = inv.agregar('obj', r.da, r.n || 1);
    if (resto) { inv.agregar('obj', A.id, 1); inv.agregar('obj', B.id, 1); return 'No tienes sitio para el resultado'; }
    FORJA.Audio.sintetico('recoger', { volumen: 0.6, tono: 0.9 });
    return `Has hecho: ${res.nombre}`;
  },

  detener(j, p, s) {
    if (s.ui) { if (s.ui.abierto) s.ui.cerrar(); s.ui.quitar(); }
    j.inventarioUI = null;
  },
});
