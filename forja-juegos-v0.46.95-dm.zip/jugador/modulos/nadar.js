/* Módulo NADAR — moverse dentro de las 💧 entidades de agua.
   Del framework de Godot (water_movement_module.gd) se tomó QUÉ hace: física de agua tipo Quake (velocidad,
   aceleración, rozamiento, hundirse despacio), salto para salir cerca de la superficie y tinte bajo el agua.
   Aquí, además, el creador elige el ESTILO:
     · 'libre'      (Quake / Half-Life): nadas hacia donde miras; Saltar sube, Agacharse baja.
     · 'superficie' (Mario 64 / Zelda): flotas con la cabeza fuera; mantén Agacharse para bucear (hacia donde miras).
   En los dos, Saltar en la superficie te saca del agua de un impulso (subir a la orilla).
   Aire opcional: bajo el agua se gasta; al acabarse pierdes vida poco a poco. El tinte, la niebla y el sonido
   apagado los pone motor/agua.js según la CÁMARA (también sirven sin este módulo).
   Mientras nada (j.nadando) Movimiento, Salto, Gravedad, Agacharse y Pasos se apartan; Salud no cuenta la caída. */
FORJA.registrarModulo({
  nombre: 'nadar',
  etiqueta: 'Nadar',
  descripcion: 'Nadar en el agua (💧): estilo libre como Quake o flotando en la superficie como Mario. Aire opcional.',
  orden: 14,                  // antes de Movimiento (20): si nadas, él decide la velocidad
  activoPorDefecto: true,
  props: [
    { k: 'estilo', t: 'sel', e: 'Estilo', def: 'libre', op: [['libre', 'Libre: nadas hacia donde miras (Quake)'], ['superficie', 'Flotar en la superficie y bucear (Mario / Zelda)']],
      ayuda: 'Libre: Saltar sube, Agacharse baja. Superficie: flotas con la cabeza fuera; mantén Agacharse para bucear' },
    { k: 'velocidad', t: 'num', e: 'Velocidad (m/s)', def: 3.5, paso: 0.1, min: 0.5 },
    { k: 'multCorrer', t: 'rango', e: 'Más rápido al correr', def: 1.4, min: 1, max: 2, paso: 0.05 },
    { k: 'aceleracion', t: 'num', e: 'Aceleración', def: 6, paso: 0.5, min: 0.5, av: true, ayuda: 'Bajo = más inercia, como en el agua de verdad' },
    { k: 'hundirse', t: 'num', e: 'Se hunde sin nadar (m/s)', def: 0.4, paso: 0.05, min: 0, av: true, si: (v) => v.estilo === 'libre' },
    { k: 'salir', t: 'num', e: 'Impulso para salir', def: 6.5, paso: 0.25, min: 0, ayuda: 'Saltar cerca de la superficie: lo que sube para llegar a la orilla' },
    { grupo: 'Aire' },
    { k: 'aire', t: 'bool', e: 'Se acaba el aire', def: true, ayuda: 'Bajo el agua sale una barra de aire: tienes unos segundos antes de ahogarte (la lava quema al instante, sin barra)' },
    { k: 'segundosAire', t: 'num', e: 'Aire (s)', def: 15, paso: 1, min: 1, si: (v) => v.aire },
    { k: 'danoAhogo', t: 'num', e: 'Daño al ahogarse (por s)', def: 10, paso: 1, min: 0, si: (v) => v.aire },
    { k: 'colorAire', t: 'color', e: 'Color de la barra', def: '#7fd4ff', si: (v) => v.aire, av: true },
    { grupo: 'Sonido' },
    { k: 'chapuzon', t: 'asset', e: 'Chapuzón al entrar', def: '', tipoAsset: 'audio', vacio: '(del motor)' },
  ],

  iniciar(j, p, s) {
    s.dentro = false;
    s.buceando = false;
    s.aire = p.segundosAire;
    s.tAhogo = 0;
    s.barra = null;
    s.vista = -1;
    j.nadando = false;
    j.bajoAgua = false;
  },

  entrada(j, p, s) {
    const agua = j.juego.agua, c = j.cuerpo;
    if (!agua || !agua.lista.length) { j.nadando = false; return; }
    // nada si el pecho está en el agua; la cabeza decide el aire
    const pechoY = c.pie.y + c.altura * 0.55;
    const vol = agua.en(c.pie.x, pechoY, c.pie.z);
    const antes = s.dentro;
    s.vol = vol;
    s.dentro = !!vol && vol.c.nadable !== false && !j.muerto;   // la lava no se nada (quema y caminas por el fondo)
    j.nadando = s.dentro;
    j.bajoAgua = s.dentro && agua.en(c.pie.x, c.pie.y + (j.alturaOjos || 1.6), c.pie.z) === vol;
    if (s.dentro && !antes) {
      // chapuzón (más fuerte cuanto más rápido caes)
      const fuerza = Math.min(1, Math.abs(c.velocidad.y) / 10);
      if (p.chapuzon) FORJA.Audio.efecto(p.chapuzon, { volumen: 0.4 + fuerza * 0.6 });
      else FORJA.Audio.sintetico('aterrizar', { volumen: 0.4 + fuerza * 0.6, tono: 0.55 });
      c.velocidad.y *= 0.3;   // el agua frena la caída
      FORJA.emitir('jugador-agua', { jugador: j, dentro: true });
    } else if (!s.dentro && antes) {
      FORJA.emitir('jugador-agua', { jugador: j, dentro: false });
    }
    if (s.dentro) { j.agachado = false; j.saltando = false; }
  },

  fisica(j, p, s, dt) {
    const E = FORJA.Entrada, c = j.cuerpo, v = c.velocidad;
    if (!s.dentro) { s.buceando = false; return; }
    const top = s.vol.top, pechoY = c.pie.y + c.altura * 0.55;
    const enSuperficie = top - pechoY < 0.45;
    const mx = j.sinControl ? 0 : E.mover.x, my = j.sinControl ? 0 : E.mover.y;
    const sube = !j.sinControl && E.mantenido('saltar'), baja = !j.sinControl && E.mantenido('agachar');
    const vel = p.velocidad * (j.corriendo ? p.multCorrer : 1);
    // salir del agua: Saltar con el pecho cerca de la superficie (para subir a la orilla)
    if (!j.sinControl && E.pulsado('saltar') && enSuperficie) {
      v.y = p.salir;
      FORJA.emitir('jugador-salto');
      return;
    }
    const sy = Math.sin(j.yaw), cy = Math.cos(j.yaw);
    const cp = Math.cos(j.pitch || 0), sp = Math.sin(j.pitch || 0);
    let wx, wy, wz;
    s.buceando = p.estilo === 'superficie' && baja;
    if (p.estilo === 'libre' || s.buceando) {
      // hacia donde miras (con la inclinación de la vista); de lado sin subir ni bajar
      wx = -sy * cp * my + cy * mx;
      wy = sp * my;
      wz = -cy * cp * my - sy * mx;
      if (p.estilo === 'libre') { if (sube) wy += 1; if (baja) wy -= 1; }
      else wy -= 0.6;   // buceando: hacia abajo aunque no mires abajo
    } else {
      // superficie: como caminar, y la cabeza fuera del agua (muelle hacia la altura de flotar)
      wx = cy * mx - sy * my;
      wz = -sy * mx - cy * my;
      wy = 0;
    }
    const largo = Math.hypot(wx, wy, wz);
    if (largo > 1) { wx /= largo; wy /= largo; wz /= largo; }
    const k = Math.min(1, p.aceleracion * dt);
    v.x += (wx * vel - v.x) * k;
    v.z += (wz * vel - v.z) * k;
    if (p.estilo === 'superficie' && !s.buceando) {
      const meta = top - c.altura * 0.62;            // pecho justo bajo la superficie: la cabeza queda fuera
      const vyMeta = Math.max(-2, Math.min(2.5, (meta - c.pie.y) * 4));
      v.y += (vyMeta - v.y) * Math.min(1, dt * 6);
    } else {
      const vyMeta = largo > 0.05 || sube || baja ? wy * vel : -p.hundirse;
      v.y += (vyMeta - v.y) * k;
      // no salir volando por la superficie: la cabeza puede asomar, el cuerpo no
      if (v.y > 0 && pechoY > top - 0.05) v.y = Math.min(v.y, (top - pechoY) * 4);
    }
  },

  despues(j, p, s, dt) {
    // aire bajo el agua (si el creador lo quiere)
    if (!p.aire) return;
    if (j.bajoAgua && !j.muerto) {
      s.aire = Math.max(0, s.aire - dt);
      if (s.aire <= 0 && j.danar) {
        s.tAhogo += dt;
        if (s.tAhogo >= 1) { s.tAhogo = 0; j.danar(p.danoAhogo, 'ahogo'); }
      }
    } else {
      s.aire = Math.min(p.segundosAire, s.aire + dt * p.segundosAire / 2);   // se recupera en 2 s
      s.tAhogo = 0;
    }
    this._barra(j, p, s);
  },

  // barra de aire del HUD: solo se ve si falta aire; solo se toca el HTML si cambia
  _barra(j, p, s) {
    const k = s.aire / p.segundosAire, ver = k < 0.999;
    const pct = Math.round(k * 50) * 2;
    if (pct === s.vista && ver === s.verBarra) return;
    s.vista = pct;
    s.verBarra = ver;
    if (!s.barra) {
      s.barra = FORJA.Hud.pieza(j.juego, 'fh-aire', '<span>AIRE</span><div class="fh-aire-caja"><div class="fh-aire-lleno"></div></div>');
      s.barra.style.setProperty('--fh-color', p.colorAire || '#7fd4ff');
    }
    s.barra.classList.toggle('fh-ver', ver);
    s.barra.classList.toggle('fh-bajo', k < 0.25);
    s.barra.lastChild.firstChild.style.width = pct + '%';
  },

  detener(j, p, s) {
    j.nadando = false;
    j.bajoAgua = false;
    if (s.barra) s.barra.classList.remove('fh-ver');
  },
});
