/* Módulo MOVIMIENTO — caminar relativo a la cámara, más lento hacia atrás.
   Equivale a tu movement_module.gd (con backward_speed_multiplier). */
FORJA.registrarModulo({
  nombre: 'movimiento',
  etiqueta: 'Movimiento',
  descripcion: 'Caminar con WASD o stick. Aceleración alta = respuesta seca estilo Doom; baja = más inercia estilo Mario.',
  orden: 20,
  props: [
    { k: 'velocidad', t: 'num', e: 'Velocidad', def: 4.5, paso: 0.1, ayuda: 'm/s' },
    { k: 'multAtras', t: 'rango', e: 'Mult. hacia atrás', def: 0.6, min: 0.2, max: 1, paso: 0.05 },
    { k: 'aceleracion', t: 'num', e: 'Aceleración', def: 50, paso: 1, ayuda: 'm/s² en el suelo' },
    { k: 'controlAire', t: 'rango', e: 'Control en aire', def: 0.3, min: 0, max: 1, paso: 0.05 },
    { k: 'noDeslizar', t: 'bool', e: 'No deslizar en paredes', def: false,
      ayuda: 'Al caminar de frente contra una pared u objeto (fijo o móvil) el jugador se queda quieto en vez de resbalar de lado (RE, Zelda). En diagonal (W+D) o rozando sí resbala' },
    { k: 'anguloNoDeslizar', t: 'num', e: 'Ángulo límite (°)', def: 30, paso: 5, min: 5, si: (v) => v.noDeslizar,
      ayuda: 'Si vas contra la pared con menos de este ángulo (casi de frente) no resbalas; con más, sí. Sirve para el stick' },
  ],

  fisica(j, p, s, dt) {
    if (j.nadando || j.trepando) return;   // en el agua manda el módulo Nadar; en una escalera de mano, Trepar
    const E = FORJA.Entrada, c = j.cuerpo;
    const mx = E.mover.x, my = E.mover.y;
    const sin = Math.sin(j.yaw), cos = Math.cos(j.yaw);
    // adelante = (-sin, -cos) · derecha = (cos, -sin)
    j.direccion.set(mx * cos - my * sin, 0, -mx * sin - my * cos);

    let vmax = p.velocidad * j.modVelocidad * (j.lentoEstado || 1);
    if (my < 0) vmax *= 1 + (p.multAtras - 1) * Math.min(1, -my);
    if (j.frenoGolpe > 0) vmax *= 0.15;   // golpe de cuerpo entero en 3ª persona (modelo.js): casi quieto mientras pega
    const wx = j.direccion.x * vmax, wz = j.direccion.z * vmax;

    const acc = (c.enSuelo ? p.aceleracion : p.aceleracion * p.controlAire) * dt;
    let dx = wx - c.velocidad.x, dz = wz - c.velocidad.z;
    const dl = Math.hypot(dx, dz);
    if (dl > acc) { dx *= acc / dl; dz *= acc / dl; }
    c.velocidad.x += dx;
    c.velocidad.z += dz;
    // 🧱 no resbalar: si delante hay una pared casi de frente, sin avance lateral
    // con teclado en diagonal (W+D…) siempre resbala
    const diagTeclado = Math.abs(mx) > 0.1 && Math.abs(my) > 0.1 && Math.abs(Math.abs(mx) - Math.abs(my)) < 0.02;
    if (p.noDeslizar && c.enSuelo && (mx || my) && !diagTeclado) {
      const M = j.mundo || c.mundo, dl2 = Math.hypot(j.direccion.x, j.direccion.z);
      if (M && dl2 > 0.2) {
        const ux = j.direccion.x / dl2, uz = j.direccion.z / dl2, r = c.radio || 0.35, P = c.pie;
        for (const h of [0.35, 0.9]) {
          const g = M.rayo(P.x, P.y + h, P.z, ux, 0, uz, r + 0.12);
          if (!g) continue;
          const nx = M.nor[g.k * 3], nz = M.nor[g.k * 3 + 2], nl = Math.hypot(nx, nz) || 1;
          if (-(ux * nx + uz * nz) / nl > Math.cos((p.anguloNoDeslizar ?? 30) * Math.PI / 180)) { c.velocidad.x = 0; c.velocidad.z = 0; break; }
        }
      }
    }
  },
});
