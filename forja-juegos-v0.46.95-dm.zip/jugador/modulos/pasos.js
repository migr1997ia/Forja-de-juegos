/* Módulo PASOS — sonido al caminar, al correr y al aterrizar. Nada en el aire.
   Ritmo FIJO: un valor para caminar y otro para correr (no depende de la velocidad del jugador),
   así un jugador muy rápido no suena como ametralladora. Cuesta un temporizador por cuadro.
   Sin archivo de sonido usa un "paso" que hace el motor (ruido corto y grave, estilo PS1). */
FORJA.registrarModulo({
  nombre: 'pasos',
  etiqueta: 'Pasos',
  descripcion: 'Sonido de pasos al caminar y al correr (cada uno con su ritmo y sonido), y golpe al aterrizar.',
  orden: 70,
  activoPorDefecto: false,
  props: [
    { k: 'volumen', t: 'rango', e: 'Volumen', def: 0.6, min: 0, max: 1, paso: 0.05 },
    { k: 'variar', t: 'rango', e: 'Variar tono', def: 0.12, min: 0, max: 0.5, paso: 0.01, ayuda: 'Para que no suenen todos iguales' },
    { k: 'aterrizar', t: 'asset', e: 'Aterrizar', def: '', tipoAsset: 'audio', vacio: '(golpe del motor)' },
    { k: 'agachadoSilencio', t: 'bool', e: 'Agachado casi no suena', def: true },

    { grupo: 'Caminar' },
    { k: 'sonido1', t: 'asset', e: 'Paso 1', def: '', tipoAsset: 'audio', vacio: '(paso del motor)' },
    { k: 'sonido2', t: 'asset', e: 'Paso 2', def: '', tipoAsset: 'audio', vacio: '(igual que el 1)', ayuda: 'Se alternan izquierdo / derecho' },
    { k: 'ritmoCaminar', t: 'num', e: 'Pasos por segundo', def: 2, paso: 0.1, min: 0.2, ayuda: 'Fijo. Con 2 va al compás del balanceo del arma de serie' },

    { grupo: 'Correr' },
    { k: 'correr1', t: 'asset', e: 'Paso 1', def: '', tipoAsset: 'audio', vacio: '(los de caminar)' },
    { k: 'correr2', t: 'asset', e: 'Paso 2', def: '', tipoAsset: 'audio', vacio: '(igual que el 1)' },
    { k: 'ritmoCorrer', t: 'num', e: 'Pasos por segundo', def: 3, paso: 0.1, min: 0.2, ayuda: 'Mientras corre (módulo Correr)' },
    { k: 'volCorrer', t: 'rango', e: 'Volumen extra', def: 1.2, min: 0.5, max: 2, paso: 0.05, ayuda: 'Correr suena más fuerte' },
  ],

  iniciar(j, p, s) {
    s.reloj = 0;          // segundos hasta el próximo paso
    s.lado = 0;
    s.enSuelo = true;
    s.tAire = 0;
  },

  _sonar(p, id, tipo, vol) {
    const tono = 1 + (Math.random() * 2 - 1) * p.variar;
    if (id) FORJA.Audio.efecto(id, { volumen: vol, tono });
    else FORJA.Audio.sintetico(tipo, { volumen: vol, tono });
  },

  despues(j, p, s, dt) {
    if (j.nadando) { s.enSuelo = j.cuerpo.enSuelo; s.tAire = 0; return; }   // nadando no hay pasos
    const c = j.cuerpo;
    const vol = p.volumen * (j.agachado && p.agachadoSilencio ? 0.25 : 1);
    if (c.enSuelo && !s.enSuelo && s.tAire > 0.25) this._sonar(p, p.aterrizar, 'aterrizar', vol);
    s.tAire = c.enSuelo ? 0 : s.tAire + dt;
    s.enSuelo = c.enSuelo;
    if (!c.enSuelo || j.muerto) return;

    const moviendo = c.velocidad.x * c.velocidad.x + c.velocidad.z * c.velocidad.z > 0.36;   // > 0.6 m/s
    if (!moviendo) { s.reloj = Math.min(s.reloj, 0.12); return; }   // al arrancar, el primer paso suena enseguida
    const corre = j.corriendo;
    s.reloj -= dt;
    if (s.reloj > 0) return;
    s.reloj += 1 / Math.max(0.2, corre ? p.ritmoCorrer ?? 3 : p.ritmoCaminar ?? 2);
    if (s.reloj < 0) s.reloj = 0;
    s.lado = 1 - s.lado;
    let id;
    if (corre && p.correr1) id = s.lado && p.correr2 ? p.correr2 : p.correr1;
    else id = s.lado && p.sonido2 ? p.sonido2 : p.sonido1;
    this._sonar(p, id, 'paso', corre ? vol * (p.volCorrer ?? 1.2) : vol);
  },
});
