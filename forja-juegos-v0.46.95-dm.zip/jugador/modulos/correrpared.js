/* Módulo CORRER POR LAS PAREDES (wall run, como en el FW): en el aire, corriendo hacia delante con una pared al lado,
   te pegas a ella y avanzas cayendo despacio (un rato). Saltar te despega de la pared hacia el otro lado y arriba.
   La cámara se ladea hacia fuera de la pared. Rayos solo mientras estás en el aire. j.enPared = −1 (izquierda) / 1 */
FORJA.registrarModulo({
  nombre: 'correrpared',
  etiqueta: 'Correr por las paredes',
  descripcion: 'En el aire y avanzando junto a una pared: corres por ella; Saltar te impulsa hacia fuera.',
  orden: 28,                 // antes de Salto (30): el salto desde la pared manda ese cuadro
  activoPorDefecto: false,
  props: [
    { k: 'velocidad', t: 'num', e: 'Velocidad por la pared (m/s)', def: 7, paso: 0.5, min: 1 },
    { k: 'caida', t: 'num', e: 'Caída en la pared (m/s)', def: 1.2, paso: 0.1, min: 0, ayuda: '0 = no cae nada mientras dure' },
    { k: 'duracion', t: 'num', e: 'Dura como mucho (s)', def: 1.4, paso: 0.1, min: 0.2 },
    { k: 'impulso', t: 'num', e: 'Impulso al saltar de la pared', def: 7, paso: 0.5, min: 1 },
    { k: 'distancia', t: 'num', e: 'Distancia a la pared (m)', def: 0.75, paso: 0.05, min: 0.3 },
    { k: 'ladeo', t: 'num', e: 'Ladeo de la cámara (°)', def: 12, paso: 1, min: 0, max: 30 },
  ],

  iniciar(j, p, s) { s.lado = 0; s.t = 0; s.k = 0; s.n = new THREE.Vector3(); s.dir = new THREE.Vector3(); s.espera = 0; },

  entrada(j, p, s) { s.salto = s.lado !== 0 && FORJA.Entrada.pulsado('saltar'); },

  fisica(j, p, s, dt) {
    const c = j.cuerpo, M = j.mundo, E = FORJA.Entrada;
    if (s.espera > 0) s.espera -= dt;
    const quiere = !c.enSuelo && !j.nadando && !j.trepando && !j.muerto && E.mover.y > 0.3 && s.espera <= 0;
    if (!quiere) { if (s.lado) this._soltar(j, s); return; }
    // ¿pared a un lado? (izquierda / derecha de hacia donde miras)
    const fx = -Math.sin(j.yaw), fz = -Math.cos(j.yaw), rx = -fz, rz = fx;   // delante y derecha
    const y = c.pie.y + c.altura * 0.5;
    let lado = 0, g = null;
    for (const sg of s.lado ? [s.lado] : [1, -1]) {
      g = M.rayo(c.pie.x, y, c.pie.z, rx * sg, 0, rz * sg, p.distancia);
      if (g) { lado = sg; break; }
    }
    if (!lado || !g) { if (s.lado) this._soltar(j, s); return; }
    // normal de la pared (horizontal): que sea pared de verdad
    const k3 = g.k * 3, N = M.nor;
    let nx = N ? N[k3] : -rx * lado, ny = N ? N[k3 + 1] : 0, nz = N ? N[k3 + 2] : -rz * lado;
    if (Math.abs(ny) > 0.35) { if (s.lado) this._soltar(j, s); return; }
    if (nx * rx * lado + nz * rz * lado > 0) { nx = -nx; nz = -nz; }   // que mire hacia el jugador
    if (!s.lado) { s.t = 0; FORJA.emitir('pared-empieza', j); }
    s.lado = lado; j.enPared = lado;
    s.t += dt;
    if (s.t > p.duracion) { this._soltar(j, s); s.espera = 0.4; return; }
    // a lo largo de la pared, hacia delante
    const L = Math.hypot(nx, nz) || 1;
    s.n.set(nx / L, 0, nz / L);
    s.dir.set(fx, 0, fz).addScaledVector(s.n, -(fx * s.n.x + fz * s.n.z)).normalize();
    if (s.salto) {
      // salto de pared: fuera, arriba y algo hacia delante
      c.velocidad.set(s.n.x * p.impulso + s.dir.x * p.velocidad * 0.6, p.impulso * 0.85, s.n.z * p.impulso + s.dir.z * p.velocidad * 0.6);
      j.saltoDePared = true;
      this._soltar(j, s); s.espera = 0.25;
      FORJA.emitir('jugador-salto', { pared: true });
      return;
    }
    c.velocidad.x = s.dir.x * p.velocidad - s.n.x * 0.5;   // un poco hacia la pared: que no se despegue
    c.velocidad.z = s.dir.z * p.velocidad - s.n.z * 0.5;
    c.velocidad.y = Math.max(c.velocidad.y * 0.8, -p.caida);
    if (s.t < 0.15) c.velocidad.y = Math.max(c.velocidad.y, 0.5);
  },

  _soltar(j, s) { s.lado = 0; j.enPared = 0; },

  despues(j, p, s, dt) {
    const meta = s.lado ? -s.lado : 0;
    s.k += (meta - s.k) * Math.min(1, dt * 8);
    if (Math.abs(s.k) > 0.002 && j.modoCamara === 'fps') j.camara.rotation.z += s.k * p.ladeo * FORJA.DEG;
  },
  detener(j, p, s) { this._soltar(j, s); },
});
