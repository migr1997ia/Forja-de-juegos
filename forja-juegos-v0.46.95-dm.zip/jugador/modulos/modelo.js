/* Módulo MODELO — el personaje visible y sus animaciones.
   Con un GLB de la Forja de Personajes conecta solas, si el modelo las trae:
     idle · walk · run · jump · crouch · walk_c (agachado caminando) · death · dash (esquiva)
     con arma de fuego: idle_p · walk_p · run_p · crouch_p · recoil (al disparar) · reload (al recargar)
     cuerpo a cuerpo: slash1 → slash2 → slash3 (combo), stab, attack_melee_c (agachado) · hit (al recibir daño)
   Las de una vez (disparo, recarga, daño) se mezclan encima de caminar; los golpes cuerpo a cuerpo mandan.
   Equivale a tu Playeranimationsync.gd. */
FORJA.registrarModulo({
  nombre: 'modelo',
  etiqueta: 'Modelo y animación',
  descripcion: 'Personaje que se ve en tercera persona. Sin modelo usa una cápsula.',
  orden: 60,
  props: [
    { k: 'modelo', t: 'asset', e: 'Modelo', def: '', tipoAsset: 'modelo' },
    { k: 'escala', t: 'num', e: 'Escala', def: 1, paso: 0.05 },
    { k: 'girar180', t: 'bool', e: 'Girar 180°', def: false, ayuda: 'Si el modelo camina de espaldas' },
    { k: 'visibleEnFps', t: 'bool', e: 'Visible en 1ª persona', def: false },
    { k: 'fundido', t: 'num', e: 'Fundido anim. (s)', def: 0.15, paso: 0.01 },
    { k: 'verEnEditor', t: 'bool', e: '🧍 Verlo en el editor (en el inicio)', def: true, ayuda: 'El personaje se ve quieto en el punto de inicio del nivel, para comparar tamaños y colocar cosas a su medida' },
    { grupo: 'Sin modelo: figura del motor', si: (v) => !v.modelo },
    { k: 'colorRopa', t: 'color', e: 'Cuerpo', def: '#e8b923', ayuda: 'Muñeco de pruebas: se nota que es provisional hasta que pongas tu modelo' },
    { k: 'colorPantalon', t: 'color', e: 'Piernas', def: '#d4a51c' },
    { k: 'colorPiel', t: 'color', e: 'Cabeza y manos', def: '#e8b923' },
    { k: 'colorJuntas', t: 'color', e: 'Articulaciones y marcas', def: '#1e1e1e' },
  ],

  /* Figura retro del motor (sin GLB): un MUÑECO DE PRUEBAS DE CHOQUE (amarillo, juntas negras y las marcas
     de cuartos negro/amarillo) para que se vea que es provisional. Cajas con articulaciones (hombro, codo, cadera,
     rodilla) que el motor anima: caminar, correr, saltar, agacharse, apuntar, disparar, golpear, dolor.
     Mira hacia +Z como los GLB. */
  _figura(j, p) {
    const T = THREE, H = j.cuerpo.altura || 1.8, R = FORJA.Render.hacerRetro;
    const mat = (c) => R(new T.MeshLambertMaterial({ color: c, flatShading: true }));
    const cRopa = p.colorRopa || '#e8b923', cPant = p.colorPantalon || '#d4a51c', cPiel = p.colorPiel || '#e8b923', cJunta = p.colorJuntas || '#1e1e1e';
    const ropa = mat(cRopa), pant = mat(cPant), piel = mat(cPiel), junta = mat(cJunta);
    // marca de prueba de choque: círculo partido en cuartos (16×16 px, sin suavizar)
    const marca = (fondo) => {
      const c = document.createElement('canvas');
      c.width = c.height = 16;
      const g = c.getContext('2d');
      g.fillStyle = fondo; g.fillRect(0, 0, 16, 16);
      for (let q = 0; q < 4; q++) {
        g.fillStyle = q % 2 ? fondo : cJunta;
        g.beginPath(); g.moveTo(8, 8); g.arc(8, 8, 6, (q * Math.PI) / 2, ((q + 1) * Math.PI) / 2); g.closePath(); g.fill();
      }
      g.strokeStyle = cJunta; g.lineWidth = 1; g.beginPath(); g.arc(8, 8, 6, 0, Math.PI * 2); g.stroke();
      const t = new T.CanvasTexture(c);
      t.magFilter = T.NearestFilter; t.minFilter = T.NearestFilter; t.colorSpace = T.SRGBColorSpace;
      return R(new T.MeshLambertMaterial({ map: t, flatShading: true }));
    };
    const marcaRopa = marca(cRopa), marcaPiel = marca(cPiel), marcaPant = marca(cPant);
    // materiales por cara de una caja: +X, −X, +Y, −Y, +Z (frente), −Z (espalda)
    const caja = (w, h, d, m, y = 0) => { const g = new T.BoxGeometry(w, Math.abs(h), d); g.translate(0, y, 0); return new T.Mesh(g, m); };
    const piv = (x, y, z) => { const o = new T.Group(); o.position.set(x, y, z); return o; };
    const raiz = new T.Group();
    const pierna = H * 0.47, muslo = pierna * 0.5, tronco = H * 0.3, brazo = H * 0.36, cab = H * 0.15;
    const cadera = piv(0, pierna, 0);                     // todo el cuerpo de arriba cuelga de aquí
    raiz.add(cadera);
    const torso = caja(H * 0.25, tronco, H * 0.13, [ropa, ropa, ropa, ropa, marcaRopa, marcaRopa], tronco / 2);
    cadera.add(torso);
    cadera.add(caja(H * 0.24, H * 0.03, H * 0.12, junta, 0));               // cinturón negro
    const cuello = caja(cab * 0.4, H * 0.03, cab * 0.4, junta, 0);
    cuello.position.y = tronco;
    cadera.add(cuello);
    // cabeza con marcas a los lados y ojos (sin pelo)
    const cabeza = caja(cab * 0.85, cab, cab * 0.9, [marcaPiel, marcaPiel, piel, piel, piel, piel], cab / 2);
    cabeza.position.y = tronco + 0.02;
    for (const x of [-1, 1]) {
      const ojo = caja(cab * 0.16, cab * 0.12, cab * 0.04, junta, cab * 0.58);
      ojo.position.set(x * cab * 0.19, 0, cab * 0.45);
      cabeza.add(ojo);
    }
    cadera.add(cabeza);
    const F = {};
    // mirando a +Z, la derecha del personaje es -X
    for (const [lado, x] of [['I', 1], ['D', -1]]) {
      // brazo: hombro → antebrazo (codo)
      const hombro = piv(x * H * 0.155, tronco * 0.92, 0);
      hombro.add(caja(H * 0.08, H * 0.05, H * 0.08, junta, 0));                // hombro negro
      hombro.add(caja(H * 0.07, -brazo * 0.5, H * 0.07, ropa, -brazo * 0.25));
      const codo = piv(0, -brazo * 0.5, 0);
      codo.add(caja(H * 0.065, H * 0.035, H * 0.065, junta, 0));               // codo negro
      codo.add(caja(H * 0.06, -brazo * 0.5, H * 0.06, piel, -brazo * 0.25));
      { const mano = piv(0, -brazo * 0.5, 0); mano.name = lado === 'D' ? 'hand_R' : 'hand_L'; codo.add(mano); }   // arma (der.) · antorcha (izq.)
      hombro.add(codo);
      cadera.add(hombro);
      // pierna: cadera → espinilla (rodilla)
      const muslo0 = piv(x * H * 0.065, pierna, 0);
      muslo0.add(caja(H * 0.095, -muslo, H * 0.1, [marcaPant, marcaPant, pant, pant, pant, pant], -muslo / 2));
      const rodilla = piv(0, -muslo, 0);
      rodilla.add(caja(H * 0.1, H * 0.04, H * 0.105, junta, 0));               // rodilla negra
      rodilla.add(caja(H * 0.085, -muslo, H * 0.09, pant, -muslo / 2));
      rodilla.add(caja(H * 0.09, H * 0.035, H * 0.13, junta, -muslo + H * 0.017));   // pie negro
      muslo0.add(rodilla);
      raiz.add(muslo0);
      F['hombro' + lado] = hombro; F['codo' + lado] = codo; F['muslo' + lado] = muslo0; F['rodilla' + lado] = rodilla;
    }
    Object.assign(F, { raiz, cadera, cabeza, pierna, brazo, tronco, H, fase: 0, retro: 0, golpe: 0, dolor: 0, flip: 0 });
    raiz.userData.figura = F;
    // agacharse y morir: la figura lo hace ella (no encoger ni tumbar desde fuera… morir sí lo tumba Salud)
    raiz.userData.animaciones = [{ name: 'crouch' }];
    return raiz;
  },

  _animarFigura(j, s, dt) {
    const F = s.obj.userData.figura, c = j.cuerpo;
    const vh = j.montado ? 0 : Math.max(Math.hypot(c.velocidad.x, c.velocidad.z), j.pasoForzado || 0);   // empujando / jalando: piernas como al caminar · montado: quieto
    const enAire = !c.enSuelo && c.tAire > 0.12 && !j.nadando;
    const corre = j.corriendo && vh > 3;
    const fuerza = Math.min(1, vh / 3.5) * (corre ? 1.35 : 1);
    F.fase += dt * (enAire ? 0 : vh * (corre ? 2.1 : j.agachado ? 4.2 : 2.6));   // agachado: pasos cortos y más seguidos
    const sn = Math.sin(F.fase), k = Math.min(1, dt * 14);
    const ir = (o, eje, meta) => { o.rotation[eje] += (meta - o.rotation[eje]) * k; };
    const ag = j.agachado ? 1 : 0;
    let mI = -sn * 0.7 * fuerza, mD = sn * 0.7 * fuerza;           // muslos
    let rI = Math.max(0, sn) * 0.9 * fuerza, rD = Math.max(0, -sn) * 0.9 * fuerza;   // rodillas (solo hacia atrás)
    let hI = sn * 0.6 * fuerza, hD = -sn * 0.6 * fuerza, cI = -0.25 * fuerza, cD = -0.25 * fuerza;   // hombros y codos
    let inclinar = corre ? 0.22 : 0.05 * fuerza, bajar = Math.abs(Math.cos(F.fase)) * 0.04 * fuerza;
    if (enAire) { mI = -0.9; rI = 1.3; mD = 0.15; rD = 0.5; hI = -2.3; hD = -2.6; cI = cD = -0.4; inclinar = 0.1; bajar = 0; }
    if (ag) {
      // agachado: quieto en cuclillas; caminando, pasos cortos alrededor de esa postura (walk_c)
      const fa = Math.min(1, vh / 1.5);
      mI = -1.25 - sn * 0.45 * fa; mD = -1.25 + sn * 0.45 * fa;
      rI = 2.0 - Math.max(0, -sn) * 0.5 * fa; rD = 2.0 - Math.max(0, sn) * 0.5 * fa;
      hI = sn * 0.35 * fa; hD = -sn * 0.35 * fa; cI = cD = -0.45;
      inclinar = 0.35 + 0.08 * fa; bajar = F.pierna * 0.42 + Math.abs(Math.cos(F.fase)) * 0.03 * fa;
    }
    // nadando: brazadas y patadas (el cuerpo entero se tumba en despues())
    if (j.nadando) {
      const nada = vh > 0.4 || Math.abs(c.velocidad.y) > 0.4;
      F.nado = (F.nado || 0) + dt * (nada ? 7 : 3);
      const b = Math.sin(F.nado);
      hI = -2.5 + b * (nada ? 0.9 : 0.4); hD = -2.5 - b * (nada ? 0.9 : 0.4); cI = cD = -0.25;
      mI = b * 0.45; mD = -b * 0.45; rI = rD = 0.35; inclinar = 0; bajar = 0;
    }
    // 🧗 colgado de un borde: brazos arriba agarrados, cuerpo colgando (y se balancea al moverse de lado)
    const subiendo = j.subiendoOrilla, colgado = j.colgado;
    if (colgado) {
      const lat = Math.hypot(c.velocidad.x, c.velocidad.z) > 0.7 ? 1 : 0;
      F.lado = (F.lado || 0) + dt * 9 * lat;
      const b = Math.sin(F.lado) * 0.25 * lat;
      hI = -2.95 + b; hD = -2.95 - b; cI = cD = -0.12;
      mI = -0.25 - b; mD = -0.25 + b; rI = rD = 0.45; inclinar = -0.05; bajar = 0;
    } else if (subiendo) {
      // subiendo el borde: empuja con los brazos y sube una rodilla
      hI = hD = -0.9; cI = cD = -1.2; mI = -1.5; rI = 1.9; mD = -0.35; rD = 0.7; inclinar = 0.45; bajar = 0;
    } else if (j.trepando) {
      // escalera de mano: brazo y pierna contrarios, al ritmo de lo que sube
      F.escala = (F.escala || 0) + dt * Math.abs(c.velocidad.y) * 3.2;
      const e = Math.sin(F.escala);
      hI = -2.5 + e * 0.45; hD = -2.5 - e * 0.45; cI = cD = -0.6;
      mI = -0.9 - e * 0.45; mD = -0.9 + e * 0.45; rI = 1.3 + e * 0.4; rD = 1.3 - e * 0.4; inclinar = 0; bajar = 0;
    }
    // 🤸 salto extra (doble salto): voltereta encogida (el giro del cuerpo entero se hace en despues())
    if (F.flip > 0) { mI = mD = -1.7; rI = rD = 2.3; hI = hD = -0.7; cI = cD = -1.6; inclinar = 0.3; bajar = 0; }
    // 🐎 montado: sentado, manos al frente (riendas / volante) que se van hacia donde gira; al saltar las levanta
    if (j.montado) {
      const MT = j.montado, g = MT.giroVis || 0;
      mI = mD = -1.45; rI = rD = 1.45; bajar = F.pierna * 0.5; inclinar = MT.p.tipo === 'montura' ? 0.15 : 0.05;
      hI = -1.0 + g * 0.35; hD = -1.0 - g * 0.35; cI = cD = -0.75;
      if (MT.saltando) { hI = hD = -2.7; cI = cD = -0.25; inclinar = -0.05; }
    }
    // con arma de fuego: brazos al frente apuntando (y retroceso al disparar)
    const arma = j.armas && j.armas[j.armaActual];
    const largo = arma && !enAire && !j.trepando && !(F.flip > 0) && !j.muerto && !(j.montado && !j.montado.p.disparar) && this._postura(arma.def);
    F.dosManos = largo === 'rifle' || largo === 'hombro';
    if (F.dosManos) {
      // 🎯 arma larga: las manos van AL ARMA (gatillo junto al pecho, la otra sujetando el cañón delante), con IK de dos
      // huesos. Al apuntar sube a la altura de los ojos; con la cámara en 3ª persona sigue lo que miras.
      const H = F.H, ap = Math.min(1, j.apuntando || 0), hombro = largo === 'hombro';
      const re = -F.retro * H * 0.035;
      const yG = H * (hombro ? 0.25 : 0.165 + 0.06 * ap), yS = H * (hombro ? 0.255 : 0.19 + 0.05 * ap);
      const tG = F._tG || (F._tG = new THREE.Vector3()), tS = F._tS || (F._tS = new THREE.Vector3());
      tG.set(-H * (hombro ? 0.1 : 0.07), yG, H * (hombro ? 0.08 : 0.13 + 0.03 * ap) + re);
      tS.set(H * (hombro ? -0.01 : 0.005), yS, H * (hombro ? 0.27 : 0.3 + 0.02 * ap) + re);
      const pitch = j.modoCamara === 'tps' ? Math.max(-0.9, Math.min(0.9, j.pitch * 0.8)) : 0;
      if (pitch) for (const t of [tG, tS]) {   // girar alrededor de los hombros
        const y0 = F.tronco * 0.92, y = t.y - y0, z = t.z, cs = Math.cos(-pitch), sn2 = Math.sin(-pitch);
        t.y = y0 + y * cs - z * sn2; t.z = y * sn2 + z * cs;
      }
      F._ik = [['D', tG], ['I', tS]];
    } else if (arma && arma.def.tipo !== 'cuerpo' && !enAire && !j.trepando && !(j.montado && !j.montado.p.disparar)) {
      F._ik = null;
      const pitch = j.modoCamara === 'tps' ? j.pitch * 0.8 : 0;
      hD = -1.45 - pitch + F.retro * 0.5; cD = -0.1; hI = -1.2 - pitch; cI = -0.5;
    } else F._ik = null;
    // ⚔ cuerpo a cuerpo según el estilo del arma: corta (estocada) · larga (tajo de arriba abajo) · dos manos (golpe
    // por encima de la cabeza con las dos manos en el mango) · lanza (empujón al frente). Con clic derecho: guardia.
    const est = arma && arma.def.tipo === 'cuerpo' && arma.def.id !== '__punos' ? FORJA.Escena.estiloCuerpo(arma.def) : (arma && arma.def.tipo === 'cuerpo' ? 'corta' : null);
    F.cruzado = false; F.agarreIzq = false;
    if (est && !enAire && !j.trepando && !(F.flip > 0) && !j.muerto) {
      const H = F.H;
      let g = F.golpe > 0 ? 1 - F.golpe / (F.golpeDur || 0.32) : -1;
      if (g >= 0 && F.varGolpe === 'reves') g = 1 - g;   // ⚔ lanzador: el tajo sube en vez de bajar
      if (g >= 0 && F.varGolpe === 'bajo') { inclinar += 0.45; bajar += H * 0.12; }   // ⚔ barrido: agachado
      const sw = g >= 0 ? Math.sin(Math.PI * g) : 0;
      if (est === 'dosManos' || est === 'lanza' || est === 'espadon') {
        const tG = F._tG || (F._tG = new THREE.Vector3()), tS = F._tS || (F._tS = new THREE.Vector3());
        F.dosManos = true;
        if (j.bloqueando && est === 'espadon') { tG.set(-H * 0.01, H * 0.33, H * 0.21); tS.set(0, H * 0.27, H * 0.2); F.agarreIzq = true; }   // ⚔ la hoja de pie delante
        else if (j.bloqueando) { tG.set(-H * 0.13, H * 0.33, H * 0.2); tS.set(H * 0.13, H * 0.34, H * 0.2); F.cruzado = true; }   // el mango cruzado delante
        else if (est === 'espadon') {
          /* ⚔ espada a dos manos: la izquierda abajo en el puño y la derecha justo encima (la hoja sale más allá de la
             derecha). En reposo apunta arriba y al frente (kendo); el golpe: alzarla por encima de la cabeza y bajar recto */
          F.agarreIzq = true;
          const P = {   // [derecha x,y,z, izquierda x,y,z] en altos del personaje
            reposo: [-0.01, 0.2, 0.235, 0.0, 0.16, 0.2],
            carga: [-0.01, 0.47, 0.02, 0.0, 0.42, 0.06],
            golpe: [-0.01, 0.15, 0.31, 0.0, 0.17, 0.26],
          };
          const suave = (t) => t * t * (3 - 2 * t), mez = (A, B, t) => A.map((v, i) => v + (B[i] - v) * t);
          let x = P.reposo;
          if (g >= 0) {
            if (g < 0.35) x = mez(P.reposo, P.carga, suave(g / 0.35));
            else if (g < 0.55) x = mez(P.carga, P.golpe, suave((g - 0.35) / 0.2));
            else x = mez(P.golpe, P.reposo, suave((g - 0.55) / 0.45));
            inclinar += g < 0.35 ? -0.08 * (g / 0.35) : g < 0.55 ? 0.3 * ((g - 0.35) / 0.2) : 0.3 * (1 - (g - 0.55) / 0.45);
          }
          tG.set(x[0] * H, x[1] * H, x[2] * H); tS.set(x[3] * H, x[4] * H, x[5] * H);
        } else if (est === 'dosManos') {
          /* Hacha / mazo de verdad: la mano IZQUIERDA en el extremo del mango y la DERECHA arriba, cerca de la cabeza
             (el arma va de la izquierda hacia la derecha y la cabeza queda más allá de la derecha). Golpe en arco:
             carga sobre el hombro derecho → por encima de la cabeza → abajo delante. Posiciones dentro del alcance. */
          F.agarreIzq = true;
          const P = {   // [derecha x,y,z, izquierda x,y,z] en altos del personaje
            reposo: [-0.07, 0.24, 0.2, 0.05, 0.1, 0.17],
            carga: [-0.1, 0.5, -0.02, -0.04, 0.42, 0.04],
            arriba: [-0.05, 0.48, 0.18, 0.0, 0.4, 0.16],
            golpe: [-0.02, 0.1, 0.28, 0.01, 0.2, 0.18],
          };
          const suave = (t) => t * t * (3 - 2 * t), mez = (A, B, t) => A.map((v, i) => v + (B[i] - v) * t);
          let x = P.reposo;
          if (g >= 0) {
            if (g < 0.4) x = mez(P.reposo, P.carga, suave(g / 0.4));                       // cargar (lento)
            else if (g < 0.55) x = mez(P.carga, P.arriba, suave((g - 0.4) / 0.15));         // arriba (rápido)
            else if (g < 0.7) x = mez(P.arriba, P.golpe, suave((g - 0.55) / 0.15));         // abajo (rápido)
            else x = mez(P.golpe, P.reposo, suave((g - 0.7) / 0.3));                        // volver
            inclinar += g < 0.4 ? -0.1 * (g / 0.4) : g < 0.7 ? 0.35 * ((g - 0.4) / 0.3) : 0.35 * (1 - (g - 0.7) / 0.3);
          }
          tG.set(x[0] * H, x[1] * H, x[2] * H); tS.set(x[3] * H, x[4] * H, x[5] * H);
        } else if (g < 0) {
          // lanza en reposo: mano derecha delante de la cadera (sin meterse en el torso) y la izquierda adelante, el asta al frente
          tG.set(-H * 0.05, H * 0.07, H * 0.14); tS.set(H * 0.02, H * 0.11, H * 0.27);
        } else {
          const em = 0.16 * sw;   // lanza: empujón al frente
          tG.set(-H * 0.06, H * (0.2 + 0.03 * sw), H * (0.05 + em)); tS.set(H * 0.0, H * (0.23 + 0.02 * sw), H * (0.3 + em));   // las dos manos delante, el asta recta al frente
          inclinar += 0.12 * sw;
        }
        F._ik = [['D', tG], ['I', tS]];
      } else {
        F.dosManos = false; F._ik = null;
        if (j.bloqueando) { hD = -1.5; cD = -1.75; }                                    // guardia: el arma de pie delante de la cara
        else if (g >= 0 && est === 'corta') { hD = -0.5 - 1.1 * sw; cD = -1.4 + 1.3 * sw; }   // estocada al frente
        else if (g >= 0) { hD = -2.6 + g * 3.0; cD = -0.3; inclinar += 0.15; }              // tajo de arriba abajo
        else if (vh < 0.3 || (j.apuntando || 0) > 0.3) { hD = est === 'larga' ? -0.55 : -0.45; cD = est === 'larga' ? -0.9 : -1.2; }   // en guardia baja
      }
    }
    // 🛡 escudo de mano: el brazo libre lo lleva doblado al costado (el escudo en el antebrazo, mirando hacia fuera);
    // cubriéndose, sube el antebrazo delante del pecho. Con armas a dos manos el escudo va a la espalda (no cambia nada)
    if (j.escudoMano && !j.escudoGuardado && !F.dosManos && !F._ik && !(F.flip > 0) && !j.montado && !j.muerto && !j.trepando) {
      if (j.cubriendo) { hI = -0.8; cI = -1.05; } else { hI = -0.3; cI = -1.3; }
    }
    // 📦 cargando un objeto movible: las dos manos al frente sujetándolo · ✋ agarrado: manos a la altura del objeto
    const EM = j.juego.empujables;
    if (EM && (EM.cargado || EM.agarre) && !j.muerto) {
      const H = F.H, tG = F._tG || (F._tG = new THREE.Vector3()), tS = F._tS || (F._tS = new THREE.Vector3());
      const emp = EM.agarre && EM.agarre.modo === 'empuje';
      const y = EM.cargado ? 0.27 : emp ? 0.22 : 0.17, z = EM.cargado ? 0.2 : 0.26;
      tG.set(-H * 0.13, H * y, H * z); tS.set(H * 0.13, H * y, H * z);
      F._ik = [['D', tG], ['I', tS]]; F.dosManos = false;
      if (EM.agarre && j.pasoForzado) inclinar += emp || j.pasoForzado > 0 && EM.agarre._hacia > 0 ? 0.28 : -0.12;   // empujar: echado hacia delante · jalar: hacia atrás
    }
    if (F.dolor > 0) inclinar -= 0.35 * (F.dolor / 0.25);
    F.retro = Math.max(0, F.retro - dt * 8);
    F.flip = Math.max(0, F.flip - dt);
    F.golpe = Math.max(0, F.golpe - dt);
    F.dolor = Math.max(0, F.dolor - dt);
    ir(F.musloI, 'x', mI); ir(F.musloD, 'x', mD); ir(F.rodillaI, 'x', rI); ir(F.rodillaD, 'x', rD);
    if (F._ik) {
      for (const [lado, t] of F._ik) this._ikBrazo(F, lado, t, k);
      if (F._ik.length === 1) { ir(F.hombroI, 'x', hI); ir(F.codoI, 'x', cI); for (const o of [F.hombroI, F.codoI]) { o.rotation.y -= o.rotation.y * k; o.rotation.z -= o.rotation.z * k; } }   // solo un brazo con IK
    } else for (const [o, meta] of [[F.hombroI, hI], [F.hombroD, hD], [F.codoI, cI], [F.codoD, cD]]) {
      ir(o, 'x', meta);
      o.rotation.y -= o.rotation.y * k; o.rotation.z -= o.rotation.z * k;   // al salir del IK vuelven a girar solo en X
    }
    ir(F.cadera, 'x', inclinar);
    F.cadera.position.y += (F.pierna - bajar - F.cadera.position.y) * k;
    for (const lado of ['I', 'D']) F['muslo' + lado].position.y = F.cadera.position.y;
  },

  /* IK de dos huesos para un brazo de la figura (hombro → codo → mano) hasta un punto en el espacio de la cadera.
     El codo apunta hacia abajo y afuera. Suave (k) para que no salte al entrar y salir. */
  _ikBrazo(F, lado, tgt, k) {
    const T = THREE, h = F['hombro' + lado], co = F['codo' + lado], L = F.brazo * 0.5;
    const v = F._v1 || (F._v1 = new T.Vector3()), pol = F._v2 || (F._v2 = new T.Vector3()), n = F._v3 || (F._v3 = new T.Vector3());
    const u = F._v4 || (F._v4 = new T.Vector3()), f = F._v5 || (F._v5 = new T.Vector3()), z = F._v6 || (F._v6 = new T.Vector3());
    v.copy(tgt).sub(h.position);
    const d = Math.min(v.length(), 2 * L * 0.995);
    v.normalize();
    pol.set(lado === 'I' ? 0.55 : -0.55, -1, -0.2).normalize();
    pol.addScaledVector(v, -v.dot(pol)).normalize();          // hacia dónde va el codo (perpendicular a la línea)
    const a = Math.acos(Math.min(1, d / (2 * L)));
    u.copy(v).multiplyScalar(Math.cos(a)).addScaledVector(pol, Math.sin(a));   // dirección del brazo
    f.copy(v).multiplyScalar(d).addScaledVector(u, -L).normalize();            // dirección del antebrazo
    n.crossVectors(u, pol).normalize();
    const y = pol.copy(u).negate();                            // el brazo cuelga hacia −Y del hombro
    z.crossVectors(n, y);
    const M = F._m || (F._m = new T.Matrix4()), qh = F._qh || (F._qh = new T.Quaternion()), qc = F._qc || (F._qc = new T.Quaternion());
    M.makeBasis(n, y, z);
    qh.setFromRotationMatrix(M);
    const qi = F._qi || (F._qi = new T.Quaternion());
    f.applyQuaternion(qi.copy(qh).invert());
    qc.setFromUnitVectors(F._abajo || (F._abajo = new T.Vector3(0, -1, 0)), f);
    h.quaternion.slerp(qh, k);
    co.quaternion.slerp(qc, k);
  },

  iniciar(j, p, s) {
    const T = THREE;
    const asset = FORJA.Assets.mapa.get(p.modelo);
    const sinClips = asset && asset.gltf && !(asset.gltf.animations || []).length;
    let humano = false;
    if (sinClips) asset.gltf.scene.traverse((o) => { if (o.isBone && /^upperarm_l$/i.test(o.name)) humano = true; });
    if (sinClips && humano) {
      // 🧍 modelo humanoide SIN animaciones (GLB o receta): lo mueve el muñeco del motor. El muñeco se anima igual que siempre
      // (mismas poses, golpes, IK y arma en su mano) pero invisible, y cada cuadro sus giros se copian a los huesos del modelo.
      s.obj = this._figura(j, p);
      s.obj.traverse((o) => { if (o.isMesh) o.visible = false; });
      const piel = T.SkeletonUtils.clone(asset.gltf.scene), B = {};
      piel.traverse((o) => { if (o.isBone) B[o.name.toLowerCase()] = o; if (o.isMesh) o.frustumCulled = false; });
      s.obj.add(piel);
      const F = s.obj.userData.figura, par = [['cadera', 'hips'], ['cabeza', 'head'], ['hombroI', 'upperarm_l'], ['codoI', 'forearm_l'], ['hombroD', 'upperarm_r'], ['codoD', 'forearm_r'], ['musloI', 'thigh_l'], ['rodillaI', 'shin_l'], ['musloD', 'thigh_r'], ['rodillaD', 'shin_r']];
      s.piel = { par: par.filter(([a, b]) => F[a] && B[b]).map(([a, b]) => [F[a], B[b], a]), hips: B.hips, hips0: B.hips && B.hips.position.clone(), cad0: F.cadera.position.clone(), F };
      s.mixer = null;
      s.acciones = null;
    } else if (asset && asset.gltf) {
      s.obj = T.SkeletonUtils.clone(asset.gltf.scene);
      s.mixer = new T.AnimationMixer(s.obj);
      // 🦴 las que le falten al modelo (apuntar, agarres, doble salto, colgarse…) las pone el editor: las del muñeco (motor/animbase.js)
      let clips = asset.gltf.animations || [];
      if (FORJA.AnimBase) {
        const ya = new Set(clips.map((c) => c.name.toLowerCase()));
        if (ya.has('walk_c')) ya.add('crouch_walk');
        if (ya.has('dash')) ya.add('dodge');
        const extra = FORJA.AnimBase.clips(s.obj, ya);
        if (extra.length) clips = clips.concat(extra);
      }
      s.acciones = FORJA.Escena.mapaAcciones(s.mixer, clips);
      // para que otros módulos sepan qué trae (agacharse, morir… usan su efecto solo si falta la animación)
      s.obj.userData.animaciones = clips;
      s.obj.userData.acciones = s.acciones;
      this._prepararApuntado(s, clips);
    } else {
      // sin modelo: la figura retro del motor, animada por código
      s.obj = this._figura(j, p);
      s.mixer = null;
      s.acciones = null;
    }
    s.obj.scale.setScalar(p.escala);
    s.obj.userData.escalaBase = p.escala;   // agacharse / morir la cambian sobre esta
    FORJA.Luces.aplicarSombras(s.obj, true);   // en tercera persona hace sombra real (si hay sombras del sol)
    s.giro = j.yaw + Math.PI + (p.girar180 ? Math.PI : 0);
    s.actual = null;
    s.capa = null;       // animación de una vez encima de la de moverse (disparo, recarga, daño)
    s.bloqueo = null;    // animación de una vez que manda (golpe cuerpo a cuerpo)
    s.combo = 0; s.tCombo = 0; s.tApuntar = 0;
    j.modelo = s.obj;
    j.escena.add(s.obj);
    // eventos del resto del jugador
    const F = FORJA;
    const fig = s.obj.userData.figura;
    s.oyentes = fig ? [
      F.on('disparo', (d) => {
        if (!d || d.jugador !== j) return;
        s.tApuntar = 0.6;
        if (d.arma && d.arma.tipo === 'cuerpo') {
          const G = d.golpe || {};
          fig.golpeDur = ({ corta: 0.25, larga: 0.32, dosManos: 0.7, espadon: 0.55, lanza: 0.35 }[FORJA.Escena.estiloCuerpo(d.arma) || 'corta'] || 0.32) * (G.dur || 1);
          fig.golpe = fig.golpeDur;
          fig.varGolpe = G.figura || null;   // ⚔ variante del combo: 'reves' (de abajo arriba) · 'bajo' (agachado)
          if (G.giro) s.vuelta = { t: 0, dur: fig.golpeDur };
        } else fig.retro = 1;
      }),
      F.on('jugador-dano', (jj) => { if (jj === j && !j.muerto) fig.dolor = 0.25; }),
      F.on('jugador-salto', (d) => { if (d && d.aire > 0) fig.flip = 0.5; }),
    ] : s.acciones ? [
      // 🤸 salto extra con modelo: double_jump / jump2 / flip si los trae (si no, sigue con 'jump')
      F.on('jugador-salto', (d) => {
        if (!d || !(d.aire > 0)) return;
        const n = ['double_jump', 'jump2', 'flip'].find((x) => s.acciones[x]);
        if (n) { s.acciones[n].setLoop(THREE.LoopOnce); s.acciones[n].clampWhenFinished = true; this._unaVez(s, n, true); }
      }),
      F.on('disparo', (d) => {
        if (!d || d.jugador !== j) return;
        s.tApuntar = 0.6;   // tras disparar, el modelo mira hacia donde apuntas un momento
        if (d.arma && d.arma.tipo === 'cuerpo') {
          const A = s.acciones;
          let n;
          // familia de golpe (la del arma o la primera que traiga el modelo) y su combo de hasta 3: slash1-3, stab/stab2/stab3…
          const fam = [d.arma.golpe3p, 'slash', 'stab', 'axe', 'spear', 'kick', 'attack'].find((f) => f && f !== 'auto' && (A[f] || A[f + '1']));
          const nombre = (f, k) => (f === 'slash' ? 'slash' + k : k === 1 ? f : f + k);
          const G = d.golpe;
          const pedido = G && G.anims && G.anims.find((x) => A[x]);   // ⚔ el movimiento del combo (si el modelo lo tiene)
          if (G && G.giro) s.vuelta = { t: 0, dur: (G.dur || 1) * 0.42 };
          if (pedido) n = pedido;
          else if (j.agachado && A.attack_melee_c) n = 'attack_melee_c';
          else if (fam) {
            s.combo = s.tCombo > 0 && s.famCombo === fam ? (s.combo % 3) + 1 : 1;
            if (!A[nombre(fam, s.combo)]) s.combo = 1;
            s.famCombo = fam;
            n = nombre(fam, s.combo);
          } else n = 'attack';
          s.tCombo = 0.9;
          this._golpe(j, s, d.arma, n);
        } else {
          // disparo propio de la postura (shoot_pistol / shoot_rifle / shoot_shoulder) si el modelo lo trae; si no, 'recoil';
          // y si tampoco, empujón procedural del torso y los brazos encima de la postura
          const tp = this._postura(d.arma), clip = tp && ('shoot_' + ({ pistola: 'pistol', rifle: 'rifle', hombro: 'shoulder' }[tp]));
          if (clip && s.acciones[clip]) this._unaVez(s, clip, false);
          else if (s.acciones.recoil && !s.posturas) this._unaVez(s, 'recoil', false);
          else s.retroceso = 1;
        }
      }),
      F.on('arma-recarga', (d) => { if (d && d.jugador === j) this._unaVez(s, 'reload', false); }),
      F.on('jugador-dano', (jj) => { if (jj === j && !j.muerto) this._unaVez(s, 'hit', false); }),
    ] : [];
  },

  /* ---------- Apuntar en 3ª persona: postura de torso y brazos (aim_pistol / aim_rifle / aim_shoulder) encima de la
     locomoción. Las posturas solo traen torso, cuello, cabeza y brazos; para que las piernas sigan caminando sin
     pelear con ellas se hace una copia de cada clip de locomoción SIN esos huesos ('#piernas'). Retroceso procedural. */
  _prepararApuntado(s, clips) {
    const A = s.acciones;
    const aims = ['aim_pistol', 'aim_rifle', 'aim_shoulder', 'aim_knife', 'hold_axe', 'hold_spear', 'hold_rifle', 'hold_shoulder', 'hold_guard2', 'hold_great', 'hold_great_g'].filter((n) => A[n]);   // hold_: agarre en reposo (hacha, lanza)
    // torso y brazos: los huesos de las posturas + todo lo que cuelga de la columna (para los golpes "solo brazos")
    const huesos = new Set();
    for (const n of aims) for (const t of A[n].getClip().tracks) huesos.add(t.name.split('.')[0]);
    let col = null;
    s.obj.traverse((o) => { if (!col && o.isBone && /spine|chest|torso/i.test(o.name)) col = o; });
    if (col) col.traverse((o) => { if (o.isBone) huesos.add(o.name); });
    if (!huesos.size) return;
    s.superiores = huesos;
    s.brazos = {};
    if (aims.length) {
      s.posturas = {};
      const NOMBRE = { aim_pistol: 'pistola', aim_rifle: 'rifle', aim_shoulder: 'hombro', aim_knife: 'cuchillo', hold_axe: 'hacha', hold_spear: 'lanza', hold_rifle: 'rifleR', hold_shoulder: 'hombroR', hold_guard2: 'guardia2', hold_great: 'espadon', hold_great_g: 'espadonG' };
      for (const n of aims) { const a = A[n]; a.setLoop(THREE.LoopRepeat); s.posturas[NOMBRE[n]] = a; }
    }
    s.piernas = {};
    for (const clip of clips) {
      if (/^aim_/.test(clip.name)) continue;
      const tracks = clip.tracks.filter((t) => !huesos.has(t.name.split('.')[0]));
      if (tracks.length === clip.tracks.length || !tracks.length) continue;
      s.piernas[clip.name] = s.mixer.clipAction(new THREE.AnimationClip(clip.name + '#piernas', clip.duration, tracks));
    }
    // huesos para el retroceso procedural
    const b = (re) => { let x = null; s.obj.traverse((o) => { if (!x && o.isBone && re.test(o.name)) x = o; }); return x; };
    s.hRetro = [b(/^chest$/i) || b(/spine/i), b(/^upperarm_r$/i), b(/^upperarm_l$/i)].filter(Boolean);
    s.retroceso = 0;
  },

  /* Golpe cuerpo a cuerpo en 3ª persona: solo brazos (copia '#brazos' del clip con torso y brazos, encima de las
     piernas que siguen caminando) o cuerpo entero (la animación completa manda y el jugador se frena: no patina) */
  _golpe(j, s, arma, n) {
    const vh = Math.hypot(j.cuerpo.velocidad.x, j.cuerpo.velocidad.z);
    let modo = (arma && arma.cuerpo3p) || 'auto';
    if (n === 'attack_melee_c' || /kick|patada/i.test(n) || !s.piernas) modo = 'entero';
    else if (modo === 'auto') modo = vh > 0.3 ? 'brazos' : 'entero';
    const a = modo === 'brazos' && this._brazos(s, n);
    if (a) {
      a.reset();
      if (s.poseActual === a) a.play();
      s.golpeArriba = { a, t: a.getClip().duration / Math.max(0.01, a.timeScale || 1) * 0.9 };
      return;
    }
    this._unaVez(s, n, true);
    if (s.bloqueo) j.frenoGolpe = s.bloqueo.t * 0.85;
  },

  _brazos(s, n) {
    if (s.brazos[n] !== undefined) return s.brazos[n];
    const base = s.acciones[n];
    let a = null;
    if (base) {
      const c = base.getClip(), tracks = c.tracks.filter((t) => s.superiores.has(t.name.split('.')[0]));
      if (tracks.length) {
        a = s.mixer.clipAction(new THREE.AnimationClip(c.name + '#brazos', c.duration, tracks));
        a.setLoop(THREE.LoopOnce); a.clampWhenFinished = true;
      }
    }
    return (s.brazos[n] = a);
  },

  // qué postura toca con esta arma (la del arma o la automática por nombre / tipo)
  _postura(arma) {
    if (!arma) return null;
    if (arma.tipo === 'cuerpo') return 'cuchillo';   // apuntar con cuerpo a cuerpo: aim_knife si el modelo lo trae
    const p = arma.postura3p || 'auto';
    if (p === 'ninguna') return null;
    if (p !== 'auto') return p;
    if (arma.magia && arma.magia !== 'no') return arma.magia === 'baston' ? 'rifle' : 'pistola';   // 🪄 bastón a dos manos
    const n = (arma.nombre || '').toLowerCase();
    if (/cohete|misil|bazuca|lanzagranadas|rpg/.test(n)) return 'hombro';
    if (/rifle|escopeta|fusil|ak|m16|ametralladora|subfusil|ballesta|l[aá]ser|plasma|francotirador|carabina/.test(n) || arma.perdigones > 1 || arma.automatica || arma.tipo === 'rayo') return 'rifle';
    return 'pistola';
  },

  _apuntado(j, s, dt, base, apunta, forzada, reposo) {
    const arma = j.armas && j.armas[j.armaActual];
    // apuntando: la postura de apuntar · sin apuntar: el agarre de reposo del arma (como el muñeco: rifle a dos manos, hacha, lanza)
    const tipo = forzada ? null : apunta ? this._postura(arma && arma.def) : reposo || null;
    const P = s.posturas || {};
    const pose = forzada || (tipo && (P[tipo] || (tipo === 'hombro' && P.rifle) || (tipo === 'rifle' && P.pistola) || null)) || null;
    // la locomoción: entera, o solo las piernas si hay postura (y la entera se apaga mientras tanto)
    const piernas = pose && base ? s.piernas[base.getClip().name] : null;
    const quiero = piernas || base;
    if (base && (quiero !== s.locoActual || base !== s.baseVisto)) {
      if (s.locoActual && s.locoActual !== quiero && s.locoActual !== base) s.locoActual.fadeOut(0.12);
      if (piernas) { piernas.reset().fadeIn(0.12).play(); base.fadeOut(0.12); }
      else if (s.locoActual && s.locoActual !== base) base.reset().fadeIn(0.12).play();
      s.locoActual = quiero; s.baseVisto = base;
    }
    if (piernas) piernas.timeScale = base.timeScale;
    if (pose !== s.poseActual) {
      if (s.poseActual) s.poseActual.fadeOut(0.12);
      if (pose) pose.reset().fadeIn(forzada ? 0.06 : 0.12).play();
      s.poseActual = pose;
    }
    s.tipoPose = tipo;
  },

  // después de animar: empuja pecho y brazos hacia atrás al disparar (más con armas grandes) y vuelve rápido
  _retroceso(s, dt) {
    if (!s.hRetro || !s.hRetro.length) return;
    // lo que puso el retroceso el cuadro anterior se quita antes de poner el nuevo: si la animación no mueve ese
    // hueso (pecho o brazo quieto), el empujón se iba SUMANDO cuadro a cuadro y el personaje acababa doblado
    if (s.retroPuesto) {
      for (const r of s.retroPuesto) if (r.h.quaternion.equals(r.puesto)) r.h.quaternion.copy(r.antes);
      s.retroPuesto = null;
    }
    if (!(s.retroceso > 0)) return;
    const fuerza = Math.min(0.3, { pistola: 0.12, rifle: 0.18, hombro: 0.3 }[s.tipoPose || 'pistola'] * Math.min(1, s.retroceso));   // con tope
    s.retroceso = Math.max(0, s.retroceso - dt * 9);
    const T = THREE, eje = new T.Vector3(1, 0, 0).applyQuaternion(s.obj.getWorldQuaternion(new T.Quaternion()));   // derecha del personaje
    s.retroPuesto = [];
    for (const h of s.hRetro) {
      const antes = h.quaternion.clone();
      const qp = h.parent.getWorldQuaternion(new T.Quaternion()).invert();
      const e = eje.clone().applyQuaternion(qp);
      h.quaternion.premultiply(new T.Quaternion().setFromAxisAngle(e, -fuerza));
      s.retroPuesto.push({ h, antes, puesto: h.quaternion.clone() });
    }
  },

  /* Animación de una vez: exclusiva (manda sobre las piernas) o mezclada encima */
  _unaVez(s, nombre, exclusiva) {
    const a = s.acciones && s.acciones[nombre];
    if (!a) return;
    const dur = a.getClip().duration / Math.max(0.01, a.timeScale || 1);
    if (exclusiva) { s.bloqueo = { nombre, t: dur * 0.9 }; return; }
    if (s.capa && s.capa.a !== a) s.capa.a.fadeOut(0.08);
    a.reset();
    a.setEffectiveWeight(0.85);
    a.fadeIn(0.05).play();
    s.capa = { a, t: dur };
  },

  despues(j, p, s, dt) {
    const c = j.cuerpo;
    s.obj.visible = j.modoCamara === 'tps' || p.visibleEnFps;
    s.obj.position.set(c.pie.x, c.visY, c.pie.z);
    const MT = j.montado;
    if (MT) { s.obj.position.y = MT.obj.position.y + (MT.p.asiento || 0); if (MT.p.ocultarJugador) s.obj.visible = false; }
    const vh = MT ? 0 : Math.max(Math.hypot(c.velocidad.x, c.velocidad.z), j.pasoForzado || 0);
    if (s.tApuntar > 0) s.tApuntar -= dt;
    if (s.tCombo > 0) s.tCombo -= dt;
    const apunta = j.modoCamara === 'tps' && ((j.apuntando || 0) > 0.2 || s.tApuntar > 0);
    if ((apunta || vh > 0.3 || j.camFija) && !j.pasoForzado) {
      // apuntando o recién disparado: mira hacia donde mira la cámara (de lado al caminar); si no, hacia donde camina
      const meta = (apunta || j.camFija ? j.yaw + Math.PI : Math.atan2(c.velocidad.x, c.velocidad.z)) + (p.girar180 ? Math.PI : 0);
      let dif = meta - s.giro;
      dif = Math.atan2(Math.sin(dif), Math.cos(dif));
      s.giro += dif * Math.min(1, dt * 12);
    }
    if (j.trepando && j.mirarEscala != null) s.giro = j.mirarEscala + (p.girar180 ? Math.PI : 0);   // de cara a la escalera de mano
    // 🧱 empujando / jalando: siempre de cara al objeto
    const AG = j.juego.empujables && j.juego.empujables.agarre;
    if (AG) {
      let dif = Math.atan2(AG.cx, AG.cz) + (p.girar180 ? Math.PI : 0) - s.giro;
      dif = Math.atan2(Math.sin(dif), Math.cos(dif));
      s.giro += dif * Math.min(1, dt * 14);
    }
    if (MT) s.giro = MT.yaw + Math.PI + (p.girar180 ? Math.PI : 0);   // 🐎 de frente como el vehículo
    s.obj.rotation.y = s.giro;
    // ⚔ giro (combo / ataque cargado): una vuelta entera rápida, frenando al final
    if (s.vuelta) { s.vuelta.t += dt; const k = Math.min(1, s.vuelta.t / s.vuelta.dur); s.obj.rotation.y -= Math.PI * 2 * k * (2 - k); if (k >= 1) s.vuelta = null; }
    // esquivar sin animación "dash"/"roll": se inclina hacia delante (barato y se lee)
    const A0 = s.acciones || {};
    let lean = j.esquivando && !(A0.roll || A0.dodge) ? -0.5 : 0;
    // nadando (sin animación "swim" propia): el cuerpo se tumba hacia delante al nadar y se endereza quieto
    if (j.nadando && !A0.swim) lean = vh > 0.6 || Math.abs(c.velocidad.y) > 0.6 ? 1.15 : 0.15;
    s.obj.rotation.order = 'YXZ';   // el giro en X es hacia SU frente (no el del mundo)
    s.obj.rotation.x += (lean - s.obj.rotation.x) * Math.min(1, dt * (j.nadando ? 5 : 14));
    if (j.nadando && s.obj.rotation.x > 0) s.obj.position.y += c.altura * 0.3 * Math.sin(s.obj.rotation.x);   // gira sobre los pies: que no se hunda
    const fg = s.obj.userData.figura;
    if (fg && fg.flip > 0) {
      // voltereta: una vuelta entera hacia delante alrededor del centro del cuerpo (no de los pies)
      const t = 1 - fg.flip / 0.5, th = Math.PI * 2 * (t * t * (3 - 2 * t)), hc = c.altura * 0.5;
      s.obj.rotation.x = lean + th;
      const dz = -hc * Math.sin(th);
      s.obj.position.y += hc * (1 - Math.cos(th));
      s.obj.position.x += Math.sin(s.giro) * dz; s.obj.position.z += Math.cos(s.giro) * dz;
      if (fg.flip - dt <= 0) s.obj.rotation.x = lean;
    }

    if (s.obj.userData.figura) this._animarFigura(j, s, dt);
    if (s.piel) {   // copiar la pose del muñeco al modelo (los muslos del muñeco cuelgan de la raíz; los del modelo, de Hips)
      const P = s.piel, qc = P.F.cadera.quaternion, inv = qc.clone().invert();
      for (const [piv, hueso, n] of P.par) { hueso.quaternion.copy(piv.quaternion); if (n.startsWith('muslo')) hueso.quaternion.premultiply(inv); }
      if (P.hips) P.hips.position.copy(P.hips0).add(P.F.cadera.position).sub(P.cad0);
    }
    if (s.acciones) {
      const vCaminar = j.props('movimiento').velocidad || 4.5;
      const A = s.acciones;
      // con arma de fuego en la mano: variantes _p (idle_p, walk_p, run_p, crouch_p) si el modelo las trae
      const arma = j.armas && j.armas[j.armaActual];
      const conArma = arma && arma.def.tipo !== 'cuerpo';
      const estC = arma && arma.def.tipo === 'cuerpo' ? FORJA.Escena.estiloCuerpo(arma.def) : null, guardia2 = estC === 'dosManos' || estC === 'lanza' || estC === 'espadon';
      const v = (n) => (conArma && A[n + '_p'] ? n + '_p' : n);
      if (s.bloqueo) { s.bloqueo.t -= dt; if (s.bloqueo.t <= 0) s.bloqueo = null; }
      if (s.golpeArriba) { s.golpeArriba.t -= dt; if (s.golpeArriba.t <= 0 || j.muerto || s.bloqueo) s.golpeArriba = null; }
      if (j.frenoGolpe > 0) j.frenoGolpe -= dt;
      // animaciones de Fase 1 si el modelo las trae (si no, los módulos usan su propio efecto)
      if (j.muerto && (A.death || A.die)) this._poner(s, A.death ? 'death' : 'die', 1, p.fundido);
      else if (j.esquivando && (A.roll || A.dodge)) this._poner(s, A.roll ? 'roll' : 'dodge', 1, 0.05);
      else if (s.bloqueo) this._poner(s, s.bloqueo.nombre, 1, 0.05);
      else if (j.bloqueando && (A.block || A.guard) && !(guardia2 && s.posturas && s.posturas.guardia2)) this._poner(s, A.block ? 'block' : 'guard', 1, 0.08);   // 🛡 guardia (a dos manos: postura cruzada, abajo)
      else if (j.agachado && (A.crouch || A.crouch_walk)) this._poner(s, vh > 0.3 && A.crouch_walk ? 'crouch_walk' : v(A.crouch ? 'crouch' : 'crouch_walk'), 1, p.fundido);
      else if (j.nadando) this._poner(s, A.swim ? 'swim' : vh > 0.3 ? v('walk') : v('idle'), A.swim ? 0.6 + vh / 3 : Math.max(0.5, vh / vCaminar), p.fundido);
      else if (j.subiendoOrilla && (A.ledge_climb || A.climb_up)) this._poner(s, A.ledge_climb ? 'ledge_climb' : 'climb_up', 1, 0.08);   // 🧗 subiendo el borde
      else if (j.colgado && (A.hang || A.climb)) this._poner(s, A.hang ? 'hang' : 'climb', A.hang ? 1 : 0.001, 0.1);   // 🧗 colgado de un borde
      else if (j.trepando && (A.climb || A.ladder)) this._poner(s, A.climb ? 'climb' : 'ladder', Math.abs(c.velocidad.y) / 1.6, 0.1);
      else if (!c.enSuelo && c.tAire > 0.15) this._poner(s, 'jump', 1, p.fundido);
      else if (j.corriendo && vh > vCaminar * 1.1) this._poner(s, v('run'), vh / (vCaminar * 1.65), p.fundido);
      else if (vh > 0.3) this._poner(s, v('walk'), vh / vCaminar, p.fundido);
      else this._poner(s, v('idle'), 1, p.fundido);
      // la de una vez encima: cuando acaba, se va suave
      if (s.capa) { s.capa.t -= dt; if (s.capa.t <= 0 || j.muerto) { s.capa.a.fadeOut(0.12); s.capa = null; } }
      // en 1ª persona el cuerpo no se ve: no se anima (se acumula el tiempo para no saltar al volver a 3ª)
      if (s.piernas) {
        // 🗡 agarre en reposo: con un modelo importado el arma no cuelga; se sujeta como el muñeco
        const ad = arma && arma.def;
        let rep = null;
        if (ad && !j.muerto && !s.bloqueo && !j.nadando && !j.trepando && !j.colgado && !(j.montado && !j.montado.p.disparar)) {
          if (ad.tipo !== 'cuerpo') rep = { rifle: 'rifleR', hombro: 'hombroR' }[this._postura(ad)] || null;   // pistola en reposo: colgando, como el muñeco
          else { const e = FORJA.Escena.estiloCuerpo(ad); rep = e === 'dosManos' ? 'hacha' : e === 'lanza' ? 'lanza' : e === 'espadon' ? 'espadon' : null; }
        }
        // 🛡 en guardia manda la animación de guardia (si no, la de apuntar le bajaba el brazo y el arma quedaba de lado)
        if (j.bloqueando && guardia2) rep = estC === 'espadon' && s.posturas && s.posturas.espadonG ? 'espadonG' : 'guardia2';   // 🛡 hacha / lanza en guardia: el mango cruzado delante
        this._apuntado(j, s, dt, s.actual, apunta && !j.muerto && !s.bloqueo && !j.bloqueando, s.golpeArriba && s.golpeArriba.a, j.bloqueando && !guardia2 ? null : rep);
      }
      if (s.obj.visible) { s.mixer.update(dt + (s.dtGuardado || 0)); s.dtGuardado = 0; if (s.hRetro) { s.obj.updateMatrixWorld(true); this._retroceso(s, dt); } }
      else s.dtGuardado = Math.min(0.5, (s.dtGuardado || 0) + dt);
    }
    // el personaje ya está movido y animado: lo que va pegado a él (el arma en la mano) se coloca ahora
    if (j.alColocarModelo) j.alColocarModelo(dt);
    if (j.alColocarAntorcha) j.alColocarAntorcha(dt);   // 🔥 la antorcha en la otra mano
  },

  _poner(s, nombre, velocidad, fundido) {
    const A = s.acciones;
    const accion = A[nombre] || (nombre === 'run' && A.walk) || A.idle || Object.values(A)[0];
    if (!accion) return;
    accion.timeScale = velocidad;
    if (accion === s.actual) return;
    accion.reset().fadeIn(fundido).play();
    if (s.actual) s.actual.fadeOut(fundido);
    s.actual = accion;
  },

  detener(j, p, s) {
    for (const quitar of s.oyentes || []) quitar();
    if (s.obj) j.escena.remove(s.obj);
    j.modelo = null;
  },
});
