/* Módulo CÁMARA — primera y tercera persona, mirar con ratón o stick.
   Equivale a tu mouse_look_module + camera_3d + ThirdPersonCameraModule. */
FORJA.registrarModulo({
  nombre: 'camara',
  etiqueta: 'Cámara',
  descripcion: 'Primera o tercera persona. En tercera persona la cámara no atraviesa paredes.',
  orden: 10,
  obligatorio: true,
  props: [
    { k: 'modo', t: 'sel', e: 'Modo', def: 'fps', op: [['fps', 'Primera persona'], ['tps', 'Tercera persona'], ['fija', '📷 Cámaras fijas (estilo Resident Evil)']],
      ayuda: 'Cámaras fijas: pon entidades 📷 en el nivel; cada una manda en su zona (un disparador)' },
    { k: 'controlFija', t: 'sel', e: 'Moverse con cámaras fijas', def: 'camara', si: (v) => v.modo === 'fija',
      op: [['camara', '🕹 Relativo a la cámara (arriba = al fondo de la pantalla)'], ['tanque', '🚜 Tanque (adelante avanza, los lados giran)']],
      ayuda: 'Relativo: al cambiar de plano mantiene la dirección mientras no sueltes. Tanque: el control clásico de RE' },
    { k: 'giroTanque', t: 'num', e: 'Giro (°/s)', def: 180, paso: 10, min: 30, si: (v) => v.modo === 'fija' },
    { k: 'autoApuntar', t: 'bool', e: 'Apuntar solo al enemigo', def: true, si: (v) => v.modo === 'fija', ayuda: 'Como en RE: al disparar apunta al enemigo que tengas delante' },
    { k: 'permitirCambio', t: 'bool', e: 'Cambiar con V / Y', def: true },
    { k: 'fov', t: 'num', e: 'Campo de visión', def: 70, paso: 1 },
    { k: 'sensRaton', t: 'rango', e: 'Sens. ratón', def: 1, min: 0.2, max: 3, paso: 0.05 },
    { k: 'sensMando', t: 'rango', e: 'Sens. mando', def: 1, min: 0.2, max: 3, paso: 0.05 },
    { k: 'invertirY', t: 'bool', e: 'Invertir vertical', def: false },
    { grupo: 'Tercera persona' },
    { k: 'distancia', t: 'num', e: 'Distancia', def: 3.5, paso: 0.1 },
    { k: 'alturaTps', t: 'num', e: 'Altura objetivo', def: 1.5, paso: 0.05, ayuda: 'A qué altura del jugador mira' },
    { k: 'hombro', t: 'num', e: 'Sobre el hombro (m)', def: 0, paso: 0.05, ayuda: 'Corre la cámara a la derecha (estilo RE4). Al apuntar se corre sola' },
  ],

  iniciar(j, p, s) {
    s.fijas = p.modo === 'fija' ? new FORJA.Camaras.Gestor(j.juego) : null;
    j.camFija = !!(s.fijas && s.fijas.hay);
    j.juego.camarasFijas = j.camFija ? s.fijas : null;   // la acción "📷 Cambiar a cámara" (mecanismos.js)
    j.tanque = j.camFija && p.controlFija === 'tanque';
    j.autoApuntar = j.camFija && p.autoApuntar !== false;
    if (p.modo === 'fija' && !j.camFija) console.warn('[cámara] modo Cámaras fijas sin ninguna 📷 en el nivel: uso 3ª persona');
    j.modoCamara = p.modo === 'fija' ? 'tps' : p.modo;   // con cámaras fijas el cuerpo se ve como en 3ª persona
    s.yawMov = null;
    FORJA.Entrada.sensRaton = p.sensRaton;
    FORJA.Entrada.sensMando = p.sensMando;
    FORJA.Entrada.invertirY = p.invertirY;
    j.camara.fov = p.fov;
    j.camara.updateProjectionMatrix();
  },

  entrada(j, p, s, dt) {
    const E = FORJA.Entrada;
    if (j.camFija) { this._entradaFija(j, p, s, dt || 0.016); return; }
    if (p.permitirCambio && E.pulsado('cambiar_camara')) {
      j.modoCamara = j.modoCamara === 'fps' ? 'tps' : 'fps';
      FORJA.emitir('camara-cambiada', j.modoCamara);
    }
    j.yaw -= E.mirar.x;
    j.pitch -= E.mirar.y;
    j.pitch = j.modoCamara === 'fps'
      ? FORJA.util.clamp(j.pitch, -1.55, 1.55)
      : FORJA.util.clamp(j.pitch, -1.2, 0.9);
  },

  /* Cámaras fijas: j.yaw es SIEMPRE hacia donde mira el cuerpo (el movimiento, el modelo y las armas lo usan).
     Tanque: los lados giran y adelante/atrás mueven. Relativo: la dirección pedida se pasa a la pantalla con el giro de la
     cámara (la de antes del corte mientras no sueltes), el cuerpo gira hacia ella y avanza. Apuntando: no se camina, se gira. */
  _entradaFija(j, p, s, dt) {
    const E = FORJA.Entrada, mx = E.mover.x, my = E.mover.y, giro = (p.giroTanque || 180) * FORJA.DEG * dt;
    j.pitch = 0;
    const apuntando = (j.apuntando || 0) > 0.2;
    if (j.tanque || apuntando) {
      j.yaw -= mx * giro;
      E.mover.x = 0;
      if (apuntando) E.mover.y = 0;
      return;
    }
    const L = Math.hypot(mx, my);
    if (L < 0.15) { s.yawMov = null; return; }
    if (s.yawMov == null) s.yawMov = s.fijas.yaw(j.camara);
    const sin = Math.sin(s.yawMov), cos = Math.cos(s.yawMov);
    const dx = mx * cos - my * sin, dz = -mx * sin - my * cos;   // como movimiento.js
    const meta = Math.atan2(-dx, -dz);
    let dif = meta - j.yaw; dif = Math.atan2(Math.sin(dif), Math.cos(dif));
    j.yaw += Math.abs(dif) < 0.05 ? dif : dif * Math.min(1, dt * 14);
    E.mover.x = 0; E.mover.y = Math.min(1, L) * (Math.abs(dif) > 2.4 ? 0.2 : 1);   // media vuelta: casi en el sitio
  },

  despues(j, p, s, dt) {
    const c = j.cuerpo, cam = j.camara;
    if (j.camFija) {
      const pecho = (s.pecho || (s.pecho = new THREE.Vector3())).set(c.pie.x, c.visY + c.altura * 0.6, c.pie.z);
      if (s.fijas.colocar(cam, pecho, dt || 0.016)) FORJA.emitir('camara-corte', s.fijas.actual.ent);
      return;
    }
    if (j.modoCamara === 'fps') {
      cam.position.set(c.pie.x, c.visY + j.alturaOjos, c.pie.z);
    } else {
      // al apuntar (módulo Armas) la cámara se acerca y se corre sobre el hombro derecho, para que el personaje no tape la mira
      const lado = (p.hombro || 0) + 0.65 * (j.apuntando || 0);
      const ox = c.pie.x + Math.cos(j.yaw) * lado, oy = c.visY + p.alturaTps - (j.bajarCamara || 0), oz = c.pie.z - Math.sin(j.yaw) * lado;
      const cp = Math.cos(j.pitch);
      const bx = Math.sin(j.yaw) * cp, by = -Math.sin(j.pitch), bz = Math.cos(j.yaw) * cp;   // hacia atrás
      let dist = (p.distancia + (j.camExtra || 0)) * (1 - 0.45 * (j.apuntando || 0));   // al apuntar la cámara se acerca
      const g = j.mundo.rayo(ox, oy, oz, bx, by, bz, dist);
      if (g) dist = Math.max(0.3, g.t - 0.2);
      cam.position.set(ox + bx * dist, oy + by * dist, oz + bz * dist);
    }
    cam.rotation.set(j.pitch, j.yaw, 0, 'YXZ');
  },
});
