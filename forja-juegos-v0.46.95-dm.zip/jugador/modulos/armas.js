/* Módulo ARMAS — disparar, apuntar, recargar y cambiar de arma. Las armas se crean en la pestaña "Armas".
   Funciona igual en 1ª y 3ª persona; lo único que cambia es de dónde sale el disparo:
   - 1ª persona: del centro de la cámara (la bala va justo a la mira). Se ve el arma en primer plano.
   - 3ª persona: se apunta con un rayo desde la cámara y la bala sale del arma (a la altura del pecho)
     hacia ese punto, así una pared entre el personaje y el blanco sí lo tapa. Mira en el centro de la pantalla.
   Rendimiento: chispas, marcas y proyectiles salen de grupos fijos (no se crea nada nuevo al disparar);
   los rayos usan el BVH del nivel y solo los objetos con Vida se revisan aparte. */
FORJA.registrarModulo({
  nombre: 'armas',
  etiqueta: 'Armas',
  descripcion: 'Clic / RT / botón táctil dispara · clic der. / LT apunta · R recarga · rueda, 1-9 o Y cambian de arma.',
  orden: 55,
  activoPorDefecto: false,
  props: [
    { k: 'alIniciar', t: 'sel', e: 'Armas al empezar', def: 'ficha', op: [['ficha', 'Las marcadas en cada arma (pestaña Armas)'],
      ['ninguna', 'Ninguna: hay que recogerlas'], ['todas', 'Todas las armas']] },
    { k: 'autoRecarga', t: 'bool', e: 'Recargar solo al vaciar', def: true },
    { k: 'cambiarSinBalas', t: 'bool', e: 'Sin balas: cambiar de arma solo', def: true,
      ayuda: 'Si el arma se vacía y no queda munición, pasa a la siguiente que tenga (o a los puños)' },
    { grupo: 'Sin arma' },
    { k: 'punos', t: 'bool', e: 'Golpear sin arma (puños)', def: false,
      ayuda: 'Los puños son un arma más (la primera, tecla 1): siempre a mano y sin munición. Útil si no hay balas o el juego es así' },
    { k: 'danoPunos', t: 'num', e: 'Daño de los puños', def: 12, paso: 1, min: 0, si: (v) => v.punos },
    { k: 'alcancePunos', t: 'num', e: 'Alcance (m)', def: 1.4, paso: 0.1, min: 0.5, si: (v) => v.punos },
    { k: 'cadenciaPunos', t: 'num', e: 'Golpes por segundo', def: 2.5, paso: 0.1, min: 0.2, si: (v) => v.punos },
    { k: 'animCambio', t: 'bool', e: 'Animación al cambiar de arma', def: true, ayuda: 'Apagada: el arma cambia al instante' },
    { k: 'dirCambio', t: 'sel', e: 'El arma entra', def: 'arriba', op: [['arriba', 'Desde arriba (sube y baja)'], ['abajo', 'Desde abajo (baja y sube)']],
      si: (v) => v.animCambio },
    { grupo: 'Calcomanías' },
    { k: 'calcomanias', t: 'bool', e: 'Sangre y quemaduras', def: true, ayuda: 'Manchas de sangre detrás de lo que hieres y quemaduras de las explosiones. Grupo fijo de 24 que se recicla: casi gratis' },
    { k: 'colorSangre', t: 'color', e: 'Color de la sangre', def: '#6a0808', si: (v) => v.calcomanias !== false },
    { k: 'armaEnTps', t: 'bool', e: 'Ver el arma en 3ª persona', def: true, ayuda: 'Va en la mano del modelo (hueso hand_R); sin hueso, a un costado' },
    { k: 'soloApuntando', t: 'bool', e: 'Solo dispara apuntando (Resident Evil)', def: false, ayuda: 'Las armas de fuego solo disparan con el clic derecho / LT mantenido (apuntando). Cuerpo a cuerpo golpea normal' },
    { k: 'soloApuntandoCuerpo', t: 'bool', e: 'Cuerpo a cuerpo solo apuntando', def: false, ayuda: 'Como los Resident Evil de PS1 y el 4: el cuchillo (y toda arma cuerpo a cuerpo) solo golpea con el clic derecho / LT mantenido' },
    { k: 'manoTps', t: 'sel', e: 'Mano del arma', def: 'derecha', op: [['derecha', 'Derecha (hand_R)'], ['izquierda', 'Izquierda (hand_L)']],
      ayuda: 'Si en tu modelo el arma sale en la mano equivocada, cambia aquí', si: (v) => v.armaEnTps },
    { k: 'fovArma', t: 'num', e: 'Campo de visión del arma', def: 0, paso: 1, min: 0,
      ayuda: '1ª persona: el arma se dibuja con su propia cámara. 0 = la misma que la vista (también hace zoom al apuntar); 55-65 = el arma no se deforma' },
    { grupo: 'Balanceo del arma (1ª persona)', av: true },
    { k: 'balanceo', t: 'rango', e: 'Intensidad general', def: 1, min: 0, max: 2, paso: 0.1, ayuda: '0 = el arma no se mece' },
    { k: 'ritmoCaminar', t: 'num', e: 'Ritmo al caminar', def: 1, paso: 0.1, min: 0, ayuda: 'Vaivenes por segundo. Fijo: no depende de la velocidad del jugador' },
    { k: 'fuerzaCaminar', t: 'rango', e: 'Fuerza al caminar', def: 1, min: 0, max: 3, paso: 0.05 },
    { k: 'ritmoCorrer', t: 'num', e: 'Ritmo al correr', def: 1.5, paso: 0.1, min: 0, ayuda: 'Vaivenes por segundo mientras corre (módulo Correr)' },
    { k: 'fuerzaCorrer', t: 'rango', e: 'Fuerza al correr', def: 1.6, min: 0, max: 3, paso: 0.05 },
    // 🛡 escudo de mano (medieval o antimotines): va en la mano libre con armas de una mano; clic derecho cubre
    { grupo: '🛡 Escudo de mano' },
    { k: 'escudoMano', t: 'sel', e: 'Escudo de base', def: 'no',
      op: [['no', 'No (solo si se recoge: ✚ Recogible ▸ Escudo de mano)'], ['medieval', '🛡 Medieval (madera y hierro)'], ['antimotines', '▮ Antimotines (transparente)']],
      ayuda: 'Va en la mano libre con armas de una mano (pistola, espada, varita…). Clic derecho / LT cubre en vez de apuntar: para lo que viene de frente hasta romperse, y entonces se pierde. Con armas a dos manos se guarda en la espalda' },
    { k: 'escudoManoAguante', t: 'num', e: 'Aguante', def: 120, paso: 10, min: 1, si: (v) => v.escudoMano && v.escudoMano !== 'no' },
    { k: 'escudoManoColor', t: 'color', e: 'Color', def: '', si: (v) => v.escudoMano && v.escudoMano !== 'no', ayuda: 'Vacío = el de su estilo' },
    { k: 'escudoManoBloquea', t: 'rango', e: 'Para del golpe (%)', def: 100, min: 10, max: 100, paso: 5, ayuda: 'Para todos los escudos de mano (de base y recogidos)' },
    { k: 'escudoManoLento', t: 'rango', e: 'Velocidad cubriéndose', def: 0.6, min: 0.2, max: 1, paso: 0.05, ayuda: '1 = igual de rápido · 0.5 = a la mitad' },
  ],

  iniciar(j, p, s) {
    // ⚔ golpe especial pedido por el módulo Combate (cargado, en caída…): aunque esté en espera, con el arma cuerpo a cuerpo
    j.golpeEspecial = (mod) => {
      const a = this._actual(j);
      if (!a || a.def.tipo !== 'cuerpo' || j.muerto) return false;
      s.golpeMod = mod; s.cd = 0;
      this._disparar(j, p, s, a);
      return true;
    };
    const T = THREE;
    const proyecto = j.juego.proyecto;
    s.T = T;
    // tipos de munición (reserva compartida entre las armas que usan el mismo tipo)
    s.tipos = new Map((proyecto.municiones || []).map((m) => [m.id, m]));
    j.tiposMunicion = s.tipos;
    j.municion = {};
    j.municionExtra = {};   // ⬆ máximo ganado con recogibles (bolsa, carcaj): se guarda en la partida
    s.maxDe = (m) => m.maxima + (j.municionExtra[m.id] || 0);
    for (const m of s.tipos.values()) j.municion[m.id] = Math.min(m.maxima, m.alEmpezar || 0);
    const todas = proyecto.armas || [];
    const iniciales = p.alIniciar === 'ninguna' ? [] : p.alIniciar === 'todas' ? todas : todas.filter((d) => d.alEmpezar);
    j.armas = iniciales.map((d) => this._nuevaArma(d, s));
    // puños: un arma "de mentira" que no está en la pestaña Armas
    s.punos = {
      ...FORJA.Escena.armaNueva(), id: '__punos', nombre: 'Puños', tipo: 'cuerpo', dano: p.danoPunos ?? 12, alcance: p.alcancePunos ?? 1.4,
      cadencia: p.cadenciaPunos ?? 2.5, cargador: 0, reserva: 0, reservaMax: 0, infinita: true, retroceso: 0, agujeros: false,
      municion: '', alEmpezar: true, posX: 0.16, posY: -0.24, posZ: -0.36,
    };
    j.armasExtra = [s.punos];   // para guardar y cargar partida
    if (p.punos) j.armas.unshift(this._nuevaArma(s.punos, s));
    j.armaActual = 0;
    j.apuntando = 0;
    j.bloqueando = false;
    /* 🛡 bloqueo: lo de frente (±70°) se reduce un %; justo al levantar la guardia (parry) no entra nada y el enemigo
       que pegó queda aturdido. Las explosiones, caídas y el entorno no se bloquean. */
    // 🛡 hechizo escudo activo: para el daño (salud.js lo pregunta antes que la armadura)
    j.alEscudo = (cant, origen, de) => this._recibirEnEscudo(j, s, cant, origen, de);
    // 🛡 escudo de mano: j.escudoMano = { estilo, vida, max, color } o null. Lo dan "Escudo de base" o un recogible
    j.escudoMano = p.escudoMano && p.escudoMano !== 'no' ? this._nuevoEscudoMano(p.escudoMano, p.escudoManoAguante, p.escudoManoColor) : null;
    j.cubriendo = false;
    j.darEscudoMano = (op = {}) => {
      j.escudoMano = this._nuevoEscudoMano(op.estilo || 'medieval', op.aguante || 120, op.color || '');
      FORJA.Audio.sintetico('recoger', { volumen: 0.7, tono: 0.8 });
      return true;
    };
    // 🛡 tiempo de gracia del parry (módulo Combate ▸ Parry): se suma a la ventana de cada arma y del escudo
    const gracia = () => { const C = j.estados.combate ? j.props('combate') : null; return C ? (C.parryGracia ?? 0.15) : 0; };
    const combate = () => (j.estados.combate ? j.props('combate') : null);
    // ¿un parry ahora mismo? (guardia recién levantada con un arma de parry, o escudo recién levantado)
    const enParry = () => {
      const a = this._actual(j), C = combate();
      if (j.cubriendo && j.escudoMano && C && C.parryEscudo !== false && (s.tCubre || 0) <= 0.2 + gracia()) return 'escudo';
      if (j.bloqueando && a && a.def.tipo === 'cuerpo') { const par = a.def.parry ?? 0.25; if (par > 0 && (s.tBloq || 0) <= par + gracia()) return 'arma'; }
      return null;
    };
    // 🛡 proyectil enemigo que llega: con un parry de frente se devuelve (enemigos.js)
    j.alDesviar = (b) => {
      const C = combate();
      if (!C || C.parryProyectiles === false) return false;
      const v = b.vel, l = Math.hypot(v.x, v.z) || 1;
      if ((Math.sin(j.yaw) * v.x + Math.cos(j.yaw) * v.z) / l < 0.34) return false;   // tiene que venir de frente
      const como = enParry();
      if (!como) return false;
      if (como === 'arma') s.tBloq = 99; else s.tCubre = 99;   // un parry por guardia
      FORJA.Audio.sintetico('impacto', { volumen: 0.9, tono: 2 });
      FORJA.emitir('parry', { jugador: j, enemigo: b.de, proyectil: true });
      return true;
    };
    j.alBloquear = (cant, origen, de) => {
      // 🛡 parry con el escudo de mano (recién levantado): no entra nada, no gasta escudo y el atacante queda aturdido
      if (j.cubriendo && j.escudoMano && (!origen || origen === 'enemigo') && enParry() === 'escudo') {
        const pie0 = de && de.cuerpo && de.cuerpo.pie;
        const frente = !pie0 || (-Math.sin(j.yaw) * (pie0.x - j.cuerpo.pie.x) - Math.cos(j.yaw) * (pie0.z - j.cuerpo.pie.z)) / (Math.hypot(pie0.x - j.cuerpo.pie.x, pie0.z - j.cuerpo.pie.z) || 1) >= 0.34;
        if (frente) {
          const EN = j.juego && j.juego.enemigos;
          if (de && EN && EN.aturdir && !de.muerto) EN.aturdir(de, 1.2);
          FORJA.Audio.sintetico('impacto', { volumen: 0.9, tono: 1.8 });
          FORJA.emitir('parry', { jugador: j, enemigo: de, escudo: true });
          s.tCubre = 99; s.golpeEscudo = 1;
          return 0;
        }
      }
      // 🛡 cubriéndose con el escudo de mano: lo de frente lo para el escudo hasta romperse (antes que la guardia del arma)
      if (j.cubriendo && j.escudoMano && (!origen || origen === 'enemigo')) {
        const pie0 = de && de.cuerpo && de.cuerpo.pie;
        let deFrente = true;
        if (pie0) {
          const dx = pie0.x - j.cuerpo.pie.x, dz = pie0.z - j.cuerpo.pie.z, l = Math.hypot(dx, dz) || 1;
          deFrente = (-Math.sin(j.yaw) * dx - Math.cos(j.yaw) * dz) / l >= 0.34;
        }
        if (deFrente) {
          const M = j.escudoMano, para = Math.min(M.vida, cant * Math.min(1, (p.escudoManoBloquea ?? 100) / 100));
          M.vida -= para;
          s.golpeEscudo = 1;
          if (M.vida <= 0.001) {
            j.escudoMano = null; j.cubriendo = false;
            FORJA.Audio.sintetico('impacto', { volumen: 0.9, tono: 0.5 });
            FORJA.emitir('escudo-mano-roto', j);
          } else FORJA.Audio.sintetico('impacto', { volumen: 0.6, tono: M.estilo === 'antimotines' ? 1.3 : 0.9 });
          cant -= para;
          if (!(cant > 0)) return 0;
        }
      }
      const a = this._actual(j);
      if (!j.bloqueando || !a || a.def.tipo !== 'cuerpo' || (origen && origen !== 'enemigo')) return cant;
      const pie = de && de.cuerpo && de.cuerpo.pie;
      if (pie) {
        const dx = pie.x - j.cuerpo.pie.x, dz = pie.z - j.cuerpo.pie.z, l = Math.hypot(dx, dz) || 1;
        if ((-Math.sin(j.yaw) * dx - Math.cos(j.yaw) * dz) / l < 0.34) return cant;   // por detrás o de lado: no se para
      }
      const d = a.def, par = (d.parry ?? 0.25) > 0 ? (d.parry ?? 0.25) + gracia() : 0;
      if (par > 0 && (s.tBloq || 0) <= par) {
        const EN = j.juego && j.juego.enemigos;
        if (de && EN && EN.aturdir && !de.muerto && (d.aturdeParry ?? 1.2) > 0) EN.aturdir(de, d.aturdeParry ?? 1.2);
        FORJA.Audio.sintetico('impacto', { volumen: 0.8, tono: 1.8 });
        FORJA.emitir('parry', { jugador: j, enemigo: de });
        s.tBloq = par + 0.01;   // un parry por guardia
        return 0;
      }
      FORJA.Audio.sintetico('impacto', { volumen: 0.5, tono: 1.4 });
      FORJA.emitir('bloqueo', { jugador: j, enemigo: de });
      return cant * (1 - Math.min(100, Math.max(0, d.bloqueo ?? 70)) / 100);
    };
    s.cd = 0;            // espera hasta el próximo disparo
    s.recargando = 0;
    s.cambio = 0;        // animación al cambiar de arma (baja y sube)
    s.retro = 0;         // retroceso visual del arma
    s.paso = 0;
    s.fov0 = j.camara.fov;
    s.v1 = new T.Vector3(); s.v2 = new T.Vector3(); s.v3 = new T.Vector3(); s.q = new T.Quaternion();
    s.ray = new T.Raycaster();

    // Textura redonda para chispas, fogonazos y explosiones
    const c = document.createElement('canvas');
    c.width = c.height = 32;
    const g = c.getContext('2d');
    for (let i = 4; i >= 1; i--) { g.fillStyle = `rgba(255,255,255,${(5 - i) / 4})`; g.beginPath(); g.arc(16, 16, i * 3.8, 0, 7); g.fill(); }
    s.tex = new T.CanvasTexture(c);
    s.tex.magFilter = T.NearestFilter;
    const sprite = (color) => {
      const sp = new T.Sprite(new T.SpriteMaterial({ map: s.tex, color, transparent: true, blending: T.AdditiveBlending, depthWrite: false }));
      sp.visible = false;
      sp.userData.ayudaEditor = true;
      j.escena.add(sp);
      return sp;
    };
    s.chispas = Array.from({ length: 14 }, () => ({ sp: sprite('#ffd27a'), t: 0 }));
    s.ci = 0;
    s.flash = sprite('#ffd27a');
    s.flashT = 0;
    s.explosiones = Array.from({ length: 4 }, () => ({ sp: sprite('#ff8a3a'), t: 0, radio: 1 }));
    s.ei = 0;
    s.balas = Array.from({ length: 16 }, () => ({ sp: sprite('#ffcc66'), activa: false, pos: new T.Vector3(), vel: new T.Vector3(), recorrido: 0, def: null }));
    // Marcas de bala en paredes (las más viejas se reutilizan)
    const matMarca = new T.MeshBasicMaterial({ color: 0x111111, transparent: true, opacity: 0.75, depthWrite: false,
      polygonOffset: true, polygonOffsetFactor: -4, polygonOffsetUnits: -4 });
    const geoMarca = new T.PlaneGeometry(0.12, 0.12);
    s.marcas = Array.from({ length: 40 }, () => { const m = new T.Mesh(geoMarca, matMarca); m.visible = false; j.escena.add(m); return m; });
    s.mi = 0;
    // 🩸 calcomanías: sangre (al herir, en la pared o suelo de detrás) y quemaduras (explosiones). Grupo fijo de 24
    // que se recicla (la más vieja se reutiliza): cero objetos nuevos al jugar
    const cc = document.createElement('canvas'); cc.width = cc.height = 32;
    const gc = cc.getContext('2d');
    gc.fillStyle = '#fff';
    for (let i = 0; i < 9; i++) { gc.beginPath(); gc.arc(16 + (Math.random() - 0.5) * 14, 16 + (Math.random() - 0.5) * 14, 3 + Math.random() * 6, 0, 7); gc.fill(); }
    s.texCalco = new T.CanvasTexture(cc); s.texCalco.magFilter = T.NearestFilter;
    const matCalco = (color, op) => new T.MeshBasicMaterial({ color, map: s.texCalco, transparent: true, opacity: op, alphaTest: 0.3, depthWrite: false,
      polygonOffset: true, polygonOffsetFactor: -4, polygonOffsetUnits: -4 });
    s.matSangre = matCalco(p.colorSangre || '#6a0808', 0.9);
    s.matQuema = matCalco('#0d0b0a', 0.8);
    const geoCalco = new T.PlaneGeometry(1, 1);
    s.calcos = p.calcomanias === false ? [] : Array.from({ length: 24 }, () => { const m = new T.Mesh(geoCalco, s.matSangre); m.visible = false; m.userData.ayudaEditor = true; j.escena.add(m); return m; });
    s.ki = 0;
    s.recursos = [matMarca, geoMarca, s.matSangre, s.matQuema, geoCalco, s.texCalco];
    // las calcomanías que estaban sobre algo que se rompe desaparecen con él; las de una puerta que se abre se van
    // con su hoja; las explosiones de barriles y bombas también queman el suelo
    s.oyentes = [
      FORJA.on('objetivo-roto', (o) => this._calcosDe(j, s, o && o.obj, false)),
      FORJA.on('puerta-abierta', (x) => { const ent = x && (x.ent || x); this._calcosDe(j, s, ent && j.juego.objetos.get(ent.id), true); }),
      FORJA.on('explosion', (p, radio) => { if (s.calcos.length && p) this._calco(j, s, p, (s.cdir || (s.cdir = new T.Vector3())).set(0, -1, 0), 4, s.matQuema, Math.max(0.8, (radio || 2) * 0.9)); }),
    ];

    // El arma que se ve (una por arma, se crea al usarla por primera vez).
    // En 1ª persona va en el "primer plano" de la vista (se dibuja encima: no atraviesa paredes);
    // en 3ª persona va en el mundo, para que las paredes sí la tapen.
    s.vista = new T.Group();
    s.vista.userData.ayudaEditor = true;
    s.pp = j.juego.vista.primerPlano();
    j.alColocarModelo = () => {
      if (s.tps) { this._colocarTps(j, s); s.tps = false; }
      // 🛡 escudo de mano en 3ª persona: también después de mover al personaje (si no, se queda atrás al correr,
      // saltar o ir montado)
      if (s.escPend) { const [p2, a2] = s.escPend; s.escPend = null; this._colocarEscudoMano(j, p2, s, a2, 0, true); }
    };
    s.pp.fov = p.fovArma || 0;
    s.pp.escena.add(s.vista);
    s.modelos = new Map();

    // HUD (dónde y cómo se ve lo decide Juego ▸ HUD)
    s.hud = FORJA.Hud.pieza(j.juego, 'fh-municion', '<span class="fh-arma"></span><span class="fh-ico"></span><span class="fh-num"></span>');
    s.hudArma = s.hud.querySelector('.fh-arma');
    s.hudIco = s.hud.querySelector('.fh-ico');
    s.hudNum = s.hud.querySelector('.fh-num');
    s.pintado = '';

    // Para recogibles: dar armas y munición. Devuelven true si algo cambió.
    // Un arma que ya tienes da munición: "extra" si se indica (el recogible), si no la que trae su ficha.
    j.darArma = (id, extra = 0) => {
      const d = (proyecto.armas || []).find((x) => x.id === id || x.nombre === id);
      if (!d) return false;
      const ya = j.armas.find((a) => a.def === d);
      if (ya) return this._sumar(j, s, ya, extra > 0 ? extra : d.reserva);
      const nueva = this._nuevaArma(d, s);
      j.armas.push(nueva);
      // con munición compartida, la que trae se suma al tipo
      if (this._tipo(s, d)) this._sumar(j, s, nueva, d.reserva);
      this._cambiar(j, s, j.armas.length - 1);
      return true;
    };
    // ⬆ sube el máximo de un tipo de munición (y si se pide, lo llena)
    j.ampliarMunicion = (id, n, llenar) => {
      const tipo = s.tipos.get(id) || [...s.tipos.values()].find((m) => m.nombre === id);
      if (!tipo || !(n > 0)) return false;
      j.municionExtra[tipo.id] = (j.municionExtra[tipo.id] || 0) + n;
      if (llenar) j.municion[tipo.id] = s.maxDe(tipo);
      return true;
    };
    // id: un tipo de munición (id o nombre) o un arma (su munición propia o la de su tipo)
    j.darMunicion = (id, n) => {
      const tipo = s.tipos.get(id) || [...s.tipos.values()].find((m) => m.nombre === id);
      if (tipo) {
        // como en Doom: se puede juntar munición de un arma que aún no tienes
        const antes = j.municion[tipo.id] || 0;
        j.municion[tipo.id] = Math.min(s.maxDe(tipo), antes + n);
        return j.municion[tipo.id] > antes;
      }
      const a = j.armas.find((x) => x.def.id === id || x.def.nombre === id);
      return a ? this._sumar(j, s, a, n) : false;
    };
  },

  _nuevaArma(d, s) {
    // con munición compartida la reserva vive en j.municion; la del arma no se usa
    return { def: d, cargador: d.cargador > 0 ? d.cargador : 0, reserva: s && this._tipo(s, d) ? 0 : d.reserva };
  },

  /* ---------- Munición: propia del arma o compartida por tipo ---------- */
  _tipo(s, d) { return d.municion ? s.tipos.get(d.municion) || null : null; },
  _res(j, s, a) {
    const t = this._tipo(s, a.def);
    return t ? j.municion[t.id] || 0 : a.reserva;
  },
  _ponerRes(j, s, a, v) {
    const t = this._tipo(s, a.def);
    if (t) j.municion[t.id] = v; else a.reserva = v;
  },
  _max(s, a) {
    const t = this._tipo(s, a.def);
    return t ? s.maxDe(t) : a.def.reservaMax;
  },
  _sumar(j, s, a, n) {
    if (a.def.infinita) return false;
    const antes = this._res(j, s, a), max = this._max(s, a);
    if (antes >= max || !(n > 0)) return false;
    this._ponerRes(j, s, a, Math.min(max, antes + n));
    return true;
  },
  // daño final y tipo: el tipo de munición multiplica y manda; sin tipo, el del arma
  _dano(s, d, base) {
    const t = this._tipo(s, d);
    const propio = d.tipoDano && d.tipoDano !== 'normal' ? d.tipoDano : null;   // hechizo con maná: manda el del arma
    return { cantidad: base * (t ? t.multDano ?? 1 : 1), tipo: propio || (t ? t.tipoDano || 'normal' : d.tipoDano || 'normal'), color: t && t.color };
  },

  _actual(j) { return j.armas && j.armas[j.armaActual]; },

  // hueso de la mano derecha del modelo del jugador (se busca una vez por modelo; la figura del motor también tiene "hand_R")
  _mano(j, s) {
    const izq = j.props('armas').manoTps === 'izquierda';
    if (s.manoDe !== j.modelo || s.manoIzq !== izq) {
      s.manoDe = j.modelo;
      s.manoIzq = izq;
      s.mano = null;
      const re = izq ? /^(hand_?l|mano_?i|lefthand|hand\.l|mixamorig:lefthand)$/i : /^(hand_?r|mano_?d|righthand|hand\.r|mixamorig:righthand)$/i;
      if (j.modelo) j.modelo.traverse((o) => { if (!s.mano && re.test(o.name)) s.mano = o; });
    }
    return s.mano;
  },

  // pone el arma de 3ª persona en la mano, con el personaje ya movido y animado en este cuadro.
  // El arma sigue a la MANO como parte del brazo: el cañón va en la dirección antebrazo → mano
  // (brazo caído = apunta al suelo; brazo al frente al apuntar = apunta al frente). No gira con el ratón.
  _colocarTps(j, s) {
    const T = s.T, mano = this._mano(j, s);
    if (!mano || !j.modelo) {
      // sin modelo con mano: a un costado del pecho, hacia donde mira la cámara (como antes)
      this._boca(j, s, s.vista.position);
      s.vista.quaternion.copy(j.camara.quaternion);
      return;
    }
    j.modelo.updateMatrixWorld(true);   // posición, giro y huesos de ESTE cuadro
    const h = mano.getWorldPosition(s.tv1 || (s.tv1 = new T.Vector3()));
    const pa = (mano.parent || mano).getWorldPosition(s.tv2 || (s.tv2 = new T.Vector3()));
    const dir = s.tv3 || (s.tv3 = new T.Vector3());
    dir.copy(h).sub(pa);
    if (dir.lengthSq() < 1e-8) dir.set(0, -1, 0); else dir.normalize();
    // 🎯 armas largas: el cañón va de la mano del gatillo hacia la otra mano (la que lo sujeta delante), si están
    // a distancia de agarrar el arma (las dos manos en el arma: postura aim_rifle / aim_shoulder o el modelo en reposo)
    const arma = this._actual(j);
    const fig = j.modelo.userData.figura;   // la figura del motor sujeta el arma larga con las dos manos siempre (IK)
    // modelo importado con su postura de agarre puesta (rifle, lanzacohetes, hacha, lanza): igual que el muñeco, a dos manos
    const sm = !fig && j.estados && j.estados.modelo, tp = sm && sm.poseActual ? sm.tipoPose : null;
    const glbDos = tp === 'rifle' || tp === 'hombro' || tp === 'rifleR' || tp === 'hombroR' || tp === 'hacha' || tp === 'lanza' || tp === 'guardia2' || tp === 'espadon' || tp === 'espadonG';
    if (arma && (j.apuntando > 0.5 || (fig && fig.dosManos) || glbDos) && (this._dosManos(arma.def) || (fig && fig.dosManos && arma.def.tipo === 'cuerpo') || glbDos)) {   // solo apuntando: al caminar las manos se cruzan y el arma giraba
      const otra = this._otraMano(j, s);
      if (otra) {
        const o = otra.getWorldPosition(s.tv8 || (s.tv8 = new T.Vector3()));
        const v = o.sub(h), largo = v.length();
        // solo si la otra mano está DELANTE (sujetando el cañón); con los brazos caídos sigue al antebrazo
        const fr = (s.tv9 || (s.tv9 = new T.Vector3())).set(0, 0, 1).applyQuaternion(j.modelo.getWorldQuaternion(s.tq2 || (s.tq2 = new T.Quaternion())));
        if (((fig && fig.agarreIzq) || tp === 'hacha' || tp === 'espadon' || tp === 'espadonG') && largo > 0.03) {
          // hacha / mazo: se agarra por el extremo con la izquierda y la cabeza sale más allá de la derecha
          dir.copy(v).divideScalar(-largo);
          h.copy(otra.getWorldPosition(s.tv8));
        } else if (largo > 0.12 && largo < 0.9 && ((fig && fig.cruzado) || glbDos || v.dot(fr) > largo * 0.35)) dir.copy(v).divideScalar(largo);   // cruzado = guardia con arma a dos manos
      }
    }
    // "arriba" del arma: con el brazo caído mira hacia delante del personaje; con el brazo horizontal, hacia arriba
    const frente = (s.tv4 || (s.tv4 = new T.Vector3())).set(0, 0, 1).applyQuaternion(j.modelo.getWorldQuaternion(s.tq || (s.tq = new T.Quaternion())));
    const k = Math.abs(dir.y);
    const arriba = (s.tv5 || (s.tv5 = new T.Vector3())).set(0, 1, 0).multiplyScalar(1 - k).addScaledVector(frente, k);
    arriba.addScaledVector(dir, -dir.dot(arriba));
    if (arriba.lengthSq() < 1e-6) arriba.copy(frente); else arriba.normalize();
    // base del arma: −Z = cañón (dir), Y = arriba, X = Y × Z
    const z = (s.tv6 || (s.tv6 = new T.Vector3())).copy(dir).negate();
    const x = (s.tv7 || (s.tv7 = new T.Vector3())).crossVectors(arriba, z).normalize();
    const y = arriba.crossVectors(z, x);
    const M = s.tm || (s.tm = new T.Matrix4());
    M.makeBasis(x, y, z);
    s.vista.quaternion.setFromRotationMatrix(M);
    // la palma está un poco más allá de la muñeca (el hueso de la mano empieza en la muñeca)
    s.vista.position.copy(h).addScaledVector(dir, 0.05);
  },

  // poses de reposo en 1ª persona por estilo: [empuñadura x, y, z, dirección x, y, z, giro] (espacio de la cámara)
  POSES_FP: {
      corta: [0.2, -0.24, -0.32, -0.5, 0.55, -0.67, 0],
      larga: [0.21, -0.3, -0.34, -0.22, 0.55, -0.8, 0],   // reposo y ataque: de canto (la guardia enseña la cara plana)
      dosManos: [0.24, -0.36, -0.36, -0.45, 0.62, -0.64, Math.PI],   // girada: el filo hacia fuera, no hacia ti
      lanza: [0.22, -0.3, -0.25, -0.25, 0.22, -0.94, 0],
      espadon: [0.13, -0.32, -0.34, -0.12, 0.78, -0.62, 0],   // ⚔ a dos manos: más al centro y la hoja hacia arriba
      },

  /* ⚔ 1ª persona, cuerpo a cuerpo (como Minecraft): la empuñadura abajo a la derecha, casi en la esquina, y el arma
     en diagonal hacia arriba a la izquierda sin pasar del centro. Golpe propio de cada estilo; guardia = cruzada abajo.
     Pose = [empuñadura x, y, z, dirección del arma x, y, z, giro sobre su eje] en el espacio de la cámara.
     Posición X/Y/Z del arma (Aspecto) se suman como ajuste sobre esto (sus valores de serie = sin cambio). */
  _fpCuerpo(j, s, d, m, bx, by, bz, bq) {
    const T = s.T, est = FORJA.Escena.estiloCuerpo(d) || 'corta';
    const REPOSO = this.POSES_FP[est];
    // guardia: la de Minecraft 1.8 para la espada (hoja cruzada inclinada hacia arriba, cara plana a la vista, cerca del centro)
    const GUARDIA = est === 'larga' || est === 'espadon' ? [0.13, -0.21, -0.3, -0.72, 0.38, -0.58, Math.PI / 2]
      : est === 'dosManos' ? [0.2, -0.2, -0.33, -0.6, 0.12, -0.79, Math.PI] : [0.2, -0.2, -0.33, -0.6, 0.12, -0.79, 0];
    const mez = (A, B, t) => A.map((v, i) => v + (B[i] - v) * t), suave = (t) => t * t * (3 - 2 * t);
    let P = mez(REPOSO, GUARDIA, bq);
    const tot = s.tGolpeTot || 0.3, t = s.tGolpe > 0 ? 1 - s.tGolpe / tot : -1;
    if (t >= 0) {
      const sw = Math.sin(Math.PI * t);
      if (est === 'corta') P = mez(REPOSO, [0.12, -0.18, -0.5, -0.15, 0.1, -0.98, 0], sw);            // estocada al frente
      else if (est === 'lanza') P = mez(REPOSO, [0.18, -0.25, -0.6, -0.2, 0.15, -0.97, 0], sw);       // empujón largo
      else if (est === 'larga') {                                                                         // tajo: arriba der. → abajo izq.
        // tajo diagonal suave (no de lado): sube a la derecha y baja hacia abajo-izquierda delante
        const ARR = [0.26, -0.12, -0.3, -0.1, 0.85, -0.5, 0], ABA = [0.03, -0.32, -0.42, -0.35, -0.1, -0.93, 0];
        P = t < 0.2 ? mez(REPOSO, ARR, suave(t / 0.2)) : t < 0.55 ? mez(ARR, ABA, suave((t - 0.2) / 0.35)) : mez(ABA, REPOSO, suave((t - 0.55) / 0.45));
      } else {                                                                                            // dos manos: carga atrás y baja de golpe
        const CARGA = [0.25, -0.15, -0.25, -0.1, 0.9, 0.4, Math.PI], GOLPE = [0.05, -0.3, -0.5, -0.15, -0.4, -0.9, Math.PI];
        P = t < 0.4 ? mez(REPOSO, CARGA, suave(t / 0.4)) : t < 0.62 ? mez(CARGA, GOLPE, suave((t - 0.4) / 0.22)) : mez(GOLPE, REPOSO, suave((t - 0.62) / 0.38));
      }
    }
    m.position.set(P[0] + bx + (d.posX - 0.22), P[1] + by + (d.posY + 0.2), P[2] + bz + (d.posZ + 0.42));
    // orientación: −Z del arma = dirección; su "arriba" (cabeza del hacha, filo) hacia arriba de la pantalla
    const zA = (s.fz || (s.fz = new T.Vector3())).set(-P[3], -P[4], -P[5]).normalize();
    const yA = (s.fy || (s.fy = new T.Vector3())).set(0, 1, 0).addScaledVector(zA, -zA.y);
    if (yA.lengthSq() < 1e-4) yA.set(0, 0, 1); else yA.normalize();
    const xA = (s.fx || (s.fx = new T.Vector3())).crossVectors(yA, zA);
    m.quaternion.setFromRotationMatrix((s.fm || (s.fm = new T.Matrix4())).makeBasis(xA, yA, zA));
    if (P[6]) m.rotateZ(P[6]);
    // ajuste del creador (Aspecto ▸ Girar en X / Y / Z), sobre los ejes del propio arma
    const G = Math.PI / 180;
    if (d.fpGiroX) m.rotateX(d.fpGiroX * G);
    if (d.fpGiroY) m.rotateY(d.fpGiroY * G);
    if (d.fpGiroZ) m.rotateZ(d.fpGiroZ * G);
  },

  /* ---------- 🛡 Escudo de mano (medieval / antimotines) ---------- */
  _nuevoEscudoMano(estilo, aguante, color) {
    const max = Math.max(1, aguante || 120);
    return { estilo: estilo === 'antimotines' ? 'antimotines' : 'medieval', vida: max, max, color: color || '' };
  },
  // Figura retro (cajas y un octógono): una para la vista en 1ª persona y otra para el mundo (3ª)
  _figuraEscudoMano(s, estilo, color) {
    const T = s.T, R = FORJA.Render, g = new T.Group();
    const mat = (c, extra = {}) => R.hacerRetro(new T.MeshLambertMaterial({ color: c, flatShading: true, ...extra }));
    if (estilo === 'antimotines') {
      // panel alto transparente con marco oscuro y una franja
      const vidrio = mat(color || '#9fc4e8', { transparent: true, opacity: 0.38, depthWrite: false, side: T.DoubleSide });
      const marco = mat('#2a2f38');
      const panel = new T.Mesh(new T.BoxGeometry(0.46, 0.78, 0.02), vidrio); g.add(panel);
      for (const [w, h, x, y] of [[0.5, 0.04, 0, 0.39], [0.5, 0.04, 0, -0.39], [0.04, 0.8, 0.23, 0], [0.04, 0.8, -0.23, 0], [0.46, 0.05, 0, 0.12]]) {
        const b = new T.Mesh(new T.BoxGeometry(w, h, 0.03), marco); b.position.set(x, y, 0); g.add(b);
      }
      const asa = new T.Mesh(new T.BoxGeometry(0.06, 0.16, 0.06), marco); asa.position.set(0, 0, 0.05); g.add(asa);
    } else {
      // escudo redondo de madera (octógono) con borde de hierro y umbo en el centro
      const madera = mat(color || '#7a5230'), hierro = mat('#8a8a90');
      const disco = new T.Mesh(new T.CylinderGeometry(0.3, 0.3, 0.04, 8).rotateX(Math.PI / 2), madera); g.add(disco);
      const borde = new T.Mesh(new T.TorusGeometry(0.31, 0.035, 4, 8).rotateZ(Math.PI / 8), hierro); g.add(borde);   // aro de hierro (8 lados)
      const umbo = new T.Mesh(new T.CylinderGeometry(0.06, 0.08, 0.06, 6).rotateX(Math.PI / 2), hierro); umbo.position.z = -0.04; g.add(umbo);
      for (const y of [-0.12, 0.12]) { const t = new T.Mesh(new T.BoxGeometry(0.56, 0.035, 0.05), hierro); t.position.set(0, y, -0.012); g.add(t); }
      const asa = new T.Mesh(new T.BoxGeometry(0.05, 0.16, 0.05), mat('#3a2416')); asa.position.set(0, 0, 0.045); g.add(asa);   // asa por detrás
    }
    g.traverse((o) => { if (o.isMesh) { o.castShadow = false; o.userData.sinSombra = true; } });
    return g;
  },
  _colocarEscudoMano(j, p, s, a, dt) {
    const M = j.escudoMano, T = s.T;
    s.escMano = s.escMano || {};
    const clave = M ? M.estilo + '|' + M.color : '';
    if (s.escClave !== clave) {
      for (const g of Object.values(s.escMano)) if (g.parent) g.parent.remove(g);
      s.escMano = {};
      if (M) { s.escMano.fps = this._figuraEscudoMano(s, M.estilo, M.color); s.escMano.tps = this._figuraEscudoMano(s, M.estilo, M.color); }
      s.escClave = clave;
    }
    // barra en pantalla mientras lo tienes
    if (!s.hudEsc && FORJA.Hud) { s.hudEsc = FORJA.Hud.pieza(j.juego, 'fh-escudomano', '<span>🛡</span><span class="fh-caja" style="display:inline-block;width:5em;height:.5em;border:1px solid #000;background:#222;margin:0 .4em;vertical-align:middle"><i style="display:block;height:100%;background:#d9c08a;width:100%"></i></span><span class="fh-n"></span>'); s.hudEsc.style.textShadow = '.1em .1em 0 #000'; }
    if (s.hudEsc) {
      const txt = M ? Math.ceil(M.vida) + '|' + M.max : '';
      if (txt !== s.hudEscTxt) {
        s.hudEscTxt = txt;
        s.hudEsc.style.display = M ? '' : 'none';
        if (M) { s.hudEsc.querySelector('i').style.width = (100 * M.vida / M.max).toFixed(0) + '%'; s.hudEsc.querySelector('.fh-n').textContent = Math.ceil(M.vida); }
      }
    }
    if (!M || j.muerto) return;
    const dos = (a && (this._dosManos(a.def) || this._dosManosCuerpo(a.def))) || j.escudoGuardado;   // a dos manos o guardado: a la espalda
    s.cubrirV = (s.cubrirV || 0) + ((j.cubriendo ? 1 : 0) - (s.cubrirV || 0)) * Math.min(1, dt * 12);
    s.golpeEscudo = Math.max(0, (s.golpeEscudo || 0) - dt * 6);
    const k = s.cubrirV, sac = s.golpeEscudo * 0.03;
    const fps = s.escMano.fps, tps = s.escMano.tps;
    if (j.modoCamara === 'fps') {
      if (tps.parent) tps.parent.remove(tps);
      if (dos) { if (fps.parent) fps.parent.remove(fps); return; }   // a dos manos: guardado (no se ve en 1ª)
      if (fps.parent !== s.vista) s.vista.add(fps);
      // abajo a la izquierda; al cubrirse sube al centro delante de la cámara
      // (cubriendo queda abajo a la izquierda del centro: tapa el cuerpo pero se sigue viendo al frente)
      const anti = M.estilo === 'antimotines';
      fps.scale.setScalar(anti ? 0.85 : 0.72);
      fps.position.set(-0.36 + 0.16 * k, -0.36 + (anti ? 0.2 : 0.13) * k + sac, -0.55 + 0.04 * k + sac);
      fps.rotation.set(0.15 - 0.12 * k, 0.55 - 0.42 * k, 0.12 - 0.1 * k);
      fps.visible = true;
    } else {
      if (fps.parent) fps.parent.remove(fps);
      if (tps.parent !== j.escena) j.escena.add(tps);
      const c = j.cuerpo, alto = c.altura || 1.8;
      // hacia dónde mira el PERSONAJE (en 3ª persona puede girar distinto que la cámara); sin modelo, la cámara
      const adel = (s.eV1 || (s.eV1 = new T.Vector3())).set(-Math.sin(j.yaw), 0, -Math.cos(j.yaw));
      if (j.modelo) {
        j.modelo.updateMatrixWorld(true);
        const f = (s.eV12 || (s.eV12 = new T.Vector3())).set(0, 0, 1).applyQuaternion(j.modelo.getWorldQuaternion(s.eQ || (s.eQ = new T.Quaternion())));
        f.y = 0;
        if (f.lengthSq() > 1e-6) adel.copy(f.normalize());
      }
      const yaw = Math.atan2(-adel.x, -adel.z);
      const base = (s.eV2 || (s.eV2 = new T.Vector3())).set(c.pie.x, c.visY + alto * 0.55, c.pie.z);
      // montado, el personaje no está en sus pies (va en el asiento): la base sale del modelo
      if (j.modelo) { const mp = j.modelo.getWorldPosition(s.eV13 || (s.eV13 = new T.Vector3())); base.set(mp.x, mp.y + alto * 0.55, mp.z); }
      const mano = !dos && j.modelo && this._mano(j, s) ? this._otraMano(j, s) : null;
      tps.scale.setScalar(M.estilo === 'antimotines' ? 1.05 : 0.9);
      if (dos) {
        // a dos manos: colgado a la espalda
        // colgado a la espalda: la cara mira hacia atrás, un poco inclinado
        tps.position.copy(base).addScaledVector(adel, -0.2);
        tps.position.y += alto * 0.05;
        tps.rotation.set(0.12, yaw + Math.PI, 0);
      } else if (mano) {
        // ✋ sujeto al antebrazo de la mano libre: el brazo pasa por detrás del escudo y la cara mira hacia fuera
        // (hacia el costado). Cubriendo, sube delante del pecho mirando al frente.
        const h = mano.getWorldPosition(s.eV3 || (s.eV3 = new T.Vector3()));
        const brazo = (s.eV4 || (s.eV4 = new T.Vector3())).copy(h).sub((mano.parent || mano).getWorldPosition(s.eV5 || (s.eV5 = new T.Vector3())));
        if (brazo.lengthSq() < 1e-8) brazo.set(0, -1, 0); else brazo.normalize();
        // hacia fuera = el costado de la mano libre (un poco hacia delante, como se lleva un escudo en reposo)
        const fuera = (s.eV6 || (s.eV6 = new T.Vector3())).set(adel.z, 0, -adel.x);   // la izquierda del personaje
        if ((h.x - base.x) * fuera.x + (h.z - base.z) * fuera.z < 0) fuera.negate();   // la mano libre es la derecha
        fuera.addScaledVector(adel, 0.35).normalize();
        // la cara: hacia fuera en reposo, al frente cubriendo
        const n = fuera.multiplyScalar(1 - k).addScaledVector(adel, k);
        // el "arriba" del escudo sigue al antebrazo; cubriendo, vertical
        const arriba = (s.eV7 || (s.eV7 = new T.Vector3())).copy(brazo).negate().multiplyScalar(1 - k);
        arriba.y += k;
        arriba.addScaledVector(n.normalize(), -arriba.dot(n));
        if (arriba.lengthSq() < 1e-6) arriba.set(0, 1, 0); else arriba.normalize();
        const z = (s.eV8 || (s.eV8 = new T.Vector3())).copy(n).negate();   // la cara del escudo es su −Z
        const x = (s.eV9 || (s.eV9 = new T.Vector3())).crossVectors(arriba, z).normalize();
        const y = arriba.crossVectors(z, x);
        tps.quaternion.setFromRotationMatrix((s.eM || (s.eM = new T.Matrix4())).makeBasis(x, y, z));
        // en el antebrazo (un poco antes de la muñeca) y apenas por fuera; cubriendo, delante del pecho
        const enMano = (s.eV10 || (s.eV10 = new T.Vector3())).copy(h).addScaledVector(brazo, -0.08).addScaledVector(n, 0.06);
        const pecho = (s.eV11 || (s.eV11 = new T.Vector3())).copy(base).addScaledVector(adel, 0.38);
        // el muñeco del motor sube el brazo al cubrirse (modelo.js): el escudo sigue a la mano. Un modelo importado
        // no tiene esa pose: cubriendo, el escudo pasa delante del pecho
        tps.position.copy(enMano);
        if (!j.modelo.userData.figura) tps.position.lerp(pecho, k);
      } else {
        // sin modelo con huesos: a la izquierda; cubriendo, delante del pecho
        const izq = (s.eV3 || (s.eV3 = new T.Vector3())).set(adel.z, 0, -adel.x);
        tps.position.copy(base).addScaledVector(izq, 0.32 * (1 - k) + 0.08 * k).addScaledVector(adel, 0.12 + 0.3 * k);
        tps.rotation.set(0, yaw + (1 - k) * Math.PI / 2, 0);
      }
      tps.visible = true;
    }
  },

  // ¿arma cuerpo a cuerpo a dos manos? (hacha, espada a dos manos, lanza): el escudo no cabe en la mano
  _dosManosCuerpo(d) {
    if (!d || d.tipo !== 'cuerpo') return false;
    const e = FORJA.Escena.estiloCuerpo(d);
    return e === 'dosManos' || e === 'espadon' || e === 'lanza';
  },

  // ¿arma a dos manos? (rifle, escopeta, rayo, al hombro): misma regla que la postura del módulo Modelo
  _dosManos(d) {
    if (!d || d.tipo === 'cuerpo') return false;
    if (d.magia && d.magia !== 'no') return d.magia === 'baston';   // 🪄 varita y libro a una mano
    const p = d.postura3p || 'auto';
    if (p === 'rifle' || p === 'hombro') return true;
    if (p !== 'auto') return false;
    return d.perdigones > 1 || d.automatica || d.tipo === 'rayo' || d.tipo === 'proyectil' ||
      /rifle|escopeta|fusil|ak|m16|ametralladora|subfusil|ballesta|l[aá]ser|plasma|francotirador|carabina|cohete|misil|bazuca|rpg/i.test(d.nombre || '');
  },

  // la otra mano (la que sujeta el cañón en las armas largas)
  _otraMano(j, s) {
    if (s.otraDe !== j.modelo || s.otraIzq !== s.manoIzq) {
      s.otraDe = j.modelo; s.otraIzq = s.manoIzq; s.otra = null;
      const re = s.manoIzq ? /^(hand_?r|mano_?d|righthand|hand\.r|mixamorig:righthand)$/i : /^(hand_?l|mano_?i|lefthand|hand\.l|mixamorig:lefthand)$/i;
      if (j.modelo) j.modelo.traverse((o) => { if (!s.otra && re.test(o.name)) s.otra = o; });
    }
    return s.otra;
  },

  _cambiar(j, s, i) {
    if (!j.armas.length) return;
    i = ((i % j.armas.length) + j.armas.length) % j.armas.length;
    if (i === j.armaActual && s.cambio <= 0) return;
    j.armaActual = i;
    s.cambio = j.props('armas').animCambio === false ? 0 : 0.35;
    s.recargando = 0;
  },

  // la siguiente arma que se pueda usar (cuerpo a cuerpo, infinita o con balas)
  _cambiarConBalas(j, s) {
    const n = j.armas.length;
    for (let k = 1; k < n; k++) {
      const i = (j.armaActual + k) % n, a = j.armas[i];
      if (a.def.tipo === 'cuerpo' || a.def.infinita || a.cargador > 0 || this._res(j, s, a) > 0) { this._cambiar(j, s, i); return true; }
    }
    return false;
  },

  _recargar(j, s, a) {
    const d = a.def;
    if (d.cargador <= 0 || a.cargador >= d.cargador || s.recargando > 0) return;
    if (!d.infinita && this._res(j, s, a) <= 0) return;
    s.recargando = d.recarga;
    FORJA.emitir('arma-recarga', { jugador: j, arma: d });
    if (d.sonidoRecarga) FORJA.Audio.efecto(d.sonidoRecarga);
    else FORJA.Audio.sintetico('recarga');
  },

  entrada(j, p, s, dt) {
    const E = FORJA.Entrada;
    if (j.muerto || !j.armas.length) return;
    if (j.montado && !j.montado.p.disparar) return;   // 🐎 vehículo sin armas
    if (E.pulsado('arma_siguiente')) this._cambiar(j, s, j.armaActual + 1);
    if (E.pulsado('arma_anterior')) this._cambiar(j, s, j.armaActual - 1);
    if (E.teclasCuadro && !(j.juego.aliados && j.juego.aliados.menu)) for (let n = 1; n <= 9; n++) if (E.teclasCuadro.has('Digit' + n) && n <= j.armas.length) this._cambiar(j, s, n - 1);
    const a = this._actual(j);
    if (!a) return;
    // clic derecho: apuntar (armas de fuego) · con cuerpo a cuerpo, apuntar, bloquear o las dos cosas (lo elige el arma)
    // ⚔ con el módulo Combate el clic derecho puede ser solo Apuntar, Fijar objetivo o Bloquear (y "Bloquear" tiene su tecla)
    const C = j.estados.combate ? j.props('combate') : null, cd = (C && C.clicDerecho) || 'arma';
    const libre = s.cambio <= 0.1;
    const der = E.mantenido('apuntar') && libre && (cd === 'arma' || cd === 'apuntar' || cd === 'bloquear');
    const teclaBloq = !!C && E.mantenido('bloquear') && libre;
    if (a.def.tipo === 'cuerpo') {
      const modo = cd === 'arma' ? (a.def.clicDerecho || 'ambos') : cd === 'apuntar' ? 'apuntar' : 'bloquear';
      s.quiereApuntar = der && modo !== 'bloquear';
      const bloq = (der && modo !== 'apuntar') || teclaBloq;
      const golpeando = (s.tGolpe || 0) > 0;
      if (bloq && !j.bloqueando && !golpeando) s.tBloq = s.trasGolpe ? 99 : 0;   // recién levantada la guardia: ventana de parry (no al volver de un golpe)
      s.trasGolpe = golpeando;
      j.bloqueando = bloq && !golpeando;
      s.quiereApuntar = s.quiereApuntar && !golpeando;   // golpeando: se quita la postura de apuntar
    } else { s.quiereApuntar = der && cd !== 'bloquear'; j.bloqueando = false; }
    // 🛡 guardar / sacar el escudo de mano (tecla N): guardado va colgado a la espalda y no cubre
    if (j.escudoMano && E.pulsado('escudo')) { j.escudoGuardado = !j.escudoGuardado; FORJA.Audio.sintetico('recoger', { volumen: 0.5, tono: j.escudoGuardado ? 0.7 : 1.1 }); }
    if (!j.escudoMano) j.escudoGuardado = false;
    // 🛡 con escudo de mano y un arma de una mano, el clic derecho cubre en vez de apuntar / guardia
    j.cubriendo = false;
    if (j.escudoMano && !j.escudoGuardado && !this._dosManos(a.def) && !this._dosManosCuerpo(a.def) && !j.montado) {
      j.cubriendo = (der && cd !== 'apuntar') || teclaBloq;
      if (j.cubriendo) { s.quiereApuntar = false; j.bloqueando = false; j.modVelocidad *= p.escudoManoLento ?? 0.6; }
    }
    if (E.pulsado('recargar')) this._recargar(j, s, a);
    // ⚡ rayo continuo: mientras se mantiene (lo hace _rayo cada cuadro, con la cámara ya colocada)
    // 🎯 estilo Resident Evil: sin apuntar, las armas de fuego no disparan
    const apuntaYa = a.def.tipo === 'cuerpo' ? !p.soloApuntandoCuerpo || der : !p.soloApuntando || (s.quiereApuntar && j.apuntando > 0.5);
    if (a.def.tipo === 'rayo') { s.rayoQuiere = apuntaYa && E.mantenido('atacar') && s.recargando <= 0 && s.cambio <= 0.1; return; }
    if (!apuntaYa) return;
    s.rayoQuiere = false;
    if (j.ataqueTomado) { j.ataqueTomado = false; return; }   // ⚔ el módulo Combate ya usó este clic (ataque en caída…)
    let quiere = a.def.automatica ? E.mantenido('atacar') : E.pulsado('atacar');
    // ⚔ cuerpo a cuerpo: un clic hecho mientras aún dura el golpe anterior se guarda un momento y sale en cuanto se pueda
    // (así los combos no se pierden por pulsar un poco antes)
    if (a.def.tipo === 'cuerpo' && !a.def.automatica) {
      if (quiere && s.cd > 0) { s.colaGolpe = 0.4; quiere = false; }
      else if (!quiere && s.colaGolpe > 0) { s.colaGolpe -= dt; if (s.cd <= 0) { quiere = true; s.colaGolpe = 0; } }
    }   // con la guardia puesta también se golpea: la guardia se quita mientras dura el golpe
    if (quiere && s.cd <= 0 && s.recargando <= 0 && s.cambio <= 0.1) this._disparar(j, p, s, a);
  },

  fisica(j, p, s, dt) {
    if (s.cd > 0) s.cd -= dt;
    // ✦ munición que se recarga sola (maná)
    for (const m of s.tipos.values()) if (m.regenera > 0 && j.municion[m.id] < s.maxDe(m)) j.municion[m.id] = Math.min(s.maxDe(m), j.municion[m.id] + m.regenera * dt);
    if (j.bloqueando) s.tBloq = (s.tBloq || 0) + dt;
    if (j.cubriendo) s.tCubre = (s.tCubre || 0) + dt; else s.tCubre = 0;   // 🛡 tiempo desde que se levantó el escudo
    if (s.tGolpe > 0) s.tGolpe -= dt;
    if (s.cambio > 0) s.cambio -= dt;
    if (s.recargando > 0) {
      s.recargando -= dt;
      if (s.recargando <= 0) {
        const a = this._actual(j), d = a.def;
        const falta = d.cargador - a.cargador;
        const toma = d.infinita ? falta : Math.min(falta, this._res(j, s, a));
        a.cargador += toma;
        if (!d.infinita) this._ponerRes(j, s, a, this._res(j, s, a) - toma);
      }
    }
  },

  /* ---------- Disparar ---------- */
  _disparar(j, p, s, a) {
    const d = a.def, T = s.T;
    // munición
    if (d.tipo !== 'cuerpo') {
      if (d.cargador > 0) {
        if (a.cargador <= 0) {
          if (p.autoRecarga) this._recargar(j, s, a);
          if (s.recargando <= 0) {
            FORJA.Audio.sintetico('vacio');
            if (p.cambiarSinBalas && this._res(j, s, a) <= 0) this._cambiarConBalas(j, s);
          }
          s.cd = 0.25;
          return;
        }
        a.cargador--;
      } else if (!d.infinita) {
        const g = d.gasto > 0 ? d.gasto : 1;   // ✦ hechizos: maná por lanzamiento
        if (this._res(j, s, a) < g) {
          FORJA.Audio.sintetico('vacio');
          if (p.cambiarSinBalas) this._cambiarConBalas(j, s);
          s.cd = 0.25;
          return;
        }
        this._ponerRes(j, s, a, this._res(j, s, a) - g);
      }
    }
    s.cd = 1 / Math.max(0.1, d.cadencia);
    // ⚔ golpe del módulo Combate (paso del combo, cargado, en caída, contraataque…): cambia daño, alcance, animación
    let mod = null;
    if (d.tipo === 'cuerpo') { mod = s.golpeMod || (j.alGolpear ? j.alGolpear(d) : null); s.golpeMod = null; if (mod && mod.cadencia) s.cd /= mod.cadencia; }
    s.retro = 1;
    s.marcasDisparo = 0;   // escopeta: solo los 3 primeros perdigones que dan en pared dejan agujero
    // cargador vacío: recarga sola en cuanto pueda
    if (p.autoRecarga && d.cargador > 0 && a.cargador === 0) setTimeout(() => this._recargar(j, s, a), s.cd * 1000);
    j.pitch += (d.retroceso || 0) * FORJA.DEG * (1 - 0.5 * j.apuntando);
    if (d.sonido) FORJA.Audio.efecto(d.sonido, { tono: 0.95 + Math.random() * 0.1 });
    else FORJA.Audio.sintetico(d.tipo === 'cuerpo' ? 'golpe' : d.tipo === 'proyectil' ? 'aterrizar' : 'disparo', { tono: 0.9 + Math.random() * 0.2 });

    const cam = j.camara, c = j.cuerpo;
    const dirCam = cam.getWorldDirection(s.v1);
    // 📷 cámaras fijas: se dispara hacia donde mira el cuerpo, desde el pecho; con "apuntar solo", al enemigo de delante
    const pecho = j.camFija ? new s.T.Vector3(c.pie.x, c.visY + c.altura * 0.7, c.pie.z) : null;
    if (pecho) { dirCam.set(-Math.sin(j.yaw), 0, -Math.cos(j.yaw)); if (j.autoApuntar) this._autoApuntar(j, pecho, dirCam, d.alcance); }
    const boca = this._boca(j, s, s.v2);   // de dónde sale (cañón)
    // 1ª persona pegado a una pared: el cañón queda "dentro" (el arma se dibuja encima de todo).
    // Entonces el cohete y el fogonazo salen justo antes de la pared, no del otro lado.
    if (j.modoCamara === 'fps') {
      const v = s.v3.copy(boca).sub(cam.position), largo = v.length();
      if (largo > 0.001) {
        v.divideScalar(largo);
        const pared = j.mundo.rayo(cam.position.x, cam.position.y, cam.position.z, v.x, v.y, v.z, largo);
        if (pared) boca.copy(cam.position).addScaledVector(v, Math.max(0, pared.t - 0.05));
      }
    }
    FORJA.emitir('disparo', { jugador: j, arma: d, punto: boca, golpe: mod });   // los enemigos podrán "oírlo"

    if (d.tipo === 'escudo') { this._escudo(j, s, d); return; }   // 🛡 hechizo escudo: sin fogonazo ni balas
    if (d.tipo === 'area') {   // ✸ ataque de área: la esfera sale del jugador (motor/area.js)
      const dn = this._dano(s, d, d.dano);
      if (FORJA.Area) FORJA.Area.lanzar(j.juego, j, { forma: d.areaForma || 'onda', radio: d.areaRadio || 5, dano: dn.cantidad, tipoDano: dn.tipo, empuje: d.areaEmpuje ?? 8,
        crecer: d.areaCrecer || 0.35, dura: d.areaDura || 4, estilo: d.areaEstilo || 'ondas', color: d.areaColor || '#c08cff', pulso: !!d.areaPulso, arma: d });
      if (d.areaForma === 'aura') s.cd = Math.max(s.cd, d.areaDura || 4);   // el aura no se encima consigo misma
      return;
    }
    if (d.tipo === 'cuerpo') {
      s.tGolpe = s.tGolpeTot = ({ corta: 0.25, larga: 0.32, dosManos: 0.7, espadon: 0.55, lanza: 0.35 }[(mod && mod.est) || FORJA.Escena.estiloCuerpo(d) || 'corta'] || 0.3) * ((mod && mod.dur) || 1);
      j.bloqueando = false;
      // ⚡ embestida (atacar corriendo): un empujón hacia delante
      if (mod && mod.avance) { j.cuerpo.velocidad.x += -Math.sin(j.yaw) * mod.avance; j.cuerpo.velocidad.z += -Math.cos(j.yaw) * mod.avance; }
      this._golpe(j, s, d, mod);
      return;
    }

    // fogonazo
    s.flash.position.copy(boca);
    s.flash.material.color.set(d.fogonazo || '#ffd27a');
    const tamF = d.tamFogonazo ?? 1;
    s.flash.scale.setScalar((0.35 + Math.random() * 0.15) * tamF);
    s.flash.visible = tamF > 0;
    s.flashT = 0.05;

    const n = Math.max(1, Math.round(d.perdigones || 1));
    const disp = (d.dispersion || 0) * FORJA.DEG * (1 - 0.6 * j.apuntando);
    // en 3ª persona el rayo de la cámara empieza a la altura del jugador (lo de atrás no cuenta)
    const saltoTps = j.modoCamara === 'tps' && !pecho ? cam.position.distanceTo(s.v3.set(c.pie.x, c.visY + 1.2, c.pie.z)) : 0;
    for (let i = 0; i < n; i++) {
      const dir = s.v3.copy(dirCam);
      if (disp > 0) {
        // cono aleatorio alrededor de la mira
        const ang = Math.random() * Math.PI * 2, r = Math.sqrt(Math.random()) * Math.tan(disp);
        const ejeX = new T.Vector3().crossVectors(dir, cam.up).normalize();
        const ejeY = new T.Vector3().crossVectors(ejeX, dir).normalize();
        dir.addScaledVector(ejeX, Math.cos(ang) * r).addScaledVector(ejeY, Math.sin(ang) * r).normalize();
      }
      // punto al que apunta la mira
      const oriCam = new T.Vector3().copy(pecho || cam.position).addScaledVector(dir, saltoTps);
      const golpe = this._trazar(j, s, oriCam, dir, d.alcance);
      const meta = golpe ? golpe.punto : oriCam.clone().addScaledVector(dir, d.alcance);
      if (d.tipo === 'proyectil') {
        this._lanzar(s, d, boca, meta);
      } else if (j.modoCamara === 'tps' && golpe) {
        // 3ª persona: la bala va del cañón al punto; si algo está en medio, pega ahí
        const v = meta.clone().sub(boca), largo = v.length();
        const real = largo > 0.01 ? this._trazar(j, s, boca, v.divideScalar(largo), largo + 0.05) : golpe;
        this._impacto(j, s, d, real || golpe);
      } else if (golpe) {
        this._impacto(j, s, d, golpe);
      }
    }
  },

  // 🎯 apuntar solo (cámaras fijas, como RE): el enemigo vivo más cercano dentro de 50° de tu frente y a la vista
  _autoApuntar(j, ori, dir, alcance) {
    const EN = j.juego.enemigos;
    if (!EN) return;
    let mejor = null, md = Math.min(alcance || 40, 40);
    for (const E of EN.lista) {
      if (E.muerto || E.reserva) continue;
      const x = E.cuerpo.pie.x - ori.x, y = E.cuerpo.pie.y + E.c.altura * 0.6 - ori.y, z = E.cuerpo.pie.z - ori.z, d = Math.hypot(x, y, z);
      if (d > md || d < 0.01 || (x * dir.x + z * dir.z) / Math.hypot(x, z) < 0.64) continue;
      if (j.mundo.rayo(ori.x, ori.y, ori.z, x / d, y / d, z / d, d - E.c.radio)) continue;
      md = d; mejor = [x / d, y / d, z / d];
    }
    if (mejor) dir.set(mejor[0], mejor[1], mejor[2]);
  },

  // Dónde está el cañón en el mundo
  _boca(j, s, out) {
    const cam = j.camara, c = j.cuerpo, d = this._actual(j).def;
    const m = s.modelos && s.modelos.get(d.id), mz = m && m.visible && m.parent === s.vista && m.userData.muzzle;
    if (mz) {
      // 🔥 pegada al cañón: la boca del modelo del arma tal como está colocado ahora
      m.updateMatrix();
      out.copy(mz).applyMatrix4(m.matrix);   // en el espacio de la "vista" del arma
      if (j.modoCamara === 'fps') {
        // la vista va pegada a la cámara y se dibuja en primer plano con el campo de visión normal; el fogonazo va en
        // el mundo con el del zoom: se compensa para que caiga en la boca en pantalla
        const z = s.fov0 && cam.fov ? Math.tan(cam.fov * Math.PI / 360) / Math.tan(s.fov0 * Math.PI / 360) : 1;
        out.x *= z; out.y *= z;
        return out.applyQuaternion(cam.quaternion).add(cam.position);
      }
      s.vista.updateMatrixWorld();
      return out.applyMatrix4(s.vista.matrixWorld);
    }
    if (j.modoCamara === 'fps') {
      // sin modelo conocido: aproximada, siguiendo al arma al apuntar
      const ap = d.tipo === 'cuerpo' ? 0 : j.apuntando || 0;
      const z = s.fov0 && cam.fov ? Math.tan(cam.fov * Math.PI / 360) / Math.tan(s.fov0 * Math.PI / 360) : 1;
      return out.set(d.posX * (1 - ap) * 0.8 * z, (d.posY + ap * 0.07) * 0.6 * z, d.posZ - 0.15).applyQuaternion(cam.quaternion).add(cam.position);
    }
    // 3ª persona sin arma en la mano: a la derecha del pecho, hacia donde mira la cámara
    const sin = Math.sin(j.yaw), cos = Math.cos(j.yaw);
    return out.set(c.pie.x + cos * 0.3 - sin * 0.45, c.visY + c.altura * 0.7, c.pie.z - sin * 0.3 - cos * 0.45);
  },

  /* Rayo contra el nivel (BVH) y contra los objetos con Vida. Devuelve { punto, normal, objetivo } o null */
  _trazar(j, s, ori, dir, alcance) {
    const T = s.T, juego = j.juego, m = juego.mundo;
    let mejor = null;
    const g = m.rayo(ori.x, ori.y, ori.z, dir.x, dir.y, dir.z, alcance);
    if (g) {
      const k = g.k * 3;
      mejor = { t: g.t, punto: ori.clone().addScaledVector(dir, g.t), normal: new T.Vector3(m.nor[k], m.nor[k + 1], m.nor[k + 2]), objetivo: null };
    }
    if (juego.objetivos && juego.objetivos.length) {
      // enemigos (y lo que traiga su propio rayo): cápsula matemática, sin recorrer mallas
      let mallas = null;
      for (const o of juego.objetivos) {
        if (!o.rayo) { (mallas || (mallas = [])).push(o.obj); continue; }
        const h = o.rayo(ori, dir, mejor ? mejor.t + 0.05 : alcance);
        if (h && (!mejor || h.t <= mejor.t + 0.05)) mejor = { t: h.t, punto: h.punto, normal: h.normal, objetivo: o };
      }
      s.ray.set(ori, dir);
      s.ray.far = mejor ? mejor.t + 0.05 : alcance;
      const h = mallas ? s.ray.intersectObjects(mallas, true)[0] : null;
      if (h) {
        let o = h.object;
        while (o && !o.userData.entId) o = o.parent;
        const obj = juego.objetivos.find((x) => x.obj === o);
        if (obj && (!mejor || h.distance <= mejor.t + 0.05)) {
          mejor = { t: h.distance, punto: h.point.clone(), normal: h.face ? h.face.normal.clone().transformDirection(h.object.matrixWorld) : dir.clone().negate(), objetivo: obj };
        }
      }
    }
    return mejor;
  },

  _impacto(j, s, d, h) {
    if (!h) return;
    const dn = this._dano(s, d, d.dano);
    if (h.objetivo) h.objetivo.danar(dn.cantidad, h.punto, { tipo: dn.tipo, arma: d, jugador: j });
    if (h.objetivo && !h.objetivo.esEnemigo && d.agujeros && h.objetivo.obj) {
      // 🛢 barril, caja… con Vida: agujero de bala PEGADO al objeto (se va con él si se rompe o se mueve)
      const m = s.marcas[s.mi];
      s.mi = (s.mi + 1) % s.marcas.length;
      if (m.parent !== j.escena) j.escena.attach(m);
      m.scale.setScalar((d.perdigones || 1) > 1 ? 0.65 : 1);
      m.position.copy(h.punto).addScaledVector(h.normal, 0.01);
      m.lookAt((s.cm || (s.cm = new s.T.Vector3())).copy(h.punto).add(h.normal));
      m.visible = true;
      h.objetivo.obj.attach(m);
    }
    if (h.objetivo && h.objetivo.esEnemigo && s.calcos.length && !h.objetivo.sinSangre) {
      // la sangre salpica DETRÁS: sigue la dirección del disparo hasta la pared; si no hay, al suelo
      // vectores PROPIOS: v1/v2/v3 los está usando el disparo (dirección de la mira, cañón) y la escopeta los necesita
      const dir = (s.cdir || (s.cdir = new s.T.Vector3())).copy(h.punto).sub(j.camara.position).normalize();
      this._calco(j, s, h.punto, dir, 2.5, s.matSangre, 0.35 + Math.random() * 0.35) || this._calco(j, s, h.punto, dir.set(0, -1, 0), 3, s.matSangre, 0.3 + Math.random() * 0.3);
    }
    this._chispa(s, h.punto, h.objetivo ? '#ff6a4a' : dn.color || d.fogonazo || '#ffd27a', 0.25);
    const perd = (d.perdigones || 1) > 1;
    if (!h.objetivo && d.agujeros && (!perd || (s.marcasDisparo = (s.marcasDisparo || 0) + 1) <= 3)) {
      const m = s.marcas[s.mi];
      if (m.parent !== j.escena) j.escena.attach(m);   // reciclada: estaba pegada a un objeto
      m.scale.setScalar(perd ? 0.65 : 1);   // agujero de perdigón: más pequeño
      s.mi = (s.mi + 1) % s.marcas.length;
      m.position.copy(h.punto).addScaledVector(h.normal, 0.01);
      m.lookAt((s.cm || (s.cm = new s.T.Vector3())).copy(h.punto).add(h.normal));   // vector propio: v1 es la dirección del disparo
      m.visible = true;
    }
    FORJA.Audio.sintetico('impacto', { volumen: 0.5 });
  },

  // calcomanías (marcas de bala, sangre, quemaduras) que están SOBRE obj: pegar = se van con la pieza que las toca
  // (hoja de puerta que se mueve); si no, se esconden (el objeto se rompió). Solo pasa en esos momentos.
  _calcosDe(j, s, obj, pegar) {
    if (!obj) return;
    const T = s.T, piezas = [];
    obj.updateMatrixWorld(true);
    obj.traverse((o) => { if (o.isMesh && !o.userData.ayudaEditor) piezas.push({ o, caja: new T.Box3().setFromObject(o).expandByScalar(0.08) }); });
    if (!piezas.length) return;
    const w = s.cw || (s.cw = new T.Vector3());
    for (const m of [...s.marcas, ...(s.calcos || [])]) {
      if (!m.visible || m.parent !== j.escena) continue;
      m.getWorldPosition(w);
      const p = piezas.find((x) => x.caja.containsPoint(w));
      if (!p) continue;
      if (pegar) p.o.attach(m); else m.visible = false;
    }
  },

  // pone una calcomanía donde el rayo (desde, dir, alcance) toca el nivel. Devuelve false si no tocó nada
  _calco(j, s, desde, dir, alcance, mat, tam) {
    const M = j.mundo, g = M && M.rayo(desde.x, desde.y, desde.z, dir.x, dir.y, dir.z, alcance);
    if (!g) return false;
    const k = g.k * 3, n = (s.cn || (s.cn = new s.T.Vector3())).set(M.nor[k], M.nor[k + 1], M.nor[k + 2]);
    const m = s.calcos[s.ki];
    s.ki = (s.ki + 1) % s.calcos.length;
    if (m.parent !== j.escena) j.escena.attach(m);
    m.material = mat;
    m.position.set(desde.x + dir.x * g.t, desde.y + dir.y * g.t, desde.z + dir.z * g.t).addScaledVector(n, 0.012);
    m.lookAt((s.cm || (s.cm = new s.T.Vector3())).copy(m.position).add(n));
    m.rotateZ(Math.random() * Math.PI * 2);
    m.scale.setScalar(tam);
    m.visible = true;
    return true;
  },

  _chispa(s, punto, color, tam) {
    const ch = s.chispas[s.ci];
    s.ci = (s.ci + 1) % s.chispas.length;
    ch.sp.position.copy(punto);
    ch.sp.material.color.set(color);
    ch.sp.scale.setScalar(tam);
    ch.sp.visible = true;
    ch.t = 0.12;
    ch.tam = tam;
  },

  // Cuerpo a cuerpo: todo lo que tenga Vida delante, dentro del alcance (cono de ~60°)
  _golpe(j, s, d, mod) {
    mod = mod || {};
    const c = j.cuerpo, juego = j.juego, alcance = d.alcance + (mod.alcance || 0), cono = mod.cono ?? 0.5;
    const pecho = s.v2.set(c.pie.x, c.visY + c.altura * 0.6, c.pie.z);
    const adelante = s.v3.set(-Math.sin(j.yaw), 0, -Math.cos(j.yaw));
    let pego = false;
    for (const o of [...(juego.objetivos || [])]) {
      let punto;
      if (o.distancia) { punto = new s.T.Vector3(); o.distancia(pecho, punto); }
      else punto = new s.T.Box3().setFromObject(o.obj).clampPoint(pecho, new s.T.Vector3());
      const v = punto.clone().sub(pecho);
      const dist = v.length();
      if (dist > alcance) continue;
      v.y = 0;
      if (dist > 0.3 && v.normalize().dot(adelante) < cono) continue;   // giro: cono −1 = todo alrededor
      const dn = this._dano(s, d, d.dano * (mod.mult || 1));
      o.danar(dn.cantidad, punto, { tipo: dn.tipo, arma: d, jugador: j, golpe: mod.nombre || null, empuje: mod.empuje || 1 });
      // lanzador: lo levanta por los aires · barrido / contra: lo deja aturdido un momento
      const E = o.enemigo;
      if (E && !E.muerto && juego.enemigos) {
        if (mod.lanzar && !E.c.jefe && E.cuerpo && E.cuerpo.velocidad) { E.cuerpo.velocidad.y = mod.lanzar; E.cuerpo.enSuelo = false; }
        if (mod.aturde && E.estado !== 'aturdido') juego.enemigos.aturdir(E, mod.aturde);
      }
      this._chispa(s, punto, '#ff6a4a', 0.3);
      pego = true;
    }
    if (!pego) {
      // ¿pared delante? chispa contra ella
      const g = juego.mundo.rayo(pecho.x, pecho.y, pecho.z, adelante.x, 0, adelante.z, alcance);
      if (g) this._chispa(s, pecho.clone().addScaledVector(adelante, g.t), '#ffffff', 0.18);
    }
  },

  /* ---------- Proyectiles ---------- */
  _lanzar(s, d, desde, hacia) {
    const b = s.balas.find((x) => !x.activa);
    if (!b) return;
    b.activa = true;
    b.def = d;
    b.pos.copy(desde);
    b.vel.copy(hacia).sub(desde).normalize().multiplyScalar(d.velocidad);
    b.recorrido = 0;
    b.sp.material.color.set(d.colorBala || '#ffcc66');
    b.sp.scale.setScalar(0.3);
    b.sp.visible = true;
  },

  _moverBalas(j, s, dt) {
    for (const b of s.balas) {
      if (!b.activa) continue;
      const d = b.def;
      b.vel.y -= (d.gravedadBala || 0) * dt;
      const paso = b.vel.length() * dt;
      const dir = s.v1.copy(b.vel).normalize();
      const h = this._trazar(j, s, b.pos, dir, paso);
      if (h) { this._explotarBala(j, s, b, h); continue; }
      b.pos.addScaledVector(b.vel, dt);
      b.recorrido += paso;
      if (b.recorrido > d.alcance * 1.5) { this._explotarBala(j, s, b, null); continue; }
      b.sp.position.copy(b.pos);
    }
  },

  _explotarBala(j, s, b, h) {
    const d = b.def;
    b.activa = false;
    b.sp.visible = false;
    const punto = h ? h.punto : b.pos.clone();
    if (d.radio > 0) {
      this._explosion(j, s, d, punto);
    } else if (h) {
      this._impacto(j, s, d, h);
    }
  },

  _explosion(j, s, d, punto) {
    // 💥 lo que se ve: la explosión del motor (fuego, chispas, humo y destello; motor/explosiones.js, reciclada).
    // Sin ese archivo, el destello simple de antes
    if (FORJA.Explosiones && j.juego) FORJA.Explosiones.efecto(j.juego, punto, Math.max(1.2, (d.radio || 2) * 0.85), d.colorBala || '#ff8a3a');
    else {
      const ex = s.explosiones[s.ei];
      s.ei = (s.ei + 1) % s.explosiones.length;
      ex.sp.position.copy(punto);
      ex.sp.material.color.set(d.colorBala || '#ff8a3a');
      ex.sp.visible = true;
      ex.t = 0.4;
      ex.radio = d.radio;
    }
    if (s.calcos.length) this._calco(j, s, punto, (s.cdir || (s.cdir = new s.T.Vector3())).set(0, -1, 0), 4, s.matQuema, Math.max(0.8, (d.radio || 2) * 0.9));   // quemadura en el suelo
    FORJA.Audio.sintetico('explosion');
    // daño que baja con la distancia
    for (const o of [...(j.juego.objetivos || [])]) {
      const dist = o.distancia ? o.distancia(punto) : new s.T.Box3().setFromObject(o.obj).distanceToPoint(punto);
      if (dist < d.radio) { const dn = this._dano(s, d, d.dano * (1 - dist / d.radio)); o.danar(dn.cantidad, punto, { tipo: dn.tipo, arma: d, jugador: j }); }
    }
    if (d.danaJugador && j.danar) {
      const c = j.cuerpo;
      const dist = s.v3.set(c.pie.x, c.visY + 0.9, c.pie.z).distanceTo(punto);
      if (dist < d.radio) j.danar(this._dano(s, d, d.dano * 0.6 * (1 - dist / d.radio)).cantidad, 'explosion');
    }
    j.temblor = Math.max(j.temblor || 0, 0.25);
  },

  /* ---------- Cada cuadro: arma visible, efectos y HUD ---------- */
  /* ---------- ⚡ Rayo continuo (1 a 3 rayos en abanico) ----------
     Cada cuadro: un rayo por haz contra el nivel y los enemigos (como las balas) y se estira la figura hasta donde pega.
     El daño se aplica a golpes cada 0,12 s (dano = por segundo, repartido entre los haces). Gasta munición por segundo;
     se recalienta a los duracionMax s y se enfría "recuperacion" s (proporcional si sueltas antes). Sin objetos nuevos:
     las figuras se crean una vez (1-3 haces × 1-3 capas) y se reutilizan. */
  _rayo(j, p, s, a, dt) {
    if (s.rayoEnfria > 0) s.rayoEnfria -= dt;
    const d = a && a.def;
    if (!d || d.tipo !== 'rayo' || j.muerto || !s.rayoQuiere || s.rayoEnfria > 0) { if (s.rayoOn) this._pararRayo(j, s, false); return; }
    if (!this._gastarRayo(j, p, s, a, dt)) { if (s.rayoOn) this._pararRayo(j, s, false); return; }
    if (!s.rayoOn) this._empezarRayo(j, s, d);
    s.rayoT += dt;
    if (d.duracionMax > 0 && s.rayoT >= d.duracionMax) { this._pararRayo(j, s, true); return; }
    const T = s.T, cam = j.camara, c = j.cuerpo, V = s.rayoVis;
    const dirCam = cam.getWorldDirection(new T.Vector3());
    const pecho = j.camFija ? new T.Vector3(c.pie.x, c.visY + c.altura * 0.7, c.pie.z) : null;
    if (pecho) { dirCam.set(-Math.sin(j.yaw), 0, -Math.cos(j.yaw)); if (j.autoApuntar) this._autoApuntar(j, pecho, dirCam, d.alcance); }
    const boca = this._boca(j, s, new T.Vector3());
    if (j.modoCamara === 'fps') {
      const v = new T.Vector3().copy(boca).sub(cam.position), largo = v.length();
      if (largo > 0.001) { v.divideScalar(largo); const pared = j.mundo.rayo(cam.position.x, cam.position.y, cam.position.z, v.x, v.y, v.z, largo); if (pared) boca.copy(cam.position).addScaledVector(v, Math.max(0, pared.t - 0.05)); }
    }
    const saltoTps = j.modoCamara === 'tps' && !pecho ? cam.position.distanceTo(new T.Vector3(c.pie.x, c.visY + 1.2, c.pie.z)) : 0;
    const n = Math.max(1, Math.min(3, Math.round(d.rayos || 1)));
    const sep = (d.separacion ?? 2.5) * FORJA.DEG;
    const eje = new T.Vector3(0, 1, 0).applyQuaternion(cam.quaternion);   // el abanico se abre a los lados de la mira
    s.rayoTick -= dt;
    const golpea = s.rayoTick <= 0;
    if (golpea) s.rayoTick += 0.12;
    // 1ª persona: el cañón está a un palmo de los ojos; el rayo y la esfera se afinan para no tapar la pantalla
    const capas = Math.max(1, Math.min(3, Math.round(d.capas || 3))), ancho = (d.anchoRayo || 0.07) * (j.modoCamara === 'fps' ? 0.4 : 1);
    const radios = capas === 1 ? [0, ancho, 0] : capas === 2 ? [ancho * 0.35, ancho, 0] : [ancho * 0.35, ancho, ancho * 2.6];
    for (let b = 0; b < 3; b++) {
      const figs = V.rayos[b];
      if (b >= n) { for (const m of figs) m.visible = false; continue; }
      const dir = dirCam.clone().applyAxisAngle(eje, sep * (b - (n - 1) * 0.5));
      const ori = new T.Vector3().copy(pecho || cam.position).addScaledVector(dir, saltoTps);
      const mira = this._trazar(j, s, ori, dir, d.alcance);
      const meta = mira ? mira.punto : ori.clone().addScaledVector(dir, d.alcance);
      // del cañón al punto: si algo se mete en medio, el rayo para ahí
      const v = meta.clone().sub(boca), largo = v.length();
      const real = largo > 0.01 ? this._trazar(j, s, boca, v.clone().divideScalar(largo), largo + 0.05) : mira;
      const fin = real ? real.punto : meta, L = Math.max(0.01, fin.distanceTo(boca));
      const q = s.q.setFromUnitVectors(V.arriba, fin.clone().sub(boca).divideScalar(L));
      const temb = 0.85 + Math.random() * 0.3;   // tiembla un poco, estilo de la época
      for (let k = 0; k < 3; k++) {
        const m = figs[k];
        m.visible = radios[k] > 0;
        if (!m.visible) continue;
        m.position.copy(boca); m.quaternion.copy(q); m.scale.set(radios[k] * temb, L, radios[k] * temb);
      }
      if (golpea && real) {
        if (real.objetivo) { const dn = this._dano(s, d, (d.dano * 0.12) / n); real.objetivo.danar(dn.cantidad, real.punto, { tipo: dn.tipo, arma: d, jugador: j }); }
        this._chispa(s, real.punto, real.objetivo ? '#ff6a4a' : d.colorRayo || '#66e6ff', 0.3);
      }
    }
    // la esfera de energía en el cañón
    V.orbe.visible = d.orbe !== false;
    if (V.orbe.visible) { V.orbe.position.copy(boca); V.orbe.scale.setScalar(ancho * (j.modoCamara === 'fps' ? 2.5 : 4) * (0.8 + Math.random() * 0.4)); }
    s.retro = Math.max(s.retro, 0.15 + Math.random() * 0.1);
    // los enemigos lo "oyen" (y el modelo en 3ª persona repite su disparo)
    s.rayoAviso -= dt;
    if (s.rayoAviso <= 0) { s.rayoAviso = 0.5; FORJA.emitir('disparo', { jugador: j, arma: d, punto: boca }); }
  },

  // munición por segundo: false = no queda
  _gastarRayo(j, p, s, a, dt) {
    const d = a.def;
    if (d.infinita || !(d.consumo > 0)) return true;
    const hay = () => (d.cargador > 0 ? a.cargador > 0 : this._res(j, s, a) > 0);
    if (!hay()) {
      if (!s.rayoVacio) { s.rayoVacio = true; FORJA.Audio.sintetico('vacio'); if (d.cargador > 0 && p.autoRecarga) this._recargar(j, s, a); else if (p.cambiarSinBalas) this._cambiarConBalas(j, s); }
      return false;
    }
    s.rayoVacio = false;
    s.rayoGasto = (s.rayoGasto || 0) + d.consumo * dt;
    while (s.rayoGasto >= 1 && hay()) {
      s.rayoGasto -= 1;
      if (d.cargador > 0) a.cargador--; else this._ponerRes(j, s, a, this._res(j, s, a) - 1);
    }
    return true;
  },

  _empezarRayo(j, s, d) {
    const T = s.T;
    if (!s.rayoVis) {
      const geo = new T.CylinderGeometry(1, 1, 1, 6, 1, true).translate(0, 0.5, 0);
      const mat = (color, op) => new T.MeshBasicMaterial({ color, transparent: true, opacity: op, blending: T.AdditiveBlending, depthWrite: false, fog: false, side: T.DoubleSide });
      const mats = [];
      const rayos = [0, 1, 2].map(() => [0, 1, 2].map((k) => {
        const m = new T.Mesh(geo, mat('#ffffff', [0.9, 0.7, 0.22][k]));
        mats.push(m.material);
        m.frustumCulled = false; m.visible = false; m.renderOrder = 6; m.userData.ayudaEditor = true;
        j.escena.add(m);
        return m;
      }));
      const orbe = new T.Sprite(new T.SpriteMaterial({ map: s.tex, color: '#ffffff', transparent: true, blending: T.AdditiveBlending, depthWrite: false }));
      orbe.visible = false; orbe.userData.ayudaEditor = true; j.escena.add(orbe);
      s.rayoVis = { geo, mats, rayos, orbe, arriba: new T.Vector3(0, 1, 0) };
    }
    // colores de esta arma: núcleo blanco, cuerpo y halo del color del rayo
    for (const capas of s.rayoVis.rayos) { capas[0].material.color.set('#ffffff'); capas[1].material.color.set(d.colorRayo || '#66e6ff'); capas[2].material.color.set(d.colorRayo || '#66e6ff'); }
    s.rayoVis.orbe.material.color.set(d.colorRayo || '#66e6ff');
    s.rayoOn = true; s.rayoT = 0; s.rayoTick = 0; s.rayoAviso = 0; s.rayoDef = d;
    // sonido: el del arma en bucle, o un zumbido hecho por el motor
    if (d.sonido) { s.rayoSon = FORJA.Audio.fuente(d.sonido, true); if (s.rayoSon) { s.rayoSon.poner(1, 0); s.rayoSon.tocar(); } }
    else {
      const c = FORJA.Audio.contexto && FORJA.Audio.contexto();
      if (c) {
        if (c.state === 'suspended') c.resume().catch(() => {});
        const o1 = c.createOscillator(), o2 = c.createOscillator(), f = c.createBiquadFilter(), g = c.createGain();
        o1.type = 'sawtooth'; o1.frequency.value = 92; o2.type = 'square'; o2.frequency.value = 183.5;
        f.type = 'lowpass'; f.frequency.value = 1100;
        const A = FORJA.Audio; g.gain.value = 0.05 * (A.volGeneral ?? 1) * (A.volEfectos ?? 1);
        o1.connect(f); o2.connect(f); f.connect(g).connect(c.destination); o1.start(); o2.start();
        s.rayoSon = { parar: () => { try { o1.stop(); o2.stop(); } catch (e) { /* ya parado */ } g.disconnect(); } };
      }
    }
  },

  // recalentado = true: se agotó; si se suelta antes, enfría lo proporcional a lo usado
  _pararRayo(j, s, recalentado) {
    const d = s.rayoDef;
    s.rayoOn = false;
    if (s.rayoVis) { for (const capas of s.rayoVis.rayos) for (const m of capas) m.visible = false; s.rayoVis.orbe.visible = false; }
    if (s.rayoSon) { if (s.rayoSon.quitar) s.rayoSon.quitar(); else s.rayoSon.parar(); s.rayoSon = null; }
    if (d && d.duracionMax > 0) s.rayoEnfria = (d.recuperacion || 0) * (recalentado ? 1 : Math.min(1, s.rayoT / d.duracionMax));
    if (recalentado) FORJA.Audio.sintetico('vacio');
  },

  /* 🪄 Figuras de base de las armas mágicas (cajas + una gema que brilla del color del hechizo).
     El arma sale hacia −Z; la mano agarra en gripMagia; la gema / el orbe se llama "boca" (de ahí sale el hechizo). */
  _figuraMagia(s, d) {
    const T = s.T, R = FORJA.Render;
    const obj = new T.Group();
    const color = (d.tipo === 'escudo' ? d.escudoColor : d.colorBala) || '#8fa8ff';
    const madera = R.hacerRetro(new T.MeshLambertMaterial({ color: 0x6a4428, flatShading: true }));
    const oscura = R.hacerRetro(new T.MeshLambertMaterial({ color: 0x3a2416, flatShading: true }));
    const oro = R.hacerRetro(new T.MeshLambertMaterial({ color: 0xc8a040, flatShading: true }));
    const brillo = new T.MeshBasicMaterial({ color });
    const caja = (x, y, z, w, h, l, m, padre = obj) => { const b = new T.Mesh(new T.BoxGeometry(w, h, l), m); b.position.set(x, y, z); padre.add(b); return b; };
    const ud = obj.userData;
    ud.magia = d.magia;
    if (d.magia === 'varita') {
      caja(0, 0, -0.1, 0.018, 0.018, 0.27, madera);             // vara
      caja(0, 0, 0.03, 0.032, 0.032, 0.1, oscura);              // empuñadura
      caja(0, 0, -0.23, 0.03, 0.03, 0.02, oro);                 // anillo
      const g = new T.Mesh(new T.OctahedronGeometry(0.028, 0), brillo);
      g.position.set(0, 0, -0.265); g.name = 'boca'; obj.add(g);
      ud.gema = g; ud.gemaY = 0;
      ud.gripMagia = new T.Vector3(0, 0, 0.03);
    } else if (d.magia === 'baston') {
      caja(0, 0, -0.35, 0.036, 0.036, 1.4, madera);             // asta
      for (const [x, y] of [[0.04, 0], [-0.04, 0], [0, 0.04]]) caja(x, y, -1.07, 0.018, 0.018, 0.12, oro);   // garras que sujetan el cristal
      caja(0, 0, -1.02, 0.05, 0.05, 0.04, oscura);
      const g = new T.Mesh(new T.OctahedronGeometry(0.075, 0), brillo);
      g.position.set(0, 0.01, -1.15); g.name = 'boca'; obj.add(g);
      ud.gema = g; ud.gemaY = 0.01;
      ud.gripMagia = new T.Vector3(0, 0, 0.12);
    } else {
      // 📖 libro abierto (lomo a lo largo de −Z), con una hoja que pasa y un orbe encima
      const tapa = R.hacerRetro(new T.MeshLambertMaterial({ color: 0x5a1e2e, flatShading: true }));
      const hojas = R.hacerRetro(new T.MeshLambertMaterial({ color: 0xe8dcc0, flatShading: true }));
      const libro = new T.Group();
      for (const lado of [-1, 1]) {
        const mitad = new T.Group();
        mitad.rotation.z = lado * 0.22;                           // un poco en V
        caja(lado * 0.065, -0.006, 0, 0.13, 0.012, 0.18, tapa, mitad);
        caja(lado * 0.06, 0.008, 0, 0.115, 0.018, 0.165, hojas, mitad);
        libro.add(mitad);
      }
      caja(0, -0.012, 0, 0.02, 0.016, 0.18, oro, libro);         // lomo
      const pivote = new T.Group(); pivote.position.y = 0.02; libro.add(pivote);
      caja(0.058, 0, 0, 0.115, 0.003, 0.16, hojas, pivote);       // la hoja que pasa (gira sobre el lomo)
      obj.add(libro);
      const g = new T.Mesh(new T.IcosahedronGeometry(0.024, 0), brillo);
      g.position.set(0, 0.09, -0.02); g.name = 'boca'; obj.add(g);
      ud.gema = g; ud.gemaY = 0.09; ud.pagina = pivote; ud.libro = libro;
      ud.gripMagia = new T.Vector3(0, -0.02, 0.06);
    }
    return obj;
  },

  // 1ª persona: postura de cada forma (sobre la posición de serie del arma) y el gesto al lanzar (s.retro 1 → 0)
  _poseMagiaFp(s, m) {
    const r = s.retro || 0, f = m.userData.magia;
    if (f === 'varita') {                // en diagonal, punta arriba y hacia el centro; al lanzar, toque rápido al frente
      m.position.x += 0.02; m.position.y -= 0.02; m.position.z -= 0.08;
      m.rotation.x += 0.5 - r * 0.6;
      m.rotation.y += 0.22;
      m.position.z -= r * 0.08;
    } else if (f === 'baston') {         // de pie a la derecha, el cristal arriba a la vista; al lanzar, empujón al frente
      m.position.x += 0.1; m.position.y -= 0.32; m.position.z -= 0.25;
      m.rotation.x += 0.62 - r * 0.3;
      m.rotation.y += 0.12;
      m.rotation.z -= 0.08;
      m.position.z -= r * 0.14;
    } else {                              // libro: abajo a la izquierda, inclinado hacia ti; al lanzar se levanta
      m.position.x -= 0.46; m.position.y -= 0.05; m.position.z -= 0.18;
      m.position.y += r * 0.04;
      m.rotation.x += 0.9; m.rotation.y += 0.3;
    }
  },

  // gema que late y gira, cristal que flota, hojas que pasan (rápido al lanzar)
  _animMagia(s, m, dt) {
    const ud = m.userData, r = s.retro || 0;
    s.tMagia = (s.tMagia || 0) + dt;
    const t = s.tMagia;
    if (ud.gema) {
      ud.gema.rotation.y += dt * (2 + r * 10);
      ud.gema.scale.setScalar(1 + Math.sin(t * 4) * 0.12 + r * 0.7);
      ud.gema.position.y = ud.gemaY + (ud.magia === 'baston' || ud.magia === 'libro' ? Math.sin(t * 2.2) * 0.015 : 0);
    }
    if (ud.pagina) {
      s.hoja = (s.hoja || 0) + dt * (r > 0.05 ? 7 : 0.25);
      const k = s.hoja % 1, e = k * k * (3 - 2 * k);
      ud.pagina.rotation.z = Math.PI * 0.86 * e;   // de la mitad derecha a la izquierda
    }
  },

  /* 🛡 Hechizo escudo: un campo de energía rodea al jugador unos segundos (motor/campos.js) */
  _escudo(j, s, d) {
    // con el módulo Salud: el mismo escudo de fuerza que los recogibles (uno solo, una sola esfera)
    if (j.activarEscudo) { j.activarEscudo({ seg: d.escudoSeg || 6, aguante: d.escudoAguante, bloquea: d.escudoBloquea, estilo: d.escudoEstilo, color: d.escudoColor }); return; }
    if (!FORJA.Campo) return;
    if (!s.campoEscudo) s.campoEscudo = FORJA.Campo.crear({ forma: 'esfera', fuerza: 0 });
    const c = s.campoEscudo;
    c.color(d.escudoColor || '#7fb4ff');
    c.estilo(d.escudoEstilo || 'ondas');
    if (c.malla.parent !== j.escena) j.escena.add(c.malla);
    c.fuerza(1, 0.25);
    s.escudoT = Math.max(0.5, d.escudoSeg || 6);
    s.escudoD = d;
    s.escudoVida = d.escudoAguante > 0 ? d.escudoAguante : Infinity;
    FORJA.Audio.sintetico('disparo', { volumen: 0.4, tono: 0.5 });
    FORJA.emitir('escudo-magico', { jugador: j, activo: true });
  },
  _actualizarEscudo(j, s, dt) {
    const c = s.campoEscudo;
    if (!c) return;
    if (s.escudoT > 0) {
      s.escudoT -= dt;
      if (s.escudoT <= 0.4 && s.escudoT + dt > 0.4) c.fuerza(0, 0.4);   // se apaga al final
      if (s.escudoT <= 0) FORJA.emitir('escudo-magico', { jugador: j, activo: false });
    }
    const pie = j.cuerpo.pie, alto = j.cuerpo.altura || 1.8;
    c.malla.position.set(pie.x, j.cuerpo.visY + alto * 0.5, pie.z);
    c.malla.scale.setScalar(Math.max(0.9, alto * 0.62));
    c.malla.visible = c.valor() > 0.001 || s.escudoT > 0;
  },
  _recibirEnEscudo(j, s, cant, origen, de) {
    if (!(s.escudoT > 0) || !s.escudoD) return cant;
    if (origen === 'lava' || origen === 'agua' || origen === 'ahogo' || origen === 'aplastar' || origen === 'caida' || origen === 'vacio') return cant;
    const para = cant * Math.min(1, (s.escudoD.escudoBloquea ?? 100) / 100);
    const pt = de && de.cuerpo && de.cuerpo.pie ? s.tv10 = (s.tv10 || new s.T.Vector3()).copy(de.cuerpo.pie).setY(de.cuerpo.pie.y + 1.2) : null;
    s.campoEscudo.golpe(pt);
    FORJA.Audio.sintetico('impacto', { volumen: 0.5, tono: 1.6 });
    s.escudoVida -= para;
    if (s.escudoVida <= 0) {   // se rompe
      s.escudoT = 0; s.campoEscudo.fuerza(0, 0.15);
      FORJA.Audio.sintetico('impacto', { volumen: 0.8, tono: 0.7 });
      FORJA.emitir('escudo-magico', { jugador: j, activo: false, roto: true });
    }
    return cant - para;
  },

  _modelo(s, d) {
    if (s.modelos.has(d.id)) return s.modelos.get(d.id);
    const T = s.T;
    let obj;
    const a = d.modelo && FORJA.Assets.mapa.get(d.modelo);
    if (a && a.gltf) {
      obj = T.SkeletonUtils.clone(a.gltf.scene);
      { const vf = obj.getObjectByName('Arma_FPS'), vt = obj.getObjectByName('Arma_TPS'); if (vf && vt) Object.assign(obj.userData, { vFps: vf, vTps: vt }); }   // Forja de personajes a2: versión 1ª y 3ª persona
    } else if (d.id === '__punos') {
      // puños: dos puños de cajas en primer plano
      obj = new T.Group();
      const piel = FORJA.Render.hacerRetro(new T.MeshLambertMaterial({ color: 0xd8a27a }));
      const manga = FORJA.Render.hacerRetro(new T.MeshLambertMaterial({ color: 0x3b6ad1 }));
      for (const x of [-0.26, 0]) {
        const puno = new T.Mesh(new T.BoxGeometry(0.09, 0.08, 0.1), piel); puno.position.set(x, 0, -0.06); obj.add(puno);
        const brazo = new T.Mesh(new T.BoxGeometry(0.08, 0.08, 0.22), manga); brazo.position.set(x, -0.01, 0.1); obj.add(brazo);
      }
    } else if (d.magia && d.magia !== 'no' && d.tipo !== 'cuerpo') {
      obj = this._figuraMagia(s, d);   // 🪄 varita · 🦯 bastón · 📖 libro
    } else {
      // arma de cajas, estilo de la época
      obj = new T.Group();
      const mat = FORJA.Render.hacerRetro(new T.MeshLambertMaterial({ color: 0x3a3f48 }));
      const mat2 = FORJA.Render.hacerRetro(new T.MeshLambertMaterial({ color: 0x8a6a4a }));
      const caja = (x, y, z, w, h, l, m) => { const b = new T.Mesh(new T.BoxGeometry(w, h, l), m); b.position.set(x, y, z); obj.add(b); };
      if (d.tipo === 'cuerpo') {
        // forma de serie según el estilo (la mano agarra en z = 0; el arma sale hacia −Z)
        const acero = FORJA.Render.hacerRetro(new T.MeshLambertMaterial({ color: 0xc8ccd4 }));
        const est = FORJA.Escena.estiloCuerpo(d);
        if (est === 'larga') {            // espada: hoja larga, guarda y empuñadura
          caja(0, 0, -0.38, 0.02, 0.05, 0.62, acero); caja(0, 0, -0.06, 0.03, 0.14, 0.025, mat); caja(0, 0, 0.03, 0.03, 0.035, 0.12, mat2);
        } else if (est === 'espadon') {   // ⚔ espada a dos manos: puño largo (dos manos), guarda ancha y hoja larga
          caja(0, 0, -0.07, 0.035, 0.035, 0.24, mat2); caja(0, 0, -0.2, 0.03, 0.2, 0.03, mat); caja(0, 0, -0.68, 0.025, 0.065, 0.92, acero);
        } else if (est === 'dosManos') {  // hacha: mango largo y cabeza al final
          caja(0, 0, -0.3, 0.035, 0.035, 0.78, mat2); caja(0, 0.07, -0.62, 0.025, 0.2, 0.14, acero);
        } else if (est === 'lanza') {     // lanza: asta muy larga (se agarra por detrás) y punta
          caja(0, 0, -0.45, 0.03, 0.03, 1.5, mat2); caja(0, 0, -1.25, 0.02, 0.05, 0.14, acero);
        } else {
          caja(0, 0, -0.08, 0.02, 0.05, 0.22, acero);
          caja(0, -0.01, 0.07, 0.03, 0.04, 0.1, mat2);
        }
      } else if (d.tipo === 'proyectil') {
        caja(0, 0, -0.05, 0.1, 0.1, 0.5, mat);
        caja(0, -0.08, 0.05, 0.04, 0.1, 0.05, mat2);
      } else if (d.tipo === 'rayo') {
        // emisor: cuerpo grueso, bobinas y la punta del color del rayo
        caja(0, 0.02, -0.12, 0.07, 0.08, 0.38, mat);
        caja(0, 0.02, -0.33, 0.05, 0.05, 0.05, new T.MeshBasicMaterial({ color: d.colorRayo || '#66e6ff' }));
        for (const z of [-0.2, -0.1, 0]) caja(0, 0.02, z, 0.09, 0.1, 0.025, mat2);
        caja(0, -0.06, 0.04, 0.045, 0.1, 0.05, mat2);
      } else if (d.automatica && d.perdigones <= 1) {
        // fusil automático: largo, con cargador y culata
        caja(0, 0.02, -0.16, 0.045, 0.06, 0.46, mat);
        caja(0, -0.06, -0.08, 0.035, 0.12, 0.05, mat);
        caja(0, -0.05, 0.05, 0.045, 0.1, 0.05, mat2);
        caja(0, 0, 0.14, 0.04, 0.08, 0.14, mat2);
      } else {
        const largo = d.perdigones > 1 ? 0.42 : 0.2;
        caja(0, 0.02, -largo / 2 + 0.05, 0.05, 0.06, largo, mat);
        caja(0, -0.05, 0.05, 0.045, 0.1, 0.05, mat2);
      }
    }
    // empuñadura: el punto que va en la mano (en 3ª persona). GLB de la Forja de personajes: su nodo "Grip".
    if (!obj.userData.grip) {
      let grip = null;
      if (a && a.gltf) {
        obj.updateMatrixWorld(true);
        obj.traverse((o) => { if (!grip && /^grip$/i.test(o.name)) grip = o.getWorldPosition(new T.Vector3()); });
      }
      if (!grip && obj.userData.gripMagia) grip = obj.userData.gripMagia;
      if (!grip) grip = d.tipo === 'cuerpo' ? new T.Vector3(0, -0.01, 0.07) : d.tipo === 'proyectil' ? new T.Vector3(0, -0.08, 0.05) : new T.Vector3(0, -0.05, 0.05);
      obj.userData.grip = grip;
    }
    // 🔥 boca del cañón (de donde salen fogonazo y balas): el nodo "Muzzle" del GLB (Forja de personajes) o, si no hay,
    // el extremo delantero (−Z) de la pieza que más sobresale. Se calcula una vez; cada disparo solo lo transforma.
    if (!obj.userData.muzzle && d.tipo !== 'cuerpo' && d.id !== '__punos') {
      obj.updateMatrixWorld(true);
      let mz = null;
      obj.traverse((o) => { if (!mz && /^(muzzle|boca)$/i.test(o.name)) mz = o.getWorldPosition(new T.Vector3()); });
      if (!mz) {
        let mejor = null;
        obj.traverse((o) => { if (o.isMesh && o.geometry) { const bb = new T.Box3().setFromObject(o); if (!bb.isEmpty() && (!mejor || bb.min.z < mejor.min.z)) mejor = bb; } });
        if (mejor) mz = new T.Vector3((mejor.min.x + mejor.max.x) / 2, (mejor.min.y + mejor.max.y) / 2, mejor.min.z);
      }
      obj.userData.muzzle = mz;
    }
    obj.scale.setScalar(d.escalaModelo || 1);
    obj.traverse((o) => { if (o.isMesh) { o.frustumCulled = false; o.castShadow = false; } });
    obj.visible = false;
    s.vista.add(obj);
    s.modelos.set(d.id, obj);
    return obj;
  },

  despues(j, p, s, dt) {
    const T = s.T, cam = j.camara, c = j.cuerpo;
    const a = this._actual(j);
    // apuntar: FOV (1ª) o cámara más cerca (3ª, la lee el módulo Cámara con j.apuntando)
    const metaAp = s.quiereApuntar && !j.muerto ? 1 : 0;
    j.apuntando += (metaAp - j.apuntando) * Math.min(1, dt * 12);
    if (a && a.def.tipo !== 'cuerpo') {
      const fov = s.fov0 + (a.def.zoom - s.fov0) * j.apuntando;
      if (!j.esquivando && Math.abs(cam.fov - fov) > 0.05) { cam.fov = fov; cam.updateProjectionMatrix(); }
    }
    // temblor por explosiones
    if (j.temblor > 0) {
      j.temblor -= dt;
      cam.position.x += (Math.random() - 0.5) * j.temblor * 0.3;
      cam.position.y += (Math.random() - 0.5) * j.temblor * 0.3;
    }

    // el arma que se ve: 1ª persona → primer plano · 3ª → en el mundo
    const destino = j.modoCamara === 'fps' ? s.pp.escena : j.escena;
    if (s.vista.parent !== destino) destino.add(s.vista);
    s.pp.activo = (j.modoCamara === 'fps' && !!a && !j.muerto) || !!j.antorchaPP;   // 🔥 la antorcha también va en primer plano
    for (const m of s.modelos.values()) m.visible = false;
    if (a && !j.muerto) {
      const m = this._modelo(s, a.def);
      const d = a.def;
      s.retro = Math.max(0, s.retro - dt * 8);
      // balanceo: dos valores fijos (caminar / correr) en vez de seguir la velocidad;
      // así un jugador muy rápido no hace vibrar el arma. La fuerza cambia suave al pasar de uno a otro.
      const vh = Math.hypot(c.velocidad.x, c.velocidad.z);
      const mueve = c.enSuelo && vh > 0.3;
      const corre = mueve && j.corriendo;
      if (mueve) s.paso += dt * Math.PI * 2 * (corre ? p.ritmoCorrer ?? 1.5 : p.ritmoCaminar ?? 1);
      const fuerza = mueve ? (corre ? p.fuerzaCorrer ?? 1.6 : p.fuerzaCaminar ?? 1) : 0;
      s.balF = (s.balF || 0) + (fuerza - (s.balF || 0)) * Math.min(1, dt * 8);
      const bal = p.balanceo * s.balF;
      // cambio de arma: "desde arriba" = el arma sube y vuelve a bajar a su sitio; "desde abajo" = baja y sube
      const sentido = p.dirCambio === 'abajo' ? 1 : -1;
      const bajar = s.cambio > 0 ? Math.sin((s.cambio / 0.35) * Math.PI) * 0.25 * sentido : 0;
      const rec = s.recargando > 0 ? 0.12 : 0;
      if (m.userData.vFps) { m.userData.vFps.visible = j.modoCamara === 'fps'; m.userData.vTps.visible = j.modoCamara !== 'fps'; }
      if (j.modoCamara === 'fps') {
        m.visible = true;
        if (s.escTps) { m.scale.setScalar(d.escalaModelo || 1); s.escTps = false; }
        const x = d.posX * (1 - j.apuntando) + Math.cos(s.paso) * 0.012 * bal;
        const y = d.posY + j.apuntando * 0.07 - Math.abs(Math.sin(s.paso)) * 0.012 * bal - bajar - rec;
        const z = d.posZ + s.retro * 0.05 * (d.retroceso > 0 ? 1 : 0) + (d.tipo === 'cuerpo' ? -s.retro * 0.15 : 0);
        s.vista.position.copy(cam.position);
        s.vista.quaternion.copy(cam.quaternion);
        // 🛡 guardia en 1ª persona: el arma se cruza horizontal delante
        s.bloqV = (s.bloqV || 0) + ((j.bloqueando ? 1 : 0) - (s.bloqV || 0)) * Math.min(1, dt * 14);
        const bq = s.bloqV;
        // cuerpo a cuerpo: sin el desplazamiento al centro de apuntar (eso es de las armas de fuego); solo balanceo y cambio
        if (d.tipo === 'cuerpo' && d.id !== '__punos') this._fpCuerpo(j, s, d, m, x - d.posX * (1 - j.apuntando), y - d.posY - j.apuntando * 0.07, z - d.posZ, bq);
        else {
          const G = Math.PI / 180;
          m.position.set(x, y, z);
          m.rotation.set(rec * 3 + s.retro * 0.08 + (d.fpGiroX || 0) * G, (d.fpGiroY || 0) * G, (d.fpGiroZ || 0) * G);
          if (m.userData.magia) this._poseMagiaFp(s, m);
        }
      } else if (p.armaEnTps && d.id !== '__punos') {   // en 3ª persona los puños son las manos del personaje
        m.visible = true;
        // la mano agarra la EMPUÑADURA (no el centro del arma); luego el ajuste "En la mano" de cada arma
        const sc = (d.escalaModelo || 1) * (d.tpsEscala || 1), G = Math.PI / 180;
        m.scale.setScalar(sc);
        m.rotation.set((d.tpsGiroX || 0) * G - s.retro * 0.2, (d.tpsGiroY || 0) * G, (d.tpsGiroZ || 0) * G);
        const grip = (m.userData.grip || s.v1.set(0, 0, 0)).clone().multiplyScalar(sc).applyEuler(m.rotation);
        m.position.set((d.tpsX || 0) - grip.x, (d.tpsY || 0) - bajar - grip.y, (d.tpsZ || 0) - grip.z);
        s.escTps = true;
        // 3ª persona: el arma va en la mano derecha del modelo (hueso hand_R / Hand_R).
        // Se coloca DESPUÉS de que el módulo Modelo mueve y anima al personaje en este cuadro (si no, se queda
        // atrás al correr): Modelo llama a j.alColocarModelo al terminar. Sin modelo ni mano: a un costado.
        s.tps = true;
        if (!j.modelo || !this._mano(j, s)) { this._colocarTps(j, s); s.tps = false; }
      }
    }

    if (a && !j.muerto) { const mm = s.modelos.get(a.def.id); if (mm && mm.userData.magia) this._animMagia(s, mm, dt); }
    this._colocarEscudoMano(j, p, s, a, dt);
    if (j.modoCamara !== 'fps' && j.modelo && j.escudoMano) s.escPend = [p, a];   // se vuelve a colocar tras el Modelo
    this._actualizarEscudo(j, s, dt);
    this._rayo(j, p, s, a, dt);
    // efectos
    if (s.flashT > 0) { s.flashT -= dt; if (s.flashT <= 0) s.flash.visible = false; }
    for (const ch of s.chispas) {
      if (!ch.sp.visible) continue;
      ch.t -= dt;
      if (ch.t <= 0) ch.sp.visible = false;
      else ch.sp.scale.setScalar(ch.tam * (0.5 + ch.t / 0.24));
    }
    for (const ex of s.explosiones) {
      if (!ex.sp.visible) continue;
      ex.t -= dt;
      if (ex.t <= 0) { ex.sp.visible = false; continue; }
      const k = 1 - ex.t / 0.4;
      ex.sp.scale.setScalar(ex.radio * 2 * (0.4 + k));
      ex.sp.material.opacity = 1 - k;
    }
    this._moverBalas(j, s, dt);

    // HUD: solo se toca el HTML cuando cambia algo
    const tipo = a && this._tipo(s, a.def);
    const num = !a || a.def.tipo === 'cuerpo' ? ''
      : `${s.recargando > 0 ? '···' : a.def.cargador > 0 ? a.cargador : ''}${a.def.cargador > 0 ? ' / ' : ''}${a.def.infinita ? '∞' : Math.floor(this._res(j, s, a))}`;
    const enfria = a && a.def.tipo === 'rayo' && s.rayoEnfria > 0;
    const clave = (a ? a.def.id : '') + '|' + num + (enfria ? '|e' : '');
    if (clave !== s.pintado) {
      s.pintado = clave;
      s.hudArma.textContent = a ? a.def.nombre : '';
      s.hudIco.textContent = tipo ? tipo.icono || '' : '';
      s.hudNum.textContent = num + (enfria ? ' ♨' : '');   // ♨ el rayo se está enfriando
      s.hud.classList.toggle('fh-vacio', !a);
      // poco: el cargador (o la reserva, si no tiene cargador) por debajo del aviso del HUD
      const bajo = (j.juego._hudCfg && j.juego._hudCfg.avisoBajo) ?? 0.25;
      let poco = false;
      if (a && bajo > 0 && a.def.tipo !== 'cuerpo' && !a.def.infinita) {
        poco = a.def.cargador > 0 ? a.cargador <= Math.floor(a.def.cargador * bajo) && s.recargando <= 0 : this._res(j, s, a) <= Math.max(1, Math.floor(this._max(s, a) * bajo * 0.2));
      }
      s.hud.classList.toggle('fh-bajo', poco);
      FORJA.Hud.cambio(j.juego, s.hud);
    }
  },

  detener(j, p, s) {
    if (s && s.escMano) for (const g of Object.values(s.escMano)) if (g.parent) g.parent.remove(g);
    if (s && s.hudEsc) s.hudEsc.remove();
    j.alBloquear = null; j.bloqueando = false;
    j.alEscudo = null;
    if (s.campoEscudo) { s.campoEscudo.malla.parent && s.campoEscudo.malla.parent.remove(s.campoEscudo.malla); s.campoEscudo = null; }
    const quitar = (o) => o && o.parent && o.parent.remove(o);
    quitar(s.vista); quitar(s.flash);
    if (s.pp) s.pp.activo = false;
    for (const ch of s.chispas) quitar(ch.sp);
    for (const ex of s.explosiones) quitar(ex.sp);
    for (const b of s.balas) quitar(b.sp);
    for (const m of s.marcas) quitar(m);
    for (const m of s.calcos || []) quitar(m);
    for (const off of s.oyentes || []) off();
    if (s.rayoOn) this._pararRayo(j, s, false);
    if (s.rayoVis) { for (const capas of s.rayoVis.rayos) for (const m of capas) quitar(m); quitar(s.rayoVis.orbe); s.rayoVis.geo.dispose(); s.rayoVis.mats.forEach((m) => m.dispose()); }
    for (const r of s.recursos) r.dispose();
    s.tex.dispose();
    j.camara.fov = s.fov0;
    j.camara.updateProjectionMatrix();
  },
});
