/* Módulo INTERACTUAR — mirar algo cercano y pulsar E / X (□) / botón táctil.
   1ª persona: el rayo sale de los ojos · 3ª persona: del pecho del personaje hacia donde mira la cámara.
   Se revisa 10 veces por segundo (no cada cuadro) y solo contra los objetos que tienen "Interacción" en el Inspector.
   Por ahora: carteles / notas (tipo "Mensaje"). Puertas, palancas, baúles… usarán el mismo aviso con
   FORJA.on('interactuar', ({ ent, obj, jugador }) => …). */
FORJA.registrarModulo({
  nombre: 'interactuar',
  etiqueta: 'Interactuar',
  descripcion: 'Aviso "E: Leer" al mirar un objeto con Interacción y acción al pulsar.',
  orden: 50,
  activoPorDefecto: true,
  props: [
    { k: 'distancia', t: 'num', e: 'Alcance (m)', def: 2.5, paso: 0.1, min: 0.5 },
    { k: 'congelar', t: 'bool', e: 'Quieto al leer', def: true, ayuda: 'Mientras hay un mensaje en pantalla el jugador no se mueve (estilo RE)' },
    { k: 'cerrarCon', t: 'sel', e: 'Cerrar mensaje con', def: 'interactuar',
      op: [['interactuar', 'El mismo botón de usar (E / X / ✋)'], ['cualquiera', 'Usar, saltar o disparar']] },
    { k: 'sonido', t: 'asset', e: 'Sonido al usar', def: '', tipoAsset: 'audio', vacio: '(ninguno)' },
  ],

  iniciar(j, p, s) {
    const H = FORJA.Hud;
    s.aviso = H.pieza(j.juego, 'fh-aviso');
    s.caja = H.pieza(j.juego, 'fh-mensaje');
    s.caja.onclick = () => { s.cerrarPedido = true; };
    s.reloj = 0;
    s.objetivo = null;
    s.leyendo = null;
    s.usados = new Set();
    s.ray = new THREE.Raycaster();
    s.dir = new THREE.Vector3();
    s.ori = new THREE.Vector3();
    // Solo los objetos con interacción (no toda la escena)
    s.lista = [];
    for (const ent of j.juego.escena.entidades) {
      const it = ent.interaccion;
      const obj = j.juego.objetos.get(ent.id);
      if (it && it.tipo && obj) s.lista.push({ ent, obj });
      // recogibles "con el botón de usar" (estilo Resident Evil)
      else if (ent.tipo === 'recogible' && obj && ent.recogible && ent.recogible.recoger === 'usar') s.lista.push({ ent, obj, recogible: true });
      // 🚪 salidas "con el botón de usar" (puertas a otro nivel)
      else if (ent.tipo === 'salida' && obj && ent.salida && ent.salida.activar === 'usar') s.lista.push({ ent, obj, salida: true });
      // 📦 baúl: abre la mochila junto al baúl (módulo Inventario)
      // (cofre de premio: lo abre motor/mecanismos.js; se marca como "puerta" para usar su aviso)
      else if (ent.tipo === 'baul' && obj && ent.baul && ent.baul.modo === 'premio') s.lista.push({ ent, obj, puerta: true });
      else if (ent.tipo === 'baul' && obj) s.lista.push({ ent, obj, baul: true });
      // 💾 punto de guardado con el botón de usar
      else if (ent.tipo === 'guardado' && obj && (ent.guardado || {}).activar !== 'tocar') s.lista.push({ ent, obj, guardado: true });
      // 🧱 objeto movible que se carga
      // 🔒 puertas que se usan con el botón (y las de palanca, para decir que no se abren desde aquí)
      else if (ent.tipo === 'puerta' && obj && ent.puerta && ent.puerta.abrir !== 'cerca') s.lista.push({ ent, obj, puerta: true });
      // 🕹 palancas, botones e interruptores (el aviso y lo que hacen los lleva motor/mecanismos.js)
      else if (ent.tipo === 'palanca' && obj) s.lista.push({ ent, obj, puerta: true });
      // 🏺 pedestales (colocar / coger el objeto clave)
      else if (ent.tipo === 'pedestal' && obj) s.lista.push({ ent, obj, puerta: true });
    }
  },

  _texto(j, ent) {
    const it = ent.interaccion || { verbo: 'Recoger' };
    const tecla = FORJA.Tactil && FORJA.Tactil.visible ? '' : FORJA.Entrada.textoTeclado('interactuar').split(' / ')[0] + ': ';
    if (ent.tipo === 'baul' && ent.baul && ent.baul.modo === 'premio') return tecla + (j.juego.mecanismos.textoUsar(ent) || '');
    if (ent.tipo === 'baul') return tecla + 'Abrir ' + (ent.nombre || 'baúl');
    if (ent.tipo === 'empujable') return tecla + ((j.juego.empujables && j.juego.empujables.textoUsar(ent)) || 'Levantar');
    if (ent.tipo === 'guardado') return tecla + ((j.juego.guardado && j.juego.guardado.textoUsar(ent)) || 'Guardar');
    if (ent.tipo === 'puerta' || ent.tipo === 'palanca' || ent.tipo === 'pedestal') return tecla + (j.juego.mecanismos.textoUsar(ent) || '');
    if (ent.tipo === 'salida') {
      const destino = j.juego.proyecto.escenas.find((e) => e.id === ent.salida.destino);
      return tecla + (ent.salida.aviso || (destino ? 'Ir a ' + destino.nombre : 'Usar ' + ent.nombre));
    }
    return `${tecla}${it.verbo || 'Usar'}${ent.nombre && it.mostrarNombre !== false ? ' ' + ent.nombre : ''}`;
  },

  entrada(j, p, s, dt) {
    // Leyendo un mensaje: el mismo botón de usar lo cierra (o tocarlo). Si aún se escribe, el primer toque lo completa.
    if (s.leyendo) {
      s.tLeyendo += dt;
      this._escribir(s, dt);
      const pulso = p.cerrarCon === 'cualquiera' ? j.pulsoContinuar : j.pulsoUsar;
      if ((pulso || s.cerrarPedido) && s.tLeyendo > 0.2 && s.escrito < s.completo.length) {
        s.escrito = s.completo.length;
        s.cuerpo.textContent = s.completo;
        s.cerrarPedido = false;
        return;
      }
      if ((pulso || s.cerrarPedido) && s.tLeyendo > 0.25) {
        s.caja.style.display = 'none';
        if (p.congelar) j.sinControl = false;
        s.leyendo = null;
        s.cerrarPedido = false;
        s.reloj = 0;
      }
      return;
    }
    s.cerrarPedido = false;
    if (j.muerto || !s.lista.length) return;

    s.reloj -= dt;
    if (s.reloj <= 0) {
      s.reloj = 0.1;
      const cam = j.camara, c = j.cuerpo;
      cam.getWorldDirection(s.dir);
      if (j.camFija) s.dir.set(-Math.sin(j.yaw), -0.25, -Math.cos(j.yaw)).normalize();   // 📷 cámaras fijas: hacia donde mira el cuerpo, algo hacia abajo
      if (j.modoCamara === 'fps') s.ori.copy(cam.position);
      else s.ori.set(c.pie.x, c.visY + c.altura * 0.7, c.pie.z);
      s.ray.set(s.ori, s.dir);
      s.ray.camera = cam;   // los recogibles llevan aura (sprite): el rayo necesita la cámara
      s.ray.far = j.modoCamara === 'fps' ? p.distancia : p.distancia + cam.position.distanceTo(s.ori);
      const M = j.juego.mecanismos;
      const libres = s.lista.filter((x) => !s.usados.has(x.ent.id) && x.obj.visible !== false && (!x.puerta || (M && M.textoUsar(x.ent))) && (!x.guardado || (j.juego.guardado && j.juego.guardado.textoUsar(x.ent))) && (!x.carga || !j.juego.empujables.cargado));
      const golpes = s.ray.intersectObjects(libres.map((x) => x.obj), true);
      let nuevo = null;
      if (golpes.length) {
        let o = golpes[0].object;
        while (o && !o.userData.entId) o = o.parent;
        const cand = o && libres.find((x) => x.obj === o);
        // que no haya una pared en medio (el propio objeto también está en la colisión: margen de 15 cm)
        const pared = j.mundo.rayo(s.ori.x, s.ori.y, s.ori.z, s.dir.x, s.dir.y, s.dir.z, golpes[0].distance);
        if (cand && (!pared || pared.t > golpes[0].distance - 0.15)) nuevo = cand;
      }
      // una puerta cambia de aviso al abrirse (Abrir → Cerrar)
      if (nuevo && nuevo === s.objetivo && nuevo.puerta) s.aviso.textContent = this._texto(j, nuevo.ent);
      if (nuevo !== s.objetivo) {
        s.objetivo = nuevo;
        s.aviso.style.display = nuevo ? 'block' : 'none';
        if (nuevo) s.aviso.textContent = this._texto(j, nuevo.ent);
        if (FORJA.Tactil) FORJA.Tactil.ponerContexto('interactuar', !!nuevo);
      }
    }

    // 🧱 cargando algo: usar = soltarlo delante
    const EM = j.juego.empujables;
    if (EM && EM.cargado) { if (s.objetivo) { s.objetivo = null; s.aviso.style.display = 'none'; } return; }
    if (s.objetivo && !j.blancoSigilo && !j.blancoTactico && !(j.sinInteractuar > 0) && FORJA.Entrada.pulsado('interactuar')) this._usar(j, p, s, s.objetivo);
  },

  _usar(j, p, s, x) {
    if (x.carga) { j.juego.empujables.usar(x.ent); s.reloj = 0; s.objetivo = null; s.aviso.style.display = 'none'; return; }
    if (x.guardado) { j.juego.guardado.usar(x.ent); s.reloj = 0; s.objetivo = null; s.aviso.style.display = 'none'; return; }
    if (x.puerta) {
      j.juego.mecanismos.usar(x.ent);
      s.reloj = 0;   // el aviso se rehace (Abrir ↔ Cerrar)
      return;
    }
    if (x.baul) {
      const inv = j.tieneModulo('inventario') && FORJA.modulosOrdenados().find((m) => m.nombre === 'inventario');
      if (inv) { s.aviso.style.display = 'none'; s.objetivo = null; inv.abrir(j, null, null, true); }
      else { s.aviso.textContent = 'Activa el módulo Inventario'; s.reloj = 0.9; }
      return;
    }
    if (x.salida) {
      // el viaje lo hace el gestor de niveles (motor/niveles.js); el sonido es el de la salida
      s.aviso.style.display = 'none';
      s.objetivo = null;
      if (FORJA.Tactil) FORJA.Tactil.ponerContexto('interactuar', false);
      if (j.juego.salidas) j.juego.salidas.activar(x.ent);
      return;
    }
    if (x.recogible) {
      const ok = j.juego.recogibles && j.juego.recogibles.recoger(x.ent.id);
      if (!ok) {
        // no lo necesita (vida llena, munición al máximo…): se queda en su sitio
        s.aviso.textContent = 'No lo necesitas ahora';
        s.reloj = 0.9;
        return;
      }
      if (p.sonido) FORJA.Audio.efecto(p.sonido);
      s.aviso.style.display = 'none';
      s.objetivo = null;
      if (FORJA.Tactil) FORJA.Tactil.ponerContexto('interactuar', false);
      return;
    }
    const it = x.ent.interaccion;
    if (p.sonido) FORJA.Audio.efecto(p.sonido);
    FORJA.emitir('interactuar', { ent: x.ent, obj: x.obj, jugador: j, juego: j.juego });
    if (it.unaVez) s.usados.add(x.ent.id);
    if (it.tipo === 'mensaje') {
      const est = (j.juego.proyecto.menus && j.juego.proyecto.menus.mensaje) || {};
      FORJA.Hud.estiloMensaje(s.caja, j.juego.proyecto);
      s.caja.innerHTML = '';
      const ret = it.retrato && FORJA.Assets && FORJA.Assets.mapa.get(it.retrato);
      if (ret && ret.url) {   // 🖼 retrato de quien habla
        const img = document.createElement('img');
        img.src = ret.url;
        img.style.cssText = 'float:left;width:4.2em;height:4.2em;object-fit:cover;image-rendering:pixelated;border:2px solid currentColor;margin:0 .7em .3em 0';
        s.caja.appendChild(img);
      }
      if (it.titulo) {
        const ti = document.createElement('b');
        ti.className = 'fh-titulo';
        ti.textContent = it.titulo;
        s.caja.appendChild(ti);
      }
      s.cuerpo = document.createElement('div');
      s.completo = it.texto || '…';
      // máquina de escribir (letras por segundo; 0 = todo de golpe)
      s.vel = est.escribir ?? 40;
      s.escrito = s.vel > 0 ? 0 : s.completo.length;
      s.acum = 0;
      s.sonidoLetra = est.sonidoLetra;
      s.cuerpo.textContent = s.completo.slice(0, s.escrito);
      const pie = document.createElement('small');
      const tecla = FORJA.Entrada.textoTeclado('interactuar').split(' / ')[0];
      pie.textContent = FORJA.Tactil && FORJA.Tactil.visible ? 'Toca ✋ para seguir' : `${tecla}: seguir`;
      s.caja.append(s.cuerpo, pie);
      s.caja.style.display = 'block';
      if (est.sonidoAbrir) FORJA.Audio.efecto(est.sonidoAbrir);
      s.leyendo = x;
      s.tLeyendo = 0;
      if (p.congelar) j.sinControl = true;
    }
    s.aviso.style.display = 'none';
    s.objetivo = null;
    if (FORJA.Tactil) FORJA.Tactil.ponerContexto('interactuar', !!s.leyendo);
  },

  _escribir(s, dt) {
    if (s.escrito >= s.completo.length) return;
    s.acum += dt * s.vel;
    const n = Math.floor(s.acum);
    if (!n) return;
    s.acum -= n;
    s.escrito = Math.min(s.completo.length, s.escrito + n);
    s.cuerpo.textContent = s.completo.slice(0, s.escrito);
    if (s.sonidoLetra && /\S/.test(s.completo[s.escrito - 1] || '')) FORJA.Audio.efecto(s.sonidoLetra, { volumen: 0.5, tono: 0.95 + Math.random() * 0.1 });
  },

  detener(j, p, s) {
    if (FORJA.Tactil) FORJA.Tactil.ponerContexto('interactuar', false);
  },
});
