/* Módulo ATAQUE ESPECIAL — ✸ ataque de área con su propia tecla, aparte de las armas.
   Pulsas "Ataque especial" (B o el botón central del ratón; se cambia en Opciones ▸ Controles) y sale una esfera de
   energía alrededor del jugador (motor/area.js): una onda que crece y empuja, o un aura que se queda unos segundos.
   Después hay que esperar la recarga. En pantalla: ✸ con la tecla cuando está listo, o los segundos que faltan.
   (El mismo ataque también existe como tipo de arma "✸ Área" en Juego ▸ Armas, para usarlo con 1, 2, 3…) */
FORJA.registrarModulo({
  nombre: 'especial',
  etiqueta: 'Ataque especial (área)',
  descripcion: 'Una esfera de energía que daña lo que toca: onda que crece o aura que se queda. Con su tecla y recarga.',
  orden: 46,
  activoPorDefecto: false,
  props: [
    { k: 'forma', t: 'sel', e: 'Forma', def: 'onda', op: [['onda', '💥 Onda que crece (un golpe)'], ['aura', '🌀 Aura que se queda (daña poco a poco)']],
      ayuda: 'Onda: sale de ti, crece hasta el radio, golpea una vez y empuja. Aura: te rodea unos segundos y daña a lo que esté dentro' },
    { k: 'radio', t: 'num', e: 'Radio (m)', def: 5, paso: 0.5, min: 1 },
    { k: 'dano', t: 'num', e: 'Daño', def: 40, paso: 5, min: 0, ayuda: 'Onda: el golpe (la mitad en el borde) · Aura: por segundo' },
    { k: 'tipoDano', t: 'sel', e: 'Tipo de daño', def: 'magico',
      op: [['normal', 'Normal'], ['explosivo', 'Explosivo'], ['fuego', 'Fuego'], ['electrico', 'Eléctrico'], ['magico', 'Mágico'], ['hielo', 'Hielo'], ['veneno', 'Veneno']] },
    { k: 'empuje', t: 'num', e: 'Empujón', def: 8, paso: 1, min: 0, ayuda: 'Cuánto lanza hacia fuera a los enemigos (el aura empuja poco)' },
    { k: 'crecer', t: 'num', e: 'Tarda en crecer (s)', def: 0.35, paso: 0.05, min: 0.05, si: (v) => v.forma !== 'aura' },
    { k: 'dura', t: 'num', e: 'Dura (s)', def: 4, paso: 0.5, min: 0.5, si: (v) => v.forma === 'aura' },
    { k: 'recarga', t: 'num', e: 'Recarga (s)', def: 8, paso: 0.5, min: 0, ayuda: 'Segundos hasta poder usarlo otra vez (desde que se lanza)' },
    { k: 'estilo', t: 'sel', e: 'Aspecto', def: 'ondas', op: [['ondas', '〰 Ondas + borde brillante'], ['hex', '⬡ Rejilla de hexágonos'], ['rayos', '⚡ Rayos eléctricos'], ['anillos', '◎ Anillos que recorren'], ['plasma', '🔥 Plasma que fluye']] },
    { k: 'color', t: 'color', e: 'Color', def: '#c08cff' },
    { k: 'pulso', t: 'bool', e: '◎ Pulso (2 esferas)', def: false, ayuda: 'Sale una segunda esfera detrás de la primera (onda) o una que late hacia fuera una y otra vez (aura). Solo se ve: no hace más daño' },
    { k: 'aviso', t: 'bool', e: 'Indicador en pantalla', def: true, ayuda: '✸ con la tecla cuando está listo, o los segundos que faltan' },
  ],

  iniciar(j, p, s) {
    s.cd = 0;
    s.txt = '';
    if (p.aviso !== false && FORJA.Hud) {
      s.el = FORJA.Hud.pieza(j.juego, 'fh-especial', '');
      s.el.style.cssText += ';font-size:1.25em;text-shadow:.1em .1em 0 #000';
    }
  },

  entrada(j, p, s, dt) {
    if (s.cd > 0) s.cd = Math.max(0, s.cd - dt);
    const E = FORJA.Entrada;
    if (!j.muerto && !j.sinControl && E.pulsado('especial') && s.cd <= 0 && FORJA.Area) {
      FORJA.Area.lanzar(j.juego, j, { forma: p.forma, radio: p.radio, dano: p.dano, tipoDano: p.tipoDano, empuje: p.empuje,
        crecer: p.crecer, dura: p.dura, estilo: p.estilo, color: p.color, pulso: !!p.pulso });
      s.cd = Math.max(0, p.recarga || 0);
      if (p.forma === 'aura') s.cd = Math.max(s.cd, p.dura || 0);   // el aura no se encima consigo misma
    }
    // indicador: solo se toca el HTML cuando cambia
    if (s.el) {
      const tecla = E.textoTeclado ? (E.textoTeclado('especial') || 'B') : 'B';
      const t = s.cd > 0 ? `<span style="color:${p.color};opacity:.5">✸</span> <small>${Math.ceil(s.cd)}s</small>` : `<span style="color:${p.color}">✸</span> <small>${tecla}</small>`;
      if (t !== s.txt) { s.txt = t; s.el.innerHTML = t; }
    }
  },

  detener(j, p, s) {
    if (s && s.el) s.el.remove();
  },
});
