/* Módulo SOMBRA — la "mancha" oscura bajo el jugador, como en Mario 64 o Crash.
   Barata (un círculo) y funciona aunque "Luces y sombras" esté apagado. Ayuda mucho a calcular los saltos.
   Con sombras del sol encendidas, el modelo en tercera persona además hace su sombra real. */
FORJA.registrarModulo({
  nombre: 'sombra',
  etiqueta: 'Sombra (mancha)',
  descripcion: 'Círculo oscuro en el suelo, debajo del jugador. Ayuda a ver dónde vas a caer.',
  orden: 65,
  activoPorDefecto: false,
  props: [
    { k: 'tamano', t: 'num', e: 'Tamaño (m)', def: 0.9, paso: 0.05, min: 0.1 },
    { k: 'opacidad', t: 'rango', e: 'Oscuridad', def: 0.55, min: 0, max: 1, paso: 0.05 },
    { k: 'encoger', t: 'bool', e: 'Encoger al subir', def: true, ayuda: 'Más chica cuanto más alto saltas' },
    { k: 'alturaMax', t: 'num', e: 'Altura máxima (m)', def: 12, paso: 1, ayuda: 'Más arriba que esto, ya no se ve' },
  ],

  iniciar(j, p, s) {
    const T = THREE;
    // Círculo con borde suave, en 8 colores (se ve "de época", no un degradado perfecto)
    const c = document.createElement('canvas');
    c.width = c.height = 32;
    const g = c.getContext('2d');
    for (let i = 8; i >= 1; i--) {
      g.fillStyle = `rgba(0,0,0,${Math.min(1, (9 - i) / 5)})`;
      g.beginPath();
      g.arc(16, 16, (i / 8) * 15, 0, Math.PI * 2);
      g.fill();
    }
    const tex = new T.CanvasTexture(c);
    tex.magFilter = T.NearestFilter;
    s.mat = new T.MeshBasicMaterial({ map: tex, transparent: true, depthWrite: false, opacity: p.opacidad,
      polygonOffset: true, polygonOffsetFactor: -4, polygonOffsetUnits: -4 });
    s.obj = new T.Mesh(new T.PlaneGeometry(1, 1).rotateX(-Math.PI / 2), s.mat);
    s.obj.renderOrder = 5;
    j.escena.add(s.obj);
  },

  despues(j, p, s) {
    const c = j.cuerpo, m = j.mundo;
    const g = m.rayo(c.pie.x, c.pie.y + 0.2, c.pie.z, 0, -1, 0, p.alturaMax + 0.2);
    if (!g) { s.obj.visible = false; return; }
    const alto = Math.max(0, g.t - 0.2);
    s.obj.visible = true;
    s.obj.position.set(c.pie.x, c.pie.y + 0.2 - g.t + 0.02, c.pie.z);
    const k = p.encoger ? Math.max(0.35, 1 - alto / p.alturaMax) : 1;
    s.obj.scale.setScalar(p.tamano * k);
    s.mat.opacity = p.opacidad * (p.encoger ? Math.max(0.3, 1 - alto / p.alturaMax) : 1);
  },

  detener(j, p, s) {
    if (s.obj) { j.escena.remove(s.obj); s.obj.geometry.dispose(); s.mat.map.dispose(); s.mat.dispose(); }
  },
});
