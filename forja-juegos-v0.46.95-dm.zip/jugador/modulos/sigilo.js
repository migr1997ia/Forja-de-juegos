/* Módulo SIGILO — ejecución silenciosa (como en el FW: stealth kill).
   Acércate por la espalda a un enemigo que no te ha visto: sale "E: Ejecutar"; al pulsar usar (E / X / ✋) muere
   de un golpe y sin ruido (los demás no se enteran). Cada enemigo dice si se le puede ejecutar (Inspector ▸ Percibir).
   Se revisa 10 veces por segundo. Avisa con F.emitir('enemigo-ejecutado', E). */
FORJA.registrarModulo({
  nombre: 'sigilo',
  etiqueta: 'Sigilo (ejecutar)',
  descripcion: 'Por la espalda y sin que te vean: "Ejecutar" mata de un golpe y en silencio.',
  orden: 49,
  activoPorDefecto: false,
  props: [
    { k: 'distancia', t: 'num', e: 'Distancia (m)', def: 1.6, paso: 0.1, min: 0.5 },
    { k: 'angulo', t: 'num', e: 'Ángulo por la espalda (°)', def: 100, paso: 10, min: 30, max: 300, ayuda: 'Cuánto de su espalda vale: 90 = justo detrás, 180 = medio lado' },
    { k: 'texto', t: 'texto', e: 'Texto del aviso', def: 'Ejecutar' },
    { k: 'soloAgachado', t: 'bool', e: 'Solo agachado', def: false, ayuda: 'Como en los juegos de sigilo: hay que ir agachado para que salga' },
    { k: 'sonido', t: 'asset', e: 'Sonido', def: '', tipoAsset: 'audio', vacio: '(golpe sordo del motor)' },
  ],

  iniciar(j, p, s) {
    s.reloj = 0;
    s.blanco = null;
    s.aviso = FORJA.Hud.pieza(j.juego, 'fh-aviso');
    s.aviso.style.display = 'none';
    s.j = j;
  },

  entrada(j, p, s, dt) {
    const EN = j.juego.enemigos;
    if (!EN || j.muerto) { this._poner(s, null, p); return; }
    s.reloj -= dt;
    if (s.reloj <= 0) {
      s.reloj = 0.1;
      let mejor = null, md = 1e9;
      if (!p.soloAgachado || j.agachado) {
        for (const E of EN.lista) {
          if (!EN.ejecutable(E, j, p.distancia, p.angulo)) continue;
          const d = Math.hypot(E.cuerpo.pie.x - j.cuerpo.pie.x, E.cuerpo.pie.z - j.cuerpo.pie.z);
          if (d < md) { md = d; mejor = E; }
        }
      }
      this._poner(s, mejor, p);
    }
    if (s.blanco && FORJA.Entrada.pulsado('interactuar')) {
      if (!EN.ejecutable(s.blanco, j, p.distancia + 0.3, p.angulo + 20)) { this._poner(s, null, p); return; }
      if (p.sonido) FORJA.Audio.efecto(p.sonido);
      EN.ejecutar(s.blanco);
      j.sinInteractuar = 0.3;   // que el mismo pulso no abra también una puerta o un cartel
      FORJA.emitir('disparo', { jugador: j, arma: { tipo: 'cuerpo', nombre: 'cuchillo', cuerpo3p: 'entero' } });   // el modelo hace su golpe
      this._poner(s, null, p);
    }
  },

  _poner(s, E, p) {
    if (s.blanco === E) return;
    s.blanco = E;
    const tecla = FORJA.Tactil && FORJA.Tactil.visible ? '' : FORJA.Entrada.textoTeclado('interactuar').split(' / ')[0] + ': ';
    s.aviso.textContent = E ? '🗡 ' + tecla + p.texto : '';
    s.aviso.style.display = E ? 'block' : 'none';
    if (FORJA.Tactil) FORJA.Tactil.ponerContexto('interactuar', !!E);
    s.j && (s.j.blancoSigilo = E);
  },

  despues(j, p, s, dt) { if (j.sinInteractuar > 0) j.sinInteractuar -= dt; },

  detener(j, p, s) { if (s.aviso) s.aviso.remove(); j.blancoSigilo = null; },
});
