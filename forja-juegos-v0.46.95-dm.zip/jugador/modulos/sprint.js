/* Módulo SPRINT — correr manteniendo Shift / L3 / LB.
   Equivale a tu sprint_module.gd. */
FORJA.registrarModulo({
  nombre: 'sprint',
  etiqueta: 'Correr',
  descripcion: 'Multiplica la velocidad mientras se mantiene la acción "correr".',
  orden: 15,
  props: [
    { k: 'multiplicador', t: 'num', e: 'Multiplicador', def: 1.65, paso: 0.05 },
    { k: 'soloAdelante', t: 'bool', e: 'Solo hacia adelante', def: false, ayuda: 'Como en muchos FPS: no se corre de lado ni hacia atrás' },
  ],

  entrada(j, p) {
    const E = FORJA.Entrada;
    if (!E.mantenido('correr')) return;
    if (p.soloAdelante && E.mover.y < 0.3) return;
    j.corriendo = true;
    j.modVelocidad *= p.multiplicador;
  },
});
