/* =========================================================
   FORJA · JUGADOR
   Orquestador de módulos (como tu player_fps.gd con su carpeta Modules/).
   Cada cuadro:
     1. entrada()  de cada módulo activo  → leer controles, decidir intenciones
     2. fisica()   de cada módulo activo  → cambiar la velocidad del cuerpo
     3. cuerpo.moverYDeslizar(dt)         → ≈ move_and_slide()
     4. despues()  de cada módulo activo  → cámara, modelo, animación, efectos
   ========================================================= */
(function (F) {
  'use strict';
  const T = THREE;

  class Jugador {
    constructor(juego) {
      this.juego = juego;
      this.mundo = juego.mundo;
      this.escena = juego.vista.escena;
      this.camara = juego.camara;
      this.cfg = juego.proyecto.jugador.modulos;

      const pc = this.cfg.cuerpo || {};
      this.cuerpo = new F.Fisica.CuerpoCinematico(this.mundo, pc);
      this.alturaOjos = pc.alturaOjos ?? 1.6;

      // Estado compartido entre módulos
      this.yaw = 0;                       // giro horizontal de la vista (radianes)
      this.pitch = 0;                     // giro vertical
      this.modoCamara = 'fps';            // 'fps' | 'tps'
      this.direccion = new T.Vector3();   // hacia dónde quiere moverse (mundo, largo 0..1)
      this.modVelocidad = 1;              // multiplicador de este cuadro (sprint, agacharse…)
      this.corriendo = false;
      this.saltando = false;
      this.modelo = null;
      // Fase 1 (v0.8): estado que comparten salud, agacharse, esquiva, interactuar…
      this.sinControl = false;            // muerto, leyendo un mensaje…: no se mueve ni pulsa nada
      this.muerto = false;
      this.agachado = false;
      this.esquivando = false;
      this.bajarCamara = 0;               // metros que baja la cámara de 3ª persona (agacharse, morir)
      this.pulsoContinuar = false;        // este cuadro se pulsó interactuar / saltar / atacar (para cerrar mensajes)
      this.danar = null;                  // lo pone el módulo Salud: danar(cantidad, origen)

      this.activos = F.modulosOrdenados().filter((m) => m.obligatorio || (this.cfg[m.nombre] && this.cfg[m.nombre].activo));
      this.estados = {};
      for (const m of this.activos) this.estados[m.nombre] = {};

      this.puntoInicio = new T.Vector3();
      this.yawInicio = 0;
      this.saltos = 0;                    // sube en cada teletransporte (llegar a un nivel, reaparecer): Salud no lo cuenta como caída
      this.limiteY = (this.mundo.n ? this.mundo.cajas[1] : 0) - 30;
    }

    props(nombre) {
      return this.cfg[nombre] || {};
    }

    tieneModulo(nombre) {
      return this.activos.some((m) => m.nombre === nombre);
    }

    _llamar(fase, dt) {
      for (const m of this.activos) {
        const fn = m[fase];
        if (!fn) continue;
        if (this.montado && F.Montables.SALTAR.has(m.nombre)) continue;   // 🐎 montado: no camina, no se agacha…
        try {
          fn.call(m, this, this.props(m.nombre), this.estados[m.nombre], dt);
        } catch (err) {
          console.error(`[FORJA] módulo "${m.nombre}" falló en ${fase}`, err);
        }
      }
    }

    iniciar(pos, yaw) {
      this.puntoInicio.copy(pos);
      this.yawInicio = yaw;
      this.reaparecer();
      this._llamar('iniciar', 0);
    }

    reaparecer() {
      this.teletransportar(this.puntoInicio.x, this.puntoInicio.y, this.puntoInicio.z, this.yawInicio, 0);
    }

    // Mover al jugador de golpe (sin que cuente como caída)
    teletransportar(x, y, z, yaw = this.yaw, pitch = this.pitch) {
      this.cuerpo.teletransportar(x, y, z);
      this.yaw = yaw;
      this.pitch = pitch;
      this.saltos++;
    }

    actualizar(dt) {
      this.modVelocidad = 1;
      this.corriendo = false;
      const E = F.Entrada;
      this.pulsoUsar = E.pulsado('interactuar');
      this.pulsoContinuar = this.pulsoUsar || E.pulsado('saltar') || E.pulsado('atacar');
      if (this.sinControl) E.neutralizar();
      this._llamar('entrada', dt);
      this._llamar('fisica', dt);
      if (this.montado) this.juego.montables.conducir(this, dt);
      if (!(this.montado && this.montado.fijo)) this.cuerpo.moverYDeslizar(dt);
      if (this.cuerpo.pie.y < this.limiteY) {
        // caer al vacío: con Salud es morir; sin Salud, volver al inicio como siempre
        if (this.danar) {
          if (!this.muerto) this.danar(1e9, 'vacio');
          this.cuerpo.velocidad.set(0, 0, 0);
          this.cuerpo.pie.y = this.limiteY;
        } else {
          this.reaparecer();
        }
      }
      this._llamar('despues', dt);
    }

    detener() {
      this._llamar('detener', 0);
    }
  }

  F.Jugador = Jugador;
})(window.FORJA);
