/* =========================================================
   EDITOR · PRINCIPAL
   Visor, escenas, árbol de jerarquía, archivos, cámara de vuelo,
   colocar sobre superficie, deshacer, probar, guardar y exportar.
   ========================================================= */
(function (F) {
  'use strict';
  const T = THREE;
  const Ed = (F.Editor = F.Editor || {});
  const $ = (id) => document.getElementById(id);
  const S = F.Escena;
  const DEG = F.DEG;
  const fmt = F.util.fmt;

  /* ---------- Avisos ---------- */
  Ed.toast = function (html, tipo = '') {
    const el = document.createElement('div');
    el.className = 'toast ' + tipo;
    el.innerHTML = html;
    $('toasts').appendChild(el);
    setTimeout(() => el.remove(), tipo === 'error' ? 7000 : 4000);
  };
  F.on('aviso', (html, tipo) => Ed.toast(html, tipo));

  /* ---------- Estado ---------- */
  Ed.proyecto = S.proyectoNuevo();
  Ed.escena = Ed.proyecto.escenas[0];     // escena que se está editando
  Ed.objetos = new Map();                 // id de entidad → Object3D
  Ed.seleccion = null;                    // id de la entidad principal seleccionada (la última que se tocó)
  Ed.seleccionados = new Set();           // todas las seleccionadas (Ctrl/Shift + clic, Shift + arrastrar)
  Ed.assetSeleccionado = null;            // id de archivo mostrado en el inspector
  Ed.jugando = false;
  Ed.juego = null;
  const ents = () => Ed.escena.entidades;
  const buscar = (id) => ents().find((e) => e.id === id);

  let temporizadorGuardado = 0;
  Ed.guardarLocal = function () {
    if (Ed.Proyectos) Ed.Proyectos.marcarSucio();
    pedirLuces();
    clearTimeout(temporizadorGuardado);
    temporizadorGuardado = setTimeout(() => {
      F.Assets.DB.poner('proyecto', { id: 'actual', datos: JSON.stringify(Ed.proyecto) }).catch(() => {});
    }, 600);
  };

  /* ---------- Deshacer / rehacer (por escena) ---------- */
  const pilaDeshacer = [], pilaRehacer = [];
  const foto = () => JSON.stringify({ escena: Ed.escena.id, entidades: ents() });
  Ed.marcarCambio = function () {
    pilaDeshacer.push(foto());
    if (pilaDeshacer.length > 100) pilaDeshacer.shift();
    pilaRehacer.length = 0;
  };
  function restaurar(json) {
    const f = JSON.parse(json);
    const esc = Ed.proyecto.escenas.find((s) => s.id === f.escena);
    if (!esc) return;
    esc.entidades = f.entidades;
    if (esc !== Ed.escena) cambiarEscena(esc.id, false);
    else reconstruirEscena();
    Ed.guardarLocal();
  }
  function deshacer() { if (pilaDeshacer.length) { pilaRehacer.push(foto()); restaurar(pilaDeshacer.pop()); } }
  function rehacer() { if (pilaRehacer.length) { pilaDeshacer.push(foto()); restaurar(pilaRehacer.pop()); } }
  Ed.deshacer = deshacer;
  Ed.rehacer = rehacer;

  /* =========================================================
     VISOR
     ========================================================= */
  const vista = (Ed.vista = new F.Render.Vista($('vista')));
  // 🌾 el pasto de los materiales también se ve en el editor (se vuelve a sembrar tras cada cambio)
  const rehacerPasto = () => {};   // 🌾 pasto apagado por ahora
  { const g0 = Ed.guardarLocal; Ed.guardarLocal = function () { g0.apply(this, arguments); rehacerPasto(); }; }
  const lienzo = vista.renderer.domElement;
  const raiz = vista.escena;
  const camEditor = new T.PerspectiveCamera(60, 1, 0.05, 3000);
  Ed.camaraEditor = camEditor;
  camEditor.position.set(10, 9, 14);
  vista.usarCamara(camEditor);

  /* Vistas superior / frontal / lateral: cámara ortográfica (sin perspectiva, como planos).
     En ellas el clic izquierdo desplaza y la rueda hace zoom; para girar se vuelve a Perspectiva. */
  const camOrto = new T.OrthographicCamera(-10, 10, 10, -10, -5000, 5000);
  camOrto.userData.mitadAlto = 10;
  vista.usarCamara(camOrto);
  const VISTAS = {
    persp: { nombre: 'Perspectiva' },
    superior: { nombre: 'Superior', dir: [0, 1, 0.0001] },
    frontal: { nombre: 'Frontal', dir: [0, 0, 1] },
    lateral: { nombre: 'Lateral', dir: [1, 0, 0] },
  };
  let vistaActual = 'persp';
  const ofsPersp = new T.Vector3();   // dónde estaba la cámara en perspectiva respecto al punto de giro
  const camVista = () => (vistaActual === 'persp' ? camEditor : camOrto);
  Ed.camVista = camVista;
  Ed.vistaActual = () => vistaActual;

  const rejilla = new T.GridHelper(100, 100, 0x55607a, 0x2c3240);
  rejilla.material.transparent = true;
  rejilla.material.opacity = 0.6;
  rejilla.material.fog = false;
  raiz.add(rejilla);

  const orbit = new T.OrbitControls(camEditor, lienzo);
  orbit.enableDamping = true;
  orbit.dampingFactor = 0.15;
  // izquierdo = girar · rueda pulsada = desplazar · derecho = cámara de vuelo (abajo)
  orbit.mouseButtons = { LEFT: T.MOUSE.ROTATE, MIDDLE: T.MOUSE.PAN, RIGHT: -1 };
  // Límites del zoom: ni pegarse al punto de giro ni irse más allá de lo que se dibuja
  orbit.minDistance = 0.2;
  orbit.maxDistance = 1500;
  orbit.minZoom = 0.01;
  orbit.maxZoom = 200;

  /* Seguro: si la cámara quedó con valores imposibles (NaN / infinito), se vuelve a una vista normal.
     Pasaba con el zoom del navegador por debajo de 100 %: la rueda dividía entre cero (error de Three r160, ya parchado). */
  const valido = (v) => Number.isFinite(v.x) && Number.isFinite(v.y) && Number.isFinite(v.z);
  function repararCamara() {
    const cams = [camEditor, camOrto];
    const malo = !valido(orbit.target) || cams.some((c) => !valido(c.position) || !Number.isFinite(c.quaternion.w) || !Number.isFinite(c.zoom));
    if (!malo) return false;
    if (!valido(orbit.target)) orbit.target.set(0, 0, 0);
    camEditor.position.copy(orbit.target).add(new T.Vector3(10, 9, 14));
    camEditor.quaternion.identity();
    camEditor.lookAt(orbit.target);
    camOrto.zoom = 1;
    camOrto.position.copy(orbit.target).add(new T.Vector3(0, 1000, 0.1));
    camOrto.lookAt(orbit.target);
    camOrto.updateProjectionMatrix();
    ofsPersp.set(10, 9, 14);
    orbit.update();
    Ed.toast('La cámara del visor se había perdido: la regresé a una vista normal');
    return true;
  }

  const gizmo = new T.TransformControls(camEditor, lienzo);
  gizmo.setSize(0.9);
  raiz.add(gizmo);
  // Con varios seleccionados el gizmo mueve este punto (en su centro) y ellos lo siguen
  const pivote = new T.Group();
  pivote.name = 'pivote-seleccion';
  raiz.add(pivote);
  let inicioMulti = null;

  Ed.ponerVista = function (tipo) {
    if (Ed.jugando || !VISTAS[tipo]) return;
    const antes = vistaActual;
    if (antes === 'persp' && tipo !== 'persp') ofsPersp.copy(camEditor.position).sub(orbit.target);
    vistaActual = tipo;
    if (tipo === 'persp') {
      camEditor.position.copy(orbit.target).add(ofsPersp.lengthSq() ? ofsPersp : new T.Vector3(8, 7, 10));
      orbit.object = camEditor;
      gizmo.camera = camEditor;
      orbit.enableRotate = true;
      orbit.mouseButtons = { LEFT: T.MOUSE.ROTATE, MIDDLE: T.MOUSE.PAN, RIGHT: -1 };
      rejilla.rotation.set(0, 0, 0);
    } else {
      // al entrar desde perspectiva, el zoom muestra más o menos lo mismo que se veía
      if (antes === 'persp') camOrto.zoom = camOrto.userData.mitadAlto / Math.max(0.5, ofsPersp.length() * Math.tan(30 * DEG));
      camOrto.position.copy(orbit.target).add(new T.Vector3(...VISTAS[tipo].dir).normalize().multiplyScalar(1000));
      camOrto.lookAt(orbit.target);
      camOrto.updateProjectionMatrix();
      orbit.object = camOrto;
      gizmo.camera = camOrto;
      orbit.enableRotate = false;
      orbit.mouseButtons = { LEFT: T.MOUSE.PAN, MIDDLE: T.MOUSE.PAN, RIGHT: -1 };
      // la rejilla se pone de frente a la cámara
      if (tipo === 'frontal') rejilla.rotation.set(Math.PI / 2, 0, 0);
      else if (tipo === 'lateral') rejilla.rotation.set(0, 0, Math.PI / 2);
      else rejilla.rotation.set(0, 0, 0);
    }
    orbit.update();
    Ed.aplicarAjustes();
    const sel = $('selVista');
    if (sel) sel.value = tipo;
    F.emitir('editor-vista', tipo);
  };

  let espacioLocal = false;
  Ed.alternarEspacio = function (local = !espacioLocal) {
    espacioLocal = local;
    gizmo.setSpace(local ? 'local' : 'world');
    const b = $('btnEspacio');
    if (b) {
      b.textContent = local ? '⬚ Local' : '🌐 Global';
      b.classList.toggle('activo', local);
    }
  };
  let snapActivo = true;
  // con imán (G): 0,25 m · 15° · 0,1 · sin imán: 0,1 m · 1° · 0,05 · con Shift mientras arrastras: fino (0,01 m · 0,5°)
  let fino = false;
  function aplicarSnap() {
    gizmo.setTranslationSnap(fino ? 0.01 : snapActivo ? 0.25 : 0.1);
    gizmo.setRotationSnap((fino ? 0.5 : snapActivo ? 15 : 1) * DEG);
    gizmo.setScaleSnap(fino ? 0.01 : snapActivo ? 0.1 : 0.05);
    $('btnSnap').classList.toggle('activo', snapActivo);
  }
  aplicarSnap();
  addEventListener('keydown', (e) => { if (e.key === 'Shift' && !fino) { fino = true; aplicarSnap(); } });
  addEventListener('keyup', (e) => { if (e.key === 'Shift' && fino) { fino = false; aplicarSnap(); } });
  addEventListener('blur', () => { if (fino) { fino = false; aplicarSnap(); } });
  gizmo.addEventListener('dragging-changed', (e) => { orbit.enabled = !e.value; });
  gizmo.addEventListener('mouseDown', () => {
    Ed.marcarCambio();
    if (gizmo.object !== pivote) return;
    // foto de dónde estaba cada uno al empezar a arrastrar
    pivote.updateMatrixWorld(true);
    inicioMulti = { inversa: pivote.matrixWorld.clone().invert(), mundos: [] };
    for (const id of raicesSeleccion()) {
      const o = Ed.objetos.get(id);
      if (!o) continue;
      o.updateMatrixWorld(true);
      inicioMulti.mundos.push([id, o.matrixWorld.clone()]);
    }
  });
  gizmo.addEventListener('objectChange', () => {
    const obj = gizmo.object;
    if (obj === pivote) { moverVarios(); return; }
    const ent = obj && buscar(obj.userData.entId);
    if (!ent) return;
    leerTransform(obj, ent);
    Ed.actualizarCamposTransform(ent);
    Ed.guardarLocal();
  });

  // Aplica a cada seleccionado lo que se movió / giró / escaló el pivote
  function moverVarios() {
    if (!inicioMulti) return;
    pivote.updateMatrixWorld(true);
    const delta = new T.Matrix4().multiplyMatrices(pivote.matrixWorld, inicioMulti.inversa);
    const m = new T.Matrix4(), inv = new T.Matrix4();
    for (const [id, m0] of inicioMulti.mundos) {
      const o = Ed.objetos.get(id), ent = buscar(id);
      if (!o || !ent) continue;
      o.parent.updateMatrixWorld(true);
      m.multiplyMatrices(delta, m0).premultiply(inv.copy(o.parent.matrixWorld).invert());
      m.decompose(o.position, o.quaternion, o.scale);
      leerTransform(o, ent);
    }
    Ed.guardarLocal();
  }

  function leerTransform(obj, ent) {
    ent.pos = obj.position.toArray().map((v) => +v.toFixed(2));
    ent.rot = [obj.rotation.x, obj.rotation.y, obj.rotation.z].map((v) => +(v / DEG).toFixed(2));
    ent.esc = obj.scale.toArray().map((v) => +v.toFixed(3));
  }

  Ed.aplicarAjustes = function () {
    const aj = Ed.proyecto.ajustes;
    const retro = Ed.jugando || aj.vistaRetroEditor;
    // en vistas orto no hay niebla (la cámara está lejísimos y todo saldría nublado)
    vista.aplicar(aj, Ed.escena.ambiente, retro, (retro || aj.nieblaEditor) && vistaActual === 'persp');
    if (Ed.pintarBotonLuces) Ed.pintarBotonLuces();
  };

  /* ---------- Cámara de vuelo: clic derecho + WASD (Q/E bajar/subir, Shift rápido) ---------- */
  const vuelo = { activo: false, yaw: 0, pitch: 0, vel: 8, teclas: new Set() };
  lienzo.addEventListener('contextmenu', (e) => e.preventDefault());
  lienzo.addEventListener('mousedown', (e) => {
    if (e.button !== 2 || Ed.jugando) return;
    if (vistaActual !== 'persp') Ed.ponerVista('persp');   // volar siempre es en perspectiva
    vuelo.activo = true;
    const eul = new T.Euler().setFromQuaternion(camEditor.quaternion, 'YXZ');
    vuelo.yaw = eul.y;
    vuelo.pitch = eul.x;
    orbit.enabled = false;
  });
  window.addEventListener('mouseup', (e) => {
    if (e.button !== 2 || !vuelo.activo) return;
    vuelo.activo = false;
    vuelo.teclas.clear();
    // el punto de giro queda delante de la cámara
    const dist = Math.max(2, camEditor.position.distanceTo(orbit.target));
    orbit.target.copy(camEditor.position).add(new T.Vector3(0, 0, -1).applyQuaternion(camEditor.quaternion).multiplyScalar(dist));
    orbit.enabled = true;
  });
  window.addEventListener('mousemove', (e) => {
    if (!vuelo.activo) return;
    vuelo.yaw -= e.movementX * 0.003;
    vuelo.pitch = F.util.clamp(vuelo.pitch - e.movementY * 0.003, -1.55, 1.55);
    camEditor.rotation.set(vuelo.pitch, vuelo.yaw, 0, 'YXZ');
  });
  lienzo.addEventListener('wheel', (e) => {
    if (!vuelo.activo) return;
    vuelo.vel = F.util.clamp(vuelo.vel * (e.deltaY < 0 ? 1.2 : 0.83), 1, 120);
    Ed.toast(`Velocidad de vuelo: ${vuelo.vel.toFixed(1)} m/s`);
  }, { passive: true });
  function actualizarVuelo(dt) {
    if (!vuelo.activo) return;
    const k = vuelo.teclas;
    const v = new T.Vector3((k.has('KeyD') ? 1 : 0) - (k.has('KeyA') ? 1 : 0), (k.has('KeyE') ? 1 : 0) - (k.has('KeyQ') ? 1 : 0),
      (k.has('KeyS') ? 1 : 0) - (k.has('KeyW') ? 1 : 0));
    if (!v.lengthSq()) return;
    v.normalize().multiplyScalar(vuelo.vel * (k.has('ShiftLeft') || k.has('ShiftRight') ? 3 : 1) * dt);
    const avance = new T.Vector3(v.x, 0, v.z).applyQuaternion(camEditor.quaternion);
    camEditor.position.add(avance);
    camEditor.position.y += v.y;
  }

  /* =========================================================
     OBJETOS DE LA ESCENA (con jerarquía)
     ========================================================= */
  function objetoPadre(ent) {
    return (ent.padre && Ed.objetos.get(ent.padre)) || raiz;
  }

  function crearObjeto(ent) {
    const obj = S.crearObjeto(ent, Ed.proyecto);
    Ed.objetos.set(ent.id, obj);
    objetoPadre(ent).add(obj);
    return obj;
  }

  function quitarObjeto(id) {
    const obj = Ed.objetos.get(id);
    if (!obj) return;
    if (gizmo.object === obj) gizmo.detach();
    obj.parent && obj.parent.remove(obj);
    S.liberarObjeto(obj);
    Ed.objetos.delete(id);
  }

  Ed.reconstruirEscena = () => reconstruirEscena();
  function reconstruirEscena() {
    gizmo.detach();
    for (const obj of Ed.objetos.values()) { obj.parent && obj.parent.remove(obj); S.liberarObjeto(obj); }
    Ed.objetos = S.construirEscena(Ed.escena, raiz, Ed.proyecto);
    Ed.seleccionados = new Set([...Ed.seleccionados].filter((id) => Ed.objetos.has(id)));
    if (Ed.seleccion && !Ed.objetos.has(Ed.seleccion)) Ed.seleccion = [...Ed.seleccionados].pop() || null;
    refrescarSeleccion();
    Ed.pintarArbol();
    F.emitir('escena-reconstruida');
  }

  // Rehace el objeto de una entidad conservando a sus hijos
  Ed.reconstruirEntidad = function (ent) {
    const viejo = Ed.objetos.get(ent.id);
    const nuevo = S.crearObjeto(ent, Ed.proyecto);
    Ed.objetos.set(ent.id, nuevo);
    objetoPadre(ent).add(nuevo);
    if (viejo) {
      for (const h of [...viejo.children]) if (h.userData.entId) nuevo.add(h);
      viejo.parent && viejo.parent.remove(viejo);
      S.liberarObjeto(viejo);
    }
    if (Ed.seleccionados.has(ent.id) && !Ed.jugando) engancharGizmo();
    F.emitir('entidad-reconstruida', ent);
  };

  Ed.refrescarMarcadorInicio = function () {
    for (const e of ents()) if (e.tipo === 'inicio') Ed.reconstruirEntidad(e);
  };

  // Tras cambiar materiales de un modelo: actualizar la prioridad de dibujo en sus copias
  Ed.actualizarUsosModelo = function (idAsset) {
    for (const e of ents()) {
      const o = e.asset === idAsset && Ed.objetos.get(e.id);
      if (!o) continue;
      F.Render.aplicarPrioridad(o);
      F.Luces.aplicarSombras(o, e.sombra !== false);   // un material que pasó a translúcido ya no hace sombra
    }
  };

  /* ---------- Luces y sombras en el editor ----------
     Se ven igual que en el juego. Las fuentes se vuelven a juntar cuando cambia la escena. */
  var temporizadorLuces = 0;   // var: guardarLocal puede llamar antes de llegar aquí
  function refrescarLuces() {
    if (!vista.luces || Ed.partida) return;
    vista.luces.registrar(ents(), Ed.objetos);
    if (Ed.actualizarAvisosLuces) Ed.actualizarAvisosLuces();
  }
  if (vista.luces) vista.luces.mostrarMarcas = true;   // puntos donde los materiales ponen luces (solo en el editor)
  function pedirLuces() {
    clearTimeout(temporizadorLuces);
    temporizadorLuces = setTimeout(refrescarLuces, 200);
  }
  F.on('escena-reconstruida', refrescarLuces);
  F.on('entidad-reconstruida', pedirLuces);
  Ed.refrescarLuces = refrescarLuces;
  Ed.alternarLuces = function (v = !Ed.proyecto.ajustes.lucesExtra) {
    Ed.proyecto.ajustes.lucesExtra = v;
    Ed.aplicarAjustes();
    if (Ed.jugando && Ed.juego) vista.aplicar(Ed.proyecto.ajustes, Ed.escena.ambiente, true, true);
    Ed.construirPanelProyecto();
    pintarBotonLuces();
    refrescarLuces();
    Ed.guardarLocal();
    Ed.toast(v ? '💡 Luces y sombras <b>encendidas</b> (ajustes en Proyecto)' : 'Luces y sombras <b>apagadas</b>: como siempre');
  };
  function pintarBotonLuces() {
    const b = $('btnLuces');
    if (b) b.classList.toggle('activo', !!Ed.proyecto.ajustes.lucesExtra);
  }
  Ed.pintarBotonLuces = pintarBotonLuces;

  /* ---------- Dónde colocar lo nuevo: sobre la superficie que mira la cámara ---------- */
  const rayo = new T.Raycaster();
  /* 🖐 Filtro de selección en el visor: con "solo luces", "solo objetos"… un clic atraviesa lo demás
     (las luces ya no estorban para acomodar cajas, ni al revés). El árbol sigue eligiendo todo. */
  const CAT_FILTRO = {
    luces: new Set(['luz', 'sonido', 'particulas']),
    zonas: new Set(['disparador', 'condicion', 'salida', 'guardado', 'aparecedor', 'marcador', 'punto', 'agua', 'inicio']),
    camaras: new Set(['camara']),
  };
  Ed.filtroSel = (() => { try { return localStorage.getItem('forja-editor:filtroSel') || 'todo'; } catch (e) { return 'todo'; } })();
  Ed.categoriaDe = (tipo) => (CAT_FILTRO.luces.has(tipo) ? 'luces' : CAT_FILTRO.zonas.has(tipo) ? 'zonas' : CAT_FILTRO.camaras.has(tipo) ? 'camaras' : 'objetos');
  Ed.sePuedeElegir = (ent) => !ent || Ed.filtroSel === 'todo' || Ed.categoriaDe(ent.tipo) === Ed.filtroSel;
  {
    const sf = $('selFiltro');
    if (sf) {
      sf.value = Ed.filtroSel;
      sf.classList.toggle('activo', Ed.filtroSel !== 'todo');
      sf.onchange = () => {
        Ed.filtroSel = sf.value;
        sf.classList.toggle('activo', Ed.filtroSel !== 'todo');
        try { localStorage.setItem('forja-editor:filtroSel', Ed.filtroSel); } catch (e) { /* nada */ }
        // lo elegido que ya no entra en el filtro se suelta
        const sel = buscar(Ed.seleccion);
        if (sel && !Ed.sePuedeElegir(sel)) seleccionar(null);
        sf.blur();
      };
    }
  }

  function objetosPickables(excluir) {
    const lista = [];
    for (const [id, o] of Ed.objetos) if (!excluir || !excluir.has(id)) lista.push(o);
    return lista;
  }
  function golpeEnPantalla(ndcX, ndcY, excluir) {
    rayo.setFromCamera(new T.Vector2(ndcX, ndcY), camVista());
    for (const g of rayo.intersectObjects(objetosPickables(excluir), true)) {
      if (g.object.userData.ayudaEditor || g.object.type === 'LineSegments') continue;
      let o = g.object;
      while (o && !o.userData.entId) o = o.parent;
      if (o && buscar(o.userData.entId)?.tipo === 'inicio') continue;
      return g.point;
    }
    // si no hay nada, el plano del suelo (y = 0)
    const p = new T.Vector3();
    return rayo.ray.intersectPlane(new T.Plane(new T.Vector3(0, 1, 0), 0), p) ? p : orbit.target.clone();
  }
  // En vistas orto, lo nuevo aparece en el punto de giro (centro de la pantalla) sobre el suelo
  function puntoNuevo() {
    if (vistaActual === 'persp') return golpeEnPantalla(0, 0);
    const p = orbit.target.clone();
    if (vistaActual === 'superior') {
      rayo.set(new T.Vector3(p.x, 1000, p.z), new T.Vector3(0, -1, 0));
      const g = rayo.intersectObjects(objetosPickables(), true).find((x) => !x.object.userData.ayudaEditor && x.object.type !== 'LineSegments');
      p.y = g ? g.point.y : 0;
    }
    return p;
  }
  const ajustar = (v) => (snapActivo ? Math.round(v * 4) / 4 : Math.round(v * 10) / 10);

  /* =========================================================
     CREAR, BORRAR, DUPLICAR, MOVER EN EL ÁRBOL
     ========================================================= */
  // punto: posición en el mundo (si no, donde mira la cámara). Si hay una carpeta seleccionada, va dentro.
  function agregarEntidad(tipo, extra = {}, punto = null) {
    Ed.marcarCambio();
    // ⚑ Puede haber varios: el primero es el principal (empezar el juego), los demás son llegadas desde otros niveles
    if (tipo === 'inicio' && ents().some((e) => e.tipo === 'inicio') && !(extra.inicio && extra.inicio.principal)) {
      const n = ents().filter((e) => e.tipo === 'inicio').length;
      extra = { nombre: n > 1 ? `Llegada ${n}` : 'Llegada', inicio: { principal: false }, ...extra };
    }
    const sel = buscar(Ed.seleccion);
    const padre = sel && sel.tipo === 'carpeta' ? sel : null;
    const mundo = punto ? punto.clone() : puntoNuevo();
    if (tipo === 'luz') mundo.y += 2;   // la luz aparece flotando, no pegada al suelo
    const local = padre ? Ed.objetos.get(padre.id).worldToLocal(mundo.clone()) : mundo;
    const ent = S.entidadNueva(tipo, { pos: [ajustar(local.x), +local.y.toFixed(3), ajustar(local.z)], padre: padre ? padre.id : '', ...extra });
    ents().push(ent);
    crearObjeto(ent);
    seleccionar(ent.id);
    Ed.pintarArbol();
    Ed.guardarLocal();
    return ent;
  }
  Ed.agregarEntidad = agregarEntidad;

  Ed.agregarModelo = function (idAsset, punto = null) {
    const a = F.Assets.mapa.get(idAsset);
    if (!a) return;
    const conAnim = a.gltf?.animations?.length > 0;
    agregarEntidad('modelo', { asset: a.id, nombre: a.nombre.replace(/\.[^.]+$/, ''), colision: conAnim ? 'ninguna' : 'malla' }, punto);
  };

  /* ---------- Ayudas para trabajar con varios a la vez ---------- */
  // Los seleccionados sin contar a los que ya van dentro de otro seleccionado (se mueven con su padre)
  function raicesSeleccion() {
    const sel = Ed.seleccionados;
    return ents().filter((e) => {
      if (!sel.has(e.id)) return false;
      let p = buscar(e.padre);
      while (p) { if (sel.has(p.id)) return false; p = buscar(p.padre); }
      return true;
    }).map((e) => e.id);
  }
  Ed.raicesSeleccion = raicesSeleccion;

  // Padres antes que hijos (para crear los objetos en orden)
  function porProfundidad(lista) {
    const ids = new Map(lista.map((e) => [e.id, e]));
    const prof = (e) => { let n = 0, p = ids.get(e.padre); while (p) { n++; p = ids.get(p.padre); } return n; };
    return lista.map((e) => [prof(e), e]).sort((x, y) => x[0] - y[0]).map((x) => x[1]);
  }

  // Copia de una entidad y sus hijos con ids nuevos. La raíz conserva su padre.
  function clonarSubarbol(id) {
    const mapaIds = new Map();
    const copias = S.subarbol(ents(), id).map((e) => {
      const c = F.util.copiar(e);
      mapaIds.set(e.id, (c.id = F.util.uid()));
      return c;
    });
    for (const c of copias) if (mapaIds.has(c.padre) && c.id !== mapaIds.get(id)) c.padre = mapaIds.get(c.padre);
    return { raiz: copias.find((c) => c.id === mapaIds.get(id)), copias: porProfundidad(copias) };
  }

  // Transformación de un objeto en el mundo → en espacio de su padre (para escribirla en la entidad)
  function transformMundo(obj) {
    const p = new T.Vector3(), q = new T.Quaternion(), s2 = new T.Vector3();
    obj.updateMatrixWorld(true);
    obj.matrixWorld.decompose(p, q, s2);
    return { p, q, s: s2 };
  }
  const redondear = (v, d = 3) => +v.toFixed(d);

  Ed.borrarSeleccion = function () {
    const raices = raicesSeleccion();
    if (!raices.length) return;
    const ids = new Set();
    for (const id of raices) for (const e of S.subarbol(ents(), id)) ids.add(e.id);
    const texto = raices.length === 1 ? `"${buscar(raices[0]).nombre}" y sus ${ids.size - 1} hijo(s)` : `${raices.length} objetos` + (ids.size > raices.length ? ` (con ${ids.size - raices.length} hijo(s))` : '');
    if (ids.size > 1 && !confirm(`¿Borrar ${texto}?`)) return;
    Ed.marcarCambio();
    for (const id of raices) quitarObjeto(id);
    for (const id of ids) Ed.objetos.delete(id);
    Ed.escena.entidades = ents().filter((e) => !ids.has(e.id));
    seleccionar(null);
    Ed.pintarArbol();
    Ed.guardarLocal();
  };

  // Ctrl+D: copia junto al original (con varios, cada uno con su copia)
  Ed.duplicarSeleccion = function () {
    const raices = raicesSeleccion().filter((id) => buscar(id).tipo !== 'inicio');
    if (!raices.length) return;
    Ed.marcarCambio();
    const nuevas = [];
    for (const id of raices) {
      const ent = buscar(id);
      const { raiz: r, copias } = clonarSubarbol(id);
      if (raices.length === 1) {
        r.nombre = ent.nombre + ' copia';
        r.pos = [ent.pos[0] + 1, ent.pos[1], ent.pos[2] + 1];
      }
      const ultimo = S.subarbol(ents(), id).pop();
      ents().splice(ents().indexOf(ultimo) + 1, 0, ...copias);
      for (const c of copias) crearObjeto(c);
      nuevas.push(r.id);
    }
    seleccionarVarios(nuevas);
    Ed.pintarArbol();
    Ed.guardarLocal();
  };

  /* Duplicar en fila: N copias separadas por un desplazamiento (en el mundo) y, si se quiere, girando cada una.
     Sirve para cercas, columnas, escaleras de caracol, filas de árboles… */
  Ed.duplicarEnFila = async function () {
    const raices = raicesSeleccion().filter((id) => buscar(id).tipo !== 'inicio');
    if (!raices.length) { Ed.toast('Selecciona primero lo que quieres repetir'); return; }
    const caja = new T.Box3();
    for (const id of raices) caja.expandByObject(Ed.objetos.get(id));
    const ancho = caja.isEmpty() ? 2 : Math.max(0.25, Math.round(caja.getSize(new T.Vector3()).x * 4) / 4);
    const v = await Ed.dialogo('Duplicar en fila', [
      { k: 'cantidad', t: 'num', e: 'Copias', def: 5, paso: 1, min: 1, ayuda: 'Cuántas copias nuevas (sin contar el original)' },
      { grupo: 'Separación entre copias (m, en el mundo)' },
      { k: 'dx', t: 'num', e: 'X', def: ancho, paso: 0.25 },
      { k: 'dy', t: 'num', e: 'Y (altura)', def: 0, paso: 0.25 },
      { k: 'dz', t: 'num', e: 'Z', def: 0, paso: 0.25 },
      { grupo: 'Giro' },
      { k: 'giroY', t: 'num', e: 'Girar cada una °', def: 0, paso: 5, ayuda: 'Ej. 15° con Y = 0.25 para una escalera de caracol' },
      { k: 'agrupar', t: 'bool', e: 'Meter en carpeta', def: true, ayuda: 'Original y copias quedan juntos en una carpeta nueva' },
    ], {}, 'Duplicar');
    if (!v) return;
    const n = Math.max(1, Math.min(500, Math.round(v.cantidad)));
    Ed.marcarCambio();
    const nuevas = [];
    const centro = caja.isEmpty() ? new T.Vector3() : caja.getCenter(new T.Vector3());
    for (let k = 1; k <= n; k++) {
      const desp = new T.Vector3(v.dx * k, v.dy * k, v.dz * k);
      const giro = new T.Quaternion().setFromAxisAngle(new T.Vector3(0, 1, 0), v.giroY * k * DEG);
      for (const id of raices) {
        const obj = Ed.objetos.get(id);
        const { raiz: r, copias } = clonarSubarbol(id);
        const { p, q, s: esc } = transformMundo(obj);
        // girar alrededor del centro de la selección y luego desplazar
        p.sub(centro).applyQuaternion(giro).add(centro).add(desp);
        q.premultiply(giro);
        const padre = obj.parent;
        padre.updateMatrixWorld(true);
        const local = new T.Matrix4().compose(p, q, esc).premultiply(padre.matrixWorld.clone().invert());
        const lp = new T.Vector3(), lq = new T.Quaternion(), ls = new T.Vector3();
        local.decompose(lp, lq, ls);
        const eu = new T.Euler().setFromQuaternion(lq, obj.rotation.order);
        r.pos = lp.toArray().map((x) => redondear(x));
        r.rot = [eu.x, eu.y, eu.z].map((x) => redondear(x / DEG, 2));
        r.nombre = `${buscar(id).nombre} ${k + 1}`;
        ents().push(...copias);
        for (const c of copias) crearObjeto(c);
        nuevas.push(r.id);
      }
    }
    if (v.agrupar) {
      seleccionarVarios([...raices, ...nuevas], true);
      agruparEnCarpeta('Fila', false);
    } else {
      seleccionarVarios(nuevas);
    }
    Ed.pintarArbol();
    Ed.guardarLocal();
    Ed.toast(`${n * raices.length} copia(s) creadas`);
  };

  /* Ctrl+G: mete los seleccionados en una carpeta nueva (en su centro). Conservan su lugar en el mundo. */
  function agruparEnCarpeta(nombre = 'Grupo', conDeshacer = true) {
    const raices = raicesSeleccion();
    if (!raices.length) return;
    if (conDeshacer) Ed.marcarCambio();
    const padres = new Set(raices.map((id) => buscar(id).padre || ''));
    const padreId = padres.size === 1 ? [...padres][0] : '';
    const caja = new T.Box3();
    for (const id of raices) caja.expandByObject(Ed.objetos.get(id));
    const centro = caja.isEmpty() ? Ed.objetos.get(raices[0]).getWorldPosition(new T.Vector3()) : caja.getCenter(new T.Vector3());
    centro.y = caja.isEmpty() ? centro.y : caja.min.y;
    const objPadre = padreId ? Ed.objetos.get(padreId) : raiz;
    const local = objPadre.worldToLocal(centro.clone());
    const carpeta = S.entidadNueva('carpeta', { nombre, padre: padreId, pos: [local.x, local.y, local.z].map((x) => redondear(x)) });
    const primero = ents().findIndex((e) => raices.includes(e.id));
    ents().splice(Math.max(0, primero), 0, carpeta);
    const objCarpeta = crearObjeto(carpeta);
    objCarpeta.updateMatrixWorld(true);
    for (const id of raices) {
      const ent = buscar(id), obj = Ed.objetos.get(id);
      ent.padre = carpeta.id;
      objCarpeta.attach(obj);
      leerTransform(obj, ent);
      // la entidad pasa al final de la lista (orden dentro de la carpeta = orden de selección en el árbol)
      ents().splice(ents().indexOf(ent), 1);
      ents().push(ent);
    }
    seleccionar(carpeta.id);
    Ed.pintarArbol();
    Ed.guardarLocal();
    return carpeta;
  }
  Ed.agruparSeleccion = () => agruparEnCarpeta();

  /* ---------- Copiar / pegar (también entre escenas) ---------- */
  let portapapeles = null;
  Ed.copiarSeleccion = function (silencioso = false) {
    const raices = raicesSeleccion().filter((id) => buscar(id).tipo !== 'inicio');
    if (!raices.length) return false;
    const lista = [];
    for (const id of raices) {
      const sub = S.subarbol(ents(), id).map((e) => F.util.copiar(e));
      // la raíz se guarda con su posición en el mundo: al pegar queda en el mismo lugar aunque cambie de padre
      const r = sub.find((e) => e.id === id);
      const obj = Ed.objetos.get(id);
      const { p, q, s: esc } = transformMundo(obj);
      const eu = new T.Euler().setFromQuaternion(q, obj.rotation.order);
      r.padre = '';
      r.pos = p.toArray().map((x) => redondear(x));
      r.rot = [eu.x, eu.y, eu.z].map((x) => redondear(x / DEG, 2));
      r.esc = esc.toArray().map((x) => redondear(x));
      lista.push(...sub);
    }
    portapapeles = { entidades: lista, raices };
    if (!silencioso) Ed.toast(`Copiado: ${raices.length} objeto(s) · Ctrl+V para pegar (en esta u otra escena)`);
    return true;
  };

  Ed.cortarSeleccion = function () {
    if (!Ed.copiarSeleccion(true)) return;
    const n = portapapeles.raices.length;
    Ed.borrarSeleccion();
    Ed.toast(`Cortado: ${n} objeto(s) · Ctrl+V para pegar`);
  };

  Ed.pegar = function () {
    if (!portapapeles) { Ed.toast('No hay nada copiado (Ctrl+C)'); return; }
    Ed.marcarCambio();
    const mapaIds = new Map();
    const copias = portapapeles.entidades.map((e) => {
      const c = F.util.copiar(e);
      mapaIds.set(e.id, (c.id = F.util.uid()));
      return c;
    });
    const nuevas = [];
    for (const c of copias) {
      if (mapaIds.has(c.padre)) c.padre = mapaIds.get(c.padre);
      else { c.padre = ''; nuevas.push(c.id); }
    }
    // modelos cuyo archivo ya no existe no se pegan
    const validas = copias.filter((c) => c.tipo !== 'modelo' || F.Assets.mapa.has(c.asset));
    ents().push(...porProfundidad(validas));
    for (const c of porProfundidad(validas)) crearObjeto(c);
    seleccionarVarios(nuevas.filter((id) => validas.some((c) => c.id === id)));
    Ed.pintarArbol();
    Ed.guardarLocal();
    Ed.toast(`Pegado: ${nuevas.length} objeto(s) en el mismo lugar · muévelos con el gizmo`);
  };
  Ed.hayPortapapeles = () => !!portapapeles;

  Ed.seleccionarTodo = function () {
    seleccionarVarios(ents().filter((e) => !e.padre).map((e) => e.id));
  };

  // Caja que envuelve a todo lo seleccionado
  function cajaSeleccion() {
    const caja = new T.Box3();
    for (const id of raicesSeleccion()) {
      const obj = Ed.objetos.get(id);
      if (!obj) continue;
      const c = new T.Box3().setFromObject(obj);
      if (c.isEmpty()) c.setFromCenterAndSize(obj.getWorldPosition(new T.Vector3()), new T.Vector3(1, 1, 1));
      caja.union(c);
    }
    return caja;
  }

  Ed.enfocarSeleccion = function () {
    const caja = cajaSeleccion();
    if (caja.isEmpty()) return;
    const centro = caja.getCenter(new T.Vector3());
    const tam = Math.max(1, caja.getSize(new T.Vector3()).length());
    repararCamara();
    if (vistaActual === 'persp') {
      const dir = camEditor.position.clone().sub(orbit.target);
      if (dir.lengthSq() < 1e-8 || !valido(dir)) dir.set(0.5, 0.45, 0.7);   // cámara encima del punto de giro: una dirección cualquiera
      dir.normalize();
      orbit.target.copy(centro);
      camEditor.position.copy(centro).addScaledVector(dir, tam * 1.3);
    } else {
      orbit.target.copy(centro);
      camOrto.position.copy(centro).add(new T.Vector3(...VISTAS[vistaActual].dir).normalize().multiplyScalar(1000));
      camOrto.zoom = camOrto.userData.mitadAlto / (tam * 0.7);
      camOrto.updateProjectionMatrix();
    }
  };

  // Baja lo seleccionado hasta lo que tenga debajo (cada uno por su cuenta)
  Ed.soltarAlSuelo = function () {
    const raices = raicesSeleccion().filter((id) => buscar(id).tipo !== 'carpeta' || raicesSeleccion().length === 1);
    if (!raices.length) return;
    const excluir = new Set();
    for (const id of raicesSeleccion()) for (const e of S.subarbol(ents(), id)) excluir.add(e.id);
    Ed.marcarCambio();
    for (const id of raices) {
      const ent = buscar(id), obj = Ed.objetos.get(id);
      if (!obj) continue;
      const caja = new T.Box3().setFromObject(obj);
      if (caja.isEmpty()) caja.setFromCenterAndSize(obj.getWorldPosition(new T.Vector3()), new T.Vector3());
      const centro = caja.getCenter(new T.Vector3());
      // Se busca desde arriba del objeto: así también sube lo que quedó medio enterrado
      rayo.set(new T.Vector3(centro.x, caja.max.y + 0.01, centro.z), new T.Vector3(0, -1, 0));
      const golpe = rayo.intersectObjects(objetosPickables(excluir), true).find((g) => !g.object.userData.ayudaEditor && g.object.type !== 'LineSegments');
      const suelo = golpe ? golpe.point.y : 0;   // sin nada debajo: el plano y = 0
      const mundo = obj.getWorldPosition(new T.Vector3());
      mundo.y += suelo - caja.min.y;
      obj.position.copy(obj.parent.worldToLocal(mundo));
      leerTransform(obj, ent);
    }
    const principal = buscar(Ed.seleccion);
    if (principal) Ed.actualizarCamposTransform(principal);
    engancharGizmo();
    Ed.guardarLocal();
  };

  /* Mover en el árbol. zona: 'antes' | 'despues' | 'dentro' | 'raiz'
     Conserva la posición en el mundo (como reparentar en Godot). */
  function moverEntidad(id, destinoId, zona) {
    const ent = buscar(id);
    if (!ent || id === destinoId) return;
    const destino = buscar(destinoId);
    if (destino && S.subarbol(ents(), id).some((e) => e.id === destinoId)) {
      Ed.toast('No se puede meter algo dentro de sí mismo');
      return;
    }
    Ed.marcarCambio();
    const nuevoPadre = zona === 'raiz' ? '' : zona === 'dentro' ? destinoId : (destino.padre || '');
    const lista = ents();
    lista.splice(lista.indexOf(ent), 1);
    if (zona === 'raiz' || zona === 'dentro' || !destino) lista.push(ent);
    else lista.splice(lista.indexOf(destino) + (zona === 'despues' ? 1 : 0), 0, ent);
    if (nuevoPadre !== (ent.padre || '')) {
      ent.padre = nuevoPadre;
      const obj = Ed.objetos.get(id);
      (nuevoPadre ? Ed.objetos.get(nuevoPadre) : raiz).attach(obj);
      leerTransform(obj, ent);
      if (zona === 'dentro' && destino) destino.plegado = false;
    }
    Ed.pintarArbol();
    if (Ed.seleccionados.has(id)) refrescarSeleccion();
    Ed.guardarLocal();
  }

  /* ---------- Selección ----------
     modo: 'solo' (reemplaza) · 'alternar' (Ctrl+clic: añade o quita) · 'agregar' */
  function engancharGizmo() {
    if (Ed.jugando) { gizmo.detach(); return; }
    const ids = raicesSeleccion().filter((id) => Ed.objetos.get(id));
    if (!ids.length) { gizmo.detach(); return; }
    if (ids.length === 1) { gizmo.attach(Ed.objetos.get(ids[0])); return; }
    const c = new T.Vector3();
    for (const id of ids) c.add(Ed.objetos.get(id).getWorldPosition(new T.Vector3()));
    pivote.position.copy(c.multiplyScalar(1 / ids.length));
    pivote.quaternion.identity();
    pivote.scale.set(1, 1, 1);
    pivote.updateMatrixWorld(true);
    gizmo.attach(pivote);
  }

  function marcarSeleccionEnArbol() {
    document.querySelectorAll('#listaEscena .nodo').forEach((el) => {
      el.classList.toggle('sel', Ed.seleccionados.has(el.dataset.id));
      el.classList.toggle('principal', el.dataset.id === Ed.seleccion && Ed.seleccionados.size > 1);
    });
    ponerPapelera();
  }

  // Papelera en la fila seleccionada del árbol: el primer clic la arma ("¿Borrar?"), el segundo borra (Ctrl+Z lo deshace)
  function ponerPapelera() {
    document.querySelectorAll('#listaEscena .papelera').forEach((b) => { clearTimeout(b._t); b.remove(); });
    const fila = Ed.seleccion && !Ed.jugando && document.querySelector(`#listaEscena .nodo[data-id="${Ed.seleccion}"]`);
    if (!fila) return;
    const n = Ed.seleccionados.size;
    const papelera = document.createElement('button');
    papelera.className = 'papelera';
    papelera.textContent = '🗑';
    papelera.title = (n > 1 ? `Borrar los ${n} seleccionados` : 'Borrar') + ' (pide confirmar · también Supr · Ctrl+Z deshace)';
    papelera.onclick = (ev) => {
      ev.stopPropagation();
      if (papelera.classList.contains('armada')) { clearTimeout(papelera._t); Ed.borrarSeleccion(); return; }
      papelera.classList.add('armada');
      papelera.textContent = n > 1 ? `¿Borrar ${n}?` : '¿Borrar?';
      papelera._t = setTimeout(() => { papelera.classList.remove('armada'); papelera.textContent = '🗑'; }, 2500);
    };
    papelera.ondblclick = (ev) => ev.stopPropagation();
    papelera.draggable = false;
    fila.appendChild(papelera);
  }

  function refrescarSeleccion() {
    engancharGizmo();
    marcarSeleccionEnArbol();
    Ed.pintarInspector();
    F.emitir('seleccion-cambiada');
  }

  function seleccionar(id, silencioso = false, modo = 'solo') {
    if (id && modo === 'alternar') {
      if (Ed.seleccionados.has(id)) {
        Ed.seleccionados.delete(id);
        if (Ed.seleccion === id) Ed.seleccion = [...Ed.seleccionados].pop() || null;
      } else {
        Ed.seleccionados.add(id);
        Ed.seleccion = id;
      }
    } else if (id && modo === 'agregar') {
      Ed.seleccionados.add(id);
      Ed.seleccion = id;
    } else {
      Ed.seleccionados = new Set(id ? [id] : []);
      Ed.seleccion = id || null;
    }
    if (!silencioso || id) Ed.assetSeleccionado = null;
    document.querySelectorAll('#listaAssets .item').forEach((el) => el.classList.remove('sel'));
    refrescarSeleccion();
  }
  Ed.seleccionar = seleccionar;

  function seleccionarVarios(ids, silencioso = false) {
    Ed.seleccionados = new Set(ids.filter((id) => buscar(id)));
    Ed.seleccion = ids.length ? ids[ids.length - 1] : null;
    if (!silencioso) Ed.assetSeleccionado = null;
    refrescarSeleccion();
  }
  Ed.seleccionarVarios = seleccionarVarios;

  Ed.seleccionarAsset = function (id) {
    Ed.seleccion = null;
    Ed.seleccionados = new Set();
    gizmo.detach();
    Ed.assetSeleccionado = id;
    document.querySelectorAll('#listaEscena .nodo').forEach((el) => el.classList.remove('sel', 'principal'));
    document.querySelectorAll('#listaAssets .item').forEach((el) => el.classList.toggle('sel', el.dataset.id === id));
    document.querySelector('.tabs-der button[data-panel="panelInspector"]').click();
    Ed.pintarInspector();
  };

  const ndcDe = (e) => {
    const r = lienzo.getBoundingClientRect();
    return new T.Vector2(((e.clientX - r.left) / r.width) * 2 - 1, -((e.clientY - r.top) / r.height) * 2 + 1);
  };

  // Clic en el visor = seleccionar (Ctrl o Shift + clic = añadir / quitar)
  let pulsacion = null;
  lienzo.addEventListener('pointerdown', (e) => { pulsacion = { x: e.clientX, y: e.clientY, boton: e.button }; });
  lienzo.addEventListener('pointerup', (e) => {
    if (Ed.jugando || !pulsacion || pulsacion.boton !== 0) return;
    const movido = Math.hypot(e.clientX - pulsacion.x, e.clientY - pulsacion.y);
    pulsacion = null;
    if (movido > 5 || gizmo.dragging || gizmo.axis) return;
    const sumar = e.ctrlKey || e.metaKey || e.shiftKey;
    rayo.setFromCamera(ndcDe(e), camVista());
    for (const g of rayo.intersectObjects(objetosPickables(), true)) {
      if (g.object.userData.ayudaEditor && !g.object.parent?.userData.entId) continue;
      let o = g.object;
      while (o && !o.userData.entId) o = o.parent;
      if (o && !Ed.sePuedeElegir(buscar(o.userData.entId))) continue;   // 🖐 filtro: se atraviesa
      if (o) { seleccionar(o.userData.entId, false, sumar ? 'alternar' : 'solo'); return; }
    }
    if (!sumar) seleccionar(null);
  });

  /* Shift + arrastrar en el visor = seleccionar con un rectángulo (Ctrl + Shift = añadir a lo que ya había).
     Se escucha en el contenedor "antes" que la cámara para que no gire mientras se dibuja el rectángulo. */
  let rect = null;
  $('vista').addEventListener('pointerdown', (e) => {
    if (Ed.jugando || e.button !== 0 || !e.shiftKey || e.target !== lienzo || gizmo.axis) return;
    orbit.enabled = false;
    const el = document.createElement('div');
    el.className = 'rect-seleccion';
    $('vista').appendChild(el);
    rect = { x0: e.clientX, y0: e.clientY, x1: e.clientX, y1: e.clientY, el, sumar: e.ctrlKey || e.metaKey };
  }, true);
  window.addEventListener('pointermove', (e) => {
    if (!rect) return;
    rect.x1 = e.clientX;
    rect.y1 = e.clientY;
    const r = $('vista').getBoundingClientRect();
    Object.assign(rect.el.style, {
      left: Math.min(rect.x0, rect.x1) - r.left + 'px', top: Math.min(rect.y0, rect.y1) - r.top + 'px',
      width: Math.abs(rect.x1 - rect.x0) + 'px', height: Math.abs(rect.y1 - rect.y0) + 'px',
    });
  });
  window.addEventListener('pointerup', () => {
    if (!rect) return;
    const { x0, y0, x1, y1, el, sumar } = rect;
    rect = null;
    el.remove();
    orbit.enabled = !Ed.jugando && !vuelo.activo;
    if (Math.hypot(x1 - x0, y1 - y0) <= 5) return;   // fue un Shift + clic normal
    const r = lienzo.getBoundingClientRect();
    const minX = Math.min(x0, x1), maxX = Math.max(x0, x1), minY = Math.min(y0, y1), maxY = Math.max(y0, y1);
    const cam = camVista();
    const dentro = [];
    for (const ent of ents()) {
      if (ent.tipo === 'carpeta') continue;   // las carpetas se eligen en el árbol
      if (!Ed.sePuedeElegir(ent)) continue;   // 🖐 filtro del visor
      const obj = Ed.objetos.get(ent.id);
      if (!obj || !obj.visible) continue;
      const caja = new T.Box3().setFromObject(obj);
      const c = caja.isEmpty() ? obj.getWorldPosition(new T.Vector3()) : caja.getCenter(new T.Vector3());
      c.project(cam);
      if (c.z < -1 || c.z > 1) continue;   // detrás de la cámara
      const sx = r.left + ((c.x + 1) / 2) * r.width, sy = r.top + ((1 - c.y) / 2) * r.height;
      if (sx >= minX && sx <= maxX && sy >= minY && sy <= maxY) dentro.push(ent.id);
    }
    seleccionarVarios(sumar ? [...Ed.seleccionados, ...dentro.filter((id) => !Ed.seleccionados.has(id))] : dentro);
    if (dentro.length) Ed.toast(`${Ed.seleccionados.size} seleccionado(s)`);
  });

  /* =========================================================
     ÁRBOL DE JERARQUÍA (arrastrar para ordenar o meter dentro)
     ========================================================= */
  let arrastrandoNodo = null;
  Ed.vistaEnts = 'arbol';
  try { Ed.vistaEnts = localStorage.getItem('forja-editor:vistaEnts') || 'arbol'; } catch (e) { /* nada */ }
  // fila simple (vista por tipo o búsqueda): clic selecciona, doble clic enfoca; sin arrastrar
  function filaPlana(ent, nivel) {
    const el = document.createElement('div');
    el.className = 'nodo' + (Ed.seleccionados.has(ent.id) ? ' sel' : '') + (ent.id === Ed.seleccion && Ed.seleccionados.size > 1 ? ' principal' : '');
    el.dataset.id = ent.id;
    el.style.paddingLeft = 4 + nivel * 14 + 'px';
    const madre = ent.padre && ents().find((e) => e.id === ent.padre);
    el.innerHTML = `<span class="plegar"></span><span>${S.ICONO[ent.tipo] || '·'}</span><span class="nom">${F.util.escapar ? F.util.escapar(ent.nombre) : ent.nombre}</span>` +
      `<span class="meta">${madre ? '📁 ' + madre.nombre : ''}${ent.visible ? '' : ' 👁̸'}</span>`;
    el.onclick = (ev) => {
      if (ev.shiftKey && Ed.seleccion) seleccionarRango(Ed.seleccion, ent.id);
      else seleccionar(ent.id, false, ev.ctrlKey || ev.metaKey ? 'alternar' : 'solo');
    };
    el.ondblclick = () => { seleccionar(ent.id); Ed.enfocarSeleccion(); };
    return el;
  }
  function pintarPorTipo(cont, filtro) {
    const grupos = new Map();
    for (const ent of ents()) {
      if (ent.tipo === 'carpeta' && !filtro) continue;
      const nomTipo = S.NOMBRE_TIPO[ent.tipo] || ent.tipo;
      if (filtro && !(ent.nombre + ' ' + nomTipo + ' ' + ent.tipo).toLowerCase().includes(filtro)) continue;
      if (!grupos.has(ent.tipo)) grupos.set(ent.tipo, []);
      grupos.get(ent.tipo).push(ent);
    }
    const plegados = Ed._tiposPlegados || (Ed._tiposPlegados = new Set());
    const tipos = [...grupos.keys()].sort((a, b) => (S.NOMBRE_TIPO[a] || a).localeCompare(S.NOMBRE_TIPO[b] || b));
    for (const t of tipos) {
      const lista = grupos.get(t), cerrado = plegados.has(t) && !filtro;
      const cab = document.createElement('div');
      cab.className = 'nodo cab-tipo';
      cab.innerHTML = `<span class="plegar">${cerrado ? '▶' : '▼'}</span><span>${S.ICONO[t] || '·'}</span><span class="nom">${S.NOMBRE_TIPO[t] || t}</span><span class="meta">${lista.length}</span>`;
      cab.onclick = () => { if (cerrado) plegados.delete(t); else plegados.add(t); Ed.pintarArbol(); };
      cont.appendChild(cab);
      if (!cerrado) for (const ent of lista) cont.appendChild(filaPlana(ent, 1));
    }
    if (!tipos.length) cont.innerHTML = '<div class="nota">' + (filtro ? 'Nada coincide con la búsqueda.' : 'La escena está vacía: añade algo con ＋ Añadir.') + '</div>';
  }
  Ed.pintarArbol = function () {
    const cont = $('listaEscena');
    cont.innerHTML = '';
    const filtro = ($('buscarEnt')?.value || '').trim().toLowerCase();
    const plano = filtro || Ed.vistaEnts === 'tipo';
    $('notaArbol').style.display = plano ? 'none' : '';
    if (plano) { pintarPorTipo(cont, filtro); ponerPapelera(); return; }
    const pintar = (padreId, nivel) => {
      for (const ent of S.hijos(ents(), padreId)) {
        const tieneHijos = ents().some((e) => e.padre === ent.id);
        const el = document.createElement('div');
        el.className = 'nodo' + (Ed.seleccionados.has(ent.id) ? ' sel' : '') + (ent.id === Ed.seleccion && Ed.seleccionados.size > 1 ? ' principal' : '');
        el.dataset.id = ent.id;
        el.draggable = true;
        el.style.paddingLeft = 4 + nivel * 14 + 'px';
        const col = S.SIN_COLISION.has(ent.tipo) ? '' : { malla: '', caja: 'caja', ninguna: 'sin col.' }[ent.colision];
        el.innerHTML = `<span class="plegar">${tieneHijos ? (ent.plegado ? '▶' : '▼') : ''}</span><span>${S.ICONO[ent.tipo] || '·'}</span>` +
          `<span class="nom">${ent.nombre}</span><span class="meta">${col}${ent.visible ? '' : ' 👁̸'}</span>`;
        el.querySelector('.plegar').onclick = (ev) => {
          ev.stopPropagation();
          ent.plegado = !ent.plegado;
          Ed.pintarArbol();
          Ed.guardarLocal();
        };
        el.onclick = (ev) => {
          if (ev.shiftKey && Ed.seleccion) seleccionarRango(Ed.seleccion, ent.id);
          else seleccionar(ent.id, false, ev.ctrlKey || ev.metaKey ? 'alternar' : 'solo');
        };
        el.ondblclick = () => { seleccionar(ent.id); Ed.enfocarSeleccion(); };
        el.ondragstart = (ev) => { arrastrandoNodo = ent.id; ev.dataTransfer.setData('text/plain', ent.id); ev.dataTransfer.effectAllowed = 'move'; };
        el.ondragend = () => { arrastrandoNodo = null; limpiarMarcas(); };
        el.ondragover = (ev) => {
          if (!arrastrandoNodo) return;
          ev.preventDefault();
          ev.stopPropagation();
          limpiarMarcas();
          el.classList.add('soltar-' + zonaDe(ev, el));
        };
        el.ondrop = (ev) => {
          if (!arrastrandoNodo) return;
          ev.preventDefault();
          ev.stopPropagation();
          const zona = zonaDe(ev, el);
          limpiarMarcas();
          moverEntidad(arrastrandoNodo, ent.id, zona);
          arrastrandoNodo = null;
        };
        cont.appendChild(el);
        if (tieneHijos && !ent.plegado) pintar(ent.id, nivel + 1);
      }
    };
    pintar('', 0);
    ponerPapelera();
  };
  // Shift + clic en el árbol: todo lo que hay entre el seleccionado y este (en el orden que se ve)
  function seleccionarRango(desde, hasta) {
    const visibles = [...document.querySelectorAll('#listaEscena .nodo')].map((el) => el.dataset.id);
    let i = visibles.indexOf(desde), j = visibles.indexOf(hasta);
    if (i < 0 || j < 0) { seleccionar(hasta); return; }
    if (i > j) [i, j] = [j, i];
    const rango = visibles.slice(i, j + 1);
    // la principal queda la que se pulsó
    seleccionarVarios([...rango.filter((id) => id !== hasta), hasta]);
  }

  function zonaDe(ev, el) {
    const r = el.getBoundingClientRect();
    const y = (ev.clientY - r.top) / r.height;
    return y < 0.28 ? 'antes' : y > 0.72 ? 'despues' : 'dentro';
  }
  function limpiarMarcas() {
    document.querySelectorAll('.soltar-antes, .soltar-despues, .soltar-dentro').forEach((x) => x.classList.remove('soltar-antes', 'soltar-despues', 'soltar-dentro'));
    $('listaEscena').classList.remove('soltar-raiz');
  }
  // Soltar en el hueco del árbol = sacar a la raíz
  $('listaEscena').addEventListener('dragover', (ev) => {
    if (!arrastrandoNodo) return;
    ev.preventDefault();
    limpiarMarcas();
    $('listaEscena').classList.add('soltar-raiz');
  });
  $('listaEscena').addEventListener('drop', (ev) => {
    if (!arrastrandoNodo) return;
    ev.preventDefault();
    limpiarMarcas();
    moverEntidad(arrastrandoNodo, null, 'raiz');
    arrastrandoNodo = null;
  });

  /* =========================================================
     ESCENAS
     ========================================================= */
  Ed.pintarSelectorEscenas = function () {
    const sel = $('selEscena');
    sel.innerHTML = '';
    for (const s of Ed.proyecto.escenas) {
      sel.add(new Option((s.capitulo ? '[' + s.capitulo + '] ' : '') + (s.id === Ed.proyecto.escenaInicial ? '★ ' : '') + s.nombre, s.id, false, s.id === Ed.escena.id));
    }
    pintarNiveles();
  };

  // 🗺 Lista de niveles agrupada por capítulo (en el orden de la lista; ▲▼ lo cambia)
  function pintarNiveles() {
    const cont = $('listaNiveles');
    if (!cont) return;
    cont.innerHTML = '';
    let capAnt = null;
    Ed.proyecto.escenas.forEach((s, i) => {
      const cap = s.capitulo || '';
      if (cap !== capAnt) {
        const h = document.createElement('div');
        h.className = 'cab-capitulo';
        h.textContent = cap ? '📚 ' + cap : 'Sin capítulo';
        h.title = 'Suelta aquí un nivel para meterlo en ' + (cap ? 'este capítulo' : 'ningún capítulo');
        zonaNivel(h, () => ({ cap, ref: s, antes: true }));
        cont.appendChild(h);
        capAnt = cap;
      }
      const el = document.createElement('div');
      el.className = 'nodo' + (s.id === Ed.escena.id ? ' sel' : '');
      el.style.paddingLeft = '10px';
      const n = (s.entidades || []).length;
      el.innerHTML = `<span class="plegar">${i + 1}</span><span>${s.id === Ed.proyecto.escenaInicial ? '★' : '🗺'}</span><span class="nom"></span><span class="meta">${n} cosas</span>`;
      el.querySelector('.nom').textContent = s.nombre;
      el.onclick = () => { if (s.id !== Ed.escena.id) cambiarEscena(s.id); };
      el.ondblclick = () => { cambiarEscena(s.id); escenaRenombrar(); };
      el.title = 'Clic: abrir · doble clic: renombrar · arrastra para ordenar o cambiar de capítulo';
      el.draggable = true;
      el.ondragstart = (ev) => { arrastrandoNivel = s.id; ev.dataTransfer.setData('text/plain', s.id); ev.dataTransfer.effectAllowed = 'move'; };
      el.ondragend = () => { arrastrandoNivel = null; limpiarNiveles(); };
      zonaNivel(el, (ev) => { const r = el.getBoundingClientRect(); return { cap, ref: s, antes: ev.clientY < r.top + r.height / 2 }; });
      cont.appendChild(el);
    });
    // ＋ el hueco de abajo = al final, sin capítulo
    const fin = document.createElement('div');
    fin.className = 'cab-capitulo fin-niveles';
    fin.textContent = '↓ Soltar aquí = al final, sin capítulo';
    zonaNivel(fin, () => ({ cap: '', ref: null, antes: false }));
    cont.appendChild(fin);
  }
  // Arrastrar niveles: sobre un capítulo = entra en él (al principio) · sobre un nivel = antes / después y toma su capítulo
  let arrastrandoNivel = null;
  function limpiarNiveles() {
    document.querySelectorAll('#listaNiveles .soltar-antes, #listaNiveles .soltar-despues, #listaNiveles .soltar-dentro')
      .forEach((x) => x.classList.remove('soltar-antes', 'soltar-despues', 'soltar-dentro'));
  }
  function zonaNivel(el, destino) {
    el.ondragover = (ev) => {
      if (!arrastrandoNivel) return;
      ev.preventDefault();
      limpiarNiveles();
      const d = destino(ev);
      el.classList.add(el.classList.contains('nodo') ? (d.antes ? 'soltar-antes' : 'soltar-despues') : 'soltar-dentro');
    };
    el.ondrop = (ev) => {
      if (!arrastrandoNivel) return;
      ev.preventDefault();
      const d = destino(ev), L = Ed.proyecto.escenas;
      const mov = L.find((x) => x.id === arrastrandoNivel);
      arrastrandoNivel = null;
      limpiarNiveles();
      if (!mov || mov === d.ref) { if (mov && mov.capitulo !== d.cap) { Ed.marcarCambio(); mov.capitulo = d.cap; } Ed.pintarSelectorEscenas(); Ed.guardarLocal(); return; }
      Ed.marcarCambio();
      L.splice(L.indexOf(mov), 1);
      let k = d.ref ? L.indexOf(d.ref) + (d.antes ? 0 : 1) : L.length;
      L.splice(k, 0, mov);
      mov.capitulo = d.cap;
      Ed.pintarSelectorEscenas();
      if (Ed.construirPanelProyecto) Ed.construirPanelProyecto();
      Ed.guardarLocal();
      Ed.toast(`<b>${mov.nombre}</b> → ${d.cap ? '📚 ' + d.cap : 'sin capítulo'}`);
    };
  }

  function cambiarEscena(id, recordarCamara = true) {
    if (Ed.jugando) Ed.detenerJuego();
    const esc = Ed.proyecto.escenas.find((s) => s.id === id);
    if (!esc) return;
    if (vistaActual !== 'persp') Ed.ponerVista('persp');
    if (recordarCamara) Ed.escena._camara = { pos: camEditor.position.toArray(), obj: orbit.target.toArray() };
    Ed.escena = esc;
    if (esc._camara) {
      camEditor.position.fromArray(esc._camara.pos);
      orbit.target.fromArray(esc._camara.obj);
    }
    Ed.seleccion = null;
    Ed.seleccionados = new Set();
    Ed.assetSeleccionado = null;
    reconstruirEscena();
    Ed.pintarSelectorEscenas();
    Ed.construirPanelEscena();
    Ed.aplicarAjustes();
    Ed.pintarInspector();
  }

  Ed.irAEntidad = function (idEscena, idEnt) {
    if (Ed.escena.id !== idEscena) cambiarEscena(idEscena);
    seleccionar(idEnt);
    Ed.enfocarSeleccion();
  };

  Ed.cambiarEscena = cambiarEscena;

  function escenaNueva() {
    const nombre = prompt('Nombre de la nueva escena:', `Nivel ${Ed.proyecto.escenas.length + 1}`);
    if (!nombre) return;
    const esc = S.escenaNueva(nombre.trim());
    esc.ambiente = { ...Ed.escena.ambiente, cieloTextura: Ed.escena.ambiente.cieloTextura };   // hereda el ambiente actual
    Ed.proyecto.escenas.push(esc);
    cambiarEscena(esc.id);
    Ed.construirPanelProyecto();
    Ed.guardarLocal();
    Ed.toast(`Escena <b>${esc.nombre}</b> creada`);
  }

  // ▲▼ ordenar niveles: el orden manda en los capítulos y en el menú de niveles / misiones
  function escenaMover(d) {
    const L = Ed.proyecto.escenas, i = L.indexOf(Ed.escena), k = i + d;
    if (i < 0 || k < 0 || k >= L.length) return;
    Ed.marcarCambio();
    [L[i], L[k]] = [L[k], L[i]];
    Ed.pintarSelectorEscenas();
    if (Ed.construirPanelProyecto) Ed.construirPanelProyecto();
    Ed.guardarLocal();
  }

  // 📚 capítulo del nivel: se elige de los que ya hay o se crea uno (vacío = sin capítulo)
  function escenaCapitulo() {
    const hay = [...new Set(Ed.proyecto.escenas.map((e) => e.capitulo).filter(Boolean))];
    const txt = prompt('Capítulo de "' + Ed.escena.nombre + '" (vacío = sin capítulo).' + (hay.length ? '\nYa existen: ' + hay.join(' · ') : '') +
      '\nLos niveles de un capítulo se juegan en el orden de la lista (▲▼).', Ed.escena.capitulo || hay[hay.length - 1] || 'Capítulo 1');
    if (txt === null) return;
    Ed.marcarCambio();
    Ed.escena.capitulo = txt.trim();
    Ed.pintarSelectorEscenas();
    Ed.guardarLocal();
  }

  function escenaRenombrar() {
    const nombre = prompt('Nuevo nombre de la escena:', Ed.escena.nombre);
    if (!nombre) return;
    Ed.escena.nombre = nombre.trim();
    Ed.pintarSelectorEscenas();
    Ed.construirPanelEscena();
    Ed.construirPanelProyecto();
    Ed.guardarLocal();
  }

  function escenaDuplicar() {
    const copia = F.util.copiar(Ed.escena);
    delete copia._camara;
    copia.id = F.util.uid();
    copia.nombre = Ed.escena.nombre + ' copia';
    const mapaIds = new Map();
    for (const e of copia.entidades) mapaIds.set(e.id, (e.id = F.util.uid()));
    for (const e of copia.entidades) if (mapaIds.has(e.padre)) e.padre = mapaIds.get(e.padre);
    Ed.proyecto.escenas.splice(Ed.proyecto.escenas.indexOf(Ed.escena) + 1, 0, copia);
    cambiarEscena(copia.id);
    Ed.construirPanelProyecto();
    Ed.guardarLocal();
  }

  function escenaBorrar() {
    if (Ed.proyecto.escenas.length <= 1) { Ed.toast('El proyecto necesita al menos una escena'); return; }
    if (!confirm(`¿Borrar la escena "${Ed.escena.nombre}" con todo su contenido? No se puede deshacer.`)) return;
    const i = Ed.proyecto.escenas.indexOf(Ed.escena);
    Ed.proyecto.escenas.splice(i, 1);
    if (Ed.proyecto.escenaInicial === Ed.escena.id) Ed.proyecto.escenaInicial = Ed.proyecto.escenas[0].id;
    pilaDeshacer.length = pilaRehacer.length = 0;
    cambiarEscena(Ed.proyecto.escenas[Math.max(0, i - 1)].id, false);
    Ed.construirPanelProyecto();
    Ed.guardarLocal();
  }

  /* =========================================================
     ARCHIVOS DEL PROYECTO
     ========================================================= */
  let filtroAssets = '';
  Ed.usosDeAsset = function (id) {
    const usos = [];
    for (const esc of Ed.proyecto.escenas) {
      for (const e of esc.entidades) {
        if (e.asset === id) usos.push({ escena: esc, ent: e, texto: `◆ ${e.nombre}` });
        if (e.textura === id) usos.push({ escena: esc, ent: e, texto: `▣ textura de ${e.nombre}` });
        if (e.normal === id) usos.push({ escena: esc, ent: e, texto: `▣ normal de ${e.nombre}` });
      }
      if (esc.ambiente.cieloTextura === id) usos.push({ escena: esc, texto: '☁ cielo' });
    }
    for (const [nombre, m] of Object.entries(Ed.proyecto.jugador.modulos)) {
      for (const v of Object.values(m)) if (v === id) usos.push({ texto: `🎮 jugador · ${nombre}` });
    }
    for (const [idModelo, mats] of Object.entries(Ed.proyecto.materiales || {})) {
      for (const cfg of Object.values(mats)) {
        if (cfg && (cfg.textura === id || cfg.normal === id)) usos.push({ texto: `▣ material de ${F.Assets.mapa.get(idModelo)?.nombre || 'modelo'}` });
      }
    }
    return usos;
  };

  /* ---------- Carpetas de Archivos (solo organizan; no afectan al juego) ---------- */
  const carpetas = () => Ed.proyecto.carpetasArchivos;
  Ed.carpetaArchivosSel = null;

  // Carpeta por defecto según el tipo (.glb → Modelos, .png → Texturas…). '' si no existe esa carpeta.
  Ed.carpetaPorDefecto = function (a) {
    const rol = S.rolDeAsset(a);
    const c = carpetas().find((x) => x.rol === rol);
    return c ? c.id : '';
  };

  // Archivos que aún no tienen carpeta (importados con versiones anteriores) → a la de su tipo
  async function acomodarArchivosSinCarpeta() {
    for (const a of F.Assets.mapa.values()) {
      if (a.carpeta === undefined) await F.Assets.moverACarpeta(a.id, Ed.carpetaPorDefecto(a));
      else if (a.carpeta && !carpetas().some((c) => c.id === a.carpeta)) await F.Assets.moverACarpeta(a.id, '');
    }
  }

  function subCarpetas(id) {
    const ids = new Set([id]);
    let creciendo = true;
    while (creciendo) {
      creciendo = false;
      for (const c of carpetas()) if (c.padre && ids.has(c.padre) && !ids.has(c.id)) { ids.add(c.id); creciendo = true; }
    }
    return ids;
  }

  function nuevaCarpetaArchivos() {
    const nombre = prompt('Nombre de la carpeta:', 'Nueva carpeta');
    if (!nombre) return;
    const padre = Ed.carpetaArchivosSel && carpetas().some((c) => c.id === Ed.carpetaArchivosSel) ? Ed.carpetaArchivosSel : '';
    const c = { id: F.util.uid(), nombre: nombre.trim(), rol: '', padre, plegada: false };
    carpetas().push(c);
    const madre = carpetas().find((x) => x.id === padre);
    if (madre) madre.plegada = false;
    Ed.carpetaArchivosSel = c.id;
    Ed.guardarLocal();
    Ed.pintarArchivos();
  }

  function renombrarCarpeta(c) {
    const nombre = prompt('Nuevo nombre de la carpeta:', c.nombre);
    if (!nombre) return;
    c.nombre = nombre.trim();
    Ed.guardarLocal();
    Ed.pintarArchivos();
  }

  async function borrarCarpeta(c) {
    const dentro = [...F.Assets.mapa.values()].filter((a) => a.carpeta === c.id).length;
    if (!confirm(`¿Borrar la carpeta "${c.nombre}"?` + (dentro ? `\nSus ${dentro} archivo(s) pasan a la carpeta de arriba (no se borran).` : ''))) return;
    for (const a of F.Assets.mapa.values()) if (a.carpeta === c.id) await F.Assets.moverACarpeta(a.id, c.padre || '');
    for (const h of carpetas()) if (h.padre === c.id) h.padre = c.padre || '';
    Ed.proyecto.carpetasArchivos = carpetas().filter((x) => x !== c);
    if (Ed.carpetaArchivosSel === c.id) Ed.carpetaArchivosSel = null;
    Ed.guardarLocal();
    Ed.pintarArchivos();
  }

  // Soltar un archivo o carpeta dentro de una carpeta ('' = raíz)
  async function soltarEnCarpeta(ev, destino) {
    const idAsset = ev.dataTransfer.getData('forja/asset');
    const idCarpeta = ev.dataTransfer.getData('forja/carpeta');
    if (idAsset) {
      await F.Assets.moverACarpeta(idAsset, destino);
    } else if (idCarpeta) {
      if (subCarpetas(idCarpeta).has(destino)) { Ed.toast('No se puede meter una carpeta dentro de sí misma'); return; }
      const c = carpetas().find((x) => x.id === idCarpeta);
      if (c) c.padre = destino;
    } else {
      return;
    }
    const d = carpetas().find((x) => x.id === destino);
    if (d) d.plegada = false;
    Ed.guardarLocal();
    Ed.pintarArchivos();
    if (Ed.assetSeleccionado) Ed.pintarInspector();
  }
  const aceptaSoltar = (ev) => {
    const t = [...ev.dataTransfer.types];
    return t.includes('forja/asset') || t.includes('forja/carpeta');
  };

  function filaArchivo(a, nivel, conRuta) {
    const fmtKb = Ed.kb;
    const usos = Ed.usosDeAsset(a.id).length;
    const el = document.createElement('div');
    el.className = 'item' + (usos ? '' : ' sinuso') + (Ed.assetSeleccionado === a.id ? ' sel' : '');
    el.dataset.id = a.id;
    el.style.paddingLeft = 6 + nivel * 14 + 'px';
    el.title = `${a.nombre}\n${fmtKb(a.datos.byteLength)} · ${usos ? `usado ${usos} vez/veces` : 'sin usar'}` +
      (a.tipo === 'modelo' ? '\nArrástralo al visor para colocarlo, o a una carpeta para moverlo' : '\nArrástralo a una carpeta para moverlo');
    const meta = conRuta ? (carpetas().find((c) => c.id === a.carpeta)?.nombre || 'raíz')
      : a.tipo === 'modelo' ? `${fmt(a.tris || 0)} tris${a.gltf?.animations?.length ? ' · anim' : ''}`
      : a.tipo === 'textura' && a.imagen ? `${a.imagen.width}×${a.imagen.height}`
      : a.tipo === 'audio' && a.duracion ? `${a.duracion.toFixed(1)} s` : fmtKb(a.datos.byteLength);
    const icono = { modelo: '◆', audio: '♪', midi: '♬', textura: '▣', fuente: 'Aa' };
    const ico = a.tipo === 'textura' ? `<img class="miniatura" src="${a.url}">`
      : a.tipo === 'fuente' ? `<span class="ico-fuente" style="font-family:'${a.familia}'">Aa</span>`
      : `<span>${icono[a.tipo] || '·'}</span>`;
    el.innerHTML = `${ico}<span class="nom">${a.nombre}</span><span class="meta">${meta}</span>`;
    el.onclick = () => Ed.seleccionarAsset(a.id);
    el.draggable = true;
    el.ondragstart = (ev) => { ev.dataTransfer.setData('forja/asset', a.id); ev.dataTransfer.effectAllowed = 'copyMove'; };
    if (a.tipo === 'modelo') {
      const b = document.createElement('button');
      b.textContent = '＋';
      b.title = 'Añadir a la escena donde mira la cámara';
      b.onclick = (ev) => { ev.stopPropagation(); Ed.agregarModelo(a.id); };
      el.appendChild(b);
    }
    return el;
  }

  function filaCarpeta(c, nivel, cuenta) {
    const el = document.createElement('div');
    el.className = 'item carpeta-archivos' + (Ed.carpetaArchivosSel === c.id ? ' sel' : '');
    el.style.paddingLeft = 2 + nivel * 14 + 'px';
    el.draggable = true;
    el.title = 'Clic: seleccionar (las carpetas nuevas se crean dentro) · Arrastra archivos aquí para moverlos';
    el.innerHTML = `<span class="plegar">${c.plegada ? '▶' : '▼'}</span><span>${c.plegada ? '📁' : '📂'}</span>` +
      `<span class="nom">${c.nombre}</span><span class="meta">${cuenta || ''}</span>`;
    const boton = (texto, titulo, fn, clase = '') => {
      const b = document.createElement('button');
      b.textContent = texto;
      b.title = titulo;
      b.className = 'solo-hover ' + clase;
      b.onclick = (ev) => { ev.stopPropagation(); fn(); };
      el.appendChild(b);
    };
    boton('✎', 'Renombrar carpeta', () => renombrarCarpeta(c));
    boton('✕', 'Borrar carpeta (los archivos no se borran)', () => borrarCarpeta(c), 'peligro');
    el.querySelector('.plegar').onclick = (ev) => { ev.stopPropagation(); c.plegada = !c.plegada; Ed.guardarLocal(); Ed.pintarArchivos(); };
    el.onclick = () => {
      Ed.carpetaArchivosSel = Ed.carpetaArchivosSel === c.id ? null : c.id;
      Ed.pintarArchivos();
    };
    el.ondblclick = () => { c.plegada = !c.plegada; Ed.guardarLocal(); Ed.pintarArchivos(); };
    el.ondragstart = (ev) => { ev.stopPropagation(); ev.dataTransfer.setData('forja/carpeta', c.id); ev.dataTransfer.effectAllowed = 'move'; };
    el.ondragover = (ev) => { if (!aceptaSoltar(ev)) return; ev.preventDefault(); ev.stopPropagation(); el.classList.add('soltar-dentro'); };
    el.ondragleave = () => el.classList.remove('soltar-dentro');
    el.ondrop = (ev) => { if (!aceptaSoltar(ev)) return; ev.preventDefault(); ev.stopPropagation(); el.classList.remove('soltar-dentro'); soltarEnCarpeta(ev, c.id); };
    return el;
  }

  Ed.pintarArchivos = function () {
    const cont = $('listaAssets');
    cont.innerHTML = '';
    const texto = ($('buscarAsset').value || '').toLowerCase();
    const todos = [...F.Assets.mapa.values()];
    const total = todos.reduce((s2, a) => s2 + a.datos.byteLength, 0);
    $('resumenAssets').textContent = todos.length ? `${todos.length} archivo(s) · ${Ed.kb(total)} en total` : '';

    // Con filtro o búsqueda: lista plana (mostrando en qué carpeta está cada uno)
    if (filtroAssets || texto) {
      const lista = todos.filter((a) => (!filtroAssets || a.tipo === filtroAssets || (filtroAssets === 'audio' && a.tipo === 'midi')) &&
        (!texto || a.nombre.toLowerCase().includes(texto)));
      if (!lista.length) cont.innerHTML = '<div class="vacio">Nada coincide</div>';
      for (const a of lista) cont.appendChild(filaArchivo(a, 0, true));
      return;
    }

    // Árbol: carpetas y, dentro, sus archivos
    const enCarpeta = (id) => todos.filter((a) => (a.carpeta || '') === id).sort((x, y) => x.nombre.localeCompare(y.nombre));
    const cuenta = (id) => {
      const ids = subCarpetas(id);
      return todos.filter((a) => ids.has(a.carpeta)).length;
    };
    const pintar = (padre, nivel) => {
      for (const c of carpetas().filter((x) => (x.padre || '') === padre)) {
        cont.appendChild(filaCarpeta(c, nivel, cuenta(c.id)));
        if (!c.plegada) pintar(c.id, nivel + 1);
      }
      for (const a of enCarpeta(padre)) cont.appendChild(filaArchivo(a, nivel, false));
    };
    pintar('', 0);
    if (!todos.length) {
      const v = document.createElement('div');
      v.className = 'vacio';
      v.textContent = 'Importa o arrastra archivos aquí: cada uno se acomoda en su carpeta';
      cont.appendChild(v);
    }
  };

  // Soltar en el hueco de la lista = sacar a la raíz
  $('listaAssets').addEventListener('dragover', (ev) => { if (aceptaSoltar(ev)) ev.preventDefault(); });
  $('listaAssets').addEventListener('drop', (ev) => { if (!aceptaSoltar(ev)) return; ev.preventDefault(); soltarEnCarpeta(ev, ''); });
  Ed.acomodarArchivosSinCarpeta = acomodarArchivosSinCarpeta;
  Ed.nuevaCarpetaArchivos = nuevaCarpetaArchivos;

  // Arrastrar un archivo al visor: modelo = colocarlo ahí · textura = ponérsela a la primitiva que está debajo
  lienzo.addEventListener('dragover', (ev) => {
    if ([...ev.dataTransfer.types].includes('forja/asset')) { ev.preventDefault(); ev.dataTransfer.dropEffect = 'copy'; }
  });
  lienzo.addEventListener('drop', (ev) => {
    const id = ev.dataTransfer.getData('forja/asset');
    if (!id) return;
    ev.preventDefault();
    ev.stopPropagation();
    const a = F.Assets.mapa.get(id);
    const r = lienzo.getBoundingClientRect();
    const nx = ((ev.clientX - r.left) / r.width) * 2 - 1, ny = -((ev.clientY - r.top) / r.height) * 2 + 1;
    if (a.tipo === 'modelo') {
      Ed.agregarModelo(id, golpeEnPantalla(nx, ny));
    } else if (a.tipo === 'textura') {
      rayo.setFromCamera(new T.Vector2(nx, ny), camVista());
      const g = rayo.intersectObjects(objetosPickables(), true)[0];
      let o = g && g.object;
      while (o && !o.userData.entId) o = o.parent;
      const ent = o && buscar(o.userData.entId);
      if (!ent || !S.PARAMS_PRIMITIVA[ent.tipo]) { Ed.toast('Suelta la textura sobre un cubo, suelo, rampa o escalera'); return; }
      Ed.marcarCambio();
      if (/_normal\.[a-z]+$/i.test(a.nombre)) ent.normal = a.id;
      else { if (!ent.textura) ent.color = '#ffffff'; ent.textura = a.id; }
      Ed.reconstruirEntidad(ent);
      seleccionar(ent.id);
      Ed.pintarArchivos();
      Ed.guardarLocal();
    }
  });

  Ed.importarArchivo = async function (nombre, blob, origen = '', vivo = false) {
    let r;
    try {
      // 🧾 receta: su generador se copia de la app (si está en Apps) al proyecto antes de generarla
      if (/\.receta\.json$/i.test(nombre)) await prepararGenerador(blob, origen);
      r = await F.Assets.importar(nombre, blob);
    } catch (err) {
      Ed.toast(`No pude importar <b>${nombre}</b>: ${err.message || err}`, 'error');
      return null;
    }
    const recetaFallida = r.asset.esReceta && !r.asset.gltf;
    if (recetaFallida) {
      Ed.toast(r.asset.faltaGenerador
        ? `🧾 <b>${nombre}</b>: falta el generador <b>${r.asset.faltaGenerador}</b>. Carga en <b>Apps</b> la app que hizo la receta (con su bloque forja-generador) y vuelve a enviarla.`
        : `🧾 <b>${nombre}</b>: ${r.asset.errorReceta}`, 'error');
    }
    if (r.asset.tipo === 'modelo') F.Assets.aplicarMaterialesAsset(Ed.proyecto, r.asset);
    if (r.reemplazado) refrescarUsos(r.asset.id);
    if (r.asset.carpeta === undefined) await F.Assets.moverACarpeta(r.asset.id, Ed.carpetaPorDefecto(r.asset));
    Ed.pintarArchivos();
    Ed.construirPanelJugador();
    Ed.construirPanelEscena();
    if (Ed.assetSeleccionado === r.asset.id || Ed.seleccion) Ed.pintarInspector();
    const de = origen ? ` desde <b>${origen}</b>` : '';
    // en vivo (cada cambio en la app) solo se avisa la primera vez
    if (recetaFallida) { /* ya avisó qué falta */ }
    else if (!vivo || !r.reemplazado) Ed.toast(`📥 <b>${nombre}</b>${de} → Archivos${r.reemplazado ? ' (reemplazado y actualizado en escena)' : ''}`);
    else F.emitir('estado', `⟳ ${nombre} actualizado en vivo`);
    return r.asset;
  };

  // copia al proyecto el código del generador que pide la receta (de la app cargada en Apps); siempre el más nuevo
  async function prepararGenerador(blob, origen) {
    let receta;
    try { receta = F.Generadores.leer(await blob.text()).receta; } catch (err) { throw new Error('la receta no se puede leer (' + err.message + ')'); }
    const clave = F.Generadores.clave(receta);
    const g = Ed.Apps && Ed.Apps.codigoGenerador(clave);
    if (g) {
      const nuevo = !Ed.proyecto.generadores || Ed.proyecto.generadores[clave] !== g.codigo;
      F.Generadores.guardarEnProyecto(Ed.proyecto, clave, g.codigo);
      if (nuevo) Ed.guardarLocal();
    } else {
      F.Generadores.usarProyecto(Ed.proyecto);
    }
  }

  function refrescarUsos(id) {
    for (const ent of ents()) {
      const usa = ent.asset === id || ent.textura === id || ent.normal === id
        || (ent.enemigo && ent.enemigo.modelo === id) || (ent.recogible && ent.recogible.modelo === id);
      if (usa) Ed.reconstruirEntidad(ent);
    }
    F.Assets.aplicarMateriales(Ed.proyecto);
    Ed.aplicarAjustes();
  }

  Ed.reemplazarAsset = function (id) {
    const a = F.Assets.mapa.get(id);
    const inp = document.createElement('input');
    inp.type = 'file';
    inp.accept = '.' + (a.nombre.split('.').pop() || '*');
    inp.onchange = async () => {
      const f = inp.files[0];
      if (!f) return;
      try {
        await F.Assets.reemplazar(id, f, f.name);
      } catch (err) {
        Ed.toast('No pude reemplazarlo: ' + err.message, 'error');
        return;
      }
      if (a.tipo === 'modelo') F.Assets.aplicarMaterialesAsset(Ed.proyecto, a);
      refrescarUsos(id);
      Ed.pintarArchivos();
      Ed.pintarInspector();
      Ed.guardarLocal();
      Ed.toast(`<b>${a.nombre}</b> reemplazado; todo lo que lo usa se actualizó`);
    };
    inp.click();
  };

  Ed.borrarAsset = function (id) {
    const a = F.Assets.mapa.get(id);
    if (!a) return;
    const usos = Ed.usosDeAsset(id);
    const modelos = usos.filter((u) => u.ent && u.ent.asset === id);
    if (!confirm(`¿Quitar "${a.nombre}" del proyecto?` + (usos.length ? `\nSe usa ${usos.length} vez/veces` +
      (modelos.length ? `; se borrarán ${modelos.length} objeto(s) que son este modelo.` : '; esos usos quedarán vacíos.') : ''))) return;
    Ed.marcarCambio();
    for (const esc of Ed.proyecto.escenas) {
      esc.entidades = esc.entidades.filter((e) => e.asset !== id);
      for (const e of esc.entidades) {
        if (e.textura === id) e.textura = '';
        if (e.normal === id) e.normal = '';
      }
      if (esc.ambiente.cieloTextura === id) esc.ambiente.cieloTextura = '';
    }
    for (const m of Object.values(Ed.proyecto.jugador.modulos)) for (const k in m) if (m[k] === id) m[k] = '';
    delete Ed.proyecto.materiales[id];
    for (const mats of Object.values(Ed.proyecto.materiales)) {
      for (const cfg of Object.values(mats)) { if (cfg.textura === id) cfg.textura = ''; if (cfg.normal === id) cfg.normal = ''; }
    }
    F.Assets.quitar(id);
    Ed.assetSeleccionado = null;
    reconstruirEscena();
    F.Assets.aplicarMateriales(Ed.proyecto);
    Ed.pintarArchivos();
    Ed.construirPanelJugador();
    Ed.construirPanelEscena();
    Ed.aplicarAjustes();
    Ed.pintarInspector();
    Ed.guardarLocal();
  };

  /* =========================================================
     PROBAR EL JUEGO (la escena actual)
     ========================================================= */
  /* inicio: lo que trae el jugador al llegar de otra escena (🚪 salida). enViaje: no pide el cursor ni avisa */
  function iniciarJuego(inicio = null, enViaje = false) {
    if (Ed.jugando) return;
    Ed.Apps.irAPestana('editor');
    if (vistaActual !== 'persp') Ed.ponerVista('persp');
    gizmo.detach();
    rejilla.visible = false;
    orbit.enabled = false;
    vuelo.activo = false;
    if (!enViaje) {
      if (F.Cine) F.Cine.reiniciarPartida();   // 🎬 las de "una vez" se vuelven a ver en cada ▶ Jugar
      // memoria de niveles de esta prueba; al Detener el editor vuelve a la escena donde empezaste
      Ed.niveles = new F.Niveles();
      Ed.escenaAlJugar = Ed.escena.id;
      inicio = { llegada: '' };
      Ed.niveles.marcarEntrada(Ed.escena.id, inicio);
    }
    Ed.juego = new F.Juego(vista, Ed.proyecto, Ed.escena, Ed.objetos);
    Ed.jugando = true;
    Ed.yaJugo = true;
    const r = Ed.juego.iniciar(inicio);
    F.Audio.musicaNivel(Ed.escena.nivel);
    if (enViaje) return Ed.juego;
    $('hudJuego').style.display = 'block';
    $('mira').style.display = 'none';   // la mira la dibuja el HUD (Juego ▸ HUD)
    $('herramientas').style.display = 'none';
    $('ayudaJuego').style.opacity = 1;
    setTimeout(() => { $('ayudaJuego').style.opacity = 0; }, 5000);
    $('btnJugar').textContent = '■ Detener';
    if (document.activeElement && document.activeElement.blur) document.activeElement.blur();
    F.Entrada.pedirBloqueo();
    Ed.toast(`▶ ${Ed.escena.nombre} · colisión: <b>${fmt(r.triangulos)}</b> triángulos (${r.msColision.toFixed(1)} ms)`);
  }

  Ed.detenerJuego = function () {
    if (Ed.partida) { detenerPartida(); return; }
    if (!Ed.jugando) return;
    Ed.jugando = false;
    Ed.juego.detener();
    Ed.juego = null;
    F.Audio.pararMusica();
    if (Ed.niveles) { Ed.niveles.quitarCapa(); Ed.niveles = null; }
    // si viajaste a otra escena, el editor vuelve a la escena donde pulsaste ▶ Jugar
    const volver = Ed.escenaAlJugar;
    Ed.escenaAlJugar = null;
    if (volver && volver !== Ed.escena.id && Ed.proyecto.escenas.some((e) => e.id === volver)) {
      cambiarEscena(volver, false);
      Ed.toast('■ Detenido: de vuelta en <b>' + Ed.escena.nombre + '</b>');
    }
    for (const obj of Ed.objetos.values()) obj.traverse((o) => { if (o.userData.entId || o.userData.ayudaEditor) o.visible = true; });
    rejilla.visible = true;
    orbit.enabled = true;
    $('hudJuego').style.display = 'none';
    $('depuracion').style.display = 'none';
    $('herramientas').style.display = 'flex';
    $('btnJugar').textContent = '▶ Jugar';
    Ed.aplicarAjustes();
    refrescarSeleccion();
    refrescarLuces();
  };

  // Con "Probar con menús" la pausa la lleva la Partida (menú de pausa); con ▶ Jugar, Esc vuelve al editor
  F.on('juego-pausa', () => { if (!Ed.partida) Ed.detenerJuego(); });
  F.on('cursor-liberado', () => { if (Ed.jugando && !Ed.partida) Ed.detenerJuego(); });

  // 🏆 / 💣 con ▶ Jugar (sin menús): aviso y vuelve al editor; las pantallas de victoria y game over salen con "Probar con menús"
  F.on('partida-fin', (juego) => { if (!Ed.partida && Ed.jugando && juego === Ed.juego) { Ed.toast('🏆 ¡Juego completado! (la pantalla de victoria sale con "▶ Probar con menús")'); setTimeout(() => { if (Ed.jugando && !Ed.partida) Ed.detenerJuego(); }, 1500); } });
  F.on('partida-misiones', (juego) => { if (!Ed.partida && Ed.jugando && juego === Ed.juego) { Ed.toast('🗺 Misión acabada: volvería al menú de misiones (pruébalo con "▶ Probar con menús")'); setTimeout(() => { if (Ed.jugando && !Ed.partida) Ed.detenerJuego(); }, 1500); } });
  F.on('mision-fallida', ({ juego, motivo }) => { if (!Ed.partida && Ed.jugando && juego === Ed.juego) { Ed.toast('💀 Misión fallida: ' + (motivo || '')); setTimeout(() => { if (Ed.jugando && !Ed.partida) Ed.detenerJuego(); }, 1500); } });

  /* 🚪 Con ▶ Jugar las salidas también funcionan: el editor cambia de escena y sigue jugando.
     Mientras dura el fundido el juego no se actualiza (el bucle solo dibuja). */
  F.on('salida', ({ juego, ent }) => {
    if (Ed.partida || !Ed.jugando || juego !== Ed.juego || !Ed.niveles) return;
    const desde = Ed.juego;
    Ed.niveles.viajar({
      juego: desde,
      ent,
      cambiar: (idEscena, inicio) => {
        if (!Ed.jugando || Ed.juego !== desde) return null;   // pulsaron Detener a medio viaje
        desde.detener({ seguir: true });
        Ed.jugando = false;
        cambiarEscena(idEscena, true);
        return iniciarJuego(inicio, true);
      },
    }).then((ok) => {
      if (ok && Ed.juego) Ed.toast(`🚪 ${Ed.escena.nombre}`);
    });
  });

  /* ---------- Probar con menús: el juego completo (FORJA.Partida) dentro del visor ----------
     Los objetos del editor se esconden; la Partida carga sus propias copias de las escenas. */
  F.Opciones.usarPrefijo('forja-editor');   // opciones y partidas de prueba aparte de las del juego exportado
  let escondidos = [];
  Ed.partida = null;
  Ed.probarMenus = function (pantalla = 'portada') {
    if (Ed.jugando) Ed.detenerJuego();
    Ed.Apps.irAPestana('editor');
    if (vistaActual !== 'persp') Ed.ponerVista('persp');
    gizmo.detach();
    orbit.enabled = false;
    vuelo.activo = false;
    escondidos = raiz.children.filter((o) => o.visible && (o.userData.entId || o === rejilla || o === gizmo || o === pivote || o.name === 'ver-colisiones'));
    for (const o of escondidos) o.visible = false;
    Ed.jugando = true;
    Ed.yaJugo = true;
    Ed.partida = new F.Partida({ vista, proyecto: Ed.proyecto, contenedor: $('vista'), enEditor: true, alSalir: () => Ed.detenerJuego() });
    $('hudJuego').style.display = 'block';
    $('ayudaJuego').style.opacity = 0;
    $('herramientas').style.display = 'none';
    $('btnJugar').textContent = '■ Detener';
    if (document.activeElement && document.activeElement.blur) document.activeElement.blur();
    Ed.partida.arrancar(pantalla);
  };

  function detenerPartida() {
    Ed.partida.destruir();
    Ed.partida = null;
    Ed.jugando = false;
    for (const o of escondidos) o.visible = true;
    escondidos = [];
    orbit.enabled = true;
    $('hudJuego').style.display = 'none';
    $('mira').style.display = 'none';
    $('depuracion').style.display = 'none';
    $('herramientas').style.display = 'flex';
    $('btnJugar').textContent = '▶ Jugar';
    Ed.aplicarAjustes();
    refrescarSeleccion();
    refrescarLuces();
    if (Ed.Colisiones && Ed.Colisiones.visible()) Ed.Colisiones.reconstruir();
  }
  

  /* =========================================================
     GUARDAR / ABRIR / NUEVO / EXPORTAR
     ========================================================= */
  function proyectoParaGuardar() {
    // sin datos internos del editor (posición de cámara por escena)
    return JSON.parse(JSON.stringify(Ed.proyecto, (k, v) => (k === '_camara' ? undefined : v)));
  }

  // Miniatura del proyecto (vista actual del editor, 320×180)
  Ed.capturarMiniatura = function () {
    return new Promise((ok) => {
      try {
        // sin gizmo ni rejilla: que se vea el juego
        const antes = [gizmo.visible, rejilla.visible];
        gizmo.visible = rejilla.visible = false;
        vista.render(camEditor);
        [gizmo.visible, rejilla.visible] = antes;
        const c = document.createElement('canvas');
        c.width = 320;
        c.height = 180;
        const g = c.getContext('2d');
        const src = lienzo, r = src.width / src.height, rr = 320 / 180;
        const sw = r > rr ? src.height * rr : src.width, sh = r > rr ? src.height : src.width / rr;
        g.drawImage(src, (src.width - sw) / 2, (src.height - sh) / 2, sw, sh, 0, 0, 320, 180);
        c.toBlob((b) => ok(b), 'image/png');
      } catch (err) { ok(null); }
    });
  };
  Ed.proyectoParaGuardar = proyectoParaGuardar;

  async function guardarArchivo() {
    Ed.toast('Empaquetando proyecto…');
    const datos = JSON.stringify({ formato: 'forja-juegos', version: F.VERSION, proyecto: proyectoParaGuardar(), assets: await F.Assets.serializar() });
    F.util.descargarBlob(new Blob([datos], { type: 'application/json' }), `${F.util.slug(Ed.proyecto.nombre)}.forja.json`);
  }

  async function cargarDatosProyecto(datos) {
    if (Ed.jugando) Ed.detenerJuego();
    await F.Assets.vaciar();
    F.Generadores.usarProyecto(datos.proyecto || {});   // 🧾 las recetas se generan con el código que trae el proyecto
    await F.Assets.deserializar(datos.assets);
    Ed.proyecto = S.normalizarProyecto(datos.proyecto || {});
    Ed.escena = Ed.proyecto.escenas.find((s) => s.id === Ed.proyecto.escenaInicial) || Ed.proyecto.escenas[0];
    await acomodarArchivosSinCarpeta();
    pilaDeshacer.length = pilaRehacer.length = 0;
    Ed.seleccion = null;
    Ed.seleccionados = new Set();
    Ed.assetSeleccionado = null;
    refrescarTodo();
    Ed.guardarLocal();
  }

  async function abrirArchivo(archivo) {
    let datos;
    try {
      datos = JSON.parse(await archivo.text());
      if (datos.formato !== 'forja-juegos') throw new Error('no es un proyecto de Forja de Juegos');
    } catch (err) {
      Ed.toast('No pude abrir el archivo: ' + err.message, 'error');
      return;
    }
    await cargarDatosProyecto(datos);
    // Viene de un archivo: aún no está en la carpeta de proyectos
    Ed.carpetaActual = null;
    F.Assets.DB.poner('proyecto', { id: 'carpetaActual', valor: null }).catch(() => {});
    Ed.guardarLocal();
    Ed.toast(`Proyecto <b>${Ed.proyecto.nombre}</b> importado. Pulsa <b>Guardar</b> para guardarlo en tu carpeta de proyectos.`);
  }

  Ed.cargarDatosProyecto = cargarDatosProyecto;
  Ed.importarForja = abrirArchivo;
  Ed.guardarArchivoForja = guardarArchivo;

  Ed.exportarJuego = () => exportarJuego();
  Ed.iniciarJuego = () => iniciarJuego();
  Ed.escenaNueva = () => escenaNueva();
  Ed.escenaRenombrar = () => escenaRenombrar();
  Ed.escenaDuplicar = () => escenaDuplicar();
  Ed.escenaBorrar = () => escenaBorrar();
  Ed.alternarSnap = () => { snapActivo = !snapActivo; aplicarSnap(); };
  Ed.modoGizmo = (m) => document.querySelector(`[data-modo="${m}"]`)?.click();

  async function proyectoEnBlanco() {
    if (!confirm('¿Empezar un proyecto nuevo? Se vacían escenas y archivos (las apps se quedan).')) return;
    await cargarDatosProyecto({ proyecto: S.proyectoNuevo(), assets: [] });
  }

  // Exportar: editor/exportar.js (un .html con todo dentro, zip para itch.io o datos.js)
  const exportarJuego = () => Ed.Exportar.exportar();

  function refrescarTodo() {
    F.Assets.aplicarMateriales(Ed.proyecto);
    reconstruirEscena();
    Ed.pintarSelectorEscenas();
    Ed.pintarArchivos();
    Ed.construirPanelEscena();
    Ed.construirPanelJugador();
    Ed.construirPanelProyecto();
    if (Ed.construirPanelMenus) Ed.construirPanelMenus();
    if (Ed.construirPanelArmas) Ed.construirPanelArmas();
    Ed.aplicarAjustes();
    pintarBotonLuces();
  }

  /* =========================================================
     INTERFAZ
     ========================================================= */
  document.querySelectorAll('[data-anadir]').forEach((b) => { b.onclick = () => agregarEntidad(b.dataset.anadir); });
  document.querySelectorAll('[data-modo]').forEach((b) => {
    b.onclick = () => {
      gizmo.setMode(b.dataset.modo);
      document.querySelectorAll('[data-modo]').forEach((x) => x.classList.toggle('activo', x === b));
    };
  });
  /* Pestañas de la derecha: Inspector · Escena · Jugador · Juego ▾ (Ajustes, Menús, HUD, Armas) */
  const subJuego = $('subtabsJuego');
  let ultimoJuego = 'panelProyecto';
  function abrirPanel(id) {
    const enJuego = !!subJuego.querySelector(`[data-panel="${id}"]`);
    if (enJuego) ultimoJuego = id;
    document.querySelectorAll('.tabs-der:not(.subtabs) button').forEach((x) =>
      x.classList.toggle('activo', x.dataset.panel === id || (enJuego && x.dataset.grupo === 'juego')));
    subJuego.querySelectorAll('button').forEach((x) => x.classList.toggle('activo', x.dataset.panel === id));
    subJuego.classList.toggle('visible', enJuego);
    document.querySelectorAll('.panel-der').forEach((p) => p.classList.toggle('visible', p.id === id));
  }
  Ed.abrirPanel = abrirPanel;
  document.querySelectorAll('.tabs-der button').forEach((b) => {
    b.addEventListener('click', () => {
      if (b.dataset.grupo === 'juego') subJuego.querySelector(`[data-panel="${ultimoJuego}"]`).click();
      else abrirPanel(b.dataset.panel);
    });
  });

  /* Modo Sencillo / Completo: el sencillo esconde los ajustes finos (props con av) y las Apps */
  function leerModo() { try { return localStorage.getItem('forja-editor:modo') !== 'completo'; } catch (e) { return true; } }
  Ed.modoSencillo = false;   // el modo Sencillo se quitó: siempre se ve todo (las secciones plegables ordenan)
  function pintarModo() {
    $('btnModo').textContent = Ed.modoSencillo ? '🧭 Sencillo' : '🧰 Completo';
    $('btnModo').classList.toggle('activo', !Ed.modoSencillo);
    document.body.classList.toggle('modo-sencillo', Ed.modoSencillo);
  }
  $('btnModo').onclick = () => {
    Ed.modoSencillo = !Ed.modoSencillo;
    try { localStorage.setItem('forja-editor:modo', Ed.modoSencillo ? 'sencillo' : 'completo'); } catch (e) { /* sin almacenamiento */ }
    pintarModo();
    Ed.pintarInspector();
    for (const f of ['construirPanelEscena', 'construirPanelJugador', 'construirPanelProyecto', 'construirPanelMenus', 'construirPanelHud', 'construirPanelArmas']) {
      if (Ed[f]) Ed[f]();
    }
    Ed.toast(Ed.modoSencillo ? 'Modo sencillo: solo lo esencial' : 'Modo completo: todos los ajustes');
  };
  pintarModo();

  /* Pestañas de la izquierda (riel vertical): una sección a la vez, se recuerda la última */
  function abrirPestanaIzq(id) {
    if (!$(id)) id = 'secEscena';
    document.querySelectorAll('#izq .pest-izq').forEach((x) => x.classList.toggle('activa', x.id === id));
    document.querySelectorAll('#rielIzq [data-tab]').forEach((x) => x.classList.toggle('activo', x.dataset.tab === id));
    try { localStorage.setItem('forja-editor:pestanaIzq', id); } catch (e) { /* nada */ }
  }
  Ed.abrirPestanaIzq = abrirPestanaIzq;
  document.querySelectorAll('#rielIzq [data-tab]').forEach((b) => { b.onclick = () => abrirPestanaIzq(b.dataset.tab); });
  try { abrirPestanaIzq(localStorage.getItem('forja-editor:pestanaIzq') || 'secEscena'); } catch (e) { /* nada */ }
  // ＋ Añadir agrupado por temas (los mismos botones, solo reordenados)
  (function agruparAnadir() {
    const barra = document.querySelector('#detAnadir .barra-anadir');
    if (!barra) return;
    const GR = [
      ['Construir', 'carpeta cubo suelo rampa escalera escala plataforma agua'],
      ['Jugador y nivel', 'inicio salida guardado camara marcador punto'],
      ['Criaturas y personas', 'enemigo aparecedor npc rehen'],
      ['Objetos', 'recogible barril empujable montable baul tienda pedestal bomba'],
      ['Mecanismos', 'puerta brecha palanca disparador condicion trampa barrera'],
      ['Ambiente', 'luz sonido particulas'],
    ];
    const botones = {};
    barra.querySelectorAll('[data-anadir]').forEach((x) => { botones[x.dataset.anadir] = x; });
    const det = $('detAnadir');
    for (const [nom, lista] of GR) {
      const g = document.createElement('div');
      g.className = 'grupo-anadir';
      g.innerHTML = `<span>${nom}</span>`;
      const fila = document.createElement('div');
      fila.className = 'barra-anadir';
      for (const t of lista.split(' ')) if (botones[t]) { fila.appendChild(botones[t]); delete botones[t]; }
      g.appendChild(fila);
      det.insertBefore(g, barra);
    }
    const ultima = [...det.querySelectorAll('.grupo-anadir .barra-anadir')].pop();
    for (const t in botones) ultima.appendChild(botones[t]);   // los nuevos que no estén en la lista
    barra.remove();
    try { det.open = localStorage.getItem('forja-editor:anadirAbierto') !== '0'; } catch (e) { /* nada */ }
    det.addEventListener('toggle', () => { try { localStorage.setItem('forja-editor:anadirAbierto', det.open ? '1' : '0'); } catch (e) { /* nada */ } });
  })();
  // 🌲 árbol / 🗂 por tipo + buscador de entidades
  document.querySelectorAll('#vistaEnts [data-vista]').forEach((b) => {
    b.classList.toggle('activo', b.dataset.vista === Ed.vistaEnts);
    b.onclick = () => {
      Ed.vistaEnts = b.dataset.vista;
      try { localStorage.setItem('forja-editor:vistaEnts', Ed.vistaEnts); } catch (e) { /* nada */ }
      document.querySelectorAll('#vistaEnts [data-vista]').forEach((x) => x.classList.toggle('activo', x === b));
      Ed.pintarArbol();
    };
  });
  $('buscarEnt').oninput = () => Ed.pintarArbol();
  $('btnEscenaInicial').onclick = () => {
    Ed.marcarCambio();
    Ed.proyecto.escenaInicial = Ed.escena.id;
    Ed.pintarSelectorEscenas();
    if (Ed.construirPanelProyecto) Ed.construirPanelProyecto();
    Ed.guardarLocal();
    Ed.toast(`El juego empieza en <b>${Ed.escena.nombre}</b>`);
  };
  document.querySelectorAll('#filtrosAssets [data-filtro]').forEach((b) => {
    b.onclick = () => {
      filtroAssets = b.dataset.filtro;
      document.querySelectorAll('#filtrosAssets [data-filtro]').forEach((x) => x.classList.toggle('activo', x === b));
      Ed.pintarArchivos();
    };
  });
  $('buscarAsset').oninput = () => Ed.pintarArchivos();
  $('btnCarpetaArchivos').onclick = nuevaCarpetaArchivos;
  $('selEscena').onchange = () => cambiarEscena($('selEscena').value);
  $('btnEscenaNueva').onclick = escenaNueva;
  $('btnEscenaRenombrar').onclick = escenaRenombrar;
  $('btnEscenaDuplicar').onclick = escenaDuplicar;
  $('btnEscenaBorrar').onclick = escenaBorrar;
  $('btnEscenaSubir').onclick = () => escenaMover(-1);
  $('btnEscenaBajar').onclick = () => escenaMover(1);
  $('btnEscenaCapitulo').onclick = escenaCapitulo;
  $('version').textContent = 'v' + F.VERSION;
  $('btnSnap').onclick = () => { snapActivo = !snapActivo; aplicarSnap(); };
  $('btnEspacio').onclick = () => Ed.alternarEspacio();
  $('btnLuces').onclick = () => { Ed.alternarLuces(); $('btnLuces').blur(); };
  $('selVista').onchange = () => { Ed.ponerVista($('selVista').value); $('selVista').blur(); };
  $('btnPantalla').onclick = () => { $('centro').requestFullscreen?.(); };
  $('btnJugar').onclick = () => (Ed.jugando ? Ed.detenerJuego() : iniciarJuego());
  $('btnImportar').onclick = () => $('archivoAssets').click();
  $('btnExportar').onclick = exportarJuego;
  $('archivoAssets').onchange = async (e) => {
    for (const f of e.target.files) await Ed.importarArchivo(f.name, f);
    e.target.value = '';
  };
  $('archivoProyecto').onchange = async (e) => { if (e.target.files[0]) await abrirArchivo(e.target.files[0]); e.target.value = ''; };

  // Arrastrar archivos desde Windows (solo archivos de verdad, no elementos del editor)
  let arrastres = 0;
  const sonArchivos = (e) => [...(e.dataTransfer?.types || [])].includes('Files');
  window.addEventListener('dragenter', (e) => { if (!sonArchivos(e)) return; e.preventDefault(); arrastres++; $('soltar').style.display = 'flex'; });
  window.addEventListener('dragleave', (e) => { if (!sonArchivos(e)) return; if (--arrastres <= 0) { arrastres = 0; $('soltar').style.display = 'none'; } });
  window.addEventListener('dragover', (e) => { if (sonArchivos(e)) e.preventDefault(); });
  window.addEventListener('drop', async (e) => {
    if (!sonArchivos(e)) return;
    e.preventDefault();
    arrastres = 0;
    $('soltar').style.display = 'none';
    for (const f of e.dataTransfer.files) {
      if (/\.html?$/i.test(f.name)) await Ed.Apps.cargarApp(f);
      else if (/\.json$/i.test(f.name)) await abrirArchivo(f);
      else await Ed.importarArchivo(f.name, f);
    }
  });

  // Atajos del editor (mientras se juega, los controles los lee FORJA.Entrada)
  window.addEventListener('keydown', (e) => {
    if (Ed.jugando || Ed.pestanaActiva !== 'editor') return;
    if (vuelo.activo) { vuelo.teclas.add(e.code); e.preventDefault(); return; }
    const tag = (e.target.tagName || '').toUpperCase();
    if (tag === 'INPUT' || tag === 'SELECT' || tag === 'TEXTAREA') return;
    const ctrl = e.ctrlKey || e.metaKey;
    if (ctrl && e.code === 'KeyZ') { e.preventDefault(); e.shiftKey ? rehacer() : deshacer(); return; }
    if (ctrl && e.code === 'KeyY') { e.preventDefault(); rehacer(); return; }
    if (ctrl && e.code === 'KeyD') { e.preventDefault(); Ed.duplicarSeleccion(); return; }
    if (ctrl && e.code === 'KeyC') { e.preventDefault(); Ed.copiarSeleccion(); return; }
    if (ctrl && e.code === 'KeyX') { e.preventDefault(); Ed.cortarSeleccion(); return; }
    if (ctrl && e.code === 'KeyV') { e.preventDefault(); Ed.pegar(); return; }
    if (ctrl && e.code === 'KeyA') { e.preventDefault(); Ed.seleccionarTodo(); return; }
    if (ctrl && e.code === 'KeyG') { e.preventDefault(); Ed.agruparSeleccion(); return; }
    if (ctrl) return;
    const modos = { KeyW: 'translate', KeyE: 'rotate', KeyR: 'scale' };
    const vistas = { Numpad7: 'superior', Numpad1: 'frontal', Numpad3: 'lateral' };
    if (modos[e.code]) document.querySelector(`[data-modo="${modos[e.code]}"]`).click();
    else if (vistas[e.code]) Ed.ponerVista(vistaActual === vistas[e.code] ? 'persp' : vistas[e.code]);
    else if (e.code === 'Numpad5') Ed.ponerVista(vistaActual === 'persp' ? 'superior' : 'persp');
    else if (e.code === 'KeyT') Ed.alternarEspacio();
    else if (e.code === 'KeyC' && Ed.Colisiones) Ed.Colisiones.alternar();
    else if (e.code === 'KeyL') Ed.alternarLuces();
    else if (e.code === 'KeyG') { snapActivo = !snapActivo; aplicarSnap(); }
    else if (e.code === 'KeyF') Ed.enfocarSeleccion();
    else if (e.code === 'End') Ed.soltarAlSuelo();
    else if (e.code === 'Delete' || e.code === 'Backspace') Ed.borrarSeleccion();
    else if (e.code === 'KeyP') iniciarJuego();
    else if (e.code === 'Escape') seleccionar(null);
  });
  window.addEventListener('keyup', (e) => vuelo.teclas.delete(e.code));

  /* =========================================================
     BUCLE PRINCIPAL
     ========================================================= */
  let ultimo = performance.now(), fps = 0, cuadros = 0, acumulado = 0;
  const limite = new F.LimiteFps();
  function bucle(ahora) {
    requestAnimationFrame(bucle);
    // El límite de FPS del proyecto vale al jugar (el editor va a la velocidad de la pantalla)
    if (Ed.partida ? !Ed.partida.listo(ahora) : Ed.jugando && !limite.listo(ahora, Ed.proyecto.ajustes.limiteFps)) return;
    const dt = Math.min((ahora - ultimo) / 1000, 1 / 20);
    ultimo = ahora;
    cuadros++;
    acumulado += dt;

    // jugando (▶ o "Probar con menús"): las líneas de las palancas se esconden
    if ((Ed.partida || Ed.jugando) && Ed.pintarConexiones) Ed.pintarConexiones(dt);
    if (Ed.partida) {
      Ed.partida.actualizar(dt);
      const j = Ed.partida && Ed.partida.juego, enJuego = Ed.partida && Ed.partida.estado === 'jugando' && j;
      $('mira').style.display = 'none';   // la mira la dibuja el HUD (Juego ▸ HUD)
      $('depuracion').style.display = enJuego && j.depuracion ? 'block' : 'none';
      if (enJuego && j.depuracion) { const el = $('depuracion'), tx = j.textoDepuracion(fps); if (el._tx !== tx) el.textContent = el._tx = tx; }
    } else if (Ed.jugando && Ed.niveles && Ed.niveles.viajando) {
      vista.render(Ed.juego.camara);   // en pleno fundido: el juego espera
    } else if (Ed.jugando) {
      Ed.juego.actualizar(dt);
      if (Ed.juego && Ed.juego.depuracion) {
        $('depuracion').style.display = 'block';
        { const el = $('depuracion'), tx = Ed.juego.textoDepuracion(fps); if (el._tx !== tx) el.textContent = el._tx = tx; }
      } else {
        $('depuracion').style.display = 'none';
      }
    } else if (Ed.pestanaActiva === 'editor') {
      actualizarVuelo(dt);
      if (!vuelo.activo) orbit.update();
      repararCamara();
      if (Ed.pintarConexiones) Ed.pintarConexiones(dt);   // líneas de palancas (editor/conexiones.js)
      vista.render(camVista());
    }

    if (acumulado >= 0.5) {
      fps = Math.round(cuadros / acumulado);
      cuadros = 0;
      acumulado = 0;
      const info = vista.renderer.info.render;
      $('estado').textContent =
        `FPS ${fps} · draw calls ${info.calls} · triángulos ${fmt(info.triangles)} · render ${lienzo.width}×${lienzo.height} · ` +
        `${Ed.escena.nombre}: ${ents().length} objetos · archivos ${F.Assets.mapa.size}` +
        (Ed.jugando && Ed.juego ? ` · colisión ${fmt(Ed.juego.mundo.n)} tris · ${F.Rendimiento.texto(true)}` : '') +
        (vuelo.activo ? ` · ✈ vuelo ${vuelo.vel.toFixed(0)} m/s` : '') +
        (vistaActual !== 'persp' && !Ed.jugando ? ` · vista ${VISTAS[vistaActual].nombre}` : '') +
        (Ed.seleccionados.size > 1 ? ` · ${Ed.seleccionados.size} seleccionados` : '') +
        (Ed.jugando && Ed.proyecto.ajustes.limiteFps ? ` · límite ${Ed.proyecto.ajustes.limiteFps} fps` : '') +
        (F.Entrada.mando ? ' · 🎮 mando' : '');
    }
  }

  /* =========================================================
     ARRANQUE
     ========================================================= */
  F.Entrada.escuchar(lienzo);
  // Si la tarjeta de video reinicia el visor (o hay demasiadas apps 3D abiertas a la vez), avisar y recuperarlo
  lienzo.addEventListener('webglcontextlost', () => {
    Ed.toast('Se perdió el visor 3D (la tarjeta de video lo reinició o hay muchas apps 3D abiertas). Se recupera solo; si no, recarga con F5: tu trabajo está guardado.', 'error');
  });
  lienzo.addEventListener('webglcontextrestored', () => {
    Ed.aplicarAjustes();
    Ed.toast('Visor 3D recuperado');
  });
  (async () => {
    try {
      await F.Assets.DB.abrir();
    } catch (err) {
      Ed.toast('Sin almacenamiento local: el trabajo no se guardará solo. Usa "Guardar".', 'error');
    }
    try {
      await F.Assets.cargarGuardados();
      const guardado = await F.Assets.DB.leer('proyecto', 'actual');
      if (guardado) {
        Ed.proyecto = S.normalizarProyecto(JSON.parse(guardado.datos));
        Ed.escena = Ed.proyecto.escenas.find((s) => s.id === Ed.proyecto.escenaInicial) || Ed.proyecto.escenas[0];
      }
      // 🧾 las recetas se cargaron antes que el proyecto (que trae sus generadores): se generan ahora
      F.Generadores.usarProyecto(Ed.proyecto);
      await F.Assets.regenerarRecetas();
    } catch (err) {
      console.warn(err);
    }
    await acomodarArchivosSinCarpeta();
    await Ed.Apps.iniciar();
    refrescarTodo();
    orbit.update();
    await Ed.Proyectos.iniciar();
    requestAnimationFrame(bucle);
  })();
})(window.FORJA);
