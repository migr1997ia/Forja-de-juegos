/* =========================================================
   EDITOR · PESTAÑA MENÚS
   Configura los menús del juego (proyecto.menus): tema, menú principal, pausa y qué opciones ve el jugador.
   "▶ Probar con menús" juega el proyecto completo como en el juego exportado
   (portada → menú → juego → Esc = pausa), dentro del visor.
   ========================================================= */
(function (F) {
  'use strict';
  const Ed = F.Editor;
  const $ = (id) => document.getElementById(id);
  const S = F.Escena;

  const ESQ_TEMA = [
    { grupo: 'Aspecto' },
    { k: 'plantilla', t: 'sel', e: 'Plantilla', op: Object.entries(F.Menus.PLANTILLAS).map(([k, v]) => [k, v.nombre]),
      ayuda: 'Al cambiarla pone sus colores y forma; luego puedes ajustar lo que quieras' },
    { k: 'fuente', t: 'asset', e: 'Fuente', tipoAsset: 'fuente', vacio: '(monoespaciada)', ayuda: 'Importa un .ttf/.otf pixelado en Archivos' },
    { k: 'tamano', t: 'num', e: 'Tamaño letra', paso: 1, min: 10, ayuda: 'En pantallas más grandes crece solo' },
    { k: 'colorTexto', t: 'color', e: 'Color texto' },
    { k: 'colorSel', t: 'color', e: 'Color elegido' },
    { k: 'colorFondo', t: 'color', e: 'Color fondo' },
    { k: 'opacidadFondo', t: 'rango', e: 'Opacidad fondo', min: 0, max: 1, paso: 0.05, ayuda: 'Cuánto tapa al juego (pausa) o a la escena de fondo' },
    { k: 'alineacion', t: 'sel', e: 'Alineación', op: [['centro', 'Centro'], ['izquierda', 'Izquierda']] },
    { k: 'mayusculas', t: 'bool', e: 'MAYÚSCULAS' },
    { k: 'sonidoMover', t: 'asset', e: 'Sonido al mover', tipoAsset: 'audio', vacio: '(ninguno)' },
    { k: 'sonidoAceptar', t: 'asset', e: 'Sonido al aceptar', tipoAsset: 'audio', vacio: '(ninguno)' },
  ];

  const esqPrincipal = () => [
    { grupo: 'Menú principal' },
    { k: 'activo', t: 'bool', e: 'Usar menú principal', ayuda: 'Desmarcado: tras "Pulsa cualquier tecla" empieza el juego directo' },
    { k: 'titulo', t: 'texto', e: 'Título', ayuda: 'Vacío = el nombre del proyecto' },
    { k: 'subtitulo', t: 'texto', e: 'Subtítulo' },
    { k: 'logo', t: 'asset', e: 'Logo (imagen)', tipoAsset: 'textura', vacio: '(sin logo)', ayuda: 'Se pone encima del título' },
    { k: 'textoPulsar', t: 'texto', e: 'Texto de portada' },
    { k: 'fondo', t: 'sel', e: 'Fondo', op: [['escena', 'Escena en vivo'], ['imagen', 'Imagen'], ['color', 'Color sólido']] },
    { k: 'escena', t: 'sel', e: 'Escena de fondo', op: [['', '(la inicial)'], ...Ed.proyecto.escenas.map((s) => [s.id, s.nombre])] },
    { k: 'velGiro', t: 'rango', e: 'Giro de cámara', min: 0, max: 0.5, paso: 0.01, ayuda: 'Vueltas lentas alrededor de la escena de fondo' },
    { k: 'imagen', t: 'asset', e: 'Imagen de fondo', tipoAsset: 'textura', vacio: '(ninguna)' },
    { k: 'musica', t: 'asset', e: 'Música', tipoAsset: 'audio', vacio: '(sin música)' },
  ];

  const ESQ_PAUSA = [
    { grupo: 'Menú de pausa' },
    { k: 'titulo', t: 'texto', e: 'Título' },
  ];

  const ESQ_MENSAJE = [
    { grupo: '💬 Caja de mensajes (carteles, notas)' },
    { k: 'posicion', t: 'sel', e: 'Posición', op: [['abajo', 'Abajo'], ['centro', 'Centro'], ['arriba', 'Arriba']] },
    { k: 'ancho', t: 'rango', e: 'Ancho %', min: 30, max: 100, paso: 5 },
    { k: 'tamano', t: 'rango', e: 'Tamaño letra', min: 0.6, max: 2, paso: 0.05 },
    { k: 'alineacion', t: 'sel', e: 'Alineación', op: [['izquierda', 'Izquierda'], ['centro', 'Centro']] },
    { k: 'colorTexto', t: 'color', e: 'Color texto', },
    { k: 'colorFondo', t: 'color', e: 'Color fondo' },
    { k: 'opacidadFondo', t: 'rango', e: 'Opacidad fondo', min: 0, max: 1, paso: 0.05 },
    { k: 'colorBorde', t: 'color', e: 'Color borde' },
    { k: 'grosorBorde', t: 'num', e: 'Grosor borde', min: 0, paso: 1 },
    { k: 'esquinas', t: 'num', e: 'Esquinas redondas', min: 0, paso: 1 },
    { k: 'escribir', t: 'num', e: 'Letras por segundo', min: 0, paso: 5, ayuda: 'Efecto máquina de escribir (RE, Zelda). 0 = todo de golpe' },
    { k: 'sonidoAbrir', t: 'asset', e: 'Sonido al abrir', tipoAsset: 'audio', vacio: '(ninguno)' },
    { k: 'sonidoLetra', t: 'asset', e: 'Sonido por letra', tipoAsset: 'audio', vacio: '(ninguno)', ayuda: 'El "bip" de los diálogos' },
  ];

  const ESQ_BRIEFING = [
    { grupo: '🎯 Fondo' },
    { k: 'fondo', t: 'sel', e: 'Fondo', op: [['aerea', 'Toma aérea girando'], ['jugador', 'Vista del jugador'], ['color', 'Color sólido']] },
    { k: 'velGiro', t: 'rango', e: 'Giro de cámara', min: 0, max: 0.5, paso: 0.01, si: (v) => v.fondo === 'aerea' },
    { k: 'distancia', t: 'rango', e: 'Distancia', min: 0.3, max: 2, paso: 0.05, si: (v) => v.fondo === 'aerea', ayuda: '1 = como el menú principal' },
    { k: 'altura', t: 'rango', e: 'Altura', min: 0, max: 1.5, paso: 0.05, si: (v) => v.fondo === 'aerea' },
    { k: 'colorFondo', t: 'color', e: 'Color fondo' },
    { k: 'opacidadFondo', t: 'rango', e: 'Opacidad fondo', min: 0, max: 1, paso: 0.05, si: (v) => v.fondo !== 'color' },
    { k: 'difuminado', t: 'rango', e: 'Difuminado (px)', min: 0, max: 20, paso: 1, si: (v) => v.fondo !== 'color' },
    { grupo: '🎯 Caja' },
    { k: 'ancho', t: 'rango', e: 'Ancho (px)', min: 320, max: 1100, paso: 10 },
    { k: 'colorCaja', t: 'color', e: 'Color caja' },
    { k: 'opacidadCaja', t: 'rango', e: 'Opacidad caja', min: 0, max: 1, paso: 0.05 },
    { k: 'colorBorde', t: 'color', e: 'Color borde' },
    { k: 'grosorBorde', t: 'num', e: 'Grosor borde', min: 0, paso: 1 },
    { k: 'colorTitulo', t: 'color', e: 'Color título' },
    { k: 'colorTexto', t: 'color', e: 'Color texto' },
    { k: 'colorBoton', t: 'color', e: 'Color botón' },
    { k: 'colorTextoBoton', t: 'color', e: 'Texto del botón (color)' },
    { grupo: '🎯 Textos' },
    { k: 'textoSub', t: 'texto', e: 'Encabezado', ayuda: 'Lo de arriba del título ("Misión")' },
    { k: 'textoObjetivos', t: 'texto', e: 'Título objetivos' },
    { k: 'textoBoton', t: 'texto', e: 'Botón' },
    { k: 'verObjetivos', t: 'bool', e: 'Mostrar objetivos' },
    { k: 'verPista', t: 'bool', e: 'Mostrar "Saltar / Usar / Enter"' },
    { k: 'sonidoAbrir', t: 'asset', e: 'Sonido al abrir', tipoAsset: 'audio', vacio: '(ninguno)' },
  ];

  // Vista previa del briefing en el panel (misma caja que en el juego, con un nivel de ejemplo detrás)
  function previaBriefing(cont, m) {
    const B = F.Misiones.estiloBriefing(Ed.proyecto), t = m.tema || {};
    const rgba = (h, o) => { h = (h || '#000000').replace('#', ''); return `rgba(${parseInt(h.slice(0, 2), 16)},${parseInt(h.slice(2, 4), 16)},${parseInt(h.slice(4, 6), 16)},${o})`; };
    const esc = (x) => String(x || '').replace(/[&<>]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;' }[c]));
    const fuente = t.fuente && F.Assets && F.Assets.mapa.get(t.fuente);
    const fam = (fuente && fuente.familia ? `'${fuente.familia}', ` : '') + 'ui-monospace, Consolas, monospace';
    const escena = B.fondo === 'color' ? '' : B.fondo === 'aerea'
      ? 'linear-gradient(#3b4a63 0 45%, #2c3a24 45%), repeating-linear-gradient(90deg, transparent 0 22px, rgba(0,0,0,.25) 22px 24px)'
      : 'linear-gradient(#26282e 0 40%, #3a3428 40%), radial-gradient(circle at 50% 70%, #6a5a40 0 18%, transparent 19%)';
    const esq = (escala) => `font-size:${escala}px`;
    cont.innerHTML = `<div style="position:relative;height:300px;margin:8px 0 10px;overflow:hidden;border:1px solid #333;background:${escena || '#000'};background-blend-mode:multiply;font-family:${fam}">
      <div style="position:absolute;inset:0;display:flex;align-items:center;justify-content:center;background:${rgba(B.colorFondo, B.fondo === 'color' ? 1 : B.opacidadFondo)};${B.fondo !== 'color' && B.difuminado ? `backdrop-filter:blur(${B.difuminado / 2}px);` : ''}">
        <div style="width:${Math.min(92, B.ancho / 11)}%;max-height:90%;overflow:hidden;box-sizing:border-box;background:${rgba(B.colorCaja, B.opacidadCaja ?? 1)};border:${(B.grosorBorde || 0)}px solid ${B.colorBorde};box-shadow:0 0 0 3px #000;padding:12px 14px;color:${B.colorTexto};${esq(11)}">
          <div style="opacity:.7;font-size:8px;letter-spacing:2px;text-transform:uppercase;margin-bottom:6px">${esc(B.textoSub)}</div>
          <div style="font-size:17px;letter-spacing:2px;text-transform:uppercase;color:${B.colorTitulo};margin-bottom:6px">Nombre del nivel</div>
          ${B.verObjetivos !== false ? `<div style="opacity:.7;font-size:8px;letter-spacing:2px;text-transform:uppercase;margin:8px 0 6px">${esc(B.textoObjetivos)}</div>
          <div style="border-top:1px solid #262a33;padding:4px 0"><span style="color:#e8c547;margin-right:8px">★</span>Llega a la salida</div>
          <div style="border-top:1px solid #262a33;padding:4px 0"><span style="color:#e8c547;margin-right:8px">★★</span>Acaba con todos los enemigos</div>` : ''}
          <div style="text-align:center;margin-top:10px"><span style="display:inline-block;padding:6px 16px;background:${B.colorBoton};color:${B.colorTextoBoton};font-weight:bold;letter-spacing:2px;text-transform:uppercase;${esq(10)}">${esc(B.textoBoton)}</span></div>
          ${B.verPista !== false ? '<div style="text-align:center;font-size:8px;opacity:.55;margin-top:4px">Saltar / Usar / Enter</div>' : ''}
        </div></div></div>`;
  }

  const ESQ_OPCIONES = [
    { grupo: 'Opciones que ve el jugador' },
    { k: 'video', t: 'bool', e: 'Imagen', ayuda: 'Resolución, dither, filtro N64, temblor, deformación y FPS (empiezan como en Proyecto)' },
    { k: 'audio', t: 'bool', e: 'Sonido', ayuda: 'Volumen general, música y efectos' },
    { k: 'controles', t: 'bool', e: 'Controles', ayuda: 'Sensibilidad de ratón y mando, invertir vertical' },
    { k: 'tactil', t: 'bool', e: 'Controles táctiles', ayuda: 'Tamaño, transparencia y mover los botones en pantalla (tablet / celular)' },
    { k: 'mapeo', t: 'bool', e: 'Asignar controles', ayuda: 'Cambiar teclas y botones, con "Restablecer controles"' },
  ];

  function cambio() {
    Ed.guardarLocal();
    if (Ed.partida) Ed.partida.menu.pintar();
  }

  /* Lista editable de botones de un menú: texto, acción (y escena si es "Ir a una escena"), subir/bajar/quitar */
  function editorBotones(cont, clave) {
    const conf = Ed.proyecto.menus[clave];
    const caja = document.createElement('div');
    caja.className = 'botones-menu';
    cont.appendChild(caja);
    const acciones = Object.entries(F.Menus.ACCIONES).filter(([, a]) => a.en.includes(clave));
    const pintar = () => {
      caja.innerHTML = '';
      conf.botones.forEach((b, i) => {
        const fila = document.createElement('div');
        fila.className = 'boton-menu';
        const txt = document.createElement('input');
        txt.value = b.texto;
        txt.title = 'Texto del botón';
        txt.onchange = () => { Ed.marcarCambio(); b.texto = txt.value; cambio(); };
        const acc = document.createElement('select');
        for (const [k, a] of acciones) acc.add(new Option(a.e, k, false, k === b.accion));
        acc.title = 'Qué hace';
        acc.onchange = () => {
          b.accion = acc.value;
          if (b.accion === 'escena' && !b.escena) b.escena = Ed.proyecto.escenas[0].id;
          cambio();
          pintar();
        };
        const mini = (t, titulo, fn, clase = '') => {
          const x = document.createElement('button');
          x.textContent = t;
          x.title = titulo;
          x.className = clase;
          x.onclick = fn;
          return x;
        };
        const linea = document.createElement('div');
        linea.className = 'linea-boton';
        linea.append(txt,
          mini('↑', 'Subir', () => { if (i > 0) { conf.botones.splice(i - 1, 0, conf.botones.splice(i, 1)[0]); cambio(); pintar(); } }),
          mini('↓', 'Bajar', () => { if (i < conf.botones.length - 1) { conf.botones.splice(i + 1, 0, conf.botones.splice(i, 1)[0]); cambio(); pintar(); } }),
          mini('✕', 'Quitar botón', () => { conf.botones.splice(i, 1); cambio(); pintar(); }, 'peligro'));
        fila.append(linea, acc);
        if (b.accion === 'escena') {
          const esc = document.createElement('select');
          for (const s of Ed.proyecto.escenas) esc.add(new Option('→ ' + s.nombre, s.id, false, s.id === b.escena));
          esc.onchange = () => { b.escena = esc.value; cambio(); };
          fila.appendChild(esc);
        }
        caja.appendChild(fila);
      });
      const mas = document.createElement('button');
      mas.textContent = '＋ Añadir botón';
      mas.onclick = () => { conf.botones.push({ texto: 'Botón', accion: acciones[0][0] }); cambio(); pintar(); };
      caja.appendChild(mas);
    };
    pintar();
  }

  /* ❤ Vidas (arcade): se edita en Jugador ▸ Salud y muerte (Ed.formVidas lo pinta allí) */
  Ed.formVidas = function (p, rehacer) {
    const m = Ed.proyecto.menus, base = F.Escena.menusPorDefecto();
      if (!m.vidas) m.vidas = { ...base.vidas };
      const divs = F.Divisas.lista(Ed.proyecto).map((d) => [d.id, `${d.icono || ''} ${d.nombre}`.trim()]);
      Ed.formulario(p, [{ grupo: '❤ Vidas (arcade)' },
        { k: 'activo', t: 'bool', e: 'Usar vidas', ayuda: 'Al morir se gasta una y reapareces en el último checkpoint (o al principio del nivel). Sin vidas: Game Over, y al continuar vuelven las de inicio' },
        { k: 'inicio', t: 'num', e: 'Vidas al empezar', paso: 1, min: 1, si: (v) => v.activo },
        { k: 'max', t: 'num', e: 'Máximo', paso: 1, min: 1, si: (v) => v.activo },
        { k: 'extraCada', t: 'num', e: 'Vida extra cada (divisa)', paso: 10, min: 0, si: (v) => v.activo, ayuda: '0 = nunca. Como las 100 monedas de Mario. También: recogible "❤ Vida extra (1UP)"' },
        { k: 'divisa', t: 'sel', e: 'Divisa que cuenta', op: [['', '(la primera)'], ...divs], si: (v) => v.activo && v.extraCada > 0 },
        { k: 'gastar', t: 'bool', e: 'Se descuentan al dar la vida', si: (v) => v.activo && v.extraCada > 0, ayuda: 'Sí = vuelve a 0 (Mario). No = cuenta cada 100 sin gastar' },
        { k: 'icono', t: 'texto', e: 'Icono', si: (v) => v.activo, ayuda: '❤ ☺ ★… o una imagen' },
        { k: 'imagen', t: 'asset', e: 'Imagen del icono', tipoAsset: 'textura', vacio: '(usar el icono)', si: (v) => v.activo }],
        m.vidas, (k, v, d) => { if (k === 'activo' || k === 'extraCada') { Ed.guardarLocal(); rehacer(); } else if (d) Ed.guardarLocal(); }, { defectos: base.vidas });
  };

  // Lista de menús (como la de Armas): al elegir uno se ve su vista previa y solo sus opciones
  const LISTA = [
    ['tema', '🎨', 'Aspecto de todos', null],
    ['principal', '🏠', 'Menú principal', 'principal'],
    ['pausa', '⏸', 'Pausa', 'pausa'],
    ['opciones', '⚙', 'Opciones del jugador', 'opciones'],
    ['capitulos', '📚', 'Capítulos', 'capitulos'],
    ['misiones', '🗺', 'Misiones (elegir nivel)', 'misiones'],
    ['gameover', '☠', 'Game Over', 'gameover'],
    ['victoria', '🏆', 'Juego completado', 'victoria'],
    ['briefing', '🎯', 'Briefing de misión', null],
    ['mensaje', '💬', 'Caja de mensajes', null],
    ['partidas', '💾', 'Partidas guardadas', null],
  ];
  let elegido = 'principal';
  // vista previa del menú elegido (capítulos y misiones se abren desde el principal)
  function previa(pant) {
    if (!pant) return;
    if (pant === 'capitulos' || pant === 'misiones') {
      Ed.probarMenus('principal');
      if (Ed.partida) Ed.partida.menu.abrir(pant);
    } else Ed.probarMenus(pant);
  }
  const usado = (acc) => ['principal', 'pausa', 'gameover', 'victoria'].some((k) => (Ed.proyecto.menus[k].botones || []).some((b) => b.accion === acc));
  // 🔓 para probar: solo en el editor (el juego exportado sigue bloqueado)
  const ESQ_DESBLOQ = [{ grupo: '🧪 Para probar' },
    { k: 'desbloquearTodo', t: 'bool', e: '🔓 Todos los niveles desbloqueados', ayuda: 'Solo al probar en el editor: capítulos, niveles y misiones abiertos. El juego exportado sigue bloqueando como siempre' }];

  Ed.construirPanelMenus = function () {
    const p = $('panelMenus');
    if (!p) return;
    const scroll = p.scrollTop;
    p.innerHTML = '';
    const m = Ed.proyecto.menus;
    const base = S.menusPorDefecto();
    if (!m.capitulos) m.capitulos = { ...base.capitulos };
    Ed.cabeceraPanel(p, 'Menús del juego', () => {
      if (!confirm('¿Dejar todos los menús como vienen de fábrica?')) return;
      Ed.proyecto.menus = S.menusPorDefecto();
      cambio();
      Ed.construirPanelMenus();
    }, 'Tema, botones y opciones de fábrica');

    const prueba = document.createElement('div');
    prueba.className = 'acciones';
    const bt = document.createElement('button');
    bt.textContent = '▶ Probar completo';
    bt.title = 'Juega todo como en el juego exportado: portada, menú, pausa con Esc, opciones y partidas';
    bt.className = 'primario';
    bt.onclick = () => Ed.probarMenus('portada');
    prueba.appendChild(bt);
    p.appendChild(prueba);

    // Lista
    const lista = document.createElement('div');
    lista.className = 'lista-armas';
    const GRUPOS = { tema: 'General', principal: 'Pantallas', briefing: 'Durante el juego', gameover: 'Final' };
    const orden = ['tema', 'principal', 'pausa', 'opciones', 'capitulos', 'misiones', 'briefing', 'mensaje', 'gameover', 'victoria', 'partidas'];
    for (const [k, ic, nom, pant] of orden.map((x) => LISTA.find((l) => l[0] === x))) {
      if (GRUPOS[k]) { const g = document.createElement('div'); g.className = 'grupo-lista'; g.textContent = GRUPOS[k]; lista.appendChild(g); }
      const el = document.createElement('div');
      el.className = 'item' + (k === elegido ? ' sel' : '');
      let meta = '';
      if (m[k] && Array.isArray(m[k].botones)) meta = m[k].botones.length + ' botones';
      if ((k === 'capitulos' || k === 'misiones') && !usado(k)) meta = '⚠ sin botón';
      el.innerHTML = `<span>${ic}</span><span class="nom">${nom}</span><span class="meta">${meta}</span>`;
      el.title = pant ? 'Clic: editarlo y ver su vista previa' : 'Clic: editarlo';
      el.onclick = () => { elegido = k; Ed.construirPanelMenus(); previa(pant); };
      lista.appendChild(el);
    }
    p.appendChild(lista);

    const vivo = (k, v, definitivo) => { if (Ed.partida) Ed.partida.menu.pintar(); if (definitivo) Ed.guardarLocal(); };
    const e = elegido;
    if (e === 'tema') {
      Ed.formulario(p, ESQ_TEMA, m.tema, (k, v, definitivo) => {
        if (k === 'plantilla') {
          const { nombre, ...pl } = F.Menus.PLANTILLAS[v];
          Object.assign(m.tema, pl);
          cambio();
          Ed.construirPanelMenus();
          return;
        }
        vivo(k, v, definitivo);
      }, { defectos: base.tema });
    } else if (e === 'principal') {
      Ed.formulario(p, esqPrincipal(), m.principal, (k, v, definitivo) => {
        if (Ed.partida && (k === 'fondo' || k === 'escena') && Ed.partida.estado === 'menu') Ed.partida.prepararFondo();
        if (Ed.partida && k === 'musica' && Ed.partida.estado === 'menu') F.Audio.musica(v);
        vivo(k, v, definitivo);
      }, { defectos: base.principal });
      Ed.titulo(p, 'Botones del menú principal');
      editorBotones(p, 'principal');
    } else if (e === 'pausa') {
      Ed.formulario(p, ESQ_PAUSA, m.pausa, vivo, { defectos: base.pausa });
      Ed.titulo(p, 'Botones de pausa');
      editorBotones(p, 'pausa');
    } else if (e === 'briefing') {
      if (!m.briefing) m.briefing = { ...base.briefing };
      const pv = document.createElement('div');
      p.appendChild(pv);
      previaBriefing(pv, m);
      Ed.formulario(p, ESQ_BRIEFING, m.briefing, (k, v, d) => { if (k === 'fondo') Ed.construirPanelMenus(); else previaBriefing(pv, m); vivo(k, v, d); }, { defectos: base.briefing });
      Ed.nota(p, 'Sale al empezar un nivel con misión (🎯 en el nivel) y "Mostrar briefing". Los cambios se ven la próxima vez que se abra.');
    } else if (e === 'opciones') {
      Ed.formulario(p, ESQ_OPCIONES, m.opciones, () => { if (Ed.partida) Ed.partida.menu.pintar(); Ed.guardarLocal(); }, { defectos: base.opciones });
    } else if (e === 'capitulos') {
      Ed.formulario(p, [{ grupo: '📚 Capítulos (como Doom o Quake)' }, { k: 'titulo', t: 'texto', e: 'Título' },
        { k: 'verCuantos', t: 'bool', e: 'Mostrar cuántos niveles tiene', ayuda: '"Episodio 1   (3 niveles)" o solo "Episodio 1"' },
        { k: 'bloquear', t: 'bool', e: 'Bloqueados hasta llegar a ellos', ayuda: 'Capítulos y niveles se abren al llegar a ellos (acabando el anterior). El primero siempre está abierto' }],
        m.capitulos, vivo, { defectos: base.capitulos });
      Ed.formulario(p, ESQ_DESBLOQ, m.misiones, vivo, { defectos: base.misiones });
      const caps = [...new Set(Ed.proyecto.escenas.map((x) => x.capitulo).filter(Boolean))];
      Ed.nota(p, caps.length ? `Capítulos: <b>${caps.join(' · ')}</b>. Elegir uno muestra sus niveles; se ordenan y se cambian de capítulo arrastrando en 🗺 Niveles (izquierda).`
        : '⚠ Ningún nivel tiene capítulo: ponlo con 📚 en la pestaña 🗺 Niveles (izquierda).');
      if (!usado('capitulos')) Ed.nota(p, '⚠ Para verlo en el juego, añade en <b>Menú principal</b> un botón con la acción <b>📚 Capítulos</b>.');
    } else if (e === 'misiones') {
      Ed.formulario(p, [{ grupo: '🗺 Menú de misiones (elegir nivel)' }, { k: 'titulo', t: 'texto', e: 'Título' },
        { k: 'bloquear', t: 'bool', e: 'Niveles bloqueados hasta acabar el anterior' },
        { k: 'soloConMision', t: 'bool', e: 'Solo los niveles con misión', ayuda: 'Si no: todas las escenas' },
        { k: 'alTerminar', t: 'sel', e: 'Al acabar una misión', op: [['menu', 'Volver al menú de misiones'], ['seguir', 'Seguir al nivel siguiente (por su salida)']] }],
        m.misiones, vivo, { defectos: base.misiones });
      Ed.formulario(p, ESQ_DESBLOQ, m.misiones, vivo, { defectos: base.misiones });
      if (!usado('misiones')) Ed.nota(p, '⚠ Para usarlo, añade en <b>Menú principal</b> un botón con la acción <b>🗺 Misiones (elegir nivel)</b>.');
      else Ed.nota(p, 'Cada nivel muestra sus mejores estrellas; el progreso se guarda en el navegador del jugador.');
    } else if (e === 'gameover') {
      Ed.formulario(p, [{ grupo: '☠ Game Over' }, { k: 'titulo', t: 'texto', e: 'Título' }, { k: 'subtitulo', t: 'texto', e: 'Subtítulo' }],
        m.gameover, vivo, { defectos: base.gameover });
      Ed.titulo(p, 'Botones de Game Over');
      editorBotones(p, 'gameover');
      Ed.nota(p, 'Sale al morir (con el módulo "Salud y muerte"). "Salir del juego" en navegador vuelve a la portada: una página no se puede cerrar sola.');
    } else if (e === 'victoria') {
      Ed.formulario(p, [{ grupo: '🏆 Juego completado' }, { k: 'titulo', t: 'texto', e: 'Título' }, { k: 'subtitulo', t: 'texto', e: 'Subtítulo' },
        { k: 'tiempo', t: 'bool', e: 'Mostrar el tiempo de juego' }, { k: 'estrellas', t: 'bool', e: 'Mostrar las estrellas de las misiones' },
        { k: 'rango', t: 'bool', e: 'Mostrar el rango (por tiempo)' },
        { k: 'rangos', t: 'texto', e: 'Rangos (letra:minutos máx.)', si: (v) => v.rango !== false, ayuda: 'En orden, de mejor a peor. "S:300, A:480, B:720" = S si acabas en 5 h o menos, A en 8 h, B en 12 h' },
        { k: 'rangoPeor', t: 'texto', e: 'Si tarda más', si: (v) => v.rango !== false }],
        m.victoria, vivo, { defectos: base.victoria });
      Ed.titulo(p, 'Botones de juego completado');
      editorBotones(p, 'victoria');
      Ed.nota(p, 'Sale con la acción <b>🏆 Juego completado</b> (o <b>🏁 Terminar la misión</b> con "Fin de la partida") de un disparador, palanca o condición del último nivel.');
    } else if (e === 'mensaje') {
      const pv = document.createElement('div');
      pv.style.cssText = 'position:relative;height:220px;margin:8px 0 10px;overflow:hidden;border:1px solid #333;background:linear-gradient(#2a3140 0 50%, #2f2a22 50%)';
      const caja = document.createElement('div');
      const t = m.tema || {}, fu = t.fuente && F.Assets && F.Assets.mapa.get(t.fuente);
      caja.style.cssText = `position:absolute;left:50%;box-sizing:border-box;padding:.7em 1em;line-height:1.45;white-space:pre-wrap;font-size:calc(var(--fm-tam,1)*12px);font-family:${(fu && fu.familia ? `'${fu.familia}', ` : '') + 'ui-monospace, Consolas, monospace'}`;
      caja.textContent = 'NOTA\nLa llave del almacén está en la oficina del segundo piso.';
      pv.appendChild(caja);
      p.appendChild(pv);
      const pintarCaja = () => F.Hud.estiloMensaje(caja, Ed.proyecto);
      pintarCaja();
      Ed.formulario(p, ESQ_MENSAJE, m.mensaje, (k, v, definitivo) => { pintarCaja(); if (definitivo) Ed.guardarLocal(); }, { defectos: base.mensaje });
    } else if (e === 'partidas') {
      Ed.nota(p, `<b>${F.Partidas.RANURAS} ranuras fijas.</b> Guardan escena, posición, hacia dónde mira y el tiempo jugado. ` +
        'Se guardan en el navegador del jugador (cada juego aparte). "Continuar" carga la más reciente. ' +
        'Para que el jugador las borre, añade a un menú un botón con la acción <b>🗑 Borrar partida guardada</b>.');
      if (!m.guardado) m.guardado = { ...base.guardado };
      Ed.formulario(p, [{ grupo: '💾 Dónde y cómo se guarda' },
        { k: 'donde', t: 'sel', e: 'Se puede guardar', op: [['ambos', 'En la pausa y en puntos del mapa'], ['pausa', 'Solo en el menú de pausa'], ['puntos', 'Solo en puntos de guardado (estilo RE)']],
          ayuda: 'Los puntos son la entidad 💾 Punto de guardado (Añadir ▸ Jugador y nivel)' },
        { k: 'alMorir', t: 'sel', e: 'Al morir', op: [['gameover', 'Pantalla de Game Over'], ['reaparecer', 'Reaparecer solo en el último checkpoint']],
          ayuda: 'Con Game Over, si tocaste un checkpoint sale "Continuar desde el punto de control"' },
        { k: 'alEntrarNivel', t: 'bool', e: 'Entrar a un nivel = checkpoint' },
        { k: 'ranuraAuto', t: 'bool', e: 'Ranura de autoguardado', ayuda: 'Los puntos "Autoguardado" escriben aquí; sale en Cargar partida y "Continuar" la usa si es la más reciente' }],
        m.guardado, (k, v, d) => { if (d) Ed.guardarLocal(); }, { defectos: base.guardado });
      Ed.nota(p, '❤ Las <b>vidas (arcade)</b> están en Jugador ▸ Salud y muerte.');
      Ed.titulo(p, 'Partidas guardadas en este navegador');
      const P = F.Partidas, l = P.lista(Ed.proyecto);
      const caja = document.createElement('div');
      caja.className = 'lista-armas';
      l.forEach((d, i) => {
        const el = document.createElement('div');
        el.className = 'item';
        el.innerHTML = `<span>💾</span><span class="nom">Ranura ${i + 1}: ${d ? (d.nombreEscena || d.escena || '¿?') : '(vacía)'}</span><span class="meta">${d && d.fecha ? new Date(d.fecha).toLocaleString() : ''}</span>`;
        if (d) {
          const b = document.createElement('button');
          b.textContent = '🗑'; b.title = 'Borrar esta partida';
          b.onclick = (ev) => { ev.stopPropagation(); if (confirm(`¿Borrar la partida de la ranura ${i + 1}?`)) { P.borrar(Ed.proyecto, i); Ed.construirPanelMenus(); } };
          el.appendChild(b);
        }
        caja.appendChild(el);
      });
      const au = P.leer(Ed.proyecto, P.AUTO);
      if (au) {
        const el = document.createElement('div');
        el.className = 'item';
        el.innerHTML = `<span>💾</span><span class="nom">Autoguardado: ${au.nombreEscena || au.escena}</span><span class="meta">${au.fecha ? new Date(au.fecha).toLocaleString() : ''}</span>`;
        const b = document.createElement('button'); b.textContent = '🗑';
        b.onclick = () => { if (confirm('¿Borrar el autoguardado?')) { P.borrar(Ed.proyecto, P.AUTO); Ed.construirPanelMenus(); } };
        el.appendChild(b); caja.appendChild(el);
      }
      p.appendChild(caja);
      const ac = document.createElement('div');
      ac.className = 'acciones';
      const b1 = document.createElement('button');
      b1.textContent = '🗑 Borrar todas las partidas';
      b1.disabled = !P.hay(Ed.proyecto);
      b1.onclick = () => { if (!confirm('¿Borrar las ' + P.RANURAS + ' partidas guardadas? No se puede deshacer.')) return; for (let i = 0; i <= P.RANURAS; i++) P.borrar(Ed.proyecto, i); Ed.construirPanelMenus(); };
      const b2 = document.createElement('button');
      b2.textContent = '⭐ Borrar progreso de misiones';
      b2.title = 'Estrellas y niveles desbloqueados';
      b2.onclick = () => {
        if (!confirm('¿Borrar estrellas y niveles desbloqueados de las misiones?')) return;
        const id = Ed.proyecto.id || Ed.proyecto.nombre;
        try { localStorage.removeItem('forja-estrellas-' + id); localStorage.removeItem('forja-hechos-' + id); } catch (er) { /* sin almacenamiento */ }
        Ed.construirPanelMenus();
      };
      ac.append(b1, b2);
      p.appendChild(ac);
      Ed.nota(p, 'Solo borra lo guardado en <b>este</b> navegador (el de pruebas). Cada jugador tiene sus propias partidas.');
    }
    Ed.nota(p, 'Mientras pruebas puedes cambiar todo aquí y se ve al momento. <b>Salir</b> o ■ Detener vuelve al editor.');
    p.scrollTop = scroll;
  };
  // Al abrir la pestaña se rehace (por si hay escenas o archivos nuevos en las listas)
  document.querySelector('[data-panel="panelMenus"]').addEventListener('click', () => Ed.construirPanelMenus());
})(window.FORJA);
