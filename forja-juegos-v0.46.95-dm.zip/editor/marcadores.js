/* =========================================================
   EDITOR · MARCADORES DE UN NIVEL (GLB del Entorno de Niveles v2.48+)
   El GLB trae un grupo «marcadores»: nodos vacíos con userData.forja = { marcador, id, ...datos }.
   "Convertir en entidades" los vuelve cosas de juego de verdad, dentro de una carpeta hija del modelo
   (así se mueven con él): ⚑ inicio, ☠ enemigos de la biblioteca, ✚ recogibles, 🔒 puertas con su llave,
   🕹 botones que abren su puerta, ⇅ elevadores, 🚪 salidas y teletransportes, 💡 luces, ⬚ zonas de muerte…
   Cada entidad recuerda de qué marcador salió (ent.deMarcador): al reenviar el nivel desde la app, "Actualizar"
   solo recoloca lo que ya existe y añade lo nuevo (lo que cambiaste a mano en el editor se respeta).
   ========================================================= */
(function (F) {
  'use strict';
  const Ed = F.Editor;
  const S = F.Escena;
  const T = THREE;
  const DEG = 180 / Math.PI;

  // los marcadores del GLB: [{ f, pos: [x,y,z] (en el espacio del modelo), rot (rad), nodo }]
  function leer(a) {
    if (!a || !a.gltf) return [];
    const sc = a.gltf.scene;
    let grupo = null;
    sc.traverse((o) => { if (!grupo && o.name === 'marcadores' && o.children.some((c) => c.userData && c.userData.forja)) grupo = o; });
    if (!grupo) return [];
    sc.updateMatrixWorld(true);
    const inv = sc.matrixWorld.clone().invert(), v = new T.Vector3(), m = new T.Matrix4();
    return grupo.children.filter((o) => o.userData && o.userData.forja && o.userData.forja.marcador).map((o) => {
      m.multiplyMatrices(inv, o.matrixWorld);
      v.setFromMatrixPosition(m);
      return { f: o.userData.forja, pos: [+v.x.toFixed(3), +v.y.toFixed(3), +v.z.toFixed(3)], rot: o.rotation.y, nodo: o };
    });
  }

  const NOMBRE = {
    jugador_inicio: '⚑ Inicio del jugador', luz: '💡 Luces', municion: '✚ Munición', salud: '✚ Salud', armadura: '✚ Armadura', arma: '✚ Armas',
    puerta: '🔒 Puertas', boton_secreto: '🕹 Botones secretos', boton: '🕹 Botones', palanca: '🕹 Palancas', elevador: '⇅ Elevadores',
    teletransporte: '🚪 Teletransportes', teletransporte_destino: '⚑ Llegadas de teletransporte', salida: '🚪 Salidas', zona_muerte: '⬚ Zonas de muerte',
    secreto_mejora: '✚ Secretos (mejora)', cofre: '📦 Cofres', marcador_brujula: '📌 Marcadores de brújula', aparecedor: '🥚 Aparecedores',
    disparador_arena: '⬚ Arenas (te encierran hasta matarlos)',
    trampa_trampilla: '⚠ Trampillas', trampa_trituradora: '⚠ Trituradoras', trampa_lanzaclavos: '⚠ Lanzaclavos',
  };
  const tipoDe = (f) => (/^enemigo_/.test(f.marcador) || f.marcador === 'jefe' ? 'enemigo' : /^llave_/.test(f.marcador) ? 'llave' : /^llegada_/.test(f.marcador) ? 'llegada' : f.marcador);
  const SOPORTADOS = new Set(['jugador_inicio', 'llegada', 'luz', 'municion', 'salud', 'armadura', 'arma', 'puerta', 'boton_secreto', 'boton', 'palanca', 'elevador',
    'teletransporte', 'teletransporte_destino', 'salida', 'zona_muerte', 'secreto_mejora', 'marcador_brujula', 'aparecedor', 'enemigo', 'llave', 'cofre', 'disparador_arena',
    'trampa_trampilla', 'trampa_trituradora', 'trampa_lanzaclavos']);

  // resumen por tipo para el inspector: [[texto, n, soportado]]
  function resumen(lista) {
    const c = new Map();
    for (const q of lista) {
      const t = tipoDe(q.f);
      const k = t === 'enemigo' ? '☠ Enemigos' : t === 'llave' ? '🗝 Llaves' : t === 'llegada' ? '⚑ Llegadas' : NOMBRE[t] || ('· ' + t);
      const x = c.get(k) || { n: 0, ok: SOPORTADOS.has(t) };
      x.n++;
      c.set(k, x);
    }
    return [...c.entries()].map(([k, x]) => [k, x.n, x.ok]);
  }

  // color de una llave por su nombre (fuego = rojo, hielo = azul…)
  function colorLlave(n) {
    const t = String(n || '').toLowerCase();
    if (/fuego|roj|red|sangre/.test(t)) return '#e2412a';
    if (/hielo|azul|blue|agua/.test(t)) return '#3a86e0';
    if (/verde|green|veneno/.test(t)) return '#3fae4a';
    if (/oro|amar|yellow|sol/.test(t)) return '#e2c23a';
    if (/morad|purp|sombra/.test(t)) return '#9a4ae2';
    return '#d8b33a';
  }

  // distancia (m) del rayo contra la geometría del nivel (en el espacio del modelo), o null
  const _ray = new T.Raycaster();
  function rayoNivel(a, o, d, lejos) {
    const sc = a.gltf.scene, geo = sc.getObjectByName('geometria') || sc;
    sc.updateMatrixWorld(true);
    const inv = sc.matrixWorld.clone().invert();
    const ori = new T.Vector3(...o).applyMatrix4(sc.matrixWorld), dir = new T.Vector3(...d).transformDirection(sc.matrixWorld);
    _ray.set(ori, dir); _ray.near = 0; _ray.far = lejos;
    const mallas = [];
    geo.traverse((m) => { if (m.isMesh && !/^deco_/i.test(m.name) && !m.userData.esAgua) mallas.push(m); });
    const h = _ray.intersectObjects(mallas, false)[0];
    if (!h) return null;
    return h.point.applyMatrix4(inv).distanceTo(new T.Vector3(...o));
  }

  /* ---------- Convertir / actualizar ---------- */
  function convertir(ent) {
    const a = F.Assets.mapa.get(ent.asset);
    const lista = leer(a);
    if (!lista.length) return;
    const P = Ed.proyecto, esc = Ed.escena, M = F.Mecanismos;
    Ed.marcarCambio();
    // la carpeta (hija del modelo: se mueve con él)
    let carpeta = esc.entidades.find((e) => e.tipo === 'carpeta' && e.padre === ent.id && e.deMarcadores);
    if (!carpeta) {
      carpeta = S.entidadNueva('carpeta', { nombre: 'Marcadores de ' + (ent.nombre || 'nivel'), padre: ent.id });
      carpeta.deMarcadores = true;
      esc.entidades.push(carpeta);
    }
    const dentro = new Set(S.subarbol ? S.subarbol(esc.entidades, carpeta.id).map((e) => e.id) : []);
    const existentes = new Map(esc.entidades.filter((e) => e.deMarcador && (dentro.has(e.id) || e.padre === carpeta.id)).map((e) => [e.deMarcador, e]));
    const porMarcador = new Map(existentes);   // id del marcador → entidad (para las referencias)
    let nuevos = 0, movidos = 0;
    const ignorados = new Map();
    const objetos = P.objetos || (P.objetos = F.Inventario.objetosPorDefecto());
    const criatura = (c) => (P.criaturas || []).find((x) => x.id === 'cr_' + c) || (P.criaturas || []).find((x) => x.id === 'cr_zombi');
    const municion = (t) => (P.municiones || []).find((m) => m.nombre.toLowerCase().startsWith(String(t || 'balas').toLowerCase().slice(0, 4))) || (P.municiones || [])[0];
    const armaRecogible = () => (P.armas || []).find((x) => x.alEmpezar === false) || (P.armas || []).find((x) => x.nombre === 'Escopeta') || (P.armas || [])[0];
    const llaveObjeto = (idMarcador, nombre) => {
      const id = 'ob_' + String(idMarcador).replace(/[^\w]/g, '_');
      let o = objetos.find((x) => x.id === id);
      if (!o) {
        o = F.Inventario.objetoNuevo({ id, nombre: nombre || 'Llave', tipo: 'llave', icono: '🗝', color: colorLlave(nombre), forma: 'llave', descripcion: 'Abre una puerta del nivel.' });
        objetos.push(o);
      }
      return o;
    };

    // 1) qué entidad hace cada marcador (sin referencias todavía)
    const pendientesRef = [];
    for (const q of lista) {
      const f = q.f, t = tipoDe(f), [x, y, z] = q.pos, ry = +(q.rot * DEG).toFixed(2);
      if (!SOPORTADOS.has(t)) { ignorados.set(f.marcador, (ignorados.get(f.marcador) || 0) + 1); continue; }
      let tipo = null, extra = { pos: [x, y, z], rot: [0, ry, 0] };
      switch (t) {
        case 'jugador_inicio': tipo = 'inicio'; extra.nombre = 'Inicio (del nivel)'; extra.inicio = { principal: true }; break;
        case 'llegada': tipo = 'inicio'; extra.nombre = f.marcador; extra.inicio = { principal: false }; break;
        case 'teletransporte_destino': tipo = 'inicio'; extra.nombre = 'Llegada ' + f.id; extra.inicio = { principal: false }; break;
        case 'luz': tipo = 'luz'; extra.nombre = 'Luz'; extra.pos = [x, y + 0.2, z]; extra.luz = { ...F.Luces.LUZ_BASE, color: f.color || F.Luces.LUZ_BASE.color, alcance: f.alcance || 7 }; break;
        case 'municion': { const mu = municion(f.tipo); tipo = 'recogible'; extra.nombre = mu ? mu.nombre : 'Munición'; extra.pos = [x, y + 0.5, z];
          extra.recogible = { ...F.Recogibles.BASE, tipo: 'municion', municionTipo: mu ? mu.id : '', cantidad: f.cantidad || 12, soloSiFalta: false }; break; }
        case 'salud': case 'armadura': case 'secreto_mejora': tipo = 'recogible'; extra.nombre = t === 'salud' ? 'Vida' : t === 'armadura' ? 'Armadura' : 'Secreto'; extra.pos = [x, y + 0.5, z];
          extra.recogible = { ...F.Recogibles.BASE, tipo: t === 'salud' ? 'vida' : 'armadura', cantidad: f.cantidad || (t === 'secreto_mejora' ? 50 : 25), soloSiFalta: false }; break;
        case 'arma': { const ar = armaRecogible(); tipo = 'recogible'; extra.nombre = ar ? ar.nombre : 'Arma'; extra.pos = [x, y + 0.5, z];
          extra.recogible = { ...F.Recogibles.BASE, tipo: 'arma', arma: ar ? ar.id : '' }; break; }
        case 'llave': { const ob = llaveObjeto(f.id, f.nombre); tipo = 'recogible'; extra.nombre = ob.nombre; extra.pos = [x, y, z];
          extra.recogible = { ...F.Recogibles.BASE, tipo: 'objeto', objeto: ob.id, cantidad: 1, recoger: 'usar', soloSiFalta: false }; break; }
        case 'enemigo': { const cr = criatura(f.criatura); tipo = 'enemigo'; extra.nombre = (f.jefe ? 'Jefe ' : '') + (cr ? cr.nombre : 'Enemigo'); extra.criatura = cr ? cr.id : '';
          extra.enemigo = { ...F.Enemigos.BASE, ...(cr ? F.util.copiar(cr.enemigo) : {}) };
          if (['emboscada', 'enjaulado', 'francotirador'].includes(f.comportamiento)) extra.enemigo.inactivo = 'quieto';
          if (f.jefe) { extra.enemigo.jefe = true; extra.enemigo.nombreJefe = extra.nombre; }
          break; }
        case 'puerta': tipo = 'puerta'; extra.nombre = f.secreta ? 'Muro secreto' : f.llave ? 'Puerta con llave' : 'Puerta';
          extra.esc = [Math.max(0.5, f.ancho || 1.4), Math.max(1, f.alto || 2.3), Math.max(0.2, f.fondo || 0.3)];
          extra.puerta = { ...M.PUERTA, abrir: f.abrir || 'usar', estilo: f.estilo || 'deslizar', marco: !f.secreta };
          if (f.secreta) Object.assign(extra.puerta, { colorHoja: '#6b6355', cerrarConUsar: false, avisoMecanismo: false });   // no se delata
          if (f.llave) pendientesRef.push(() => { const e = porMarcador.get(f.id); const ll = lista.find((r) => r.f.id === f.llave); if (e && ll) e.puerta.llave = llaveObjeto(ll.f.id, ll.f.nombre).id; });
          break;
        case 'boton_secreto': case 'boton': case 'palanca': tipo = 'palanca'; extra.nombre = t === 'boton_secreto' ? 'Botón secreto' : t === 'boton' ? 'Botón' : 'Palanca';
          extra.palanca = { ...F.util.copiar(M.PALANCA), forma: t === 'palanca' ? 'palanca' : 'boton', modo: 'una' };
          if (t !== 'palanca') extra.pos = [x, y - 1.1, z];   // el botón del motor está a 1,1 m de su base
          pendientesRef.push(() => { const e = porMarcador.get(f.id); if (!e || (e.palanca.acciones || []).length) return; e.palanca.acciones = (f.abre || []).map((id) => porMarcador.get(id)).filter(Boolean).map((d) => M.accionNueva({ que: 'abrir', a: d.id })); });
          break;
        case 'elevador': { const caja = q.nodo.getObjectByName('elevador_plataforma'), g = caja && caja.geometry && caja.geometry.parameters || {};
          const al = g.height || 0.2; tipo = 'plataforma'; extra.nombre = 'Elevador'; extra.pos = [x, y + al / 2, z];
          const r = f.recorrido || [0, 3, 0];
          extra.plataforma = { ...M.PLATAFORMA, modo: 'pisar', dx: r[0] || 0, dy: r[1] || 0, dz: r[2] || 0, tiempo: f.tiempo || 3, ancho: g.width || 1.3, alto: al, largo: g.depth || 1.3 };
          break; }
        case 'teletransporte': tipo = 'salida'; extra.nombre = 'Teletransporte'; extra.esc = [1.2, 2, 1.2];
          extra.salida = { ...F.Niveles.SALIDA, destino: esc.id, activar: 'tocar', figura: 'portal', fundido: 0.25 };
          pendientesRef.push(() => { const e = porMarcador.get(f.id), d = porMarcador.get(f.destino); if (e && d) e.salida.llegada = d.id; });
          break;
        case 'salida': { const dest = P.escenas.find((s) => f.nivel && s.nombre.toLowerCase() === String(f.nivel).toLowerCase());
          tipo = 'salida'; extra.nombre = 'Salida del nivel'; extra.salida = { ...F.Niveles.SALIDA, destino: dest ? dest.id : '', activar: 'tocar', figura: 'portal' }; break; }
        case 'zona_muerte': tipo = 'disparador'; extra.nombre = 'Zona de muerte';
          extra.esc = [Math.max(0.5, f.ancho || 2), Math.max(0.5, (f.alto || 0.5) + 0.5), Math.max(0.5, f.fondo || 2)];
          extra.disparador = { ...F.util.copiar(M.DISPARADOR), cuando: 'cada', espera: 1, acciones: [M.accionNueva({ que: 'matar', cantidad: 9999 })] }; break;
        case 'disparador_arena': {
          // al entrar: encierra (bloquea las puertas de la sala), despierta a sus enemigos y apaga las otras entradas.
          // Una condición por sala (apagada hasta entrar) libera las puertas cuando mueren todos
          tipo = 'disparador'; extra.nombre = 'Entrada de arena';
          extra.pos = [x, y - (f.alto ? f.alto / 2 : 1), z];
          extra.esc = [Math.max(0.5, f.ancho || 2), Math.max(0.5, f.alto || 2.5), Math.max(0.5, f.fondo || 2)];
          extra.disparador = { ...F.util.copiar(M.DISPARADOR), cuando: 'una', quien: 'jugador', color: '#ff5a3a', acciones: [] };
          const sala = f.sala != null ? 'sala_' + f.sala : [f.id, ...(f.disparadores || [])].sort().join('|');
          pendientesRef.push(() => {
            const e = porMarcador.get(f.id);
            if (!e) return;
            const clave = 'arena_' + sala;
            let cond = porMarcador.get(clave);
            if (!cond) {
              const ds = lista.filter((r) => r.f.marcador === 'disparador_arena' && ('arena_' + (r.f.sala != null ? 'sala_' + r.f.sala : [r.f.id, ...(r.f.disparadores || [])].sort().join('|'))) === clave);
              const c = ds.reduce((s, r) => [s[0] + r.pos[0] / ds.length, s[1] + r.pos[1] / ds.length, s[2] + r.pos[2] / ds.length], [0, 0, 0]);
              const enem = (f.enemigos || []).map((id) => porMarcador.get(id)).filter(Boolean);
              const pts = (f.puertas || []).map((id) => porMarcador.get(id)).filter(Boolean);
              cond = S.entidadNueva('condicion', { nombre: 'Arena despejada' + (f.sala != null ? ' (sala ' + f.sala + ')' : ''), pos: c.map((v) => +v.toFixed(2)), padre: carpeta.id,
                condicion: { ...F.util.copiar(M.CONDICION), modo: 'todas', unaVez: true, activa: false,
                  requisitos: enem.map((d) => M.requisitoNuevo({ tipo: 'enemigo', a: d.id })),
                  acciones: pts.map((d) => M.accionNueva({ que: 'desbloquear', a: d.id })) } });
              if (!enem.length) cond.condicion.requisitos = [M.requisitoNuevo({ tipo: 'todos' })];
              cond.deMarcador = clave;
              esc.entidades.push(cond);
              porMarcador.set(clave, cond);
              nuevos++;
            }
            if ((e.disparador.acciones || []).length) return;   // ya tenía su lista (o la cambiaste a mano)
            const A = (que, d) => M.accionNueva({ que, a: d.id });
            e.disparador.acciones = [
              ...(f.puertas || []).map((id) => porMarcador.get(id)).filter(Boolean).map((d) => A('bloquear', d)),
              ...(f.enemigos || []).map((id) => porMarcador.get(id)).filter(Boolean).map((d) => A('despertar', d)),
              A('condOn', cond),
              ...(f.disparadores || []).map((id) => porMarcador.get(id)).filter(Boolean).map((d) => A('disOff', d)),
            ];
          });
          break;
        }
        case 'trampa_trampilla': case 'trampa_trituradora': case 'trampa_lanzaclavos': {
          const forma = t.slice(7), pz = q.nodo.getObjectByName('trampa_pieza'), g = pz && pz.geometry && pz.geometry.parameters || {};
          tipo = 'trampa'; extra.nombre = forma === 'trampilla' ? 'Trampilla' : forma === 'trituradora' ? 'Trituradora' : 'Lanzaclavos';
          extra.trampa = { ...F.util.copiar(M.TRAMPA), forma };
          if (forma === 'trampilla') {
            const al = g.height || 0.1;
            Object.assign(extra.trampa, { ancho: g.width || 2, largo: g.depth || 2, grosor: al, danoFoso: 20, retraso: 0.3 });
            extra.pos = [x, +(y + al / 2).toFixed(3), z];   // la entidad es la cara de arriba
          } else if (forma === 'trituradora') {
            const al = g.height || 0.7, b = [x, y - al / 2, z];
            const d = f.recorrido || rayoNivel(a, b, [0, -1, 0], 30);
            Object.assign(extra.trampa, { ancho: g.width || 1.66, largo: g.depth || 1.66, alto: al, recorrido: d ? +Math.max(0.2, (f.recorrido || d - 0.02)).toFixed(2) : 2.5 });
          } else {
            // hacia dónde dispara: lo que diga el marcador, si no al revés de la pared que tiene detrás
            let dx = f.dirX, dz = f.dirZ;
            if (dx == null || dz == null) {
              let mejor = Infinity;
              for (const [ax, az] of [[1, 0], [-1, 0], [0, 1], [0, -1]]) {
                const d = rayoNivel(a, [x, y, z], [ax, 0, az], 1.5);
                if (d != null && d < mejor) { mejor = d; dx = -ax; dz = -az; }
              }
            }
            if (dx != null) extra.rot = [0, +(Math.atan2(-dx, -dz) * DEG).toFixed(2), 0];
          }
          break;
        }
        case 'cofre': { const premio = (P.ajustesMarcadores || {}).cofres !== 'compartido', mu = municion('balas');
          tipo = 'baul'; extra.nombre = premio ? 'Cofre' : 'Baúl';
          extra.baul = { ...F.util.copiar(F.Inventario.BAUL), modo: premio ? 'premio' : 'compartido',
            contenido: premio ? [{ tipo: 'vida', cantidad: 25 }, { tipo: 'municion', municionTipo: mu ? mu.id : '', cantidad: 12 }] : [] };
          break; }
        case 'marcador_brujula': tipo = 'marcador'; extra.nombre = f.texto || 'Marcador'; extra.marcador = { ...F.Brujula.MARCADOR, icono: f.icono || '◆', texto: f.texto || '' }; break;
        case 'aparecedor': { const salen = (f.criaturas || ['zombi']).map((c) => criatura(c)).filter(Boolean).map((c) => ({ criatura: c.id, n: 1 }));
          tipo = 'aparecedor'; extra.nombre = 'Aparecedor'; extra.aparecedor = { ...F.Enemigos.APARECEDOR, modo: f.modo === 'oleadas' ? 'oleadas' : 'zona', salen: salen.length ? salen : F.Enemigos.APARECEDOR.salen }; break; }
      }
      if (!tipo) continue;
      const ya = existentes.get(f.id);
      if (ya) {
        // ya existe: solo se recoloca (lo demás lo pudiste cambiar a mano)
        if (JSON.stringify(ya.pos) !== JSON.stringify(extra.pos) || ya.rot[1] !== extra.rot[1]) movidos++;
        ya.pos = extra.pos; ya.rot = extra.rot;
        if (extra.esc && tipo !== 'enemigo') ya.esc = extra.esc;
        continue;
      }
      if (extra.recogible) extra.recogible.radio = 1.2;   // a veces están en baldas: el jugador no cabe entre ellas
      const e = S.entidadNueva(tipo, { ...extra, padre: carpeta.id });
      e.deMarcador = f.id;
      esc.entidades.push(e);
      porMarcador.set(f.id, e);
      nuevos++;
    }
    // 2) referencias (puerta → su llave, botón → su puerta, teletransporte → su llegada)
    for (const fn of pendientesRef) fn();
    // el inicio del nivel pasa a ser el principal
    const ini = [...porMarcador.values()].find((e) => e.tipo === 'inicio' && e.inicio && e.inicio.principal);
    if (ini) for (const e of esc.entidades) if (e.tipo === 'inicio' && e !== ini && e.inicio && e.inicio.principal) e.inicio.principal = false;
    // el modelo deja de dibujar sus marcadores (hojas de puerta, plataformas): ahora son entidades
    ent.marcadores = 'convertidos';
    Ed.reconstruirEscena ? Ed.reconstruirEscena() : Ed.reconstruirEntidad(ent);
    Ed.pintarArbol && Ed.pintarArbol();
    Ed.guardarLocal();
    Ed.pintarInspector();
    const ign = [...ignorados.entries()].map(([k, n]) => `${k} (${n})`).join(', ');
    Ed.toast(`🏷 ${nuevos} entidad${nuevos === 1 ? '' : 'es'} nueva${nuevos === 1 ? '' : 's'}${movidos ? `, ${movidos} recolocada${movidos === 1 ? '' : 's'}` : ''}` +
      (ign ? `<br>Sin convertir (todavía no hay equivalente): ${ign}` : ''));
    return { nuevos, movidos, ignorados };
  }

  /* ---------- Sección del inspector de un 🧱 modelo ---------- */
  Ed.pintarMarcadoresModelo = function (p, ent, a) {
    const lista = leer(a);
    if (!lista.length) return;
    const titulo = document.createElement('h4');
    titulo.textContent = '🏷 Marcadores del nivel (' + lista.length + ')';
    p.appendChild(titulo);
    const res = resumen(lista);
    const nota = (html) => { const d = document.createElement('div'); d.className = 'nota'; d.innerHTML = html; p.appendChild(d); return d; };
    nota(res.map(([k, n, ok]) => `${ok ? '' : '<span style="opacity:.55">'}${k}: <b>${n}</b>${ok ? '' : ' (aún no)</span>'}`).join(' · '));
    const convertidos = ent.marcadores === 'convertidos';
    if (lista.some((q) => q.f.marcador === 'cofre')) {
      const aj = Ed.proyecto.ajustesMarcadores || (Ed.proyecto.ajustesMarcadores = { cofres: 'premio' });
      p.appendChild(Ed.fila('Los cofres son', Ed.controlEsquema({ t: 'sel', op: [['premio', '🎁 De premio (se abren una vez)'], ['compartido', '📦 Baúles compartidos (Resident Evil)']] }, aj.cofres || 'premio',
        (v) => { aj.cofres = v; Ed.guardarLocal(); }), 'Para los cofres nuevos al convertir. Cada uno se puede cambiar después en su inspector'));
    }
    if (!convertidos) nota('⚠ Todavía son solo marcas: <b>las puertas no se abren</b> y no hay enemigos ni recogibles hasta convertirlos.');
    const acc = document.createElement('div');
    acc.className = 'acciones';
    const b = document.createElement('button');
    b.className = 'primario';
    b.textContent = convertidos ? '⟳ Actualizar desde el nivel' : '🏷 Convertir en entidades';
    b.title = convertidos ? 'Recoloca lo que ya convertiste y añade lo nuevo (lo que cambiaste a mano se queda)' : 'Crea las entidades de juego en una carpeta dentro de este modelo';
    b.onclick = () => convertir(ent);
    acc.appendChild(b);
    if (convertidos) {
      const v = document.createElement('button');
      v.textContent = 'Ver marcas del modelo';
      v.title = 'Vuelve a dibujar las hojas de puerta y plataformas del GLB (para comparar). Las entidades se quedan';
      v.onclick = () => { Ed.marcarCambio(); ent.marcadores = ''; Ed.reconstruirEntidad(ent); Ed.guardarLocal(); Ed.pintarInspector(); };
      acc.appendChild(v);
    }
    p.appendChild(acc);
    if (convertidos) nota('Las entidades están en la carpeta <b>Marcadores de ' + (ent.nombre || 'nivel') + '</b>. Si reenvías el nivel desde la app, pulsa <b>Actualizar</b>.');
  };

  Ed.Marcadores = { leer, convertir, resumen };
})(window.FORJA);
