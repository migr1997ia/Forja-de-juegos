/* =========================================================
   EDITOR · PESTAÑA ARMAS
   Lista de armas del proyecto (proyecto.armas) y el formulario de la elegida.
   Las usa el módulo "Armas" del jugador (1ª y 3ª persona). Se prueban con ▶ Jugar.
   ========================================================= */
(function (F) {
  'use strict';
  const Ed = F.Editor;
  const $ = (id) => document.getElementById(id);
  const S = F.Escena;
  let elegida = null;
  let municionElegida = null;

  const ICONO = { instantaneo: '⌐', proyectil: '➶', cuerpo: '🗡', rayo: '⚡', escudo: '🛡', area: '✸' };

  // Descarga el txt de la guía + un anexo con las armas del proyecto, y el html base
  function exportarGuia() {
    const G = window.FORJA_GUIA;
    if (!G) { Ed.toast('Falta editor/guia-animaciones.js (corre herramientas/empaquetar.js)'); return; }
    const M = F.modulos || {}, modelo = M.modelo, armasMod = M.armas;
    const n3 = (v) => (typeof v === 'number' ? +v.toFixed(3) : v);
    const L = ['', '', '9. ARMAS DE ESTE PROYECTO ("' + (Ed.proyecto.nombre || '') + '", exportado desde el editor v' + F.VERSION + ')',
      '----------------------------------------------------------------------------------------',
      'Cómo están configuradas ahora mismo. 1ª persona: posición = pose de serie del estilo + (Posición X/Y/Z − serie 0.22/−0.2/−0.42),',
      'luego Girar en X/Y/Z (grados, sobre los ejes del arma). 3ª persona: el arma va en hand_R (ver punto 4) y luego',
      '"En la mano" mueve (m) y gira (°) sobre la empuñadura.', ''];
    for (const a of Ed.proyecto.armas) {
      const est = S.estiloCuerpo(a), post = a.tipo === 'cuerpo' ? null : modelo && modelo._postura ? modelo._postura(a) : a.postura3p;
      L.push('· ' + a.nombre + '  [' + a.tipo + (est ? ' · estilo ' + est : '') + (post ? ' · postura 3ª ' + post : '') + ']');
      if (a.tipo === 'cuerpo') {
        L.push('    clic derecho: ' + (a.clicDerecho || 'ambos') + ' · bloquea ' + (a.bloqueo ?? 70) + ' % · parry ' + (a.parry ?? 0.25) + ' s (aturde ' + (a.aturdeParry ?? 1.2) + ' s) · golpe 3ª: ' + (a.golpe3p || 'auto') + ' / ' + (a.cuerpo3p || 'auto'));
        const P = armasMod && armasMod.POSES_FP && armasMod.POSES_FP[est];
        if (P) L.push('    pose 1ª persona de serie (empuñadura xyz, dirección xyz, giro rad): [' + P.map(n3).join(', ') + ']');
      }
      if (a.tipo !== 'cuerpo') L.push('    fogonazo: color ' + (a.fogonazo || '#ffd27a') + ' · tamaño ' + (a.tamFogonazo ?? 1) + ' · sale del nodo Muzzle del modelo (o de su extremo delantero −Z)');
      L.push('    1ª persona: posición (' + [a.posX, a.posY, a.posZ].map(n3).join(', ') + ') · giro (' + [a.fpGiroX || 0, a.fpGiroY || 0, a.fpGiroZ || 0].join('°, ') + '°) · escala ' + (a.escalaModelo ?? 1) + (a.modelo ? ' · modelo ' + ((F.Assets.mapa.get(a.modelo) || {}).nombre || a.modelo) : ' · modelo de cajas del motor'));
      L.push('    3ª persona (en la mano): mover (' + [a.tpsX || 0, a.tpsY || 0, a.tpsZ || 0].map(n3).join(', ') + ') m · girar (' + [a.tpsGiroX || 0, a.tpsGiroY || 0, a.tpsGiroZ || 0].join('°, ') + '°) · tamaño ' + (a.tpsEscala ?? 1));
    }
    const plt = (Ed.proyecto.jugador.modulos || {}).linterna || {}, pam = (Ed.proyecto.jugador.modulos || {}).armas || {};
    L.push('', 'Mano del arma (3ª persona): ' + (pam.manoTps === 'izquierda' ? 'IZQUIERDA (se cambian hand_R y hand_L en la tabla 4c)' : 'derecha (hand_R)'));
    L.push('Linterna: ' + (plt.activo ? 'activa · modo ' + (plt.modo || 'proyectada') + (plt.modo === 'antorcha' ? ' · antorcha ' + (plt.verAntorcha === false ? 'invisible' : 'visible en la mano ' + (pam.manoTps === 'izquierda' ? 'derecha' : 'izquierda')) : ' · sale de los ojos / el pecho (no usa huesos)') : 'apagada (módulo desactivado)'));
    const pm = (Ed.proyecto.jugador.modulos || {}).modelo || {};
    L.push('', 'Jugador ▸ Modelo: ' + (pm.modelo ? ((F.Assets.mapa.get(pm.modelo) || {}).nombre || pm.modelo) : '(el muñeco del motor)') + ' · escala ' + (pm.escala ?? 1) + (pm.girar180 ? ' · girado 180°' : ''));
    const bajar = (nombre, texto, tipo) => {
      const a = document.createElement('a');
      a.href = URL.createObjectURL(new Blob([texto], { type: tipo }));
      a.download = nombre;
      document.body.appendChild(a); a.click(); a.remove();
      setTimeout(() => URL.revokeObjectURL(a.href), 2000);
    };
    bajar('ANIMACIONES-MUNECO.txt', G.txt.replace(/\s*$/, '') + '\n' + L.join('\n') + '\n', 'text/plain;charset=utf-8');
    // el html recibe las armas del proyecto (categoría y ajuste "En la mano") y si hay antorcha
    const pl = (Ed.proyecto.jugador.modulos || {}).linterna || {}, pa = (Ed.proyecto.jugador.modulos || {}).armas || {};
    const datos = {
      manoIzquierda: pa.manoTps === 'izquierda',
      antorcha: !!(pl.activo && pl.modo === 'antorcha' && pl.verAntorcha !== false),
      armas: Ed.proyecto.armas.map((a) => ({
        nombre: a.nombre,
        cat: a.tipo === 'cuerpo' ? S.estiloCuerpo(a) : (modelo && modelo._postura ? modelo._postura(a) : 'pistola') || 'pistola',
        tpsMover: [a.tpsX || 0, a.tpsY || 0, a.tpsZ || 0], tpsGiro: [a.tpsGiroX || 0, a.tpsGiroY || 0, a.tpsGiroZ || 0], tpsEscala: a.tpsEscala ?? 1,
      })),
    };
    const html = G.html.replace('/*FORJA_PROYECTO*/null', JSON.stringify(datos).replace(/</g, '\\u003c'));
    setTimeout(() => bajar('base-generador-personajes.html', html, 'text/html;charset=utf-8'), 300);
    Ed.toast('📤 Guía descargada: <b>ANIMACIONES-MUNECO.txt</b> + <b>base-generador-personajes.html</b>');
  }

  Ed.construirPanelArmas = function () {
    const p = $('panelArmas');
    if (!p) return;
    const scroll = p.scrollTop;
    p.innerHTML = '';
    const armas = Ed.proyecto.armas;
    if (!armas.some((a) => a.id === elegida)) elegida = armas[0] ? armas[0].id : null;
    Ed.cabeceraPanel(p, 'Armas del juego', () => {
      if (!confirm('¿Volver a las 6 armas y 4 municiones de ejemplo? Se pierden las que creaste.')) return;
      const pa = S.paqueteArmas();
      Ed.proyecto.armas = pa.armas;
      Ed.proyecto.municiones = pa.municiones;
      Ed.guardarLocal();
      Ed.construirPanelArmas();
    }, 'Pistola, escopeta, lanzacohetes, rifle de asalto, rayo de energía y cuchillo de ejemplo, con balas, cartuchos, cohetes y energía');

    const mod = Ed.proyecto.jugador.modulos.armas;
    if (!mod || !mod.activo) {
      const n = Ed.nota(p, '⚠ El módulo <b>Armas</b> está apagado. ');
      const b = document.createElement('button');
      b.textContent = 'Activarlo';
      b.onclick = () => { Ed.proyecto.jugador.modulos.armas.activo = true; Ed.construirPanelJugador(); Ed.guardarLocal(); Ed.construirPanelArmas(); };
      n.appendChild(b);
    }
    Ed.nota(p, 'Clic / RT dispara · clic der. / LT apunta · R recarga · rueda, 1-9 o Y cambian. Los objetos con <b>Vida</b> (Inspector) se rompen a tiros.');

    // Lista
    const lista = document.createElement('div');
    lista.className = 'lista-armas';
    armas.forEach((a, i) => {
      const el = document.createElement('div');
      el.className = 'item' + (a.id === elegida ? ' sel' : '');
      const mun = (Ed.proyecto.municiones || []).find((m) => m.id === a.municion);
      el.innerHTML = `<span>${ICONO[a.tipo] || '·'}</span><span class="nom"></span><span class="meta">${mun ? (mun.icono || '') + ' ' : ''}${a.alEmpezar ? i + 1 : 'recoger'}</span>`;
      el.querySelector('.nom').textContent = a.nombre;
      el.onclick = () => { elegida = a.id; Ed.construirPanelArmas(); };
      lista.appendChild(el);
    });
    p.appendChild(lista);
    const idx = armas.findIndex((a) => a.id === elegida);
    Ed.botonera(p, [
      ['＋ Nueva', () => { const a = S.armaNueva({ nombre: 'Arma ' + (armas.length + 1) }); armas.push(a); elegida = a.id; Ed.guardarLocal(); Ed.construirPanelArmas(); }],
      ['Duplicar', () => { if (idx < 0) return; const a = { ...F.util.copiar(armas[idx]), id: F.util.uid(), nombre: armas[idx].nombre + ' 2' }; armas.splice(idx + 1, 0, a); elegida = a.id; Ed.guardarLocal(); Ed.construirPanelArmas(); }],
      ['↑', () => { if (idx > 0) { armas.splice(idx - 1, 0, armas.splice(idx, 1)[0]); Ed.guardarLocal(); Ed.construirPanelArmas(); } }, '', 'Antes en el orden (tecla 1, 2, 3…)'],
      ['↓', () => { if (idx >= 0 && idx < armas.length - 1) { armas.splice(idx + 1, 0, armas.splice(idx, 1)[0]); Ed.guardarLocal(); Ed.construirPanelArmas(); } }],
      ['Borrar', () => { if (idx < 0 || !confirm(`¿Borrar "${armas[idx].nombre}"?`)) return; armas.splice(idx, 1); Ed.guardarLocal(); Ed.construirPanelArmas(); }, 'peligro'],
    ]);

    // 📤 Guía para el generador de personajes: txt (con las armas de ESTE proyecto) + html base
    Ed.botonera(p, [['📤 Guía para el generador (txt + html)', () => exportarGuia(), '',
      'Descarga ANIMACIONES-MUNECO.txt (cómo es y se mueve el muñeco, más la configuración de tus armas) y base-generador-personajes.html. Pásaselos a Claude para adaptar el generador de personajes']]);

    // Formulario de la elegida
    const arma = armas[idx];
    if (arma) {
      const base = S.armaNueva();
      // solo los grupos que tienen sentido para su tipo
      const opMun = [['', 'Propia (solo esta arma)'], ...(Ed.proyecto.municiones || []).map((m) => [m.id, `${m.icono || ''} ${m.nombre}`.trim()])];
      const esq = S.ESQUEMA_ARMA.map((d) => (d.k === 'municion' ? { ...d, op: opMun } : d)).filter((d, i, todo) => {
        let grupo = '';
        for (let k = i; k >= 0; k--) if (todo[k].grupo) { grupo = todo[k].grupo; break; }
        if (arma.tipo === 'cuerpo' && (grupo === 'Balas' || grupo === 'Proyectil')) return false;
        if ((arma.tipo === 'instantaneo' || arma.tipo === 'rayo') && grupo === 'Proyectil') return false;
        if (arma.tipo !== 'rayo' && grupo === 'Rayo continuo') return false;
        if (arma.tipo === 'cuerpo' && d.k === 'municion') return false;
        if (arma.tipo === 'area' && (d.k === 'perdigones' || d.k === 'dispersion' || d.k === 'alcance')) return false;
        return true;
      });
      Ed.formulario(p, esq, arma, (k, v, definitivo) => {
        if (k === 'tipo' || k === 'nombre' || k === 'alEmpezar' || k === 'municion') { Ed.guardarLocal(); Ed.construirPanelArmas(); return; }
        if (definitivo) Ed.guardarLocal();
      }, { defectos: base });
    }

    pintarMuniciones(p);
    p.scrollTop = scroll;
  };

  /* Tipos de munición (proyecto.municiones): se comparten entre armas */
  function pintarMuniciones(p) {
    const ms = Ed.proyecto.municiones || (Ed.proyecto.municiones = []);
    Ed.titulo(p, 'Tipos de munición');
    Ed.nota(p, 'Varias armas pueden usar la misma (balas para pistola y metralleta). Cada tipo multiplica el daño y dice de qué clase es; los enemigos podrán resistirlo o ser débiles a él.');
    if (!ms.some((m) => m.id === municionElegida)) municionElegida = ms[0] ? ms[0].id : null;
    const lista = document.createElement('div');
    lista.className = 'lista-armas';
    for (const m of ms) {
      const usan = Ed.proyecto.armas.filter((a) => a.municion === m.id).length;
      const el = document.createElement('div');
      el.className = 'item' + (m.id === municionElegida ? ' sel' : '');
      el.innerHTML = `<span></span><span class="nom"></span><span class="meta">${usan ? usan + (usan > 1 ? ' armas' : ' arma') : 'sin uso'}</span>`;
      el.firstChild.textContent = m.icono || '·';
      el.querySelector('.nom').textContent = m.nombre;
      el.onclick = () => { municionElegida = m.id; Ed.construirPanelArmas(); };
      lista.appendChild(el);
    }
    p.appendChild(lista);
    const i = ms.findIndex((m) => m.id === municionElegida);
    Ed.botonera(p, [
      ['＋ Nueva', () => { const m = S.municionNueva({ nombre: 'Munición ' + (ms.length + 1) }); ms.push(m); municionElegida = m.id; Ed.guardarLocal(); Ed.construirPanelArmas(); }],
      ['Borrar', () => {
        if (i < 0) return;
        const usan = Ed.proyecto.armas.filter((a) => a.municion === ms[i].id);
        if (!confirm(`¿Borrar "${ms[i].nombre}"?` + (usan.length ? `\n${usan.length} arma(s) pasarán a usar munición propia.` : ''))) return;
        for (const a of usan) a.municion = '';
        ms.splice(i, 1);
        Ed.guardarLocal();
        Ed.construirPanelArmas();
      }, 'peligro'],
    ]);
    const m = ms[i];
    if (m) {
      Ed.formulario(p, S.ESQUEMA_MUNICION, m, (k, v, definitivo) => {
        if (k === 'nombre' || k === 'icono') { Ed.guardarLocal(); Ed.construirPanelArmas(); return; }
        if (definitivo) Ed.guardarLocal();
      }, { defectos: S.municionNueva() });
    }
  }

  document.querySelector('[data-panel="panelArmas"]').addEventListener('click', () => Ed.construirPanelArmas());
})(window.FORJA);
