/* =========================================================
   EDITOR · EXPORTAR JUEGO
   Hace UN solo archivo .html con todo dentro (motor + Three.js + tu proyecto + archivos):
   doble clic y se juega, sin carpetas ni datos.js aparte.
   Formatos:
     html  → mi_juego.html (para abrir en cualquier navegador o mandarlo)
     zip   → mi_juego_itch.zip con index.html dentro (se sube tal cual a itch.io)
     datos → solo datos.js (forma vieja: va en la carpeta juego/ junto a index.html)
   ========================================================= */
(function (F) {
  'use strict';
  const Ed = F.Editor;

  /* ---------- Leer los archivos del motor ----------
     Con doble clic (file://) el navegador no deja leerlos: se usan los de editor/empaque.js.
     Si el editor se abre desde un servidor (http://), se leen directo (siempre al día). */
  async function fuente(ruta) {
    if (location.protocol.startsWith('http')) {
      try {
        const r = await fetch(ruta + '?t=' + Date.now());
        if (r.ok) return await r.text();
      } catch (err) { /* sigue con el empaque */ }
    }
    // editor-completo.html: el motor está dentro de la propia página
    if (window.FORJA_TEXTOS && window.FORJA_TEXTOS[ruta] !== undefined) return window.FORJA_TEXTOS[ruta];
    const enPagina = document.querySelector(`script[data-ruta="${ruta}"]`);
    if (enPagina) return enPagina.textContent.replace(/^\n/, '').replace(/\n$/, '').replace(/<\\\/script/gi, '</script');
    const emp = window.FORJA_EMPAQUE;
    if (emp && emp.archivos[ruta] !== undefined) return emp.archivos[ruta];
    throw new Error(`no encuentro "${ruta}" (falta editor/empaque.js)`);
  }

  // Un </script> dentro del código o de los datos cerraría la etiqueta antes de tiempo
  const seguro = (txt) => txt.replace(/<\/script/gi, '<\\/script');

  async function datosDelJuego() {
    // 🧾 generadores: solo los que usa alguna receta, y comprimidos (el de terrenos pasa de ~1,5 MB a ~0,5 MB)
    const usados = new Set();
    for (const a of F.Assets.mapa.values()) {
      if (!a.esReceta || !a.datos) continue;
      try { usados.add(F.Generadores.clave(F.Generadores.leer(a.datos).receta)); } catch (e) { /* receta rota: no pide nada */ }
    }
    const proyecto = await F.Generadores.empaquetar(Ed.proyectoParaGuardar(), usados);
    return { formato: 'forja-juegos', version: F.VERSION, proyecto, assets: await F.Assets.serializar() };
  }

  async function construirHtml() {
    const emp = window.FORJA_EMPAQUE;
    if (!window.FORJA_UN_ARCHIVO && !location.protocol.startsWith('http') && (!emp || emp.version !== F.VERSION)) {
      Ed.toast(`Aviso: el empaque del motor es ${emp ? 'v' + emp.version : 'inexistente'} y el editor v${F.VERSION}. ` +
        'El juego puede salir con el motor viejo.', 'error');
    }
    const lista = window.FORJA_ARCHIVOS || (emp && emp.lista) || [];
    let html = await fuente('index.html');
    const motor = [];
    // 🎬 las cinemáticas solo pesan en el juego si algún nivel tiene alguna
    const usaCine = Ed.proyecto.escenas.some((s) => (s.cinematicas || []).length);
    for (const ruta of lista) if (ruta !== 'motor/cinematicas.js' || usaCine) motor.push(`<script>/* ${ruta} */\n${seguro(await fuente(ruta))}\n</script>`);
    const datos = await datosDelJuego();
    const arranque = await fuente('juego/arranque.js');
    const nombre = Ed.proyecto.nombre.replace(/[<>&"]/g, '');
    // Se cambian las tres etiquetas <script src> de index.html por su contenido
    html = html
      .replace(/<script src="archivos\.js[^"]*"><\/script>/, () => motor.join('\n'))
      .replace(/<!--[^>]*Exportar juego[^>]*-->\s*/, '')
      .replace(/<script src="juego\/datos\.js[^"]*"><\/script>/, () => `<script>\nwindow.FORJA_JUEGO = ${seguro(JSON.stringify(datos))};\n</script>`)
      .replace(/<script src="juego\/arranque\.js[^"]*"><\/script>/, () => `<script>\n${seguro(arranque)}\n</script>`)
      .replace(/<title>[^<]*<\/title>/, `<title>${nombre}</title>`);
    return `<!-- ${nombre} · hecho con Forja de Juegos ${F.VERSION} -->\n` + html;
  }

  /* ---------- ZIP mínimo (sin comprimir) para itch.io ---------- */
  const TABLA_CRC = (() => {
    const t = new Uint32Array(256);
    for (let n = 0; n < 256; n++) {
      let c = n;
      for (let k = 0; k < 8; k++) c = c & 1 ? 0xedb88320 ^ (c >>> 1) : c >>> 1;
      t[n] = c >>> 0;
    }
    return t;
  })();
  function crc32(bytes) {
    let c = 0xffffffff;
    for (let i = 0; i < bytes.length; i++) c = TABLA_CRC[(c ^ bytes[i]) & 0xff] ^ (c >>> 8);
    return (c ^ 0xffffffff) >>> 0;
  }

  // archivos: [{ nombre, bytes: Uint8Array }]
  function hacerZip(archivos) {
    const partes = [], central = [];
    let desplazamiento = 0;
    const ahora = new Date();
    const hora = (ahora.getHours() << 11) | (ahora.getMinutes() << 5) | (ahora.getSeconds() >> 1);
    const fecha = ((ahora.getFullYear() - 1980) << 9) | ((ahora.getMonth() + 1) << 5) | ahora.getDate();
    for (const a of archivos) {
      const nombre = new TextEncoder().encode(a.nombre);
      const crc = crc32(a.bytes);
      const loc = new DataView(new ArrayBuffer(30));
      loc.setUint32(0, 0x04034b50, true); loc.setUint16(4, 20, true); loc.setUint16(6, 0x0800, true); loc.setUint16(8, 0, true);
      loc.setUint16(10, hora, true); loc.setUint16(12, fecha, true); loc.setUint32(14, crc, true);
      loc.setUint32(18, a.bytes.length, true); loc.setUint32(22, a.bytes.length, true);
      loc.setUint16(26, nombre.length, true); loc.setUint16(28, 0, true);
      partes.push(new Uint8Array(loc.buffer), nombre, a.bytes);
      const cen = new DataView(new ArrayBuffer(46));
      cen.setUint32(0, 0x02014b50, true); cen.setUint16(4, 20, true); cen.setUint16(6, 20, true); cen.setUint16(8, 0x0800, true);
      cen.setUint16(10, 0, true); cen.setUint16(12, hora, true); cen.setUint16(14, fecha, true); cen.setUint32(16, crc, true);
      cen.setUint32(20, a.bytes.length, true); cen.setUint32(24, a.bytes.length, true); cen.setUint16(28, nombre.length, true);
      cen.setUint32(42, desplazamiento, true);
      central.push(new Uint8Array(cen.buffer), nombre);
      desplazamiento += 30 + nombre.length + a.bytes.length;
    }
    const tamCentral = central.reduce((s, p) => s + p.length, 0);
    const fin = new DataView(new ArrayBuffer(22));
    fin.setUint32(0, 0x06054b50, true); fin.setUint16(8, archivos.length, true); fin.setUint16(10, archivos.length, true);
    fin.setUint32(12, tamCentral, true); fin.setUint32(16, desplazamiento, true);
    return new Blob([...partes, ...central, new Uint8Array(fin.buffer)], { type: 'application/zip' });
  }

  /* ---------- Exportar ---------- */
  async function exportar() {
    if (Ed.jugando) Ed.detenerJuego();
    const v = await Ed.dialogo('Exportar juego', [
      { k: 'formato', t: 'sel', e: 'Formato', def: 'html', op: [
        ['html', 'Un archivo .html (doble clic y se juega)'],
        ['zip', 'ZIP para itch.io (index.html dentro)'],
        ['datos', 'Solo datos.js (para la carpeta juego/)'],
      ], ayuda: 'El .html lleva todo dentro: motor, tu proyecto y tus archivos' },
    ], {}, 'Exportar');
    if (!v) return;
    const slug = F.util.slug(Ed.proyecto.nombre);
    Ed.toast('Exportando juego…');
    try {
      if (v.formato === 'datos') {
        const js = '/* Juego exportado con Forja de Juegos ' + F.VERSION + ' */\nwindow.FORJA_JUEGO = ' + JSON.stringify(await datosDelJuego()) + ';\n';
        F.util.descargarBlob(new Blob([js], { type: 'text/javascript' }), 'datos.js');
        Ed.toast('Listo: pon <b>datos.js</b> en la carpeta <b>juego/</b> y abre <b>index.html</b> (no abras el .js con doble clic).');
        return;
      }
      const html = await construirHtml();
      const kb = Ed.kb(new Blob([html]).size);
      if (v.formato === 'zip') {
        F.util.descargarBlob(hacerZip([{ nombre: 'index.html', bytes: new TextEncoder().encode(html) }]), `${slug}_itch.zip`);
        Ed.toast(`Listo: <b>${slug}_itch.zip</b> (${kb}). En itch.io: Kind of project → <b>HTML</b>, sube el zip y marca ` +
          '<b>"This file will be played in the browser"</b>.');
      } else {
        F.util.descargarBlob(new Blob([html], { type: 'text/html' }), `${slug}.html`);
        Ed.toast(`Listo: <b>${slug}.html</b> (${kb}). Doble clic para jugar; funciona sin internet.`);
      }
    } catch (err) {
      Ed.toast('No pude exportar: ' + (err.message || err), 'error');
    }
  }

  Ed.Exportar = { exportar, construirHtml, hacerZip };
})(window.FORJA);
