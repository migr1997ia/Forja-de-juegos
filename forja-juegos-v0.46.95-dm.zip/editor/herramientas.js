/* =========================================================
   FORJA · EDITOR · HERRAMIENTAS
   🔎 Buscador de opciones (arriba del panel derecho): filtra las filas por nombre y abre sus secciones.
   🩺 Revisar proyecto (botón arriba): lista problemas; clic → te lleva al objeto.
   ▶ Desde aquí: Ed.jugarDesdeAqui() empieza a jugar donde mira la cámara del editor (botón y Mayús+P).
   ========================================================= */
(function (F) {
  'use strict';
  const Ed = F.Editor;
  const $ = (id) => document.getElementById(id);
  const norm = (s) => (s || '').normalize('NFD').replace(/[̀-ͯ]/g, '').toLowerCase();

  /* ---------- 🔎 Buscador ---------- */
  const caja = document.createElement('div');
  caja.className = 'buscador-der';
  caja.innerHTML = '<input type="search" placeholder="🔎 Buscar opción… (sombra, maná, vidas)"><button title="Borrar">✕</button>';
  const inp = caja.querySelector('input');
  $('der').insertBefore(caja, $('der').firstChild);

  function filtrar() {
    const q = norm(inp.value.trim());
    caja.classList.toggle('con-texto', !!q);
    for (const p of document.querySelectorAll('.panel-der')) {
      const activo = p.classList.contains('visible') && q;
      p.classList.toggle('buscando', !!activo);
      // deshacer: lo escondido vuelve y las secciones quedan como estaban
      p.querySelectorAll('.fb-no').forEach((x) => x.classList.remove('fb-no'));
      p.querySelectorAll('[data-pleg-prev]').forEach((x) => { x.classList.toggle('abierto', x.dataset.plegPrev === '1'); delete x.dataset.plegPrev; });
      if (!activo) continue;
      let n = 0;
      for (const f of p.querySelectorAll('.fila')) {
        const l = f.querySelector('label');
        const ok = norm(l ? l.textContent + ' ' + (l.title || '') : f.textContent).includes(q);
        if (!ok) f.classList.add('fb-no'); else n++;
      }
      // secciones y módulos: de dentro hacia fuera; se ven si su nombre coincide o tienen algo que coincide
      const mods = [...p.querySelectorAll('.modulo')].reverse();
      for (const m of mods) {
        const cab = m.querySelector(':scope > .modulo-cab');
        const nombre = cab ? norm(cab.textContent).includes(q) : false;
        if (nombre) { m.querySelectorAll('.fb-no').forEach((x) => x.classList.remove('fb-no')); }
        const hay = nombre || m.querySelector('.fila:not(.fb-no)');
        if (!hay) { m.classList.add('fb-no'); continue; }
        if (!('plegPrev' in m.dataset)) m.dataset.plegPrev = m.classList.contains('abierto') ? '1' : '0';
        m.classList.add('abierto');
        n++;
      }
      caja.dataset.n = n;
    }
  }
  inp.addEventListener('input', filtrar);
  caja.querySelector('button').onclick = () => { inp.value = ''; filtrar(); inp.focus(); };
  // al cambiar de pestaña o rehacerse un panel, se vuelve a aplicar
  $('der').addEventListener('click', (e) => { if (e.target.closest('.tabs-der') && inp.value) setTimeout(filtrar, 30); });
  new MutationObserver(() => { if (inp.value && !filtrar._t) filtrar._t = setTimeout(() => { filtrar._t = 0; filtrar(); }, 60); })
    .observe($('der'), { childList: true, subtree: false });
  Ed.filtrarOpciones = filtrar;

  /* ---------- 🩺 Revisar proyecto ---------- */
  function revisar() {
    const P = Ed.proyecto, L = [];
    const escenas = new Map(P.escenas.map((s) => [s.id, s]));
    const armas = new Set((P.armas || []).map((a) => a.id)), muns = new Set((P.municiones || []).map((m) => m.id));
    const objetos = new Set((P.objetos || []).map((o) => o.id)), criaturas = new Set((P.criaturas || []).map((c) => c.id));
    const mod = P.jugador.modulos;
    const add = (s, e, txt, grave) => L.push({ s, e, txt, grave });
    if (!escenas.has(P.escenaInicial)) add(null, null, 'La escena inicial del juego no existe (Juego ▸ Ajustes)', true);
    for (const s of P.escenas) {
      const ids = new Set(s.entidades.map((e) => e.id));
      const texto = JSON.stringify(s.entidades);
      if (!s.entidades.some((e) => e.tipo === 'inicio')) add(s, null, 'No tiene ⚑ Inicio del jugador', true);
      for (const e of s.entidades) {
        const n = `“${e.nombre || e.tipo}”`;
        if (e.tipo === 'salida') {
          const d = e.salida || {};
          if (!d.destino) add(s, e, `${n}: la salida no lleva a ningún nivel`, true);
          else if (d.destino !== '__fin__' && !escenas.has(d.destino)) add(s, e, `${n}: lleva a un nivel que ya no existe`, true);
        }
        if (e.tipo === 'puerta' && e.puerta && e.puerta.abrir === 'mecanismo' && !e.puerta.canal && texto.split(`"${e.id}"`).length <= 2)
          add(s, e, `${n}: se abre "solo con mecanismo" pero nada la abre (sin canal ni palanca/placa)`, true);
        // "Qué hace" de palancas, disparadores, pedestales y condiciones (antes solo se revisaban unas pocas acciones)
        const ACC = F.Mecanismos ? Object.fromEntries(F.Mecanismos.ACCIONES.map((x) => [x.que, x])) : {};
        for (const k of ['palanca', 'disparador', 'pedestal', 'condicion']) {
          const v = e[k];
          if (!v || !Array.isArray(v.acciones)) continue;
          // vacía, salvo que otra cosa la use como zona (extracción de un rehén, zona de cámara…)
          if (!v.acciones.length) { if (texto.split(`"${e.id}"`).length <= 2) add(s, e, `${n}: no hace nada (su lista "Qué hace" está vacía)`); continue; }
          for (const a of v.acciones) {
            const def = ACC[a.que];
            if (!def) { add(s, e, `${n}: tiene una acción que el motor ya no conoce (${a.que})`, true); continue; }
            if (def.obj && !a.a) add(s, e, `${n}: la acción "${def.e}" no dice a cuál afecta`, true);
            else if (def.obj && !ids.has(a.a)) add(s, e, `${n}: la acción "${def.e}" apunta a algo que ya no existe`, true);
            if (a.que === 'nivel' && (!a.destino || !escenas.has(a.destino))) add(s, e, `${n}: "Ir a otro nivel" sin nivel (o el nivel ya no existe)`, true);
            if (a.que === 'cine' && !(s.cinematicas || []).some((c) => c.id === a.cine)) add(s, e, `${n}: "Ver cinemática" sin cinemática (o ya no existe)`, true);
            if (a.que === 'canal' && !String(a.canal || '').trim()) add(s, e, `${n}: "Avisar a un canal" sin canal`, true);
            if (a.que === 'mensaje' && !String(a.texto || '').trim()) add(s, e, `${n}: "Mostrar mensaje" sin texto`);
            if (a.que === 'sonido' && !a.asset) add(s, e, `${n}: "Sonar" sin sonido elegido`);
            if (/^(lluviaOn|lluviaOff|rayo|hora)$/.test(a.que) && !(s.ambiente && s.ambiente.clima)) add(s, e, `${n}: una acción de clima, pero el nivel no tiene 🌦 Clima`);
          }
        }
        const r = e.recogible;
        if (r) {
          if (r.tipo === 'arma' && !armas.has(r.arma)) add(s, e, `${n}: da un arma que no existe`, true);
          if ((r.tipo === 'municion' || r.tipo === 'capacidad') && r.municionTipo && !muns.has(r.municionTipo)) add(s, e, `${n}: da un tipo de munición que no existe`, true);
          if (r.tipo === 'objeto' && !objetos.has(r.objeto)) add(s, e, `${n}: da un objeto que no existe`, true);
          if (r.tipo === 'objeto' && !mod.inventario?.activo) add(s, e, `${n}: da un objeto, pero el módulo Inventario está apagado`);
          if ((r.tipo === 'arma' || r.tipo === 'municion') && !mod.armas?.activo) add(s, e, `${n}: da armas o munición, pero el módulo Armas está apagado`);
        }
        if (e.tipo === 'guardado' && e.guardado && e.guardado.objeto && !mod.inventario?.activo) add(s, e, `${n}: pide un objeto, pero el módulo Inventario está apagado`, true);
        if (e.tipo === 'enemigo' && e.criatura && !criaturas.has(e.criatura)) add(s, e, `${n}: vinculado a una criatura que ya no existe`);
        if (e.tipo === 'aparecedor' && e.aparecedor) {
          const sal = e.aparecedor.salen || [];
          if (!sal.length) add(s, e, `${n}: no tiene ninguna criatura que hacer salir`, true);
          else if (sal.some((x) => x.criatura && !criaturas.has(x.criatura))) add(s, e, `${n}: hace salir una criatura que ya no existe`, true);
        }
      }
      // 🎬 cinemáticas del nivel
      for (const c of s.cinematicas || []) {
        const n = `🎬 “${c.nombre}”`;
        if (!(c.pasos || []).length) add(s, null, `${n}: no tiene pasos`);
        if (c.alTerminar === 'nivel' && (!c.destino || !escenas.has(c.destino))) add(s, null, `${n}: al terminar va a otro nivel, pero no dice a cuál (o ya no existe)`, true);
        if (c.alTerminar === 'cine' && !(s.cinematicas || []).some((x) => x.id === c.siguiente)) add(s, null, `${n}: al terminar sigue otra cinemática que no está elegida`, true);
        if (Ed.avisosPasoCine) (c.pasos || []).forEach((p, i) => { for (const t of Ed.avisosPasoCine(p, s)) add(s, null, `${n}, paso ${i + 1}: ${t}`); });
      }
      // 📼 efectos propios del nivel puestos pero sin nada que se vea
      const am = s.ambiente || {};
      if (am.fxPropio && F.Efectos && F.Efectos.hayFx(am) && !F.Efectos.efectivos({}, am)) add(s, null, 'Efectos de cámara propios con estilo puesto pero todos los controles en 0: no se verá nada');
    }
    return L;
  }

  function mostrarRevision() {
    const L = revisar();
    let fondo = $('revisionProyecto');
    if (!fondo) { fondo = document.createElement('div'); fondo.id = 'revisionProyecto'; document.body.appendChild(fondo); }
    const filas = L.length ? L.map((x, i) => `<div class="rv-item${x.grave ? ' rv-grave' : ''}" data-i="${i}"><span>${x.grave ? '⛔' : '⚠'}</span><b>${x.s ? x.s.nombre : 'Proyecto'}</b> ${x.txt}</div>`).join('')
      : '<div class="rv-ok">✔ Todo en orden: no encontré problemas.</div>';
    fondo.innerHTML = `<div class="rv-caja"><div class="rv-cab"><b>🩺 Revisión del proyecto</b><span>${L.length} aviso${L.length === 1 ? '' : 's'}</span><button>✕</button></div><div class="rv-lista">${filas}</div><small>Clic en un aviso: te lleva al objeto.</small></div>`;
    fondo.style.display = 'flex';
    fondo.querySelector('.rv-cab button').onclick = () => { fondo.style.display = 'none'; };
    fondo.onclick = (ev) => { if (ev.target === fondo) fondo.style.display = 'none'; };
    fondo.querySelectorAll('.rv-item').forEach((el) => {
      el.onclick = () => {
        const x = L[+el.dataset.i];
        if (x.s && x.e) { fondo.style.display = 'none'; Ed.irAEntidad(x.s.id, x.e.id); }
        else if (x.s) { fondo.style.display = 'none'; Ed.cambiarEscena(x.s.id); }
      };
    });
  }
  Ed.revisarProyecto = revisar;
  const bRev = document.createElement('button');
  bRev.id = 'btnRevisar';
  bRev.textContent = '🩺 Revisar';
  bRev.title = 'Busca problemas: salidas sin destino, puertas que nada abre, recogibles de cosas borradas…';
  bRev.onclick = mostrarRevision;
  $('btnExportar').before(bRev);

  /* ---------- 🎬 Probar completo (con menús) ---------- */
  $('btnProbarCompleto').onclick = () => { if (Ed.jugando) Ed.detenerJuego(); Ed.probarMenus('portada'); };

  /* ---------- ▶ Desde aquí ---------- */
  Ed.jugarDesdeAqui = function () {
    if (Ed.jugando) return;
    const cam = Ed.camaraEditor;
    if (!cam) return;
    const pos = cam.position.clone(), dir = new THREE.Vector3();
    cam.getWorldDirection(dir);
    $('btnJugar').click();
    const J = Ed.juego, j = J && J.jugador;
    if (!j) return;
    // el suelo bajo la cámara (si no hay, delante de ella)
    let g = J.mundo.rayo(pos.x, pos.y, pos.z, 0, -1, 0, 300);
    if (!g) { const d = J.mundo.rayo(pos.x, pos.y, pos.z, dir.x, dir.y, dir.z, 300); if (d) { pos.addScaledVector(dir, d.t - 0.5); g = J.mundo.rayo(pos.x, pos.y + 0.5, pos.z, 0, -1, 0, 300); pos.y += 0.5; } }
    if (!g) { Ed.toast('No hay suelo bajo la cámara: empiezas en el inicio', 'aviso'); return; }
    j.teletransportar(pos.x, pos.y - g.t + 0.05, pos.z, Math.atan2(-dir.x, -dir.z), 0);
    Ed.toast('▶ Desde aquí (Mayús+P)');
  };
  const bAqui = document.createElement('button');
  bAqui.id = 'btnDesdeAqui';
  bAqui.textContent = '▶ Desde aquí';
  bAqui.title = 'Jugar empezando donde está la cámara del editor (Mayús+P)';
  bAqui.onclick = () => Ed.jugarDesdeAqui();
  $('btnJugar').before(bAqui);
  addEventListener('keydown', (e) => {
    if (e.code === 'KeyP' && e.shiftKey && !Ed.jugando && !/INPUT|TEXTAREA|SELECT/.test((document.activeElement || {}).tagName || '')) { e.preventDefault(); e.stopImmediatePropagation(); Ed.jugarDesdeAqui(); }
  }, true);
})(window.FORJA);

/* ---- Celular: botones para abrir los paneles laterales como cajones ---- */
(function () {
  const barra = document.getElementById('barra'); if (!barra) return;
  const mk = (txt, lado, tit) => { const b = document.createElement('button'); b.className = 'btn-cajon'; b.textContent = txt; b.title = tit;
    b.onclick = (e) => { e.stopPropagation(); const otro = lado === 'izq' ? 'der' : 'izq'; document.body.classList.remove('ver-' + otro); document.body.classList.toggle('ver-' + lado); }; return b; };
  barra.insertBefore(mk('☰', 'izq', 'Escena y objetos'), barra.firstChild);
  barra.insertBefore(mk('⚙', 'der', 'Propiedades'), barra.children[1]);
  const centro = document.getElementById('centro');
  if (centro) centro.addEventListener('pointerdown', () => document.body.classList.remove('ver-izq', 'ver-der'));
})();
