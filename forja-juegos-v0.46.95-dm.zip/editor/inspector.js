/* =========================================================
   EDITOR · INSPECTOR
   Formularios generados desde esquemas: entidades, archivos (con sus materiales),
   ambiente de la escena, módulos del jugador y ajustes del proyecto.
   ========================================================= */
(function (F) {
  'use strict';
  const Ed = (F.Editor = F.Editor || {});
  const $ = (id) => document.getElementById(id);
  const fmt = F.util.fmt;
  const S = F.Escena;

  /* =========================================================
     PIEZAS DE FORMULARIO
     ========================================================= */
  /* Fila etiqueta + control. revertir = { modificado(): bool, alRevertir(), texto } añade el ↺ de esa propiedad
     (como la flechita de Godot): solo se ve cuando el valor es distinto del de por defecto. */
  function fila(etiqueta, control, ayuda, revertir) {
    const f = document.createElement('div');
    f.className = 'fila';
    const l = document.createElement('label');
    l.textContent = etiqueta;
    if (ayuda) l.title = ayuda;
    const b = document.createElement('button');
    b.className = 'revertir';
    b.textContent = '↺';
    f.append(l, control, b);
    f._actualizar = () => {
      b.style.visibility = revertir && revertir.modificado() ? 'visible' : 'hidden';
    };
    if (revertir) {
      b.title = 'Volver al valor por defecto' + (revertir.texto ? ': ' + revertir.texto : '');
      b.onclick = () => revertir.alRevertir();
    }
    f._actualizar();
    return f;
  }

  const igual = (a, b) => JSON.stringify(a) === JSON.stringify(b);
  const textoValor = (v) => (typeof v === 'boolean' ? (v ? 'sí' : 'no') : v === '' ? '(ninguno)' : Array.isArray(v) ? v.join(', ') : String(v));
  Ed.fila = fila;

  // Cabecera de panel: título a la izquierda y "↺ Por defecto" a la derecha, siempre visible arriba
  function cabeceraPanel(cont, texto, alRestablecer, ayuda) {
    const c = document.createElement('div');
    c.className = 'cab-panel';
    const t = document.createElement('h4');
    t.textContent = texto;
    c.appendChild(t);
    if (alRestablecer) {
      const b = document.createElement('button');
      b.textContent = '↺ Por defecto';
      b.title = ayuda || 'Volver a los valores por defecto';
      b.onclick = alRestablecer;
      c.appendChild(b);
    }
    cont.appendChild(c);
    return c;
  }

  function titulo(cont, texto) {
    const h = document.createElement('h4');
    h.textContent = texto;
    cont.appendChild(h);
    return h;
  }

  function nota(cont, html) {
    const d = document.createElement('div');
    d.className = 'nota';
    d.innerHTML = html;
    cont.appendChild(d);
    return d;
  }

  function botonera(cont, botones) {
    const acc = document.createElement('div');
    acc.className = 'acciones';
    for (const [texto, fn, clase, ayuda] of botones) {
      const b = document.createElement('button');
      b.textContent = texto;
      b.className = clase || '';
      if (ayuda) b.title = ayuda;
      b.onclick = fn;
      acc.appendChild(b);
    }
    cont.appendChild(acc);
    return acc;
  }

  /* Control para una propiedad de esquema.
     alCambiar(valor, definitivo): definitivo=false mientras se arrastra un slider o se elige color */
  function controlEsquema(d, valor, alCambiar) {
    let c;
    if (d.t === 'rango') {
      c = document.createElement('div');
      c.className = 'rango';
      const r = document.createElement('input');
      r.type = 'range'; r.min = d.min; r.max = d.max; r.step = d.paso; r.value = valor;
      const s = document.createElement('span');
      s.textContent = valor;
      r.oninput = () => { s.textContent = r.value; alCambiar(parseFloat(r.value), false); };
      r.onchange = () => alCambiar(parseFloat(r.value), true);
      c.append(r, s);
    } else if (d.t === 'num') {
      c = document.createElement('input');
      c.type = 'number'; c.step = d.paso ?? 0.1; c.value = valor;
      if (d.min !== undefined) c.min = d.min;
      c.onchange = () => alCambiar(parseFloat(c.value) || 0, true);
    } else if (d.t === 'bool') {
      c = document.createElement('input');
      c.type = 'checkbox'; c.checked = !!valor;
      c.onchange = () => alCambiar(c.checked, true);
    } else if (d.t === 'color') {
      c = document.createElement('input');
      c.type = 'color'; c.value = valor;
      c.oninput = () => alCambiar(c.value, false);
      c.onchange = () => alCambiar(c.value, true);
    } else if (d.t === 'sel') {
      c = document.createElement('select');
      for (const [v, t] of d.op) c.add(new Option(t, v, false, String(valor) === String(v)));
      c.onchange = () => alCambiar(typeof d.op[0][0] === 'number' ? Number(c.value) : c.value, true);
    } else if (d.t === 'asset') {
      c = document.createElement('select');
      c.add(new Option(d.vacio || '(ninguno)', ''));
      for (const a of F.Assets.de(d.tipoAsset || 'modelo')) c.add(new Option(a.nombre, a.id, false, valor === a.id));
      c.onchange = () => alCambiar(c.value, true);
    } else if (d.t === 'ent' || d.t === 'objeto') {
      // elegir una entidad de este nivel (de un tipo) o un objeto de la mochila (Juego ▸ Objetos)
      c = document.createElement('select');
      const L = d.t === 'ent' ? Ed.escena.entidades.filter((e) => e.tipo === d.tipoEnt) : (Ed.proyecto.objetos || []);
      c.add(new Option(L.length ? '(ninguno)' : (d.t === 'ent' ? '(no hay ninguno en este nivel)' : '(no hay objetos en Juego ▸ Objetos)'), ''));
      for (const e of L) c.add(new Option(e.nombre, e.id, false, valor === e.id));
      if (valor && !L.some((e) => e.id === valor)) c.add(new Option('⚠ (ya no existe)', valor, false, true));
      c.onchange = () => alCambiar(c.value, true);
    } else if (d.t === 'textoLargo') {
      c = document.createElement('textarea');
      c.rows = d.filas || 4;
      c.value = valor ?? '';
      c.onchange = () => alCambiar(c.value, true);
    } else {
      c = document.createElement('input');
      c.value = valor ?? '';
      c.onchange = () => alCambiar(c.value, true);
    }
    return c;
  }
  Ed.controlEsquema = controlEsquema;

  /* Formulario completo de un esquema.
     alCambiar(k, valor, definitivo, anterior)
     opciones.defectos: valores por defecto (si no, d.def del esquema)
     opciones.antes(): se llama una vez al empezar cada cambio (para "deshacer") */
  /* 📂 Secciones plegables (acordeón): cada { grupo } del esquema es una caja que se abre y cierra.
     Se recuerda abierta/cerrada por nombre (localStorage); la primera de cada formulario empieza abierta */
  let PLEG = null;
  const plegLeer = () => { if (!PLEG) { try { PLEG = JSON.parse(localStorage.getItem('forja-editor:plegables')) || {}; } catch (e) { PLEG = {}; } } return PLEG; };
  const plegGuardar = () => { try { localStorage.setItem('forja-editor:plegables', JSON.stringify(PLEG)); } catch (e) { /* nada */ } };
  function seccion(cont, texto, abiertaSiNueva) {
    const st = plegLeer(), abierta = texto in st ? st[texto] : abiertaSiNueva;
    const caja = document.createElement('div');
    caja.className = 'modulo plegable' + (abierta ? ' abierto' : '');
    const cab = document.createElement('div');
    cab.className = 'modulo-cab';
    const fl = document.createElement('span'); fl.className = 'flecha'; fl.textContent = abierta ? '▼' : '▶';
    const b = document.createElement('b'); b.textContent = texto;
    cab.append(fl, b);
    cab.onclick = () => { const a = caja.classList.toggle('abierto'); fl.textContent = a ? '▼' : '▶'; plegLeer()[texto] = a; plegGuardar(); };
    const cuerpo = document.createElement('div'); cuerpo.className = 'modulo-cuerpo';
    caja.append(cab, cuerpo);
    cont.appendChild(caja);
    return { caja, cuerpo };
  }
  Ed.seccion = seccion;

  function formulario(cont0, esquema, valores, alCambiar, opciones = {}) {
    let cont = cont0, primera = true;
    // d.si(valores) → false esconde la fila; en un { grupo, si } esconde todo el grupo
    const condicionales = [];
    const revisar = () => { for (const [el, si] of condicionales) el.style.display = si(valores) ? '' : 'none'; };
    let siGrupo = null;
    let saltarGrupo = false;
    for (const d of esquema) {
      // modo sencillo: lo marcado como avanzado (av) no se pinta (los valores siguen ahí)
      if (d.grupo) saltarGrupo = !!(Ed.modoSencillo && d.av);
      if (saltarGrupo || (Ed.modoSencillo && d.av)) continue;
      if (d.grupo) {
        siGrupo = d.si || null;
        const sc = seccion(cont0, d.grupo, primera);
        primera = false;
        cont = sc.cuerpo;
        if (siGrupo) condicionales.push([sc.caja, siGrupo]);
        continue;
      }
      const sg = siGrupo;   // copia: siGrupo cambia en el siguiente grupo
      const si = d.si && sg ? (v) => sg(v) && d.si(v) : (d.si || sg);
      const def = opciones.defectos ? opciones.defectos[d.k] : d.def;
      const crear = () => {
        let enCurso = false;
        const ctrl = controlEsquema(d, valores[d.k], (v, definitivo) => {
          if (!enCurso && opciones.antes) opciones.antes();
          enCurso = !definitivo;
          const anterior = valores[d.k];
          valores[d.k] = v;
          alCambiar(d.k, v, definitivo, anterior);
          f._actualizar();
          if (condicionales.length) revisar();
        });
        const f = fila(d.e, ctrl, d.ayuda, def === undefined ? null : {
          texto: textoValor(def),
          modificado: () => !igual(valores[d.k], def),
          alRevertir: () => {
            if (opciones.antes) opciones.antes();
            const anterior = valores[d.k];
            valores[d.k] = F.util.copiar(def);
            alCambiar(d.k, valores[d.k], true, anterior);
            if (f.isConnected) {
              const nueva = crear();
              const c = condicionales.find((x) => x[0] === f);
              if (c) c[0] = nueva;
              f.replaceWith(nueva);
            }
            if (condicionales.length) revisar();
          },
        });
        return f;
      };
      const fila0 = crear();
      if (si) condicionales.push([fila0, si]);
      cont.appendChild(fila0);
    }
    revisar();
  }
  Ed.formulario = formulario;

  /* Primeros pasos: una guía corta con lo que ya hiciste marcado (se puede esconder) */
  function pintarPrimerosPasos(p) {
    let oculto = false;
    try { oculto = localStorage.getItem('forja-editor:pasos-oculto') === '1'; } catch (e) { /* nada */ }
    if (oculto) return;
    const ents = Ed.escena.entidades;
    const pr = Ed.proyecto, m = pr.jugador.modulos;
    const pasos = [
      ['Pon algo de suelo y paredes: botones ▭ ⬛ ◢ ▤ arriba del árbol (o importa tu nivel .glb en Archivos)',
        ents.filter((e) => ['suelo', 'cubo', 'rampa', 'escalera', 'modelo'].includes(e.tipo)).length > 2],
      ['Coloca el inicio del jugador ⚑', ents.some((e) => e.tipo === 'inicio')],
      ['Elige cómo se juega: Jugador ▸ Cámara (1ª o 3ª persona) y activa los módulos que quieras',
        Object.values(m).filter((x) => x.activo).length > 8, () => Ed.abrirPanel('panelJugador')],
      ['Añade luces 💡 y recogibles ✚', ents.some((e) => e.tipo === 'luz' || e.tipo === 'recogible')],
      ['Prueba con ▶ Jugar (P)', !!Ed.yaJugo],
      ['Dale cara: Juego ▸ Menús y HUD', !!(pr.menus.principal.titulo || (pr.hud && pr.hud.plantilla)), () => Ed.abrirPanel('panelMenus')],
      ['Exporta tu juego (un .html para jugar o un .zip para itch.io)', false],
    ];
    const caja = document.createElement('div');
    caja.className = 'primeros-pasos';
    caja.innerHTML = '<b class="tit">Primeros pasos</b><ol></ol>';
    const ol = caja.querySelector('ol');
    for (const [texto, hecho, ir] of pasos) {
      const li = document.createElement('li');
      li.textContent = texto;
      if (hecho) li.className = 'hecho';
      if (ir) { const b = document.createElement('button'); b.textContent = 'Ir'; b.onclick = ir; li.appendChild(b); }
      ol.appendChild(li);
    }
    const quitar = document.createElement('button');
    quitar.textContent = 'Ya lo sé, esconder';
    quitar.style.marginTop = '6px';
    quitar.onclick = () => { try { localStorage.setItem('forja-editor:pasos-oculto', '1'); } catch (e) { /* nada */ } caja.remove(); };
    caja.appendChild(quitar);
    p.appendChild(caja);
  }

  /* Esquema de un enemigo: qué es, cómo se comporta, se mueve, percibe, ataca, recibe daño y qué deja al morir */
  function esquemaEnemigo() {
    const EN = F.Enemigos;
    const noFijo = (v) => v.tipo !== 'fijo';
    const lejos = (v) => v.ataque === 'disparo' || v.ataque === 'proyectil';
    const nombresDano = { normal: 'Normal', perforante: 'Perforante', explosivo: 'Explosivo', fuego: 'Fuego', electrico: 'Eléctrico', magico: 'Mágico', veneno: 'Veneno', hielo: 'Hielo' };
    const sueltas = [['', 'Nada'], ...Object.entries(F.Recogibles.PRESETS).map(([k, v]) => [k, v.nombre]),
      ...(Ed.proyecto.objetos || []).map((o) => ['obj:' + o.id, `${o.icono || '◆'} ${o.nombre} (mochila)`])];
    const cazador = (v) => v.actitud === 'depredador' || v.actitud === 'agresivo';
    const ESQ = [
      { grupo: 'Qué es' },
      { k: 'tipo', t: 'sel', e: 'Tipo', op: [['terrestre', '🚶 Terrestre'], ['volador', '🦇 Volador'], ['acuatico', '🐟 Acuático (solo en el agua)'], ['fijo', '🗼 Fijo (torreta)']] },
      { k: 'vida', t: 'num', e: 'Vida', paso: 5, min: 1 },
      { grupo: 'Comportamiento' },
      { k: 'actitud', t: 'sel', e: 'Actitud', op: [['agresivo', '😠 Agresivo: te caza'], ['neutral', '😐 Neutral: se defiende si le atacas'],
        ['pacifico', '🐇 Pacífico: huye'], ['depredador', '🐺 Depredador: caza animales'], ['aliado', '🛡 Aliado: tu equipo (máx. 3, órdenes con G)']],
        ayuda: 'El neutral y el depredador solo van a por ti si les haces daño. Aliado: ataca a los enemigos, te sigue y obedece (G = órdenes)' },
      { k: 'seguirAlEmpezar', t: 'bool', e: 'Te sigue al empezar', si: (v) => v.actitud === 'aliado', ayuda: 'Si no, empieza esperando donde está' },
      { k: 'fuegoAmigo', t: 'bool', e: 'Recibe fuego amigo', si: (v) => v.actitud === 'aliado', ayuda: 'Tus balas le hacen daño (nunca se vuelve contra ti)' },
      { k: 'etiqueta', t: 'texto', e: 'Etiqueta (especie o grupo)', ayuda: 'Avisa a los de su misma etiqueta. Los depredadores cazan por etiqueta. Ej.: presa, ganado, lobo' },
      { k: 'caza', t: 'texto', e: 'Caza a (etiquetas)', si: cazador, ayuda: 'Separadas por comas: presa, ganado. "jugador" también vale' },
      { k: 'avisar', t: 'num', e: 'Avisa a los suyos (m)', paso: 1, min: 0, ayuda: 'Al verte o recibir daño, los de su etiqueta en este radio atacan (o huyen) con él. 0 = a nadie' },
      { k: 'huirConVida', t: 'rango', e: 'Huye con poca vida', min: 0, max: 1, paso: 0.05, si: (v) => v.actitud !== 'pacifico' && v.tipo !== 'fijo', av: true,
        ayuda: '0 = nunca · 0.25 = cuando le queda un cuarto de vida' },
      { k: 'jefe', t: 'bool', e: 'Es un jefe', ayuda: 'Sale su barra de vida arriba mientras pelea contigo' },
      { k: 'nombreJefe', t: 'texto', e: 'Nombre en la barra', si: (v) => v.jefe },
      { k: 'soloMolde', t: 'bool', e: 'Solo como molde', ayuda: 'No sale en la escena: lo copian los aparecedores (escribe su nombre en el aparecedor)' },
      { grupo: 'Moverse', si: noFijo },
      { k: 'velocidad', t: 'num', e: 'Velocidad caminando', paso: 0.1, min: 0 },
      { k: 'velCorrer', t: 'num', e: 'Velocidad persiguiendo', paso: 0.1, min: 0 },
      { k: 'giro', t: 'num', e: 'Rapidez al girar', paso: 0.5, min: 0.5, av: true },
      { k: 'inactivo', t: 'sel', e: 'Sin verte', op: [['deambular', 'Deambula cerca de su sitio'], ['quieto', 'Se queda quieto']] },
      { k: 'radioDeambular', t: 'num', e: 'Radio de paseo (m)', paso: 0.5, min: 0.5, si: (v) => v.inactivo === 'deambular' && !v.patrulla },
      { k: 'patrulla', t: 'sel', e: 'Patrulla (ruta)', op: [['', '(ninguna)'], ...rutasEscena()],
        ayuda: 'Recorre los 📍 puntos de esa ruta en vez de pasear. Añade puntos con 📍 en la barra de Escena' },
      { k: 'enAgua', t: 'sel', e: 'En el agua', si: (v) => v.tipo === 'terrestre',
        op: [['nadar', '🏊 Nada (más lento)'], ['orilla', '🚫 No entra: se queda en la orilla'], ['fondo', '⚓ Se hunde y camina por el fondo']],
        ayuda: 'Qué hace al llegar a un 💧 agua. "No entra" convierte el agua en un refugio' },
      { k: 'saltaFuera', t: 'bool', e: 'Salta fuera del agua', si: (v) => v.tipo === 'acuatico', ayuda: 'Para morderte en la orilla o en un muelle (tiburón, cocodrilo)' },
      { k: 'alcanceSalto', t: 'num', e: 'Alcance del salto (m)', paso: 0.5, min: 1, si: (v) => v.tipo === 'acuatico' && v.saltaFuera },
      { k: 'alturaVuelo', t: 'num', e: 'Altura de vuelo (m)', paso: 0.25, min: 0.5, si: (v) => v.tipo === 'volador', ayuda: 'Sobre el suelo que tenga debajo (sube y baja con el terreno)' },
      { k: 'flotar', t: 'num', e: 'Sube y baja al flotar', paso: 0.05, min: 0, si: (v) => v.tipo === 'volador', av: true },
      { k: 'radio', t: 'num', e: 'Radio (m)', paso: 0.05, min: 0.1, av: true, ayuda: 'Tamaño para chocar y para recibir balas' },
      { k: 'altura', t: 'num', e: 'Altura (m)', paso: 0.05, min: 0.2, av: true },
      { k: 'escalaVel', t: 'bool', e: 'Al escalarlo cambia su velocidad', av: true, ayuda: 'Escala en el visor (R): más grande = más rápido (y al revés). Tamaño, choque, alcance y vuelo siempre escalan' },
      { k: 'escalaFuerza', t: 'bool', e: 'Al escalarlo cambia su vida y daño', av: true, ayuda: 'Vida × escala², daño × escala' },
      { grupo: 'Percibir' },
      { k: 'vision', t: 'num', e: 'Ve hasta (m)', paso: 1, min: 0, ayuda: 'Cono amarillo en el visor. No ve a través de paredes' },
      { k: 'angulo', t: 'num', e: 'Ángulo de visión (°)', paso: 10, min: 10, ayuda: '360 = ve hacia todos lados' },
      { k: 'oidoCaminar', t: 'num', e: 'Te oye caminar (m)', paso: 0.5, min: 0, ayuda: 'Agachado no se te oye' },
      { k: 'oidoCorrer', t: 'num', e: 'Te oye correr (m)', paso: 0.5, min: 0, ayuda: 'Círculo azul en el visor' },
      { k: 'oidoDisparo', t: 'num', e: 'Oye disparos (m)', paso: 1, min: 0, av: true },
      { k: 'veLinterna', t: 'bool', e: 'Ve tu linterna', ayuda: 'Con la linterna encendida te ve desde más lejos, y si lo alumbras te ve aunque no te mire. Apágala para esconderte' },
      { k: 'ejecutable', t: 'bool', e: 'Se le puede ejecutar', ayuda: 'Acercándote por la espalda sin que te vea sale "Ejecutar" (módulo Sigilo del jugador). Quítalo a los jefes' },
      { k: 'memoria', t: 'num', e: 'Te recuerda (s)', paso: 0.5, min: 0, ayuda: 'Al perderte de vista va a donde te vio por última vez y luego busca' },
      { k: 'reaccion', t: 'num', e: 'Tarda en reaccionar (s)', paso: 0.05, min: 0, av: true },
      { grupo: 'Atacar' },
      { k: 'ataque', t: 'sel', e: 'Ataque', op: [['cuerpo', 'Cuerpo a cuerpo'], ['disparo', 'Disparo (instantáneo)'], ['proyectil', 'Proyectil (bola, flecha)'],
        ['embestida', 'Embestida (terrestre)'], ['salto', 'Salto encima (terrestre)'], ['picado', 'Picado en vuelo (volador)']] },
      { k: 'dano', t: 'num', e: 'Daño', paso: 1, min: 0 },
      { k: 'alcance', t: 'num', e: 'Alcance (m)', paso: 0.25, min: 0.5, ayuda: 'Desde qué distancia empieza el ataque' },
      { k: 'distanciaIdeal', t: 'num', e: 'Distancia que prefiere (m)', paso: 0.5, min: 1, si: lejos, ayuda: 'Se acerca o se aleja para quedar a esta distancia' },
      { k: 'anticipacion', t: 'num', e: 'Aviso antes de atacar (s)', paso: 0.05, min: 0, ayuda: 'Se queda quieto mirándote: tiempo para esquivar' },
      { k: 'enfriamiento', t: 'num', e: 'Espera entre ataques (s)', paso: 0.1, min: 0.1 },
      { k: 'empuje', t: 'num', e: 'Empuje al golpear', paso: 0.5, min: 0, av: true },
      { k: 'dispersion', t: 'num', e: 'Puntería (dispersión °)', paso: 0.5, min: 0, si: (v) => v.ataque === 'disparo' },
      { k: 'velProyectil', t: 'num', e: 'Velocidad del proyectil', paso: 1, min: 1, si: (v) => v.ataque === 'proyectil' },
      { k: 'colorProyectil', t: 'color', e: 'Color del proyectil', si: (v) => v.ataque === 'proyectil' },
      { k: 'tipoDano', t: 'sel', e: 'Tipo de daño de su ataque', op: F.Escena.TIPOS_DANO, av: true },
      { k: 'efecto', t: 'sel', e: 'Efecto de su ataque', op: F.Estados.OPCIONES, av: true, ayuda: 'Quema, envenena, congela o aturde al jugador (y a tus aliados)' },
      { k: 'efectoSeg', t: 'num', e: 'Duración del efecto (s)', paso: 0.5, min: 0, av: true, si: (v) => v.efecto !== 'ninguno', ayuda: '0 = la de serie' },
      { grupo: 'Táctica (élite)' },
      { k: 'escudo', t: 'num', e: 'Escudo', paso: 5, min: 0, ayuda: 'Absorbe el daño antes que la vida (destello azul) y se recarga si dejas de darle. 0 = sin escudo' },
      { k: 'escudoEspera', t: 'num', e: 'Recarga tras (s)', paso: 0.5, min: 0, si: (v) => v.escudo > 0, av: true },
      { k: 'escudoRecarga', t: 'num', e: 'Recarga (por s)', paso: 5, min: 1, si: (v) => v.escudo > 0, av: true },
      { k: 'esquiva', t: 'rango', e: 'Esquiva', min: 0, max: 1, paso: 0.05, ayuda: 'Qué tan seguido se aparta de lado cuando le apuntas o le das. 0 = nunca' },
      { k: 'esquivaCada', t: 'num', e: 'Entre esquivas (s)', paso: 0.1, min: 0.3, si: (v) => v.esquiva > 0, av: true },
      { k: 'cubrirse', t: 'bool', e: 'Se cubre', ayuda: 'Al romperse su escudo busca un sitio cerca donde no lo veas y espera a recargarlo. Sin escudo: se cubre un rato al recibir mucho daño' },
      { k: 'lateral', t: 'num', e: 'Se mueve de lado al disparar (m/s)', paso: 0.25, min: 0, si: (v) => v.ataque === 'disparo' || v.ataque === 'proyectil' },
      { grupo: 'Recibir daño' },
      { k: 'aguante', t: 'num', e: 'Aguante', paso: 5, min: 0, av: true, ayuda: 'Daño de un golpe para aturdirlo. 0 = se aturde con todo; 999 = nunca' },
      { k: 'aturdir', t: 'num', e: 'Aturdido (s)', paso: 0.05, min: 0, av: true },
      ...EN.RESISTENCIAS.map((r) => ({ k: 'res_' + r, t: 'rango', e: 'Daño ' + nombresDano[r], min: 0, max: 3, paso: 0.05,
        ayuda: r === 'normal' ? '1 = normal · 2 = le duele el doble · 0.5 = la mitad · 0 = inmune. Según el tipo de munición' : undefined })),
      { k: 'pisable', t: 'bool', e: 'Muere si le caes encima', ayuda: 'Estilo Mario: rebotas al pisarlo' },
      { k: 'danoPisar', t: 'num', e: 'Daño al pisarlo', paso: 5, min: 1, si: (v) => v.pisable, av: true },
      { grupo: 'Al morir' },
      { k: 'suelta', t: 'sel', e: 'Suelta', op: sueltas },
      { k: 'probSoltar', t: 'rango', e: 'Probabilidad', min: 0, max: 1, paso: 0.05, si: (v) => !!v.suelta },
      { k: 'suelta2', t: 'sel', e: 'Y también', op: sueltas, si: (v) => !!v.suelta, ayuda: 'Botín: cada cosa con su probabilidad (una llave al 100 %, munición al 50 %…)' },
      { k: 'probSoltar2', t: 'rango', e: 'Probabilidad', min: 0, max: 1, paso: 0.05, si: (v) => !!v.suelta2 },
      { k: 'cantidad2', t: 'num', e: 'Cuántos', paso: 1, min: 1, si: (v) => /^obj:/.test(v.suelta2 || '') },
      { k: 'suelta3', t: 'sel', e: 'Y también', op: sueltas, si: (v) => !!v.suelta2 },
      { k: 'probSoltar3', t: 'rango', e: 'Probabilidad', min: 0, max: 1, paso: 0.05, si: (v) => !!v.suelta3 },
      { k: 'cantidad3', t: 'num', e: 'Cuántos', paso: 1, min: 1, si: (v) => /^obj:/.test(v.suelta3 || '') },
      { k: 'desaparecer', t: 'num', e: 'Desaparece a los (s)', paso: 0.5, min: 0, ayuda: '0 = el cuerpo se queda' },
      { grupo: 'Aspecto y sonido' },
      { k: 'modelo', t: 'asset', e: 'Modelo', tipoAsset: 'modelo', vacio: '(figura del motor)',
        ayuda: 'Animaciones que usa si las trae: idle, walk, run, attack, hurt, die y fly' },
      { k: 'escalaModelo', t: 'num', e: 'Escala del modelo', paso: 0.05, min: 0.01, si: (v) => !!v.modelo },
      { k: 'color', t: 'color', e: 'Color', si: (v) => !v.modelo },
      { k: 'forma', t: 'sel', e: 'Figura', op: [['humano', '🧍 Persona'], ['animal', '🐕 Animal (cuatro patas)']], si: (v) => !v.modelo && v.tipo === 'terrestre' },
      { k: 'sonidoAlerta', t: 'asset', e: 'Sonido al verte', tipoAsset: 'audio', vacio: '(ninguno)', av: true },
      { k: 'sonidoAtaque', t: 'asset', e: 'Sonido al atacar', tipoAsset: 'audio', vacio: '(ninguno)', av: true },
      { k: 'sonidoDolor', t: 'asset', e: 'Sonido de dolor', tipoAsset: 'audio', vacio: '(ninguno)', av: true },
      { k: 'sonidoMuerte', t: 'asset', e: 'Sonido al morir', tipoAsset: 'audio', vacio: '(golpe del motor)', av: true },
    ];
    return ESQ;
  }

  const VISUAL_ENEMIGO = ['tipo', 'forma', 'modelo', 'escalaModelo', 'color', 'radio', 'altura', 'vision', 'angulo', 'oidoCorrer', 'inactivo', 'radioDeambular', 'alturaVuelo'];

  /* Formulario de la configuración de un enemigo (lo usan el inspector y Juego ▸ Criaturas).
     alCambiar(k, v, definitivo, visual): visual = cambió algo que se ve (hay que rehacer la figura) */
  // deCriatura: el formulario edita una criatura de la biblioteca (la patrulla no va ahí: es de cada enemigo de la escena)
  function formEnemigo(p, c, alCambiar, deCriatura = false) {
    const esquema = deCriatura ? esquemaEnemigo().filter((f) => f.k !== 'patrulla') : esquemaEnemigo();
    formulario(p, esquema, c, (k, v, definitivo) => {
      if (k === 'tipo') {
        if (v === 'volador' && (c.ataque === 'embestida' || c.ataque === 'salto')) c.ataque = 'picado';
        if (v !== 'volador' && c.ataque === 'picado') c.ataque = 'cuerpo';
        if (v === 'acuatico' && (c.ataque === 'embestida' || c.ataque === 'salto')) c.ataque = 'cuerpo';
      }
      alCambiar(k, v, definitivo, VISUAL_ENEMIGO.includes(k) && definitivo);
    }, { defectos: F.Enemigos.BASE, antes: () => Ed.marcarCambio() });
    const am = c.modelo && F.Assets.mapa.get(c.modelo);
    if (am && Ed.Apps && Ed.Apps.datosForja(am)) botonera(p, [['✎ Editar su modelo en Forja de personajes', () => Ed.Apps.editarEnApp(am.id), 'primario']]);
  }

  // cuántos usan una criatura: enemigos vinculados y aparecedores (en todas las escenas)
  function usosCriatura(id) {
    let enemigos = 0, aparecedores = 0;
    for (const s of Ed.proyecto.escenas) for (const e of s.entidades) {
      if (e.tipo === 'enemigo' && e.criatura === id) enemigos++;
      if (e.tipo === 'aparecedor' && e.aparecedor) {
        const a = e.aparecedor;
        if (a.jefe === id || (a.salen || []).some((x) => x.criatura === id) || (a.oleadas || []).some((o) => o.some((x) => x.criatura === id))) aparecedores++;
      }
    }
    return { enemigos, aparecedores };
  }

  // una criatura cambió: sus enemigos vinculados copian la configuración (y se rehacen los de esta escena si se ve distinto)
  function propagarCriatura(id, visual) {
    const cambiados = S.aplicarCriaturas(Ed.proyecto, id);
    if (visual) for (const e of cambiados) if (Ed.objetos.has(e.id) && Ed.escena.entidades.includes(e)) Ed.reconstruirEntidad(e);
  }

  /* Enemigo de la escena: propio, o vinculado a una criatura de la biblioteca (editarlo edita la criatura) */
  function pintarEnemigo(p, ent) {
    const EN = F.Enemigos, P = Ed.proyecto;
    const crs = P.criaturas || (P.criaturas = []);
    const cr = ent.criatura && crs.find((x) => x.id === ent.criatura);
    formulario(p, [{ k: 'criatura', t: 'sel', e: '📚 Criatura', op: [['', '(propia: solo este enemigo)'], ...crs.map((x) => [x.id, x.nombre])],
      ayuda: 'Vinculado a una criatura de Juego ▸ Criaturas: si la cambias, cambian todos los que la usan' }], ent, (k, v) => {
      if (v) {
        const nueva = crs.find((x) => x.id === v);
        S.aplicarCriaturas(P, v);
        if (nueva && (ent.nombre === 'Enemigo' || crs.some((x) => x.nombre === ent.nombre.replace(/ \d+$/, '')))) ent.nombre = nueva.nombre;
        Ed.reconstruirEntidad(ent);
        Ed.pintarArbol();
      }
      Ed.pintarInspector();
      Ed.guardarLocal();
    }, { antes: () => Ed.marcarCambio() });

    if (cr) {
      const u = usosCriatura(cr.id);
      nota(p, `Editas la criatura <b>${cr.nombre}</b>: cambian sus ${u.enemigos} enemigo${u.enemigos === 1 ? '' : 's'} del proyecto` +
        (u.aparecedores ? ` y lo que sacan ${u.aparecedores} aparecedor${u.aparecedores === 1 ? '' : 'es'}` : '') + '.');
      botonera(p, [
        ['📚 Abrir en Criaturas', () => { Ed.criaturaElegida = cr.id; Ed.abrirPanel('panelCriaturas'); Ed.construirPanelCriaturas(); }],
        ['Desvincular', () => { Ed.marcarCambio(); ent.criatura = ''; Ed.pintarInspector(); Ed.guardarLocal(); }, '', 'Se queda con una copia propia que ya no cambia con la criatura'],
      ]);
      // lo que es de ESTE enemigo aunque esté vinculado: su ruta de patrulla
      if (cr.enemigo.tipo !== 'fijo') {
        titulo(p, 'Solo este enemigo');
        formulario(p, [{ k: 'patrulla', t: 'sel', e: 'Patrulla (ruta)', op: [['', '(ninguna)'], ...rutasEscena()],
          ayuda: 'Recorre los 📍 puntos de esa ruta en vez de pasear. Es de este enemigo: los demás de la criatura no la siguen' }],
        ent.enemigo, (k, v, definitivo) => { if (definitivo) Ed.guardarLocal(); }, { antes: () => Ed.marcarCambio() });
        titulo(p, '📚 ' + cr.nombre + ' (todos los vinculados)');
      }
      formEnemigo(p, cr.enemigo, (k, v, definitivo, visual) => {
        propagarCriatura(cr.id, visual);
        if (k === 'tipo') Ed.pintarInspector();
        if (definitivo) Ed.guardarLocal();
      }, true);
    } else {
      const c = ent.enemigo;
      titulo(p, 'Preajustes');
      const presets = document.createElement('div');
      presets.className = 'acciones';
      for (const pr of Object.values(EN.PRESETS)) {
        const b = document.createElement('button');
        b.textContent = pr.nombre;
        b.onclick = () => {
          Ed.marcarCambio();
          const { nombre, ...valores } = pr;
          ent.enemigo = { ...EN.BASE, ...valores, modelo: c.modelo, escalaModelo: c.escalaModelo };
          const nombres = Object.values(EN.PRESETS).map((x) => x.nombre);
          if (ent.nombre === 'Enemigo' || nombres.includes(ent.nombre.replace(/ \d+$/, ''))) ent.nombre = nombre;
          Ed.reconstruirEntidad(ent);
          Ed.pintarArbol();
          Ed.pintarInspector();
          Ed.guardarLocal();
        };
        presets.appendChild(b);
      }
      p.appendChild(presets);
      botonera(p, [['📚 Guardar como criatura', () => {
        Ed.marcarCambio();
        const nueva = S.criaturaNueva({ nombre: ent.nombre, enemigo: F.util.copiar(c) });
        crs.push(nueva);
        ent.criatura = nueva.id;
        Ed.pintarInspector();
        Ed.guardarLocal();
        Ed.toast(`📚 <b>${nueva.nombre}</b> está en Juego ▸ Criaturas: ya la pueden usar los aparecedores`);
      }, '', 'La añade a la biblioteca y deja este enemigo vinculado']]);
      formEnemigo(p, c, (k, v, definitivo, visual) => {
        if (visual) Ed.reconstruirEntidad(ent);
        if (k === 'tipo') Ed.pintarInspector();
        if (definitivo) Ed.guardarLocal();
      });
    }
    const m = P.jugador.modulos, c = cr ? cr.enemigo : ent.enemigo;
    // un acuático fuera del agua se queda varado: avisar si no está bajo ninguna superficie de agua
    if (c.tipo === 'acuatico') {
      const obj = Ed.objetos.get(ent.id), punto = obj && obj.getWorldPosition(new THREE.Vector3()).add(new THREE.Vector3(0, c.radio || 0.2, 0));
      const ents = Ed.escena.entidades;
      const conModelo = ents.some((e) => e.tipo === 'modelo' && Ed.objetos.get(e.id)?.userData.liquidos);
      const dentro = punto && ents.some((e) => e.tipo === 'agua' && Ed.objetos.get(e.id) && F.Agua.dentroDeCaja(Ed.objetos.get(e.id), punto));
      if (!dentro && !conModelo) nota(p, '⚠ <b>No está en el agua</b>: un acuático fuera del agua se queda dando saltitos. Ponlo bajo la superficie de una 💧.');
    }
    if (!m.salud?.activo) nota(p, '⚠ Para que te haga daño activa <b>Salud y muerte</b> en la pestaña Jugador.');
    if (!m.armas?.activo && !c.pisable) nota(p, 'ℹ Para dispararle activa <b>Armas</b> en la pestaña Jugador (o márcalo como "Muere si le caes encima").');
  }

  // nombres de las rutas de 📍 puntos de la escena actual
  function rutasEscena() {
    const r = new Set();
    for (const e of Ed.escena.entidades) if (e.tipo === 'punto' && e.punto && e.punto.ruta) r.add(e.punto.ruta.trim());
    return [...r].sort().map((x) => [x, x]);
  }

  /* Punto de ruta: patrullas y sitios donde sacan enemigos los aparecedores */
  /* 📷 Cámara fija (estilo RE): se encuadra girando la entidad; su zona es un disparador */
  function pintarCamara(p, ent) {
    const c = ent.camara;
    const rehacer = new Set(['fov', 'activacion', 'zAncho', 'zAlto', 'zLargo', 'zDelante', 'zAbajo']);
    formulario(p, [
      { k: 'modo', t: 'sel', e: 'Cómo encuadra', op: [['fija', '🎬 Fija (el plano no se mueve, RE clásico)'], ['sigue', '👁 Te sigue con la mirada (sin moverse de sitio)']] },
      { k: 'fov', t: 'num', e: 'Campo de visión (°)', paso: 1, min: 10, max: 120 },
      { k: 'activacion', t: 'sel', e: 'Se activa', op: [['zona', '🟧 Con su zona (la caja naranja)'], ['disparador', '⬚ Con un disparador (acción "📷 Cambiar a cámara")'], ['cine', '🎬 Solo para cinemáticas']],
        ayuda: 'Zona: al entrar en su caja manda esta cámara. Disparador: la enciende la acción de un disparador, palanca o condición (y esos disparadores pueden hacer más cosas)' },
      { k: 'zAncho', t: 'num', e: 'Zona: ancho (m)', paso: 0.5, min: 0.5, si: (v) => v.activacion === 'zona' },
      { k: 'zAlto', t: 'num', e: 'Zona: alto (m)', paso: 0.5, min: 0.5, si: (v) => v.activacion === 'zona' },
      { k: 'zLargo', t: 'num', e: 'Zona: largo (m)', paso: 0.5, min: 0.5, si: (v) => v.activacion === 'zona' },
      { k: 'zDelante', t: 'num', e: 'Zona: delante de la cámara (m)', paso: 0.5, si: (v) => v.activacion === 'zona' },
      { k: 'zAbajo', t: 'num', e: 'Zona: por debajo de la cámara (m)', paso: 0.25, si: (v) => v.activacion === 'zona' },
      { k: 'suave', t: 'num', e: 'Suavidad al seguir (s)', paso: 0.02, min: 0, si: (v) => v.modo === 'sigue' },
      { k: 'inicial', t: 'bool', e: 'Cámara del principio', ayuda: 'La que manda al empezar el nivel (si no hay ninguna marcada: la de la zona donde empiezas, o la más cercana que te ve)' },
    ], c, (k, v, definitivo) => { if (definitivo) { if (rehacer.has(k)) Ed.reconstruirEscena(); Ed.pintarInspector(); Ed.guardarLocal(); } }, { defectos: F.Camaras.CAMARA, antes: () => Ed.marcarCambio() });
    if (c.zona) nota(p, 'ℹ Esta cámara usa como zona un disparador (versión anterior). Sigue funcionando; para cambiarlo, elige otra forma en "Se activa".');
    if (c.activacion === 'disparador' && !c.zona) {
      const usan = Ed.escena.entidades.filter((e) => ['disparador', 'palanca', 'condicion', 'pedestal'].some((t) => e[t] && (e[t].acciones || []).some((a) => a.que === 'camara' && a.a === ent.id)));
      nota(p, usan.length ? `La activa${usan.length > 1 ? 'n' : ''}: <b>${usan.map((e) => e.nombre).join(', ')}</b>.` : '⚠ Ningún disparador la activa todavía: añade a uno la acción "📷 Cambiar a cámara fija" y elígela.');
    }
    const modo = ((Ed.proyecto.jugador.modulos || {}).camara || {}).modo;
    if (c.activacion === 'cine') nota(p, '🎬 Cámara de cinemáticas: la usan los pasos "🎥 Cámara a un punto". Mira hacia la flecha del dibujo; muévela y gírala para encuadrar (o usa "📷 Cámara aquí" en el taller).');
    else nota(p, modo === 'fija' ? 'Mira hacia la flecha del dibujo: gírala para encuadrar. Solo se ve en el editor.' : '⚠ Para usarla: Jugador ▸ Cámara ▸ Modo <b>Cámaras fijas</b>.');
  }

  function pintarPunto(p, ent) {
    const pt = ent.punto;
    formulario(p, [
      { k: 'ruta', t: 'texto', e: 'Ruta', ayuda: 'Los puntos con el mismo nombre forman un camino. Elígelo en "Patrulla" de un enemigo o en "En los puntos" de un aparecedor' },
      { k: 'orden', t: 'num', e: 'Orden', paso: 1, ayuda: 'Se recorren de menor a mayor y vuelve al primero' },
      { k: 'espera', t: 'num', e: 'Espera aquí (s)', paso: 0.5, min: 0 },
    ], pt, (k, v, definitivo) => { if (definitivo) { Ed.pintarArbol(); Ed.guardarLocal(); } }, { defectos: F.Enemigos.PUNTO, antes: () => Ed.marcarCambio() });
    const mismos = Ed.escena.entidades.filter((e) => e.tipo === 'punto' && e.punto && e.punto.ruta === pt.ruta).length;
    nota(p, `Esta ruta tiene <b>${mismos}</b> punto${mismos === 1 ? '' : 's'}. Solo se ven en el editor.`);
    botonera(p, [['＋ Siguiente punto de esta ruta', () => {
      const mundo = Ed.objetos.get(ent.id).getWorldPosition(new THREE.Vector3()).add(new THREE.Vector3(3, 0, 0));
      const orden = Math.max(...Ed.escena.entidades.filter((e) => e.tipo === 'punto' && e.punto && e.punto.ruta === pt.ruta).map((e) => e.punto.orden)) + 1;
      Ed.agregarEntidad('punto', { punto: { ...pt, orden } }, mundo);
      Ed.pintarInspector();
    }, 'primario']]);
  }

  /* Agua: volumen (caja) con superficie animada. Se nada dentro (módulo Nadar) y los acuáticos viven aquí */
  function pintarAgua(p, ent) {
    formulario(p, F.Agua.ESQUEMA_AGUA, ent.agua, (k, v, definitivo) => {
      if (k === 'liquido') {
        // elegir líquido pone sus valores de serie (color, vista, daño, si se nada…)
        const { nombre, ...valores } = F.Agua.LIQUIDOS[v] || {};
        Object.assign(ent.agua, valores);
        Ed.reconstruirEntidad(ent);
        Ed.pintarInspector();
        Ed.guardarLocal();
        return;
      }
      if (['color', 'opacidad', 'textura', 'mosaico', 'corriente', 'superficie', 'nube', 'nubeOpacidad', 'nubeTramado'].includes(k) && definitivo) Ed.reconstruirEntidad(ent);
      if (definitivo) Ed.guardarLocal();
    }, { defectos: F.Agua.AGUA, antes: () => Ed.marcarCambio() });
    nota(p, 'La caja es el agua: su cara de arriba es la superficie. Agrándala con <b>Escalar (R)</b>; ponla hundida en el suelo para un lago o una piscina.');
    if (!Ed.proyecto.jugador.modulos.nadar?.activo) nota(p, 'ℹ Para nadar activa el módulo <b>Nadar</b> en la pestaña Jugador (si no, el jugador camina por el fondo).');
  }

  /* Marcador: punto del mapa que sale en la brújula del HUD */
  function pintarMarcador(p, ent) {
    formulario(p, [
      { k: 'icono', t: 'texto', e: 'Icono', ayuda: 'Un carácter o emoji: ◆ ★ ⚑ ✚ 🏠 🚪 💀' },
      { k: 'color', t: 'color', e: 'Color' },
      { k: 'texto', t: 'texto', e: 'Texto', ayuda: 'Sale debajo del icono (vacío = solo la distancia)' },
      { k: 'alEmpezar', t: 'bool', e: 'Visible al empezar', ayuda: 'Desmarcado: lo encenderá una puerta, misión o disparador (próximamente)' },
      { k: 'radioLlegar', t: 'num', e: 'Desaparece al llegar (m)', paso: 0.5, min: 0, ayuda: '0 = siempre se ve. Con más, al acercarte a esa distancia se quita' },
    ], ent.marcador, (k, v, definitivo) => {
      if ((k === 'color' || k === 'radioLlegar') && definitivo) Ed.reconstruirEntidad(ent);
      if (definitivo) Ed.guardarLocal();
    }, { defectos: F.Brujula.MARCADOR, antes: () => Ed.marcarCambio() });
    const h = Ed.proyecto.hud || {};
    if (!h.brujula || h.brujula === 'no') nota(p, 'ℹ La brújula está apagada: enciéndela en <b>Juego ▸ HUD ▸ Brújula</b>.');
  }

  /* =========================================================
     NIVELES: ⚑ inicios (llegadas) y 🚪 salidas a otras escenas
     ========================================================= */
  const nombreEscena = (id) => (Ed.proyecto.escenas.find((e) => e.id === id) || {}).nombre || '(ya no existe)';

  // Salidas de todo el proyecto que llevan a este ⚑ (las que no eligen llegada van al principal)
  function salidasQueLlegan(escena, ini) {
    const r = [];
    const principal = F.Niveles.inicioDe(escena, '');
    for (const esc of Ed.proyecto.escenas) {
      for (const e of esc.entidades) {
        if (e.tipo !== 'salida' || !e.salida || e.salida.destino !== escena.id) continue;
        const llega = F.Niveles.inicioDe(escena, e.salida.llegada);
        if (llega === ini || (!llega && ini === principal)) r.push({ escena: esc, ent: e });
      }
    }
    return r;
  }

  function enlaces(p, texto, lista) {
    if (!lista.length) return;
    const d = nota(p, texto + ' ');
    lista.forEach(({ escena, ent }, i) => {
      const a = document.createElement('a');
      a.href = '#';
      a.textContent = `${F.Escena.ICONO[ent.tipo] || ''} ${ent.nombre} (${escena.nombre})`;
      a.onclick = (ev) => { ev.preventDefault(); Ed.irAEntidad(escena.id, ent.id); };
      if (i) d.appendChild(document.createTextNode(' · '));
      d.appendChild(a);
    });
  }

  /* ⚑ Inicio: el principal es donde empieza el juego; los demás, puntos de llegada desde otros niveles */
  function pintarInicio(p, ent) {
    if (!ent.inicio) ent.inicio = { principal: true };
    formulario(p, [
      { k: 'principal', t: 'bool', e: 'Inicio principal', ayuda: 'Donde empieza el jugador al entrar a este nivel sin elegir llegada (Nueva partida, ▶ Jugar). Solo uno por escena' },
    ], ent.inicio, (k, v) => {
      if (v) for (const e of Ed.escena.entidades) if (e.tipo === 'inicio' && e !== ent && e.inicio) e.inicio.principal = false;
      for (const e of Ed.escena.entidades) if (e.tipo === 'inicio') Ed.reconstruirEntidad(e);
      Ed.pintarArbol();
      Ed.pintarInspector();
      Ed.guardarLocal();
    }, { antes: () => Ed.marcarCambio() });
    const llegan = salidasQueLlegan(Ed.escena, ent);
    if (llegan.length) enlaces(p, 'Aquí llegan:', llegan);
    else if (!ent.inicio.principal) nota(p, 'Ninguna 🚪 salida llega aquí todavía. Elige este punto en "Llegada" de una salida de otro nivel.');
    nota(p, 'La flecha verde es hacia dónde mira el jugador al aparecer.');
  }

  /* 🚪 Salida: lleva a otra escena (o a otro punto de esta) */
  function pintarSalida(p, ent) {
    const sa = ent.salida;
    const escenas = Ed.proyecto.escenas;
    const destino = escenas.find((e) => e.id === sa.destino);
    const guardar = (repintar, reconstruir) => {
      if (reconstruir) Ed.reconstruirEntidad(ent);
      if (repintar) Ed.pintarInspector();
      Ed.guardarLocal();
    };
    titulo(p, '🚪 A dónde lleva');
    const opEsc = [['', '(elige un nivel)'], ...escenas.map((e) => [e.id, e.id === Ed.escena.id ? `${e.nombre} (esta misma: teletransporte)` : e.nombre]), ['__fin__', '🏆 Fin del juego (puntuación y victoria)']];
    const selEsc = controlEsquema({ t: 'sel', op: opEsc }, sa.destino, (v) => {
      Ed.marcarCambio();
      sa.destino = v;
      sa.llegada = '';
      if (/^(Salida a otro nivel|Salida|Ir a .*)( \d+)?$/.test(ent.nombre) && v) ent.nombre = 'Ir a ' + nombreEscena(v);
      Ed.pintarArbol();
      guardar(true);
    });
    p.appendChild(fila('Nivel', selEsc, 'La escena a la que te lleva. Se crean con ＋ junto a la lista de escenas'));
    if (destino) {
      const ins = F.Niveles.inicios(destino);
      const principal = F.Niveles.inicioDe(destino, '');
      const opLl = [['', `⚑ Principal${principal ? ' (' + principal.nombre + ')' : ''}`],
        ...ins.filter((e) => e !== principal).map((e) => [e.id, '⚑ ' + e.nombre])];
      const selLl = controlEsquema({ t: 'sel', op: opLl }, sa.llegada, (v) => { Ed.marcarCambio(); sa.llegada = v; guardar(true); });
      p.appendChild(fila('Llegada', selLl, 'En qué ⚑ de ese nivel apareces. Para volver al lado de la puerta, pon un ⚑ ahí y elígelo'));
      if (sa.llegada && !ins.some((e) => e.id === sa.llegada)) nota(p, '⚠ Ese punto de llegada ya no existe: se usará el principal.');
    } else if (sa.destino === '__fin__') {
      nota(p, '🏆 Al cruzarla: la puntuación de la misión (si el nivel la tiene) y luego la pantalla de <b>Juego completado</b> (Juego ▸ Menús).');
    } else if (sa.destino) {
      nota(p, '⚠ El nivel al que llevaba ya no existe. Elige otro.');
    } else {
      nota(p, '⚠ <b>Todavía no lleva a ningún nivel</b>: elígelo arriba en <b>Nivel</b> (si solo tienes uno, crea otro con <b>＋</b> en el panel Escena). Agranda la caja con <b>Escalar (R)</b> para que tape la puerta o el pasillo.');
    }
    // las animaciones que se pueden elegir son las del GLB del modelo
    const am = sa.modelo && F.Assets.mapa.get(sa.modelo);
    const clips = ((am && am.gltf && am.gltf.animations) || []).map((c) => [c.name, c.name]);
    const esq = F.Niveles.ESQUEMA_SALIDA.map((d) => ((d.k === 'animReposo' || d.k === 'animUsar')
      ? { ...d, op: [['', clips.length ? '(ninguna)' : '(el modelo no trae animaciones)'], ...clips] } : d));
    const VISUAL = ['modelo', 'modeloEscala', 'modeloX', 'modeloY', 'modeloZ', 'modeloGiro', 'colorMarco', 'colorPuerta', 'colorPortal'];
    formulario(p, esq, sa, (k, v, definitivo) => {
      if (k === 'modelo') { sa.animReposo = ''; sa.animUsar = ''; guardar(true, true); }
      else if (k === 'activar' || k === 'figura' || k === 'choca') guardar(true, true);
      else if (VISUAL.includes(k)) { Ed.reconstruirEntidad(ent); if (definitivo) guardar(false); }
      else if (definitivo) guardar(false);
    }, { defectos: F.Niveles.SALIDA, antes: () => Ed.marcarCambio() });
    if (am && am.gltf && F.Niveles.chocaDe(sa) && am.gltf.scene.getObjectByProperty('isSkinnedMesh', true)) {
      nota(p, 'ℹ Este modelo tiene huesos (skinned): esas partes no chocan. Pon un ⬛ cubo invisible si necesitas que tape el paso.');
    }

    const botones = [];
    if (destino && destino.id !== Ed.escena.id) {
      botones.push(['↔ Crear la vuelta', () => crearVuelta(ent), 'primario',
        `Pone en "${destino.nombre}" un ⚑ de llegada y una 🚪 que vuelve aquí, y aquí un ⚑ delante de esta salida. Luego acomódalos`]);
    }
    if (destino) {
      const ll = F.Niveles.inicioDe(destino, sa.llegada);
      if (ll) botones.push(['⚑ Ver la llegada', () => Ed.irAEntidad(destino.id, ll.id), '', 'Abre el otro nivel con el punto de llegada seleccionado']);
    }
    if (botones.length) botonera(p, botones);
    if (sa.activar === 'usar' && !Ed.proyecto.jugador.modulos.interactuar?.activo) {
      nota(p, '⚠ Para usarla con el botón activa el módulo <b>Interactuar</b> en la pestaña Jugador.');
    }
    if (sa.activar === 'usar') nota(p, 'La caja tiene que sobresalir un poco de la puerta: si queda detrás de la pared, no se puede usar.');
    // cosas que hacen que la salida NO funcione
    if (sa.activar === 'tocar' && F.Niveles.chocaDe(sa)) {
      nota(p, '⚠ <b>No podrás entrar</b>: se activa al entrar en la caja pero la puerta es sólida y tapa el paso. Pon "¿Se puede atravesar?" en Sí o cambia a "Con el botón de usar".');
    }
    if (destino && destino.id !== Ed.escena.id && !F.Niveles.inicios(destino).length) {
      nota(p, `⚠ "${destino.nombre}" no tiene ningún ⚑ inicio: llegarías al centro del mapa. Pon uno o pulsa "↔ Crear la vuelta".`);
    }
    const obj = Ed.objetos.get(ent.id);
    if (obj && sa.activar === 'tocar') {
      // un ⚑ dentro de la caja: al llegar ahí la salida no se dispara hasta que sales (y parece que "no funciona")
      obj.updateWorldMatrix(true, false);
      const inv = obj.matrixWorld.clone().invert();
      const dentro = Ed.escena.entidades.filter((e) => e.tipo === 'inicio').find((e) => {
        const o = Ed.objetos.get(e.id);
        if (!o) return false;
        const q = o.getWorldPosition(new THREE.Vector3()).applyMatrix4(inv);
        return Math.abs(q.x) <= 0.5 && Math.abs(q.z) <= 0.5 && q.y >= -0.25 && q.y <= 1;
      });
      if (dentro) nota(p, `⚠ El ⚑ "${dentro.nombre}" está dentro de esta caja: quien aparece ahí tiene que salir y volver a entrar para usarla. Muévelo delante.`);
    }
    nota(p, 'La caja solo se ve en el editor. Al jugar, entrar en ella (o usarla) te lleva al otro nivel con lo que llevas: vida, armas y munición.');
  }

  /* 🔒 Puerta: se abre con el botón, sola al acercarte o con un mecanismo; llave opcional (motor/mecanismos.js) */
  function pintarPuerta(p, ent) {
    const pu = ent.puerta, P = Ed.proyecto, M = F.Mecanismos;
    const llaves = (P.objetos || []).filter((o) => o.tipo === 'llave' || o.tipo === 'clave');
    const am = pu.modelo && F.Assets.mapa.get(pu.modelo);
    const clips = ((am && am.gltf && am.gltf.animations) || []).map((c) => [c.name, c.name]);
    const esq = M.ESQUEMA_PUERTA.map((d) => {
      if (d.k === 'llave') {
        const op = [['', '(nada: no tiene llave)'], ...llaves.map((o) => [o.id, `${o.icono || '🗝'} ${o.nombre}`])];
        if (pu.llave && !llaves.some((o) => o.id === pu.llave)) op.push([pu.llave, '⚠ (ya no existe)']);
        return { ...d, op };
      }
      if (d.k === 'canal') return { ...d, op: opCanales(pu.canal) };
      if (d.k === 'animAbrir') return { ...d, op: [['', clips.length ? '(la mueve el motor)' : '(el modelo no trae animaciones)'], ...clips] };
      if (d.k === 'animCerrar') return { ...d, op: [['', '(la de abrir al revés)'], ...clips] };
      return d;
    });
    const VISUAL = ['estilo', 'lado', 'marco', 'colorMarco', 'colorHoja', 'colorEnergia', 'opacidadEnergia', 'modelo', 'modeloEscala', 'modeloX', 'modeloY', 'modeloZ', 'modeloGiro'];
    titulo(p, '🔒 Puerta');
    formulario(p, esq, pu, (k, v, definitivo) => {
      // la sci-fi que se abre al acercarte se suele cerrar al irte
      if (k === 'abrir' && v === 'cerca' && !pu.cerrarTras) pu.cerrarTras = 1;
      // vuelve a "con el botón": el cierre automático que se puso solo para 'cerca' se quita
      if (k === 'abrir' && v !== 'cerca' && pu.cerrarTras === 1) pu.cerrarTras = 0;
      if (k === 'canal') { pu.canal = canalElegido(v, ''); Ed.pintarInspector(); Ed.guardarLocal(); return; }
      if (k === 'modelo') { pu.animAbrir = ''; pu.animCerrar = ''; if (v) pu.marco = false; }
      if (VISUAL.includes(k)) Ed.reconstruirEntidad(ent);
      if (['abrir', 'estilo', 'llave', 'modelo', 'animAbrir', 'cerrarTras', 'marco'].includes(k)) { Ed.pintarInspector(); Ed.guardarLocal(); return; }
      if (definitivo) Ed.guardarLocal();
    }, { defectos: M.PUERTA, antes: () => Ed.marcarCambio() });
    // lo que hace que la puerta NO funcione
    const mods = P.jugador.modulos;
    if (pu.abrir === 'usar' && !mods.interactuar?.activo) nota(p, '⚠ Para abrirla con el botón activa el módulo <b>Interactuar</b> (pestaña Jugador).');
    if (pu.llave && !mods.inventario?.activo) nota(p, '⚠ Pide llave pero el módulo <b>Inventario</b> está apagado: nadie podrá llevar la llave.');
    if (pu.llave && !llaves.some((o) => o.id === pu.llave)) nota(p, '⚠ La llave que pedía ya no existe en Juego ▸ Objetos. Elige otra.');
    if (pu.llave && llaves.some((o) => o.id === pu.llave) && !P.escenas.some((s) => s.entidades.some((e) => e.tipo === 'recogible' && e.recogible && e.recogible.tipo === 'objeto' && e.recogible.objeto === pu.llave))) {
      nota(p, '⚠ Ningún ✚ recogible de ningún nivel da esa llave: la puerta no se podrá abrir. Pon uno (Juego ▸ Objetos ▸ ✚ Poner en la escena).');
    }
    if (!llaves.length) nota(p, 'Para una puerta con llave crea primero el objeto en <b>Juego ▸ Objetos</b> (tipo 🗝 Llave).');
    if (pu.abrir === 'mecanismo') {
      const quien = quienApunta(ent.id, pu.canal);
      nota(p, quien.length ? `🕹 La abre: ${quien.map((x) => '<b>' + x + '</b>').join(', ')}.`
        : '⚠ Se abre "solo con palanca" pero <b>ninguna palanca la abre</b> todavía: pon una 🕹 y en su lista <b>Qué hace</b> elige "Abrir puerta" → esta.');
    }
    if (pu.estilo === 'negro') nota(p, '⬛ Al usarla la pantalla funde a negro y apareces al otro lado, mirando hacia delante. Deja sitio libre a los dos lados.');
    nota(p, 'Agranda el hueco con <b>Escalar (R)</b>: la puerta se ajusta sin estirarse. La flecha del suelo es el frente.');
  }

  /* 📡 canales: los nombres que ya usa el proyecto (en "Avisar a un canal" y en lo que escucha) */
  function canalesProyecto() {
    const c = new Set();
    for (const s of Ed.proyecto.escenas) for (const e of s.entidades) {
      if (e.palanca) { if (e.palanca.canal) c.add(e.palanca.canal); for (const a of e.palanca.acciones || []) if (a.que === 'canal' && a.canal) c.add(a.canal); }
      if (e.puerta && e.puerta.canal) c.add(e.puerta.canal);
      if (e.disparador && e.disparador.canal) c.add(e.disparador.canal);
      for (const d of [e.disparador, e.pedestal, e.condicion]) if (d) for (const a of d.acciones || []) if (a.que === 'canal' && a.canal) c.add(a.canal);
    }
    return [...c].sort();
  }
  function opCanales(actual) {
    const lista = canalesProyecto();
    if (actual && !lista.includes(actual)) lista.push(actual);
    return [['', '(ninguno)'], ...lista.map((x) => [x, '📡 ' + x]), ['__nuevo', '＋ Canal nuevo…']];
  }
  // pide el nombre de un canal nuevo (si eligieron "＋ Canal nuevo…")
  function canalElegido(v, anterior) {
    if (v !== '__nuevo') return v;
    const n = prompt('Nombre del canal (ej. "alarma", "sala 2"):', '');
    return n && n.trim() ? n.trim().toLowerCase() : anterior || '';
  }
  // quién abre / enciende esta entidad (palancas con una acción que la apunta, o que avisan a su canal)
  function quienApunta(id, canal) {
    const r = [];
    for (const e of Ed.escena.entidades) {
      const d = e.palanca || e.disparador || e.pedestal || e.condicion;
      if (!d) continue;
      const acc = d.acciones || [];
      if (acc.some((a) => a.a === id) || (canal && acc.some((a) => a.que === 'canal' && a.canal === canal))) r.push(e.nombre);
    }
    return r;
  }
  Ed.quienApunta = quienApunta;
  Ed.editarAcciones = (...a) => editarAcciones(...a);

  /* "Qué hace": la lista de acciones de una palanca o un disparador (dueno.acciones) */
  function editarAcciones(p, ent, dueno, texto, alRepintar = null) {
    const M = F.Mecanismos;
    titulo(p, 'Qué hace');
    nota(p, texto);
    const caja = document.createElement('div');
    caja.className = 'lista-acciones';
    const guardar = (repintar) => { Ed.guardarLocal(); if (repintar) (alRepintar || Ed.pintarInspector)(); };
    dueno.acciones = dueno.acciones || [];
    dueno.acciones.forEach((a, i) => {
      const def = M.ACCION[a.que] || M.ACCIONES[0];
      const tarjeta = document.createElement('div');
      tarjeta.className = 'accion';
      const cab = document.createElement('div');
      cab.className = 'accion-cab';
      const selQue = controlEsquema({ t: 'sel', op: M.ACCIONES.map((x) => [x.que, x.e]) }, a.que, (v) => {
        Ed.marcarCambio();
        const antes = M.ACCION[a.que];
        a.que = v;
        if (!antes || antes.obj !== M.ACCION[v].obj) a.a = '';
        guardar(true);
      });
      const quitar = document.createElement('button');
      quitar.textContent = '✕';
      quitar.title = 'Quitar esta acción';
      quitar.onclick = () => { Ed.marcarCambio(); dueno.acciones.splice(i, 1); guardar(true); };
      const subir = document.createElement('button');
      subir.textContent = '↑';
      subir.title = 'Antes';
      subir.disabled = i === 0;
      subir.onclick = () => { Ed.marcarCambio(); dueno.acciones.splice(i - 1, 0, dueno.acciones.splice(i, 1)[0]); guardar(true); };
      cab.append(selQue, subir, quitar);
      tarjeta.appendChild(cab);
      // a qué cosa (selector con las de este nivel)
      if (def.obj) {
        const lista = Ed.escena.entidades.filter((e) => e.tipo === def.obj && e.id !== ent.id);
        const op = [['', lista.length ? '(elige cuál)' : `(no hay ninguna en este nivel)`], ...lista.map((e) => [e.id, e.nombre])];
        if (a.a && !lista.some((e) => e.id === a.a)) op.push([a.a, '⚠ (ya no existe)']);
        tarjeta.appendChild(fila('Cuál', controlEsquema({ t: 'sel', op }, a.a, (v) => { Ed.marcarCambio(); a.a = v; guardar(true); })));
        if (!a.a) nota(tarjeta, '⚠ Elige a cuál afecta.');
        const objetivo = lista.find((e) => e.id === a.a);
        if (objetivo && def.obj === 'aparecedor' && objetivo.aparecedor && objetivo.aparecedor.modo === 'oleadas' && objetivo.aparecedor.empezar !== 'mecanismo' && a.que === 'apaOn') {
          nota(tarjeta, 'ℹ Ese aparecedor también empieza solo (al entrar / al empezar). Si solo quieres que lo empiece esta palanca, pon su "Empiezan" en "Con una palanca".');
        }
        if (objetivo && def.obj === 'luz' && !Ed.proyecto.ajustes.lucesExtra) nota(tarjeta, '⚠ Las luces están apagadas en el proyecto (💡 Luces en la barra del visor).');
      }
      if (a.que === 'matar') tarjeta.appendChild(fila('Daño', controlEsquema({ t: 'num', paso: 5, min: 1 }, a.cantidad || 9999, (v) => { Ed.marcarCambio(); a.cantidad = Math.max(1, v); guardar(); }),
        '9999 = muere (caída, lava de mentira). Menos = una trampa que quita vida'));
      if (/^(lluviaOn|lluviaOff|rayo|hora)$/.test(a.que) && !Ed.escena.ambiente.clima) nota(tarjeta, '⚠ Esta escena no tiene 🌦 Clima (Escena ▸ Ambiente ▸ Activar clima): la acción no hará nada.');
      if (a.que === 'hora') tarjeta.appendChild(fila('Hora', controlEsquema({ t: 'rango', min: 0, max: 24, paso: 0.25 }, a.hora ?? 21, (v) => { Ed.marcarCambio(); a.hora = v; guardar(); }), 'Salta a esa hora (la luz cambia con un fundido corto)'));
      if (a.que === 'mensaje') tarjeta.appendChild(fila('Texto', controlEsquema({ t: 'texto' }, a.texto, (v) => { Ed.marcarCambio(); a.texto = v; guardar(); })));
      if (a.que === 'musica' || a.que === 'musicaNivel') {
        // 🎵 cambiar la música: pista (vacío = silencio), volumen, bucle y fundido
        if (a.que === 'musica') {
          tarjeta.appendChild(fila('Música', controlEsquema({ t: 'asset', tipoAsset: 'audio', vacio: '(silencio)' }, a.asset || '', (v) => { Ed.marcarCambio(); a.asset = v; guardar(); })));
          tarjeta.appendChild(fila('Volumen', controlEsquema({ t: 'rango', min: 0, max: 1, paso: 0.05 }, a.volumen ?? 1, (v) => { Ed.marcarCambio(); a.volumen = v; guardar(); })));
          tarjeta.appendChild(fila('Bucle vuelve a (s)', controlEsquema({ t: 'num', paso: 0.1, min: 0 }, a.inicio || 0, (v) => { Ed.marcarCambio(); a.inicio = Math.max(0, v); guardar(); }), 'La primera vez suena desde el principio; luego repite desde aquí'));
          tarjeta.appendChild(fila('Bucle termina en (s)', controlEsquema({ t: 'num', paso: 0.1, min: 0 }, a.fin || 0, (v) => { Ed.marcarCambio(); a.fin = Math.max(0, v); guardar(); }), '0 = al final del archivo'));
          if (a.asset && Ed.ondaMusica) Ed.ondaMusica(tarjeta, a.asset, a, { kIni: 'inicio', kFin: 'fin', volumen: () => a.volumen ?? 1,
            alCambiar: (fin) => { if (fin) { Ed.marcarCambio(); guardar(); } }, alSoltar: () => guardar(true) });
        }
        tarjeta.appendChild(fila('Fundido (s)', controlEsquema({ t: 'num', paso: 0.25, min: 0 }, a.fundido ?? 1, (v) => { Ed.marcarCambio(); a.fundido = Math.max(0, v); guardar(); }), 'Se cruza con la que sonaba. 0 = de golpe'));
      }
      if (a.que === 'explosion') {
        const op = [['', '(aquí mismo: en esta palanca / disparador)'], ['__jugador', '🧍 En el jugador'],
          ...Ed.escena.entidades.filter((e) => e.id !== ent.id).map((e) => [e.id, (F.Escena.ICONO[e.tipo] || '') + ' ' + e.nombre])];
        if (a.donde && !Ed.escena.entidades.some((e) => e.id === a.donde) && a.donde !== '__jugador') op.push([a.donde, '⚠ (ya no existe)']);
        tarjeta.appendChild(fila('Dónde', controlEsquema({ t: 'sel', op }, a.donde || '', (v) => { Ed.marcarCambio(); a.donde = v; guardar(); })));
        tarjeta.appendChild(fila('Tamaño', controlEsquema({ t: 'sel', op: F.Explosiones.OP_TAMANOS }, a.tam || 'media', (v) => { Ed.marcarCambio(); a.tam = v; guardar(); })));
        tarjeta.appendChild(fila('Daño', controlEsquema({ t: 'num', paso: 10, min: 0 }, a.dano || 0, (v) => { Ed.marcarCambio(); a.dano = Math.max(0, v); guardar(); }),
          '0 = solo se ve. Con daño hiere a jugador y enemigos y rompe lo rompible cerca (barriles en cadena)'));
        tarjeta.appendChild(fila('Con humo', controlEsquema({ t: 'bool' }, a.humo !== false, (v) => { Ed.marcarCambio(); a.humo = v; guardar(); })));
        if (!a.donde) a._de = ent.id; else delete a._de;
      }
      if (a.que === 'cine') {
        const cs = Ed.escena.cinematicas || [];
        const op = [['', cs.length ? '(elige cuál)' : '(este nivel no tiene cinemáticas)'], ...cs.map((c) => [c.id, '🎬 ' + c.nombre])];
        if (a.cine && !cs.some((c) => c.id === a.cine)) op.push([a.cine, '⚠ (ya no existe)']);
        tarjeta.appendChild(fila('Cinemática', controlEsquema({ t: 'sel', op }, a.cine || '', (v) => { Ed.marcarCambio(); a.cine = v; guardar(true); })));
        if (!a.cine) nota(tarjeta, '⚠ Elige qué cinemática se ve.');
        if (Ed.abrirTallerCine) {
          const b = document.createElement('button'); b.textContent = '🎬 Abrir el taller de cinemáticas';
          b.onclick = () => Ed.abrirTallerCine(a.cine || null);
          tarjeta.appendChild(b);
        }
      }
      if (a.que === 'efectos') {
        const op = [['nivel', 'Los del nivel (solo cambiar barras)'], ['ninguno', 'Sin efectos'],
          ...F.Efectos.ESQUEMA[1].op.filter(([k]) => k !== 'ninguno' && k !== 'propio')];
        tarjeta.appendChild(fila('Estilo', controlEsquema({ t: 'sel', op }, a.estilo || 'nivel', (v) => { Ed.marcarCambio(); a.estilo = v; guardar(); }),
          'Se pone encima de los efectos del nivel hasta que otra acción lo cambie o vuelvas a los del nivel. Al cambiar de nivel se quita'));
        tarjeta.appendChild(fila('Barras de cine', controlEsquema({ t: 'rango', min: 0, max: 0.25, paso: 0.01 }, a.barras || 0, (v) => { Ed.marcarCambio(); a.barras = v; guardar(); }),
          'Entran deslizándose. 0 = sin barras. 0.12 ≈ película'));
        if (/^(entrarSalir)$/.test((ent.disparador || {}).cuando || '') || (ent.palanca && ent.palanca.alApagar === 'invertir')) nota(tarjeta, 'ℹ Al salir / apagar vuelve a los efectos del nivel.');
      }
      if (a.que === 'sonido') tarjeta.appendChild(fila('Sonido', controlEsquema({ t: 'asset', tipoAsset: 'audio', vacio: '(elige uno)' }, a.asset, (v) => { Ed.marcarCambio(); a.asset = v; guardar(); })));
      if (a.que === 'mision') {
        tarjeta.appendChild(fila('Después', controlEsquema({ t: 'sel', op: [['', '🏁 Fin de la partida (menú principal)'], ...Ed.proyecto.escenas.map((e) => [e.id, '🚪 ' + e.nombre])] }, a.destino, (v) => { Ed.marcarCambio(); a.destino = v; guardar(); })));
        if (!(Ed.escena.mision && Ed.escena.mision.activa)) nota(tarjeta, 'ℹ Este nivel no tiene misión (Escena ▸ ⭐ Misión): solo hará lo de "Después".');
      }
      if (a.que === 'nivel') {
        const escenas = Ed.proyecto.escenas;
        tarjeta.appendChild(fila('Nivel', controlEsquema({ t: 'sel', op: [['', '(elige un nivel)'], ...escenas.map((e) => [e.id, e.nombre])] }, a.destino, (v) => { Ed.marcarCambio(); a.destino = v; a.llegada = ''; guardar(true); })));
        const dest = escenas.find((e) => e.id === a.destino);
        if (dest) {
          const ins = F.Niveles.inicios(dest);
          tarjeta.appendChild(fila('Llegada', controlEsquema({ t: 'sel', op: [['', '⚑ Principal'], ...ins.map((e) => [e.id, '⚑ ' + e.nombre])] }, a.llegada, (v) => { Ed.marcarCambio(); a.llegada = v; guardar(); })));
          tarjeta.appendChild(fila('Transición', controlEsquema({ t: 'sel', op: F.Efectos.TRANSICIONES }, a.transicion || 'negro', (v) => { Ed.marcarCambio(); a.transicion = v; guardar(); })));
        } else nota(tarjeta, '⚠ Elige a qué nivel lleva.');
      }
      if (a.que === 'canal') {
        tarjeta.appendChild(fila('Canal', controlEsquema({ t: 'sel', op: opCanales(a.canal) }, a.canal, (v) => { Ed.marcarCambio(); a.canal = canalElegido(v, a.canal); guardar(true); }),
          'Lo escuchan las puertas y palancas que tengan este canal en "Escucha el canal"'));
        const oyen = Ed.escena.entidades.filter((e) => a.canal && e !== ent && ((e.puerta && e.puerta.canal === a.canal) || (e.palanca && e.palanca.canal === a.canal) || (e.disparador && e.disparador.canal === a.canal)));
        nota(tarjeta, a.canal ? (oyen.length ? 'Lo escuchan: ' + oyen.map((e) => '<b>' + e.nombre + '</b>').join(', ') : '⚠ Nadie de este nivel escucha este canal.') : '⚠ Elige o crea un canal.');
      }
      tarjeta.appendChild(fila('Espera antes (s)', controlEsquema({ t: 'num', paso: 0.25, min: 0 }, a.retraso || 0, (v) => { Ed.marcarCambio(); a.retraso = Math.max(0, v); guardar(); }),
        'Segundos desde que usas la palanca hasta que pasa esto (0 = al momento)'));
      caja.appendChild(tarjeta);
    });
    p.appendChild(caja);
    botonera(p, [['＋ Añadir acción', () => {
      Ed.marcarCambio();
      // la primera puerta "de palanca" que nadie abre todavía, si la hay
      const libre = Ed.escena.entidades.find((e) => e.tipo === 'puerta' && e.puerta && e.puerta.abrir === 'mecanismo' && !quienApunta(e.id, e.puerta.canal).length);
      dueno.acciones.push(M.accionNueva({ que: 'abrir', a: libre ? libre.id : '' }));
      guardar(true);
    }, 'primario']]);
    if (!dueno.acciones.length) nota(p, '⚠ Todavía no hace nada: pulsa <b>＋ Añadir acción</b>.');

  }

  /* 📦 Baúl: compartido (Resident Evil) o cofre de premio (se abre una vez y da su contenido) */
  function pintarBaul(p, ent) {
    const b = ent.baul, P = Ed.proyecto;
    formulario(p, [
      { k: 'modo', t: 'sel', e: 'Tipo', op: [['compartido', '📦 Baúl compartido (Resident Evil)'], ['premio', '🎁 Cofre de premio (se abre una vez)']],
        ayuda: 'Compartido: abre la mochila; lo que guardas en uno sale en todos. Premio: al abrirlo te da lo que lleva y queda abierto' },
      { k: 'color', t: 'color', e: 'Color de la madera' },
    ], b, (k, v, definitivo) => {
      if (k === 'modo') { Ed.pintarInspector(); Ed.guardarLocal(); return; }
      if (definitivo) { Ed.reconstruirEntidad(ent); Ed.guardarLocal(); }
    }, { defectos: F.Inventario.BAUL, antes: () => Ed.marcarCambio() });
    if (b.modo !== 'premio') {
      nota(p, '📦 Con el botón de usar abre la mochila junto al baúl. Lo que guardas en uno sale en <b>todos</b> los baúles del juego.');
      if (!P.jugador.modulos.inventario?.activo) nota(p, '⚠ Necesita el módulo <b>Inventario</b> (pestaña Jugador).');
      return;
    }
    titulo(p, 'Lo que lleva');
    b.contenido = b.contenido || [];
    const caja = document.createElement('div');
    caja.className = 'lista-acciones';
    const TIPOS = [['vida', '✚ Vida'], ['armadura', '⛨ Armadura'], ['municion', '▮ Munición'], ['arma', '🔫 Arma'], ['bateria', '🔋 Pilas (linterna)'], ['objeto', '◆ Objeto de la mochila'], ['moneda', '🪙 Monedas']];
    b.contenido.forEach((c, i) => {
      const t = document.createElement('div');
      t.className = 'accion';
      const cab = document.createElement('div');
      cab.className = 'accion-cab';
      const sel = controlEsquema({ t: 'sel', op: TIPOS }, c.tipo, (v) => {
        Ed.marcarCambio(); c.tipo = v;
        if (v === 'municion' && !c.municionTipo) c.municionTipo = (P.municiones || [])[0]?.id || '';
        if (v === 'arma' && !c.arma) c.arma = (P.armas || [])[0]?.id || '';
        if (v === 'objeto' && !c.objeto) { c.objeto = (P.objetos || [])[0]?.id || ''; c.cantidad = 1; }
        Ed.guardarLocal(); Ed.pintarInspector();
      });
      const x = document.createElement('button');
      x.textContent = '✕';
      x.onclick = () => { Ed.marcarCambio(); b.contenido.splice(i, 1); Ed.guardarLocal(); Ed.pintarInspector(); };
      cab.append(sel, x);
      t.appendChild(cab);
      if (c.tipo === 'municion') t.appendChild(fila('Cuál', controlEsquema({ t: 'sel', op: (P.municiones || []).map((m) => [m.id, m.nombre]) }, c.municionTipo, (v) => { Ed.marcarCambio(); c.municionTipo = v; Ed.guardarLocal(); })));
      if (c.tipo === 'arma') t.appendChild(fila('Cuál', controlEsquema({ t: 'sel', op: (P.armas || []).map((m) => [m.id, m.nombre]) }, c.arma, (v) => { Ed.marcarCambio(); c.arma = v; Ed.guardarLocal(); })));
      if (c.tipo === 'objeto') t.appendChild(fila('Cuál', controlEsquema({ t: 'sel', op: (P.objetos || []).map((m) => [m.id, `${m.icono || ''} ${m.nombre}`]) }, c.objeto, (v) => { Ed.marcarCambio(); c.objeto = v; Ed.guardarLocal(); })));
      if (c.tipo !== 'arma') t.appendChild(fila('Cantidad', controlEsquema({ t: 'num', paso: 1, min: 1 }, c.cantidad || 1, (v) => { Ed.marcarCambio(); c.cantidad = Math.max(1, Math.round(v)); Ed.guardarLocal(); })));
      caja.appendChild(t);
    });
    p.appendChild(caja);
    botonera(p, [['＋ Añadir', () => { Ed.marcarCambio(); b.contenido.push({ tipo: 'vida', cantidad: 25 }); Ed.guardarLocal(); Ed.pintarInspector(); }, 'primario']]);
    if (!b.contenido.length) nota(p, '⚠ Está vacío: al abrirlo dirá "Está vacío".');
    if (b.contenido.some((c) => c.tipo === 'objeto') && !P.jugador.modulos.inventario?.activo) nota(p, '⚠ Lleva objetos de la mochila: activa el módulo <b>Inventario</b>.');
    if (!P.jugador.modulos.interactuar?.activo) nota(p, '⚠ Para abrirlo activa el módulo <b>Interactuar</b> (pestaña Jugador).');
  }

  /* ⇅ Plataforma / elevador */
  function pintarPlataforma(p, ent) {
    const M = F.Mecanismos, pl = ent.plataforma;
    titulo(p, '⇅ Plataforma');
    formulario(p, M.ESQUEMA_PLATAFORMA, pl, (k, v, definitivo) => {
      if (['dx', 'dy', 'dz', 'ancho', 'alto', 'largo', 'color'].includes(k)) Ed.reconstruirEntidad(ent);
      if (k === 'modo') { Ed.pintarInspector(); Ed.guardarLocal(); return; }
      if (definitivo) Ed.guardarLocal();
    }, { defectos: M.PLATAFORMA, antes: () => Ed.marcarCambio() });
    nota(p, 'La caja azul es a dónde llega. La entidad marca la cara de arriba de la plataforma: ponla a ras del suelo de donde sales.');
    if (!pl.dx && !pl.dy && !pl.dz) nota(p, '⚠ El recorrido es 0: no se moverá.');
    if (pl.modo === 'mecanismo' && !quienApunta(ent.id, '').length) nota(p, '⚠ Se mueve "solo con palanca" pero ninguna la mueve: en una 🕹 palanca añade "Mover plataforma (ida / vuelta)".');
  }

  /* ⚠ Trampa: trampilla, trituradora o lanzaclavos */
  function pintarTrampa(p, ent) {
    const M = F.Mecanismos, t = ent.trampa;
    titulo(p, '⚠ Trampa');
    formulario(p, M.ESQUEMA_TRAMPA, t, (k, v, definitivo) => {
      if (['forma', 'ancho', 'largo', 'alto', 'grosor', 'recorrido', 'alcance', 'color'].includes(k)) Ed.reconstruirEntidad(ent);
      if (['forma', 'activar', 'disparo'].includes(k)) { Ed.pintarInspector(); Ed.guardarLocal(); return; }
      if (definitivo) Ed.guardarLocal();
    }, { defectos: M.TRAMPA, antes: () => Ed.marcarCambio() });
    const textos = {
      trampilla: 'La entidad es la cara de arriba de la losa (ponla a ras del suelo). Debajo tiene que haber un hueco (foso): la losa es lo único que te sostiene.',
      trituradora: 'La entidad es el centro del bloque arriba. El fantasma azul es hasta dónde baja: que toque el suelo.',
      lanzaclavos: 'La flecha naranja es hacia dónde dispara. Pon la boquilla en la pared, mirando hacia el pasillo.',
    };
    nota(p, textos[t.forma] || '');
    const conMecanismo = (t.forma === 'trampilla' && t.activar === 'mecanismo') || (t.forma === 'lanzaclavos' && t.disparo === 'mecanismo');
    if (conMecanismo && !quienApunta(ent.id, '').length) nota(p, '⚠ Solo funciona con mecanismo, pero ninguno la usa: en una 🕹 palanca o ⬚ disparador añade "Disparar trampa".');
    if (!t.activa && !quienApunta(ent.id, '').length && !t.canal) nota(p, '⚠ Empieza apagada y nada la enciende ("Encender trampa").');
  }

  /* 🏺 Pedestal: hueco para un objeto de la mochila */
  function pintarPedestal(p, ent) {
    const M = F.Mecanismos, pe = ent.pedestal, P = Ed.proyecto;
    const obs = P.objetos || [];
    const esq = M.ESQUEMA_PEDESTAL.map((d) => {
      if (d.k !== 'objeto') return d;
      const op = [['', '(elige el objeto)'], ...obs.map((o) => [o.id, `${o.icono || '◆'} ${o.nombre}${o.tipo === 'clave' ? '' : ' (' + o.tipo + ')'}`])];
      if (pe.objeto && !obs.some((o) => o.id === pe.objeto)) op.push([pe.objeto, '⚠ (ya no existe)']);
      return { ...d, op };
    });
    titulo(p, '🏺 Pedestal');
    formulario(p, esq, pe, (k, v, definitivo) => {
      if (k === 'objeto' || k === 'color') Ed.reconstruirEntidad(ent);
      if (k === 'objeto' || k === 'gastar') { Ed.pintarInspector(); Ed.guardarLocal(); return; }
      if (definitivo) Ed.guardarLocal();
    }, { defectos: M.PEDESTAL, antes: () => Ed.marcarCambio() });
    if (!pe.objeto) nota(p, '⚠ Elige qué objeto encaja. Créalo en <b>Juego ▸ Objetos</b> (tipo 🧩 objeto clave).');
    else if (!P.escenas.some((s) => s.entidades.some((e) => e.tipo === 'recogible' && e.recogible && e.recogible.tipo === 'objeto' && e.recogible.objeto === pe.objeto))) {
      nota(p, '⚠ Ningún ✚ recogible de ningún nivel da ese objeto: no se podrá colocar.');
    }
    if (!P.jugador.modulos.inventario?.activo) nota(p, '⚠ Necesita el módulo <b>Inventario</b> (pestaña Jugador).');
    editarAcciones(p, ent, pe, pe.sePuedeQuitar && pe.gastar
      ? 'Lo que pasa al colocar el objeto; al quitarlo, lo contrario.'
      : 'Lo que pasa al colocar el objeto. Para un puzle de varios pedestales usa una ⚙ Condición.');
  }

  /* ⚙ Condición: hace su lista cuando se cumplen sus requisitos (puzles) */
  function pintarCondicion(p, ent) {
    const M = F.Mecanismos, c = ent.condicion;
    titulo(p, '⚙ Condición');
    formulario(p, [
      { k: 'modo', t: 'sel', e: 'Se cumple con', op: [['todas', 'Todas las de la lista'], ['alguna', 'Cualquiera de la lista']] },
      { k: 'unaVez', t: 'bool', e: 'Una vez cumplida, se queda', ayuda: 'Desmarcado: si deja de cumplirse (apagas una palanca), hace lo contrario' },
      { k: 'activa', t: 'bool', e: 'Encendida al empezar', ayuda: 'Apagada: no se revisa hasta que la encienda una palanca o un disparador ("⚙ Encender condición"). Arenas: la enciende el disparador de entrada' },
    ], c, (k, v, definitivo) => { if (definitivo) Ed.guardarLocal(); }, { defectos: M.CONDICION, antes: () => Ed.marcarCambio() });
    titulo(p, 'Qué tiene que pasar');
    nota(p, 'Las líneas verdes del visor van de cada requisito a la condición.');
    const caja = document.createElement('div');
    caja.className = 'lista-acciones';
    c.requisitos = c.requisitos || [];
    c.requisitos.forEach((r, i) => {
      const def = M.REQUISITO[r.tipo] || M.REQUISITOS[0];
      const t = document.createElement('div');
      t.className = 'accion';
      const cab = document.createElement('div');
      cab.className = 'accion-cab';
      const sel = controlEsquema({ t: 'sel', op: M.REQUISITOS.map((x) => [x.tipo, x.e]) }, r.tipo, (v) => {
        Ed.marcarCambio(); r.tipo = v; r.a = ''; r.estado = 'on'; Ed.guardarLocal(); Ed.pintarInspector();
      });
      const quitar = document.createElement('button');
      quitar.textContent = '✕';
      quitar.onclick = () => { Ed.marcarCambio(); c.requisitos.splice(i, 1); Ed.guardarLocal(); Ed.pintarInspector(); };
      cab.append(sel, quitar);
      t.appendChild(cab);
      if (def.obj) {
        const lista = Ed.escena.entidades.filter((e) => e.tipo === def.obj);
        const op = [['', lista.length ? '(elige cuál)' : '(no hay ninguno en este nivel)'], ...lista.map((e) => [e.id, e.nombre])];
        if (r.a && !lista.some((e) => e.id === r.a)) op.push([r.a, '⚠ (ya no existe)']);
        t.appendChild(fila('Cuál', controlEsquema({ t: 'sel', op }, r.a, (v) => { Ed.marcarCambio(); r.a = v; Ed.guardarLocal(); Ed.pintarInspector(); })));
        if (!r.a) nota(t, '⚠ Elige cuál.');
        const ap = r.tipo === 'arena' && lista.find((e) => e.id === r.a);
        if (ap && ap.aparecedor && (ap.aparecedor.modo !== 'oleadas' || ap.aparecedor.total === 0)) nota(t, '⚠ Ese aparecedor nunca termina (zona, u oleadas infinitas): pon un número de oleadas.');
      }
      if (def.estados) t.appendChild(fila('Tiene que estar', controlEsquema({ t: 'sel', op: def.estados }, r.estado, (v) => { Ed.marcarCambio(); r.estado = v; Ed.guardarLocal(); })));
      caja.appendChild(t);
    });
    p.appendChild(caja);
    botonera(p, [['＋ Añadir requisito', () => { Ed.marcarCambio(); c.requisitos.push(M.requisitoNuevo()); Ed.guardarLocal(); Ed.pintarInspector(); }, 'primario']]);
    if (!c.requisitos.length) nota(p, '⚠ Sin requisitos no se cumple nunca. Ejemplo: 3 palancas encendidas → abrir puerta.');
    editarAcciones(p, ent, c, c.unaVez ? 'Lo que pasa cuando se cumple.' : 'Lo que pasa cuando se cumple; si deja de cumplirse, lo contrario.');
    nota(p, 'La condición no se ve al jugar: ponla donde quieras (cerca del puzle, para encontrarla).');
  }

  /* ⬚ Disparador: zona invisible que hace su lista al entrar (una vez, cada vez, o entrar y salir) */
  function pintarDisparador(p, ent) {
    const M = F.Mecanismos, d = ent.disparador;
    titulo(p, '⬚ Disparador');
    formulario(p, M.ESQUEMA_DISPARADOR, d, (k, v, definitivo) => {
      if (k === 'color' || k === 'placa') Ed.reconstruirEntidad(ent);
      if (k === 'quien') { Ed.pintarInspector(); Ed.guardarLocal(); return; }
      if (k === 'cuando') { Ed.pintarInspector(); Ed.guardarLocal(); return; }
      if (definitivo) Ed.guardarLocal();
    }, { defectos: M.DISPARADOR, antes: () => Ed.marcarCambio() });
    editarAcciones(p, ent, d, d.cuando === 'entrarSalir'
      ? 'Al entrar hace esto; al salir, lo contrario (cierra lo que abrió, apaga lo que encendió…).'
      : 'Lo que pasa al entrar en la zona. Ejemplos: cerrar la puerta tras de ti, empezar una arena, encender un marcador.');
    titulo(p, '📡 Canal');
    formulario(p, [{ k: 'canal', t: 'sel', e: 'Escucha el canal', op: opCanales(d.canal),
      ayuda: 'Un canal encendido lo enciende; apagado, lo apaga (así una palanca puede activar o desactivar la zona)' }], d, (k, v) => {
      d.canal = canalElegido(v, '');
      Ed.guardarLocal();
      Ed.pintarInspector();
    }, { defectos: M.DISPARADOR, antes: () => Ed.marcarCambio() });
    // avisos de cosas que no funcionarán
    const obj = Ed.objetos.get(ent.id);
    if (obj && d.quien !== 'enemigos') {
      obj.updateWorldMatrix(true, false);
      const inv = obj.matrixWorld.clone().invert();
      const ini = Ed.escena.entidades.filter((e) => e.tipo === 'inicio').find((e) => {
        const o = Ed.objetos.get(e.id);
        if (!o) return false;
        const q = o.getWorldPosition(new THREE.Vector3()).applyMatrix4(inv);
        return Math.abs(q.x) <= 0.5 && Math.abs(q.z) <= 0.5 && q.y >= -0.25 && q.y <= 1;
      });
      if (ini) nota(p, `ℹ El ⚑ "${ini.nombre}" está dentro de la zona: salta en cuanto empieza el nivel.`);
    }
    if (!d.activo) nota(p, quienApunta(ent.id, d.canal).length ? '🕹 Empieza apagado; lo encienden: ' + quienApunta(ent.id, d.canal).map((x) => '<b>' + x + '</b>').join(', ') + '.'
      : '⚠ Empieza apagado y <b>nada lo enciende</b>: usa una acción "Encender disparador" o un canal.');
    nota(p, 'La caja solo se ve en el editor. Agrándala con <b>Escalar (R)</b> para que tape el pasillo o la entrada.');
  }

  /* 🕹 Palanca / botón / interruptor: forma, modo y la lista "Qué hace" */
  function pintarPalanca(p, ent) {
    const M = F.Mecanismos, pl = ent.palanca;
    titulo(p, '🕹 Palanca');
    formulario(p, M.ESQUEMA_PALANCA, pl, (k, v, definitivo) => {
      if (['forma', 'color', 'colorBase', 'empiezaEncendida'].includes(k)) Ed.reconstruirEntidad(ent);
      if (k === 'forma' && /^(Palanca|Botón|Interruptor)( \d+)?$/.test(ent.nombre)) { ent.nombre = { palanca: 'Palanca', boton: 'Botón', interruptor: 'Interruptor' }[v]; Ed.pintarArbol(); }
      if (k === 'modo' || k === 'forma') { Ed.pintarInspector(); Ed.guardarLocal(); return; }
      if (definitivo) Ed.guardarLocal();
    }, { defectos: M.PALANCA, antes: () => Ed.marcarCambio() });

    editarAcciones(p, ent, pl, 'Lo que pasa al usarla, en orden. La línea naranja del visor va de la palanca a cada cosa que mueve.');

    titulo(p, '📡 Canal');
    formulario(p, [{ k: 'canal', t: 'sel', e: 'Escucha el canal', op: opCanales(pl.canal),
      ayuda: 'Otra palanca o un disparador que avise a este canal la enciende (o apaga) como si la usaran' }], pl, (k, v) => {
      pl.canal = canalElegido(v, '');
      Ed.guardarLocal();
      Ed.pintarInspector();
    }, { defectos: M.PALANCA, antes: () => Ed.marcarCambio() });
    if (!Ed.proyecto.jugador.modulos.interactuar?.activo) nota(p, '⚠ Para usarla activa el módulo <b>Interactuar</b> (pestaña Jugador).');
  }

  /* ↔ Crear la vuelta: llegada en el otro nivel + salida que regresa + llegada aquí delante de esta salida */
  function crearVuelta(ent) {
    const T = THREE, S = F.Escena;
    const sa = ent.salida;
    const otro = Ed.proyecto.escenas.find((e) => e.id === sa.destino);
    if (!otro) return;
    Ed.marcarCambio();
    // 1) Aquí: un ⚑ delante de esta salida (del lado de la flecha), mirando hacia afuera
    const obj = Ed.objetos.get(ent.id);
    const pos = obj.getWorldPosition(new T.Vector3());
    const giro = new T.Euler().setFromQuaternion(obj.getWorldQuaternion(new T.Quaternion()), 'YXZ').y;
    const fondo = Math.abs(ent.esc[2]) / 2 + 1.5;
    const frente = new T.Vector3(0, 0, -1).applyAxisAngle(new T.Vector3(0, 1, 0), giro);
    const aqui = S.entidadNueva('inicio', {
      nombre: 'Desde ' + otro.nombre, inicio: { principal: false },
      pos: [+(pos.x + frente.x * fondo).toFixed(2), +pos.y.toFixed(2), +(pos.z + frente.z * fondo).toFixed(2)],
      rot: [0, Math.round(giro / F.DEG), 0],
    });
    Ed.escena.entidades.push(aqui);
    Ed.reconstruirEntidad(aqui);
    // 2) En el otro nivel: un ⚑ cerca de su inicio principal y, detrás de él, la salida que vuelve
    let llegada = sa.llegada && otro.entidades.find((e) => e.id === sa.llegada);
    if (!llegada) {
      const pr = F.Niveles.inicioDe(otro, '');
      const base = pr ? pr.pos : [0, 0, 0];
      llegada = S.entidadNueva('inicio', {
        nombre: 'Desde ' + Ed.escena.nombre, inicio: { principal: false },
        pos: [base[0] + 3, base[1], base[2]], rot: [0, pr ? pr.rot[1] : 0, 0],
      });
      otro.entidades.push(llegada);
      sa.llegada = llegada.id;
    }
    const g = llegada.rot[1] * F.DEG;
    const atras = [Math.sin(g) * 3, Math.cos(g) * 3];   // detrás del jugador (mira hacia −Z girado)
    const vuelta = S.entidadNueva('salida', {
      nombre: 'Volver a ' + Ed.escena.nombre,
      pos: [+(llegada.pos[0] + atras[0]).toFixed(2), llegada.pos[1], +(llegada.pos[2] + atras[1]).toFixed(2)],
      rot: [0, llegada.rot[1], 0],   // su flecha mira hacia el jugador que acaba de llegar
      salida: { ...F.Niveles.SALIDA, destino: Ed.escena.id, llegada: aqui.id, activar: sa.activar },
    });
    otro.entidades.push(vuelta);
    Ed.pintarArbol();
    Ed.pintarInspector();
    Ed.guardarLocal();
    Ed.toast(`↔ Listo: en <b>${otro.nombre}</b> hay un ⚑ "${llegada.nombre}" y una 🚪 "${vuelta.nombre}"; aquí un ⚑ "${aqui.nombre}". Acomódalos a tu gusto.`);
  }

  /* Filas "criatura × número" (selector de la biblioteca). alCambiar(repintar) */
  function filasCriaturas(cont, filas, textoN, alCambiar) {
    const crs = Ed.proyecto.criaturas || [];
    const caja = document.createElement('div');
    caja.className = 'filas-criaturas';
    filas.forEach((f, i) => {
      const fila = document.createElement('div');
      fila.className = 'fila-cr';
      const sel = document.createElement('select');
      if (!crs.some((x) => x.id === f.criatura)) sel.add(new Option('⚠ (ya no existe)', f.criatura || ''));
      for (const x of crs) sel.add(new Option(x.nombre, x.id, false, x.id === f.criatura));
      sel.onchange = () => { Ed.marcarCambio(); f.criatura = sel.value; alCambiar(false); };
      const n = document.createElement('input');
      n.type = 'number'; n.min = 1; n.step = 1; n.value = f.n; n.title = textoN;
      n.onchange = () => { Ed.marcarCambio(); f.n = Math.max(1, Math.round(+n.value || 1)); n.value = f.n; alCambiar(false); };
      const x = document.createElement('button');
      x.textContent = '✕'; x.title = 'Quitar';
      x.onclick = () => { Ed.marcarCambio(); filas.splice(i, 1); alCambiar(true); };
      const por = document.createElement('span');
      por.textContent = '×';
      fila.append(sel, por, n, x);
      caja.appendChild(fila);
    });
    const mas = document.createElement('button');
    mas.textContent = '＋ Criatura';
    mas.disabled = !crs.length;
    mas.onclick = () => { Ed.marcarCambio(); filas.push({ criatura: crs[0].id, n: 1 }); alCambiar(true); };
    caja.appendChild(mas);
    cont.appendChild(caja);
  }

  /* Aparecedor: zona que va sacando criaturas (estilo Minecraft) o arena de oleadas (horda) */
  function pintarAparecedor(p, ent) {
    const EN = F.Enemigos, a = ent.aparecedor;
    if (!Array.isArray(a.salen)) a.salen = [];
    if (!Array.isArray(a.oleadas)) a.oleadas = [];
    const zona = (v) => v.modo !== 'oleadas', ole = (v) => v.modo === 'oleadas', auto = (v) => ole(v) && v.forma !== 'lista';
    const guardar = (repintar) => { Ed.guardarLocal(); if (repintar) Ed.pintarInspector(); };
    const opc = { defectos: EN.APARECEDOR, antes: () => Ed.marcarCambio() };
    const alCambiar = (k, v, definitivo) => {
      if ((k === 'modo' || k === 'radio') && definitivo) Ed.reconstruirEntidad(ent);
      if (k === 'modo' || k === 'forma' || k === 'jefe') Ed.pintarInspector();
      if (definitivo) Ed.guardarLocal();
    };
    formulario(p, [
      { grupo: 'Qué hace' },
      { k: 'modo', t: 'sel', e: 'Modo', op: [['zona', '🌿 Zona: siempre hay criaturas (estilo Minecraft)'], ['oleadas', '⚔ Arena de oleadas (horda)']] },
      { k: 'forma', t: 'sel', e: 'Oleadas', si: ole, op: [['auto', 'Crecen solas'], ['lista', 'Lista: tú dices cada oleada']] },
    ], a, alCambiar, opc);

    // qué salen: de la biblioteca de criaturas (Juego ▸ Criaturas)
    if (a.modo === 'oleadas' && a.forma === 'lista') {
      a.oleadas.forEach((ol, i) => {
        const cab = document.createElement('div');
        cab.className = 'cab-oleada';
        cab.innerHTML = `<b>Oleada ${i + 1}</b>`;
        const q = document.createElement('button');
        q.textContent = '✕ Quitar oleada';
        q.onclick = () => { Ed.marcarCambio(); a.oleadas.splice(i, 1); guardar(true); };
        cab.appendChild(q);
        p.appendChild(cab);
        filasCriaturas(p, ol, 'Cuántos salen', guardar);
      });
      botonera(p, [['＋ Oleada', () => {
        Ed.marcarCambio();
        const ultima = a.oleadas[a.oleadas.length - 1];
        a.oleadas.push(ultima ? ultima.map((x) => ({ ...x, n: x.n + 1 })) : [{ criatura: (Ed.proyecto.criaturas[0] || {}).id || '', n: 3 }]);
        guardar(true);
      }, '', 'Copia la anterior con uno más de cada']]);
    } else {
      const t = document.createElement('div');
      t.className = 'nota';
      t.textContent = a.modo === 'oleadas' ? 'Qué salen (el número = proporción: 3 zombis por cada demonio)' : 'Qué salen (el número = cuánto más a menudo)';
      p.appendChild(t);
      filasCriaturas(p, a.salen, a.modo === 'oleadas' ? 'Proporción' : 'Cuánto más a menudo', guardar);
    }
    nota(p, '📚 Las criaturas se crean y configuran en <b>Juego ▸ Criaturas</b>.');

    const opJefe = [['', '(sin jefe)'], ...(Ed.proyecto.criaturas || []).map((x) => [x.id, x.nombre])];
    formulario(p, [
      { grupo: 'Dónde salen' },
      { k: 'radio', t: 'num', e: 'Radio (m)', paso: 1, min: 1, ayuda: 'Círculo en el visor. En oleadas "al entrar", entrar en él las empieza' },
      { k: 'aparicion', t: 'sel', e: 'Aparecen', op: [['fuera', 'Donde no miras (no los ves aparecer)'], ['siempre', 'En cualquier momento']] },
      { k: 'distanciaMin', t: 'num', e: 'Nunca más cerca de ti que (m)', paso: 1, min: 0 },
      { k: 'puntos', t: 'sel', e: 'En los puntos de la ruta', op: [['', '(al azar dentro del radio)'], ...rutasEscena()],
        ayuda: 'Salen en los 📍 puntos de esa ruta: puertas, cuevas, bordes de la arena' },
      { grupo: 'Zona', si: zona },
      { k: 'encendido', t: 'bool', e: 'Encendido al empezar', ayuda: 'Apagado: no saca nada hasta que una 🕹 palanca o un disparador lo encienda' },
      { k: 'maximo', t: 'num', e: 'Cuántos a la vez', paso: 1, min: 1 },
      { k: 'cada', t: 'num', e: 'Sale uno cada (s)', paso: 0.5, min: 0.5 },
      { k: 'alInicio', t: 'bool', e: 'Ya poblada al empezar' },
      { k: 'desaparecerLejos', t: 'num', e: 'Se van si te alejas más de (m)', paso: 5, min: 0, ayuda: 'Solo los que no ves. Al volver hay otros. 0 = nunca' },
      { k: 'activa', t: 'num', e: 'Funciona si estás a menos de (m)', paso: 5, min: 0, av: true, ayuda: 'Desde el borde del círculo' },
      { grupo: 'Oleadas', si: ole },
      { k: 'empezar', t: 'sel', e: 'Empiezan', op: [['entrar', 'Al entrar en el radio'], ['inicio', 'Al empezar el nivel'], ['mecanismo', '🕹 Con una palanca o disparador']] },
      { k: 'inicial', t: 'num', e: 'Enemigos en la 1ª oleada', paso: 1, min: 1, si: auto },
      { k: 'crecer', t: 'num', e: 'Más por cada oleada', paso: 1, min: 0, si: auto },
      { k: 'total', t: 'num', e: 'Número de oleadas', paso: 1, min: 0, si: auto, ayuda: '0 = infinitas (supervivencia)' },
      { k: 'fuerza', t: 'num', e: 'Más fuertes cada oleada (%)', paso: 5, min: 0, ayuda: 'Su vida y su daño suben este % por oleada' },
      { k: 'jefe', t: 'sel', e: 'Jefe', op: opJefe, ayuda: 'Sale el último en algunas oleadas, con su barra de vida arriba' },
      { k: 'jefeCada', t: 'num', e: 'Jefe cada (oleadas)', paso: 1, min: 1, si: (v) => !!v.jefe },
      { k: 'descanso', t: 'num', e: 'Descanso entre oleadas (s)', paso: 1, min: 0 },
      { k: 'vivosMax', t: 'num', e: 'Máximo vivos a la vez', paso: 1, min: 1, av: true },
      { k: 'avisoOleada', t: 'bool', e: 'Carteles y contador en pantalla' },
    ], a, alCambiar, opc);
    const m = Ed.proyecto.jugador.modulos;
    if (!m.salud?.activo) nota(p, '⚠ Para que te hagan daño activa <b>Salud y muerte</b> en la pestaña Jugador.');
  }

  /* Recogible (pickup): qué da, cómo se recoge y cómo se ve */
  function pintarRecogible(p, ent) {
    const R = F.Recogibles;
    const r = ent.recogible;
    const armas = (Ed.proyecto.armas || []).map((a) => [a.id, a.nombre]);
    const tiposM = (Ed.proyecto.municiones || []).map((m) => [m.id, `${m.icono || ''} ${m.nombre}`.trim()]);
    const conArma = (v) => v.tipo === 'arma' || (v.tipo === 'municion' && !v.municionTipo);
    const ESQ = [
      { grupo: 'Qué da' },
      { k: 'tipo', t: 'sel', e: 'Da', op: [['vida', '♥ Vida'], ['armadura', '⛨ Armadura'], ['arma', '🔫 Arma'], ['municion', '▮ Munición'], ['bateria', '🔋 Pilas de la linterna (%)'], ['objeto', '🎒 Objeto (a la mochila)'], ['moneda', '💰 Divisa (monedas, oro, gemas…)'], ['vidaExtra', '❤ Vida extra (1UP)'], ['corazon', '♥ Contenedor de corazón (+1 máx.)'], ['piezaCorazon', '◔ Pedazo de corazón'], ['capacidad', '⬆ Más munición máxima (bolsa, carcaj)'], ['escudo', '🛡 Escudo de fuerza (esfera de energía)'], ['escudoMano', '🛡 Escudo de mano (medieval / antimotines)']] },
      { k: 'escudoManoEstilo', t: 'sel', e: 'Escudo', op: [['medieval', '🛡 Medieval (madera y hierro)'], ['antimotines', '▮ Antimotines (transparente)']], si: (v) => v.tipo === 'escudoMano',
        ayuda: 'Va en la mano libre con armas de una mano; clic derecho cubre. Necesita el módulo Armas. Cantidad = aguante' },
      { k: 'escudoSeg', t: 'num', e: 'Dura (s)', paso: 1, min: 0, si: (v) => v.tipo === 'escudo', ayuda: '0 = hasta que se rompa' },
      { k: 'escudoAguante', t: 'num', e: 'Aguante', paso: 10, min: 0, si: (v) => v.tipo === 'escudo', ayuda: 'Daño que para antes de romperse. 0 = no se rompe (dura lo que diga "Dura")' },
      { k: 'escudoBloquea', t: 'rango', e: 'Para del golpe (%)', min: 10, max: 100, paso: 5, si: (v) => v.tipo === 'escudo' },
      { k: 'escudoEstilo', t: 'sel', e: 'Aspecto', op: [['hex', '⬡ Rejilla de hexágonos'], ['ondas', '〰 Ondas + borde brillante'], ['rayos', '⚡ Rayos eléctricos'], ['anillos', '◎ Anillos que recorren'], ['plasma', '🔥 Plasma que fluye']], si: (v) => v.tipo === 'escudo' },
      { k: 'escudoColor', t: 'color', e: 'Color del escudo', si: (v) => v.tipo === 'escudo' },
      { k: 'divisa', t: 'sel', e: 'Divisa', si: (v) => v.tipo === 'moneda', op: F.Divisas.lista(Ed.proyecto).map((d) => [d.id, `${d.icono || ''} ${d.nombre}`.trim()]),
        ayuda: 'Las divisas se crean en Juego ▸ Objetos ▸ Divisas' },
      { k: 'objeto', t: 'sel', e: 'Objeto', si: (v) => v.tipo === 'objeto',
        op: (Ed.proyecto.objetos || []).length ? Ed.proyecto.objetos.map((o) => [o.id, `${o.icono || ''} ${o.nombre}`.trim()]) : [['', '(no hay objetos: Juego ▸ Objetos)']],
        ayuda: 'De Juego ▸ Objetos. Necesita el módulo Inventario del jugador' },
      { k: 'municionTipo', t: 'sel', e: 'Munición', op: [...tiposM, ['', 'La propia de un arma…']], si: (v) => v.tipo === 'municion' || v.tipo === 'capacidad',
        ayuda: 'Tipos de munición: pestaña Juego ▸ Armas. Se puede juntar aunque aún no tengas el arma' },
      { k: 'arma', t: 'sel', e: 'Arma', op: armas.length ? armas : [['', '(no hay armas: Juego ▸ Armas)']], si: conArma,
        ayuda: 'De la pestaña Armas' },
      { k: 'cantidad', t: 'num', e: 'Cantidad', paso: 5, min: 0, si: (v) => v.tipo !== 'arma' && v.tipo !== 'escudo',
        ayuda: 'Vida, armadura o balas que da' },
      { k: 'cantidad', t: 'num', e: 'Munición si ya la tienes', paso: 1, min: 0, si: (v) => v.tipo === 'arma',
        ayuda: 'Recoger un arma que ya tienes da munición. 0 = la que trae el arma (su ficha)' },
      { k: 'recoger', t: 'sel', e: 'Se recoge', op: [['tocar', 'Al tocarlo (Quake, Mario)'], ['usar', 'Con el botón de usar (Resident Evil)']] },
      { k: 'llenar', t: 'bool', e: 'Además la llena', si: (v) => v.tipo === 'capacidad', ayuda: 'Cantidad = cuánto sube el máximo' },
      { k: 'soloSiFalta', t: 'bool', e: 'Solo si lo necesita', ayuda: 'Con la vida llena (o la munición al máximo) se queda en su sitio' },
      { k: 'reaparece', t: 'num', e: 'Reaparece (s)', paso: 5, min: 0, ayuda: '0 = no vuelve (aventura, survival) · 30 = estilo Quake' },
      { k: 'radio', t: 'num', e: 'Radio para tocar (m)', paso: 0.1, min: 0.1, si: (v) => v.recoger !== 'usar' },
      { grupo: 'Cómo se ve' },
      { k: 'modelo', t: 'asset', e: 'Modelo', tipoAsset: 'modelo', vacio: '(figura del motor)' },
      { k: 'color', t: 'color', e: 'Color', ayuda: 'De la figura y del aura. ↺ = el del tipo' },
      { k: 'girar', t: 'bool', e: 'Girar' },
      { k: 'flotar', t: 'bool', e: 'Flotar' },
      { k: 'brillo', t: 'rango', e: 'Aura', min: 0, max: 2, paso: 0.1, ayuda: '0 = sin aura' },
      { grupo: 'Al recogerlo' },
      { k: 'aviso', t: 'bool', e: 'Aviso en pantalla', ayuda: 'Ej. "+25 Vida", arriba a la izquierda' },
      { k: 'texto', t: 'texto', e: 'Texto propio', ayuda: 'Vacío = automático', si: (v) => v.aviso },
      { k: 'sonido', t: 'asset', e: 'Sonido', tipoAsset: 'audio', vacio: '(del motor)' },
    ];
    if (!r.color) r.color = R.COLOR_TIPO[r.tipo];
    if (r.municionTipo === undefined) r.municionTipo = '';
    if (conArma(r) && !r.arma && armas.length) r.arma = armas[0][0];
    titulo(p, 'Preajustes');
    const presets = document.createElement('div');
    presets.className = 'acciones';
    for (const pr of Object.values(R.PRESETS)) {
      const b = document.createElement('button');
      b.textContent = pr.nombre;
      b.title = 'Poner los valores de: ' + pr.nombre;
      b.onclick = () => {
        Ed.marcarCambio();
        const { nombre, armaPorNombre, municionPorNombre, ...valores } = pr;
        Object.assign(ent.recogible, { ...R.BASE, ...valores, color: R.COLOR_TIPO[valores.tipo] });
        if (armaPorNombre) {
          const a = (Ed.proyecto.armas || []).find((x) => x.nombre === armaPorNombre) || (Ed.proyecto.armas || [])[0];
          ent.recogible.arma = a ? a.id : '';
        }
        if (municionPorNombre) {
          // el tipo con ese nombre; si no, el que use el arma; si no, munición propia del arma
          const ms = Ed.proyecto.municiones || [];
          const arma = (Ed.proyecto.armas || []).find((x) => x.id === ent.recogible.arma);
          const m = ms.find((x) => x.nombre === municionPorNombre) || (arma && ms.find((x) => x.id === arma.municion));
          ent.recogible.municionTipo = m ? m.id : '';
        }
        const nombres = Object.values(R.PRESETS).map((x) => x.nombre);
        if (ent.nombre === 'Recogible' || nombres.includes(ent.nombre.replace(/ \d+$/, ''))) ent.nombre = nombre;
        Ed.reconstruirEntidad(ent);
        Ed.pintarArbol();
        Ed.pintarInspector();
        Ed.guardarLocal();
      };
      presets.appendChild(b);
    }
    p.appendChild(presets);
    const defectos = { ...R.BASE, color: R.COLOR_TIPO[r.tipo] };
    formulario(p, ESQ, r, (k, v, definitivo, anterior) => {
      if (k === 'tipo') {
        // color del tipo nuevo si no se había cambiado a mano
        if (r.color === R.COLOR_TIPO[anterior]) r.color = R.COLOR_TIPO[v];
        if (v === 'municion' && !r.municionTipo && tiposM.length) r.municionTipo = tiposM[0][0];
        if (v === 'arma' && r.cantidad === R.BASE.cantidad) r.cantidad = 0;
        if (conArma(r) && !r.arma && armas.length) r.arma = armas[0][0];
        if (v === 'objeto') {
          const obs = Ed.proyecto.objetos || [];
          if (!r.objeto && obs.length) r.objeto = obs[0].id;
          if (r.cantidad === R.BASE.cantidad) r.cantidad = 1;
          r.color = '';                       // el del objeto
        }
      }
      if (k === 'municionTipo' && !v && !r.arma && armas.length) r.arma = armas[0][0];
      if (['tipo', 'modelo', 'color', 'brillo', 'objeto'].includes(k)) Ed.reconstruirEntidad(ent);
      if (k === 'tipo' || k === 'recoger') { Ed.pintarInspector(); }
      if (definitivo) Ed.guardarLocal();
    }, { defectos, antes: () => Ed.marcarCambio() });


    // avisos: qué módulo del jugador hace falta
    const m = Ed.proyecto.jugador.modulos;
    if ((r.tipo === 'vida' || r.tipo === 'armadura') && !m.salud?.activo) nota(p, '⚠ Activa <b>Salud y muerte</b> en la pestaña Jugador para que dé vida o armadura.');
    else if (r.tipo === 'armadura' && !(m.salud.armaduraMax > 0)) nota(p, '⚠ En <b>Salud y muerte</b> la armadura máxima es 0: súbela para que sirva.');
    if (conArma(r) && !m.armas?.activo) nota(p, '⚠ Activa el módulo <b>Armas</b> en la pestaña Jugador.');
    if (r.recoger === 'usar' && !m.interactuar?.activo) nota(p, '⚠ Para recogerlo con el botón de usar activa <b>Interactuar</b> en la pestaña Jugador.');
  }
  Ed.cabeceraPanel = cabeceraPanel;
  Ed.titulo = titulo;
  Ed.nota = nota;
  Ed.botonera = botonera;
  Ed.formEnemigo = formEnemigo;
  Ed.usosCriatura = usosCriatura;
  Ed.propagarCriatura = propagarCriatura;

  /* ---------- 🌊 Atajos de movimiento de materiales ---------- */
  const SIN_MOV = { ondular: false, olas: false, viento: false, ondear: false };
  const ATAJOS_MOV = {
    quieto: { nombre: '⏹ Quieto (sin movimiento ni pasto)', ...SIN_MOV, pasto: false, desplazX: 0, desplazY: 0 },
    rio: { nombre: '🏞 Río', ...SIN_MOV, ondular: true, ondularCant: 0.03, ondularTam: 6, ondularVel: 1.2, desplazX: 0.15, desplazY: 0, modo: 'translucido', opacidad: 0.75 },
    mar: { nombre: '🌊 Mar con oleaje', ...SIN_MOV, olas: true, olaAltura: 0.5, olaLargo: 8, olaVel: 1.5, olaDir: 0, ondular: true, ondularCant: 0.015, ondularTam: 4, ondularVel: 0.8, desplazX: 0.02, desplazY: 0.01 },
    arbol: { nombre: '🌳 Hojas de árbol / arbusto', ...SIN_MOV, viento: true, vientoFuente: 'nivel', vientoCant: 0.25, vientoAlto: 4, vientoVel: 0.8 },
    bandera: { nombre: '🚩 Bandera / tela', ...SIN_MOV, ondear: true, ondearCant: 0.12, ondearLargo: 0.6, ondearVel: 1.4, dobleCara: true },
    lava: { nombre: '🔥 Lava burbujeante', ...SIN_MOV, ondular: true, ondularCant: 0.04, ondularTam: 5, ondularVel: 0.6, desplazX: 0.03, desplazY: 0.02, olas: true, olaAltura: 0.12, olaLargo: 3, olaVel: 0.4, sinLuz: true },
  };
  const valoresAtajo = (clave) => { const { nombre, ...v } = ATAJOS_MOV[clave] || {}; return v; };

  /* ---------- Esquema simple de material (modelos y primitivas) ---------- */
  const ESQUEMA_MATERIAL = [
    { k: 'modo', t: 'sel', e: 'Modo', op: F.Render.MODOS_MATERIAL, ayuda: 'Translúcido para agua y vidrio · Recorte para hojas y rejas · Aditivo para fuego y magia' },
    { k: 'opacidad', t: 'rango', e: 'Opacidad', min: 0, max: 1, paso: 0.05, ayuda: 'Solo en translúcido y aditivo' },
    { k: 'prioridad', t: 'num', e: 'Prioridad', paso: 1, ayuda: 'Orden entre transparencias: el número más alto se dibuja encima (como render priority de Godot)' },
    { k: 'dobleCara', t: 'bool', e: 'Doble cara', ayuda: 'Se ve por los dos lados (hojas, telas, agua vista desde abajo)' },
    { k: 'sinLuz', t: 'bool', e: 'Sin luz', ayuda: 'Ignora las luces: letreros, cielos, cascadas brillantes' },
    { k: 'desplazX', t: 'num', e: 'Fluir X', paso: 0.01, ayuda: 'La textura se mueve sola (agua, lava). Repeticiones por segundo' },
    { k: 'desplazY', t: 'num', e: 'Fluir Y', paso: 0.01 },
    // 🌊 movimiento (todo en la GPU; lo que está apagado no cuesta nada)
    { grupo: '🌊 Movimiento' },
    { k: 'movAtajo', t: 'sel', e: 'Atajo', op: [['', '— elegir para poner sus valores —'], ...Object.entries(ATAJOS_MOV).map(([k, v]) => [k, v.nombre])],
      ayuda: 'Pone de una vez los valores de ese efecto (luego ajusta lo que quieras)' },
    { k: 'ondular', t: 'bool', e: '〰 Ondular la textura', ayuda: 'La textura se deforma en ondas: reflejos de río, calor, portales. Necesita textura' },
    { k: 'ondularCant', t: 'rango', e: 'Cuánto', min: 0, max: 0.15, paso: 0.005, si: (v) => v.ondular },
    { k: 'ondularTam', t: 'num', e: 'Ondas por repetición', paso: 0.5, min: 0.5, si: (v) => v.ondular },
    { k: 'ondularVel', t: 'num', e: 'Velocidad', paso: 0.1, min: 0, si: (v) => v.ondular },
    { k: 'olas', t: 'bool', e: '🌊 Oleaje', ayuda: 'La superficie sube y baja en olas (mar, lago con viento, lava). Solo se ve: la colisión no se mueve. Las piezas del motor se parten solas para que ondulen; un modelo necesita bastantes vértices' },
    { k: 'olaAltura', t: 'num', e: 'Altura de las olas (m)', paso: 0.05, min: 0, si: (v) => v.olas },
    { k: 'olaLargo', t: 'num', e: 'Largo de onda (m)', paso: 0.5, min: 0.2, si: (v) => v.olas },
    { k: 'olaVel', t: 'num', e: 'Velocidad (m/s)', paso: 0.1, min: 0, si: (v) => v.olas },
    { k: 'olaDir', t: 'rango', e: 'Dirección (°)', min: 0, max: 360, paso: 5, si: (v) => v.olas },
    { k: 'olasJuego', t: 'bool', e: 'El juego las nota (flotar)', si: (v) => v.olas, ayuda: 'Si es el agua de un lago o mar del modelo: nadando, en bote y los enemigos suben y bajan con las olas. Apagado = solo se ven (un poco más barato)' },
    { k: 'viento', t: 'bool', e: '🌬 Se mece con el viento', ayuda: 'Pasto, arbustos, copas de árbol, cables: la base queda quieta y lo de arriba se mece' },
    { k: 'vientoFuente', t: 'sel', e: 'Viento', op: [['nivel', 'El del nivel (Escena ▸ Ambiente ▸ Viento)'], ['propio', 'Propio de este material']], si: (v) => v.viento,
      ayuda: 'Del nivel: todo se mueve junto hacia el mismo lado, con ráfagas. Sin viento en el nivel hay una brisa suave' },
    { k: 'vientoDir', t: 'rango', e: 'Hacia dónde (°)', min: 0, max: 360, paso: 5, si: (v) => v.viento && v.vientoFuente === 'propio' },
    { k: 'vientoFuerza', t: 'rango', e: 'Fuerza', min: 0, max: 1, paso: 0.05, si: (v) => v.viento && v.vientoFuente === 'propio' },
    { k: 'vientoCant', t: 'num', e: 'Cuánto se mueve (m)', paso: 0.05, min: 0, si: (v) => v.viento, ayuda: 'Lo que se mueve la punta con fuerza 1' },
    { k: 'vientoAlto', t: 'num', e: 'Altura que se mueve entera (m)', paso: 0.25, min: 0.05, si: (v) => v.viento, ayuda: 'Desde el pie del objeto: a esta altura ya se mueve todo. Pasto ≈ 0.5 · árbol ≈ 4' },
    { k: 'vientoVel', t: 'num', e: 'Rapidez', paso: 0.1, min: 0, si: (v) => v.viento },
    { k: 'ondear', t: 'bool', e: '🚩 Ondear (bandera, tela)', ayuda: 'Una onda recorre el ancho; el lado izquierdo queda fijo (el mástil)' },
    { k: 'ondearCant', t: 'num', e: 'Cuánto (m)', paso: 0.02, min: 0, si: (v) => v.ondear },
    { k: 'ondearLargo', t: 'num', e: 'Largo de onda (m)', paso: 0.1, min: 0.05, si: (v) => v.ondear },
    { k: 'ondearVel', t: 'num', e: 'Velocidad', paso: 0.1, min: 0, si: (v) => v.ondear },
    // 🌾 (pasto encima: apagado por ahora; se rehará solo alrededor del jugador)
  ];
  // atajos: ponen varios valores de una vez (lo que no dicen se apaga)
  Ed.ATAJOS_MOV = ATAJOS_MOV;
  // solo el grupo de movimiento (para el inspector de la entidad modelo)
  const ESQUEMA_MOV = ESQUEMA_MATERIAL.slice(ESQUEMA_MATERIAL.findIndex((d) => d.grupo === '🌊 Movimiento') + 1);
  const ESQUEMA_MATERIAL_MODELO = [
    { k: 'tinte', t: 'color', e: 'Tinte' },
    { k: 'textura', t: 'asset', e: 'Textura', tipoAsset: 'textura', vacio: '(la del modelo)' },
    { k: 'normal', t: 'asset', e: 'Mapa normal', tipoAsset: 'textura', vacio: '(el del modelo)' },
    ...ESQUEMA_MATERIAL,
    { grupo: '💡 Emite luz' },
    { k: 'luz', t: 'bool', e: 'Emite luz', ayuda: 'Cada lámpara / antorcha hecha con este material se vuelve una fuente de luz (con 💡 Luces encendido). Tip: marca también "Sin luz" para que brille' },
  ];
  // Sección propia de la luz de un material (aparece al marcar "Emite luz")
  const ESQUEMA_LUZ_MATERIAL = [
    { k: 'luzColor', t: 'color', e: 'Color luz' },
    { k: 'luzFuerza', t: 'rango', e: 'Fuerza', min: 0, max: 5, paso: 0.1 },
    { k: 'luzAlcance', t: 'num', e: 'Alcance (m)', paso: 0.5, min: 0.5 },
    { k: 'luzParpadeo', t: 'rango', e: 'Parpadeo', min: 0, max: 1, paso: 0.05, ayuda: '0 = fija · 0.3 antorcha · 0.8 foco a punto de fundirse' },
    { k: 'luzVelocidad', t: 'num', e: 'Vel. parpadeo', paso: 0.5, min: 0.5 },
    { k: 'luzAgrupar', t: 'num', e: 'Juntar en (m)', paso: 0.25, min: 0.2, ayuda: 'Triángulos a menos de esta distancia son la misma lámpara (una sola luz)' },
    { k: 'luzHalo', t: 'rango', e: 'Aura', min: 0, max: 1.5, paso: 0.05, ayuda: 'Resplandor alrededor, como en los juegos de la época. 0 = sin aura' },
    { k: 'luzHaloTam', t: 'num', e: 'Tamaño aura (m)', paso: 0.1, min: 0.1 },
    { k: 'luzHaloForma', t: 'sel', e: 'Forma del aura', op: [['circulo', '● Círculo'], ['estrella', '✦ Estrella']] },
  ];
  const ESQUEMA_LUZ = [
    { grupo: '💡 Luz' },
    { k: 'color', t: 'color', e: 'Color' },
    { k: 'fuerza', t: 'rango', e: 'Fuerza', min: 0, max: 5, paso: 0.1 },
    { k: 'alcance', t: 'num', e: 'Alcance (m)', paso: 0.5, min: 0.5, ayuda: 'Más allá de esto no alumbra nada' },
    { k: 'apagada', t: 'bool', e: 'Empieza apagada', ayuda: 'Al jugar empieza apagada: la enciende una 🕹 palanca o un interruptor (acción "Encender luz")' },
    { k: 'soloNoche', t: 'bool', e: '🌙 Solo de noche', ayuda: 'Con 🌦 Clima en la escena se enciende sola al anochecer y se apaga al amanecer (farolas, ventanas). Sin clima, siempre encendida' },
    { k: 'parpadeo', t: 'rango', e: 'Parpadeo', min: 0, max: 1, paso: 0.05, ayuda: '0 = fija · 0.3 antorcha · 0.8 foco a punto de fundirse' },
    { k: 'velocidad', t: 'num', e: 'Vel. parpadeo', paso: 0.5, min: 0.5 },
    { k: 'halo', t: 'rango', e: 'Aura', min: 0, max: 1.5, paso: 0.05, ayuda: 'Resplandor alrededor de la luz, como en los juegos de la época. 0 = sin aura' },
    { k: 'haloTam', t: 'num', e: 'Tamaño aura (m)', paso: 0.1, min: 0.1 },
    { k: 'haloForma', t: 'sel', e: 'Forma del aura', op: [['circulo', '● Círculo'], ['estrella', '✦ Estrella (destello)']] },
  ];

  /* ---------- Sección "Luz de este material" ----------
     Tipo (antorcha, lámpara…) que rellena todo, y luego color, fuerza, alcance, parpadeo y aura.
     Es independiente del sol: cada material tiene su propia luz. */
  function guardarMaterial(a, i, m, cambios) {
    const { map, normalMap, ...guardable } = { ...F.Assets.configMaterial(Ed.proyecto, a.id, i, m), ...cambios };
    F.Assets.guardarConfigMaterial(Ed.proyecto, a, i, guardable);
    F.Assets.aplicarMaterialesAsset(Ed.proyecto, a);
    Ed.actualizarUsosModelo(a.id);
  }

  function seccionLuzMaterial(cont, a, i, m) {
    const caja = document.createElement('div');
    caja.className = 'seccion-luz';
    cont.appendChild(caja);
    const pintar = () => {
      caja.innerHTML = '';
      const cfg = F.Assets.configMaterial(Ed.proyecto, a.id, i, m);
      caja.style.display = cfg.luz ? '' : 'none';
      if (!cfg.luz) return;
      titulo(caja, `💡 Luz de "${m.name || 'material ' + (i + 1)}"`);
      // Tipo: busca si los valores coinciden con alguno; si no, "Personalizada"
      const presets = Object.entries(F.Luces.PRESETS);
      const actual = presets.find(([, pr]) => pr.color === cfg.luzColor && pr.fuerza === cfg.luzFuerza && pr.alcance === cfg.luzAlcance && pr.parpadeo === cfg.luzParpadeo);
      const tipo = controlEsquema({ t: 'sel', op: [['', 'Personalizada'], ...presets.map(([k, pr]) => [k, pr.nombre])] }, actual ? actual[0] : '', (v) => {
        if (!v) return;
        const pr = F.Luces.PRESETS[v];
        guardarMaterial(a, i, m, { luzColor: pr.color, luzFuerza: pr.fuerza, luzAlcance: pr.alcance, luzParpadeo: pr.parpadeo,
          luzVelocidad: pr.velocidad, luzHalo: pr.halo, luzHaloTam: pr.haloTam });
        Ed.guardarLocal();
        pintar();
      });
      caja.appendChild(fila('Tipo', tipo, 'Pone color, fuerza, alcance, parpadeo y aura de golpe; luego ajusta lo que quieras'));
      const { map: _m, normalMap: _n, ...original } = m.userData.original || {};
      formulario(caja, ESQUEMA_LUZ_MATERIAL, cfg, (k, v, definitivo) => {
        guardarMaterial(a, i, m, { [k]: v });
        if (definitivo) { Ed.guardarLocal(); pintar(); }
      }, { defectos: original });
      avisoLuces(caja, m, () => F.Assets.configMaterial(Ed.proyecto, a.id, i, m));
    };
    pintar();
    return pintar;
  }
  Ed.seccionLuzMaterial = seccionLuzMaterial;

  /* Texto de diagnóstico de un material que emite luz: cuántas luces creó y por qué podría no verse */
  function textoLucesMaterial(mat, cfg) {
    if (!cfg.luz) return '';
    if (!Ed.proyecto.ajustes.lucesExtra) return '⚠ 💡 Luces está apagado: enciéndelo en la barra del visor (o tecla L) para verlas.';
    const n = Ed.vista.luces ? Ed.vista.luces.cuantasDe(mat) : 0;
    if (!n) return '⚠ Ninguna luz: este modelo no está colocado en la escena que estás editando.';
    return `💡 ${n} luz(es) creadas con este material en esta escena (puntos de color en el visor).`;
  }
  Ed.textoLucesMaterial = textoLucesMaterial;
  // Tras volver a juntar las luces, se actualizan los avisos que estén a la vista
  Ed.actualizarAvisosLuces = function () {
    document.querySelectorAll('#panelInspector [data-luces-mat]').forEach((el) => {
      const mat = el._mat, cfg = el._cfg();
      el.textContent = textoLucesMaterial(mat, cfg);
      el.style.display = cfg.luz ? '' : 'none';
    });
  };
  function avisoLuces(cont, mat, cfg) {
    const el = document.createElement('div');
    el.className = 'nota aviso-luces';
    el.dataset.lucesMat = mat.uuid;
    el._mat = mat;
    el._cfg = cfg;
    cont.appendChild(el);
    const c = cfg();
    el.textContent = textoLucesMaterial(mat, c);
    el.style.display = c.luz ? '' : 'none';
    return el;
  }

  /* ---------- Miniatura de una textura (para materiales de GLB) ---------- */
  function miniatura(tex, tam = 34) {
    const c = document.createElement('canvas');
    c.width = c.height = tam;
    c.className = 'miniatura';
    c.style.width = c.style.height = tam + 'px';
    const img = tex && tex.image;
    const g = c.getContext('2d');
    g.imageSmoothingEnabled = false;
    if (img && img.width) {
      try { g.drawImage(img, 0, 0, tam, tam); } catch (err) { /* imagen no dibujable */ }
    } else {
      g.fillStyle = '#333';
      g.fillRect(0, 0, tam, tam);
    }
    return c;
  }

  /* =========================================================
     INSPECTOR (entidad o archivo seleccionado)
     ========================================================= */
  function campoVector(ent, clave, paso) {
    const cont = document.createElement('div');
    cont.className = 'vec';
    for (let i = 0; i < 3; i++) {
      const inp = document.createElement('input');
      inp.type = 'number';
      inp.step = paso;
      inp.value = ent[clave][i];
      inp.dataset.vec = clave + i;
      inp.onchange = () => {
        Ed.marcarCambio();
        ent[clave][i] = parseFloat(inp.value) || 0;
        F.Escena.aplicarTransform(Ed.objetos.get(ent.id), ent);
        Ed.guardarLocal();
      };
      cont.appendChild(inp);
    }
    return cont;
  }

  const filasVector = [];
  Ed.actualizarCamposTransform = function (ent) {
    for (const f of filasVector) if (f.isConnected) f._actualizar();
    for (const clave of ['pos', 'rot', 'esc']) {
      for (let i = 0; i < 3; i++) {
        const inp = document.querySelector(`#panelInspector [data-vec="${clave}${i}"]`);
        if (inp && document.activeElement !== inp) inp.value = ent[clave][i];
      }
    }
  };

  Ed.pintarInspector = function () {
    if (Ed.assetSeleccionado) return pintarInspectorAsset(Ed.assetSeleccionado);
    const p = $('panelInspector');
    p.innerHTML = '';
    if (Ed.seleccionados && Ed.seleccionados.size > 1) return pintarInspectorVarios(p);
    const ent = Ed.escena.entidades.find((e) => e.id === Ed.seleccion);
    if (!ent) {
      pintarPrimerosPasos(p);
      nota(p, 'Selecciona algo en el visor, en el árbol de <b>Escena</b> o un archivo en <b>Archivos</b>.');
      nota(p, `<b>Visor:</b> clic izq. girar · rueda zoom · rueda pulsada desplazar ·
        <b>clic derecho + WASD</b> volar (Q/E bajar/subir, Shift rápido)`);
      nota(p, `<b>Atajos:</b> W mover · E rotar · R escalar · T local/global · G imán (0,25 m · 15°; sin imán 0,1 m · 1°; Shift al arrastrar = fino) · F enfocar · Fin = al suelo · Supr borrar ·
        Ctrl+D duplicar · Ctrl+C / Ctrl+V copiar y pegar · Ctrl+G agrupar · Ctrl+Z / Ctrl+Y deshacer · P jugar`);
      nota(p, `<b>Varios a la vez:</b> Ctrl + clic (visor o árbol) · Shift + clic en el árbol = rango · Shift + arrastrar en el visor = rectángulo.
        <b>Vistas:</b> teclado numérico 7 superior · 1 frontal · 3 lateral · 5 perspectiva. Todos los atajos en <b>Ayuda</b>.`);
      nota(p, '<b>Tip:</b> arrastra un modelo desde Archivos al visor para colocarlo donde sueltes.');
      return;
    }
    const S = F.Escena;
    cabeceraPanel(p, `${S.ICONO[ent.tipo] || ''} ${S.NOMBRE_TIPO[ent.tipo] || ent.tipo}`, () => restablecerEntidad(ent),
      'Deja material, medidas, colisión, rotación y escala como recién creado (conserva nombre, posición y jerarquía)');

    const nom = document.createElement('input');
    nom.value = ent.nombre;
    nom.onchange = () => { Ed.marcarCambio(); ent.nombre = nom.value; Ed.pintarArbol(); Ed.guardarLocal(); };
    p.appendChild(fila('Nombre', nom));
    const filaVector = (texto, clave, paso, def) => {
      const f = fila(texto, campoVector(ent, clave, paso), '', {
        texto: def.join(', '),
        modificado: () => !igual(ent[clave], def),
        alRevertir: () => {
          Ed.marcarCambio();
          ent[clave] = def.slice();
          F.Escena.aplicarTransform(Ed.objetos.get(ent.id), ent);
          Ed.actualizarCamposTransform(ent);
          f.querySelectorAll('[data-vec]').forEach((inp, i) => { inp.value = ent[clave][i]; });   // aunque tenga el foco
          f._actualizar();
          Ed.guardarLocal();
        },
      });
      f.querySelectorAll('input').forEach((i) => i.addEventListener('change', () => f._actualizar()));
      filasVector.push(f);
      return f;
    };
    filasVector.length = 0;
    p.appendChild(filaVector('Posición', 'pos', 0.1, [0, 0, 0]));
    p.appendChild(filaVector('Rotación °', 'rot', 15, [0, 0, 0]));
    if (ent.tipo !== 'inicio' && ent.tipo !== 'trampa') p.appendChild(filaVector(ent.tipo === 'salida' ? 'Tamaño caja' : ent.tipo === 'puerta' ? 'Hueco (an·al·fondo)' : ent.tipo === 'disparador' ? 'Tamaño de la zona' : 'Escala', 'esc', 0.1, S.entidadNueva(ent.tipo).esc));

    if (ent.tipo === 'modelo') {
      const a = F.Assets.mapa.get(ent.asset);
      const enlace = document.createElement('button');
      enlace.textContent = a ? `◆ ${a.nombre}` : 'Archivo no encontrado';
      enlace.title = 'Ver el archivo, sus materiales y texturas';
      enlace.onclick = () => a && Ed.seleccionarAsset(a.id);
      p.appendChild(fila('Archivo', enlace));
      if (a && Ed.Apps && Ed.Apps.datosForja(a)) botonera(p, [[Ed.Apps.textoEditar(a), () => Ed.Apps.editarEnApp(a.id), 'primario', 'Abre la app con esto mismo; lo que cambies vuelve solo aquí']]);
      if (a && a.esReceta) {
        if (a.gltf) nota(p, `🧾 <b>Receta</b>: generada con <b>${F.Generadores.clave(a.receta)}</b> en ${a.infoReceta && a.infoReceta.ms != null ? a.infoReceta.ms + ' ms' : '?'} · ${F.util.fmt ? F.util.fmt(a.tris || 0) : a.tris} triángulos · la receta pesa ${(a.datos.byteLength / 1024).toFixed(1)} KB.`);
        else nota(p, a.faltaGenerador ? `⚠ <b>Falta el generador ${a.faltaGenerador}</b>: carga la app que hizo esta receta en <b>Apps</b> y vuelve a enviarla.` : `⚠ La receta no se pudo generar: ${a.errorReceta}`);
      }
      if (a && a.gltf && Ed.pintarMarcadoresModelo) Ed.pintarMarcadoresModelo(p, ent, a);   // niveles del Entorno de Niveles
      if (a && a.gltf) pintarMaterialesModelo(p, a);
      // lagos, ríos y lava del modelo (mallas cuyo material se llama agua / water / lava / ácido…)
      const objM = Ed.objetos.get(ent.id), liqs = objM && objM.userData.liquidos;
      if (liqs) {
        const am = ent.aguaModelo || (ent.aguaModelo = { ...F.Agua.AGUA_MODELO });
        const cuenta = {};
        for (const l of liqs) cuenta[l] = (cuenta[l] || 0) + 1;
        titulo(p, '💧 Líquidos del modelo');
        nota(p, 'Encontré ' + Object.entries(cuenta).map(([l, n]) => `${n} malla${n === 1 ? '' : 's'} de <b>${(F.Agua.LIQUIDOS[l] || {}).nombre || l}</b>`).join(', ') +
          ' (por el nombre de su material). No chocan: se nada dentro y los acuáticos viven ahí.');
        formulario(p, [
          { k: 'activo', t: 'bool', e: 'Usar como líquido', ayuda: 'Apagado = son mallas normales (sólidas, sin nadar)' },
          { k: 'liquido', t: 'sel', e: 'Qué líquido es', si: (v) => v.activo !== false,
            op: [['auto', 'Según el nombre del material'], ...Object.entries(F.Agua.LIQUIDOS).map(([k, v]) => [k, v.nombre])] },
          { k: 'aspecto', t: 'sel', e: 'Cómo se ve', si: (v) => v.activo !== false,
            op: [['auto', 'Automático (como viene si trae textura; si no, ondas)'], ['motor', 'Ondas retro del motor (se mueven)'], ['modelo', 'Como viene en el modelo']] },
          { k: 'mosaico', t: 'num', e: 'Tamaño de las ondas (m)', paso: 0.25, min: 0.25, si: (v) => v.activo !== false && v.aspecto !== 'modelo', av: true },
        ], am, (k, v, definitivo) => { if (definitivo) { Ed.reconstruirEntidad(ent); Ed.guardarLocal(); } }, { defectos: F.Agua.AGUA_MODELO, antes: () => Ed.marcarCambio() });
      }
    }

    const base = S.entidadNueva(ent.tipo);
    if (ent.tipo === 'modelo') {
      const am = F.Assets.mapa.get(ent.asset);
      base.colision = am && am.gltf && am.gltf.animations.length ? 'ninguna' : 'malla';
    }
    const opc = (defectos) => ({ defectos, antes: () => Ed.marcarCambio() });
    const generales = [];
    if (!S.SIN_COLISION.has(ent.tipo) && ent.tipo !== 'puerta' && ent.tipo !== 'plataforma' && ent.tipo !== 'trampa') {
      generales.push({ k: 'colision', t: 'sel', e: 'Colisión', op: [['malla', 'Malla exacta (trimesh)'], ['caja', 'Caja envolvente'], ['ninguna', 'Sin colisión']],
        ayuda: 'Malla = choca con la forma exacta. Caja = más barato, para objetos simples.' });
    }
    if (!['inicio', 'carpeta', 'luz', 'punto', 'aparecedor', 'marcador', 'salida', 'agua', 'disparador', 'condicion'].includes(ent.tipo)) {
      generales.push({ k: 'sombra', t: 'bool', e: 'Proyecta sombra', ayuda: 'Sombra del sol (con 💡 Luces encendido). Apágalo en objetos pequeños o lejanos: menos trabajo' });
    }
    if (!['inicio', 'carpeta', 'luz', 'recogible', 'enemigo', 'punto', 'aparecedor', 'marcador', 'salida', 'agua', 'disparador', 'puerta', 'palanca', 'pedestal', 'condicion', 'plataforma', 'trampa'].includes(ent.tipo)) {
      generales.push({ k: 'vida', t: 'num', e: 'Vida (rompible)', paso: 5, min: 0,
        ayuda: '0 = indestructible. Con vida, los disparos y golpes lo rompen: desaparece y deja de chocar (cajas, barriles, paredes falsas)' });
      generales.push({ k: 'explota', t: 'num', e: '💥 Explota al romperse (radio m)', paso: 0.5, min: 0, si: (v) => v.vida > 0,
        ayuda: '0 = no explota. Daña al jugador, enemigos, rehenes y a otros rompibles cerca (barriles en cadena)' });
      generales.push({ k: 'danoExplosion', t: 'num', e: 'Daño de la explosión', paso: 5, min: 0, si: (v) => v.vida > 0 && v.explota > 0 });
    }
    if (!['inicio', 'luz', 'salida', 'disparador', 'condicion'].includes(ent.tipo)) {
      generales.push({ k: 'visible', t: 'bool', e: 'Visible en juego', ayuda: 'Desmarcado = no se ve pero sigue chocando (muro invisible). En carpetas oculta a sus hijos.' });
    }
    formulario(p, generales, ent, (k) => {
      if (k === 'sombra') F.Luces.aplicarSombras(Ed.objetos.get(ent.id), ent.sombra !== false);
      Ed.pintarArbol();
      Ed.guardarLocal();
    }, opc(base));

    // Interacción: lo que pasa al mirarlo y pulsar E (módulo "Interactuar" del jugador)
    if (!['inicio', 'luz', 'recogible', 'enemigo', 'punto', 'aparecedor', 'marcador', 'salida', 'agua', 'disparador', 'puerta', 'palanca', 'pedestal', 'condicion', 'plataforma', 'trampa'].includes(ent.tipo)) {
      const base = { tipo: '', verbo: 'Leer', titulo: '', texto: '', mostrarNombre: true, unaVez: false };
      const it = { ...base, ...(ent.interaccion || {}) };
      const ESQ_INTER = [
        { grupo: '✋ Interacción' },
        { k: 'tipo', t: 'sel', e: 'Al usarlo', op: [['', 'Nada'], ['mensaje', 'Mostrar mensaje (cartel, nota)']],
          ayuda: 'Necesita el módulo "Interactuar" activo en Jugador. Pronto: puertas, palancas, baúles…' },
      ];
      if (it.tipo) {
        ESQ_INTER.push(
          { k: 'verbo', t: 'texto', e: 'Verbo del aviso', ayuda: 'Sale como "E: Leer cartel"' },
          { k: 'mostrarNombre', t: 'bool', e: 'Aviso con el nombre', ayuda: 'Añade el nombre del objeto al aviso' },
          { k: 'titulo', t: 'texto', e: 'Título', ayuda: 'Opcional, arriba del mensaje (ej. "NOTA", "DIARIO DEL DOCTOR")' },
          { k: 'retrato', t: 'asset', e: 'Retrato', tipoAsset: 'textura', vacio: '(sin retrato)', ayuda: 'Cara de quien habla, a la izquierda del texto (imagen pequeña, mejor cuadrada)' },
          { k: 'texto', t: 'textoLargo', e: 'Mensaje', filas: 4 },
          { k: 'unaVez', t: 'bool', e: 'Solo una vez' },
        );
      }
      formulario(p, ESQ_INTER, it, (k) => {
        ent.interaccion = { ...it };
        if (!it.tipo) delete ent.interaccion;
        Ed.guardarLocal();
        if (k === 'tipo') Ed.pintarInspector();
      }, { defectos: base, antes: () => Ed.marcarCambio() });
      if (it.tipo && !Ed.proyecto.jugador.modulos.interactuar?.activo) {
        nota(p, '⚠ Activa el módulo <b>Interactuar</b> en la pestaña Jugador para poder usarlo.');
      }
    }

    if (ent.tipo === 'luz') {
      formulario(p, ESQUEMA_LUZ, ent.luz, (k, v, definitivo) => {
        if (k === 'alcance') ent.luz.alcance = Math.max(0.5, v || 0.5);
        if (k === 'color' || k === 'alcance') Ed.reconstruirEntidad(ent);
        if (definitivo) Ed.guardarLocal();
      }, { defectos: F.Luces.LUZ_BASE, antes: () => Ed.marcarCambio() });
      const presets = document.createElement('div');
      presets.className = 'acciones';
      for (const [clave, pr] of Object.entries(F.Luces.PRESETS)) {
        const b = document.createElement('button');
        b.textContent = pr.nombre;
        b.title = 'Poner los valores de: ' + pr.nombre;
        b.onclick = () => {
          Ed.marcarCambio();
          const { nombre, ...valores } = pr;
          Object.assign(ent.luz, valores);
          if (/^(Luz|Lámpara|Antorcha|Fogata|Fluorescente roto|Magia)( \d+)?$/.test(ent.nombre)) ent.nombre = nombre;
          Ed.reconstruirEntidad(ent);
          Ed.pintarArbol();
          Ed.pintarInspector();
          Ed.guardarLocal();
        };
        presets.appendChild(b);
      }
      p.appendChild(presets);
      if (!Ed.proyecto.ajustes.lucesExtra) {
        nota(p, '⚠ Las luces están apagadas en este proyecto. Enciéndelas con <b>💡 Luces</b> (barra del visor) o en <b>Proyecto</b>.');
      }
    }

    if (ent.tipo === 'recogible') pintarRecogible(p, ent);
    if (ent.tipo === 'enemigo') pintarEnemigo(p, ent);
    if (ent.tipo === 'punto') pintarPunto(p, ent);
    if (ent.tipo === 'camara') pintarCamara(p, ent);
    if (ent.tipo === 'sonido') {
      formulario(p, F.Sonidos.ESQ_SONIDO, ent.sonido, (k, v, definitivo) => { if (definitivo) { if (k === 'radio') Ed.reconstruirEntidad(ent); Ed.guardarLocal(); } }, { defectos: F.Sonidos.SONIDO, antes: () => Ed.marcarCambio() });
      if (!ent.sonido.asset) nota(p, '⚠ Elige un sonido (impórtalo en Archivos ▸ Sonidos).');
      else if (ent.sonido.cerca >= ent.sonido.radio) nota(p, '⚠ "A todo volumen hasta" debe ser menor que "Se oye hasta".');
    }
    if (ent.tipo === 'particulas') {
      formulario(p, F.Particulas.ESQ, ent.particulas, (k, v, definitivo) => {
        if (k === 'tipo') Object.assign(ent.particulas, F.Particulas.PRESET[v] || {});
        if (definitivo || k === 'tipo') { Ed.reconstruirEntidad(ent); Ed.guardarLocal(); if (k === 'tipo') Ed.pintarInspector(); }
      }, { defectos: F.Particulas.PARTICULAS, antes: () => Ed.marcarCambio() });
    }
    if (ent.tipo === 'barrera') {
      formulario(p, F.Campo.ESQ_BARRERA, ent.barrera, (k, v, definitivo) => { if (definitivo || k === 'color' || k === 'fuerza') { Ed.reconstruirEntidad(ent); if (definitivo) Ed.guardarLocal(); } },
        { defectos: F.Campo.BARRERA, antes: () => Ed.marcarCambio() });
      nota(p, 'Tamaño = escala (R). Choca mientras está encendida. Para apagarla: una palanca / disparador con la acción <b>⬡ Apagar barrera</b>.');
    }
    if (ent.tipo === 'tienda') pintarTienda(p, ent);
    if (ent.tipo === 'npc') pintarNpc(p, ent);
    if (ent.tipo === 'rehen' || ent.tipo === 'bomba' || ent.tipo === 'brecha') {
      const TA = F.Tactico, esq = { rehen: TA.ESQ_REHEN, bomba: TA.ESQ_BOMBA, brecha: TA.ESQ_BRECHA }[ent.tipo], base = { rehen: TA.REHEN, bomba: TA.BOMBA, brecha: TA.BRECHA }[ent.tipo];
      formulario(p, esq, ent[ent.tipo], (k, v, definitivo) => { if (definitivo) { Ed.reconstruirEntidad(ent); Ed.guardarLocal(); } }, { defectos: base, antes: () => Ed.marcarCambio() });
      if (ent.tipo === 'rehen' && ent.rehen.modo === 'escolta' && !ent.rehen.extraccion) nota(p, '⚠ Elige su zona de extracción (un ⬚ disparador).');
      if (ent.tipo === 'brecha') nota(p, 'Se usa por los dos lados: se abre hacia el lado contrario al jugador. Distinta de la 🔒 puerta normal.');
      if (ent.tipo === 'bomba' && !ent.bomba.activa) nota(p, 'ℹ Arráncala con la acción "💣 Activar bomba" de un disparador o palanca.');
    }
    if (ent.tipo === 'aparecedor') pintarAparecedor(p, ent);
    if (ent.tipo === 'marcador') pintarMarcador(p, ent);
    if (ent.tipo === 'agua') pintarAgua(p, ent);
    if (ent.tipo === 'baul') pintarBaul(p, ent);
    if (ent.tipo === 'inicio') pintarInicio(p, ent);
    if (ent.tipo === 'salida') pintarSalida(p, ent);
    if (ent.tipo === 'empujable') {
      if (!ent.empujable) ent.empujable = { ...F.Empujables.EMPUJABLE };
      formulario(p, F.Empujables.ESQUEMA, ent.empujable, (k, v, definitivo) => {
        if (['forma', 'modelo', 'color'].includes(k)) { if (definitivo || k !== 'color') Ed.reconstruirEntidad(ent); }
        if (definitivo) Ed.guardarLocal();
      }, { defectos: F.Empujables.EMPUJABLE, antes: () => Ed.marcarCambio() });
      nota(p, 'El tamaño es su <b>Escala</b> (1 = 1 m). Para placas de presión: un ⬚ Disparador con "Lo activa: 🧱 Objetos movibles" y "Placa de presión visible".');
    }
    if (ent.tipo === 'montable') {
      if (!ent.montable) ent.montable = { ...F.Montables.MONTABLE };
      formulario(p, F.Montables.ESQUEMA, ent.montable, (k, v, definitivo) => {
        if (k === 'tipo') { Object.assign(ent.montable, F.Montables.PRESETS[v] || {}); Ed.reconstruirEntidad(ent); Ed.guardarLocal(); Ed.pintarInspector(); return; }
        if (['modelo', 'color', 'escalaModelo'].includes(k)) { if (definitivo || k !== 'color') Ed.reconstruirEntidad(ent); }
        if (definitivo) Ed.guardarLocal();
      }, { defectos: F.Montables.MONTABLE, antes: () => Ed.marcarCambio() });
      nota(p, 'Usar cerca = subir · usar otra vez (parado) = bajar. Adelante/atrás acelera y frena, izquierda/derecha gira. Bote: solo en 💧 agua. Vagoneta: sigue los 📍 Puntos de ruta "Riel 1", "Riel 2"…');
    }
    if (ent.tipo === 'guardado') {
      if (!ent.guardado) ent.guardado = { ...F.Guardado.PUNTO };
      formulario(p, F.Guardado.ESQUEMA, ent.guardado, (k, v, definitivo) => {
        if (['hace', 'activar', 'objeto', 'modelo', 'figura'].includes(k)) { Ed.reconstruirEntidad(ent); Ed.pintarInspector(); Ed.guardarLocal(); return; }
        if (definitivo) { if (k === 'color') Ed.reconstruirEntidad(ent); Ed.guardarLocal(); }
      }, { defectos: F.Guardado.PUNTO, antes: () => Ed.marcarCambio() });
      const g = (Ed.proyecto.menus.guardado || {});
      const im = Ed.proyecto.jugador.modulos.inventario;
      if (ent.guardado.objeto && !(im && im.activo)) nota(p, '⚠ Pide un objeto pero el módulo <b>Inventario</b> del jugador está apagado: este punto no se podrá usar nunca. Actívalo en Jugador ▸ Inventario.');
      nota(p, `Ajustes generales en Menús ▸ Partidas guardadas: se guarda en <b>${({ pausa: 'el menú de pausa', puntos: 'solo puntos del mapa', ambos: 'pausa y puntos' })[g.donde || 'ambos']}</b>, al morir <b>${g.alMorir === 'reaparecer' ? 'reaparece solo' : 'Game Over'}</b>.`);
    }
    if (ent.tipo === 'puerta') pintarPuerta(p, ent);
    if (ent.tipo === 'palanca') pintarPalanca(p, ent);
    if (ent.tipo === 'disparador') pintarDisparador(p, ent);
    if (ent.tipo === 'pedestal') pintarPedestal(p, ent);
    if (ent.tipo === 'plataforma') pintarPlataforma(p, ent);
    if (ent.tipo === 'trampa') pintarTrampa(p, ent);
    if (ent.tipo === 'condicion') pintarCondicion(p, ent);

    if (S.PARAMS_PRIMITIVA[ent.tipo]) {
      titulo(p, 'Material');
      const ESQ_MAT_PRIM = [
        { k: 'color', t: 'color', e: 'Color / tinte' },
        { k: 'textura', t: 'asset', e: 'Textura', tipoAsset: 'textura', vacio: '(cuadros)' },
        { k: 'normal', t: 'asset', e: 'Mapa normal', tipoAsset: 'textura', vacio: '(ninguno)', ayuda: 'Textura de relieve (_normal.png de tu forja de niveles)' },
        { k: 'fuerzaNormal', t: 'rango', e: 'Fuerza normal', min: 0, max: 3, paso: 0.05 },
        { k: 'mosaico', t: 'num', e: 'Mosaico (m)', paso: 0.25, min: 0.05, ayuda: 'Cuántos metros ocupa una repetición de la textura' },
      ];
      formulario(p, ESQ_MAT_PRIM, ent, (k, v, definitivo, anterior) => {
        if (k === 'mosaico') ent.mosaico = Math.max(0.05, v || 0.05);
        Ed.reconstruirEntidad(ent);
        if (k === 'textura' && v && !anterior && ent.color !== '#ffffff') {
          ent.color = '#ffffff';   // tinte blanco = colores reales de la textura
          Ed.reconstruirEntidad(ent);
          Ed.pintarInspector();
        }
        if (definitivo) Ed.guardarLocal();
      }, opc(base));
      formulario(p, ESQUEMA_MATERIAL, ent.material, (k, v, definitivo) => {
        if (k === 'movAtajo') {   // 🌊 atajo: pone sus valores y vuelve a pintar el formulario
          if (v) Object.assign(ent.material, valoresAtajo(v));
          ent.material.movAtajo = '';
          Ed.reconstruirEntidad(ent); Ed.guardarLocal(); Ed.pintarInspector();
          return;
        }
        Ed.reconstruirEntidad(ent);
        if (definitivo) Ed.guardarLocal();
      }, opc(base.material));

      if (ent.tipo === 'escala') {
        titulo(p, 'Escalera de mano');
        formulario(p, [{ k: 'forma', t: 'sel', e: 'Modelo', op: [['escalera', '🪜 Escalera (de madera o metal, contra una pared)'], ['cuerda', '🪢 Cuerda / lazo (colgando, se sube por cualquier lado)']],
          ayuda: 'La escalera se sube por su frente y arriba sales al borde. La cuerda cuelga de su punto más alto y se agarra desde cualquier lado' }],
          ent, (k, v) => { Ed.reconstruirEntidad(ent); Ed.guardarLocal(); }, { defectos: { forma: 'escalera' }, antes: () => Ed.marcarCambio() });
      }
      titulo(p, 'Medidas');
      const nombres = { peldanos: 'Peldaños', altoPeldano: 'Alto peldaño', ancho: 'Ancho', alto: 'Alto', largo: 'Largo', fondo: 'Fondo' };
      const ESQ_MEDIDAS = S.PARAMS_PRIMITIVA[ent.tipo].map(([k, , paso]) => ({ k, t: 'num', e: nombres[k] || k, paso, min: 0.01 }));
      formulario(p, ESQ_MEDIDAS, ent.params, (k, v) => {
        ent.params[k] = Math.max(0.01, v || 0.01);
        Ed.reconstruirEntidad(ent);
        Ed.guardarLocal();
      }, opc(base.params));
    }

    const botones = [['Enfocar (F)', Ed.enfocarSeleccion]];
    if (ent.tipo !== 'carpeta') botones.push(['⬇ Al suelo', Ed.soltarAlSuelo, '', 'Baja el objeto hasta lo que tenga debajo (Fin)']);
    if (ent.tipo !== 'inicio') {
      botones.push(['Duplicar', Ed.duplicarSeleccion, '', 'Ctrl+D']);
      botones.push(['Duplicar en fila…', Ed.duplicarEnFila, '', 'Varias copias en línea (cercas, columnas, escaleras de caracol)']);
    }
    botones.push(['Borrar', Ed.borrarSeleccion, 'peligro']);
    botonera(p, botones);
  };

  /* ---------- Varios seleccionados: lo que se puede hacer a todos a la vez ---------- */
  function pintarInspectorVarios(p) {
    const S = F.Escena;
    const lista = Ed.escena.entidades.filter((e) => Ed.seleccionados.has(e.id));
    cabeceraPanel(p, `${lista.length} objetos seleccionados`);
    const resumen = {};
    for (const e of lista) resumen[S.NOMBRE_TIPO[e.tipo] || e.tipo] = (resumen[S.NOMBRE_TIPO[e.tipo] || e.tipo] || 0) + 1;
    nota(p, Object.entries(resumen).map(([t, n]) => `${n} × ${t}`).join(' · '));
    const nombres = document.createElement('div');
    nombres.className = 'lista-nombres';
    for (const e of lista.slice(0, 40)) {
      const b = document.createElement('button');
      b.textContent = `${S.ICONO[e.tipo] || '·'} ${e.nombre}`;
      b.title = 'Clic: seleccionar solo este · Ctrl+clic: quitarlo de la selección';
      b.className = e.id === Ed.seleccion ? 'principal' : '';
      b.onclick = (ev) => Ed.seleccionar(e.id, false, ev.ctrlKey || ev.metaKey ? 'alternar' : 'solo');
      nombres.appendChild(b);
    }
    if (lista.length > 40) nombres.appendChild(document.createTextNode(` … y ${lista.length - 40} más`));
    p.appendChild(nombres);

    // Propiedades comunes: se aplican a todos (si todos tienen el mismo valor se muestra; si no, "(varios)")
    titulo(p, 'Cambiar a todos');
    const conCol = lista.filter((e) => !S.SIN_COLISION.has(e.tipo));
    const comun = (arr, k) => (arr.length && arr.every((e) => e[k] === arr[0][k]) ? arr[0][k] : null);
    const selComun = (arr, k, etiqueta, op, ayuda) => {
      if (!arr.length) return;
      const c = document.createElement('select');
      const v = comun(arr, k);
      if (v === null) c.add(new Option('(varios)', '', true, true));
      for (const [val, t] of op) c.add(new Option(t, val, false, v !== null && String(v) === String(val)));
      c.onchange = () => {
        if (c.value === '') return;
        Ed.marcarCambio();
        const val = c.value === 'true' ? true : c.value === 'false' ? false : c.value;
        for (const e of arr) e[k] = val;
        for (const e of arr) if (k !== 'colision') Ed.reconstruirEntidad(e);
        Ed.pintarArbol();
        Ed.guardarLocal();
        Ed.pintarInspector();
      };
      p.appendChild(fila(etiqueta, c, ayuda));
    };
    selComun(conCol, 'colision', 'Colisión', [['malla', 'Malla exacta (trimesh)'], ['caja', 'Caja envolvente'], ['ninguna', 'Sin colisión']]);
    selComun(lista.filter((e) => e.tipo !== 'inicio'), 'visible', 'Visible en juego', [['true', 'Sí'], ['false', 'No (muro invisible)']]);
    const prims = lista.filter((e) => S.PARAMS_PRIMITIVA[e.tipo]);
    if (prims.length) {
      const c = document.createElement('input');
      c.type = 'color';
      c.value = comun(prims, 'color') || '#ffffff';
      let enCurso = false;
      c.oninput = () => {
        if (!enCurso) { Ed.marcarCambio(); enCurso = true; }
        for (const e of prims) { e.color = c.value; Ed.reconstruirEntidad(e); }
      };
      c.onchange = () => { enCurso = false; Ed.guardarLocal(); };
      p.appendChild(fila('Color / tinte', c, `De las ${prims.length} primitiva(s) seleccionadas`));
    }

    botonera(p, [
      ['Enfocar (F)', Ed.enfocarSeleccion],
      ['📁 Agrupar en carpeta', Ed.agruparSeleccion, '', 'Ctrl+G · los mete en una carpeta nueva sin moverlos'],
      ['Duplicar', Ed.duplicarSeleccion, '', 'Ctrl+D'],
      ['Duplicar en fila…', Ed.duplicarEnFila],
      ['⬇ Al suelo', Ed.soltarAlSuelo, '', 'Fin · cada uno baja a lo que tenga debajo'],
      ['Copiar', () => Ed.copiarSeleccion(), '', 'Ctrl+C · luego Ctrl+V aquí o en otra escena'],
      ['Borrar', Ed.borrarSeleccion, 'peligro'],
    ]);
    nota(p, 'El gizmo mueve, gira y escala a todos juntos alrededor de su centro.');
  }

  /* ---------- Ventana con un formulario (para preguntas con varios datos) ----------
     const v = await Ed.dialogo('Título', esquema, valores, 'Aceptar');   → objeto con los valores, o null si se canceló */
  Ed.dialogo = function (textoTitulo, esquema, valores = {}, textoAceptar = 'Aceptar') {
    return new Promise((resolver) => {
      const datos = { ...F.valoresPorDefecto(esquema), ...valores };
      const fondo = document.createElement('div');
      fondo.className = 'dialogo-fondo';
      const caja = document.createElement('div');
      caja.className = 'dialogo dialogo-chico';
      const cab = document.createElement('div');
      cab.className = 'dialogo-cab';
      cab.innerHTML = `<b></b>`;
      cab.querySelector('b').textContent = textoTitulo;
      const cuerpo = document.createElement('div');
      cuerpo.className = 'dialogo-cuerpo';
      formulario(cuerpo, esquema, datos, () => {});
      const pie = document.createElement('div');
      pie.className = 'dialogo-pie';
      const cerrar = (v) => { fondo.remove(); window.removeEventListener('keydown', teclas, true); resolver(v); };
      const cancelar = document.createElement('button');
      cancelar.textContent = 'Cancelar';
      cancelar.onclick = () => cerrar(null);
      const aceptar = document.createElement('button');
      aceptar.className = 'primario';
      aceptar.textContent = textoAceptar;
      aceptar.onclick = () => {
        // por si el último número escrito aún no disparó "change"
        cuerpo.querySelectorAll('input').forEach((i) => i.dispatchEvent(new Event('change')));
        cerrar(datos);
      };
      const teclas = (e) => {
        if (e.key === 'Escape') { e.stopPropagation(); cerrar(null); }
        else if (e.key === 'Enter') { e.preventDefault(); e.stopPropagation(); aceptar.click(); }
      };
      window.addEventListener('keydown', teclas, true);
      pie.append(document.createElement('span'), cancelar, aceptar);
      pie.firstChild.style.flex = '1';
      caja.append(cab, cuerpo, pie);
      fondo.appendChild(caja);
      fondo.onclick = (e) => { if (e.target === fondo) cerrar(null); };
      document.body.appendChild(fondo);
      const primero = cuerpo.querySelector('input, select');
      if (primero) { primero.focus(); primero.select?.(); }
    });
  };

  function restablecerEntidad(ent) {
    if (!confirm(`¿Restablecer "${ent.nombre}" a sus valores por defecto?\n(Se conservan nombre, posición y jerarquía: la posición tiene su propio ↺. Se puede deshacer con Ctrl+Z.)`)) return;
    Ed.marcarCambio();
    const base = F.Escena.entidadNueva(ent.tipo);
    for (const k of ['colision', 'visible', 'color', 'textura', 'normal', 'fuerzaNormal', 'mosaico', 'material', 'params']) ent[k] = F.util.copiar(base[k]);
    if (ent.tipo === 'modelo') {
      const a = F.Assets.mapa.get(ent.asset);
      ent.colision = a && a.gltf && a.gltf.animations.length ? 'ninguna' : 'malla';
    }
    ent.rot = [0, 0, 0];
    ent.esc = base.esc.slice();
    // la salida conserva a dónde lleva; el resto vuelve a lo de serie
    if (ent.tipo === 'salida') ent.salida = { ...base.salida, destino: ent.salida.destino, llegada: ent.salida.llegada };
    Ed.reconstruirEntidad(ent);
    Ed.pintarArbol();
    Ed.pintarInspector();
    Ed.guardarLocal();
  }

  /* ---------- Materiales y texturas de un modelo (en el inspector de la entidad) ----------
     Por ahora solo cambiar la textura; el resto de opciones está en el inspector del archivo. */
  function pintarMaterialesModelo(p, a) {
    titulo(p, 'Materiales y texturas');
    nota(p, 'Cambiar una textura afecta a todas las copias de este modelo. Más opciones (transparencia, prioridad…) en su archivo.');
    F.Assets.materialesDe(a).forEach((m, i) => {
      const cfg = F.Assets.configMaterial(Ed.proyecto, a.id, i, m);
      const caja = document.createElement('div');
      caja.className = 'material-fila';
      const actual = m.map;
      const info = document.createElement('div');
      const nombre = document.createElement('b');
      nombre.textContent = m.name || `Material ${i + 1}`;
      const detalle = document.createElement('div');
      detalle.className = 'nota';
      const original = m.userData.original && m.userData.original.map;
      detalle.textContent = cfg.textura
        ? `Textura: ${F.Assets.mapa.get(cfg.textura)?.nombre || '?'}`
        : original && original.image ? `Textura del modelo · ${original.image.width}×${original.image.height}` : 'Sin textura (solo color)';
      const sel = controlEsquema({ t: 'asset', tipoAsset: 'textura', vacio: '(la del modelo)' }, cfg.textura || '', (v) => {
        const { map, normalMap, ...guardable } = cfg;
        guardable.textura = v;
        F.Assets.guardarConfigMaterial(Ed.proyecto, a, i, guardable);
        F.Assets.aplicarMaterialesAsset(Ed.proyecto, a);
        Ed.actualizarUsosModelo(a.id);
        Ed.guardarLocal();
        Ed.pintarInspector();
      });
      const vuelta = document.createElement('button');
      vuelta.className = 'revertir';
      vuelta.textContent = '↺';
      vuelta.title = 'Volver a la textura que trae el modelo';
      vuelta.style.visibility = cfg.textura ? 'visible' : 'hidden';
      vuelta.onclick = () => {
        const { map, normalMap, ...guardable } = F.Assets.configMaterial(Ed.proyecto, a.id, i, m);
        guardable.textura = '';
        F.Assets.guardarConfigMaterial(Ed.proyecto, a, i, guardable);
        F.Assets.aplicarMaterialesAsset(Ed.proyecto, a);
        Ed.actualizarUsosModelo(a.id);
        Ed.guardarLocal();
        Ed.pintarInspector();
      };
      const lineaSel = document.createElement('div');
      lineaSel.className = 'linea-sel';
      lineaSel.append(sel, vuelta);
      // Emite luz (fuego, lámparas…) también aquí, a la mano; el resto de opciones de luz está en el archivo
      const chkLuz = document.createElement('label');
      chkLuz.className = 'chk-luz';
      chkLuz.title = 'Cada fuego / lámpara hecho con este material se vuelve una luz. Color, fuerza y aura: en el archivo del modelo';
      const cb = document.createElement('input');
      cb.type = 'checkbox';
      cb.checked = !!cfg.luz;
      cb.onchange = () => {
        const { map, normalMap, ...guardable } = F.Assets.configMaterial(Ed.proyecto, a.id, i, m);
        guardable.luz = cb.checked;
        F.Assets.guardarConfigMaterial(Ed.proyecto, a, i, guardable);
        F.Assets.aplicarMaterialesAsset(Ed.proyecto, a);
        Ed.guardarLocal();
        repintarLuz();
      };
      chkLuz.append(cb, document.createTextNode(' 💡 Emite luz'));
      // 🌊 movimiento (río, mar, pasto, bandera…): también aquí, plegado; abierto si ya tiene alguno
      const mov = document.createElement('details');
      mov.className = 'mov-material';
      const hay = cfg.ondular || cfg.olas || cfg.viento || cfg.ondear || cfg.desplazX || cfg.desplazY;
      mov.open = !!hay;
      const sum = document.createElement('summary');
      sum.textContent = '🌊 Movimiento' + (hay ? ' · activo' : '');
      sum.style.cssText = 'cursor:pointer;margin-top:4px;user-select:none';
      mov.appendChild(sum);
      const { map: _m2, normalMap: _n2, ...orig2 } = m.userData.original || {};
      formulario(mov, [ESQUEMA_MATERIAL.find((d) => d.k === 'desplazX'), ESQUEMA_MATERIAL.find((d) => d.k === 'desplazY'), ...ESQUEMA_MOV], cfg, (k, v, definitivo) => {
        if (k === 'movAtajo') {
          if (v) guardarMaterial(a, i, m, { ...valoresAtajo(v), movAtajo: '' });
          Ed.guardarLocal();
          Ed.pintarInspector();
          return;
        }
        guardarMaterial(a, i, m, { [k]: v });
        if (definitivo) Ed.guardarLocal();
      }, { defectos: orig2 });
      info.append(nombre, detalle, lineaSel, chkLuz, mov);
      const repintarLuz = seccionLuzMaterial(info, a, i, m);
      caja.append(miniatura(actual, 44), info);
      p.appendChild(caja);
    });
  }

  /* =========================================================
     INSPECTOR DE ARCHIVO (≈ ver un recurso en Godot)
     ========================================================= */
  function tabla(cont, filas) {
    const t = document.createElement('table');
    t.className = 'tabla-info';
    for (const [k, v] of filas) {
      const tr = t.insertRow();
      tr.insertCell().textContent = k;
      tr.insertCell().innerHTML = v;
    }
    cont.appendChild(t);
    return t;
  }

  const kb = (bytes) => (bytes > 1048576 ? (bytes / 1048576).toFixed(2) + ' MB' : Math.max(1, Math.round(bytes / 1024)) + ' KB');
  Ed.kb = kb;

  function pintarInspectorAsset(id) {
    const p = $('panelInspector');
    p.innerHTML = '';
    const a = F.Assets.mapa.get(id);
    if (!a) { Ed.assetSeleccionado = null; return Ed.pintarInspector(); }
    const iconos = { modelo: '◆ Modelo', textura: '▣ Textura', audio: '♪ Audio', midi: '♬ MIDI', fuente: 'Aa Fuente' };
    titulo(p, iconos[a.tipo] || a.tipo);

    const nom = document.createElement('input');
    nom.value = a.nombre;
    nom.onchange = async () => {
      await F.Assets.renombrar(a.id, nom.value.trim() || a.nombre);
      Ed.pintarArchivos();
    };
    p.appendChild(fila('Nombre', nom));

    // Carpeta (solo organiza)
    const rutas = [];
    const recorrer = (padre, prefijo) => {
      for (const c of Ed.proyecto.carpetasArchivos.filter((x) => (x.padre || '') === padre)) {
        rutas.push([c.id, prefijo + c.nombre]);
        recorrer(c.id, prefijo + c.nombre + ' / ');
      }
    };
    recorrer('', '');
    const selCarpeta = controlEsquema({ t: 'sel', op: [['', '(raíz)'], ...rutas] }, a.carpeta || '', async (v) => {
      await F.Assets.moverACarpeta(a.id, v);
      Ed.pintarArchivos();
    });
    p.appendChild(fila('Carpeta', selCarpeta, 'Solo para organizar. También puedes arrastrarlo a una carpeta en la lista'));

    const filas = [['Tipo', a.tipo], ['Tamaño', kb(a.datos.byteLength)]];
    if (a.tipo === 'fuente') {
      const muestra = document.createElement('div');
      muestra.className = 'muestra-fuente';
      muestra.style.fontFamily = `'${a.familia}'`;
      muestra.contentEditable = 'true';
      muestra.spellcheck = false;
      muestra.title = 'Escribe aquí para probar la fuente';
      muestra.textContent = 'PRESS START · Vida 100 · ¡Misión cumplida! 0123456789';
      p.appendChild(muestra);
      filas.push(['Uso', 'Textos del HUD y menús (próximas versiones)']);
    }
    if (a.tipo === 'textura' && a.imagen) {
      const img = document.createElement('img');
      img.src = a.url;
      img.className = 'vista-previa';
      p.appendChild(img);
      filas.push(['Medidas', `${a.imagen.width} × ${a.imagen.height} px`]);
      if (a.imagen.width > 256 || a.imagen.height > 256) filas.push(['Consejo', 'Para estilo PS1, 64–256 px rinde y se ve mejor']);
    }
    if (a.tipo === 'audio' && a.duracion) filas.push(['Duración', `${a.duracion.toFixed(1)} s`]);
    if (a.tipo === 'audio') {
      const au = document.createElement('audio');
      au.controls = true;
      au.src = a.url;
      au.style.width = '100%';
      p.appendChild(au);
    }
    const d = F.Assets.desglose(a);
    if (d) {
      filas.push(['Triángulos', fmt(a.tris)], ['Mallas', d.mallas.length], ['Materiales', d.materiales.length],
        ['Texturas', d.texturas.length ? d.texturas.join(', ') : 'ninguna'], ['Huesos', d.huesos || 'no'],
        ['Animaciones', d.animaciones.length ? d.animaciones.map((x) => `${x.nombre} (${x.duracion.toFixed(1)}s)`).join('<br>') : 'no']);
    }
    tabla(p, filas);

    // Materiales del modelo: se pueden ajustar y valen para todas sus copias
    if (a.tipo === 'modelo' && a.gltf) {
      titulo(p, 'Materiales');
      nota(p, 'Los cambios valen para todas las copias de este modelo en todas las escenas.');
      const mats = F.Assets.materialesDe(a);
      mats.forEach((m, i) => {
        const cfg = F.Assets.configMaterial(Ed.proyecto, a.id, i, m);
        const caja = document.createElement('div');
        caja.className = 'modulo' + (mats.length === 1 ? ' abierto' : '');
        const cab = document.createElement('div');
        cab.className = 'modulo-cab';
        const flecha = document.createElement('span');
        flecha.className = 'flecha';
        flecha.textContent = mats.length === 1 ? '▼' : '▶';
        const nombre = document.createElement('b');
        nombre.textContent = m.name || `Material ${i + 1}`;
        const modo = document.createElement('span');
        modo.className = 'meta';
        modo.textContent = (F.Render.MODOS_MATERIAL.find((x) => x[0] === cfg.modo) || ['', ''])[1].split(' ')[0];
        cab.append(flecha, miniatura(m.map), nombre, modo);
        cab.onclick = () => {
          const abre = !caja.classList.contains('abierto');
          caja.classList.toggle('abierto', abre);
          flecha.textContent = abre ? '▼' : '▶';
        };
        const cuerpo = document.createElement('div');
        cuerpo.className = 'modulo-cuerpo';
        const { map: _m, normalMap: _n, ...original } = m.userData.original || {};
        formulario(cuerpo, ESQUEMA_MATERIAL_MODELO, cfg, (k, v, definitivo) => {
          if (k === 'movAtajo') {   // 🌊 atajo de movimiento: todos sus valores de una vez
            if (v) guardarMaterial(a, i, m, { ...valoresAtajo(v), movAtajo: '' });
            Ed.guardarLocal();
            pintarInspectorAsset(id);
            return;
          }
          guardarMaterial(a, i, m, { [k]: v });   // solo lo que cambió (la sección de luz guarda lo suyo aparte)
          if (k === 'modo') modo.textContent = (F.Render.MODOS_MATERIAL.find((x) => x[0] === v) || ['', ''])[1].split(' ')[0];
          if (definitivo) Ed.guardarLocal();
          if (k === 'luz') repintarLuz();
        }, { defectos: original });
        const repintarLuz = seccionLuzMaterial(cuerpo, a, i, m);
        if (cfg.luz) { caja.classList.add('abierto'); flecha.textContent = '▼'; }
        botonera(cuerpo, [['Como venía en el GLB', () => {
          F.Assets.borrarConfigMaterial(Ed.proyecto, a, i);
          F.Assets.aplicarMaterialesAsset(Ed.proyecto, a);
          Ed.actualizarUsosModelo(a.id);
          Ed.guardarLocal();
          pintarInspectorAsset(id);
        }]]);
        caja.append(cab, cuerpo);
        p.appendChild(caja);
      });
    }

    if (a.tipo === 'modelo' && a.gltf) {
      botonera(p, [['↺ Todos los materiales como en el GLB', () => {
        if (!confirm('¿Dejar todos los materiales de este modelo como venían en el GLB?')) return;
        delete Ed.proyecto.materiales[a.id];
        F.Assets.aplicarMaterialesAsset(Ed.proyecto, a);
        Ed.actualizarUsosModelo(a.id);
        Ed.guardarLocal();
        pintarInspectorAsset(id);
      }]]);
    }

    // Dónde se usa
    titulo(p, 'Usado en');
    const usos = Ed.usosDeAsset(a.id);
    if (!usos.length) nota(p, '<i>No se usa en ninguna parte.</i>');
    for (const u of usos) {
      const el = document.createElement('div');
      el.className = 'item';
      el.innerHTML = `<span class="nom">${u.texto}</span><span class="meta">${u.escena ? u.escena.nombre : ''}</span>`;
      if (u.ent) el.onclick = () => Ed.irAEntidad(u.escena.id, u.ent.id);
      p.appendChild(el);
    }

    const botones = [];
    if (a.tipo === 'modelo') botones.push(['＋ Añadir a la escena', () => Ed.agregarModelo(a.id)]);
    if (a.tipo === 'textura') botones.push(['Usar como cielo', () => {
      Ed.escena.ambiente.cieloTextura = a.id;
      Ed.aplicarAjustes();
      Ed.construirPanelEscena();
      Ed.guardarLocal();
      Ed.toast(`Cielo de <b>${Ed.escena.nombre}</b> con ${a.nombre}`);
    }]);
    if (Ed.Apps && Ed.Apps.datosForja(a)) {
      botones.unshift([Ed.Apps.textoEditar(a), () => Ed.Apps.editarEnApp(a.id), 'primario',
        'Abre la app que lo hizo con esto mismo; lo que cambies vuelve solo aquí']);
    }
    botones.push(['Reemplazar archivo…', () => Ed.reemplazarAsset(a.id), '', 'Cargar otro archivo en su lugar; todo lo que lo usa se actualiza']);
    botones.push(['Descargar', () => F.util.descargarBlob(new Blob([a.datos], { type: a.mime }), a.nombre)]);
    botones.push(['Quitar', () => Ed.borrarAsset(a.id), 'peligro']);
    botonera(p, botones);
  }

  /* 🗣 NPC: el diálogo en nodos (1, 2, 3…): cada nodo es lo que dice y sus respuestas; cada respuesta va a otro nodo
     o termina, y puede hacer acciones (las mismas de las palancas: abrir una puerta, dar un objeto con un canal…) */
  function pintarNpc(p, ent) {
    const n = ent.npc, TA = F.Tactico, repintar = () => { Ed.guardarLocal(); Ed.pintarInspector(); };
    formulario(p, [{ k: 'texto', t: 'texto', e: 'Texto del aviso' }, { k: 'color', t: 'color', e: 'Color (figura del motor)' },
      { k: 'modelo', t: 'asset', tipoAsset: 'modelo', e: 'Modelo', vacio: '(figura del motor)' }, { k: 'mirar', t: 'bool', e: 'Se gira hacia ti al hablar' },
      { k: 'retratoAuto', t: 'bool', e: 'Retrato automático (su cara)', ayuda: 'Una foto de la cabeza de su modelo (figura del motor, receta o GLB), hecha al hablar. Si pones una imagen abajo, manda la imagen' },
      { k: 'retrato', t: 'asset', tipoAsset: 'textura', e: 'Retrato (imagen)', vacio: '(sin imagen)', ayuda: 'Su cara en la caja del diálogo (cada diálogo puede llevar otra: expresiones)' },
      { k: 'ladoRetrato', t: 'sel', e: 'Retrato a la', op: [['izquierda', 'Izquierda'], ['derecha', 'Derecha']], si: (v) => !!v.retrato || v.retratoAuto }],
      n, (k, v, definitivo) => { if (definitivo) { if (k === 'color' || k === 'modelo') Ed.reconstruirEntidad(ent); Ed.guardarLocal(); } }, { defectos: TA.NPC, antes: () => Ed.marcarCambio() });
    nota(p, 'El nombre que sale en el diálogo es el de la entidad (arriba).');
    (n.nodos = n.nodos || []).forEach((nodo, i) => {
      titulo(p, `💬 Diálogo ${i + 1}${i === 0 ? ' (el primero)' : ''}`);
      formulario(p, [{ k: 'texto', t: 'textoLargo', e: 'Dice', filas: 3 }, { k: 'retrato', t: 'asset', tipoAsset: 'textura', e: 'Otro retrato', vacio: '(el del personaje)', ayuda: 'Para otra expresión en este diálogo (enfadado, sorprendido…)' }], nodo, (k, v, definitivo) => { if (definitivo) Ed.guardarLocal(); }, { antes: () => Ed.marcarCambio() });
      const opSig = [['', '⏹ Termina la conversación'], ...n.nodos.map((x, k) => [String(k), `→ Diálogo ${k + 1}: ${(x.texto || '').slice(0, 24)}`])];
      (nodo.opciones = nodo.opciones || []).forEach((o, k) => {
        const c = document.createElement('div');
        c.className = 'accion';
        formulario(c, [{ k: 'texto', t: 'texto', e: `Respuesta ${k + 1}` }, { k: 'siguiente', t: 'sel', e: 'Luego', op: opSig }], o,
          (kk, v, definitivo) => { if (definitivo) Ed.guardarLocal(); }, { antes: () => Ed.marcarCambio() });
        editarAcciones(c, ent, o, 'Al elegir esta respuesta (opcional):');
        botonera(c, [['Quitar respuesta', () => { Ed.marcarCambio(); nodo.opciones.splice(k, 1); repintar(); }, 'peligro']]);
        p.appendChild(c);
      });
      if (!nodo.opciones.length) nota(p, 'Sin respuestas: sale "Continuar" y termina.');
      botonera(p, [['＋ Respuesta', () => { Ed.marcarCambio(); nodo.opciones.push(TA.opcionNueva()); repintar(); }],
        ...(i > 0 ? [['Quitar diálogo', () => { Ed.marcarCambio(); n.nodos.splice(i, 1); repintar(); }, 'peligro']] : [])]);
    });
    botonera(p, [['＋ Diálogo', () => { Ed.marcarCambio(); n.nodos.push(TA.nodoNuevo({ texto: '' })); repintar(); }, 'primario']]);
  }

  /* 🏪 Tienda: título y artículos (qué, cuánto, precio, existencias) */
  function pintarTienda(p, ent) {
    const t = ent.tienda, P = Ed.proyecto, repintar = () => { Ed.guardarLocal(); Ed.pintarInspector(); };
    formulario(p, [{ k: 'titulo', t: 'texto', e: 'Título' }, { k: 'texto', t: 'texto', e: 'Texto del aviso' }, { k: 'color', t: 'color', e: 'Color del mostrador' }],
      t, (k, v, definitivo) => { if (definitivo) { if (k === 'color') Ed.reconstruirEntidad(ent); Ed.guardarLocal(); } }, { defectos: F.Tactico.TIENDA, antes: () => Ed.marcarCambio() });
    titulo(p, 'Artículos');
    const caja = document.createElement('div');
    caja.className = 'lista-acciones';
    (t.articulos = t.articulos || []).forEach((a, i) => {
      const c = document.createElement('div');
      c.className = 'accion';
      const esq = [{ k: 'que', t: 'sel', e: 'Vende', op: [['vida', '✚ Vida'], ['armadura', '⛨ Armadura'], ['municion', '▮ Munición'], ['arma', '🔫 Arma'], ['bateria', '🔋 Pilas'], ['objeto', '🎒 Objeto']] }];
      if (a.que === 'arma') esq.push({ k: 'ref', t: 'sel', e: 'Arma', op: [['', '(elige)'], ...(P.armas || []).map((x) => [x.id, x.nombre])] });
      if (a.que === 'municion') esq.push({ k: 'ref', t: 'sel', e: 'Munición', op: [['', '(elige)'], ...(P.municiones || []).map((x) => [x.id, x.nombre])] });
      if (a.que === 'objeto') esq.push({ k: 'ref', t: 'objeto', e: 'Objeto' });
      if (a.que !== 'arma') esq.push({ k: 'cantidad', t: 'num', e: 'Cantidad', paso: 1, min: 1 });
      esq.push({ k: 'precio', t: 'num', e: 'Precio', paso: 1, min: 0 },
        { k: 'divisa', t: 'sel', e: 'Se paga con', op: F.Divisas.lista(P).map((d) => [d.id, `${d.icono || ''} ${d.nombre}`.trim()]) }, { k: 'stock', t: 'num', e: 'Existencias (0 = sin fin)', paso: 1, min: 0 });
      formulario(c, esq, a, (k, v, definitivo) => { if (definitivo) { if (k === 'que') { a.ref = ''; repintar(); } else Ed.guardarLocal(); } }, { antes: () => Ed.marcarCambio() });
      if (['arma', 'municion', 'objeto'].includes(a.que) && !a.ref) nota(c, '⚠ Elige cuál.');
      botonera(c, [['Quitar', () => { Ed.marcarCambio(); t.articulos.splice(i, 1); repintar(); }, 'peligro']]);
      caja.appendChild(c);
    });
    p.appendChild(caja);
    botonera(p, [['＋ Artículo', () => { Ed.marcarCambio(); t.articulos.push(F.Tactico.articuloNuevo()); repintar(); }, 'primario']]);
    nota(p, 'Cada artículo se paga con su divisa: pon recogibles de tipo <b>Divisa</b> (o que los enemigos suelten "Moneda"). Las divisas se crean en Juego ▸ Objetos ▸ Divisas.');
  }

  /* ⭐ Misión del nivel: briefing, objetivos por estrella y pantalla de puntuación (motor/misiones.js) */
  function pintarMision(p) {
    const MS = F.Misiones, esc = Ed.escena;
    if (!esc.mision) esc.mision = F.util.copiar(MS.MISION);
    const m = esc.mision;
    const repintar = () => { Ed.guardarLocal(); Ed.construirPanelEscena(); };
    titulo(p, '⭐ Misión y estrellas');
    formulario(p, [
      { k: 'activa', t: 'bool', e: 'Este nivel es una misión', ayuda: 'Briefing al empezar, objetivos con estrellas (1-3) y pantalla de puntuación al salir' },
      { k: 'titulo', t: 'texto', e: 'Título', si: (v) => v.activa },
      { k: 'briefing', t: 'textoLargo', e: 'Briefing', filas: 4, si: (v) => v.activa, ayuda: 'Lo que se cuenta antes de empezar (situación, qué hay que hacer)' },
      { k: 'imagen', t: 'asset', tipoAsset: 'textura', e: 'Imagen del briefing', vacio: '(ninguna)', si: (v) => v.activa },
      { k: 'mostrarBriefing', t: 'bool', e: 'Pantalla de briefing al empezar', si: (v) => v.activa },
      { k: 'mostrarPuntuacion', t: 'bool', e: 'Pantalla de puntuación al salir', si: (v) => v.activa },
    ], m, (k, v, definitivo) => { if (definitivo) { if (k === 'activa') repintar(); else Ed.guardarLocal(); } }, { defectos: MS.MISION, antes: () => Ed.marcarCambio() });
    if (!m.activa) return;
    const ents = (t) => esc.entidades.filter((e) => e.tipo === t);
    const opEnt = (t, vacio) => { const L = ents(t); return [['', L.length ? vacio : '(no hay ninguno en este nivel)'], ...L.map((e) => [e.id, e.nombre])]; };
    const objs = Ed.proyecto.objetos || [];
    const opQue = [['todos', 'Todo lo que se recoge'], ['moneda', 'Monedas'], ['vida', 'Vida'], ['armadura', 'Armadura'], ['municion', 'Munición'], ['arma', 'Armas'], ['bateria', 'Pilas'], ['objeto', 'Objetos de la mochila (todos)'], ...objs.map((o) => ['obj:' + o.id, '🎒 ' + o.nombre])];
    const caja = document.createElement('div');
    caja.className = 'lista-acciones';
    (m.objetivos = m.objetivos || []).forEach((o, i) => {
      const t = document.createElement('div');
      t.className = 'accion';
      const esq = [
        { k: 'tipo', t: 'sel', e: 'Objetivo', op: MS.TIPOS },
        { k: 'estrella', t: 'sel', e: 'Estrella', op: [[1, '★ (la primera)'], [2, '★★'], [3, '★★★']] },
      ];
      if (o.tipo === 'salir') esq.push({ k: 'a', t: 'sel', e: 'Salida', op: opEnt('salida', '(cualquier salida)') });
      if (o.tipo === 'matarJefe') esq.push({ k: 'a', t: 'sel', e: 'Enemigo', op: opEnt('enemigo', '(elige cuál)') });
      if (o.tipo === 'zona') esq.push({ k: 'a', t: 'sel', e: 'Disparador', op: opEnt('disparador', '(elige cuál)') });
      if (o.tipo === 'tiempo') esq.push({ k: 'segundos', t: 'num', e: 'Segundos', paso: 10, min: 5 });
      if (o.tipo === 'recoger') esq.push({ k: 'que', t: 'sel', e: 'Qué', op: opQue });
      if (o.tipo === 'tener') esq.push({ k: 'a', t: 'sel', e: 'Objeto', op: [['', objs.length ? '(elige cuál)' : '(no hay objetos en Juego ▸ Objetos)'], ...objs.map((x) => [x.id, x.nombre])] }, { k: 'cantidad', t: 'num', e: 'Cantidad', paso: 1, min: 1 });
      if (o.tipo === 'ejecutar') esq.push({ k: 'cantidad', t: 'num', e: 'Cantidad', paso: 1, min: 1 });
      if (o.tipo === 'canal') esq.push({ k: 'canal', t: 'texto', e: 'Canal', ayuda: 'Se cumple cuando una palanca, disparador o bomba "avisa a un canal" con este nombre' });
      esq.push({ k: 'texto', t: 'texto', e: 'Texto (opcional)', ayuda: 'Cómo se lee en la lista. Vacío = el del motor' });
      formulario(t, esq, o, (k, v, definitivo) => { if (definitivo) { if (k === 'tipo') { o.a = ''; repintar(); } else Ed.guardarLocal(); } }, { antes: () => Ed.marcarCambio() });
      if (['matarJefe', 'zona', 'tener'].includes(o.tipo) && !o.a) nota(t, '⚠ Elige cuál.');
      if (o.tipo === 'canal' && !o.canal) nota(t, '⚠ Escribe el nombre del canal.');
      botonera(t, [['Quitar', () => { Ed.marcarCambio(); m.objetivos.splice(i, 1); repintar(); }, 'peligro']]);
      caja.appendChild(t);
    });
    p.appendChild(caja);
    botonera(p, [['＋ Objetivo', () => { Ed.marcarCambio(); m.objetivos.push(MS.objetivoNuevo({ tipo: m.objetivos.length ? 'matarTodos' : 'salir', estrella: Math.min(3, m.objetivos.length + 1) })); repintar(); }, 'primario']]);
    const por = [1, 2, 3].map((k) => m.objetivos.filter((o) => (o.estrella || 1) === k).length);
    nota(p, `Cada estrella se gana sola al cumplir todos sus objetivos: ★ (${por[0]}) · ★★ (${por[1]}) · ★★★ (${por[2]}). Fallar una no quita las otras.` + (m.objetivos.length ? '' : ' ⚠ Añade al menos un objetivo.') + (por.some((x) => !x) ? ' Una estrella sin objetivos se gana al acabar el nivel.' : ''));
  }

  /* =========================================================
     PANEL ESCENA (ambiente: cielo, niebla, luz)
     ========================================================= */
  /* ⚠ 📼 por qué no se ven los efectos en el editor (regla: el Inspector avisa) */
  function avisoEfectos(p) {
    const aj = Ed.proyecto.ajustes, amb = Ed.escena.ambiente;
    const fuente = amb.fxPropio ? amb : aj;
    if (!F.Efectos.hayFx(fuente)) return;
    const avisos = [];
    if (!aj.fxEnEditor && !aj.vistaRetroEditor) avisos.push('Los efectos de cámara solo se ven al jugar: enciende <b>Vista del editor ▸ Efectos de cámara en editor</b> para verlos aquí');
    if (!F.Efectos.efectivos(aj, amb)) avisos.push('El estilo está puesto pero todos sus controles están en 0: no se verá nada');
    if (amb.fxPropio && p.id === 'panelProyecto') avisos.push(`El nivel "${Ed.escena.nombre}" usa sus efectos propios (Escena ▸ 📼 Efectos de cámara): ahí no se ven los de aquí`);
    for (const a of avisos) nota(p, '⚠ ' + a);
  }

  Ed.construirPanelEscena = function () {
    const p = $('panelEscena');
    p.innerHTML = '';
    cabeceraPanel(p, 'Ambiente de la escena', () => {
      if (!confirm(`¿Restablecer cielo, niebla y luz de "${Ed.escena.nombre}" a los valores por defecto?`)) return;
      Ed.escena.ambiente = F.valoresPorDefecto(F.Escena.ESQUEMA_AMBIENTE);
      Ed.aplicarAjustes();
      Ed.construirPanelEscena();
      Ed.guardarLocal();
    }, 'Cielo, niebla, distancia de dibujado y luz de esta escena');
    const nom = document.createElement('input');
    nom.value = Ed.escena.nombre;
    nom.onchange = () => { Ed.escena.nombre = nom.value || 'Escena'; Ed.pintarSelectorEscenas(); Ed.guardarLocal(); };
    p.appendChild(fila('Nombre', nom));
    // 🚪 Nivel: memoria al volver y música (motor/niveles.js)
    if (!Ed.escena.nivel) Ed.escena.nivel = { ...F.Niveles.NIVEL };
    formulario(p, F.Niveles.ESQUEMA_NIVEL, Ed.escena.nivel, (k, v, definitivo) => { if (definitivo) Ed.guardarLocal(); });
    // 🎵 probar la música del nivel aquí mismo (para ajustar el bucle: "▶ Probar el final" salta 4 s antes de que vuelva)
    if (Ed.escena.nivel && Ed.escena.nivel.musica) {
      const n = Ed.escena.nivel;
      if (Ed.ondaMusica) Ed.ondaMusica(p, n.musica, n, { kIni: 'musicaInicio', kFin: 'musicaFin', volumen: () => n.musicaVolumen ?? 1,
        alCambiar: (fin) => { if (fin) Ed.guardarLocal(); }, alSoltar: () => { const sc = [p, p.parentElement].map((x) => x && x.scrollTop); Ed.construirPanelEscena(); [p, p.parentElement].forEach((x, i) => { if (x) x.scrollTop = sc[i]; }); } });
    }
    pintarMision(p);
    if (Ed.pintarCinesEscena) Ed.pintarCinesEscena(p);   // 🎬 editor/taller-cine.js
    const salidas = Ed.escena.entidades.filter((e) => e.tipo === 'salida');
    const llegan = [];
    for (const esc of Ed.proyecto.escenas) for (const e of esc.entidades) if (e.tipo === 'salida' && e.salida && e.salida.destino === Ed.escena.id && esc !== Ed.escena) llegan.push({ escena: esc, ent: e });
    if (salidas.length) enlaces(p, 'Salidas de este nivel:', salidas.map((ent) => ({ escena: Ed.escena, ent })));
    if (llegan.length) enlaces(p, 'Llegan desde:', llegan);
    const amb = Ed.escena.ambiente;
    formulario(p, F.Escena.ESQUEMA_AMBIENTE, amb, (k, v, definitivo) => {
      // 📼 al encender los efectos propios empiezan copiando los del proyecto; un estilo rellena sus controles
      const aj = Ed.proyecto.ajustes;
      if (k === 'fxPropio' && v) for (const c of F.Efectos.CLAVES) if (aj[c] !== undefined) amb[c] = F.util.copiar(aj[c]);
      if (k === 'fxEstilo' && definitivo) F.Efectos.aplicarEstilo(amb, v);
      Ed.aplicarAjustes();
      if (definitivo) Ed.guardarLocal();
      if ((k === 'fxPropio' || k === 'fxEstilo') && definitivo) { const y = p.scrollTop; Ed.construirPanelEscena(); p.scrollTop = y; }
    }, { defectos: { ...F.valoresPorDefecto(F.Escena.ESQUEMA_AMBIENTE), ...F.Efectos.defectosDe(amb.fxEstilo) } });
    avisoEfectos(p);
  };

  /* =========================================================
     PANEL JUGADOR (módulos activables)
     ========================================================= */
  const abiertos = new Set(['camara', 'movimiento']);
  // Módulos del jugador por temas (para no ver 16 cajas seguidas)
  const CATEGORIAS = [
    ['Lo básico', 'Moverse, mirar y saltar', ['cuerpo', 'camara', 'movimiento', 'sprint', 'salto', 'gravedad']],
    ['Interacción con el mundo', 'Usar puertas, leer notas, recoger objetos, mochila', ['interactuar', 'inventario', 'nadar']],
    ['Movimientos extra', 'Agacharse, esquivar…', ['agachar', 'esquiva']],
    ['Vida y combate', 'Salud, armadura, armas, combate, ataque especial', ['salud', 'combate', 'armas', 'especial']],
    ['Aspecto y sensación', 'Modelo, sombra, pasos y cámara viva', ['modelo', 'sombra', 'pasos', 'balanceo']],
  ];
  // Ajustes finos que el modo Sencillo esconde ('#Grupo' = el grupo entero)
  const AVANZADO = {
    cuerpo: ['radio', 'escalon', 'pendienteMax'],
    camara: ['sensMando', 'invertirY', 'alturaTps', 'hombro'],
    movimiento: ['multAtras', 'aceleracion', 'controlAire'],
    sprint: ['soloAdelante'],
    salto: ['coyote', 'bufer', 'alturaVariable', 'corte'],
    gravedad: ['multCaida', 'velMaxCaida'],
    agachar: ['suave', 'saltar'],
    esquiva: ['duracion', 'espera', 'enAire', 'subeFov'],
    salud: ['escudoTraspasa', 'invencible', 'esquivaInvencible', 'regenEspera', 'regenHasta', 'regenArmEspera', 'sonidoRecarga',
      'sonidoEscudoRoto', 'alturaSegura', 'danoPorMetro', 'flash', 'fundido', 'sonidoDano', 'sonidoMuerte'],
    armas: ['armaEnTps', '#Balanceo del arma (1ª persona)'],
    interactuar: ['cerrarCon'],
    modelo: ['fundido'],
    sombra: ['encoger', 'alturaMax'],
    pasos: ['variar', 'ritmoCaminar', 'ritmoCorrer', 'volCorrer'],
    balanceo: ['frecuencia', 'multCorrer', '#Ligero', '#Con inercia'],
  };
  // Lo mismo para Ajustes del proyecto y el ambiente de la escena
  (function marcarAvanzados() {
    const marcar = (esq, claves) => { for (const d of esq) if (claves.includes(d.k) || (d.grupo && claves.includes('#' + d.grupo)) || (d.k && d.k.startsWith('tb_') && claves.includes('tb_'))) d.av = true; };
    marcar(F.Escena.ESQUEMA_RENDER, ['afin', 'dither', 'distanciaSombras', 'halos', 'maxLuces', 'tb_', '#Vista del editor']);
    marcar(F.Escena.ESQUEMA_AMBIENTE, ['cieloAlturaHorizonte', 'cieloModo', 'cieloEscalaX', 'cieloEscalaY', 'cieloVelX', 'cieloVelY',
      'nieblaDelCielo', 'nieblaVertice', 'nieblaPasos', 'recortarEnNiebla', 'solSombra']);
    marcar(F.Escena.ESQUEMA_HUD, ['margen', 'sombra', 'iconoMunicion', 'tamMira']);
    marcar(F.Escena.ESQUEMA_MUNICION, ['color']);
  })();
  Ed.construirPanelJugador = function () {
    const p = $('panelJugador');
    p.innerHTML = '';
    nota(p, 'Cada módulo es un archivo en <b>jugador/modulos/</b>. Actívalos o desactívalos y ajusta sus valores; se notan al pulsar ▶ Jugar.');
    p.insertBefore(cabeceraPanel(document.createElement('div'), 'Módulos del jugador', () => {
      if (!confirm('¿Restablecer TODOS los módulos del jugador (activos y valores) a los de por defecto?')) return;
      Ed.proyecto.jugador = F.Escena.jugadorPorDefecto();
      Ed.guardarLocal();
      Ed.refrescarMarcadorInicio();
      Ed.construirPanelJugador();
    }, 'Todos los módulos. Cada módulo también tiene su propio botón dentro'), p.firstChild);
    const cfg = Ed.proyecto.jugador.modulos;
    const todos = F.modulosOrdenados();
    const vistos = new Set();
    const grupos = CATEGORIAS.map(([titulo, ayuda, nombres]) => {
      const ms = nombres.map((n) => todos.find((m) => m.nombre === n)).filter(Boolean);
      ms.forEach((m) => vistos.add(m.nombre));
      return [titulo, ayuda, ms];
    });
    const resto = todos.filter((m) => !vistos.has(m.nombre));
    if (resto.length) grupos.push(['Otros', 'Módulos nuevos o tuyos', resto]);
    for (const [tituloCat, ayudaCat, ms] of grupos) {
      if (!ms.length) continue;
      const h = titulo(p, tituloCat);
      h.className = 'cat-modulos';
      if (ayudaCat) h.title = ayudaCat;
    for (const m of ms) {
      const valores = cfg[m.nombre] || (cfg[m.nombre] = { activo: true, ...F.valoresPorDefecto(m.props) });
      const caja = document.createElement('div');
      caja.className = 'modulo' + (abiertos.has(m.nombre) ? ' abierto' : '') + (m.obligatorio || valores.activo ? '' : ' apagado');
      const cab = document.createElement('div');
      cab.className = 'modulo-cab';
      cab.title = m.descripcion || '';
      const flecha = document.createElement('span');
      flecha.className = 'flecha';
      flecha.textContent = abiertos.has(m.nombre) ? '▼' : '▶';
      cab.appendChild(flecha);
      if (m.obligatorio) {
        const fijo = document.createElement('span');
        fijo.className = 'fijo';
        fijo.textContent = '●';
        fijo.title = 'Siempre activo';
        cab.appendChild(fijo);
      } else {
        const chk = document.createElement('input');
        chk.type = 'checkbox';
        chk.checked = !!valores.activo;
        chk.title = 'Activar / desactivar módulo';
        chk.onclick = (e) => e.stopPropagation();
        chk.onchange = () => { valores.activo = chk.checked; caja.classList.toggle('apagado', !chk.checked); Ed.guardarLocal(); };
        cab.appendChild(chk);
      }
      const b = document.createElement('b');
      b.textContent = m.etiqueta;
      cab.appendChild(b);
      cab.onclick = () => {
        const abre = !caja.classList.contains('abierto');
        caja.classList.toggle('abierto', abre);
        flecha.textContent = abre ? '▼' : '▶';
        if (abre) abiertos.add(m.nombre); else abiertos.delete(m.nombre);
      };
      const cuerpo = document.createElement('div');
      cuerpo.className = 'modulo-cuerpo';
      if (m.descripcion) nota(cuerpo, m.descripcion);
      const av = AVANZADO[m.nombre] || [];
      const esq = m.props.map((d) => (av.includes(d.k) || (d.grupo && av.includes('#' + d.grupo)) ? { ...d, av: true } : d));
      formulario(cuerpo, esq, valores, (k, v, definitivo) => {
        if (definitivo) Ed.guardarLocal();
        if (m.nombre === 'cuerpo' || m.nombre === 'modelo') Ed.refrescarMarcadorInicio();
        // el módulo puede cambiar otros valores (p. ej. Combate ▸ Estilo pone los suyos): se repinta el panel
        if (m.alCambiar && m.alCambiar(k, v, valores)) { Ed.guardarLocal(); Ed.construirPanelJugador(); }
      });
      if (m.nombre === 'salud' && Ed.formVidas) Ed.formVidas(cuerpo, () => Ed.construirPanelJugador());
      botonera(cuerpo, [['↺ Valores por defecto', () => {
        cfg[m.nombre] = { activo: valores.activo, ...F.valoresPorDefecto(m.props) };
        Ed.guardarLocal();
        Ed.construirPanelJugador();
      }]]);
      caja.append(cab, cuerpo);
      p.appendChild(caja);
    }
    }
    if (Ed.modoSencillo) nota(p, 'Modo <b>Sencillo</b>: se esconden los ajustes finos. Cámbialo arriba (<b>Completo</b>) para verlo todo.');
  };

  /* =========================================================
     PANEL PROYECTO
     ========================================================= */
  Ed.construirPanelProyecto = function () {
    const p = $('panelProyecto');
    p.innerHTML = '';
    cabeceraPanel(p, 'Ajustes del juego', () => {
      if (!confirm('¿Restablecer los ajustes de render retro y de vista del editor?')) return;
      Ed.proyecto.ajustes = F.valoresPorDefecto(F.Escena.ESQUEMA_RENDER);
      Ed.aplicarAjustes();
      Ed.construirPanelProyecto();
      Ed.guardarLocal();
    }, 'Resolución, temblor, textura afín, dither, filtro y vista del editor (no toca escenas ni jugador)');
    Ed.titulo(p, '🎮 Juego');
    const nom = document.createElement('input');
    nom.value = Ed.proyecto.nombre;
    nom.onchange = () => { Ed.proyecto.nombre = nom.value || 'Mi juego'; Ed.guardarLocal(); Ed.pintarBarraProyecto && Ed.pintarBarraProyecto(); };
    p.appendChild(fila('Nombre del juego', nom));
    const ini = controlEsquema({ t: 'sel', op: Ed.proyecto.escenas.map((s) => [s.id, s.nombre]) }, Ed.proyecto.escenaInicial, (v) => {
      Ed.proyecto.escenaInicial = v;
      Ed.guardarLocal();
    });
    p.appendChild(fila('Escena inicial', ini, 'La primera que se juega en el juego exportado'));
    // controles táctiles con lo del juego; el resto es imagen y rendimiento
    const E = F.Escena.ESQUEMA_RENDER, it = E.findIndex((d) => d.grupo === 'Controles táctiles');
    let fin = E.findIndex((d, i) => i > it && d.grupo); if (fin < 0) fin = E.length;
    const aj = Ed.proyecto.ajustes;
    const alCambiar = (k, v, definitivo) => {
      if (k === 'fxEstilo' && definitivo) F.Efectos.aplicarEstilo(aj, v);   // 📼 el estilo rellena sus controles
      Ed.aplicarAjustes();
      if (definitivo) Ed.guardarLocal();
      if (k === 'fxEstilo' && definitivo) { const y = p.scrollTop; Ed.construirPanelProyecto(); p.scrollTop = y; }
    };
    if (it >= 0) formulario(p, E.slice(it, fin), aj, alCambiar);
    Ed.titulo(p, '🖥 Imagen y rendimiento');
    // el ↺ de cada efecto vuelve al valor del estilo elegido
    formulario(p, it >= 0 ? [...E.slice(0, it), ...E.slice(fin)] : E, aj, alCambiar,
      { defectos: { ...F.valoresPorDefecto(E), ...F.Efectos.defectosDe(aj.fxEstilo) } });
    avisoEfectos(p);
  };
})(window.FORJA);
