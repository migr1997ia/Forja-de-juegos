/* =========================================================
   EDITOR · MENÚ SUPERIOR
   Archivo · Editar · Escena · Ver · Ayuda (como en Godot / cualquier programa).
   Cada opción llama a una función del editor; aquí no hay lógica propia,
   así que añadir una opción nueva es añadir una línea en MENUS.
   ========================================================= */
(function (F) {
  'use strict';
  const Ed = F.Editor;
  const $ = (id) => document.getElementById(id);
  const clic = (id) => () => $(id) && $(id).click();
  const haySel = () => Ed.seleccionados.size > 0;
  const libre = () => !Ed.jugando;

  /* { t: texto, a: atajo (solo se muestra), fn: acción, si: () => habilitado, marca: () => casilla marcada }  ·  '-' = separador */
  const MENUS = [
    ['Archivo', [
      { t: '📂 Proyectos…', fn: () => Ed.Proyectos.abrirDialogo() },
      { t: '＋ Nuevo proyecto…', fn: clic('dlgNuevo') },
      { t: '📂 Abrir carpeta de proyecto…', fn: clic('dlgAbrirCarpeta') },
      '-',
      { t: '💾 Guardar', a: 'Ctrl+S', fn: () => Ed.Proyectos.guardar() },
      { t: 'Guardar copia como…', fn: clic('dlgGuardarComo') },
      { t: 'Guardar archivo .forja.json…', fn: clic('dlgExportar') },
      { t: 'Importar .forja.json…', fn: clic('dlgImportar') },
      '-',
      { t: '＋ Importar archivos (GLB, texturas, audio, fuentes)…', fn: clic('btnImportar') },
      { t: '＋ Cargar app HTML…', fn: clic('btnCargarApp') },
      '-',
      { t: 'Exportar juego (itch.io)…', fn: () => Ed.exportarJuego() },
    ]],
    ['Editar', [
      { t: 'Deshacer', a: 'Ctrl+Z', fn: () => Ed.deshacer(), si: libre },
      { t: 'Rehacer', a: 'Ctrl+Y', fn: () => Ed.rehacer(), si: libre },
      '-',
      { t: 'Cortar', a: 'Ctrl+X', fn: () => Ed.cortarSeleccion(), si: haySel },
      { t: 'Copiar', a: 'Ctrl+C', fn: () => Ed.copiarSeleccion(), si: haySel },
      { t: 'Pegar', a: 'Ctrl+V', fn: () => Ed.pegar(), si: () => Ed.hayPortapapeles() && libre() },
      { t: 'Duplicar', a: 'Ctrl+D', fn: () => Ed.duplicarSeleccion(), si: haySel },
      { t: 'Duplicar en fila…', fn: () => Ed.duplicarEnFila(), si: haySel },
      '-',
      { t: 'Seleccionar todo', a: 'Ctrl+A', fn: () => Ed.seleccionarTodo(), si: libre },
      { t: 'Quitar selección', a: 'Esc', fn: () => Ed.seleccionar(null), si: haySel },
      { t: '📁 Agrupar en carpeta', a: 'Ctrl+G', fn: () => Ed.agruparSeleccion(), si: haySel },
      { t: '⬇ Al suelo', a: 'Fin', fn: () => Ed.soltarAlSuelo(), si: haySel },
      { t: 'Borrar', a: 'Supr', fn: () => Ed.borrarSeleccion(), si: haySel },
    ]],
    ['Escena', [
      { t: '📁 Añadir carpeta', fn: () => Ed.agregarEntidad('carpeta'), si: libre },
      { t: '⬛ Añadir cubo', fn: () => Ed.agregarEntidad('cubo'), si: libre },
      { t: '▭ Añadir suelo', fn: () => Ed.agregarEntidad('suelo'), si: libre },
      { t: '◢ Añadir rampa', fn: () => Ed.agregarEntidad('rampa'), si: libre },
      { t: '▤ Añadir escalera', fn: () => Ed.agregarEntidad('escalera'), si: libre },
      { t: '🪜 Añadir escalera de mano', fn: () => Ed.agregarEntidad('escala'), si: libre },
      { t: '🛢 Añadir barril explosivo', fn: () => Ed.agregarEntidad('barril'), si: libre },
      { t: '📷 Añadir cámara fija', fn: () => Ed.agregarEntidad('camara'), si: libre },
      { t: '🔊 Añadir sonido', fn: () => Ed.agregarEntidad('sonido'), si: libre },
      { t: '✨ Añadir partículas', fn: () => Ed.agregarEntidad('particulas'), si: libre },
      { t: '🧍 Añadir rehén', fn: () => Ed.agregarEntidad('rehen'), si: libre },
      { t: '💣 Añadir bomba', fn: () => Ed.agregarEntidad('bomba'), si: libre },
      { t: '🚧 Añadir puerta táctica', fn: () => Ed.agregarEntidad('brecha'), si: libre },
      { t: '🏪 Añadir tienda', fn: () => Ed.agregarEntidad('tienda'), si: libre },
      { t: '🗣 Añadir personaje con diálogo', fn: () => Ed.agregarEntidad('npc'), si: libre },
      { t: '⚑ Añadir inicio / punto de llegada', fn: () => Ed.agregarEntidad('inicio'), si: libre },
      { t: '💡 Añadir luz', fn: () => Ed.agregarEntidad('luz'), si: libre },
      { t: '✚ Añadir recogible', fn: () => Ed.agregarEntidad('recogible'), si: libre },
      { t: '☠ Añadir enemigo', fn: () => Ed.agregarEntidad('enemigo'), si: libre },
      { t: '🥚 Añadir aparecedor (zona / oleadas)', fn: () => Ed.agregarEntidad('aparecedor'), si: libre },
      { t: '📍 Añadir punto de ruta', fn: () => Ed.agregarEntidad('punto'), si: libre },
      { t: '📌 Añadir marcador (brújula)', fn: () => Ed.agregarEntidad('marcador'), si: libre },
      { t: '💧 Añadir agua', fn: () => Ed.agregarEntidad('agua'), si: libre },
      { t: '📦 Añadir baúl', fn: () => Ed.agregarEntidad('baul'), si: libre },
      { t: '🔒 Añadir puerta', fn: () => Ed.agregarEntidad('puerta'), si: libre },
      { t: '🕹 Añadir palanca / botón', fn: () => Ed.agregarEntidad('palanca'), si: libre },
      { t: '⬚ Añadir disparador (zona)', fn: () => Ed.agregarEntidad('disparador'), si: libre },
      { t: '🏺 Añadir pedestal (objeto clave)', fn: () => Ed.agregarEntidad('pedestal'), si: libre },
      { t: '⇅ Añadir plataforma / elevador', fn: () => Ed.agregarEntidad('plataforma'), si: libre },
      { t: '⚠ Añadir trampa', fn: () => Ed.agregarEntidad('trampa'), si: libre },
      { t: '⚙ Añadir condición (puzle)', fn: () => Ed.agregarEntidad('condicion'), si: libre },
      { t: '🚪 Añadir salida a otro nivel', fn: () => Ed.agregarEntidad('salida'), si: libre },
      { t: '💾 Añadir punto de guardado', fn: () => Ed.agregarEntidad('guardado'), si: libre },
      { t: '🧱 Añadir objeto movible', fn: () => Ed.agregarEntidad('empujable'), si: libre },
      { t: '🐎 Añadir montable (vehículo)', fn: () => Ed.agregarEntidad('montable'), si: libre },
      '-',
      { t: '＋ Nueva escena…', fn: () => Ed.escenaNueva() },
      { t: '✎ Renombrar escena…', fn: () => Ed.escenaRenombrar() },
      { t: '⧉ Duplicar escena', fn: () => Ed.escenaDuplicar() },
      { t: '✕ Borrar escena…', fn: () => Ed.escenaBorrar() },
      '-',
      { t: '▶ Jugar esta escena', a: 'P', fn: () => (Ed.jugando ? Ed.detenerJuego() : Ed.iniciarJuego()) },
      { t: '▶ Probar con menús (juego completo)', fn: () => Ed.probarMenus('portada'), si: libre },
    ]],
    ['Ver', [
      { t: 'Perspectiva', a: 'Num 5', fn: () => Ed.ponerVista('persp'), marca: () => Ed.vistaActual() === 'persp', si: libre },
      { t: 'Superior', a: 'Num 7', fn: () => Ed.ponerVista('superior'), marca: () => Ed.vistaActual() === 'superior', si: libre },
      { t: 'Frontal', a: 'Num 1', fn: () => Ed.ponerVista('frontal'), marca: () => Ed.vistaActual() === 'frontal', si: libre },
      { t: 'Lateral', a: 'Num 3', fn: () => Ed.ponerVista('lateral'), marca: () => Ed.vistaActual() === 'lateral', si: libre },
      '-',
      { t: '💡 Luces y sombras (del juego)', a: 'L', fn: () => Ed.alternarLuces(), marca: () => !!Ed.proyecto.ajustes.lucesExtra },
      { t: 'Ver colisiones', a: 'C', fn: () => Ed.Colisiones.alternar(), marca: () => Ed.Colisiones.visible() },
      { t: 'Gizmo en espacio local', a: 'T', fn: () => Ed.alternarEspacio(), marca: () => $('btnEspacio').classList.contains('activo') },
      { t: 'Ajuste a rejilla (snap)', a: 'G', fn: () => Ed.alternarSnap(), marca: () => $('btnSnap').classList.contains('activo') },
      { t: 'Enfocar selección', a: 'F', fn: () => Ed.enfocarSeleccion(), si: haySel },
      '-',
      { t: 'Retro en el editor', fn: () => alternarAjuste('vistaRetroEditor'), marca: () => !!Ed.proyecto.ajustes.vistaRetroEditor },
      { t: 'Niebla en el editor', fn: () => alternarAjuste('nieblaEditor'), marca: () => !!Ed.proyecto.ajustes.nieblaEditor },
      { t: 'Pantalla completa del visor', fn: clic('btnPantalla') },
    ]],
    ['Ayuda', [
      { t: '⌨ Atajos de teclado y ratón', a: 'F1', fn: () => mostrarAtajos() },
      { t: 'Acerca de Forja de Juegos', fn: () => acercaDe() },
    ]],
  ];

  function alternarAjuste(k) {
    Ed.proyecto.ajustes[k] = !Ed.proyecto.ajustes[k];
    Ed.aplicarAjustes();
    Ed.construirPanelProyecto();
    Ed.guardarLocal();
  }

  /* ---------- Pintar la barra y los desplegables ---------- */
  const barra = $('menuSuperior');
  let abierto = null;   // { boton, caja }

  function cerrar() {
    if (!abierto) return;
    abierto.caja.remove();
    abierto.boton.classList.remove('abierto');
    abierto = null;
  }

  function abrir(boton, items) {
    cerrar();
    const caja = document.createElement('div');
    caja.className = 'menu-desplegable';
    for (const it of items) {
      if (it === '-') {
        const sep = document.createElement('div');
        sep.className = 'menu-sep';
        caja.appendChild(sep);
        continue;
      }
      const b = document.createElement('button');
      const ok = !it.si || it.si();
      b.disabled = !ok;
      const marca = it.marca ? (it.marca() ? '✓' : '') : '';
      b.innerHTML = `<span class="menu-marca">${marca}</span><span class="menu-texto"></span><span class="menu-atajo">${it.a || ''}</span>`;
      b.querySelector('.menu-texto').textContent = it.t;
      b.onclick = () => { cerrar(); it.fn(); };
      caja.appendChild(b);
    }
    const r = boton.getBoundingClientRect();
    caja.style.left = r.left + 'px';
    caja.style.top = r.bottom + 'px';
    document.body.appendChild(caja);
    boton.classList.add('abierto');
    abierto = { boton, caja };
  }

  for (const [nombre, items] of MENUS) {
    const b = document.createElement('button');
    b.className = 'menu-boton';
    b.textContent = nombre;
    b.onclick = (e) => {
      e.stopPropagation();
      if (abierto && abierto.boton === b) cerrar();
      else abrir(b, items);
    };
    // con un menú abierto, pasar por encima de otro lo abre (como en cualquier programa)
    b.onmouseenter = () => { if (abierto && abierto.boton !== b) abrir(b, items); };
    barra.appendChild(b);
  }
  document.addEventListener('pointerdown', (e) => {
    if (abierto && !abierto.caja.contains(e.target) && !barra.contains(e.target)) cerrar();
  });
  window.addEventListener('keydown', (e) => {
    if (e.key === 'Escape' && abierto) { cerrar(); e.stopPropagation(); }
    if (e.key === 'F1' && !Ed.jugando) { e.preventDefault(); mostrarAtajos(); }
  }, true);
  window.addEventListener('blur', cerrar);

  /* ---------- Ayuda ---------- */
  const ATAJOS = [
    ['Visor', [
      ['Clic izquierdo', 'Seleccionar'],
      ['Ctrl / Shift + clic', 'Añadir o quitar de la selección'],
      ['Shift + arrastrar', 'Seleccionar con rectángulo (Ctrl + Shift = sumar)'],
      ['Arrastrar con clic izq.', 'Girar la cámara (en vistas orto: desplazar)'],
      ['Rueda / rueda pulsada', 'Zoom / desplazar'],
      ['Clic derecho + WASD', 'Volar (Q/E bajar/subir, Shift rápido, rueda = velocidad)'],
      ['Num 7 · 1 · 3', 'Vista superior · frontal · lateral (otra vez = perspectiva)'],
      ['Num 5', 'Perspectiva ↔ orto'],
      ['F', 'Enfocar selección'],
      ['C', 'Ver / ocultar colisiones'],
      ['L', 'Luces y sombras encendidas / apagadas'],
    ]],
    ['Gizmo', [
      ['W · E · R', 'Mover · rotar · escalar'],
      ['T', 'Espacio local ↔ global'],
      ['G', 'Ajuste a rejilla (snap)'],
      ['Fin', 'Bajar al suelo'],
    ]],
    ['Edición', [
      ['Ctrl+Z · Ctrl+Y', 'Deshacer · rehacer'],
      ['Ctrl+C · Ctrl+X · Ctrl+V', 'Copiar · cortar · pegar (también entre escenas)'],
      ['Ctrl+D', 'Duplicar'],
      ['Ctrl+G', 'Agrupar en carpeta'],
      ['Ctrl+A', 'Seleccionar todo'],
      ['Supr', 'Borrar'],
      ['Esc', 'Quitar selección'],
      ['Ctrl+S', 'Guardar'],
      ['P', 'Jugar la escena'],
    ]],
    ['Árbol de escena', [
      ['Ctrl + clic', 'Añadir o quitar'],
      ['Shift + clic', 'Seleccionar un rango'],
      ['Doble clic', 'Enfocar'],
      ['Arrastrar', 'Ordenar o meter dentro (centro del elemento = hijo)'],
    ]],
    ['Jugando', [
      ['WASD / stick izq.', 'Moverse'],
      ['Ratón / stick der.', 'Mirar'],
      ['Espacio / A', 'Saltar'],
      ['Shift / L3', 'Correr'],
      ['V / Y', 'Cambiar cámara'],
      ['F3', 'Datos de depuración'],
      ['Esc', 'Volver al editor'],
    ]],
  ];

  function ventana(tituloHtml, cuerpoHtml) {
    const fondo = document.createElement('div');
    fondo.className = 'dialogo-fondo';
    fondo.innerHTML = `<div class="dialogo"><div class="dialogo-cab"><b>${tituloHtml}</b><span style="flex:1"></span>` +
      `<button title="Cerrar">✕</button></div><div class="dialogo-cuerpo">${cuerpoHtml}</div></div>`;
    const quitar = () => { fondo.remove(); window.removeEventListener('keydown', esc, true); };
    const esc = (e) => { if (e.key === 'Escape') { e.stopPropagation(); quitar(); } };
    window.addEventListener('keydown', esc, true);
    fondo.querySelector('.dialogo-cab button').onclick = quitar;
    fondo.onclick = (e) => { if (e.target === fondo) quitar(); };
    document.body.appendChild(fondo);
  }

  function mostrarAtajos() {
    const html = '<div class="atajos">' + ATAJOS.map(([grupo, filas]) =>
      `<div class="atajos-grupo"><h4>${grupo}</h4><table>${filas.map(([k, v]) => `<tr><td><kbd>${k}</kbd></td><td>${v}</td></tr>`).join('')}</table></div>`,
    ).join('') + '</div>';
    ventana('⌨ Atajos de teclado y ratón', html);
  }

  function acercaDe() {
    ventana('Forja de Juegos', `<p><b>Forja de Juegos v${F.VERSION}</b> — motor y editor de juegos 3D retro (PS1 / N64) en HTML.</p>
      <p class="nota">Three.js r160 incluido (funciona sin internet). Los juegos se exportan para itch.io o cualquier navegador
      (PC, Android, iOS) y se juegan con teclado + ratón o mando.</p>`);
  }

  Ed.Menu = { cerrar, mostrarAtajos };
})(window.FORJA);
