/* =========================================================
   EDITOR · 🎬 TALLER DE CINEMÁTICAS
   Se abre abajo del visor (el nivel se sigue viendo arriba). Las cinemáticas son de cada nivel
   (escena.cinematicas, motor/cinematicas.js).

   · Izquierda: la lista de PASOS en orden, como un guion. Cada paso dice si va "después del anterior" o
     "a la vez que el anterior", y cuándo empieza y termina. Debajo, la línea de tiempo con una pista por
     tipo (cámara, imagen, texto, audio, nivel): clic en un bloque = elegir ese paso.
   · Derecha: lo del paso elegido, o los ajustes de la cinemática (cuándo se ve, saltar, al terminar…).
   · ▶ Probar: juega el nivel y empieza la cinemática al momento (Detener vuelve al taller).
   · 📷 "Cámara desde la vista": crea una cámara de cinemática donde está la cámara del editor ahora mismo.
   ========================================================= */
(function (F) {
  'use strict';
  const T = THREE;
  const Ed = (F.Editor = F.Editor || {});
  const $ = (id) => document.getElementById(id);
  const C = () => F.Cine;

  let abierto = false, idCine = null, idPaso = null, vistaLinea = true;

  /* ---------- estilos (aquí mismo: todo el taller en un archivo) ---------- */
  const st = document.createElement('style');
  st.textContent = `
  #tallerCine { position: absolute; left: 0; right: 0; bottom: 0; height: 52%; min-height: 280px; z-index: 40; display: none; flex-direction: column;
    background: var(--panel, #1b1d22); border-top: 2px solid #e8a33c; color: var(--texto, #ddd); font-size: 12.5px; box-shadow: 0 -6px 20px rgba(0,0,0,.4); }
  #tallerCine.abierto { display: flex; }
  #tallerCine .tc-cab { display: flex; gap: 6px; align-items: center; padding: 6px 8px; border-bottom: 1px solid rgba(255,255,255,.08); flex-wrap: wrap; }
  #tallerCine .tc-cab b { color: #e8a33c; margin-right: 4px; }
  #tallerCine .tc-cab input { width: 130px; }
  #tallerCine .tc-cab select { width: auto; max-width: 170px; }
  #tallerCine .tc-cab button { padding: 3px 7px; }
  #tallerCine .tc-cab .tc-hueco { flex: 1; }
  #tallerCine .tc-cuerpo { flex: 1; display: flex; min-height: 0; }
  #tallerCine .tc-izq { flex: 1.35; display: flex; flex-direction: column; min-width: 0; border-right: 1px solid rgba(255,255,255,.08); }
  #tallerCine .tc-der { flex: 1; overflow: auto; padding: 8px 10px; min-width: 0; }
  #tallerCine .tc-pasos { flex: 1; overflow: auto; padding: 4px 6px; min-height: 70px; }
  #tallerCine .tc-paso { display: grid; grid-template-columns: 22px 1fr auto auto; gap: 6px; align-items: center; padding: 4px 6px; margin: 2px 0;
    border-radius: 3px; background: rgba(255,255,255,.04); cursor: pointer; border-left: 3px solid var(--c, #888); }
  #tallerCine .tc-paso.sel { background: rgba(232,163,60,.2); outline: 1px solid #e8a33c; }
  #tallerCine .tc-paso.alavez { margin-left: 18px; }
  #tallerCine .tc-paso small { opacity: .65; font-variant-numeric: tabular-nums; }
  #tallerCine .tc-paso .tc-n { opacity: .5; text-align: right; }
  #tallerCine .tc-paso .tc-av { color: #ffb347; }
  #tallerCine .tc-paso button { padding: 0 5px; min-width: 0; }
  #tallerCine .tc-anadir { display: flex; gap: 4px; flex-wrap: wrap; padding: 6px; border-top: 1px solid rgba(255,255,255,.08); }
  #tallerCine .tc-anadir select { max-width: 100%; }
  #tallerCine .tc-linea { height: 112px; flex: none; position: relative; overflow-x: auto; overflow-y: hidden; border-top: 1px solid rgba(255,255,255,.08); background: rgba(0,0,0,.2); }
  #tallerCine .tc-linea .tc-pista { position: absolute; left: 0; height: 18px; font-size: 10px; opacity: .55; padding-left: 4px; line-height: 18px; pointer-events: none; }
  #tallerCine .tc-linea .tc-bloque { position: absolute; height: 16px; border-radius: 3px; background: var(--c, #888); color: #111; font-size: 10px; line-height: 16px;
    padding: 0 3px; overflow: hidden; white-space: nowrap; cursor: pointer; min-width: 6px; box-sizing: border-box; }
  #tallerCine .tc-linea .tc-bloque.sel { outline: 2px solid #fff; }
  #tallerCine .tc-linea .tc-regla { position: absolute; top: 0; height: 12px; font-size: 9px; opacity: .5; border-left: 1px solid rgba(255,255,255,.3); padding-left: 2px; }
  #tallerCine .tc-vacio { opacity: .7; padding: 14px; line-height: 1.5; }
  #tallerCine h4 { margin: 4px 0 6px; color: #e8a33c; font-size: 13px; }
  `;
  document.head.appendChild(st);

  // color de cada grupo de pasos (lista y línea de tiempo)
  const COLOR = { Cámara: '#5fb0ff', Imagen: '#c08cff', Texto: '#ffd166', Audio: '#7be08a', Nivel: '#ff9f6b' };
  const PISTAS = ['Cámara', 'Imagen', 'Texto', 'Audio', 'Nivel'];

  const escena = () => Ed.escena;
  const cines = () => (escena().cinematicas = escena().cinematicas || []);
  const cineActual = () => cines().find((c) => c.id === idCine) || null;
  const guardar = () => { Ed.marcarCambio && Ed.marcarCambio(); Ed.guardarLocal(); };
  const fmt = (s) => (Math.round(s * 10) / 10).toFixed(1) + ' s';

  /* ---------- entidades para los selectores ---------- */
  function opEntidades(tipos, primeras = []) {
    const L = escena().entidades.filter((e) => !tipos || tipos.includes(e.tipo));
    return [...primeras, ...L.map((e) => [e.id, (F.Escena.ICONO && F.Escena.ICONO[e.tipo] ? F.Escena.ICONO[e.tipo] + ' ' : '') + (e.nombre || e.tipo)])];
  }
  const opDestino = () => opEntidades(['camara', 'punto', 'inicio', 'marcador'], [['', '(elige a dónde)'], ['__jugador', '🧍 La vista del jugador']]);
  const opMirar = () => [['', '(nada: mira como el punto)'], ['__jugador', '🧍 Al jugador'],
    ...opEntidades(['enemigo', 'npc', 'rehen', 'tienda', 'montable', 'baul', 'puerta', 'palanca', 'modelo', 'cubo', 'barril', 'recogible', 'bomba', 'pedestal', 'empujable', 'punto', 'marcador', 'luz', 'particulas'])];

  /* Esquema del formulario de cada tipo de paso (más "cuándo") */
  function esquemaPaso(p) {
    const cuando = { k: 'cuando', t: 'sel', e: 'Empieza', op: [['despues', '⤵ Después del anterior (cuando todo lo de antes acabó)'], ['alavez', '⇉ A la vez que el anterior']] };
    const dur = (e = 'Dura (s)') => ({ k: 'dur', t: 'num', e, paso: 0.25, min: 0 });
    const S = {
      camara: [{ k: 'destino', t: 'sel', e: 'A dónde', op: opDestino(), ayuda: 'Una 📷 cámara (con su giro), un 📍 punto o la vista del jugador. Crea una con "📷 Cámara desde la vista"' },
        { k: 'modo', t: 'sel', e: 'Cómo', op: [['viaje', '🎥 Viaje suave'], ['corte', '✂ Corte (de golpe)']] },
        { ...dur('Dura el viaje (s)'), si: (v) => v.modo !== 'corte' },
        { k: 'mirar', t: 'sel', e: 'Mirando a', op: opMirar(), ayuda: 'Sigue mirando a eso aunque se mueva, hasta el siguiente paso de cámara' }],
      mirar: [{ k: 'mirar', t: 'sel', e: 'Mirar a', op: opMirar(), ayuda: 'La cámara se queda donde está y gira para seguirlo' }],
      temblor: [{ k: 'fuerza', t: 'rango', e: 'Fuerza', min: 0.05, max: 1.5, paso: 0.05 }, dur()],
      zoom: [{ k: 'fov', t: 'rango', e: 'Campo de visión', min: 10, max: 110, paso: 1, ayuda: 'Menos = más cerca (zoom) · 60 ≈ normal' }, dur('Tarda (s)')],
      fundido: [{ k: 'trans', t: 'sel', e: 'Transición', op: F.Efectos ? F.Efectos.TRANSICIONES : [['negro', 'Fundido a negro']] },
        { k: 'tapar', t: 'bool', e: 'Tapar la pantalla', ayuda: 'Marcado = se tapa · desmarcado = se destapa (vuelve la imagen)' }, dur('Tarda (s)')],
      barras: [{ k: 'grosor', t: 'rango', e: 'Grosor', min: 0, max: 0.25, paso: 0.01, ayuda: 'Entran o salen deslizándose. 0 = quitarlas' }],
      efectos: [{ k: 'estilo', t: 'sel', e: 'Filtro', op: [['nivel', 'Los del nivel'], ['ninguno', 'Sin efectos'],
        ...(F.Efectos ? F.Efectos.ESQUEMA[1].op.filter(([k]) => k !== 'ninguno' && k !== 'propio') : [])], ayuda: 'Al terminar la cinemática vuelven los efectos de antes' }],
      dialogo: [{ k: 'quien', t: 'texto', e: 'Quién habla', ayuda: 'Vacío = sin nombre (narrador)' }, { k: 'texto', t: 'textoLargo', e: 'Texto', filas: 3 },
        dur('Se ve (s)'), { k: 'esperar', t: 'bool', e: 'Esperar a que pulse', ayuda: 'Al acabar espera a que el jugador pulse Usar / Saltar para seguir' }],
      titulo: [{ k: 'texto', t: 'texto', e: 'Título' }, { k: 'sub', t: 'texto', e: 'Debajo' }, dur('Se ve (s)')],
      sonido: [{ k: 'asset', t: 'asset', e: 'Sonido', tipoAsset: 'audio', vacio: '(elige uno)' }],
      musica: [{ k: 'asset', t: 'asset', e: 'Música', tipoAsset: 'audio', vacio: '(parar la música)' }],
      explosion: [{ k: 'donde', t: 'sel', e: 'Dónde', op: [['', '(elige dónde)'], ['__jugador', '🧍 En el jugador'], ...opEntidades(null)],
          ayuda: 'En cualquier cosa del nivel: un 📍 punto, un barril, una cámara… (a media altura)' },
        { k: 'tam', t: 'sel', e: 'Tamaño', op: F.Explosiones ? F.Explosiones.OP_TAMANOS : [['media', 'Mediana']] },
        { k: 'humo', t: 'bool', e: 'Con humo' },
        { k: 'dano', t: 'num', e: 'Daño', paso: 10, min: 0, ayuda: '0 = solo se ve (lo normal en una cinemática). Con daño hiere al jugador, enemigos y rompe cajas/barriles cerca' },
        { k: 'asset', t: 'asset', e: 'Sonido', tipoAsset: 'audio', vacio: '(el del motor)' }],
      particulas: [{ k: 'a', t: 'sel', e: 'Cuáles', op: [['', '(elige)'], ...opEntidades(['particulas'])], ayuda: 'Un emisor ✨ Partículas del nivel. Para que empiece apagado: su opción "Encendidas al empezar"' },
        { k: 'encender', t: 'bool', e: 'Encender', ayuda: 'Desmarcado = apagar' }],
      hacer: [],
      esperar: [dur('Esperar (s)')],
    };
    return [cuando, ...(S[p.tipo] || [])];
  }

  const ESQUEMA_CINE = () => [
    { grupo: '🎬 Cuándo se ve' },
    { k: 'alEmpezar', t: 'bool', e: 'Al empezar el nivel', ayuda: 'Si no, la pone una palanca o un disparador con la acción "🎬 Ver cinemática"' },
    { k: 'unaVez', t: 'bool', e: 'Solo una vez por partida' },
    { k: 'saltar', t: 'sel', e: 'Se puede saltar', op: [['siempre', 'Siempre'], ['vista', 'Solo si ya la vio antes']],
      ayuda: 'Manteniendo Saltar / Usar / Esc, o tocando el botón ⏭. Lo que cambia el nivel (puertas, luces…) pasa igual' },
    { k: 'barras', t: 'rango', e: 'Barras de cine', min: 0, max: 0.25, paso: 0.01, ayuda: 'Mientras dura. 0 = sin barras' },
    { grupo: '⏭ Al terminar' },
    { k: 'alTerminar', t: 'sel', e: 'Después', op: [['juego', '🎮 Volver al juego'], ['nivel', '🚪 Ir a otro nivel'], ['cine', '🎬 Otra cinemática']] },
    { k: 'destino', t: 'sel', e: 'Nivel', op: [['', '(elige)'], ...Ed.proyecto.escenas.map((s) => [s.id, s.nombre])], si: (v) => v.alTerminar === 'nivel' },
    { k: 'transicion', t: 'sel', e: 'Transición', op: F.Efectos ? F.Efectos.TRANSICIONES : [['negro', 'Fundido']], si: (v) => v.alTerminar === 'nivel' },
    { k: 'siguiente', t: 'sel', e: 'Cuál', op: [['', '(elige)'], ...cines().filter((c) => c.id !== idCine).map((c) => [c.id, c.nombre])], si: (v) => v.alTerminar === 'cine' },
  ];

  /* ---------- avisos de un paso (⚠ en la lista y en su formulario) ---------- */
  function avisos(p, esc = escena()) {
    const ids = new Set(esc.entidades.map((e) => e.id));
    const L = [];
    const existe = (id) => !id || id === '__jugador' || ids.has(id);
    if (p.tipo === 'camara' && !p.destino) L.push('Elige a dónde va la cámara');
    if ((p.tipo === 'camara' || p.tipo === 'mirar') && (!existe(p.destino) || !existe(p.mirar))) L.push('Apunta a algo que ya no existe');
    if (p.tipo === 'mirar' && !p.mirar) L.push('Elige a qué mira');
    if (p.tipo === 'dialogo' && !String(p.texto || '').trim()) L.push('Sin texto');
    if (p.tipo === 'titulo' && !String(p.texto || '').trim()) L.push('Sin título');
    if (p.tipo === 'sonido' && !p.asset) L.push('Elige un sonido');
    if (p.tipo === 'hacer' && !(p.acciones || []).length) L.push('No hace nada todavía');
    if (p.tipo === 'explosion' && !p.donde) L.push('Elige dónde explota');
    if (p.tipo === 'particulas' && !p.a) L.push('Elige qué partículas');
    if ((p.tipo === 'explosion' && !existe(p.donde)) || (p.tipo === 'particulas' && !existe(p.a))) L.push('Apunta a algo que ya no existe');
    return L;
  }
  Ed.avisosPasoCine = avisos;

  /* ---------- el panel ---------- */
  function caja() {
    let el = $('tallerCine');
    if (!el) {
      el = document.createElement('div');
      el.id = 'tallerCine';
      $('vista').appendChild(el);
    }
    return el;
  }

  function pintar() {
    const el = caja();
    el.classList.toggle('abierto', abierto);
    if ($('btnRielCine')) $('btnRielCine').classList.toggle('activo', abierto);
    if (!abierto) return;
    const lista = cines();
    if (idCine && !cineActual()) idCine = null;
    if (!idCine && lista.length) idCine = lista[0].id;
    const c = cineActual();
    el.innerHTML = '';
    // cabecera
    const cab = document.createElement('div');
    cab.className = 'tc-cab';
    cab.innerHTML = `<b title="Cinemáticas de este nivel">🎬 ${escena().nombre}</b>`;
    const sel = Ed.controlEsquema({ t: 'sel', op: lista.length ? lista.map((x) => [x.id, x.nombre]) : [['', '(ninguna)']] }, idCine || '', (v) => { idCine = v; idPaso = null; pintar(); });
    const bNueva = boton('＋ Nueva', () => {
      const n = C().cineNueva('Cinemática ' + (lista.length + 1));
      // un comienzo útil: barras, cámara al jugador y un diálogo
      n.pasos = [C().pasoNuevo('camara', { destino: '__jugador', modo: 'corte' }), C().pasoNuevo('dialogo', { texto: '…' })];
      cines().push(n); idCine = n.id; idPaso = null; guardar(); pintar(); pintarPanelEscena();
    }, 'primario');
    cab.append(sel, bNueva);
    if (c) {
      const nom = document.createElement('input');
      nom.value = c.nombre; nom.title = 'Nombre';
      nom.onchange = () => { c.nombre = nom.value || 'Cinemática'; guardar(); pintar(); pintarPanelEscena(); };
      const bDup = boton('⧉', () => { const d = F.util.copiar(c); d.id = F.util.uid(); d.nombre = c.nombre + ' (copia)'; for (const p of d.pasos) p.id = F.util.uid(); cines().push(d); idCine = d.id; guardar(); pintar(); pintarPanelEscena(); }, '', 'Duplicar');
      const bBorrar = boton('🗑', () => {
        if (!confirm(`¿Borrar la cinemática "${c.nombre}"?`)) return;
        escena().cinematicas = cines().filter((x) => x !== c); idCine = null; idPaso = null; guardar(); pintar(); pintarPanelEscena();
      }, 'peligro', 'Borrar');
      const bAjustes = boton('⚙ Ajustes', () => { idPaso = null; pintar(); }, idPaso ? '' : 'activo', 'Cuándo se ve, saltar, qué pasa al terminar');
      const bVista = boton(vistaLinea ? '⏱ Sin línea' : '⏱ Línea', () => { vistaLinea = !vistaLinea; pintar(); });
      const bCam = boton('📷 Cámara aquí', crearCamaraAqui, '', 'Crea una cámara de cinemática donde está ahora la cámara del editor (y la usa en el paso elegido si es de cámara)');
      const bProbar = boton('▶ Probar', probar, 'primario', 'Juega el nivel y la cinemática empieza al momento');
      cab.append(nom, bDup, bBorrar, bAjustes, bVista, bCam, bProbar);
    }
    const hueco = document.createElement('span'); hueco.className = 'tc-hueco';
    cab.append(hueco, boton('✕', cerrar, '', 'Cerrar el taller'));
    el.appendChild(cab);

    const cuerpo = document.createElement('div');
    cuerpo.className = 'tc-cuerpo';
    el.appendChild(cuerpo);
    if (!c) {
      const v = document.createElement('div');
      v.className = 'tc-vacio';
      v.innerHTML = 'Este nivel no tiene cinemáticas. Pulsa <b>＋ Nueva</b>.<br>Una cinemática es una lista de pasos: mover la cámara, diálogos, fundidos, música, abrir puertas… ' +
        'Cada paso va <b>después del anterior</b> o <b>a la vez</b>. Luego la pones "al empezar el nivel" o con un disparador (acción 🎬 Ver cinemática).';
      cuerpo.appendChild(v);
      return;
    }
    const izq = document.createElement('div'); izq.className = 'tc-izq';
    const der = document.createElement('div'); der.className = 'tc-der';
    cuerpo.append(izq, der);
    pintarPasos(izq, c);
    pintarDerecha(der, c);
  }

  function boton(texto, fn, clase = '', titulo = '') {
    const b = document.createElement('button');
    b.textContent = texto; if (clase) b.className = clase; if (titulo) b.title = titulo;
    b.onclick = fn;
    return b;
  }

  function pintarPasos(izq, c) {
    const hor = C().horario(c);
    const caja = document.createElement('div');
    caja.className = 'tc-pasos';
    if (!c.pasos.length) caja.innerHTML = '<div class="tc-vacio">Sin pasos. Añade el primero abajo (＋ Añadir paso).</div>';
    hor.filas.forEach((f, i) => {
      const p = f.paso, P = C().PASOS[p.tipo] || { e: p.tipo, cat: 'Nivel' };
      const fila = document.createElement('div');
      fila.className = 'tc-paso' + (p.id === idPaso ? ' sel' : '') + (p.cuando === 'alavez' && i > 0 ? ' alavez' : '');
      fila.style.setProperty('--c', COLOR[P.cat] || '#888');
      const av = avisos(p);
      fila.innerHTML = `<span class="tc-n">${i + 1}</span><span>${P.e}${resumen(p)}${av.length ? ' <span class="tc-av" title="' + av.join(' · ') + '">⚠</span>' : ''}</span>` +
        `<small>${fmt(f.inicio)} → ${fmt(f.fin)}</small>`;
      const bots = document.createElement('span');
      bots.append(
        boton('↑', (ev) => { ev.stopPropagation(); mover(c, i, -1); }, '', 'Antes'),
        boton('↓', (ev) => { ev.stopPropagation(); mover(c, i, 1); }, '', 'Después'),
        boton('✕', (ev) => { ev.stopPropagation(); c.pasos.splice(i, 1); if (idPaso === p.id) idPaso = null; guardar(); pintar(); }, '', 'Quitar paso'));
      fila.appendChild(bots);
      fila.onclick = () => { idPaso = p.id; pintar(); };
      caja.appendChild(fila);
    });
    izq.appendChild(caja);
    // añadir paso (tras el elegido, o al final)
    const an = document.createElement('div'); an.className = 'tc-anadir';
    const op = [['', '＋ Añadir paso…']];
    for (const cat of PISTAS) for (const [k, P] of Object.entries(C().PASOS)) if (P.cat === cat) op.push([k, `${cat} · ${P.e}`]);
    const selN = Ed.controlEsquema({ t: 'sel', op }, '', (v) => {
      if (!v) return;
      const nuevo = C().pasoNuevo(v);
      const i = c.pasos.findIndex((x) => x.id === idPaso);
      c.pasos.splice(i >= 0 ? i + 1 : c.pasos.length, 0, nuevo);
      idPaso = nuevo.id; guardar(); pintar();
    });
    an.appendChild(selN);
    const tot = document.createElement('small');
    tot.style.cssText = 'margin-left:auto;opacity:.7;align-self:center';
    tot.textContent = 'Total: ' + fmt(hor.total);
    an.appendChild(tot);
    izq.appendChild(an);
    if (vistaLinea) pintarLinea(izq, c, hor);
  }

  // texto corto de cada paso en la lista
  function resumen(p) {
    const nom = (id) => id === '__jugador' ? 'jugador' : ((escena().entidades.find((e) => e.id === id) || {}).nombre || '?');
    const corta = (t, n = 28) => { t = String(t || ''); return t.length > n ? t.slice(0, n) + '…' : t; };
    switch (p.tipo) {
      case 'camara': return p.destino ? ` <small>→ ${nom(p.destino)}${p.modo === 'corte' ? ' (corte)' : ''}${p.mirar ? ' 👁 ' + nom(p.mirar) : ''}</small>` : '';
      case 'mirar': return p.mirar ? ` <small>${nom(p.mirar)}</small>` : '';
      case 'dialogo': return ` <small>${p.quien ? p.quien + ': ' : ''}«${corta(p.texto)}»</small>`;
      case 'titulo': return ` <small>«${corta(p.texto)}»</small>`;
      case 'fundido': return ` <small>${p.tapar ? 'tapar' : 'destapar'} · ${p.trans || 'negro'}</small>`;
      case 'barras': return ` <small>${p.grosor > 0 ? p.grosor : 'quitar'}</small>`;
      case 'efectos': return ` <small>${p.estilo}</small>`;
      case 'hacer': return ` <small>${(p.acciones || []).length} acción(es)</small>`;
      case 'explosion': return p.donde ? ` <small>${nom(p.donde)} · ${p.tam}${p.dano > 0 ? ' · daño ' + p.dano : ''}</small>` : '';
      case 'particulas': return p.a ? ` <small>${p.encender !== false ? 'encender' : 'apagar'} ${nom(p.a)}</small>` : '';
      default: return '';
    }
  }

  function mover(c, i, d) {
    const j = i + d;
    if (j < 0 || j >= c.pasos.length) return;
    c.pasos.splice(j, 0, c.pasos.splice(i, 1)[0]);
    guardar(); pintar();
  }

  /* Línea de tiempo: una pista por grupo; los pasos instantáneos se ven como una marca fina */
  function pintarLinea(izq, c, hor) {
    const caja = document.createElement('div');
    caja.className = 'tc-linea';
    const anchoVis = Math.max(300, (izq.clientWidth || 600) - 20);
    const escala = Math.max(18, Math.min(120, anchoVis / Math.max(4, hor.total + 1)));   // px por segundo
    const ancho = 70 + (hor.total + 2) * escala;
    const dentro = document.createElement('div');
    dentro.style.cssText = `position:relative;height:100%;width:${ancho}px`;
    for (let s = 0; s <= hor.total + 1; s++) {
      const r = document.createElement('div'); r.className = 'tc-regla'; r.style.left = (70 + s * escala) + 'px'; r.textContent = s + 's';
      dentro.appendChild(r);
    }
    PISTAS.forEach((cat, i) => {
      const y = 14 + i * 20;
      const n = document.createElement('div'); n.className = 'tc-pista'; n.style.top = y + 'px'; n.textContent = cat;
      dentro.appendChild(n);
      for (const f of hor.filas) {
        const P = C().PASOS[f.paso.tipo];
        if (!P || P.cat !== cat) continue;
        const b = document.createElement('div');
        b.className = 'tc-bloque' + (f.paso.id === idPaso ? ' sel' : '');
        b.style.setProperty('--c', COLOR[cat]);
        b.style.left = (70 + f.inicio * escala) + 'px';
        b.style.top = y + 'px';
        b.style.width = Math.max(6, (f.fin - f.inicio) * escala) + 'px';
        b.textContent = P.e.split(' ')[0] + ' ' + (f.paso.tipo === 'dialogo' ? (f.paso.texto || '') : '');
        b.title = P.e + ' · ' + fmt(f.inicio) + ' → ' + fmt(f.fin);
        b.onclick = () => { idPaso = f.paso.id; pintar(); };
        dentro.appendChild(b);
      }
    });
    caja.appendChild(dentro);
    izq.appendChild(caja);
  }

  function pintarDerecha(der, c) {
    const p = c.pasos.find((x) => x.id === idPaso);
    if (!p) {
      const h = document.createElement('h4'); h.textContent = '⚙ Ajustes de «' + c.nombre + '»';
      der.appendChild(h);
      Ed.formulario(der, ESQUEMA_CINE(), c, (k, v, definitivo) => { if (definitivo) { guardar(); if (k === 'alTerminar') pintar(); } },
        { defectos: C().CINE });
      if (c.alTerminar === 'nivel' && !c.destino) nota(der, '⚠ Elige a qué nivel va al terminar.');
      if (c.alTerminar === 'cine' && !c.siguiente) nota(der, '⚠ Elige qué cinemática sigue.');
      if (!c.alEmpezar && !usadaPorAccion(c.id)) nota(der, 'ℹ Nadie la pone todavía: marca "Al empezar el nivel" o usa un disparador / palanca con la acción <b>🎬 Ver cinemática</b>.');
      return;
    }
    const P = C().PASOS[p.tipo];
    const h = document.createElement('h4'); h.textContent = P.e;
    der.appendChild(h);
    const def = { ...C().PASOS[p.tipo].def, cuando: 'despues' };
    Ed.formulario(der, esquemaPaso(p), p, (k, v, definitivo) => {
      if (!definitivo) return;
      guardar();
      // repinta la lista (tiempos y resumen) sin perder lo que se escribe
      const izq = $('tallerCine').querySelector('.tc-izq');
      if (izq) { izq.innerHTML = ''; pintarPasos(izq, c); }
      if (k === 'modo' || k === 'destino') { der.innerHTML = ''; pintarDerecha(der, c); }
    }, { defectos: def });
    if (p.tipo === 'hacer' && Ed.editarAcciones) {
      Ed.editarAcciones(der, { id: '__cine' }, p, 'Lo mismo que puede hacer una palanca: abrir puertas, encender luces, partículas, sonidos, clima, plataformas…',
        () => { der.innerHTML = ''; pintarDerecha(der, c); const izq = $('tallerCine').querySelector('.tc-izq'); if (izq) { izq.innerHTML = ''; pintarPasos(izq, c); } });
    }
    if (p.tipo === 'camara') {
      const b = boton('📷 Nueva cámara desde la vista del editor', crearCamaraAqui, '', 'Mueve la vista del editor (clic derecho + WASD) a donde quieres el plano y pulsa aquí');
      der.appendChild(b);
    }
    for (const a of avisos(p)) nota(der, '⚠ ' + a);
  }

  function nota(cont, html) {
    const d = document.createElement('div');
    d.className = 'nota';
    d.innerHTML = html;
    cont.appendChild(d);
  }

  function usadaPorAccion(id) {
    return escena().entidades.some((e) => ['palanca', 'disparador', 'pedestal', 'condicion'].some((k) => e[k] && (e[k].acciones || []).some((a) => a.que === 'cine' && a.cine === id)));
  }

  /* 📷 una cámara de cinemática donde está la del editor */
  function crearCamaraAqui() {
    const cam = Ed.camaraEditor;
    if (!cam) return;
    const c = cineActual();
    const n = escena().entidades.filter((e) => e.tipo === 'camara').length + 1;
    const e = new T.Euler().setFromQuaternion(cam.quaternion, 'XYZ');
    const ent = Ed.agregarEntidad('camara', {
      nombre: 'Plano ' + n,
      rot: [e.x, e.y, e.z].map((r) => +(r * 180 / Math.PI).toFixed(1)),
      camara: { ...(F.Camaras ? F.Camaras.CAMARA : {}), activacion: 'cine', fov: Math.round(cam.fov) },
    }, cam.position.clone());
    const p = c && c.pasos.find((x) => x.id === idPaso);
    if (p && p.tipo === 'camara' && ent) { p.destino = ent.id; }
    else if (c && ent) {
      const nuevo = C().pasoNuevo('camara', { destino: ent.id, modo: 'corte' });
      const i = c.pasos.findIndex((x) => x.id === idPaso);
      c.pasos.splice(i >= 0 ? i + 1 : c.pasos.length, 0, nuevo);
      idPaso = nuevo.id;
    }
    guardar();
    Ed.toast('📷 Cámara creada donde mira el editor');
    pintar();
  }

  /* ▶ Probar: ▶ Jugar y la cinemática al momento. Al Detener se vuelve a abrir el taller */
  let volverAlTaller = false;
  function probar() {
    const c = cineActual();
    if (!c) return;
    if (!c.pasos.length) { Ed.toast('Añade algún paso primero', 'error'); return; }
    volverAlTaller = true;
    abierto = false; pintar();
    $('btnJugar').click();
    let intentos = 0;
    const esperar = () => {
      const J = Ed.juego;
      if (J && J.cine) { J.cine.reproducir(c.id, true); return; }
      if (J && !J.cine) { Ed.toast('No se pudo empezar la cinemática', 'error'); return; }
      if (++intentos < 100) setTimeout(esperar, 50);
    };
    setTimeout(esperar, 50);
  }
  // envolver Detener (se define en editor.js antes que este archivo)
  if (typeof Ed.detenerJuego === 'function') {
    const original = Ed.detenerJuego;
    Ed.detenerJuego = function (...a) {
      const r = original.apply(this, a);
      if (volverAlTaller) { volverAlTaller = false; abierto = true; setTimeout(pintar, 0); }
      return r;
    };
  }

  // ▶ Jugar con el taller abierto: se esconde y vuelve al Detener
  if ($('btnJugar')) $('btnJugar').addEventListener('click', () => { if (abierto) { volverAlTaller = true; abierto = false; pintar(); } }, true);

  // 🎥 botón del riel izquierdo: abre / cierra el taller
  if ($('btnRielCine')) $('btnRielCine').onclick = () => { if (Ed.jugando) return; if (abierto) cerrar(); else abrir(); };

  function abrir(id = null) {
    abierto = true;
    if (id) { idCine = id; idPaso = null; }
    pintar();
  }
  function cerrar() { abierto = false; pintar(); }
  Ed.abrirTallerCine = abrir;
  Ed.cerrarTallerCine = cerrar;

  // al cambiar de nivel el taller muestra las de ese nivel
  const cambiarAntes = Ed.cambiarEscena;
  if (typeof cambiarAntes === 'function') {
    Ed.cambiarEscena = function (...a) { const r = cambiarAntes.apply(this, a); idCine = null; idPaso = null; if (abierto) pintar(); return r; };
  }
  F.on('escena-reconstruida', () => { if (abierto && !Ed.jugando) { if (idCine && !cineActual()) { idCine = null; idPaso = null; } pintar(); } });

  /* ---------- sección en el panel Escena ---------- */
  function pintarPanelEscena() { if ($('panelEscena') && $('panelEscena').offsetParent) Ed.construirPanelEscena(); }
  Ed.pintarCinesEscena = function (p) {
    const sc = Ed.seccion(p, '🎬 Cinemáticas', true);
    const L = cines();
    if (!L.length) nota(sc.cuerpo, 'Ninguna en este nivel. Escenas con cámara, diálogos, fundidos, música…');
    for (const c of L) {
      const f = document.createElement('div');
      f.style.cssText = 'display:flex;gap:6px;align-items:center;margin:2px 0';
      const t = document.createElement('span'); t.style.flex = '1';
      t.textContent = '🎬 ' + c.nombre + (c.alEmpezar ? ' · al empezar' : '') + ' · ' + fmt(C().horario(c).total);
      f.append(t, boton('Abrir', () => abrir(c.id)));
      sc.cuerpo.appendChild(f);
    }
    const b = boton(L.length ? '🎬 Abrir el taller' : '＋ Crear cinemática', () => {
      if (!L.length) { const n = C().cineNueva('Cinemática 1'); n.pasos = [C().pasoNuevo('camara', { destino: '__jugador', modo: 'corte' }), C().pasoNuevo('dialogo', { texto: '…' })]; cines().push(n); guardar(); abrir(n.id); Ed.construirPanelEscena(); }
      else abrir();
    }, 'primario');
    sc.cuerpo.appendChild(b);
  };
})(window.FORJA);
