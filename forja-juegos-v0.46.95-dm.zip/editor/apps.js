/* =========================================================
   EDITOR · APPS INTEGRADAS
   Tus HTML (forja de niveles, de personajes, Trovador…) se abren en pestañas.
   Un pequeño script inyectado captura sus descargas (a.download + a.click)
   y las manda a la biblioteca. Versiones: ⟳ cargar otra, ↶ volver a la anterior.
   ========================================================= */
(function (F) {
  'use strict';
  const Ed = (F.Editor = F.Editor || {});
  const $ = (id) => document.getElementById(id);
  const DB = F.Assets.DB;

  const INYECCION = `<script>(function(){
    var mapa = new Map(), crear = URL.createObjectURL.bind(URL), descargar = false;
    URL.createObjectURL = function(o){ var u = crear(o); try { if (o instanceof Blob) mapa.set(u, o); } catch(e){} return u; };
    addEventListener('message', function(e){ if (e.data && e.data.__forja === 'descargar') descargar = !!e.data.valor; });
    var EXT = /\\.(glb|gltf|mp3|wav|ogg|mid|midi|png|jpe?g|webp|receta\\.json)$/i;
    var P = HTMLAnchorElement.prototype, original = P.click;
    P.click = function(){
      try {
        var n = this.download, h = this.href;
        if (n && EXT.test(n)) {
          var enviar = function(b){ parent.postMessage({ __forja: 'export', nombre: n, blob: b }, '*'); };
          var b = mapa.get(h);
          if (b) enviar(b);
          else if (/^data:/.test(h)) fetch(h).then(function(r){ return r.blob(); }).then(enviar);
          if (!descargar) return;
        }
      } catch(e){}
      return original.call(this);
    };
  })();<\/script>`;

  const apps = new Map();     // id → { id, nombre, version, archivo, html, fecha, anterior }
  const marcos = new Map();   // id → { iframe, url }
  let paraActualizar = null;
  Ed.pestanaActiva = 'editor';

  function tituloDeHtml(html, respaldo) {
    const m = html.match(/<title[^>]*>([^<]*)<\/title>/i);
    return (m && m[1].trim()) || respaldo.replace(/\.html?$/i, '');
  }

  // Versión: primero del nombre del archivo (forja_personajes_v0.15.html), luego del título
  function versionDe(titulo, archivo) {
    const nombre = (archivo || '').replace(/\.html?$/i, '');
    const m = nombre.match(/[_\-\s.]v?(\d+(?:[._]\d+)+)$/i) || nombre.match(/\bv(\d+(?:[._]\d+)*)/i) || titulo.match(/\bv\s?(\d+(?:[._]\d+)*)/i);
    return m ? m[1].replace(/_/g, '.') : '';
  }

  function nombreSinVersion(titulo) {
    return titulo.replace(/\bv\s?\d+(?:[._]\d+)*\b/gi, '').replace(/\(\d+\)/g, '')
      .replace(/\s*[—–\-|·:]\s*$/g, '').replace(/^\s*[—–\-|·:]\s*/g, '').replace(/\s{2,}/g, ' ').trim();
  }

  function normalizarApp(app) {
    const titulo = tituloDeHtml(app.html, app.archivo || app.nombre || 'app');
    app.nombre = nombreSinVersion(titulo) || titulo;
    app.version = app.version ?? versionDe(titulo, app.archivo || '');
    app.fecha = app.fecha || Date.now();
    app.anterior = app.anterior || null;
    return app;
  }

  const etiqueta = (app) => app.nombre + (app.version ? ' v' + app.version : '');
  const etiquetaVersion = (v) => (v.version ? 'v' + v.version : new Date(v.fecha).toLocaleString('es-MX', { dateStyle: 'short', timeStyle: 'short' }));

  async function cargarApp(archivo, idDestino = null) {
    const html = await archivo.text();
    const titulo = tituloDeHtml(html, archivo.name);
    const nueva = { nombre: nombreSinVersion(titulo) || titulo, version: versionDe(titulo, archivo.name), archivo: archivo.name, html, fecha: Date.now() };
    const existente = idDestino ? apps.get(idDestino) : null;   // solo ⟳ reemplaza
    if (existente) {
      if (existente.html === html) { Ed.toast(`Ya tienes cargada esa versión de <b>${existente.nombre}</b>`); abrir(existente.id); return; }
      const abierta = marcos.has(existente.id);
      const antes = etiquetaVersion(existente);
      existente.anterior = { version: existente.version, archivo: existente.archivo, html: existente.html, fecha: existente.fecha };
      Object.assign(existente, nueva);
      await DB.poner('apps', existente).catch(() => {});
      if (abierta) cerrar(existente.id);
      pintarLista();
      abrir(existente.id);
      Ed.toast(`⟳ <b>${existente.nombre}</b> actualizada: ${antes} → <b>${etiquetaVersion(existente)}</b>`);
      return;
    }
    const app = { id: F.util.uid(), ...nueva, anterior: null };
    apps.set(app.id, app);
    await DB.poner('apps', app).catch(() => {});
    pintarLista();
    abrir(app.id);
    Ed.toast(`App <b>${etiqueta(app)}</b> añadida`);
  }

  async function volverAnterior(id) {
    const app = apps.get(id);
    if (!app || !app.anterior) return;
    if (!confirm(`¿Volver ${app.nombre} a ${etiquetaVersion(app.anterior)}?\n(La ${etiquetaVersion(app)} queda como anterior por si quieres regresar.)`)) return;
    const actual = { version: app.version, archivo: app.archivo, html: app.html, fecha: app.fecha };
    Object.assign(app, app.anterior);
    app.anterior = actual;
    await DB.poner('apps', app).catch(() => {});
    const abierta = marcos.has(id);
    if (abierta) cerrar(id);
    pintarLista();
    if (abierta) abrir(id);
    Ed.toast(`↶ <b>${app.nombre}</b> regresó a ${etiquetaVersion(app)}`);
  }

  function abrir(id) {
    const app = apps.get(id);
    if (!app) return;
    if (!marcos.has(id)) {
      const html = /<head[^>]*>/i.test(app.html) ? app.html.replace(/<head[^>]*>/i, (m) => m + INYECCION) : INYECCION + app.html;
      const url = URL.createObjectURL(new Blob([html], { type: 'text/html' }));
      const iframe = document.createElement('iframe');
      iframe.src = url;
      iframe.allow = 'fullscreen; autoplay; gamepad';
      iframe.onload = () => iframe.contentWindow.postMessage({ __forja: 'descargar', valor: $('chkDescargar').checked }, '*');
      $('marcos').appendChild(iframe);
      marcos.set(id, { iframe, url });
    }
    irAPestana(id);
  }

  function cerrar(id) {
    const m = marcos.get(id);
    if (!m) return;
    m.iframe.remove();
    URL.revokeObjectURL(m.url);
    marcos.delete(id);
    if (Ed.pestanaActiva === id) irAPestana('editor');
    else pintarPestanas();
  }

  function quitar(id) {
    const app = apps.get(id);
    if (!app || !confirm(`¿Quitar la app "${app.nombre}" del editor?`)) return;
    cerrar(id);
    apps.delete(id);
    DB.borrar('apps', id).catch(() => {});
    pintarLista();
  }

  function irAPestana(id) {
    if (id !== 'editor' && Ed.jugando) Ed.detenerJuego();
    Ed.pestanaActiva = id;
    const enEditor = id === 'editor';
    $('vista').style.display = enEditor ? 'block' : 'none';
    $('marcos').style.display = enEditor ? 'none' : 'block';
    for (const [mid, m] of marcos) m.iframe.style.display = mid === id ? 'block' : 'none';
    $('opcDescarga').style.display = enEditor ? 'none' : 'flex';
    pintarPestanas();
    if (enEditor && Ed.vista) requestAnimationFrame(() => Ed.vista.ajustarTamano());
  }

  function pintarPestanas() {
    const cont = $('pestanas');
    cont.innerHTML = '';
    const crear = (id, texto, cerrable) => {
      const el = document.createElement('div');
      el.className = 'pestana' + (Ed.pestanaActiva === id ? ' activa' : '');
      el.innerHTML = `<span>${texto}</span>`;
      el.onclick = () => irAPestana(id);
      if (cerrable) {
        const x = document.createElement('span');
        x.className = 'x';
        x.textContent = '✕';
        x.title = 'Cerrar pestaña (la app sigue guardada)';
        x.onclick = (ev) => { ev.stopPropagation(); cerrar(id); };
        el.appendChild(x);
      }
      cont.appendChild(el);
    };
    crear('editor', '🎮 Editor', false);
    for (const id of marcos.keys()) { const app = apps.get(id); crear(id, app ? etiqueta(app) : 'App', true); }
  }

  function pintarLista() {
    const cont = $('listaApps');
    cont.innerHTML = '';
    if (!apps.size) {
      cont.innerHTML = '<div class="vacio">Carga tu forja de niveles, de personajes o el Trovador</div>';
      return;
    }
    for (const app of apps.values()) {
      const el = document.createElement('div');
      el.className = 'item';
      const ayuda = `${app.archivo || app.nombre}\nCargada: ${new Date(app.fecha).toLocaleString('es-MX')}` +
        (app.anterior ? `\nAnterior: ${etiquetaVersion(app.anterior)}` : '');
      el.innerHTML = `<span>▣</span><span class="nom" title="${ayuda}">${app.nombre}</span><span class="meta">${app.version ? 'v' + app.version : ''}</span>`;
      el.onclick = () => abrir(app.id);
      const boton = (texto, titulo, fn, clase = '') => {
        const b = document.createElement('button');
        b.textContent = texto;
        b.title = titulo;
        b.className = clase;
        b.onclick = (ev) => { ev.stopPropagation(); fn(); };
        el.appendChild(b);
      };
      boton('⟳', 'Cargar una versión nueva de esta app', () => { paraActualizar = app.id; $('archivoApp').click(); });
      if (app.anterior) boton('↶', `Volver a ${etiquetaVersion(app.anterior)}`, () => volverAnterior(app.id));
      boton('✕', 'Quitar app', () => quitar(app.id), 'peligro');
      cont.appendChild(el);
    }
  }

  /* ---------- Ida y vuelta con la Forja de personajes ----------
     Al enviarlo, la app guarda sus ajustes dentro del GLB (extras del nodo raíz → userData.forja).
     "Editar en Forja de personajes" abre la app y le pasa esos ajustes; ella reenvía con el mismo nombre. */
  function datosForja(a) {
    if (!a || !a.gltf) return null;
    let d = null;
    a.gltf.scene.traverse((o) => { if (!d && o.userData && o.userData.forja && o.userData.forja.estado) d = o.userData.forja; });
    return d;
  }
  // qué app hizo cada archivo (userData.forja.app); sin "app" = la Forja de personajes (sus GLB viejos no lo traen)
  const APPS_EDITAR = {
    'forja-terrenos': { nombre: 'Entorno de Niveles', re: /entorno de niveles|forja de niveles/i, minima: 'v2.48' },
    'forja-sonidos': { nombre: 'Forja de Sonidos', re: /forja de sonidos/i, minima: 'v0.1' },
    'forja-personajes': { nombre: 'Forja de personajes', re: /forja de personajes/i, minima: 'v0.16' },
  };
  function appDe(a) {
    const d = datosForja(a);
    if (!d) return null;
    return APPS_EDITAR[d.app] || APPS_EDITAR['forja-personajes'];
  }
  function editarEnApp(idAsset) {
    const a = F.Assets.mapa.get(idAsset), d = datosForja(a), cual = appDe(a);
    if (!d || !cual) return;
    const esa = (app) => cual.re.test(app.nombre) || cual.re.test(tituloDeHtml(app.html || '', ''));
    const est = d.estado || {}, clave = est.formato === 'forja-receta' ? `${est.app}@${est.generador || 1}` : null;
    const lista = [...apps.values()].filter(esa).sort((x, y) => (y.fecha || 0) - (x.fecha || 0));
    const app = (clave && lista.find((x) => (x.html || '').includes(`'${clave}'`))) || lista[0];   // a1 = Forja vieja, a2 = la nueva
    if (!app) { Ed.toast(`Carga <b>${cual.nombre}</b> (${cual.minima} o más nueva) en el panel <b>Apps</b>`, 'error'); return; }
    const yaAbierta = marcos.has(app.id);
    abrir(app.id);
    const m = marcos.get(app.id);
    const mensaje = { __forja: 'editar', estado: d.estado, archivo: a.nombre };
    if (yaAbierta && m.lista) m.iframe.contentWindow.postMessage(mensaje, '*');
    else {
      m.pendiente = mensaje;
      clearTimeout(m.tAviso);
      m.tAviso = setTimeout(() => {
        if (m.pendiente) Ed.toast(`Esta versión de la app no sabe editar desde el editor: carga la <b>${cual.minima}</b> o más nueva`, 'error');
      }, 8000);
    }
    Ed.toast(`✎ Editando <b>${a.nombre}</b> en ${app.nombre}: lo que cambies vuelve solo`);
  }

  /* 🧾 El generador de una app (para las recetas): su bloque <script id="forja-generador" data-app=… data-generador=…>.
     Devuelve el código del más nuevo que registre esa clave ('forja-terrenos@1'), o null */
  function codigoGenerador(clave) {
    const [app] = clave.split('@');
    const lista = [...apps.values()].sort((x, y) => (y.fecha || 0) - (x.fecha || 0));
    for (const ap of lista) {
      for (const html of [ap.html, ap.anterior && ap.anterior.html]) {
        if (!html) continue;
        const re = /<script\b([^>]*\bid\s*=\s*["']forja-generador["'][^>]*)>([\s\S]*?)<\/script>/gi;
        let m;
        while ((m = re.exec(html))) {
          const attrs = m[1], da = /data-app\s*=\s*["']([^"']+)["']/i.exec(attrs);
          if (da && da[1] !== app) continue;
          // ¿registra esa clave? (el bloque puede traer varias versiones del algoritmo)
          if (m[2].includes(clave) || !da) return { codigo: m[2], app: ap };
        }
      }
    }
    return null;
  }

  // Exportaciones que llegan desde las apps
  window.addEventListener('message', (e) => {
    const d = e.data;
    // la app avisa que ya cargó: si había algo para editar, se lo pasamos
    if (d && d.__forja === 'app-lista') {
      for (const m of marcos.values()) {
        if (m.iframe.contentWindow !== e.source) continue;
        m.lista = true;
        if (m.pendiente) { e.source.postMessage(m.pendiente, '*'); m.pendiente = null; }
      }
      return;
    }
    if (!d || d.__forja !== 'export' || !(d.blob instanceof Blob)) return;
    let origen = '';
    for (const [id, m] of marcos) if (m.iframe.contentWindow === e.source) origen = apps.get(id)?.nombre || '';
    Ed.importarArchivo(d.nombre, d.blob, origen, !!d.vivo);
  });

  Ed.Apps = {
    async iniciar() {
      for (const app of (await DB.todos('apps')) || []) apps.set(app.id, normalizarApp(app));
      pintarLista();
      pintarPestanas();
      $('btnCargarApp').onclick = () => { paraActualizar = null; $('archivoApp').click(); };
      $('archivoApp').onchange = async (e) => {
        const destino = paraActualizar;
        paraActualizar = null;
        if (e.target.files[0]) await cargarApp(e.target.files[0], destino);
        e.target.value = '';
      };
      $('chkDescargar').onchange = () => {
        for (const m of marcos.values()) m.iframe.contentWindow?.postMessage({ __forja: 'descargar', valor: $('chkDescargar').checked }, '*');
      };
    },
    cargarApp,
    irAPestana,
    datosForja,
    editarEnApp,
    codigoGenerador,
    appDe,
    // texto del botón: "✎ Editar en Entorno de Niveles"
    textoEditar: (a) => { const c = appDe(a); return c ? '✎ Editar en ' + c.nombre : ''; },
  };
})(window.FORJA);
