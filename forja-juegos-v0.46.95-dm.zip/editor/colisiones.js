/* =========================================================
   EDITOR · VER COLISIONES
   Dibuja encima de la escena exactamente los triángulos con los que choca el jugador
   (los mismos que usa la física): relleno verde translúcido + líneas.
   Botón "⬡ Colisiones" en la barra del visor, tecla C, o menú Ver. Empieza oculto.
   ========================================================= */
(function (F) {
  'use strict';
  const T = THREE;
  const Ed = F.Editor;
  const $ = (id) => document.getElementById(id);

  let visible = false;
  let grupo = null;
  let temporizador = 0;
  let triangulos = 0;

  const matRelleno = new T.MeshBasicMaterial({
    color: 0x3dff7a, transparent: true, opacity: 0.18, depthWrite: false, side: T.DoubleSide,
    polygonOffset: true, polygonOffsetFactor: -2, polygonOffsetUnits: -2, fog: false,
  });
  const matLineas = new T.LineBasicMaterial({ color: 0x3dff7a, transparent: true, opacity: 0.75, depthWrite: false, fog: false });

  function quitar() {
    if (!grupo) return;
    grupo.parent && grupo.parent.remove(grupo);
    grupo.traverse((o) => o.geometry && o.geometry.dispose());
    grupo = null;
  }

  function construir() {
    quitar();
    if (!visible || Ed.partida) return;   // probando con menús: la escena del editor está escondida
    const tri = F.Fisica.triangulosDe(Ed.escena.entidades, Ed.objetos);
    grupo = new T.Group();
    grupo.name = 'ver-colisiones';
    grupo.userData.ayudaEditor = true;
    grupo.renderOrder = 1e6;
    if (tri.length) {
      const geo = new T.BufferGeometry();
      geo.setAttribute('position', new T.BufferAttribute(tri, 3));
      const relleno = new T.Mesh(geo, matRelleno);
      relleno.renderOrder = 1e6;
      relleno.userData.ayudaEditor = true;
      relleno.raycast = () => {};   // no estorba al hacer clic en el visor
      // líneas: las aristas de cada triángulo (WireframeGeometry)
      const lineas = new T.LineSegments(new T.WireframeGeometry(geo), matLineas);
      lineas.renderOrder = 1e6 + 1;
      lineas.userData.ayudaEditor = true;
      lineas.raycast = () => {};
      grupo.add(relleno, lineas);
    }
    Ed.vista.escena.add(grupo);
    triangulos = tri.length / 9;
    actualizarBoton();
  }

  // Muchos cambios seguidos (arrastrar con el gizmo) → reconstruir una sola vez al final
  function pedirReconstruir() {
    if (!visible) return;
    clearTimeout(temporizador);
    temporizador = setTimeout(construir, 250);
  }

  function actualizarBoton() {
    const b = $('btnColisiones');
    if (!b) return;
    b.classList.toggle('activo', visible);
    b.title = visible
      ? `Ocultar colisiones (C) · ${F.util.fmt(triangulos)} triángulos chocan`
      : 'Ver colisiones (C): lo que el jugador toca, en verde';
  }

  function alternar(v = !visible) {
    visible = v;
    if (visible) construir();
    else quitar();
    actualizarBoton();
    F.emitir('editor-colisiones', visible);
  }

  // Se rehace cuando la escena cambia (guardarLocal se llama tras cada cambio)
  const guardarOriginal = Ed.guardarLocal;
  Ed.guardarLocal = function () {
    guardarOriginal.apply(this, arguments);
    pedirReconstruir();
  };
  F.on('escena-reconstruida', pedirReconstruir);
  F.on('entidad-reconstruida', pedirReconstruir);
  // Al jugar se reconstruye con la escena en su lugar (útil para ver por dónde se puede caminar)
  F.on('juego-iniciado', () => { if (visible) construir(); });
  F.on('juego-detenido', () => { if (visible) pedirReconstruir(); });

  $('btnColisiones').onclick = () => { alternar(); $('btnColisiones').blur(); };
  actualizarBoton();

  Ed.Colisiones = { alternar, visible: () => visible, reconstruir: construir };
})(window.FORJA);
