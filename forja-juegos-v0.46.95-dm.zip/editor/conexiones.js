/* =========================================================
   EDITOR · LÍNEAS DE CONEXIÓN (Fase 5)
   Con una 🕹 palanca seleccionada: línea NARANJA a cada cosa de su lista "Qué hace" y CIAN a lo que escucha
   los canales que avisa. Con una puerta, luz, marcador, aparecedor u otra palanca seleccionada: las líneas
   de quien la mueve. Solo en el editor (no al jugar). Se rehace 5 veces por segundo como mucho.
   ========================================================= */
(function (F) {
  'use strict';
  const Ed = F.Editor;
  const T = THREE;
  let lineas = null, reloj = 0, ultimaClave = '';
  const _a = new T.Vector3(), _b = new T.Vector3();

  function crear() {
    const geo = new T.BufferGeometry();
    geo.setAttribute('position', new T.BufferAttribute(new Float32Array(6 * 64), 3));
    geo.setAttribute('color', new T.BufferAttribute(new Float32Array(6 * 64), 3));
    lineas = new T.LineSegments(geo, new T.LineBasicMaterial({ vertexColors: true, depthTest: false, transparent: true, opacity: 0.95, fog: false }));
    lineas.renderOrder = 1e6;
    lineas.frustumCulled = false;
    lineas.userData.ayudaEditor = true;
    lineas.raycast = () => {};
    Ed.vista.escena.add(lineas);
  }
  // al jugar (▶ o "Probar con menús") nunca se ven
  F.on('juego-iniciado', () => { if (lineas) lineas.visible = false; });

  // pares [desde, hasta, color] para la selección actual
  function pares(sel) {
    const ents = Ed.escena.entidades, r = [];
    const NARANJA = [1, 0.64, 0.24], CIAN = [0.3, 0.85, 1];
    const canal = (x) => String(x || '').trim().toLowerCase();
    const oyentes = (c) => ents.filter((e) => c && ((e.puerta && canal(e.puerta.canal) === c) || (e.palanca && canal(e.palanca.canal) === c) || (e.disparador && canal(e.disparador.canal) === c)));
    const VERDE = [0.37, 0.88, 0.63];
    for (const e of ents) {
      if (e.condicion) for (const q of e.condicion.requisitos || []) if (q.a && (e.id === sel || q.a === sel)) r.push([q.a, e.id, VERDE]);
      const d = e.palanca || e.disparador || e.pedestal || e.condicion;
      if (!d) continue;
      for (const a of d.acciones || []) {
        if (a.a && (e.id === sel || a.a === sel)) r.push([e.id, a.a, NARANJA]);
        if (a.que === 'canal' && a.canal) for (const o of oyentes(canal(a.canal))) if (o !== e && (e.id === sel || o.id === sel)) r.push([e.id, o.id, CIAN]);
      }
    }
    // 📍 la ruta de patrulla: el punto seleccionado, o el enemigo / aparecedor que la usa → sus puntos en orden (y vuelta)
    const se = ents.find((e) => e.id === sel);
    const ruta = se && (se.tipo === 'punto' ? se.punto && se.punto.ruta : se.enemigo ? se.enemigo.patrulla : se.aparecedor ? se.aparecedor.puntos : '');
    if (ruta) {
      const AMARILLO = [1, 0.85, 0.2];
      const pts = ents.filter((e) => e.tipo === 'punto' && e.punto && canal(e.punto.ruta) === canal(ruta)).sort((a, b) => (a.punto.orden || 0) - (b.punto.orden || 0));
      for (let i = 0; i < pts.length - 1; i++) r.push([pts[i].id, pts[i + 1].id, AMARILLO]);
      if (pts.length > 2) r.push([pts[pts.length - 1].id, pts[0].id, AMARILLO]);
      if (se.tipo === 'enemigo' && pts.length) r.push([se.id, pts[0].id, AMARILLO]);
    }
    return r;
  }

  Ed.pintarConexiones = function (dt = 0) {
    if (!Ed.vista || !Ed.escena) return;
    if (!lineas) crear();
    const sel = !Ed.jugando && !Ed.partida && Ed.seleccion;
    lineas.visible = !!sel;
    if (!sel) return;
    reloj -= dt;
    const clave = sel + '|' + Ed.escena.id;
    if (reloj > 0 && clave === ultimaClave) return;
    reloj = 0.2;
    ultimaClave = clave;
    const lista = pares(sel).slice(0, 64);
    const pos = lineas.geometry.attributes.position, col = lineas.geometry.attributes.color;
    let n = 0;
    for (const [de, a, c] of lista) {
      const oa = Ed.objetos.get(de), ob = Ed.objetos.get(a);
      if (!oa || !ob) continue;
      oa.getWorldPosition(_a); ob.getWorldPosition(_b);
      _a.y += 0.6; _b.y += 0.8;
      pos.setXYZ(n * 2, _a.x, _a.y, _a.z); pos.setXYZ(n * 2 + 1, _b.x, _b.y, _b.z);
      col.setXYZ(n * 2, c[0], c[1], c[2]); col.setXYZ(n * 2 + 1, c[0], c[1], c[2]);
      n++;
    }
    lineas.geometry.setDrawRange(0, n * 2);
    pos.needsUpdate = col.needsUpdate = true;
    lineas.visible = n > 0;
  };
})(window.FORJA);
