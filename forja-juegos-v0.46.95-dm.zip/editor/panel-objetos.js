/* =========================================================
   EDITOR · JUEGO ▸ OBJETOS
   Biblioteca de objetos de la mochila (proyecto.objetos) y sus RECETAS de combinar (proyecto.recetas).
   Se ponen en el mapa con un ✚ recogible de tipo "Objeto"; el jugador necesita el módulo Inventario.
   ========================================================= */
(function (F) {
  'use strict';
  const Ed = F.Editor;
  const $ = (id) => document.getElementById(id);
  const S = F.Escena;
  let elegido = null;

  const TIPOS = [['cura', '✚ Cura'], ['llave', '🗝 Llave'], ['clave', '🧩 Objeto clave (puzle)'], ['nota', '📄 Nota (se lee)'], ['mochila', '🎒 Mochila (+casillas)'], ['otro', '◆ Otro (para combinar)']];
  const ESQUEMA = [
    { k: 'nombre', t: 'texto', e: 'Nombre' },
    { k: 'tipo', t: 'sel', e: 'Tipo', op: TIPOS },
    { k: 'icono', t: 'texto', e: 'Icono', ayuda: 'Un carácter o emoji para su casilla: 🌿 🧴 🗝 📄 💎' },
    { k: 'color', t: 'color', e: 'Color' },
    { k: 'descripcion', t: 'textoLargo', e: 'Descripción', filas: 2, ayuda: 'Sale al elegirlo en la mochila' },
    { k: 'pila', t: 'num', e: 'Cuántos caben en una casilla', paso: 1, min: 1 },
    { k: 'vida', t: 'num', e: 'Vida que cura', paso: 5, min: 0, si: (v) => v.tipo === 'cura' },
    { k: 'armadura', t: 'num', e: 'Armadura que da', paso: 5, min: 0, si: (v) => v.tipo === 'cura' },
    { k: 'casillas', t: 'num', e: 'Casillas que añade', paso: 1, min: 1, si: (v) => v.tipo === 'mochila' },
    { k: 'texto', t: 'textoLargo', e: 'Lo que dice', filas: 4, si: (v) => v.tipo === 'nota' },
    { grupo: 'Cómo se ve en el mapa y al examinarlo' },
    { k: 'forma', t: 'sel', e: 'Figura del motor', op: [['frasco', 'Frasco'], ['hierba', 'Hierba en maceta'], ['llave', 'Llave'], ['caja', 'Caja'], ['papel', 'Papel'], ['bolsa', 'Bolsa / mochila']], si: (v) => !v.modelo },
    { k: 'modelo', t: 'asset', e: 'Modelo', tipoAsset: 'modelo', vacio: '(figura del motor)' },
    { k: 'sonido', t: 'asset', e: 'Sonido al usarlo', tipoAsset: 'audio', vacio: '(del motor)', av: true },
  ];

  // 💰 Divisas del proyecto: nombre, icono (emoji o imagen), color, tope y si se guardan en el baúl
  const ESQ_DIVISA = [
    { k: 'nombre', t: 'texto', e: 'Nombre' },
    { k: 'icono', t: 'texto', e: 'Icono', ayuda: 'Emoji o carácter: 🪙 💎 💰 ⭐ 🔩. Se usa si no hay imagen' },
    { k: 'imagen', t: 'asset', e: 'Imagen del icono', tipoAsset: 'textura', vacio: '(usar el emoji)' },
    { k: 'color', t: 'color', e: 'Color' },
    { k: 'max', t: 'num', e: 'Máximo (0 = sin tope)', paso: 1, min: 0 },
    { k: 'enBaul', t: 'bool', e: 'Se puede guardar en el baúl' },
  ];
  function pintarDivisas(p, P) {
    Ed.titulo(p, '💰 Divisas');
    Ed.nota(p, 'Monedas, oro, gemas… Se recogen con un <b>✚ recogible</b> de tipo "Divisa" y se gastan en las <b>tiendas</b> (cada artículo dice con cuál se paga). Se ven en el HUD y en la mochila.');
    if (!Array.isArray(P.divisas) || !P.divisas.length) P.divisas = [{ ...F.Divisas.BASE }];
    const L = P.divisas;
    L.forEach((d, i) => {
      const c = document.createElement('div');
      c.className = 'accion';
      Ed.formulario(c, ESQ_DIVISA, d, (k, v, definitivo) => { if (definitivo) Ed.guardarLocal(); }, { defectos: F.Divisas.BASE });
      const b = [];
      if (i > 0) b.push(['↑', () => { L.splice(i - 1, 0, L.splice(i, 1)[0]); Ed.guardarLocal(); Ed.construirPanelObjetos(); }]);
      if (L.length > 1) b.push(['Quitar', () => { if (!confirm(`¿Quitar la divisa "${d.nombre}"? Recogibles y artículos que la usen pasarán a la primera.`)) return; L.splice(i, 1); Ed.guardarLocal(); Ed.construirPanelObjetos(); }, 'peligro']);
      if (b.length) Ed.botonera(c, b);
      p.appendChild(c);
    });
    Ed.botonera(p, [['＋ Divisa', () => { L.push({ ...F.Divisas.BASE, id: F.util.uid(), nombre: 'Gemas', icono: '💎', color: '#5fd3e8' }); Ed.guardarLocal(); Ed.construirPanelObjetos(); }, 'primario']]);
    Ed.nota(p, 'La primera es la de serie: la usan los recogibles y artículos que no dicen divisa, y lo que sueltan los enemigos.');
  }

  Ed.construirPanelObjetos = function () {
    const p = $('panelObjetos');
    if (!p) return;
    const scroll = p.scrollTop;
    p.innerHTML = '';
    const P = Ed.proyecto;
    const obs = P.objetos || (P.objetos = F.Inventario.objetosPorDefecto());
    const recetas = P.recetas || (P.recetas = []);
    if (!obs.some((o) => o.id === elegido)) elegido = obs[0] ? obs[0].id : null;

    Ed.cabeceraPanel(p, 'Objetos de la mochila', () => {
      const faltan = F.Inventario.objetosPorDefecto().filter((d) => !obs.some((o) => o.id === d.id));
      if (!faltan.length) { Ed.toast('Ya están todos los objetos de serie'); return; }
      if (!confirm(`¿Añadir de nuevo ${faltan.length} objeto(s) de serie que faltan? Los tuyos no se tocan.`)) return;
      obs.push(...faltan);
      Ed.guardarLocal();
      Ed.construirPanelObjetos();
    }, 'Vuelve a añadir los objetos de serie que hayas borrado');

    const m = P.jugador.modulos.inventario;
    if (!m || !m.activo) {
      const n = Ed.nota(p, '⚠ El módulo <b>Inventario</b> está apagado. ');
      const b = document.createElement('button');
      b.textContent = 'Activarlo';
      b.onclick = () => { P.jugador.modulos.inventario.activo = true; Ed.construirPanelJugador && Ed.construirPanelJugador(); Ed.guardarLocal(); Ed.construirPanelObjetos(); };
      n.appendChild(b);
    }
    Ed.nota(p, 'Ponlos en el mapa con un <b>✚ recogible</b> de tipo "Objeto". En el juego, <b>Tab</b> o <b>I</b> abre la mochila.');

    const lista = document.createElement('div');
    lista.className = 'lista-armas';
    for (const o of obs) {
      const el = document.createElement('div');
      el.className = 'item' + (o.id === elegido ? ' sel' : '');
      el.innerHTML = '<span></span><span class="nom"></span><span class="meta"></span>';
      el.firstChild.textContent = o.icono || '◆';
      el.firstChild.style.color = o.color;
      el.querySelector('.nom').textContent = o.nombre;
      el.querySelector('.meta').textContent = (TIPOS.find((t) => t[0] === o.tipo) || ['', ''])[1].replace(/^\S+\s/, '');
      el.onclick = () => { elegido = o.id; Ed.construirPanelObjetos(); };
      lista.appendChild(el);
    }
    p.appendChild(lista);
    const idx = obs.findIndex((o) => o.id === elegido), ob = obs[idx];
    Ed.botonera(p, [
      ['＋ Nuevo', () => { const o = F.Inventario.objetoNuevo({ nombre: 'Objeto ' + (obs.length + 1) }); obs.push(o); elegido = o.id; Ed.guardarLocal(); Ed.construirPanelObjetos(); }],
      ['Duplicar', () => { if (!ob) return; const o = { ...F.util.copiar(ob), id: F.util.uid(), nombre: ob.nombre + ' 2' }; obs.splice(idx + 1, 0, o); elegido = o.id; Ed.guardarLocal(); Ed.construirPanelObjetos(); }],
      ['✚ Poner en la escena', () => {
        if (!ob) return;
        Ed.agregarEntidad('recogible', { nombre: ob.nombre, recogible: { ...F.Recogibles.BASE, tipo: 'objeto', objeto: ob.id, cantidad: 1, recoger: 'usar', soloSiFalta: false } });
        Ed.abrirPanel('panelInspector');
      }, 'primario', 'Un recogible que lo mete en la mochila (con el botón de usar, estilo RE)'],
      ['Borrar', () => {
        if (!ob || !confirm(`¿Borrar "${ob.nombre}"? Las recetas que lo usan también se borran.`)) return;
        obs.splice(idx, 1);
        P.recetas = recetas.filter((r) => r.a !== ob.id && r.b !== ob.id && r.da !== ob.id);
        Ed.guardarLocal();
        Ed.construirPanelObjetos();
      }, 'peligro'],
    ]);
    if (ob) {
      Ed.titulo(p, '✎ ' + ob.nombre);
      Ed.formulario(p, ESQUEMA, ob, (k, v, definitivo) => {
        if (['nombre', 'icono', 'color', 'tipo'].includes(k) && definitivo) { Ed.guardarLocal(); Ed.construirPanelObjetos(); return; }
        if (definitivo) Ed.guardarLocal();
      }, { defectos: F.Inventario.OBJETO });
    }

    // Recetas: A + B → resultado
    Ed.titulo(p, 'Recetas (combinar)');
    Ed.nota(p, 'Dos objetos que se combinan en la mochila y lo que dan. La munición con su arma se combina sola (recarga).');
    const op = obs.map((o) => [o.id, `${o.icono || ''} ${o.nombre}`.trim()]);
    const sel = (valor, alCambiar) => {
      const s = document.createElement('select');
      if (!obs.some((o) => o.id === valor)) s.add(new Option('⚠ (ya no existe)', valor || ''));
      for (const [v, t] of op) s.add(new Option(t, v, false, v === valor));
      s.onchange = () => { alCambiar(s.value); Ed.guardarLocal(); };
      return s;
    };
    const caja = document.createElement('div');
    caja.className = 'filas-criaturas';
    P.recetas.forEach((r, i) => {
      const fila = document.createElement('div');
      fila.className = 'fila-cr fila-receta';
      const mas = document.createElement('span'); mas.textContent = '+';
      const da = document.createElement('span'); da.textContent = '→';
      const n = document.createElement('input');
      n.type = 'number'; n.min = 1; n.value = r.n || 1; n.title = 'Cuántos da';
      n.onchange = () => { r.n = Math.max(1, Math.round(+n.value || 1)); Ed.guardarLocal(); };
      const x = document.createElement('button');
      x.textContent = '✕';
      x.onclick = () => { P.recetas.splice(i, 1); Ed.guardarLocal(); Ed.construirPanelObjetos(); };
      fila.append(sel(r.a, (v) => { r.a = v; }), mas, sel(r.b, (v) => { r.b = v; }), da, sel(r.da, (v) => { r.da = v; }), n, x);
      caja.appendChild(fila);
    });
    const nueva = document.createElement('button');
    nueva.textContent = '＋ Receta';
    nueva.disabled = obs.length < 2;
    nueva.onclick = () => { P.recetas.push({ a: obs[0].id, b: obs[1].id, da: obs[0].id, n: 1 }); Ed.guardarLocal(); Ed.construirPanelObjetos(); };
    caja.appendChild(nueva);
    p.appendChild(caja);

    // La mochila al empezar (nueva partida): objetos de la biblioteca y, con "armas dentro", munición
    Ed.titulo(p, 'La mochila al empezar');
    Ed.nota(p, 'Con qué empieza el jugador una partida nueva. Al pasar de nivel o cargar una partida se conserva lo que lleve.');
    const ini = P.inventarioInicial || (P.inventarioInicial = []);
    const opIni = [...obs.map((o) => ['obj:' + o.id, `${o.icono || ''} ${o.nombre}`.trim()]),
      ...(P.municiones || []).map((m) => ['mun:' + m.id, `▮ ${m.nombre} (munición)`])];
    const cajaIni = document.createElement('div');
    cajaIni.className = 'filas-criaturas';
    ini.forEach((x, i) => {
      const fila = document.createElement('div');
      fila.className = 'fila-cr fila-receta';
      const s = document.createElement('select');
      const valor = (x.k || 'obj') + ':' + x.id;
      if (!opIni.some((o) => o[0] === valor)) s.add(new Option('⚠ (ya no existe)', valor));
      for (const [v, t] of opIni) s.add(new Option(t, v, false, v === valor));
      s.onchange = () => { Ed.marcarCambio && Ed.marcarCambio(); const [k, id] = s.value.split(':'); x.k = k; x.id = id; Ed.guardarLocal(); };
      const n = document.createElement('input');
      n.type = 'number'; n.min = 1; n.value = x.n || 1; n.title = 'Cuántos';
      n.onchange = () => { x.n = Math.max(1, Math.round(+n.value || 1)); Ed.guardarLocal(); };
      const q = document.createElement('button');
      q.textContent = '✕';
      q.onclick = () => { ini.splice(i, 1); Ed.guardarLocal(); Ed.construirPanelObjetos(); };
      fila.append(s, n, q);
      cajaIni.appendChild(fila);
    });
    const masIni = document.createElement('button');
    masIni.textContent = '＋ Objeto al empezar';
    masIni.disabled = !opIni.length;
    masIni.onclick = () => { const [k, id] = opIni[0][0].split(':'); ini.push({ k, id, n: 1 }); Ed.guardarLocal(); Ed.construirPanelObjetos(); };
    cajaIni.appendChild(masIni);
    p.appendChild(cajaIni);
    if (!(P.jugador && P.jugador.modulos && P.jugador.modulos.inventario && P.jugador.modulos.inventario.activo) && ini.length) Ed.nota(p, '⚠ Activa el módulo <b>Inventario</b> (pestaña Jugador) para que se use.');
    pintarDivisas(p, P);
    p.scrollTop = scroll;
  };

  document.querySelector('[data-panel="panelObjetos"]').addEventListener('click', () => Ed.construirPanelObjetos());
})(window.FORJA);
