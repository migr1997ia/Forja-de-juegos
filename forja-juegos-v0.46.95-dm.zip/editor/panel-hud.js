/* =========================================================
   EDITOR · JUEGO ▸ HUD
   Qué se ve en pantalla mientras se juega (proyecto.hud) y dónde: plantillas (Clásico, Quake, Halo, Survival,
   Arcade, Mínimo), posiciones, qué piezas se muestran, estilo y mira. Con vista previa al momento.
   Lo dibuja motor/hud.js; los colores de las barras son del módulo "Salud y muerte".
   ========================================================= */
(function (F) {
  'use strict';
  const Ed = F.Editor;
  const $ = (id) => document.getElementById(id);
  const S = F.Escena;

  Ed.construirPanelHud = function () {
    const p = $('panelHud');
    if (!p) return;
    const scroll = p.scrollTop;
    p.innerHTML = '';
    const hud = Ed.proyecto.hud || (Ed.proyecto.hud = S.hudPorDefecto());

    Ed.cabeceraPanel(p, 'HUD del juego', () => {
      if (!confirm('¿Volver al HUD de serie?')) return;
      Ed.proyecto.hud = S.hudPorDefecto();
      Ed.guardarLocal();
      Ed.construirPanelHud();
    }, 'Todo el HUD como recién creado');

    // vista previa (16:9) con valores de ejemplo
    const caja = document.createElement('div');
    caja.className = 'previa-hud';
    p.appendChild(caja);
    const repintar = () => { const capa = F.Hud.vistaPrevia(caja, Ed.proyecto); if (hud.posicion === 'libre') arrastrable(caja, capa); };

    /* ✥ Libre: cada pieza de la vista previa se arrastra con el ratón (o el dedo). Al soltarla se guarda su punto
       en % de la pantalla (hud.libre[pieza] = [x, y]); el juego la pone en el mismo sitio a cualquier tamaño. */
    function arrastrable(caja, capa) {
      const piezas = capa.querySelectorAll('[data-fh-pieza]');
      for (const el of piezas) {
        Object.assign(el.style, { pointerEvents: 'auto', cursor: 'move', outline: '1px dashed rgba(255,210,74,.75)', outlineOffset: '2px' });
        el.title = 'Arrastra para moverla';
        el.onpointerdown = (ev) => {
          ev.preventDefault();
          const caj = caja.getBoundingClientRect(), r0 = el.getBoundingClientRect();
          const dx = ev.clientX - r0.left, dy = ev.clientY - r0.top;
          // la pieza sale de su zona y se mueve suelta (en px) mientras se arrastra
          if (el.parentNode !== capa) capa.appendChild(el);
          el.classList.add('fh-libre');
          Object.assign(el.style, { left: r0.left - caj.left + 'px', top: r0.top - caj.top + 'px', right: 'auto', bottom: 'auto', transform: 'none', margin: '0', outline: '1px solid #ffd24a' });
          // (la captura va después de cambiarla de sitio en la página: moverla la suelta)
          try { el.setPointerCapture(ev.pointerId); } catch (e) { /* sin captura también funciona dentro de la caja */ }
          el.onpointermove = (e) => {
            el.style.left = Math.max(0, Math.min(caj.width - r0.width, e.clientX - caj.left - dx)) + 'px';
            el.style.top = Math.max(0, Math.min(caj.height - r0.height, e.clientY - caj.top - dy)) + 'px';
          };
          el.onpointerup = () => {
            el.onpointermove = el.onpointerup = null;
            // el punto que se guarda: el borde o el centro según el tercio (como lo pone el juego)
            const r = el.getBoundingClientRect();
            const cx = (r.left + r.width / 2 - caj.left) / caj.width * 100, cy = (r.top + r.height / 2 - caj.top) / caj.height * 100;
            const x = cx < 33.3 ? (r.left - caj.left) / caj.width * 100 : cx > 66.6 ? (r.right - caj.left) / caj.width * 100 : cx;
            const y = cy < 33.3 ? (r.top - caj.top) / caj.height * 100 : cy > 66.6 ? (r.bottom - caj.top) / caj.height * 100 : cy;
            hud.libre = { ...(hud.libre || {}), [el.dataset.fhPieza]: [+x.toFixed(1), +y.toFixed(1)] };
            Ed.guardarLocal();
            repintar();
          };
        };
      }
    }
    requestAnimationFrame(repintar);   // necesita el tamaño real de la caja

    Ed.titulo(p, 'Plantillas');
    const pl = document.createElement('div');
    pl.className = 'acciones';
    for (const [clave, val] of Object.entries(S.PLANTILLAS_HUD)) {
      const b = document.createElement('button');
      b.textContent = val.nombre;
      b.onclick = () => {
        const { nombre, ...resto } = val;
        Object.assign(hud, resto);
        hud.plantilla = clave;
        Ed.guardarLocal();
        Ed.construirPanelHud();
      };
      pl.appendChild(b);
    }
    p.appendChild(pl);
    Ed.nota(p, 'Una plantilla cambia posiciones y estilo; luego ajusta lo que quieras. Los colores de vida y armadura están en Jugador ▸ Salud y muerte.');

    if (hud.posicion === 'libre') {
      Ed.nota(p, '✥ <b>Libre</b>: arrastra las piezas de la vista previa (las de borde punteado). Las que no muevas van como en Esquinas. La mira siempre va al centro. Las piezas de otros módulos que no salen aquí también van como en Esquinas.');
      const ac = document.createElement('div');
      ac.className = 'acciones';
      const b = document.createElement('button');
      b.textContent = '↺ Volver a colocar todo';
      b.title = 'Borra las posiciones movidas a mano';
      b.onclick = () => { hud.libre = {}; Ed.guardarLocal(); repintar(); };
      ac.appendChild(b);
      p.appendChild(ac);
    }

    Ed.formulario(p, S.ESQUEMA_HUD, hud, (k, v, definitivo) => {
      if (k === 'posicion' && definitivo) { Ed.guardarLocal(); Ed.construirPanelHud(); return; }   // aparece / se va lo de "Libre"
      repintar();
      if (definitivo) Ed.guardarLocal();
    }, { defectos: S.hudPorDefecto() });

    const m = Ed.proyecto.jugador.modulos;
    if (!m.salud?.activo) Ed.nota(p, 'ℹ La vida y la armadura salen con el módulo <b>Salud y muerte</b> (Jugador).');
    if (!m.armas?.activo) Ed.nota(p, 'ℹ La munición sale con el módulo <b>Armas</b> (Jugador).');
    p.scrollTop = scroll;
  };

  document.querySelector('[data-panel="panelHud"]').addEventListener('click', () => Ed.construirPanelHud());
})(window.FORJA);
