/* =========================================================
   EDITOR · 🎵 ONDA DE LA MÚSICA (como el importador de audio de Godot)
   Dibuja la forma de onda de una pista y deja ajustar el bucle a ojo:
     · Asa VERDE  = "el bucle vuelve a" (inicio).  · Asa ROJA = "el bucle termina en" (fin).
     · Arrastra las asas. Clic en la onda = escuchar desde ahí. Rueda = zoom, arrastrar con botón
       derecho / central (o Mayús + arrastrar) = moverse. Doble clic = ver todo.
     · La línea blanca es por dónde va la música mientras suena.
     · "Imán" acerca la asa al cruce por cero más cercano (evita el "clic" al volver el bucle).
   Ed.ondaMusica(cont, idAsset, valores, { kIni, kFin, volumen, alCambiar, alSoltar })
   ========================================================= */
(function (F) {
  'use strict';
  const Ed = (F.Editor = F.Editor || {});

  const cache = new Map();   // idAsset -> { dur, canales:[Float32Array], picos (por resolución) }
  let ctxDec = null;
  const vistas = new Map();   // idAsset -> [v0, v1] (el zoom se conserva al repintar el panel)

  async function decodificar(a) {
    if (cache.has(a.id)) return cache.get(a.id);
    const pr = (async () => {
      ctxDec = ctxDec || new (window.AudioContext || window.webkitAudioContext)();
      let datos = a.datos;
      if (!datos && a.url) datos = await (await fetch(a.url)).arrayBuffer();
      const buf = await ctxDec.decodeAudioData(datos.slice(0));
      // mezcla a mono (para dibujar y buscar cruces por cero)
      const n = buf.length, mono = new Float32Array(n);
      for (let c = 0; c < buf.numberOfChannels; c++) { const d = buf.getChannelData(c); for (let i = 0; i < n; i++) mono[i] += d[i] / buf.numberOfChannels; }
      return { dur: buf.duration, frec: buf.sampleRate, mono };
    })();
    cache.set(a.id, pr);
    try { return await pr; } catch (e) { cache.delete(a.id); throw e; }
  }

  function fmt(t) {
    const m = Math.floor(t / 60), s = t - m * 60;
    return m + ':' + (s < 10 ? '0' : '') + s.toFixed(2);
  }

  Ed.ondaMusica = function (cont, idAsset, val, op = {}) {
    const kIni = op.kIni || 'inicio', kFin = op.kFin || 'fin';
    const caja = document.createElement('div');
    caja.className = 'onda-musica';
    caja.style.cssText = 'margin:6px 0;border:1px solid #333;border-radius:4px;background:#0d0f14;padding:4px;';
    const cv = document.createElement('canvas');
    cv.style.cssText = 'width:100%;height:96px;display:block;cursor:crosshair;touch-action:none;';
    const info = document.createElement('div');
    info.style.cssText = 'display:flex;justify-content:space-between;font:11px monospace;color:#aaa;margin-top:3px;gap:6px;flex-wrap:wrap;';
    caja.append(cv, info);
    const barra = document.createElement('div');
    barra.className = 'acciones';
    caja.appendChild(barra);
    cont.appendChild(caja);

    const a = F.Assets && F.Assets.mapa.get(idAsset);
    const g = cv.getContext('2d');
    let D = null, v0 = 0, v1 = 1, arrastra = null, iman = true, raf = 0;
    const leerIni = () => Math.max(0, val[kIni] || 0);
    const leerFin = () => (val[kFin] > 0 ? Math.min(val[kFin], D ? D.dur : val[kFin]) : (D ? D.dur : 0));

    function boton(t, fn, ayuda) { const b = document.createElement('button'); b.textContent = t; b.onclick = fn; if (ayuda) b.title = ayuda; barra.appendChild(b); return b; }
    const sonando = () => { const m = F.Audio.musicaActual && F.Audio.musicaActual(); return m && m.id === idAsset ? m : null; };
    function tocar(desde) {
      F.Audio.pararMusica();
      F.Audio.musica(idAsset, { volumen: op.volumen ? op.volumen() : 1, inicio: leerIni(), fin: val[kFin] || 0, fundido: 0 });
      setTimeout(() => { const el = F.Audio._pista && F.Audio._pista(); if (el) el.currentTime = Math.max(0, desde); }, 60);
      animar();
    }
    boton('▶ Desde el principio', () => tocar(0));
    boton('⏭ Escuchar el corte', () => tocar(Math.max(0, leerFin() - 3)), 'Suena 3 s antes del final del bucle para oír cómo empalma con el inicio');
    boton('■ Parar', () => { F.Audio.pararMusica(); dibujar(); });
    const bIman = boton('🧲 Imán: sí', () => { iman = !iman; bIman.textContent = '🧲 Imán: ' + (iman ? 'sí' : 'no'); }, 'Al soltar una asa la acerca al cruce por cero más cercano (bucle sin "clic")');
    boton('↺ Sin bucle propio', () => { val[kIni] = 0; val[kFin] = 0; cambio(true); }, 'Vuelve a repetir el archivo entero');

    function x2t(px) { const r = cv.getBoundingClientRect(); return v0 + (v1 - v0) * F.util.clamp(px / r.width, 0, 1); }
    function t2x(t, W) { return ((t - v0) / (v1 - v0)) * W; }

    function dibujar() {
      if (D) vistas.set(idAsset, [v0, v1]);
      const r = cv.getBoundingClientRect(), dpr = window.devicePixelRatio || 1;
      const W = Math.max(50, Math.round(r.width * dpr)), H = Math.round(96 * dpr);
      if (cv.width !== W || cv.height !== H) { cv.width = W; cv.height = H; }
      g.fillStyle = '#0d0f14'; g.fillRect(0, 0, W, H);
      if (!D) { g.fillStyle = '#888'; g.font = 12 * dpr + 'px sans-serif'; g.fillText(a ? 'Leyendo la onda…' : 'Sin pista', 8, H / 2); return; }
      const ti = leerIni(), tf = leerFin();
      // zona del bucle
      const xi = t2x(ti, W), xf = t2x(tf, W);
      g.fillStyle = 'rgba(70,160,255,0.10)'; g.fillRect(xi, 0, xf - xi, H);
      // onda (pico por columna)
      const m = D.mono, fr = D.frec, mid = H / 2;
      g.fillStyle = '#4fa3ff';
      for (let x = 0; x < W; x++) {
        const a0 = Math.floor((v0 + (v1 - v0) * (x / W)) * fr), a1 = Math.max(a0 + 1, Math.floor((v0 + (v1 - v0) * ((x + 1) / W)) * fr));
        let mn = 0, mx = 0;
        const paso = Math.max(1, Math.floor((a1 - a0) / 256));
        for (let i = a0; i < a1 && i < m.length; i += paso) { const s = m[i]; if (s < mn) mn = s; if (s > mx) mx = s; }
        const dentro = (v0 + (v1 - v0) * (x / W)) >= ti && (v0 + (v1 - v0) * (x / W)) <= tf;
        g.fillStyle = dentro ? '#4fa3ff' : '#355a80';
        g.fillRect(x, mid - mx * mid * 0.95, 1, Math.max(1, (mx - mn) * mid * 0.95));
      }
      g.fillStyle = '#222'; g.fillRect(0, mid, W, 1);
      // regla de segundos
      g.fillStyle = '#666'; g.font = 10 * dpr + 'px monospace';
      const span = v1 - v0, pasos = [0.1, 0.25, 0.5, 1, 2, 5, 10, 15, 30, 60];
      const st = pasos.find((p) => span / p < Math.max(3, W / dpr / 55)) || 60;
      for (let t = Math.ceil(v0 / st) * st; t <= v1; t += st) { const x = t2x(t, W); g.fillRect(x, H - 6 * dpr, 1, 6 * dpr); g.fillText(st >= 1 ? (t >= 60 ? fmt(t).slice(0, -3) : Math.round(t) + 's') : t.toFixed(st < 0.25 ? 2 : 1) + 's', x + 2, H - 7 * dpr); }
      // asas
      const asa = (x, col, txt) => {
        g.fillStyle = col; g.fillRect(x - dpr, 0, 2 * dpr, H);
        g.beginPath(); g.moveTo(x - 7 * dpr, 0); g.lineTo(x + 7 * dpr, 0); g.lineTo(x, 10 * dpr); g.fill();
        g.font = 'bold ' + 10 * dpr + 'px monospace'; g.fillText(txt, x + 4 * dpr, 20 * dpr);
      };
      asa(xi, '#3aff6a', 'INICIO');
      asa(xf, '#ff4a4a', 'FIN');
      // por dónde va
      const s = sonando();
      if (s) { g.fillStyle = '#fff'; g.fillRect(t2x(s.t, W), 0, dpr, H); }
      info.innerHTML = '<span style="color:#3aff6a">▶ vuelve a ' + fmt(ti) + '</span><span style="color:#ff4a4a">■ termina en ' + fmt(tf) + (val[kFin] > 0 ? '' : ' (final)') + '</span><span>bucle ' + (tf - ti).toFixed(2) + ' s · total ' + fmt(D.dur) + (s ? ' · ♪ ' + fmt(s.t) : '') + '</span>';
    }
    function animar() {
      if (raf) return;
      const f = () => { raf = 0; if (!caja.isConnected) return; dibujar(); if (sonando()) raf = requestAnimationFrame(f); };
      raf = requestAnimationFrame(f);
    }

    // acerca t al cruce por cero (subida) más cercano, ±15 ms
    function alCero(t) {
      if (!iman || !D) return t;
      const m = D.mono, c = Math.round(t * D.frec), r = Math.round(0.015 * D.frec);
      for (let d = 0; d < r; d++) for (const i of [c + d, c - d]) if (i > 0 && i < m.length && m[i - 1] <= 0 && m[i] > 0) return i / D.frec;
      return t;
    }
    function cambio(soltar) {
      if (op.alCambiar) op.alCambiar(soltar);
      dibujar();
      if (soltar && op.alSoltar) op.alSoltar();
    }

    let panX = null;
    cv.addEventListener('contextmenu', (e) => e.preventDefault());
    cv.addEventListener('pointerdown', (e) => {
      if (!D) return;
      const r = cv.getBoundingClientRect(), px = e.clientX - r.left, W = r.width;
      cv.setPointerCapture(e.pointerId);
      if (e.button !== 0 || e.shiftKey) { panX = { x: e.clientX, v0, v1 }; return; }
      const xi = t2x(leerIni(), W), xf = t2x(leerFin(), W);
      if (Math.abs(px - xi) < 8) arrastra = 'ini';
      else if (Math.abs(px - xf) < 8) arrastra = 'fin';
      else { arrastra = null; tocar(x2t(px)); }
    });
    cv.addEventListener('pointermove', (e) => {
      const r = cv.getBoundingClientRect(), px = e.clientX - r.left;
      if (panX) {
        const d = ((e.clientX - panX.x) / r.width) * (panX.v1 - panX.v0);
        const span = panX.v1 - panX.v0;
        v0 = F.util.clamp(panX.v0 - d, 0, D.dur - span); v1 = v0 + span; dibujar(); return;
      }
      if (!arrastra) {
        if (D) { const xi = t2x(leerIni(), r.width), xf = t2x(leerFin(), r.width); cv.style.cursor = Math.abs(px - xi) < 8 || Math.abs(px - xf) < 8 ? 'ew-resize' : 'crosshair'; }
        return;
      }
      const t = +x2t(px).toFixed(3);
      if (arrastra === 'ini') val[kIni] = Math.min(t, leerFin() - 0.05);
      else val[kFin] = Math.max(t, leerIni() + 0.05) >= D.dur - 0.01 ? 0 : Math.max(t, leerIni() + 0.05);
      cambio(false);
    });
    const soltar = () => {
      if (panX) { panX = null; return; }
      if (!arrastra) return;
      if (arrastra === 'ini') val[kIni] = +alCero(val[kIni]).toFixed(4);
      else if (val[kFin] > 0) val[kFin] = +alCero(val[kFin]).toFixed(4);
      arrastra = null;
      // si está sonando, que use el bucle nuevo
      if (sonando()) F.Audio.musica(idAsset, { volumen: op.volumen ? op.volumen() : 1, inicio: leerIni(), fin: val[kFin] || 0, fundido: 0 });
      cambio(true);
    };
    cv.addEventListener('pointerup', soltar);
    cv.addEventListener('pointercancel', soltar);
    cv.addEventListener('wheel', (e) => {
      if (!D) return;
      e.preventDefault();
      const r = cv.getBoundingClientRect(), t = x2t(e.clientX - r.left);
      const f = e.deltaY > 0 ? 1.25 : 0.8, span = F.util.clamp((v1 - v0) * f, 0.05, D.dur);
      const k = (t - v0) / (v1 - v0);
      v0 = F.util.clamp(t - span * k, 0, D.dur - span); v1 = v0 + span; dibujar();
    }, { passive: false });
    cv.addEventListener('dblclick', () => { if (D) { v0 = 0; v1 = D.dur; dibujar(); } });

    if (!a) { dibujar(); return caja; }
    dibujar();
    decodificar(a).then((d) => { D = d; const vv = vistas.get(idAsset); v0 = vv ? vv[0] : 0; v1 = vv ? vv[1] : d.dur; dibujar(); if (sonando()) animar(); })
      .catch(() => { info.textContent = '⚠ No se pudo leer la onda de este archivo.'; });
    new ResizeObserver(() => { if (caja.isConnected) dibujar(); }).observe(cv);
    return caja;
  };
})(window.FORJA);
