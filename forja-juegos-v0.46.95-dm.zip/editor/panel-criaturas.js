/* =========================================================
   EDITOR · JUEGO ▸ CRIATURAS
   Biblioteca de enemigos y animales del proyecto (proyecto.criaturas = [{ id, nombre, enemigo }]).
   - Los aparecedores eligen de aquí qué sacan (zona y oleadas).
   - "☠ Poner en la escena" coloca un enemigo VINCULADO: si cambias la criatura, cambian todos
     (S.aplicarCriaturas copia la configuración en ent.enemigo; el motor no necesita saber nada).
   Se configura con el mismo formulario que el enemigo del Inspector (Ed.formEnemigo).
   ========================================================= */
(function (F) {
  'use strict';
  const Ed = F.Editor;
  const $ = (id) => document.getElementById(id);
  const S = F.Escena;

  const ICONO_ACTITUD = { agresivo: '😠', neutral: '😐', pacifico: '🐇', depredador: '🐺' };
  const ICONO_TIPO = { terrestre: '', volador: '🦇', fijo: '🗼' };

  function nombreLibre(base) {
    const usados = new Set(Ed.proyecto.criaturas.map((c) => c.nombre));
    if (!usados.has(base)) return base;
    let i = 2;
    while (usados.has(base + ' ' + i)) i++;
    return base + ' ' + i;
  }

  Ed.construirPanelCriaturas = function () {
    const p = $('panelCriaturas');
    if (!p) return;
    const scroll = p.scrollTop;
    p.innerHTML = '';
    const P = Ed.proyecto;
    const crs = P.criaturas || (P.criaturas = S.criaturasPorDefecto());
    if (!crs.some((c) => c.id === Ed.criaturaElegida)) Ed.criaturaElegida = crs[0] ? crs[0].id : null;

    Ed.cabeceraPanel(p, 'Criaturas', () => {
      // no borra nada: vuelve a añadir las de serie que falten
      const faltan = S.criaturasPorDefecto().filter((d) => !crs.some((c) => c.id === d.id));
      if (!faltan.length) { Ed.toast('Ya están todas las criaturas de serie'); return; }
      if (!confirm(`¿Añadir de nuevo ${faltan.length} criatura(s) de serie que faltan? Las tuyas no se tocan.`)) return;
      Ed.marcarCambio();
      crs.push(...faltan);
      Ed.guardarLocal();
      Ed.construirPanelCriaturas();
    }, 'Vuelve a añadir las criaturas de serie que hayas borrado (no toca las tuyas)');

    Ed.nota(p, 'Tu biblioteca de enemigos y animales. Los <b>🥚 aparecedores</b> eligen de aquí qué sacan. ' +
      '<b>☠ Poner en la escena</b> coloca uno vinculado: si cambias la criatura, cambian todos.');

    // Lista
    const lista = document.createElement('div');
    lista.className = 'lista-armas';
    for (const c of crs) {
      const u = Ed.usosCriatura(c.id);
      const el = document.createElement('div');
      el.className = 'item' + (c.id === Ed.criaturaElegida ? ' sel' : '');
      const usos = [u.enemigos ? u.enemigos + ' en escena' : '', u.aparecedores ? u.aparecedores + ' 🥚' : ''].filter(Boolean).join(' · ');
      el.innerHTML = `<span></span><span class="nom"></span><span class="meta"></span>`;
      el.firstChild.textContent = (ICONO_ACTITUD[c.enemigo.actitud] || '·') + (ICONO_TIPO[c.enemigo.tipo] || '');
      el.querySelector('.nom').textContent = c.nombre;
      el.querySelector('.meta').textContent = usos || 'sin uso';
      el.onclick = () => { Ed.criaturaElegida = c.id; Ed.construirPanelCriaturas(); };
      lista.appendChild(el);
    }
    p.appendChild(lista);

    const idx = crs.findIndex((c) => c.id === Ed.criaturaElegida);
    const cr = crs[idx];
    Ed.botonera(p, [
      ['＋ Nueva', () => {
        Ed.marcarCambio();
        const c = S.criaturaNueva({ nombre: nombreLibre('Criatura') });
        crs.push(c);
        Ed.criaturaElegida = c.id;
        Ed.guardarLocal();
        Ed.construirPanelCriaturas();
      }],
      ['Duplicar', () => {
        if (!cr) return;
        Ed.marcarCambio();
        const c = S.criaturaNueva({ nombre: nombreLibre(cr.nombre), enemigo: F.util.copiar(cr.enemigo) });
        crs.splice(idx + 1, 0, c);
        Ed.criaturaElegida = c.id;
        Ed.guardarLocal();
        Ed.construirPanelCriaturas();
      }],
      ['☠ Poner en la escena', () => {
        if (!cr) return;
        Ed.agregarEntidad('enemigo', { criatura: cr.id, nombre: cr.nombre, enemigo: { ...F.Enemigos.BASE, ...F.util.copiar(cr.enemigo) } });
        Ed.abrirPanel('panelInspector');
      }, 'primario', 'Donde mira la cámara, vinculado a esta criatura'],
      ['Borrar', () => {
        if (!cr) return;
        const u = Ed.usosCriatura(cr.id);
        const avisos = [u.enemigos ? `${u.enemigos} enemigo(s) de la escena se quedan con una copia propia` : '',
          u.aparecedores ? `${u.aparecedores} aparecedor(es) dejan de sacarla` : ''].filter(Boolean);
        if (!confirm(`¿Borrar "${cr.nombre}"?` + (avisos.length ? '\n' + avisos.join('\n') : ''))) return;
        Ed.marcarCambio();
        for (const s of P.escenas) for (const e of s.entidades) {
          if (e.tipo === 'enemigo' && e.criatura === cr.id) e.criatura = '';
          if (e.tipo === 'aparecedor' && e.aparecedor) {
            const a = e.aparecedor;
            a.salen = (a.salen || []).filter((x) => x.criatura !== cr.id);
            a.oleadas = (a.oleadas || []).map((o) => o.filter((x) => x.criatura !== cr.id)).filter((o) => o.length);
            if (a.jefe === cr.id) a.jefe = '';
          }
        }
        crs.splice(idx, 1);
        Ed.guardarLocal();
        Ed.construirPanelCriaturas();
      }, 'peligro'],
    ]);

    // Nueva desde un preajuste del motor
    Ed.titulo(p, 'Nueva desde preajuste');
    const pre = document.createElement('div');
    pre.className = 'acciones';
    for (const [k, pr] of Object.entries(F.Enemigos.PRESETS)) {
      const b = document.createElement('button');
      b.textContent = pr.nombre;
      b.onclick = () => {
        Ed.marcarCambio();
        const { nombre, ...v } = pr;
        const c = S.criaturaNueva({ nombre: nombreLibre(nombre), enemigo: { ...F.Enemigos.BASE, ...v } });
        crs.push(c);
        Ed.criaturaElegida = c.id;
        Ed.guardarLocal();
        Ed.construirPanelCriaturas();
      };
      b.title = 'Crea una criatura nueva con los valores de ' + k;
      pre.appendChild(b);
    }
    p.appendChild(pre);

    // Formulario de la elegida
    if (cr) {
      Ed.titulo(p, '✎ ' + cr.nombre);
      Ed.formulario(p, [{ k: 'nombre', t: 'texto', e: 'Nombre' }], cr, (k, v) => {
        cr.nombre = String(v).trim() || 'Criatura';
        Ed.guardarLocal();
        Ed.construirPanelCriaturas();
      }, { antes: () => Ed.marcarCambio() });
      Ed.formEnemigo(p, cr.enemigo, (k, v, definitivo, visual) => {
        Ed.propagarCriatura(cr.id, visual);
        if (k === 'tipo' || k === 'actitud') Ed.construirPanelCriaturas();
        if (definitivo) Ed.guardarLocal();
      }, true);
    }
    p.scrollTop = scroll;
  };

  document.querySelector('[data-panel="panelCriaturas"]').addEventListener('click', () => Ed.construirPanelCriaturas());
})(window.FORJA);
