/* =========================================================
   EDITOR · PLANTILLAS DE PROYECTO NUEVO
   Al crear un proyecto se elige con qué empieza:
     · 'ejemplo'  — el nivel de siempre: suelo, escalera, rampa y dos cubos para probar el movimiento.
     · 'demo'     — "Campo de pruebas": un nivel con TODAS las mecánicas del motor ya puestas
                    (recogibles, mochila y baúl, cajas rompibles, enemigos con ruta, animales, piscina con peces,
                    foso de lava con puente, arena de oleadas, brújula con marcadores y una puerta a un 2º nivel).
     · 'vacio'    — solo el suelo y el ⚑ inicio (lo mínimo para poder darle a ▶ Jugar).
   Las bibliotecas (armas, criaturas, objetos) vienen en las tres: son del proyecto, no del nivel.
   ========================================================= */
(function (F) {
  'use strict';
  const S = F.Escena;

  const PLANTILLAS = [
    { id: 'ejemplo', icono: '🧱', nombre: 'Ejemplo sencillo', texto: 'Suelo, escalera, rampa y cubos para probar el movimiento.' },
    { id: 'demo', icono: '🎮', nombre: 'Campo de pruebas', texto: 'Un nivel con todas las mecánicas: armas, mochila, baúl, enemigos, animales, agua, lava, oleadas, brújula y salida a otro nivel.' },
    { id: 'vacio', icono: '▭', nombre: 'Vacío', texto: 'Solo el suelo y el inicio del jugador. Para empezar de cero.' },
  ];

  function crear(plantilla = 'ejemplo') {
    const p = S.proyectoNuevo();
    if (plantilla === 'vacio') {
      const e = S.escenaNueva('Nivel 1', false);
      p.escenas = [e];
      p.escenaInicial = e.id;
    } else if (plantilla === 'demo') {
      campoDePruebas(p);
    }
    return p;
  }

  /* ---------- Campo de pruebas ----------
     El terreno de juego está a la altura 0 hecho de losas (cubos de 3 m) y bajo todo hay un suelo a -3:
     así quedan dos fosos de verdad (piscina y lava) sin modelos externos. */
  function campoDePruebas(p) {
    const ent = (tipo, extra) => S.entidadNueva(tipo, extra);
    const nivel1 = S.escenaNueva('Campo de pruebas', false);
    // 🛡 la armadura se ve como escudo de fuerza (hexágonos) al recibir golpes
    if (p.jugador && p.jugador.modulos && p.jugador.modulos.salud) p.jugador.modulos.salud.burbuja = 'hex';
    const nivel2 = S.escenaNueva('Nivel 2', false);
    const nivel3 = S.escenaNueva('Nivel 3', false);
    const L = [];   // entidades del nivel 1

    // módulos que la demo enseña
    const m = p.jugador.modulos;
    for (const k of ['salud', 'armas', 'inventario', 'agachar', 'esquiva', 'interactuar', 'nadar', 'sombra', 'pasos', 'especial']) if (m[k]) m[k].activo = true;
    if (m.especial) Object.assign(m.especial, { forma: 'aura', radio: 4, dano: 30, dura: 4, recarga: 10, estilo: 'hex', color: '#ff8a4a', tipoDano: 'fuego' });   // ✸ B: aura de fuego
    if (m.salud) m.salud.armaduraMax = 100;
    p.hud.brujula = 'tira';
    p.ajustes.lucesExtra = true;   // luces de verdad (la farola y la lava alumbran)
    p.nombre = p.nombre || 'Mi juego';
    // 💰 dos divisas (monedas y gemas; las gemas se pueden guardar en el baúl) · ❤ vidas arcade · 💾 guardar en pausa y en puntos
    p.divisas = [{ ...F.Divisas.BASE }, { ...F.Divisas.BASE, id: 'gemas', nombre: 'Gemas', icono: '💎', color: '#5fd3e8', max: 99, enBaul: true }];
    p.menus = F.Escena.normalizarMenus(p.menus);
    Object.assign(p.menus.vidas, { activo: true, inicio: 3, max: 9, extraCada: 50 });
    Object.assign(p.menus.guardado, { donde: 'ambos', alMorir: 'gameover', alEntrarNivel: true, ranuraAuto: true });
    if (m.movimiento) m.movimiento.noDeslizar = true;

    // armas: la escopeta y el lanzacohetes se recogen en el mapa
    const arma = (n) => p.armas.find((a) => a.nombre === n);
    const mun = (n) => p.municiones.find((a) => a.nombre === n);
    if (arma('Escopeta')) arma('Escopeta').alEmpezar = false;

    // una nota propia que explica el nivel
    const nota = F.Inventario.objetoNuevo({
      id: 'ob_nota_demo', nombre: 'Nota del campo de pruebas', tipo: 'nota', icono: '📄', color: '#e8e0c8', forma: 'papel',
      descripcion: 'Explica qué hay en este nivel.',
      texto: 'CAMPO DE PRUEBAS\n\n· Delante: vida, armadura, munición, armas y objetos. Tab / I abre la mochila (combina las dos hierbas).\n'
        + '· El baúl 📦 guarda cosas (lo que dejas en uno sale en todos).\n· Las cajas marrones se rompen a golpes o a tiros.\n'
        + '· A la derecha: escalera, rampa, plataformas y un elevador (súbete). A la izquierda: animales.\n'
        + '· Al fondo: la piscina (nadar, peces), el foso de lava con su puente y la arena de oleadas (empieza con el botón rojo de la columna).\n'
        + '· Junto al inicio, la palanca enciende y apaga la farola.\n'
        + '· Al entrar en la arena aparece en la brújula el marcador de la salida.\n'
        + '· En el fondo de la piscina hay una gema: ponla en el pedestal de la sala del tesoro (esquina derecha).\n'
        + '· La puerta del muro del fondo pide la llave: está en la arena.\n'
        + '· Detrás, la puerta del final lleva al Nivel 2 (pulsa E). Para volver, resuelve allí el puzle de las 3 palancas (lee el cartel).\n'
        + '· NUEVO: la máquina de escribir 💾 junto al inicio guarda la partida; la bandera antes de la arena es un checkpoint (con vidas ❤: al morir vuelves ahí).\n'
        + '· NUEVO: a la izquierda del inicio, empuja la caja 🧱 hasta la placa para abrir la jaula (vida extra, contenedor y pedazo de corazón). La caja pequeña se carga (E) y vuelve sola a su sitio.\n'
        + '· NUEVO: en el Nivel 2 te acompañan 2 agentes (G = órdenes: seguir, esperar, ir, abrir y limpiar la puerta táctica). En el Nivel 3 hay gemas 💎 (segunda divisa) y el guía tiene retrato.',
    });
    p.objetos.push(nota);

    // --- terreno: suelo bajo todo y losas con dos huecos ---
    L.push(ent('suelo', { nombre: 'Fondo de los fosos', pos: [0, -3, -8], params: { ancho: 60, largo: 72 }, color: '#4a4f44' }));
    const X0 = -22, X1 = 22, Z0 = -38, Z1 = 20;
    const huecos = [
      { nombre: 'piscina', x0: -16, x1: -6, z0: -20, z1: -10 },
      { nombre: 'lava', x0: 5, x1: 11, z0: -16, z1: -11 },
    ];
    const cortes = [...new Set([Z0, Z1, ...huecos.flatMap((h) => [h.z0, h.z1])])].sort((a, b) => a - b);
    const terreno = ent('carpeta', { nombre: 'Terreno' });
    L.push(terreno);
    for (let i = 0; i < cortes.length - 1; i++) {
      const za = cortes[i], zb = cortes[i + 1];
      const tapan = huecos.filter((h) => h.z0 < zb && h.z1 > za).sort((a, b) => a.x0 - b.x0);
      let x = X0;
      const tramo = (xa, xb) => {
        if (xb - xa < 0.01) return;
        L.push(ent('cubo', { nombre: 'Losa', padre: terreno.id, pos: [(xa + xb) / 2, -3, (za + zb) / 2], params: { ancho: xb - xa, alto: 3, largo: zb - za }, color: '#5f6b4e', mosaico: 4 }));
      };
      for (const h of tapan) { tramo(x, h.x0); x = h.x1; }
      tramo(x, X1);
    }
    // muros alrededor
    const muros = ent('carpeta', { nombre: 'Muros' });
    L.push(muros);
    const muro = (x, z, an, la) => L.push(ent('cubo', { nombre: 'Muro', padre: muros.id, pos: [x, 0, z], params: { ancho: an, alto: 1.4, largo: la }, color: '#7a7466' }));
    muro(0, Z1 + 0.25, X1 - X0 + 1, 0.5); muro(0, Z0 - 0.25, X1 - X0 + 1, 0.5);
    muro(X0 - 0.25, (Z0 + Z1) / 2, 0.5, Z1 - Z0); muro(X1 + 0.25, (Z0 + Z1) / 2, 0.5, Z1 - Z0);

    // --- inicio, nota y baúl ---
    const inicio = ent('inicio', { pos: [0, 0, 16] });
    L.push(inicio);
    // 🛡 escudo de fuerza temporal (15 s, para 100 de daño): la esfera de hexágonos alrededor del jugador
    L.push(ent('recogible', { nombre: 'Escudo de fuerza', pos: [-3.5, 0.8, 11], recogible: { ...F.Recogibles.BASE, ...strip(F.Recogibles.PRESETS.escudoFuerza) } }));
    L.push(ent('recogible', { nombre: 'Nota del nivel', pos: [-1.5, 0.8, 14], recogible: { ...F.Recogibles.BASE, tipo: 'objeto', objeto: nota.id, cantidad: 1, recoger: 'usar', soloSiFalta: false } }));
    L.push(ent('baul', { nombre: 'Baúl', pos: [3, 0, 14.5], rot: [0, -90, 0] }));
    L.push(ent('baul', { nombre: 'Cofre', pos: [5, 0, 15.5], rot: [0, 180, 0], baul: { ...F.util.copiar(F.Inventario.BAUL), modo: 'premio', color: '#8a5a2a',
      contenido: [{ tipo: 'objeto', objeto: 'ob_spray', cantidad: 1 }, { tipo: 'municion', municionTipo: mun('Balas') ? mun('Balas').id : '', cantidad: 24 }] } }));
    L.push(ent('luz', { nombre: 'Luz del inicio', pos: [0, 3, 14], luz: { ...F.Luces.LUZ_BASE, alcance: 9 } }));
    // 🕹 palanca que enciende / apaga una farola
    const farola = ent('luz', { nombre: 'Farola (apagada)', pos: [9, 3.2, 13], luz: { ...F.Luces.LUZ_BASE, color: '#bfe0ff', alcance: 10, apagada: true } });
    L.push(farola, ent('cubo', { nombre: 'Poste', pos: [9, 0, 13], params: { ancho: 0.2, alto: 3, largo: 0.2 }, color: '#3a3a40' }));
    // 🚩 bandera que ondea en el poste · 🍃 hojas al viento
    const bandera = ent('cubo', { nombre: 'Bandera', pos: [9.85, 2.1, 13], params: { ancho: 1.5, alto: 0.9, largo: 0.04 }, color: '#c0392b' });
    Object.assign(bandera.material, { ondear: true, ondearCant: 0.14, ondearLargo: 0.7, ondearVel: 1.3, dobleCara: true });
    L.push(bandera, ent('particulas', { nombre: 'Hojas al viento', pos: [4, 0, 12], particulas: { ...F.Particulas.PARTICULAS, tipo: 'hojas', ...F.Particulas.PRESET.hojas } }));
    // ⬡ cúpula de energía con una armadura dentro: la palanca de al lado la apaga y la enciende
    if (F.Campo) {
      const cupula = ent('barrera', { nombre: 'Cúpula de energía', pos: [-8.5, 0, 5.5], esc: [3.2, 2.4, 3.2], barrera: { ...F.Campo.BARRERA, forma: 'cupula', estilo: 'hex', color: '#5fd0ff' } });
      L.push(cupula);
      L.push(ent('recogible', { nombre: 'Armadura (dentro de la cúpula)', pos: [-8.5, 0.6, 5.5], recogible: { ...F.Recogibles.BASE, tipo: 'armadura', cantidad: 100, soloSiFalta: false } }));
      L.push(ent('palanca', { nombre: 'Palanca de la cúpula', pos: [-8.5, 0, 8.2], rot: [0, 0, 0],
        palanca: { ...F.util.copiar(F.Mecanismos.PALANCA), acciones: [F.Mecanismos.accionNueva({ que: 'barAlt', a: cupula.id })] } }));
    }
    L.push(ent('palanca', { nombre: 'Palanca de la farola', pos: [7, 0, 13.5], rot: [0, 0, 0],
      palanca: { ...F.util.copiar(F.Mecanismos.PALANCA), acciones: [F.Mecanismos.accionNueva({ que: 'luzAlt', a: farola.id })] } }));

    // --- fila de recogibles ---
    const rec = (nombre, x, z, r) => L.push(ent('recogible', { nombre, pos: [x, 0.6, z], recogible: { ...F.Recogibles.BASE, ...r } }));
    const recogibles = ent('carpeta', { nombre: 'Recogibles' });
    L.push(recogibles);
    const n0 = L.length;
    rec('Vida', -6, 10, { tipo: 'vida', cantidad: 25, soloSiFalta: false });
    rec('Armadura', -4, 10, { tipo: 'armadura', cantidad: 50, soloSiFalta: false });
    rec('Balas', -2, 10, { tipo: 'municion', municionTipo: mun('Balas') ? mun('Balas').id : '', cantidad: 24, soloSiFalta: false });
    rec('Escopeta', 0, 10, { tipo: 'arma', arma: arma('Escopeta') ? arma('Escopeta').id : '' });
    rec('Cartuchos', 2, 10, { tipo: 'municion', municionTipo: mun('Cartuchos') ? mun('Cartuchos').id : '', cantidad: 8, soloSiFalta: false });
    rec('Lanzacohetes', 4, 10, { tipo: 'arma', arma: arma('Lanzacohetes') ? arma('Lanzacohetes').id : '' });
    rec('Cohetes', 6, 10, { tipo: 'municion', municionTipo: mun('Cohetes') ? mun('Cohetes').id : '', cantidad: 4, soloSiFalta: false });
    const obj = (nombre, id, x, z) => rec(nombre, x, z, { tipo: 'objeto', objeto: id, cantidad: 1, recoger: 'usar', soloSiFalta: false });
    obj('Hierba verde', 'ob_hierba_verde', -6, 7);
    obj('Hierba roja', 'ob_hierba_roja', -4, 7);
    obj('Spray', 'ob_spray', -2, 7);
    obj('Mochila', 'ob_mochila', 0, 7);
    rec('Bolsa de balas (+50 máx.)', 2, 7, { tipo: 'capacidad', municionTipo: mun('Balas') ? mun('Balas').id : '', cantidad: 50, llenar: true, soloSiFalta: false, brillo: 0.6 });
    rec('Bola de fuego', 4, 7, { tipo: 'arma', arma: arma('Bola de fuego') ? arma('Bola de fuego').id : '' });
    rec('Frasco de maná', 6, 7, { tipo: 'municion', municionTipo: mun('Maná') ? mun('Maná').id : '', cantidad: 40, soloSiFalta: false });
    rec('Rayo de hielo (bastón)', 8, 7, { tipo: 'arma', arma: arma('Rayo de hielo') ? arma('Rayo de hielo').id : '' });
    rec('Escudo arcano (libro)', 8, 10, { tipo: 'arma', arma: arma('Escudo arcano') ? arma('Escudo arcano').id : '' });
    rec('Nova arcana (área)', 10, 10, { tipo: 'arma', arma: arma('Nova arcana') ? arma('Nova arcana').id : '' });
    rec('Escudo medieval', -8, 10, { ...strip(F.Recogibles.PRESETS.escudoMedieval) });
    rec('Escudo antimotines', -8, 7, { ...strip(F.Recogibles.PRESETS.escudoAntimotines) });
    for (let i = n0; i < L.length; i++) L[i].padre = recogibles.id;

    // --- cajas rompibles ---
    const cajas = ent('carpeta', { nombre: 'Cajas rompibles' });
    L.push(cajas);
    for (const [x, y, z] of [[4, 0, 6], [5.1, 0, 6], [4.55, 1, 6], [6.2, 0, 6.2]]) {
      L.push(ent('cubo', { nombre: 'Caja', padre: cajas.id, pos: [x, y, z], params: { ancho: 1, alto: 1, largo: 1 }, color: '#8a6238', vida: 30 }));
    }

    // --- movimiento: escalera, rampa, bloques y una plataforma alta ---
    const parkour = ent('carpeta', { nombre: 'Movimiento' });
    L.push(parkour);
    const pk = (tipo, extra) => L.push(ent(tipo, { padre: parkour.id, ...extra }));
    pk('escalera', { pos: [12, 0, 8], rot: [0, 180, 0] });
    pk('cubo', { nombre: 'Rellano', pos: [12, 0, 5.3], params: { ancho: 2, alto: 1.52, largo: 3 } });
    pk('rampa', { pos: [17, 0, 8], rot: [0, 180, 0] });
    pk('cubo', { nombre: 'Bloque bajo', pos: [14.5, 0, 3], params: { ancho: 2, alto: 0.4, largo: 2 } });
    pk('cubo', { nombre: 'Bloque medio', pos: [14.5, 0, 0], params: { ancho: 2, alto: 1.2, largo: 2 } });
    pk('cubo', { nombre: 'Agujero para agacharse', pos: [19, 1, 0], params: { ancho: 3, alto: 0.6, largo: 3 }, color: '#6b6f78' });
    pk('cubo', { nombre: 'Pata', pos: [17.7, 0, -1.3], params: { ancho: 0.4, alto: 1, largo: 0.4 } });
    pk('cubo', { nombre: 'Pata', pos: [20.3, 0, -1.3], params: { ancho: 0.4, alto: 1, largo: 0.4 } });
    pk('cubo', { nombre: 'Pata', pos: [17.7, 0, 1.3], params: { ancho: 0.4, alto: 1, largo: 0.4 } });
    pk('cubo', { nombre: 'Pata', pos: [20.3, 0, 1.3], params: { ancho: 0.4, alto: 1, largo: 0.4 } });
    pk('cubo', { nombre: 'Plataforma alta', pos: [14.5, 0, -4], params: { ancho: 3, alto: 2, largo: 3 } });
    // ⇅ elevador al lado de la plataforma alta (sube al pisarlo y vuelve al bajarte)
    pk('plataforma', { nombre: 'Elevador', pos: [12, 0.3, -4], plataforma: { ...F.Mecanismos.PLATAFORMA, modo: 'pisar', dy: 1.7, tiempo: 1.6, espera: 2, ancho: 1.8, largo: 1.8 } });
    L.push(ent('recogible', { nombre: 'Armadura (arriba)', padre: parkour.id, pos: [14.5, 2.6, -4], recogible: { ...F.Recogibles.BASE, tipo: 'armadura', cantidad: 100, soloSiFalta: false } }));

    // --- 🏺 sala del tesoro: se abre poniendo la gema (está en el fondo de la piscina) en el pedestal ---
    const sala = ent('carpeta', { nombre: 'Sala del tesoro' });
    L.push(sala);
    const pared = (nombre, x, z, an, la) => L.push(ent('cubo', { nombre, padre: sala.id, pos: [x, 0, z], params: { ancho: an, alto: 2.6, largo: la }, color: '#6b6355' }));
    pared('Pared norte', 19, 17.2, 4.4, 0.4);
    pared('Pared este', 21, 15, 0.4, 4.4);
    pared('Pared oeste', 17, 15, 0.4, 4.4);
    pared('Pared sur', 17.65, 12.8, 1.3, 0.4);
    pared('Pared sur', 20.35, 12.8, 1.3, 0.4);
    L.push(ent('cubo', { nombre: 'Techo', padre: sala.id, pos: [19, 2.6, 15], params: { ancho: 4.4, alto: 0.2, largo: 4.8 }, color: '#5a5348' }));
    L.push(ent('cubo', { nombre: 'Dintel', padre: sala.id, pos: [19, 2.3, 12.8], params: { ancho: 1.4, alto: 0.3, largo: 0.4 }, color: '#6b6355' }));
    const puertaTesoro = ent('puerta', { nombre: 'Puerta del tesoro', padre: sala.id, pos: [19, 0, 12.8], esc: [1.4, 2.3, 0.4], puerta: { ...F.Mecanismos.PUERTA, abrir: 'mecanismo', estilo: 'arriba', colorHoja: '#5a5a62' } });
    L.push(puertaTesoro);
    L.push(ent('pedestal', { nombre: 'Pedestal de la gema', padre: sala.id, pos: [17.6, 0, 11.4], rot: [0, 180, 0],
      pedestal: { ...F.util.copiar(F.Mecanismos.PEDESTAL), objeto: 'ob_gema', acciones: [F.Mecanismos.accionNueva({ que: 'abrir', a: puertaTesoro.id }), F.Mecanismos.accionNueva({ que: 'mensaje', texto: 'Algo se abrió cerca…' })] } }));
    L.push(ent('recogible', { nombre: 'Armadura del tesoro', padre: sala.id, pos: [19, 0.6, 15.6], recogible: { ...F.Recogibles.BASE, tipo: 'armadura', cantidad: 100, soloSiFalta: false } }));
    L.push(ent('recogible', { nombre: 'Spray del tesoro', padre: sala.id, pos: [20, 0.6, 15.6], recogible: { ...F.Recogibles.BASE, tipo: 'objeto', objeto: 'ob_spray', cantidad: 1, recoger: 'usar', soloSiFalta: false } }));
    L.push(ent('recogible', { nombre: 'Gema roja', pos: [-13, -2.6, -17.5], recogible: { ...F.Recogibles.BASE, tipo: 'objeto', objeto: 'ob_gema', cantidad: 1, recoger: 'tocar', soloSiFalta: false } }));

    // --- enemigos con la biblioteca ---
    const enem = (nombre, cr, pos, extra = {}) => {
      const c = p.criaturas.find((x) => x.id === cr);
      const e = ent('enemigo', { nombre, pos, criatura: c ? cr : '' });
      if (c) e.enemigo = { ...F.Enemigos.BASE, ...F.util.copiar(c.enemigo), ...extra };
      return e;
    };
    const ruta = ent('carpeta', { nombre: 'Ruta del zombi' });
    L.push(ruta);
    [[-3, -2], [3, -2], [3, -7], [-3, -7]].forEach(([x, z], i) => L.push(ent('punto', { nombre: 'Punto ' + (i + 1), padre: ruta.id, pos: [x, 0, z], punto: { ...F.Enemigos.PUNTO, ruta: 'ruta1', orden: i } })));
    L.push(enem('Zombi de ronda', 'cr_zombi', [-3, 0, -2], { patrulla: 'ruta1' }));
    L.push(enem('Soldado', 'cr_soldado', [16, 0, -20]));
    L.push(enem('Torreta', 'cr_torreta', [-19, 0, -34]));

    // --- animales (a la izquierda) ---
    const animales = ent('carpeta', { nombre: 'Animales' });
    L.push(animales);
    for (const [nombre, cr, x, z] of [['Conejo', 'cr_conejo', -16, 8], ['Conejo', 'cr_conejo', -18, 4], ['Vaca', 'cr_vaca', -13, 2], ['Lobo', 'cr_lobo', -19, -4]]) {
      const e = enem(nombre, cr, [x, 0, z]);
      e.padre = animales.id;
      L.push(e);
    }

    // --- piscina: agua, escalera para salir y peces ---
    const piscina = ent('carpeta', { nombre: 'Piscina' });
    L.push(piscina);
    L.push(ent('agua', { nombre: 'Agua', padre: piscina.id, pos: [-11, -3, -15], esc: [10, 2.7, 10], agua: { ...F.Agua.AGUA, olas: true, olaAltura: 0.35, olaLargo: 5, olaVel: 1, olasJuego: true } }));   // 🌊 con oleaje que se nota al nadar
    L.push(ent('escalera', { nombre: 'Escalera para salir', padre: piscina.id, pos: [-6.7, -3, -12.4], params: { peldanos: 16, ancho: 1.2, altoPeldano: 0.19, fondo: 0.3 } }));
    for (const [nombre, cr, x, z] of [['Pez', 'cr_pez', -13, -13], ['Pez', 'cr_pez', -10, -17], ['Pez', 'cr_pez', -14, -18], ['Piraña', 'cr_pirana', -9, -14]]) {
      const e = enem(nombre, cr, [x, -1.8, z]);
      e.padre = piscina.id;
      L.push(e);
    }
    L.push(ent('luz', { nombre: 'Luz de la piscina', padre: piscina.id, pos: [-11, 3, -15], luz: { ...F.Luces.LUZ_BASE, color: '#9ad4ff', alcance: 10 } }));

    // --- foso de lava con puente ---
    const lava = ent('carpeta', { nombre: 'Foso de lava' });
    L.push(lava);
    L.push(ent('cubo', { nombre: 'Fondo del foso', padre: lava.id, pos: [8, -3, -13.5], params: { ancho: 6, alto: 2.4, largo: 5 }, color: '#3a2a22' }));
    L.push(ent('agua', { nombre: 'Lava', padre: lava.id, pos: [8, -0.6, -13.5], esc: [6, 0.45, 5], agua: { ...F.Agua.AGUA, ...strip(F.Agua.LIQUIDOS.lava), liquido: 'lava' } }));
    L.push(ent('cubo', { nombre: 'Puente', padre: lava.id, pos: [8, -0.4, -13.5], params: { ancho: 1, alto: 0.4, largo: 5 }, color: '#6a5a48' }));
    L.push(ent('luz', { nombre: 'Brillo de la lava', padre: lava.id, pos: [8, 1, -13.5], luz: { ...F.Luces.LUZ_BASE, color: '#ff6a1a', alcance: 7, parpadeo: 0.3 } }));

    // --- arena de oleadas ---
    const arena = ent('carpeta', { nombre: 'Arena' });
    L.push(arena);
    const oleadas = ent('aparecedor', { nombre: 'Oleadas', padre: arena.id, pos: [0, 0, -29], aparecedor: { ...F.Enemigos.APARECEDOR, modo: 'oleadas', forma: 'auto', empezar: 'mecanismo', radio: 7, distanciaMin: 5, inicial: 2, crecer: 1, total: 3, jefeCada: 0, descanso: 6, vivosMax: 6, salen: [{ criatura: 'cr_zombi', n: 3 }, { criatura: 'cr_demonio', n: 1 }] } });
    L.push(oleadas);
    // 🔴 botón en la columna de la entrada: empieza las oleadas
    L.push(ent('palanca', { nombre: 'Botón de la arena', padre: arena.id, pos: [-7, 0, -23.44], rot: [0, 180, 0],
      palanca: { ...F.util.copiar(F.Mecanismos.PALANCA), forma: 'boton', modo: 'una',
        acciones: [F.Mecanismos.accionNueva({ que: 'mensaje', texto: '¡Que empiece la pelea!' }), F.Mecanismos.accionNueva({ que: 'apaOn', a: oleadas.id })] } }));
    L.push(ent('marcador', { nombre: 'Marcador arena', padre: arena.id, pos: [0, 0, -29], marcador: { ...F.Brujula.MARCADOR, icono: '⚔', color: '#ff7a5a', texto: 'Arena' } }));
    L.push(ent('condicion', { nombre: 'Arena superada', padre: arena.id, pos: [3, 0, -29],
      condicion: { ...F.util.copiar(F.Mecanismos.CONDICION), requisitos: [F.Mecanismos.requisitoNuevo({ tipo: 'arena', a: oleadas.id })],
        acciones: [F.Mecanismos.accionNueva({ que: 'mensaje', texto: '¡Arena superada!' })] } }));
    for (const [x, z] of [[-7, -24], [7, -24], [-7, -34], [7, -34]]) {
      L.push(ent('cubo', { nombre: 'Columna', padre: arena.id, pos: [x, 0, z], params: { ancho: 1, alto: 3, largo: 1 }, color: '#8a7f6a' }));
    }

    // --- muro con 🔒 puerta con llave (la llave está en la arena) ---
    const cierre = ent('carpeta', { nombre: 'Muro con puerta' });
    L.push(cierre);
    L.push(ent('cubo', { nombre: 'Muro', padre: cierre.id, pos: [-11.35, 0, -35], params: { ancho: 21.3, alto: 3, largo: 0.4 }, color: '#7a7466' }));
    L.push(ent('cubo', { nombre: 'Muro', padre: cierre.id, pos: [11.35, 0, -35], params: { ancho: 21.3, alto: 3, largo: 0.4 }, color: '#7a7466' }));
    L.push(ent('cubo', { nombre: 'Dintel', padre: cierre.id, pos: [0, 2.3, -35], params: { ancho: 1.4, alto: 0.7, largo: 0.4 }, color: '#7a7466' }));
    L.push(ent('puerta', { nombre: 'Puerta con llave', padre: cierre.id, pos: [0, 0, -35], esc: [1.4, 2.3, 0.4], puerta: { ...F.Mecanismos.PUERTA, llave: 'ob_llave', gastarLlave: true } }));
    L.push(ent('recogible', { nombre: 'Llave', pos: [5, 0.6, -27], recogible: { ...F.Recogibles.BASE, tipo: 'objeto', objeto: 'ob_llave', cantidad: 1, recoger: 'usar', soloSiFalta: false } }));

    // --- puerta al nivel 2 (y llegada de vuelta) ---
    const vuelta = ent('inicio', { nombre: 'Llegada desde el Nivel 2', pos: [0, 0, -36.5], rot: [0, 180, 0], inicio: { principal: false } });
    L.push(vuelta);
    const inicio2 = nivel2.entidades.find((e) => e.tipo === 'inicio');
    L.push(ent('salida', { nombre: 'Puerta al Nivel 2', pos: [0, 0, -37.5], salida: { ...F.Niveles.SALIDA, destino: nivel2.id, llegada: inicio2.id, activar: 'usar', figura: 'puerta' } }));
    const mSalida = ent('marcador', { nombre: 'Marcador salida', pos: [0, 0, -37.5], marcador: { ...F.Brujula.MARCADOR, icono: '🚪', texto: 'Salida', alEmpezar: false } });
    L.push(mSalida);
    // ⬚ al entrar en la arena (una vez): aparece el marcador de la salida y una pista
    L.push(ent('disparador', { nombre: 'Entrada de la arena', pos: [0, 0, -22.5], esc: [14, 2.5, 2],
      disparador: { ...F.util.copiar(F.Mecanismos.DISPARADOR), acciones: [
        F.Mecanismos.accionNueva({ que: 'marcaOn', a: mSalida.id }),
        F.Mecanismos.accionNueva({ que: 'mensaje', texto: 'La llave está en la arena. Pulsa el botón rojo para empezar.' })] } }));
    L.push(ent('luz', { nombre: 'Luz de la puerta', pos: [0, 3, -36], luz: { ...F.Luces.LUZ_BASE } }));

    // --- 💾 guardado: máquina de escribir (menú de ranuras) junto al inicio y bandera-checkpoint antes de la arena ---
    L.push(ent('guardado', { nombre: 'Máquina de escribir', pos: [-4, 0, 18], rot: [0, 180, 0], guardado: { ...F.Guardado.PUNTO, hace: 'menu', activar: 'usar', figura: 'maquina' } }));
    L.push(ent('guardado', { nombre: 'Checkpoint de la arena', pos: [-3, 0, -20.5], guardado: { ...F.Guardado.PUNTO, hace: 'auto', activar: 'tocar', figura: 'bandera', color: '#5fd35f', llenarVida: true } }));
    // --- 🧱 puzle: empuja la caja hasta la placa ⬚ y se abre la jaula con premios (vida extra y corazones) ---
    const puzleCaja = ent('carpeta', { nombre: 'Puzle de la caja' });
    L.push(puzleCaja);
    const pz = (tipo, extra) => { const e = ent(tipo, { padre: puzleCaja.id, ...extra }); L.push(e); return e; };
    pz('cubo', { nombre: 'Jaula', pos: [-20, 0, 17.8], params: { ancho: 4, alto: 2.4, largo: 0.3 }, color: '#5a5a62' });
    pz('cubo', { nombre: 'Jaula', pos: [-20, 0, 14.2], params: { ancho: 4, alto: 2.4, largo: 0.3 }, color: '#5a5a62' });
    pz('cubo', { nombre: 'Jaula', pos: [-18, 0, 17.45], params: { ancho: 0.3, alto: 2.4, largo: 0.7 }, color: '#5a5a62' });
    pz('cubo', { nombre: 'Jaula', pos: [-18, 0, 14.55], params: { ancho: 0.3, alto: 2.4, largo: 0.7 }, color: '#5a5a62' });
    const rejaJaula = pz('puerta', { nombre: 'Reja de la jaula', pos: [-18, 0, 16], rot: [0, 90, 0], esc: [2.2, 2.3, 0.3], puerta: { ...F.Mecanismos.PUERTA, abrir: 'mecanismo', estilo: 'arriba', tiempo: 0.8, colorHoja: '#3a3a40' } });
    const premio = (nombre, z, pre) => pz('recogible', { nombre, pos: [-20.5, 0.6, z], recogible: { ...F.Recogibles.BASE, ...strip(F.Recogibles.PRESETS[pre]) } });
    premio('Vida extra (1UP)', 15, 'vidaExtra'); premio('Contenedor de corazón', 16, 'corazon'); premio('Pedazo de corazón', 17, 'piezaCorazon');
    pz('empujable', { nombre: 'Caja para empujar', pos: [-11, 0, 16], empujable: { ...F.Empujables.EMPUJABLE, empujar: true, tirar: true, cargar: false, velocidad: 1.4, etiqueta: 'caja' } });
    pz('disparador', { nombre: 'Placa de presión', pos: [-15, 0, 16], esc: [1.2, 1, 1.2], disparador: { ...F.util.copiar(F.Mecanismos.DISPARADOR), quien: 'objetos', etiqueta: 'caja', placa: true, cuando: 'entrarSalir', color: '#c8a040',
      acciones: [F.Mecanismos.accionNueva({ que: 'abrir', a: rejaJaula.id })] } });
    pz('empujable', { nombre: 'Barril (se carga y vuelve)', pos: [-8, 0, 18.5], esc: [0.6, 0.6, 0.6], empujable: { ...F.Empujables.EMPUJABLE, cargar: true, tirar: false, volver: 10, forma: 'barril', color: '#8a5a3a', etiqueta: 'barril' } });
    // ⏳ puzle con tiempo: el barril sobre la placa pequeña abre la reja del cofre de gemas… hasta que vuelve a su sitio
    pz('cubo', { nombre: 'Nicho', pos: [-13.5, 0, 19.6], params: { ancho: 3, alto: 2.4, largo: 0.3 }, color: '#5a5a62' });
    pz('cubo', { nombre: 'Nicho', pos: [-15.1, 0, 18.9], params: { ancho: 0.3, alto: 2.4, largo: 1.4 }, color: '#5a5a62' });
    pz('cubo', { nombre: 'Nicho', pos: [-11.9, 0, 18.9], params: { ancho: 0.3, alto: 2.4, largo: 1.4 }, color: '#5a5a62' });
    const rejaNicho = pz('puerta', { nombre: 'Reja del nicho', pos: [-13.5, 0, 18.2], esc: [2.9, 2.3, 0.2], puerta: { ...F.Mecanismos.PUERTA, abrir: 'mecanismo', estilo: 'arriba', tiempo: 0.5, colorHoja: '#3a3a40' } });
    pz('recogible', { nombre: 'Gemas del nicho', pos: [-13.5, 0.5, 19], recogible: { ...F.Recogibles.BASE, ...strip(F.Recogibles.PRESETS.moneda), divisa: 'gemas', cantidad: 3, color: '#5fd3e8' } });
    pz('disparador', { nombre: 'Placa del barril', pos: [-6, 0, 16.5], esc: [0.9, 1, 0.9], disparador: { ...F.util.copiar(F.Mecanismos.DISPARADOR), quien: 'objetos', etiqueta: 'barril', placa: true, cuando: 'entrarSalir', color: '#9ad4ff',
      acciones: [F.Mecanismos.accionNueva({ que: 'abrir', a: rejaNicho.id })] } });
    // 🐎 montables: uno de cada tipo
    const mt = (nombre, pos, rotY, tipo, extra = {}) => pz('montable', { nombre, pos, rot: [0, rotY, 0], montable: { ...F.Montables.MONTABLE, ...F.Montables.PRESETS[tipo], tipo, ...extra } });
    mt('Caballo', [-4, 0, 3.5], 0, 'montura');
    mt('Jeep', [6.5, 0, 2.5], 0, 'carro', { alBajar: 'volver', volverTras: 8 });
    mt('Balsa', [-11, -0.45, -11.4], 0, 'bote');
    mt('Vagoneta', [-21, 0, 11], 0, 'riel', { ruta: 'Riel' });
    [[11], [4], [-3], [-9]].forEach(([z], i) => pz('punto', { nombre: 'Riel ' + (i + 1), pos: [-21, 0, z], punto: { ...F.Enemigos.PUNTO } }));
    pz('cubo', { nombre: 'Cartel', pos: [-9.5, 0, 12.5], params: { ancho: 1.2, alto: 1.6, largo: 0.15 }, color: '#7a5a3a',
      interaccion: { tipo: 'mensaje', verbo: 'Leer', titulo: 'PUZLE', mostrarNombre: true, unaVez: false,
        texto: 'Empuja la caja grande hasta la placa (camina contra ella). Para jalarla: E para agarrar, retrocede, E para soltar.\nLa jaula se abre mientras la caja esté sobre la placa.\nEl barril se carga con E: déjalo en la placa azul y la reja del nicho se abre… hasta que el barril vuelva solo (mira la cuenta ⏳).' } });

    // 🎬 Cinemática de prueba: un disparador cerca del inicio la pone (una vez por partida). Dos cámaras solo de
    // cinemática, humo que se enciende en la lava y explosiones (sin daño) en el foso.
    if (F.Cine) {
      const C = F.Cine, Cam = F.Camaras ? F.Camaras.CAMARA : {};
      const cine = ent('carpeta', { nombre: 'Cinemática de prueba' });
      const plano1 = ent('camara', { nombre: 'Plano general', padre: cine.id, pos: [0, 9, 24], rot: [-22, 0, 0], camara: { ...Cam, activacion: 'cine', fov: 55 } });
      const plano2 = ent('camara', { nombre: 'Plano de la lava', padre: cine.id, pos: [15, 4, -5], rot: [-20, 40, 0], camara: { ...Cam, activacion: 'cine', fov: 50 } });
      const centroLava = ent('punto', { nombre: 'Centro de la lava', padre: cine.id, pos: [8, -0.3, -13.5], punto: { ...F.Enemigos.PUNTO, ruta: '' } });
      const orilla = ent('punto', { nombre: 'Orilla de la lava', padre: cine.id, pos: [10.5, -0.3, -12], punto: { ...F.Enemigos.PUNTO, ruta: '' } });
      const humo = ent('particulas', { nombre: 'Humo de la lava', padre: cine.id, pos: [8, -0.3, -13.5],
        particulas: { ...F.Particulas.PARTICULAS, ...F.Particulas.PRESET.humo, tipo: 'humo', cantidad: 70, radio: 1.6, alto: 6, tam: 0.9, color: '#5a5048', color2: '#2a2422', activa: false } });
      L.push(cine, plano1, plano2, centroLava, orilla, humo);
      const intro = C.cineNueva('Prueba: explosión en la lava');
      intro.barras = 0.12;
      intro.pasos = [
        C.pasoNuevo('fundido', { trans: 'negro', tapar: true, dur: 0.4 }),
        C.pasoNuevo('camara', { destino: plano1.id, modo: 'corte', mirar: centroLava.id }),
        C.pasoNuevo('fundido', { trans: 'negro', tapar: false, dur: 0.6 }),
        C.pasoNuevo('titulo', { texto: 'CAMPO DE PRUEBAS', sub: 'una cinemática de ejemplo', dur: 2.6, cuando: 'alavez' }),
        C.pasoNuevo('camara', { destino: plano2.id, modo: 'viaje', dur: 3, mirar: centroLava.id }),
        C.pasoNuevo('dialogo', { quien: 'Narrador', texto: 'Las explosiones son baratas: cada una es un solo dibujo.', dur: 2.8, cuando: 'alavez' }),
        C.pasoNuevo('explosion', { donde: centroLava.id, tam: 'grande', humo: true }),
        C.pasoNuevo('particulas', { a: humo.id, encender: true, cuando: 'alavez' }),
        C.pasoNuevo('esperar', { dur: 0.7 }),
        C.pasoNuevo('explosion', { donde: orilla.id, tam: 'media', humo: true }),
        C.pasoNuevo('zoom', { fov: 38, dur: 1.2, cuando: 'alavez' }),
        C.pasoNuevo('esperar', { dur: 1.2 }),
        C.pasoNuevo('camara', { destino: '__jugador', modo: 'viaje', dur: 2.2 }),
        C.pasoNuevo('dialogo', { quien: 'Narrador', texto: 'Haz las tuyas en 🎥 Cine (barra de la izquierda).', dur: 2.6, cuando: 'alavez' }),
      ];
      nivel1.cinematicas = [intro];
      L.push(ent('disparador', { nombre: 'Disparador: cinemática de prueba', padre: cine.id, pos: [0, 0, 12.5], esc: [4, 2.5, 1],
        disparador: { ...F.util.copiar(F.Mecanismos.DISPARADOR), cuando: 'una', acciones: [F.Mecanismos.accionNueva({ que: 'cine', a: '', cine: intro.id })] } }));
    }

    nivel1.entidades = L;

    // --- nivel 2: el portal de vuelta está en una cámara cerrada; se abre con la combinación de 3 palancas ---
    const M = F.Mecanismos;
    const suelo2 = nivel2.entidades.find((e) => e.tipo === 'suelo');
    suelo2.params.ancho = 18; suelo2.params.largo = 18; suelo2.color = '#4e5a6b';
    inicio2.pos = [0, 0, 6];
    const E2 = nivel2.entidades;
    const muro2 = (nombre, x, z, an, la, alto = 3, padre = '') => { const e = ent('cubo', { nombre, padre, pos: [x, 0, z], params: { ancho: an, alto, largo: la }, color: '#5b6372' }); E2.push(e); return e; };
    // muros de la sala
    const bordes = ent('carpeta', { nombre: 'Muros' });
    E2.push(bordes);
    muro2('Muro', 0, 9.2, 18.8, 0.4, 3, bordes.id); muro2('Muro', 0, -9.2, 18.8, 0.4, 3, bordes.id);
    muro2('Muro', 9.2, -4.85, 0.4, 8.3, 3, bordes.id); muro2('Muro', 9.2, 4.85, 0.4, 8.3, 3, bordes.id);   // hueco de la puerta táctica
    E2.push(ent('cubo', { nombre: 'Dintel', padre: bordes.id, pos: [9.2, 2.35, 0], params: { ancho: 0.4, alto: 0.65, largo: 1.4 }, color: '#5b6372' }));
    muro2('Muro', -9.2, 0, 0.4, 18, 3, bordes.id);
    // la cámara del portal (x −3..3, z −8..−4) con una reja que sube
    const camara = ent('carpeta', { nombre: 'Cámara del portal' });
    E2.push(camara);
    muro2('Fondo', 0, -8.2, 6.4, 0.4, 3, camara.id);
    muro2('Lado', -3, -6.1, 0.4, 4.2, 3, camara.id);
    muro2('Lado', 3, -6.1, 0.4, 4.2, 3, camara.id);
    muro2('Frente', -1.95, -4, 1.7, 0.4, 3, camara.id);
    muro2('Frente', 1.95, -4, 1.7, 0.4, 3, camara.id);
    E2.push(ent('cubo', { nombre: 'Dintel', padre: camara.id, pos: [0, 2.3, -4], params: { ancho: 2.2, alto: 0.7, largo: 0.4 }, color: '#5b6372' }));
    E2.push(ent('cubo', { nombre: 'Techo', padre: camara.id, pos: [0, 3, -6.1], params: { ancho: 6.4, alto: 0.2, largo: 4.6 }, color: '#4a5260' }));
    const reja = ent('puerta', { nombre: 'Reja del portal', padre: camara.id, pos: [0, 0, -4], esc: [2.2, 2.3, 0.4],
      puerta: { ...M.PUERTA, abrir: 'mecanismo', estilo: 'arriba', tiempo: 1.6, colorHoja: '#3a3a40', colorMarco: '#2c2c32' } });
    E2.push(reja);
    const inicio3 = nivel3.entidades.find((e) => e.tipo === 'inicio');
    E2.push(ent('salida', { nombre: 'Portal al Nivel 3', padre: camara.id, pos: [0, 0, -6.4], salida: { ...F.Niveles.SALIDA, destino: nivel3.id, llegada: inicio3.id, activar: 'tocar', figura: 'portal' } }));
    // las 3 palancas: cada una enciende su luz (para ver cómo está). La del centro empieza arriba
    const puzle = ent('carpeta', { nombre: 'Puzle de palancas' });
    E2.push(puzle);
    const palancas2 = [-4, 0, 4].map((x, i) => {
      const centro = i === 1;
      const luz = ent('luz', { nombre: 'Luz palanca ' + (i + 1), padre: puzle.id, pos: [x, 2.4, 1.4], luz: { ...F.Luces.LUZ_BASE, color: '#ffd27a', alcance: 4, fuerza: 1.2, apagada: !centro } });
      const pal = ent('palanca', { nombre: 'Palanca ' + (i + 1), padre: puzle.id, pos: [x, 0, 1.4], rot: [0, 180, 0],
        palanca: { ...F.util.copiar(M.PALANCA), empiezaEncendida: centro, acciones: [M.accionNueva({ que: 'luzOn', a: luz.id })] } });   // encendida = luz encendida
      E2.push(luz, pal);
      return pal;
    });
    const marcaPortal = ent('marcador', { nombre: 'Marcador portal', padre: camara.id, pos: [0, 0, -6.4], marcador: { ...F.Brujula.MARCADOR, icono: '🌀', texto: 'Portal', alEmpezar: false } });
    E2.push(marcaPortal);
    E2.push(ent('condicion', { nombre: 'Combinación', padre: puzle.id, pos: [0, 0, -2.5],
      condicion: { ...F.util.copiar(M.CONDICION), modo: 'todas', unaVez: true,
        requisitos: [M.requisitoNuevo({ tipo: 'palanca', a: palancas2[0].id, estado: 'on' }), M.requisitoNuevo({ tipo: 'palanca', a: palancas2[1].id, estado: 'off' }), M.requisitoNuevo({ tipo: 'palanca', a: palancas2[2].id, estado: 'on' })],
        acciones: [M.accionNueva({ que: 'abrir', a: reja.id }), M.accionNueva({ que: 'mensaje', texto: 'Se oye un mecanismo… la reja sube.' }), M.accionNueva({ que: 'marcaOn', a: marcaPortal.id })] } }));
    // el cartel con la pista
    E2.push(ent('cubo', { nombre: 'Cartel', pos: [-6.5, 0, 4], params: { ancho: 1.2, alto: 1.6, largo: 0.15 }, color: '#7a5a3a', rot: [0, 30, 0],
      interaccion: { tipo: 'mensaje', verbo: 'Leer', titulo: 'CARTEL', texto: 'Para abrir el portal: las palancas de los lados, arriba. La del centro, abajo.', mostrarNombre: true, unaVez: false } }));
    E2.push(
      ent('recogible', { nombre: 'Spray', pos: [6, 0.6, 4], recogible: { ...F.Recogibles.BASE, tipo: 'objeto', objeto: 'ob_spray', cantidad: 1, recoger: 'usar', soloSiFalta: false } }),
      ent('luz', { nombre: 'Luz', pos: [0, 3, 3], luz: { ...F.Luces.LUZ_BASE, color: '#9ab8ff' } }),
    );

    // --- nivel 2 · ANEXO "Operación Rescate": todo lo táctico (rehenes, bombas, puertas tácticas, sigilo, escaleras,
    //     cuerda, cámaras fijas) y la misión con estrellas. Al este de la sala, tras una 🚧 puerta táctica ---
    const T2 = F.Tactico, C2 = F.Camaras, T3 = F.Tactico;
    const anexo = ent('carpeta', { nombre: 'Anexo táctico' });
    E2.push(anexo);
    const sold = (extra) => ({ ...F.Enemigos.BASE, ...F.util.copiar(((p.criaturas || []).find((c) => c.id === 'cr_soldado') || {}).enemigo || {}), ...extra });
    const pa = (tipo, extra) => { const e = ent(tipo, { padre: anexo.id, ...extra }); E2.push(e); return e; };
    const muroA = (x, z, an, la, alto = 3) => pa('cubo', { nombre: 'Muro', pos: [x, 0, z], params: { ancho: an, alto, largo: la }, color: '#6a6458' });
    pa('suelo', { nombre: 'Suelo del anexo', pos: [17.3, 0, 0], params: { ancho: 16, largo: 18.4 }, color: '#55504a' });
    muroA(17.3, -9.2, 15.8, 0.4); muroA(17.3, 9.2, 15.8, 0.4); muroA(25.2, 0, 0.4, 18.8);
    // pared entre la sala A y la sala B, con la segunda puerta (cerrada: ganzúa, patada o C2)
    muroA(17.2, -3.35, 0.4, 11.3); muroA(17.2, 6.35, 0.4, 5.3);
    pa('cubo', { nombre: 'Dintel', pos: [17.2, 2.35, 3], params: { ancho: 0.4, alto: 0.65, largo: 1.4 }, color: '#6a6458' });
    pa('brecha', { nombre: 'Puerta táctica (entrada)', pos: [9.2, 0, 0], rot: [0, 90, 0], brecha: { ...T2.BRECHA } });
    pa('brecha', { nombre: 'Puerta táctica (cerrada)', pos: [17.2, 0, 3], rot: [0, 90, 0], brecha: { ...T2.BRECHA, cerrada: true, color: '#5a3a30' } });
    // sala A: un guardia de espaldas a la puerta (ejecútalo por la espalda), un rehén que se libera y una escalera de mano
    pa('enemigo', { nombre: 'Guardia (de espaldas)', pos: [14, 0, 1.5], rot: [0, 90, 0], criatura: '',
      enemigo: sold({ inactivo: 'quieto', vision: 9, angulo: 90, oidoCaminar: 2, oidoCorrer: 8 }) });
    pa('rehen', { nombre: 'Rehén (liberar)', pos: [13, 0, -4], rot: [0, 90, 0], rehen: { ...T2.REHEN } });
    pa('cubo', { nombre: 'Altillo', pos: [11.25, 0, -7.75], params: { ancho: 2.5, alto: 2.4, largo: 2.5 }, color: '#6f6a5e' });
    pa('escala', { nombre: 'Escalera de mano', pos: [11.25, 0, -6.45], forma: 'escalera', params: { alto: 2.4, ancho: 0.6 } });
    pa('recogible', { nombre: 'Armadura (en el altillo)', pos: [11.25, 2.9, -7.75], recogible: { ...F.Recogibles.BASE, tipo: 'armadura', cantidad: 50, soloSiFalta: false } });
    // sala B: al entrar empieza la cuenta atrás de la bomba de cables y cambia el plano; rehén a escoltar; cuerda al altillo
    const bombaB = pa('bomba', { nombre: 'Bomba (cables)', pos: [20, 0, 8.2], bomba: { ...T2.BOMBA, activa: false, tiempo: 75, desactivar: 'cables', cables: 3, correcto: 0, fallo: 'acelera' } });
    pa('enemigo', { nombre: 'Guardia B1', pos: [21.5, 0, 5], rot: [0, -90, 0], criatura: '', enemigo: sold({ inactivo: 'quieto', vision: 12 }) });
    pa('enemigo', { nombre: 'Guardia B2', pos: [23, 0, -2], rot: [0, -90, 0], criatura: '', enemigo: sold({ inactivo: 'quieto', vision: 12 }) });
    pa('cubo', { nombre: 'Altillo B', pos: [23.1, 0, -7.1], params: { ancho: 4, alto: 2.6, largo: 3.8 }, color: '#6f6a5e' });
    pa('escala', { nombre: 'Cuerda', pos: [20.7, 0, -7.1], forma: 'cuerda', params: { alto: 2.9, ancho: 0.6 } });
    pa('bomba', { nombre: 'Bomba (mantener)', pos: [23.5, 2.6, -7.5], bomba: { ...T2.BOMBA, activa: true, tiempo: 420, desactivar: 'mantener', segundos: 3 } });
    const extraccion = ent('disparador', { nombre: 'Extracción', pos: [0, 0, 6], esc: [4, 2.5, 3] });
    E2.push(extraccion);
    pa('rehen', { nombre: 'Rehén (escolta)', pos: [24, 0, 6.5], rot: [0, -90, 0], rehen: { ...T2.REHEN, modo: 'escolta', extraccion: extraccion.id, vida: 60 } });
    E2.push(ent('marcador', { nombre: 'Marcador extracción', pos: [0, 0, 6], marcador: { ...F.Brujula.MARCADOR, icono: '🚁', texto: 'Extracción' } }));
    // 📷 cámaras fijas (se usan con Jugador ▸ Cámara ▸ "Cámaras fijas"): sala principal y sala A por zona; sala B por disparador
    E2.push(ent('camara', { nombre: 'Cámara sala principal', pos: [0, 6, 9], rot: [-35, 0, 0], camara: { ...C2.CAMARA, inicial: true, zAncho: 18, zLargo: 18, zDelante: 9, zAbajo: 6, zAlto: 4 } }));
    pa('camara', { nombre: 'Cámara sala A', pos: [9.9, 3.5, 8.4], rot: [-24, -22, 0], camara: { ...C2.CAMARA, zAncho: 8, zLargo: 18, zDelante: 8, zAbajo: 3.5, zAlto: 4 } });
    const camB = pa('camara', { nombre: 'Cámara sala B', pos: [24.6, 3.5, 8.6], rot: [-22, 22, 0], camara: { ...C2.CAMARA, activacion: 'disparador', modo: 'sigue' } });
    pa('disparador', { nombre: 'Entrada a la sala B', pos: [19, 0, 3], esc: [2.5, 2.5, 3],
      disparador: { ...F.util.copiar(M.DISPARADOR), acciones: [M.accionNueva({ que: 'bombaOn', a: bombaB.id }), M.accionNueva({ que: 'camara', a: camB.id }),
        M.accionNueva({ que: 'mensaje', texto: '¡Una bomba! Corta el cable bueno… o busca otra forma.' })] } });
    pa('cubo', { nombre: 'Cartel del anexo', pos: [10, 0, 6.5], params: { ancho: 1.2, alto: 1.6, largo: 0.15 }, color: '#7a5a3a', rot: [0, 90, 0],
      interaccion: { tipo: 'mensaje', verbo: 'Leer', titulo: 'OPERACIÓN RESCATE', mostrarNombre: true, unaVez: false,
        texto: 'Puertas tácticas: usar = menú (cuidado, patada, C2, ganzúa, espejo).\nPor la espalda y sin que te vean: Ejecutar.\nEscaleras: adelante sube. Cuerda: izquierda/derecha giran.\nO = ver objetivos.\nCámaras fijas: Jugador ▸ Cámara ▸ "Cámaras fijas".' } });
    pa('luz', { nombre: 'Luz sala A', pos: [13, 2.8, 0], luz: { ...F.Luces.LUZ_BASE, color: '#ffd9a0', alcance: 9 } });
    pa('luz', { nombre: 'Luz sala B', pos: [21, 2.8, 0], luz: { ...F.Luces.LUZ_BASE, color: '#ffb0a0', alcance: 9 } });
    // ⭐ la misión del nivel 2
    const MS = F.Misiones, ob = MS.objetivoNuevo;
    nivel2.mision = { ...F.util.copiar(MS.MISION), activa: true, titulo: 'Operación Rescate',
      briefing: 'Hay dos rehenes en el edificio del este y al menos una bomba.\nEntra por la puerta táctica, libera a los rehenes y saca al de la sala B hasta la extracción.\nLuego sal por el portal (el puzle de las palancas) hacia el Nivel 3.',
      objetivos: [ob({ tipo: 'rescatar', estrella: 1 }), ob({ tipo: 'salir', estrella: 1, texto: 'Sal por el portal' }),
        ob({ tipo: 'bombas', estrella: 2 }), ob({ tipo: 'leer', estrella: 2 }),
        ob({ tipo: 'ejecutar', estrella: 3, cantidad: 1 }), ob({ tipo: 'tiempo', estrella: 3, segundos: 480 })] };
    // 🛡 dos agentes aliados (equipo SWAT): G = órdenes (seguir, esperar, ir ahí, abrir y limpiar la puerta táctica)
    for (const [i, x] of [[1, -1.5], [2, 1.5]]) E2.push(ent('enemigo', { nombre: 'Agente ' + i, pos: [x, 0, 7.6], enemigo: { ...F.Enemigos.BASE, ...F.util.copiar(F.Enemigos.PRESETS.agente) } }));
    // lo que enseña: doble salto, sigilo
    if (m.salto) { m.salto.saltos = 2; m.salto.modoSaltos = 'aire'; }
    if (m.sigilo) m.sigilo.activo = true;

    // --- NIVEL 3 · "El bazar del páramo": monedas y tienda, personaje con diálogo, barriles explosivos, zona de gas,
    //     correr por las paredes sobre un foso, y la salida 🏆 que acaba el juego ---
    const E3 = nivel3.entidades, p3 = (tipo, extra) => { const e = ent(tipo, extra); E3.push(e); return e; };
    const suelo3 = E3.find((e) => e.tipo === 'suelo');
    suelo3.params.ancho = 30; suelo3.params.largo = 30; suelo3.color = '#7a6a4e';
    inicio3.pos = [0, 0, 12]; inicio3.rot = [0, 0, 0];
    const muro3 = (x, y, z, an, al, la, color = '#8a7a5e') => p3('cubo', { nombre: 'Muro', pos: [x, y, z], params: { ancho: an, alto: al, largo: la }, color });
    muro3(-15.2, 0, 0, 0.4, 3, 30); muro3(15.2, 0, 0, 0.4, 3, 30); muro3(0, 0, 15.2, 30.8, 3, 0.4);
    muro3(-8.4, 0, -15.2, 15.2, 3, 0.4); muro3(8.4, 0, -15.2, 15.2, 3, 0.4);   // muro del fondo con hueco para la puerta
    const puerta3 = p3('puerta', { nombre: 'Puerta del foso', pos: [0, 0, -15.2], esc: [1.6, 2.3, 0.4], puerta: { ...M.PUERTA, abrir: 'mecanismo', estilo: 'arriba', tiempo: 1.2 } });
    // 🗣 el guía: explica el nivel y abre la puerta del foso
    p3('npc', { nombre: 'Guía del bazar', pos: [-4, 0, 8], npc: { ...F.util.copiar(T3.NPC), color: '#3a8a6a', retratoAuto: true, nodos: [
      T3.nodoNuevo({ texto: 'Bienvenido al bazar. Aquí todo se paga con monedas.', opciones: [
        T3.opcionNueva({ texto: '¿Dónde consigo monedas?', siguiente: '1' }),
        T3.opcionNueva({ texto: '¿Qué hay al fondo?', siguiente: '2' }),
        T3.opcionNueva({ texto: 'Ábreme la puerta del foso', siguiente: '3', acciones: [M.accionNueva({ que: 'abrir', a: puerta3.id })] }),
        T3.opcionNueva({ texto: 'Adiós' })] }),
      T3.nodoNuevo({ texto: 'Están por el suelo. Hay una bolsa al final del pasillo de gas: corre, que el gas quita vida.', opciones: [T3.opcionNueva({ texto: 'Gracias', siguiente: '0' })] }),
      T3.nodoNuevo({ texto: 'Un foso. Corre por las paredes (salta junto a una y sigue hacia delante). Si caes, hay una escalera.', opciones: [T3.opcionNueva({ texto: 'Entendido', siguiente: '0' })] }),
      T3.nodoNuevo({ texto: 'Hecho. Y cuidado con los barriles rojos: explotan.' })] } });
    // 🏪 la tienda
    const arma3 = (n) => (p.armas.find((a) => a.nombre === n) || {}).id || '';
    p3('tienda', { nombre: 'Tienda', pos: [6, 0, 7], tienda: { ...F.util.copiar(T3.TIENDA), titulo: 'BAZAR', articulos: [
      T3.articuloNuevo({ que: 'vida', cantidad: 25, precio: 5 }), T3.articuloNuevo({ que: 'armadura', cantidad: 50, precio: 12 }),
      T3.articuloNuevo({ que: 'municion', ref: mun('Cartuchos') ? mun('Cartuchos').id : '', cantidad: 8, precio: 6 }),
      T3.articuloNuevo({ que: 'arma', ref: arma3('Escopeta'), cantidad: 0, precio: 25, stock: 1 }),
      T3.articuloNuevo({ que: 'armadura', cantidad: 100, precio: 2, divisa: 'gemas' }), T3.articuloNuevo({ que: 'vida', cantidad: 100, precio: 1, divisa: 'gemas' })] } });
    // 💎 gemas: la segunda divisa (se pueden guardar en el baúl)
    [[-12, 12], [12, 4], [0, -12]].forEach(([x, z]) => p3('recogible', { nombre: 'Gema', pos: [x, 0.5, z], recogible: { ...F.Recogibles.BASE, ...strip(F.Recogibles.PRESETS.moneda), divisa: 'gemas', color: '#5fd3e8' } }));
    p3('guardado', { nombre: 'Punto de guardado', pos: [-3, 0, 13.5], rot: [0, 180, 0], guardado: { ...F.Guardado.PUNTO, hace: 'menu', figura: 'cristal', color: '#9ad4ff' } });
    // 🪙 monedas sueltas
    const monedas = ent('carpeta', { nombre: 'Monedas' }); E3.push(monedas);
    [[-2, 9], [2, 9], [-6, 3], [0, 3], [6, 2], [-10, 6], [10, 10], [-11, -10], [12, -12]].forEach(([x, z]) =>
      p3('recogible', { nombre: 'Moneda', padre: monedas.id, pos: [x, 0.5, z], recogible: { ...F.Recogibles.BASE, ...strip(F.Recogibles.PRESETS.moneda) } }));
    // 🛢 barriles junto a dos zombis
    [[-8, -4], [-7, -5], [-8.6, -5.6], [-6.6, -3.4]].forEach(([x, z]) => p3('barril', { pos: [x, 0, z] }));
    const enem3 = (n, cr, pos) => { const c = (p.criaturas || []).find((x) => x.id === cr); const e = ent('enemigo', { nombre: n, pos, criatura: c ? cr : '' }); if (c) e.enemigo = { ...F.Enemigos.BASE, ...F.util.copiar(c.enemigo) }; E3.push(e); return e; };
    enem3('Zombi', 'cr_zombi', [-9.5, 0, -7.5]); enem3('Zombi', 'cr_zombi', [-6, 0, -8]);
    // ☠ pasillo de gas con una bolsa de monedas al fondo
    muro3(5.8, 0, -7, 0.4, 3, 9); muro3(10.2, 0, -7, 0.4, 3, 9);
    p3('agua', { nombre: 'Gas venenoso', pos: [8, 0, -7], esc: [4, 3, 9], agua: { ...F.Agua.AGUA, ...strip(F.Agua.LIQUIDOS.veneno), liquido: 'veneno' } });
    p3('recogible', { nombre: 'Bolsa de monedas', padre: monedas.id, pos: [8, 0.5, -10.8], recogible: { ...F.Recogibles.BASE, ...strip(F.Recogibles.PRESETS.bolsaMonedas) } });
    // 🧗 tras la puerta: rellano, foso con paredes para correr y la salida final
    p3('suelo', { nombre: 'Rellano', pos: [0, 0, -18], params: { ancho: 10, largo: 6 }, color: '#7a6a4e' });
    p3('suelo', { nombre: 'Fondo del foso', pos: [0, -3, -25], params: { ancho: 10, largo: 8 }, color: '#4a3f30' });
    p3('suelo', { nombre: 'Al otro lado', pos: [0, 0, -32], params: { ancho: 10, largo: 6 }, color: '#7a6a4e' });
    muro3(-2.4, -3, -25, 0.4, 8, 8.4, '#6a5a44'); muro3(2.4, -3, -25, 0.4, 8, 8.4, '#6a5a44');   // las paredes para correr
    muro3(-5.2, -3, -26.5, 0.4, 6, 17); muro3(5.2, -3, -26.5, 0.4, 6, 17);                      // lados del recinto
    p3('cubo', { nombre: 'Pared del foso', pos: [0, -3, -21], params: { ancho: 10, alto: 3, largo: 0.2 }, color: '#5a4a38' });
    p3('cubo', { nombre: 'Pared del foso', pos: [0, -3, -29], params: { ancho: 10, alto: 3, largo: 0.2 }, color: '#5a4a38' });
    p3('escala', { nombre: 'Escalera para salir del foso', pos: [-3.6, -3, -21.25], rot: [0, 180, 0], forma: 'escalera', params: { alto: 3, ancho: 0.6 } });
    p3('salida', { nombre: 'Salida (fin del juego)', pos: [0, 0, -34], salida: { ...F.Niveles.SALIDA, destino: '__fin__', activar: 'tocar', figura: 'portal' } });
    p3('luz', { nombre: 'Luz del bazar', pos: [0, 4, 6], luz: { ...F.Luces.LUZ_BASE, color: '#ffd9a0', alcance: 16, soloNoche: true } });
    // 🌦 clima: el día pasa en 4 minutos (empieza al atardecer), llueve a ratos con tormenta; la luz del bazar es de noche
    Object.assign(nivel3.ambiente, { clima: true, climaHora: 17, climaCiclo: true, climaMinutos: 4, climaLluvia: 'azar', climaFuerza: 0.7, climaTormenta: true, climaRayos: 10 });
    p3('disparador', { nombre: 'Tormenta ante la puerta del foso', pos: [0, 0, -12], esc: [6, 2, 1], disparador: { ...F.util.copiar(M.DISPARADOR), acciones: [M.accionNueva({ que: 'lluviaOn' }), M.accionNueva({ que: 'rayo' })] } });
    p3('luz', { nombre: 'Luz del foso', pos: [0, 3, -25], luz: { ...F.Luces.LUZ_BASE, color: '#ffb070', alcance: 10 } });
    p3('cubo', { nombre: 'Cartel', pos: [2.5, 0, 12.5], params: { ancho: 1.2, alto: 1.6, largo: 0.15 }, color: '#7a5a3a',
      interaccion: { tipo: 'mensaje', verbo: 'Leer', titulo: 'EL BAZAR', mostrarNombre: true, unaVez: false,
        texto: 'Habla con el guía (usar). Recoge 🪙 y compra en la tienda.\nLos barriles rojos explotan.\nEl pasillo verde es gas: quita vida.\nAl fondo: corre por las paredes del foso.\nEl día pasa rápido: de noche se enciende la luz del bazar.' } });
    nivel3.mision = { ...F.util.copiar(MS.MISION), activa: true, titulo: 'El bazar del páramo',
      briefing: 'Consigue monedas, compra lo que necesites y cruza el foso hasta la salida.\nEl guía te abre la puerta del foso.',
      objetivos: [ob({ tipo: 'salir', estrella: 1, texto: 'Llega a la salida' }), ob({ tipo: 'recoger', que: 'moneda', estrella: 2, texto: 'Recoge todas las monedas' }), ob({ tipo: 'matarTodos', estrella: 3 })] };
    if (m.correrpared) m.correrpared.activo = true;
    if (m.asomarse) m.asomarse.activo = true;
    // 🗺 menú de misiones en el principal (los niveles siguen de uno a otro por sus salidas)
    p.menus.principal.botones.splice(1, 0, { texto: 'Misiones', accion: 'misiones' });
    p.menus.misiones = { ...(p.menus.misiones || {}), alTerminar: 'seguir' };

    p.escenas = [nivel1, nivel2, nivel3];
    p.escenaInicial = nivel1.id;
    S.aplicarCriaturas && S.aplicarCriaturas(p);
    return p;
  }
  // los valores de un líquido sin su nombre visible
  function strip(l) { const { nombre, ...r } = l; return r; }

  F.Plantillas = { PLANTILLAS, crear };
})(window.FORJA);
