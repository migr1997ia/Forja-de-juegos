/* =========================================================
   EDITOR · PROYECTOS EN CARPETA
   Con Chrome / Edge de PC eliges una vez tu carpeta "Proyectos".
   Cada proyecto es una subcarpeta con su nombre:
     Proyectos/
       Mi juego/
         proyecto.json            escenas, jugador, materiales… y la lista de archivos
         miniatura.png            vista del editor al guardar
         archivos/Modelos/nivel.glb
         archivos/Texturas/agua.png …   (mismas carpetas que el panel Archivos)
   El navegador (IndexedDB) sigue siendo la copia de trabajo rápida; la carpeta es la copia buena.
   Sin ese permiso (Firefox, celular) se usa el archivo .forja.json.
   ========================================================= */
(function (F) {
  'use strict';
  const Ed = (F.Editor = F.Editor || {});
  const $ = (id) => document.getElementById(id);
  const DB = F.Assets.DB;

  const soportado = typeof window.showDirectoryPicker === 'function';
  let raiz = null;               // FileSystemDirectoryHandle de la carpeta Proyectos
  Ed.carpetaActual = null;       // nombre de la subcarpeta del proyecto abierto (null = aún no guardado en carpeta)
  Ed.sinGuardar = false;
  let guardando = false;

  /* ---------- Utilidades de archivos ---------- */
  // Nombres válidos en Windows
  const limpiar = (s) => (s || 'sin nombre').replace(/[<>:"/\\|?*\x00-\x1f]/g, '_').replace(/[. ]+$/, '').trim() || 'sin nombre';

  async function permiso(handle, pedir) {
    const o = { mode: 'readwrite' };
    try {
      if ((await handle.queryPermission(o)) === 'granted') return true;
      if (pedir && (await handle.requestPermission(o)) === 'granted') return true;
    } catch (err) { /* sin permiso */ }
    return false;
  }

  async function carpetaDe(dir, partes, crear) {
    let d = dir;
    for (const p of partes) d = await d.getDirectoryHandle(p, { create: crear });
    return d;
  }

  async function escribir(dir, ruta, datos) {
    const partes = ruta.split('/');
    const nombre = partes.pop();
    const d = await carpetaDe(dir, partes, true);
    const fh = await d.getFileHandle(nombre, { create: true });
    const w = await fh.createWritable();
    await w.write(datos);
    await w.close();
  }

  async function leerArchivo(dir, ruta) {
    const partes = ruta.split('/');
    const nombre = partes.pop();
    const d = await carpetaDe(dir, partes, false);
    return (await d.getFileHandle(nombre)).getFile();
  }

  async function borrar(dir, ruta) {
    try {
      const partes = ruta.split('/');
      const nombre = partes.pop();
      const d = await carpetaDe(dir, partes, false);
      await d.removeEntry(nombre);
    } catch (err) { /* ya no estaba */ }
  }

  async function leerJSON(dir, ruta) {
    try { return JSON.parse(await (await leerArchivo(dir, ruta)).text()); } catch (err) { return null; }
  }

  // Ruta de un archivo según su carpeta en el panel Archivos
  function rutaAsset(a) {
    const partes = [];
    let c = Ed.proyecto.carpetasArchivos.find((x) => x.id === a.carpeta);
    let guarda = 0;
    while (c && guarda++ < 20) {
      partes.unshift(limpiar(c.nombre));
      c = Ed.proyecto.carpetasArchivos.find((x) => x.id === c.padre);
    }
    return ['archivos', ...partes, limpiar(a.nombre)].join('/');
  }

  /* =========================================================
     ARCHIVO ÚNICO .forja.json (funciona en cualquier navegador)
     Chrome/Edge: preguntas dónde una vez y después se sobrescribe ese mismo archivo.
     Otros navegadores: se descarga (el navegador decide la carpeta o te pregunta).
     ========================================================= */
  const puedeGuardarArchivo = typeof window.showSaveFilePicker === 'function';
  let archivoForja = null;            // archivo elegido con "Guardar archivo…"
  let cambiosDesdeRespaldo = false;
  let ultimoRespaldo = null;

  async function datosForja() {
    return JSON.stringify({
      formato: 'forja-juegos', version: F.VERSION, guardado: new Date().toISOString(),
      proyecto: Ed.proyectoParaGuardar(), assets: await F.Assets.serializar(),
    });
  }

  async function guardarArchivo({ preguntar = true, silencioso = false } = {}) {
    const nombre = F.util.slug(Ed.proyecto.nombre) + '.forja.json';
    if (puedeGuardarArchivo) {
      try {
        if (!archivoForja || preguntar) {
          archivoForja = await window.showSaveFilePicker({
            suggestedName: nombre,
            types: [{ description: 'Proyecto de Forja de Juegos', accept: { 'application/json': ['.json'] } }],
          });
          await DB.poner('proyecto', { id: 'archivoForja', handle: archivoForja }).catch(() => {});
        } else if (!(await permiso(archivoForja, !silencioso))) {
          return false;
        }
        const w = await archivoForja.createWritable();
        await w.write(await datosForja());
        await w.close();
        if (!silencioso) Ed.toast(`💾 Guardado en el archivo <b>${archivoForja.name}</b> (las siguientes veces se sobrescribe solo)`);
        return true;
      } catch (err) {
        if (err.name !== 'AbortError') Ed.toast('No pude guardar el archivo: ' + (err.message || err), 'error');
        return false;
      }
    }
    if (silencioso) return false;   // una descarga siempre la inicia la persona
    F.util.descargarBlob(new Blob([await datosForja()], { type: 'application/json' }), nombre);
    Ed.toast(`⬇ Descargado <b>${nombre}</b>. Muévelo a tu carpeta de proyectos; para abrirlo: Proyectos → Abrir carpeta o Importar.`);
    return true;
  }

  /* ---------- Respaldo automático cada 5 minutos (solo si hubo cambios) ----------
     1) Proyecto en carpeta (Chrome/Edge): guarda y escribe respaldo.forja.json en su carpeta, siempre el mismo archivo.
     2) Si no, el archivo elegido con "Guardar archivo…": se sobrescribe.
     3) Si no se puede escribir en el equipo: la copia queda en el navegador y se avisa para guardar a mano. */
  async function respaldar() {
    if (!cambiosDesdeRespaldo || Ed.jugando) return 'sin cambios';
    try {
      if (raiz && Ed.carpetaActual && (await permiso(raiz, false))) {
        await guardar({ silencioso: true });
        const dir = await raiz.getDirectoryHandle(Ed.carpetaActual);
        await escribir(dir, 'respaldo.forja.json', await datosForja());
        cambiosDesdeRespaldo = false;
        ultimoRespaldo = new Date();
        pintarBarra();
        return 'carpeta';
      }
      if (archivoForja && (await guardarArchivo({ preguntar: false, silencioso: true }))) {
        cambiosDesdeRespaldo = false;
        ultimoRespaldo = new Date();
        pintarBarra();
        return 'archivo';
      }
    } catch (err) {
      console.warn('[FORJA] respaldo', err);
    }
    Ed.toast('⏰ Llevas 5 minutos con cambios: pulsa <b>💾 Guardar</b> para dejar una copia en tu equipo. (El navegador ya guarda una copia de trabajo.)');
    cambiosDesdeRespaldo = false;
    return 'aviso';
  }

  /* =========================================================
     ABRIR UNA CARPETA (cualquier navegador, solo lectura)
     Sirve la carpeta de un proyecto o la carpeta Proyectos completa.
     ========================================================= */
  async function abrirDesdeSeleccion(archivos) {
    const lista = [...archivos];
    const ruta = (f) => f.webkitRelativePath || f.name;
    const porRuta = new Map(lista.map((f) => [ruta(f), f]));
    const jsons = lista.filter((f) => /(^|\/)proyecto\.json$/.test(ruta(f)));
    if (!jsons.length) {
      const forja = lista.filter((f) => /\.forja\.json$/i.test(f.name)).sort((a, b) => b.lastModified - a.lastModified);
      if (forja.length) {
        if (confirm(`No hay proyecto.json en esa carpeta, pero sí ${forja.length} archivo(s) .forja.json.\n¿Abrir el más reciente (${forja[0].name})?`)) {
          await Ed.importarForja(forja[0]);
          cerrarDialogo();
        }
      } else {
        Ed.toast('En esa carpeta no encontré proyectos (proyecto.json o .forja.json)', 'error');
      }
      return;
    }
    const proyectos = [];
    for (const f of jsons) {
      try {
        const datos = JSON.parse(await f.text());
        if (datos.formato !== 'forja-juegos') continue;
        const base = ruta(f).replace(/proyecto\.json$/, '');
        const mini = porRuta.get(base + 'miniatura.png');
        proyectos.push({ f, datos, base, mini: mini ? URL.createObjectURL(mini) : '' });
      } catch (err) { /* json dañado */ }
    }
    if (proyectos.length === 1) return abrirDeSeleccion(proyectos[0], porRuta);
    // Varios: elegir en la ventana
    const cuerpo = $('dlgProyectosCuerpo');
    cuerpo.innerHTML = '<div class="aviso-dlg">Proyectos encontrados en la carpeta que elegiste. Clic para abrir.</div>';
    const rejilla = document.createElement('div');
    rejilla.className = 'rejilla-proyectos';
    for (const pr of proyectos) {
      const t = document.createElement('div');
      t.className = 'tarjeta-proyecto';
      const pj = pr.datos.proyecto || {};
      t.innerHTML = `<div class="mini">${pr.mini ? `<img src="${pr.mini}">` : '<span>🎮</span>'}</div><b>${pj.nombre || pr.base}</b>
        <div class="nota">${(pj.escenas || []).length} escena(s) · ${(pr.datos.archivos || []).length} archivo(s)</div>`;
      t.onclick = () => abrirDeSeleccion(pr, porRuta);
      rejilla.appendChild(t);
    }
    cuerpo.appendChild(rejilla);
  }

  async function abrirDeSeleccion(pr, porRuta) {
    if (Ed.sinGuardar && !confirm('Hay cambios sin guardar. ¿Abrir otro proyecto de todos modos?')) return;
    const lista = [], faltan = [];
    for (const x of pr.datos.archivos || []) {
      const f = porRuta.get(pr.base + x.ruta);
      if (!f) { faltan.push(x.ruta); continue; }
      lista.push({ id: x.id, nombre: x.nombre, tipo: x.tipo, mime: x.mime, carpeta: x.carpeta, datos: await f.arrayBuffer() });
    }
    await Ed.cargarDatosProyecto({ proyecto: pr.datos.proyecto, assets: lista });
    // Abierto en modo lectura: para guardar se usa la carpeta de proyectos (Chrome/Edge) o "Guardar archivo…"
    Ed.carpetaActual = null;
    await DB.poner('proyecto', { id: 'carpetaActual', valor: null }).catch(() => {});
    for (const a of F.Assets.mapa.values()) a.sucio = true;
    marcarSucio();
    cerrarDialogo();
    Ed.toast(`📂 <b>${Ed.proyecto.nombre}</b> abierto desde la carpeta.` + (faltan.length ? ` Faltan ${faltan.length} archivo(s).` : ''), faltan.length ? 'error' : '');
  }

  /* ---------- Carpeta de proyectos ---------- */
  async function recordarRaiz() {
    await DB.poner('proyecto', { id: 'carpetaProyectos', handle: raiz }).catch(() => {});
  }

  async function elegirCarpeta() {
    if (!soportado) return false;
    try {
      raiz = await window.showDirectoryPicker({ id: 'forja-proyectos', mode: 'readwrite', startIn: 'documents' });
    } catch (err) {
      return false;   // canceló
    }
    await recordarRaiz();
    Ed.toast(`Carpeta de proyectos: <b>${raiz.name}</b>`);
    pintarBarra();
    return true;
  }

  async function asegurarRaiz(pedir = true) {
    if (!raiz) {
      if (!pedir) return false;
      if (!(await elegirCarpeta())) return false;
    }
    return permiso(raiz, pedir);
  }

  /* ---------- Guardar ---------- */
  function marcarSucio() {
    cambiosDesdeRespaldo = true;
    if (!Ed.sinGuardar) DB.poner('proyecto', { id: 'sinGuardar', valor: true }).catch(() => {});
    Ed.sinGuardar = true;
    pintarBarra();
  }

  // Los guardados se forman en fila: si llega uno mientras otro escribe, espera su turno (nunca se pierde)
  let cola = Promise.resolve(true);
  function guardar(opciones = {}) {
    cola = cola.then(() => guardarAhora(opciones), () => guardarAhora(opciones));
    return cola;
  }

  async function guardarAhora({ silencioso = false, comoNuevo = false } = {}) {
    if (!soportado) {
      // Sin carpetas: el archivo único (en Chrome sin permiso de carpeta se sobrescribe el elegido; si no, se descarga)
      if (silencioso) return false;
      const ok = await guardarArchivo({ preguntar: !archivoForja });
      if (ok) { Ed.sinGuardar = false; await DB.poner('proyecto', { id: 'sinGuardar', valor: false }).catch(() => {}); pintarBarra(); }
      return ok;
    }
    if (!(await asegurarRaiz(!silencioso))) {
      if (!silencioso) Ed.toast('No hay carpeta de proyectos con permiso. Elige una en <b>Proyectos</b>.', 'error');
      return false;
    }
    guardando = true;
    try {
      let nombreCarpeta = Ed.carpetaActual;
      if (!nombreCarpeta || comoNuevo) {
        nombreCarpeta = limpiar(Ed.proyecto.nombre);
        // no pisar otro proyecto con el mismo nombre
        const existentes = new Set((await listar()).map((x) => x.carpeta));
        if (existentes.has(nombreCarpeta)) {
          let n = 2;
          while (existentes.has(`${nombreCarpeta} (${n})`)) n++;
          nombreCarpeta = `${nombreCarpeta} (${n})`;
        }
      }
      const dir = await raiz.getDirectoryHandle(nombreCarpeta, { create: true });
      const previo = await leerJSON(dir, 'proyecto.json');
      const rutasPrevias = new Map(((previo && previo.archivos) || []).map((x) => [x.id, x.ruta]));

      // Archivos: solo se escriben los nuevos, los cambiados o los que se movieron de carpeta
      const archivos = [];
      let escritos = 0;
      for (const a of F.Assets.mapa.values()) {
        const ruta = rutaAsset(a);
        const antes = rutasPrevias.get(a.id);
        if (a.sucio || antes !== ruta || comoNuevo) {
          await escribir(dir, ruta, a.datos);
          escritos++;
          if (antes && antes !== ruta) await borrar(dir, antes);
        }
        a.sucio = false;
        archivos.push({ id: a.id, nombre: a.nombre, tipo: a.tipo, mime: a.mime, carpeta: a.carpeta || '', ruta });
        rutasPrevias.delete(a.id);
      }
      for (const ruta of rutasPrevias.values()) await borrar(dir, ruta);   // archivos quitados del proyecto

      const datos = {
        formato: 'forja-juegos', version: F.VERSION, guardado: new Date().toISOString(),
        proyecto: Ed.proyectoParaGuardar(), archivos,
      };
      await escribir(dir, 'proyecto.json', JSON.stringify(datos, null, 1));
      const mini = await Ed.capturarMiniatura();
      if (mini) await escribir(dir, 'miniatura.png', mini);

      Ed.carpetaActual = nombreCarpeta;
      await DB.poner('proyecto', { id: 'carpetaActual', valor: nombreCarpeta }).catch(() => {});
      await DB.poner('proyecto', { id: 'sinGuardar', valor: false }).catch(() => {});
      Ed.sinGuardar = false;
      pintarBarra();
      if (!silencioso) Ed.toast(`💾 Guardado en <b>${raiz.name} / ${nombreCarpeta}</b>${escritos ? ` (${escritos} archivo(s) escritos)` : ''}`);
      return true;
    } catch (err) {
      console.error(err);
      Ed.toast('No pude guardar en la carpeta: ' + (err.message || err), 'error');
      return false;
    } finally {
      guardando = false;
    }
  }

  /* ---------- Listar y abrir ---------- */
  async function listar() {
    if (!raiz || !(await permiso(raiz, false))) return [];
    const lista = [];
    for await (const [nombre, h] of raiz.entries()) {
      if (h.kind !== 'directory') continue;
      let info;
      try { info = await (await h.getFileHandle('proyecto.json')).getFile(); } catch (err) { continue; }
      let datos = null;
      try { datos = JSON.parse(await info.text()); } catch (err) { continue; }
      if (!datos || datos.formato !== 'forja-juegos') continue;
      let mini = '';
      try { mini = URL.createObjectURL(await (await h.getFileHandle('miniatura.png')).getFile()); } catch (err) { /* sin miniatura */ }
      lista.push({
        carpeta: nombre, nombre: (datos.proyecto && datos.proyecto.nombre) || nombre,
        escenas: (datos.proyecto && datos.proyecto.escenas || []).length, archivos: (datos.archivos || []).length,
        fecha: datos.guardado ? new Date(datos.guardado) : new Date(info.lastModified), mini, version: datos.version,
      });
    }
    return lista.sort((a, b) => b.fecha - a.fecha);
  }

  async function abrir(nombreCarpeta) {
    if (Ed.sinGuardar && !confirm('Hay cambios sin guardar en la carpeta. ¿Abrir otro proyecto de todos modos?\n(Siguen en el navegador hasta que abras otro.)')) return;
    if (!(await asegurarRaiz(true))) return;
    try {
      const dir = await raiz.getDirectoryHandle(nombreCarpeta);
      const datos = await leerJSON(dir, 'proyecto.json');
      if (!datos) throw new Error('proyecto.json no válido');
      const lista = [];
      const faltan = [];
      for (const x of datos.archivos || []) {
        try {
          const f = await leerArchivo(dir, x.ruta);
          lista.push({ id: x.id, nombre: x.nombre, tipo: x.tipo, mime: x.mime, carpeta: x.carpeta, datos: await f.arrayBuffer() });
        } catch (err) {
          faltan.push(x.ruta);
        }
      }
      await Ed.cargarDatosProyecto({ proyecto: datos.proyecto, assets: lista });
      Ed.carpetaActual = nombreCarpeta;
      await DB.poner('proyecto', { id: 'carpetaActual', valor: nombreCarpeta }).catch(() => {});
      await DB.poner('proyecto', { id: 'sinGuardar', valor: false }).catch(() => {});
      Ed.sinGuardar = false;
      pintarBarra();
      cerrarDialogo();
      Ed.toast(`📂 <b>${Ed.proyecto.nombre}</b> abierto`);
      if (faltan.length) Ed.toast(`Faltan ${faltan.length} archivo(s) en la carpeta: ${faltan.slice(0, 3).join(', ')}${faltan.length > 3 ? '…' : ''}`, 'error');
    } catch (err) {
      console.error(err);
      Ed.toast('No pude abrir el proyecto: ' + (err.message || err), 'error');
    }
  }

  // ＋ Nuevo proyecto: nombre y con qué empieza (editor/plantillas.js)
  async function nuevo() {
    if (Ed.sinGuardar && !confirm('Hay cambios sin guardar. ¿Crear un proyecto nuevo de todos modos?')) return;
    const cuerpo = $('dlgProyectosCuerpo');
    $('dlgProyectos').style.display = 'flex';
    let elegida = 'ejemplo';
    cuerpo.innerHTML = `<div class="nuevo-proyecto">
      <label>Nombre del proyecto <input id="npNombre" type="text" value="Mi juego" maxlength="60"></label>
      <div class="nota">Con qué empieza:</div>
      <div class="rejilla-proyectos" id="npPlantillas"></div>
      <div class="acciones"><button id="npCrear" class="primario">Crear proyecto</button><button id="npCancelar">Cancelar</button></div>
    </div>`;
    const rejilla = $('npPlantillas');
    for (const pl of F.Plantillas.PLANTILLAS) {
      const t = document.createElement('div');
      t.className = 'tarjeta-proyecto tarjeta-plantilla' + (pl.id === elegida ? ' actual' : '');
      t.innerHTML = `<div class="mini"><span>${pl.icono}</span></div><b>${pl.nombre}</b><div class="nota">${pl.texto}</div>`;
      t.onclick = () => { elegida = pl.id; for (const o of rejilla.children) o.classList.toggle('actual', o === t); };
      t.ondblclick = () => crear();
      rejilla.appendChild(t);
    }
    const inp = $('npNombre');
    inp.focus(); inp.select();
    inp.onkeydown = (e) => { if (e.key === 'Enter') crear(); };
    $('npCancelar').onclick = () => abrirDialogo();
    $('npCrear').onclick = () => crear();
    async function crear() {
      const nombre = inp.value.trim();
      if (!nombre) { inp.focus(); return; }
      const p = F.Plantillas.crear(elegida);
      p.nombre = nombre;
      await Ed.cargarDatosProyecto({ proyecto: p, assets: [] });
      Ed.carpetaActual = null;
      await DB.poner('proyecto', { id: 'carpetaActual', valor: null }).catch(() => {});
      cerrarDialogo();
      if (soportado && raiz && (await permiso(raiz, true))) await guardar();
      else { Ed.sinGuardar = true; pintarBarra(); }
    }
  }

  /* ---------- Barra superior: nombre del proyecto y estado ---------- */
  function pintarBarra() {
    const el = $('nombreProyecto');
    if (!el) return;
    const donde = !soportado ? (archivoForja ? `archivo ${archivoForja.name}` : 'en el navegador · Guardar crea un .forja.json')
      : !raiz ? 'sin carpeta de proyectos'
      : Ed.carpetaActual ? `${raiz.name} / ${Ed.carpetaActual}` : `${raiz.name} (aún no guardado)`;
    el.innerHTML = `<b>${Ed.proyecto ? Ed.proyecto.nombre : ''}</b>${Ed.sinGuardar ? ' <span class="punto-sucio" title="Cambios sin guardar en la carpeta (Ctrl+S)">●</span>' : ''}`;
    el.title = donde + (ultimoRespaldo ? `\nÚltimo respaldo automático: ${ultimoRespaldo.toLocaleTimeString('es-MX')}` : '\nRespaldo automático cada 5 minutos si hay cambios');
  }
  Ed.pintarBarraProyecto = pintarBarra;

  /* ---------- Ventana "Proyectos" ---------- */
  function cerrarDialogo() {
    $('dlgProyectos').style.display = 'none';
  }

  async function abrirDialogo() {
    const d = $('dlgProyectos');
    d.style.display = 'flex';
    const cuerpo = $('dlgProyectosCuerpo');
    cuerpo.innerHTML = '<div class="nota">Cargando…</div>';
    const partes = [];
    if (!soportado) {
      partes.push(`<div class="aviso-dlg">Este navegador no deja que una página escriba en tus carpetas.
        <b>📂 Abrir carpeta…</b> sí funciona (para abrir proyectos), y <b>💾 Guardar</b> crea un archivo <b>.forja.json</b> con todo.
        Con <b>Chrome</b> o <b>Edge</b> en PC se guarda directo en la carpeta y con respaldo automático cada 5 minutos.</div>`);
    } else if (!raiz) {
      partes.push(`<div class="aviso-dlg">Elige (o crea) una carpeta llamada <b>Proyectos</b>, por ejemplo en
        <i>Documentos\\Videojuegos\\Claude</i>. Ahí se guardará cada juego en su propia subcarpeta.</div>`);
    } else if (!(await permiso(raiz, false))) {
      partes.push(`<div class="aviso-dlg">El navegador necesita que confirmes otra vez el permiso de la carpeta <b>${raiz.name}</b>.
        <button id="btnReconectar" class="primario">Dar permiso</button></div>`);
    }
    cuerpo.innerHTML = partes.join('');
    $('dlgCarpeta').textContent = raiz ? `📁 ${raiz.name}` : '📁 (ninguna)';
    const btn = $('btnReconectar');
    if (btn) btn.onclick = async () => { if (await permiso(raiz, true)) abrirDialogo(); };

    const lista = await listar();
    const rejilla = document.createElement('div');
    rejilla.className = 'rejilla-proyectos';
    for (const pr of lista) {
      const t = document.createElement('div');
      t.className = 'tarjeta-proyecto' + (pr.carpeta === Ed.carpetaActual ? ' actual' : '');
      t.innerHTML = `<div class="mini">${pr.mini ? `<img src="${pr.mini}">` : '<span>🎮</span>'}</div>
        <b>${pr.nombre}</b>
        <div class="nota">${pr.carpeta !== pr.nombre ? pr.carpeta + ' · ' : ''}${pr.escenas} escena(s) · ${pr.archivos} archivo(s)</div>
        <div class="nota">${pr.fecha.toLocaleString('es-MX', { dateStyle: 'medium', timeStyle: 'short' })}${pr.carpeta === Ed.carpetaActual ? ' · <b>abierto</b>' : ''}</div>`;
      t.onclick = () => abrir(pr.carpeta);
      t.title = 'Abrir este proyecto';
      // 🗑 borrar el proyecto (su carpeta entera, con sus respaldos)
      const bor = document.createElement('button');
      bor.className = 'borrar-proyecto';
      bor.textContent = '🗑';
      bor.title = 'Borrar este proyecto';
      bor.style.cssText = 'position:absolute;top:6px;right:6px;padding:2px 6px;background:#3a1d1d;border:1px solid #6b2a2a;color:#f0c0c0;cursor:pointer';
      bor.onclick = async (e) => {
        e.stopPropagation();
        if (!confirm(`¿Borrar el proyecto "${pr.nombre}"?\n\nSe borra su carpeta "${pr.carpeta}" con todos sus archivos y respaldos. No se puede deshacer.`)) return;
        if (!confirm(`Última confirmación: borrar "${pr.nombre}" para siempre.`)) return;
        try {
          await raiz.removeEntry(pr.carpeta, { recursive: true });
          if (pr.carpeta === Ed.carpetaActual) {
            // el abierto sigue en el editor, pero ya sin carpeta (Guardar lo vuelve a crear)
            Ed.carpetaActual = null;
            await DB.poner('proyecto', { id: 'carpetaActual', valor: null }).catch(() => {});
            Ed.sinGuardar = true; pintarBarra();
          }
          Ed.toast && Ed.toast(`🗑 Proyecto "${pr.nombre}" borrado`);
        } catch (err) { alert('No se pudo borrar: ' + err.message); }
        abrirDialogo();
      };
      t.style.position = 'relative';
      t.appendChild(bor);
      rejilla.appendChild(t);
    }
    if (raiz && !lista.length && (await permiso(raiz, false))) {
      const v = document.createElement('div');
      v.className = 'nota';
      v.innerHTML = 'Todavía no hay proyectos en esta carpeta. Pulsa <b>Guardar</b> para guardar el actual o <b>＋ Nuevo proyecto</b>.';
      rejilla.appendChild(v);
    }
    cuerpo.appendChild(rejilla);
  }

  /* ---------- Arranque ---------- */
  Ed.Proyectos = {
    soportado,
    async iniciar() {
      try {
        const r = await DB.leer('proyecto', 'carpetaProyectos');
        if (r && r.handle) raiz = r.handle;
        const c = await DB.leer('proyecto', 'carpetaActual');
        Ed.carpetaActual = (c && c.valor) || null;
        const af = await DB.leer('proyecto', 'archivoForja');
        if (af && af.handle) archivoForja = af.handle;
      } catch (err) { /* sin datos */ }
      const s = await DB.leer('proyecto', 'sinGuardar').catch(() => null);
      Ed.sinGuardar = !!(s && s.valor);
      pintarBarra();

      $('btnProyectos').onclick = abrirDialogo;
      $('btnGuardar').onclick = () => guardar();
      $('dlgCerrar').onclick = cerrarDialogo;
      $('dlgNuevo').onclick = nuevo;
      $('dlgElegirCarpeta').onclick = async () => { if (await elegirCarpeta()) abrirDialogo(); };
      $('dlgGuardarComo').onclick = async () => {
        const nombre = prompt('Guardar una copia como (nombre del proyecto):', Ed.proyecto.nombre + ' copia');
        if (!nombre) return;
        Ed.proyecto.nombre = nombre.trim();
        Ed.construirPanelProyecto();
        if (await guardar({ comoNuevo: true })) abrirDialogo();
      };
      $('dlgImportar').onclick = () => $('archivoProyecto').click();
      $('dlgExportar').onclick = () => guardarArchivo({ preguntar: true });
      $('dlgAbrirCarpeta').onclick = () => $('archivoCarpeta').click();
      $('archivoCarpeta').onchange = async (e) => {
        if (e.target.files.length) await abrirDesdeSeleccion(e.target.files);
        e.target.value = '';
      };
      $('dlgProyectos').addEventListener('mousedown', (e) => { if (e.target.id === 'dlgProyectos') cerrarDialogo(); });
      if (!soportado) { $('dlgElegirCarpeta').style.display = 'none'; $('dlgGuardarComo').style.display = 'none'; }

      F.on('assets-cambiaron', marcarSucio);
      // Ctrl+S = guardar
      window.addEventListener('keydown', (e) => {
        if ((e.ctrlKey || e.metaKey) && e.code === 'KeyS') { e.preventDefault(); guardar(); }
      });
      // Respaldo automático cada 5 minutos (solo si hubo cambios; nunca pregunta nada)
      setInterval(respaldar, 5 * 60 * 1000);
      // Aviso al cerrar con cambios sin guardar en carpeta
      window.addEventListener('beforeunload', (e) => {
        if (Ed.sinGuardar && soportado && raiz) { e.preventDefault(); e.returnValue = ''; }
      });

      // Al abrir el editor: primero la ventana de proyectos (opción "Mostrar al abrir el editor", de serie sí);
      // y siempre la primera vez o con un proyecto sin carpeta
      let alIniciar = true;
      try { alIniciar = localStorage.getItem('forja-proyectosAlIniciar') !== 'no'; } catch (err) { /* sin almacenamiento */ }
      const chk = $('dlgAlIniciar');
      if (chk) {
        chk.checked = alIniciar;
        chk.onchange = () => { try { localStorage.setItem('forja-proyectosAlIniciar', chk.checked ? 'si' : 'no'); } catch (err) { /* nada */ } };
      }
      if (alIniciar || (soportado && (!raiz || !Ed.carpetaActual))) abrirDialogo();
    },
    marcarSucio,
    guardar,
    guardarArchivo,
    respaldar,
    abrirDesdeSeleccion,
    listar,
    abrir,
    abrirDialogo,
    // Para pruebas: usar una carpeta ya obtenida (por ejemplo el almacenamiento privado del navegador)
    _usarRaiz(h) { raiz = h; pintarBarra(); },
  };
})(window.FORJA);
